// Decompiled by DJ v3.0.0.63 Copyright 2002 Atanas Neshkov  Date: 8/16/2009 11:03:49 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CustomMbo.java

package com.psa.app.packaging;

import java.rmi.RemoteException;
import psdi.mbo.*;
import psdi.util.MXException;
import com.psa.app.packaging.*;
import java.rmi.*;
import psdi.util.MXApplicationException;

// Referenced classes of package psdi.mbo.custapp:
//            CustomMboRemote

public class PackageLines extends Mbo
    implements PackageLinesRemote
{

    public PackageLines(MboSet ms)
        throws MXException, RemoteException
    {
        super(ms);
        super.add();
        System.out.println("--Inside Pack Lines main add--");
        
    }

	public void add() throws MXException , RemoteException
	{
		System.out.println("add() of PackageLines.java");
		MboRemote owner = getOwner();
		if(owner != null && (owner instanceof PackageRemote))
		{
		    System.out.println("add() of PackageLines.java --2");
			setValue("PACKAGEID", owner.getString("PACKAGEID"), 11L);
			setValue("ORGID", owner.getString("ORGID"), 11L);
			setValue("POLINENUM", (int)getThisMboSet().max("POLINENUM")+1, 11L);
		}
		super.add();
		System.out.println("--Inside Pack Lines add after--");
	}


	public void init()
		throws MXException
	{
		super.init();
try
{
if(!isNew())
{
	System.out.println("--Inside Pack Lines --");
    String alwaysReadOnlyLine[] = {"POLINENUM","ITEMNUM","QTY","BINNUM","CONDITIONCODE"};   
    setFieldFlag(alwaysReadOnlyLine, 7L, true);
    System.out.println("--Inside Pack Lines After--");
}
}
catch(RemoteException e)
{
e.printStackTrace();

}


	}

	public void canDelete()
    		throws MXException, RemoteException
	{
		MboRemote owner = getOwner();
		String packageStatus = owner.getString("STATUS");
        	if(packageStatus.equalsIgnoreCase("CAN") || packageStatus.equalsIgnoreCase("ISSUED") || packageStatus.equalsIgnoreCase("TRANSFER"))        		
			throw new MXApplicationException("jspmessages", "table_cannotdelete");
	}
	
	public MboRemote duplicate()
        throws MXException, RemoteException
    {
        return copy();
    }

    protected boolean skipCopyField(MboValueInfo mvi)
        throws RemoteException, MXException
    {
        return !mvi.getAttributeName().equalsIgnoreCase("SITEID") && !mvi.getAttributeName().equalsIgnoreCase("ORGID") && mvi.isKey();
    }
}