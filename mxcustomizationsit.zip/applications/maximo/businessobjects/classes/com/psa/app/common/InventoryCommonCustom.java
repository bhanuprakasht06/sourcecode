/*
 * Modification history
 * 05-10-2007	AGD	SR-117	Common method related to inventory
 */
package com.psa.app.common;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXException;


public final class InventoryCommonCustom
{

	/*
	 * Check wheter an inventory record exist
	 */
	public static MboRemote getInventoryMbo(String itemnum, String storeroom, String siteid, UserInfo userinfo)
			throws MXException, RemoteException
	{
		MboSetRemote inventory = MXServer.getMXServer().getMboSet("INVENTORY", userinfo);
		SqlFormat sqlformat = new SqlFormat("itemnum=:1 AND location=:2 AND siteid=:3");
		sqlformat.setObject(1, "inventory", "itemnum", itemnum);
		sqlformat.setObject(2, "inventory", "location", storeroom);
		sqlformat.setObject(3, "inventory", "siteid", siteid);
		inventory.setWhere(sqlformat.format());
		return inventory.getMbo(0);
	}


	/*
	 * Get the balance given an item, store, condition code
	 */
	public static double getBalance(String itemnum, String location, String storelocsite, String conditioncode, UserInfo userinfo)
			throws RemoteException, MXException
	{
		MboRemote inventory = InventoryCommonCustom.getInventoryMbo(itemnum, location, storelocsite, userinfo);
		return getBalance(inventory, conditioncode);
	}


	/*
	 * Get the balance of an inventory record with a specific condition code
	 */
	public static double getBalance(MboRemote inventory, String conditioncode)
			throws RemoteException, MXException
	{
		double curbal = 0;	//return value

		MboSetRemote invbalset = inventory.getMboSet("INVBALANCES");
		MboRemote invbal = null;
		for (int i = 0; (invbal = invbalset.getMbo(i)) != null; i++)
		{
			if (invbal.getString("conditioncode").equals(conditioncode))
				curbal = curbal + invbal.getDouble("curbal");
		}
		invbalset.close();
		return curbal;
	}

}
