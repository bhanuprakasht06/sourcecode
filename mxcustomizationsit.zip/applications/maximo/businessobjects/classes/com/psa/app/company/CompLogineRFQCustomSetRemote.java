/*
 * Modification history
 * 28-09-07	AGD	NA		Creation
 */
package com.psa.app.company;

import psdi.mbo.MboSetRemote;

public interface CompLogineRFQCustomSetRemote
		extends MboSetRemote
{

}
