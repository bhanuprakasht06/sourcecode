/*
 * Modification history
 * 03-Oct-2007		AGD	SR-116	Validate vendor and update lookup
 */
package com.psa.app.common.purchasing;

import java.rmi.RemoteException;

import com.psa.app.common.VendorCheckCustom;

import psdi.app.common.purchasing.FldPurVendor;
import psdi.app.pr.PR;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXException;


public class FldPurVendorCustom extends FldPurVendor
{

	public FldPurVendorCustom(MboValue vendorvalue)
			throws MXException, RemoteException
	{
		super(vendorvalue);
	}


	/*
	 * Vendor validation
	 */
	public void validate()
			throws MXException, RemoteException
	{
		super.validate();
		if (getMboValue().getMbo() instanceof PR)
			VendorCheckCustom.checkValidity(getMboValue(), "PR_VENDOR");
		else
			VendorCheckCustom.checkValidity(getMboValue(), "VENDOR");
	}


	/*
	 * Lookup
	 */
	public MboSetRemote getList()
   		throws MXException, RemoteException
   {
   	return VendorCheckCustom.getValidVendorList(getMboValue().getMbo());
   }

}
