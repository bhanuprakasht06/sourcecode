/*
 * Modification history
 * 22-06-07	LS	Clear Reservation for Force Cancel Action 
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public class ClearReservationCustom 
	implements ActionCustomClass
{
	public ClearReservationCustom() 
	{
	}

	public void applyCustomAction(MboRemote mboremote, Object aobj[])
		throws MXException, RemoteException
	{
		MboSetRemote invresvsetremote = mboremote.getMboSet("INVRESERVE");
		invresvsetremote.deleteAll();
	}
}
