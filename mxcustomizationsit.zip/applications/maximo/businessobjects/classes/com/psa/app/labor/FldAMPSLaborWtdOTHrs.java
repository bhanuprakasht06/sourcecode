/*
 * Modification history 
 * 
 * 23-11-2020: BCT Modified (Oracle to SQL conversion)
 * 
 */

package com.psa.app.labor;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;

import com.ibm.icu.text.SimpleDateFormat;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;

public class FldAMPSLaborWtdOTHrs extends MboValueAdapter
{
	public FldAMPSLaborWtdOTHrs(MboValue mbv)
			throws MXException
	{
		super(mbv);
	}

	public void initValue()
			throws MXException, RemoteException
	{
		super.initValue();
	
	    double laborWtdOTHrs = 0.0D;
	    int laborWtdOTHrs_int = 0;
	    MboRemote mboRemote = getMboValue().getMbo();
	    MboValue laborMtdOTHrsTotal = getMboValue();
	    
	
	    if (!getMboValue("laborcode").isNull())
	    {
	    	MboSetRemote laborTransSetA = MXServer.getMXServer().getMboSet("LABTRANS", mboRemote.getUserInfo());
	    	
	    	/*
	    	 * 23-11-2020
	    	 * <START> - Code below has been commented as part of the DB migration from Oracle to SQL 
			 * Informational Message: This MboSet (LabTransSetA) will fetch the labtrans records that has start time and end time in current week
	    		SqlFormat sqlformatLabA = new SqlFormat(mboRemote.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE>=trunc(SYSDATE,'W')+1 and FINISHDATE>=trunc(SYSDATE,'W')+1 and FINISHDATE<trunc(SYSDATE,'W')+7");
			 * <END>
			 */
	    	
	    	SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy HH:mm");
			
			Calendar startDateCal = Calendar.getInstance();			 
			startDateCal.setFirstDayOfWeek(Calendar.MONDAY);
			startDateCal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
			startDateCal.set(Calendar.HOUR_OF_DAY, 0);
			startDateCal.clear(Calendar.MINUTE);
			startDateCal.clear(Calendar.SECOND);
			startDateCal.clear(Calendar.MILLISECOND);
			
			Date startDate = startDateCal.getTime();
			String startDateString = format.format(startDate);
			
			System.out.println(">>>>>>>>>>>>>>>> START DAY OF THE WEEK IS : " + startDateString);
			
			Calendar endDateCal = Calendar.getInstance();			
			endDateCal.setFirstDayOfWeek(Calendar.MONDAY);
			endDateCal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
			endDateCal.add(Calendar.DATE,7);
			endDateCal.set(Calendar.HOUR_OF_DAY, 0);
			endDateCal.clear(Calendar.MINUTE);
			endDateCal.clear(Calendar.SECOND);
			endDateCal.clear(Calendar.MILLISECOND);
			
			Date endDate = endDateCal.getTime();
			String endDateString = format.format(endDate);
			System.out.println(">>>>>>>>>>>>>>>> LAST DAY OF THE WEEK IS : " + endDateString);
	    	
	    	SqlFormat sqlformatLabA = new SqlFormat(mboRemote.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE>= '"+startDateString+"' and FINISHDATE>= '"+startDateString+"' and FINISHDATE< '"+endDateString+"'");
	    	/*
			 * 23-11-2020 : BCT Modification Ends here
			 * <END>
			 */
	    	sqlformatLabA.setObject(1, "LABTRANS", "LABORCODE", mboRemote.getString("laborcode"));
	    	sqlformatLabA.setObject(2, "LABTRANS", "PSA_OT_FLAG", "1");
	    	laborTransSetA.setWhere(sqlformatLabA.format());
	    	System.out.println(">>>>>>>>>>> LABTRANS SET-A Query is : " + sqlformatLabA.format());
	    	
			MboSetRemote laborTransSetB = MXServer.getMXServer().getMboSet("LABTRANS", mboRemote.getUserInfo());
			/*
	    	 * 23-11-2020
	    	 * <START> - Code below has been commented as part of the DB migration from Oracle to SQL.  
			 * Informational Message: This MboSet (LabTransSetB) will fetch the labtrans records that has start time prior to current week and end time in current week
	    		SqlFormat sqlformatLabB = new SqlFormat(mboRemote.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE<trunc(SYSDATE,'W')+1 and FINISHDATE>=trunc(SYSDATE,'W')+1 and FINISHDATE<trunc(SYSDATE,'W')+7");
			 * 
			 */
			SqlFormat sqlformatLabB = new SqlFormat(mboRemote.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE< '"+startDateString+"' and FINISHDATE>= '"+startDateString+"' and FINISHDATE< '"+endDateString+"'");
			/*
			 * 23-11-2020 : BCT Modification Ends here
			 * <END>
			 */
			sqlformatLabB.setObject(1, "LABTRANS", "LABORCODE", mboRemote.getString("laborcode"));
	    	sqlformatLabB.setObject(2, "LABTRANS", "PSA_OT_FLAG", "1");
	    	laborTransSetB.setWhere(sqlformatLabB.format());
	    	System.out.println(">>>>>>>>>>> LABTRANS SET-B Query is : " + sqlformatLabB.format());
	    	
	    	Calendar calThisMth = Calendar.getInstance();
			//calThisMth.set(Calendar.DATE, 1);
			//calThisMth.setFirstDayOfWeek(Calendar.MONDAY);
			calThisMth.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
			calThisMth.set(Calendar.HOUR_OF_DAY, 0);
	        calThisMth.set(Calendar.MINUTE, 0);
	        calThisMth.set(Calendar.SECOND, 0);
	        calThisMth.set(Calendar.MILLISECOND,0);
			Date thisMthFirstDate = calThisMth.getTime();
			LabTransCustomRemote labtrans;
	    	for (int i = 0; (labtrans = (LabTransCustomRemote)laborTransSetB.getMbo(i)) != null; i++)
	     	{
		     	labtrans.checkDates();
		     	Date dtFinish = labtrans.validateDateTime(labtrans.getDate("finishdate"), labtrans.getDate("finishtime"));
	    		Date dtStart = labtrans.validateDateTime(thisMthFirstDate, thisMthFirstDate);
		     	if ((dtFinish != null) && (dtStart != null))
			    {
		     		laborWtdOTHrs = laborWtdOTHrs + (dtFinish.getTime() - dtStart.getTime()) / 3600000.0D;
			    }	     	
		    }	    
	    	laborWtdOTHrs = laborWtdOTHrs + laborTransSetA.sum("REGULARHRS");
	    	laborWtdOTHrs_int=(int)laborWtdOTHrs;
	    	int decimal_add=0;
	    	double decimal = laborWtdOTHrs-(int)laborWtdOTHrs;
	    	if (decimal>0)
	    		decimal_add=1;
	    	laborWtdOTHrs_int=laborWtdOTHrs_int+decimal_add;
	    }
	    laborMtdOTHrsTotal.setValue(laborWtdOTHrs_int, 11L);
	}
}