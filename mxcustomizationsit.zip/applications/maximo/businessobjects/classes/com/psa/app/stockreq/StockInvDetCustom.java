/*
 * Modification history
 * 27-05-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.*;

import psdi.mbo.*;
import psdi.util.*;
import psdi.mbo.custapp.*;

public class StockInvDetCustom extends CustomMbo 
	implements StockInvDetCustomRemote 
{
	
	public StockInvDetCustom (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void init()
    	throws MXException
    {
	    super.init();
	    String alwaysReadOnly[] = {
	        "ITEMNUM", "COMMODITYGROUP", "COMMODITY", "ISSUEUNIT", "SITEID", "SECTION"
	    };
	    String OwnerReadOnly[] = {
		        "DESCRIPTION", "DESCRIPTION_LONGDESCRIPTION", "ITEMNUM", "COMMODITYGROUP", "COMMODITY", "ISSUEUNIT", "SITEID", "SECTION", "EQTYPE", "BRANDBATCH", "ITEMSIZE", "RECOND", "MODIFIED", "COVERRISK", "SPARESBRAND", "SYSTEM", "REORDERPOINT", "REORDERUSGQTY", "REORDERUSGINT", "INTORDERQTY", "SSTOCK", "CATALOGNUM", "REMARK", "IMSJO"
		};
	    String Required[] = {
	            "STORELOC", "ROP", "EOQ", "VENDOR"
	    };
	    setFieldFlag(alwaysReadOnly, 7L, true);
	    setFieldFlag(Required, 8L, true);
	    
	    MboRemote owner;
	    owner = getOwner();
	    if(owner == null)
	        return;
	    try 
	    {
			owner.setFieldFlag(OwnerReadOnly, 7L, true);
		} catch (RemoteException e) {
			e.printStackTrace();
		}	    
	    if(toBeAdded())
	        return;
	    try
	    {
	        if(owner.getString("STATUS").equals("CLOSED") || owner.getString("STATUS").equals("CAN"))
	        {
	        	setFlag(7L, true);
	            return;
	        }
	    }
	    catch(RemoteException rx)
	    {
	        rx.printStackTrace();
	    }
	    return;
	}
	
	public void add() 
		throws MXException, RemoteException 
	{
		super.add();
		MboRemote owner = getOwner();
		setValue("STOCKREQNUM", owner.getString("STOCKREQNUM"), 11L);		
		setValue("ITEMNUM", owner.getString("ITEMNUM"), 2L);
		setValue("DESCRIPTION", owner.getString("DESCRIPTION"), 11L);
		setValue("COMMODITYGROUP", owner.getString("COMMODITYGROUP"), 11L);
		setValue("COMMODITY", owner.getString("COMMODITY"), 11L);
		setValue("ISSUEUNIT", owner.getString("ISSUEUNIT"), 11L);
		setValue("SECTION", owner.getString("SECTION"), 11L);
		setValue("ITEMSETID", owner.getString("ITEMSETID"), 11L);
		setValue("ORGID", owner.getString("ORGID"), 11L);
		if (owner.getDouble("REORDERPOINT") > 0.0D)
		{
			double eoq = owner.getDouble("REORDERPOINT") * 1.25;
			eoq = Math.ceil(eoq);
			setValue("EOQ", eoq, 2L);
			setValue("ROP", owner.getDouble("REORDERPOINT"), 2L);
		}
		else if(owner.getDouble("REORDERPOINT") <= 0.0D)
		{
			setValue("EOQ", 1, 2L);
			setValue("ROP", owner.getDouble("REORDERPOINT"), 2L);
		}
		setValue("SSTOCK", owner.getDouble("SSTOCK"), 2L);
		String brandofspares = owner.getString("SPARESBRAND");
		SqlFormat sqf = new SqlFormat(this, " COMPANY = '"+brandofspares+"'");
        MboSetRemote CompanySetRemote = getMboSet("$COMPANIES", "COMPANIES", sqf.format());
        MboRemote CompanyMbo = CompanySetRemote.getMbo(0);
        if (CompanyMbo != null)
        {
        	setValue("MANUFACTURER", brandofspares, 11L);
        }
	}	
		
	public void save() 
		throws MXException, RemoteException 
	{
		super.save();
	}
	
	public void canDelete()
    throws MXException, RemoteException
	{
		MboRemote owner = getOwner();
		String stockIteStatus = owner.getString("STATUS");
        if(stockIteStatus.equalsIgnoreCase("CLOSED") || stockIteStatus.equalsIgnoreCase("CAN"))
        	throw new MXApplicationException("jspmessages", "table_cannotdelete");
	}
	 
}
