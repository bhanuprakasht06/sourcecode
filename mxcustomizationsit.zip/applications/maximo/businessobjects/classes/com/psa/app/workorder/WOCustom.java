/*
 * Modification history
 * 20-06-06	HCHCA	NA			Creation
 * 10-04-07	LS		DR-015	Allow editing of WOInterrupt during edit WO history
 * 28-05-07	AGD	SR-030	Set project fields read-only depending on work type
 * 06-06-07	AGD	SR-097	Derive responsibility centre for project WO from expenditure organization
 * 25-06-07	RHA	SR-105	Upon saving a WO, check that the Oracle asset number is populated for the 
 * 						WO location or asset if the GL account is 4XXX-series (main account segment).
 * 						If not, the WO cannot be saved.
 * 10-10-08 HMD	DR-63	Include FCPROJECTID & FCTASKID details into WO When creating follow up WO
 * PO/CS/016/13--Version 0.1 UAT
 * 16-07-2013--4.1.2--  Enhance Work Order Tracking Application to enforce WO must be a child or follow-up WO
 *  				  	if the work type (MACR, MACI, LACR, LACI) is selected
 * 16-07-2013--4.1.3	Edit history option gives a warning Prompt
 * 16-07-2013--4.1.4	Edit history should have PROBLEMCODE & FAILIURECODE Editable 
 * 29-07-2013--4.1.1	Create Followup Work Order across different Site.  
 * 02-10-2020 BCT		Code updated as part of the Chart of Accounts restructure during NextGen Maximo implementation. Below is the account structure
             * 
             * ***********************************************************************************************************************************************
             * 						GLCOMP1		- GLCOMP2					-GLCOMP3	-GLCOMP4		-GLCOMP5	-GLCOMP6		-GLCOMP7		-GLCOMP8
             * ***********************************************************************************************************************************************
             * Old Account Format: Company (3)	- Main Acc (4)			 	-Type(1)	-LOB(2)		 	-InterCo(3) -Resp Center(4)	-Sub (4)		-Local (3)
             * New Account Format: Company (3)	- Main Acc (4)+ Sub Acc(3) 	-LOB(3)		-Resp Center(4) -InterCo(3) -Future1(4)		-Future2(4)     - NA  
			 ************************************************************************************************************************************************
 * 
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.poi.util.SystemOutLogger;

import psdi.app.asset.AssetRemote;
import psdi.app.common.AncMbo;
import psdi.app.common.TicketWOUtility;
import psdi.app.inventory.MatRecTrans;
import psdi.app.inventory.MatRecTransSetRemote;
import psdi.app.inventory.MatUseTrans;
import psdi.app.inventory.MatUseTransSetRemote;
import psdi.app.labor.LabTrans;
import psdi.app.labor.LabTransSetRemote;
import psdi.app.labor.ServRecTrans;
import psdi.app.labor.ServRecTransSetRemote;
import psdi.app.pm.PM;
import psdi.app.pm.PMRemote;
import psdi.app.workorder.WO;
import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOSetRemote;
import psdi.app.workorder.WPMaterialSetRemote;
import psdi.app.workorder.WPService;
import psdi.app.workorder.WPServiceSetRemote;

import com.psa.custom.common.MboConstantsCustom;

import psdi.mbo.GLFormat;
import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetEnumeration;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.MaxVarServiceRemote;
import psdi.util.MXAccessException;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;




import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;



public class WOCustom extends WO 
implements WORemote, AncMbo
{
//	private boolean editHist;
	private double orgTotalCost;
		
public WOCustom(MboSet arg0)throws MXException, RemoteException 
{
	super(arg0);
}

//Custom Method : When Asset and Location are selected if the locations has valid OAASSETNUM and GLAccount
//             it will populate the Location GLaccount to workorder. 


public void PSAcalcGLAccount()
    throws RemoteException, MXException
{
	
	//System.out.println("Inside PSAcalcGLAccount()");
	
    MboValue mbovalue = getMboValue("GLAccount");
       if(getBoolean("ChargeStore"))
    {    	
        if(!isNull("assetnum"))        {
        	 
            String s = getString("asset.rotsuspacct");           
            mbovalue.setValue(s, 2L);
            mbovalue.setReadOnly(true);
        }
    } else
    {    
    	//System.out.println("Inside PSAcalcGLAccount() Before Merging GL-->"+mbovalue);
    	
        mbovalue.setReadOnly(false);
        String s1 = "";
        String s2 = "";       
        if(!isNull("assetnum") && isNull("location"))
            s1 = getString("asset.glaccount");
       
         else if(!isNull("assetnum") && !isNull("location") && !isNull("location.glaccount") && !isNull("location.OAASSETNUM"))
            s1 = getString("location.glaccount");
         else
            s1 = getString("asset.glaccount");
        
               
        if(!isNull("location"))
            s2 = getString("location.glaccount");        
        if(s1.equals("") && s2.equals(""))        	 
            return;       
        GLFormat glformat = new GLFormat(s1, getString("orgid"));      
        glformat.mergeString(s2);       
        mbovalue.setValue(glformat.toDisplayString(), 2L);
        
    	//System.out.println("Inside PSAcalcGLAccount() After Merging GL-->"+mbovalue);
    }
}

//Custom End


public boolean glCodeValidation() throws MXException,RemoteException
{

	String workType=getString("WORKTYPE");
	
	String woGLAccount=getString("GLACCOUNT");
	
	MboSetRemote workTypeSetRemote=MXServer.getMXServer().getMboSet("WORKTYPE", getUserInfo());
	
	//System.out.println("Inside glCodeValidation()");
	workTypeSetRemote.setWhere("WORKTYPE='"+workType+"'");
	workTypeSetRemote.reset();
	
	if(!workTypeSetRemote.isEmpty() & workTypeSetRemote!=null)
	{
		if(workTypeSetRemote.getMbo(0).getBoolean("CAPITALWORK")==false & workTypeSetRemote.getMbo(0).getBoolean("PROJECT")==false )
		{
			//System.out.println("Before Merging GLAccount"+woGLAccount);
			
			MboSetRemote accountDefaultSet = MXServer.getMXServer().getMboSet("ACCOUNTDEFAULTS",getUserInfo());
			String woTypeGlaccount=workTypeSetRemote.getMbo(0).getString("GLACCOUNT");
		    GLFormat glformat = new GLFormat(woGLAccount, getString("orgid"));      
	        glformat.mergeString(woTypeGlaccount);   
	        String partialGL= glformat.toDisplayString();
	        WPMaterialSetRemote wpmaterialSetRemote = (WPMaterialSetRemote) getMboSet("WPMATERIAL");
	        
			//System.out.println("After Merging GLAccount"+woGLAccount);
	        
	        if(wpmaterialSetRemote.count(MboConstants.COUNT_AFTERSAVE)>0)
	        {
	        	MboRemote wpMaterialRemote=null;
				
				for(int i=0;(wpMaterialRemote=wpmaterialSetRemote.getMbo(i))!=null;i++)
				{
				String lineType=wpMaterialRemote.getString("LINETYPE");
				String itemNum=wpMaterialRemote.getString("ITEMNUM");
	        	
	        	if(lineType.equalsIgnoreCase("MATERIAL"))
	        	{
	        	accountDefaultSet.setWhere(  "DFLTGROUP='MATERIAL_RC' and GROUPVALUE='0' " );
	        	accountDefaultSet.reset();
	        	accountDefaultSet.count();
	        	
	        	String materialDefltgl;
	        	
	        	if(!accountDefaultSet.isEmpty() & accountDefaultSet!=null)
	        	{
	        		  materialDefltgl=accountDefaultSet.getMbo(0).getString("GLDEFAULT");
	        		  GLFormat actualGLcode = new GLFormat(partialGL, getString("orgid"));    
	        		  actualGLcode.mergeString(materialDefltgl);
	        		  String glCodeValidate=actualGLcode.toDisplayString();
	        		  System.out.println("MATERIAL::::"+glCodeValidate);
	        		   int recordExit=glCodeExist(glCodeValidate);
	        		   if(0==recordExit)
	        		   {
	        			   return true;
	        		   }
	        		
	        	}
	        	}
	        	if(lineType.equalsIgnoreCase("ITEM"))
	        	{
	        		MboSetRemote itemSetRemote =MXServer.getMXServer().getMboSet("ITEM", getUserInfo());
	        		
	        		itemSetRemote.setWhere("ITEMNUM='"+itemNum+"'");
	        		itemSetRemote.reset();
	        		
	        		if(!itemSetRemote.isEmpty()& itemSetRemote!=null)
	        		{
	        			String commodityGrp=itemSetRemote.getMbo(0).getString("COMMODITYGROUP");
	        			
	        			accountDefaultSet.setWhere("GROUPVALUE='"+commodityGrp+"'");
	    	        	accountDefaultSet.reset();
	    	        	
	    	        	String itemCommGrpgl;
	    	        	
	    	        	if(!accountDefaultSet.isEmpty() & accountDefaultSet!=null)
	    	        	{
	    	        		itemCommGrpgl=accountDefaultSet.getMbo(0).getString("GLDEFAULT");
	    	        		  GLFormat actualGLcode = new GLFormat(partialGL, getString("orgid"));    
	    	        		  actualGLcode.mergeString(itemCommGrpgl);
	    	        		  String glCodeValidate=actualGLcode.toDisplayString();
	    	        		  System.out.println("ITEM::::"+glCodeValidate);
	    	        		   int recordExit=glCodeExist(glCodeValidate);
	    	        		   if(0==recordExit)
	    	        		   {
	    	        			   return true;
	    	        		   }
	    	        		
	    	        	}
	        			
	        		}
	        		
	        		
	        	}
	        	
	        	
				}
	        	
	        }
	        
	        
	        
	        WPServiceSetRemote wpServiceSetRemote = (WPServiceSetRemote) getMboSet("WPSERVICE");
	        if(wpServiceSetRemote.count(MboConstants.COUNT_AFTERSAVE)>0)
	        {
	        	MboRemote wpServiceRemote=null;
				
				for(int i=0;(wpServiceRemote=wpServiceSetRemote.getMbo(i))!=null;i++)
				{
				String lineType=wpServiceRemote.getString("LINETYPE");
				String itemNum=wpServiceRemote.getString("ITEMNUM");
	        	
	        	if(lineType.equalsIgnoreCase("SERVICE"))
	        	{
	        	accountDefaultSet.setWhere("DFLTGROUP='SERVICE_RC' and GROUPVALUE='0' ");
	        	accountDefaultSet.reset();
	        	
	        	String serviceDefltgl;
	        	
	        	if(!accountDefaultSet.isEmpty() & accountDefaultSet!=null)
	        	{
	        		  serviceDefltgl=accountDefaultSet.getMbo(0).getString("GLDEFAULT");
	        		  GLFormat actualGLcode = new GLFormat(partialGL, getString("orgid"));    
	        		  actualGLcode.mergeString(serviceDefltgl);
	        		  String glCodeValidate=actualGLcode.toDisplayString();
	        		  System.out.println("WPSERVICE::::"+glCodeValidate);
	        		   int recordExit=glCodeExist(glCodeValidate);
	        		   if(0==recordExit)
	        		   {
	        			   return true;
	        		   }
	        		
	        	}
	        	}
	        	if(lineType.equalsIgnoreCase("STDSERVICE"))
	        	{
	        		MboSetRemote serviceItemSetRemote =MXServer.getMXServer().getMboSet("SERVICEITEMS", getUserInfo());
	        		
	        		serviceItemSetRemote.setWhere("ITEMNUM='"+itemNum+"'");
	        		serviceItemSetRemote.reset();
	        		
	        		if(!serviceItemSetRemote.isEmpty()& serviceItemSetRemote!=null)
	        		{
	        			String commodityGrp=serviceItemSetRemote.getMbo(0).getString("COMMODITYGROUP");
	        			
	        			accountDefaultSet.setWhere("GROUPVALUE='"+commodityGrp+"'");
	    	        	accountDefaultSet.reset();
	    	        	
	    	        	String serviceItemCommGrpgl;
	    	        	
	    	        	if(!accountDefaultSet.isEmpty() & accountDefaultSet!=null)
	    	        	{
	    	        		serviceItemCommGrpgl=accountDefaultSet.getMbo(0).getString("GLDEFAULT");
	    	        		  GLFormat actualGLcode = new GLFormat(partialGL, getString("orgid"));    
	    	        		  actualGLcode.mergeString(serviceItemCommGrpgl);
	    	        		  String glCodeValidate=actualGLcode.toDisplayString();
	    	        		  System.out.println("SERVICEITEMS::::"+glCodeValidate);
	    	        		   int recordExit=glCodeExist(glCodeValidate);
	    	        		   if(0==recordExit)
	    	        		   {
	    	        			   return true;
	    	        		   }
	    	        		
	    	        	}
	    	        	else 
	    	        		return false;
	        		}
	        		
	        		
	        	}
	        	
	        	
				}
	        	
	        }
	        
	       
	        
	        
	        
	        
	        
		}
		
	}
	return false;
	
}

public int glCodeExist(String glCodeValidate) throws MXException,RemoteException
{
	int count=0;
	  SqlFormat chartOFAacctsql = new SqlFormat("GLACCOUNT =:1 AND ACTIVE =1");
	  chartOFAacctsql.setObject(1,"CHARTOFACCOUNTS","GLACCOUNT",glCodeValidate);
	  MboSetRemote  chartOFAacctSetRemote=getMboSet("$CHARTOFACCOUNTS","CHARTOFACCOUNTS",chartOFAacctsql.format());
	  if(!chartOFAacctSetRemote.isEmpty() & chartOFAacctSetRemote!=null)
	  	{
		  count=chartOFAacctSetRemote.count();
	  		
	  		return count;
	  	
	  }
	return count;
}

public MboRemote woGLValidation()throws MXException, RemoteException
{
	MboRemote owner=getOwner();
	return owner;
}

protected void save()
	throws MXException, RemoteException
{
	
String previousStatus=getMboInitialValue("STATUS").toString();

// Added the Below Code on 01-July-2022 for Linear Asset Configuration

//System.out.println("PreviousStatus Status-->"+previousStatus);
//System.out.println("Current Status-->"+getString("STATUS"));

boolean isLinear = false;

if ((getString("WORKTYPE").equalsIgnoreCase("TLPA") || getString("WORKTYPE").equalsIgnoreCase("TLPM1") ||  getString("WORKTYPE").equalsIgnoreCase("MAPM1") ))
{
	isLinear = true;
}

if (isLinear)
{
	super.save();
}
else
{

	if(!isNew()&& !getString("STATUS").equalsIgnoreCase("WSCH")&& !getString("STATUS").equalsIgnoreCase("PRGENFAIL") && !previousStatus.equalsIgnoreCase("PRGENFAIL") )
	{
		
if (!getInternalStatus().equalsIgnoreCase("APPR")&!getInternalStatus().equalsIgnoreCase("CLOSE") & !getInternalStatus().equalsIgnoreCase("CAN") & !getInternalStatus().equalsIgnoreCase("COMP")) 
{
	
	//System.out.println("Before glCodeValidation()");
		
		boolean recordExist = glCodeValidation();
		
	//System.out.println("After glCodeValidation()");
	//System.out.println("After glCodeValidation()"+ getString("GLACCOUNT"));
	
	
		if(recordExist)
			{
				throw new MXApplicationException("WO", "Glcheck");
			}

}
}		
	/* Start of Modification - LS */
	/* PSSD_EAMS_IN_2010_013_Pre INCAS */
	/*PSA_Ref-4.1.2 comment start old code for work type validation
	if(getString("WORKTYPE").equals("ACI") || getString("WORKTYPE").equals("ACR"))
	{		
		try 
		{			
			if(isNull("PARENT") && isNull("ORIGRECORDID"))
				throw new MXApplicationException("workorder", "nonparentwo");
		}catch(RemoteException remoteexception) 
		{
		}
		
	}
	
	/* End of Modification - LS */

	//System.out.println("[WOCustom.save()]Entering...");
	//Comment end PSA_REF4.1.2
//********************************PSA_REF4.1.2 Validation Start*************************************************************
	boolean mustChild=false;
	if(!isNull("WORKTYPE"))
	{
		System.out.println("###IN WORK TYPE VALIDTAION ###");
		MboRemote workorder=getMboValue("WORKTYPE").getMbo();
		MboSetRemote wotype=workorder.getMboSet("WOTYPE");
		System.out.println("###Total VALUES IN DOMAIN IS--"+wotype.getSize()+"###");
		System.out.println("###VALUE OF WORK TYPE IN WO--"+getString("WORKTYPE")+"###");
			for(int i =0;(wotype.getMbo(i)!=null&&!mustChild);i++)
			{
				System.out.println("###Comaparing WO work type with value--"+wotype.getMbo(i).getString("VALUE")+"###");
				if(getString("WORKTYPE").equalsIgnoreCase(wotype.getMbo(i).getString("VALUE")))
					{
	
						try 
						{			
							if(isNull("PARENT") && isNull("ORIGRECORDID"))
							throw new MXApplicationException("workorder", "nonparentwo");
						}
						catch(RemoteException remoteexception) 
						{
						}
						mustChild=true;
						break;
					}
			}

	}
	
	//********************************PSA_REF4.1.2 Validation END*************************************************************	
	//********************************PSA_REF4.1.4 Validation Start*************************************************************
	if(isWOInEditHist())
    {
         histEdit();
         AssetRemote asset = getAsset();
         if(asset != null && getBoolean("chargestore"))
        {
             double newTotalCost = getDouble("actlabcost") + getDouble("acttoolcost") + getDouble("actmatcost") + getDouble("actservcost");
             double deltaTotalCost = newTotalCost - orgTotalCost;
             MXLogger myLogger = MXLoggerFactory.getLogger("maximo.application.WOTRACK");
             if(myLogger.isDebugEnabled())
                 myLogger.debug((new StringBuilder()).append("** deltaTotalCost =").append(deltaTotalCost).toString());
             if(deltaTotalCost != 0.0D)
                 asset.incrInvCost(deltaTotalCost);
        }
	}
	//********************************PSA_REF4.1.4 Validation END*************************************************************
	
	//Change GL account only if not charge to store

	MboValue mbovalue = getMboValue("GLAccount");
	 
	//System.out.println("Inside WOCustom Save() GLAccount-->"+mbovalue);
	if(!getBoolean("ChargeStore")&&!mbovalue.isFlagSet(7L))
    {
		System.out.println("isModified worktype-->"+isModified("worktype"));
		
		
		if(isModified("worktype")||isModified("LOCATION")||isModified("ASSETNUM")){			
			
			//recalculates the GL Account
			//calcGLAccount();
			PSAcalcGLAccount(); 
			
			System.out.println("isNull worktype"+isNull("worktype"));
			
			if(!isNull("worktype")){
				
				//Get GL Account of Work Type
//				String wtGLAccount = getString("worktype.glaccount");
//				System.out.println("[WOCustom.save()]Work Type GL Account:"+wtGLAccount);
				
				//Modified 	By BCT 19-June-2023
				String workType=getString("WORKTYPE");
				MboSetRemote workTypeSetRemote=MXServer.getMXServer().getMboSet("WORKTYPE", getUserInfo());
				workTypeSetRemote.setWhere("WORKTYPE='"+workType+"'");
				workTypeSetRemote.reset();
				
				System.out.println("Inside isNull worktype GL-->"+workTypeSetRemote.getMbo(0).getString("GLACCOUNT"));
				
			if(!workTypeSetRemote.isEmpty() & workTypeSetRemote!=null)
				{
				String wtGLAccount=workTypeSetRemote.getMbo(0).getString("GLACCOUNT");
				
				
				if(wtGLAccount!=null&&!wtGLAccount.equals("")){					
					
					//mbovalue.setReadOnly(false);
					GLFormat glformat = new GLFormat(wtGLAccount, getString("orgid"));
					
					String curGLAccount = getString("glaccount");
					
					//System.out.println("[WOCustom.save()]Current GL Account:"+curGLAccount);
					
					if(curGLAccount!=null&&!curGLAccount.equals("")){
						glformat.mergeString(curGLAccount);
						
						//System.out.println("Inside WOCustom Save() mergeString GLAccount-->"+mbovalue);
						//System.out.println("[WOCustom.save()]Merged GL Account:"+glformat.toDisplayString());
						
//Begin modification SR-097
						// Set the responsibility center from the project expenditure organization
						 
						
						if (workTypeSetRemote.getMbo(0).getBoolean("PROJECT") && !isNull("fcprojectid") && !workTypeSetRemote.getMbo(0).getBoolean("CAPITALWORK"))
						{
							MXLogger mxlogger = getMboLogger();
							mxlogger.debug("GL A/c before modification for Project = " + glformat.toDisplayString());
							String[] segments = glformat.getSegments();							
							if (segments[5].length() != 4)
								throw new MXApplicationException("system", "setupcustopb");
							
							 /* * 02-10-2020
				             * <START> - Code below has been commented as part of the Chart of Accounts restructure
				             * Going forward the RESP CENTER will be the 4th component of the GL account. In the old structure it was the 6th component.
				             * 
				             * 						GLCOMP1		- GLCOMP2					-GLCOMP3	-GLCOMP4		-GLCOMP5	-GLCOMP6		-GLCOMP7		-GLCOMP8
				             * Old Account Format: Company (3)	- Main Acc (4)			 	-Type(1)	-LOB(2)		 	-InterCo(3) -Resp Center(4)	-Sub (4)		-Local (3)
				             * New Account Format: Company (3)	- Main Acc (4)+ Sub Acc(3) 	-LOB(3)		-Resp Center(4) -InterCo(3) -Future1(4)		-Future2(4)     - NA  
							 * 
							segments[5] = getMboSet("FINCNTRL").getMbo(0).getString("oa_expendorgname").substring(0,4);
							*
							*/
							
							segments[3] = getMboSet("FINCNTRL").getMbo(0).getString("oa_expendorgname").substring(0,4);
							
							/* * 02-10-2020
				             * <END> - Code below has been commented as part of the Chart of Accounts restructure
				             */
							glformat = new GLFormat(segments);							
							mxlogger.debug("Modified GL A/c = " + glformat.toDisplayString());
						}
//End modification SR-097

					}

		            mbovalue.setValue(glformat.toDisplayString(), 2L);	
		            
		            //System.out.println("Inside WOCustom Save() Final GLAccount-->"+mbovalue);
		            
				}//End of if(wtGLAccount!=null&&!wtGLAccount.equals(""))
				}//End of if(!workTypeSetRemote.isEmpty() & workTypeSetRemote!=null) #UpdatedBy BCT Jun-2023

			}//End of if(!isNull("worktype"))
		}//End of if(isModified("worktype")||isModified("LOCATION")||isModified("ASSETNUM"))
		
    }// End of if(!getBoolean("ChargeStore")&&!mbovalue.isFlagSet(7L))

	//Comment: Update assetnum if assetnum is blank.
	//System.out.println("***WOCustom.Save.Assetnum:"+getString("ASSETNUM"));
  	if((getString("ASSETNUM").isEmpty() || getString("ASSETNUM").trim().equalsIgnoreCase("")) && 
  	  ((!getString("LOCATION").isEmpty() && !getString("LOCATION").trim().equalsIgnoreCase(""))))
  	{
  		//System.out.println("***WOCustom.Save.loc:"+getString("LOCATION"));
  		setValue("ASSETNUM",getDefaultAssetFromLoc(getString("LOCATION")), 11L);
  	}
	//EOF
//Begin modification SR-105
	//super.save();
	
	//Step 1: Check main account segment of GLACCOUNT. If it is a 4XXX series, go to step 2
	//Step 2: If Step 1 returns true, check if Oracle Asset Number (OAN) of WO Location OR WO Asset is populated	
	//Step 3: If Step 2 returns true, save the WO. Otherwise, throw exception.
	if(isGL4000Series())
	{
		if(isLocationOANPopulated() || isAssetOANPopulated()){
			super.save();
		}
		
		else{
			throw new MXApplicationException("workorder", "oaasetnumNotPopulated");
		}
	}
	else{ //Not a 4XXX series
	
		super.save();
	}
//End modifcation SR-105
	//System.out.println("[WOCustom.save()]Leaving...");



}
	
	

}



/*************** BCT Work order GL Code validation Start***********************/


public boolean checkCondition() throws MXException, RemoteException
{

	
	boolean recordExist=false;
	WPMaterialSetRemote wpmaterialSet = (WPMaterialSetRemote) getMboSet("WPMATERIAL");
	
	WPServiceSetRemote wpserviceSet = (WPServiceSetRemote) getMboSet("WPSERVICE");
	MatUseTransSetRemote matuseSet = (MatUseTransSetRemote) getMboSet("MATUSETRANSISSUED");
	ServRecTransSetRemote servrectransSet = (ServRecTransSetRemote) getMboSet("SERVICES");
	LabTransSetRemote labtranstransSet = (LabTransSetRemote) getMboSet("LABTRANS");
	
if(wpmaterialSet.count(MboConstants.COUNT_AFTERSAVE)>0|| wpserviceSet.count(MboConstants.COUNT_AFTERSAVE)>0 ||matuseSet.count(MboConstants.COUNT_AFTERSAVE)>0 || servrectransSet.count(MboConstants.COUNT_AFTERSAVE)>0 || labtranstransSet.count(MboConstants.COUNT_AFTERSAVE)>0 )
{
	recordExist=true;
}

return recordExist;
}


/*************** BCT Work order GL Code validation End***********************/

//SR 57 - Recond
public void init()
	throws MXException
{
	super.init();
	// Custom code for making the completed field of WOActivity to readonly 
	//System.out.println("-----Inside WOCustom Init-----");
//	try {
//		if(getString("STATUS").equalsIgnoreCase("COMP"))
//		{
//			MboSetRemote woactivity= getMboSet("WOACTIVITY");
//			MboRemote mboremote;
//			for(int i=0;(mboremote = woactivity.getMbo(i))!=null;i++)
//			{
//				mboremote.setFieldFlag("TASKCOMP", 7L, true);
//			}
//		}
//	} catch (RemoteException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}		
	
	/* Start of Modification - LS */
	/* PSSD_EAMS_IN_2010_013_Pre INCAS */

	//Start - Converted to Condition Expression in Maximo 7.6
	/*try
	{
		if(getString("WORKTYPE").equals("ACI"))			
			setFieldFlag("INCASNUM", MboConstantsCustom.REQUIRED, true);		
		else
			setFieldFlag("INCASNUM", MboConstantsCustom.REQUIRED, false);
	} catch(RemoteException remoteexception) { } */
	//End - Converted to Condition Expression in Maximo 7.6
	
	
	/* End of Modification - LS */
	
	if(!toBeAdded())			
	{		
		try
		{
			if(getBoolean("worecond"))
			{
				setFieldFlag("RECONDITEM", 7L, true);
				setFieldFlag("RECONDQTY", 7L, true);
				setFieldFlag("RETURNSTORE", 7L, true);
			}
			if(getString("status").equals("RCNSCRAPAPPR") || getString("status").equals("RCNSCRAP"))
			{
				setFieldFlag("SCRAPQTY", 7L, true);
			}

//Begin modification SR-030
			setProjectFieldsFlags();
//End modification SR-030

			/* Make Waiver of Quotation READONLY */
			if(!getInternalStatus().equals("WAPPR") || getString("STATUS").equalsIgnoreCase("WFAPPR"))
			{
				setFieldFlag("WAVIERQUOTE", 7L, true);
				setFieldFlag("WAVIERQUOTEREMARK", 7L, true);
			}
			/* End of Modification */
			
		}
		catch(RemoteException remoteexception) { }
	}
}



public void add() throws MXException, RemoteException {
	// TODO Auto-generated method stub
	MboRemote owner1=getOwner();
	
	super.add();
	MboRemote owner=getOwner();
	setFieldFlag("SITEID", 7L, false);
	if (owner != null && owner instanceof WORemote)
	{ 
		
		if(isNull("ASSETNUM") && !owner.isNull("ASSETNUM"))
              setValue("ASSETNUM",owner.getString("ASSETNUM"), 66L);
         
		if(isNull("LOCATION") && !owner.isNull("LOCATION"))
        	 setValue("LOCATION",owner.getString("LOCATION"), 66L);

		//BCT Comment: set assetnum to default Asset num from location 
		if(isNull("ASSETNUM") && !owner.isNull("LOCATION"))
		{
			//System.out.println("***WOCustom >> 1A loc:"+owner.getString("LOCATION"));
            setValue("ASSETNUM",getDefaultAssetFromLoc(owner.getString("LOCATION")), 66L);
		}
		
		//BCT EOF
		
		if(isNull("TEAMIC") && !owner.isNull("TEAMIC"))       
	            setValue("teamic",owner.getString("teamic"),2L);
	      
	      setValue("REPORTEDBY",owner.getUserInfo().getUserName(),2L);
	 
	        setValueNull("WORKTYPE");
            setValueNull("GLACCOUNT");
            setValueNull("TARGSTARTDATE");
            setValueNull("TARGCOMPDATE");
            setValueNull("SCHEDSTART");
            setValueNull("SCHEDFINISH");
            setValueNull("ACTSTART");
            setValueNull("ACTFINISH");
            
	}

}


//	Begin modification SR-030
protected void setProjectFieldsFlags()
		throws MXException, RemoteException
{
	String requiredprojectfields[] = { "fcprojectid", "fctaskid" };
	String projectfields[] = { "fcprojectid", "fctaskid", "oa_expendcomment" };
	MboRemote worktype = getMboSet("WORKTYPE").getMbo(0);
	if (worktype != null && worktype.getBoolean("project"))
	{
		setFieldFlag(projectfields, MboConstants.READONLY, false);
		setFieldFlag(requiredprojectfields, MboConstants.REQUIRED, true);
	}
	else
	{
		for (int i = 0; i < projectfields.length; i ++)
			setValueNull(projectfields[i], MboConstants.NOACCESSCHECK);
		setFieldFlag(projectfields, MboConstants.READONLY, true);
		setFieldFlag(requiredprojectfields, MboConstants.REQUIRED, false);
	}
}
//End modification SR-030


//SR 56 - WO Interruption
public void delete(long l)
    throws MXException, RemoteException
{
	getMboSet("WOINTERRUPT").deleteAll(2L);
	super.delete(l);
}


//SR 65 - WO Interruption
protected void setRelatedSetEditibilityFlags()
	throws MXException, RemoteException
{
	if(!isNew())
    {
//		System.out.println("[WOCustom.setRelatedSetEditibilityFlags()] In setRelatedSetEditibilityFlags");
		MboSetRemote mbosetremote = getMboSet("WOINTERRUPT");
		if(mbosetremote != null)
		{
			int i = 0;
//			System.out.println("[WOCustom.setRelatedSetEditibilityFlags()] In Set Flag");
			mbosetremote.setFlag(7L, false);
			for(MboRemote mboremote; (mboremote = mbosetremote.getMbo(i)) != null; i++)
			{
//				System.out.println("[WOCustom.setRelatedSetEditibilityFlags()] WOInterruptid:" + mboremote.getString("WOINTERRUPTID"));
				mboremote.setFlag(7L, false);
			}
//			System.out.println("[WOCustom.setRelatedSetEditibilityFlags()] Flag:" + mbosetremote.getFlags());
		}
    }
	super.setRelatedSetEditibilityFlags();
}

//Begin SR-105 
//This function checks if the main account segment of the GLACCOUNT is a 4XXX series

/**** 02-10-2020 BCT		Code commented as part of the Chart of Accounts restructure during NextGen Maximo implementation. New logic is applied in the uncommented method
	*<START> 

public boolean isGL4000Series() throws MXException, RemoteException{
	boolean isGL4000Series = false;
	String finalGLAccount = getString("glaccount");
	//System.out.println("Start isGL4000Series [finalGLAccount] " + finalGLAccount);
	if(!(finalGLAccount.equals(null) || finalGLAccount.equals("")) ){  
		//System.out.println("Inside  isGL4000Series");
		MXServer mxserver = MXServer.getMXServer();
		UserInfo userinfo = getUserInfo();
		MboSetRemote glconfigureset = mxserver.getMboSet("GLCONFIGURE", userinfo);
		String gldelimiter = glconfigureset.getMbo(0).getString("delimiter");

		String[] glaccountseg = finalGLAccount.split(gldelimiter);
		//System.out.println("Inside  isGL4000Series glaccountseg :"+glaccountseg);
		MboSetRemote maxvarsset = mxserver.getMboSet("MAXVARS", userinfo);			
		SqlFormat sqlformat = new SqlFormat("varname = 'GLSERIESCHECK' AND orgid = '"
				+ getString("orgid")+"'");
		maxvarsset.setWhere(sqlformat.format());
		MboRemote maxvarsMboRemote = null;
		String glseries = "4XXX";
        //System.out.println("[Hardcoded glseriescheck from MAXVARS] " + glseries);
    	if(!maxvarsset.isEmpty()){
    		maxvarsMboRemote = maxvarsset.getMbo(0);
    		glseries = maxvarsMboRemote.getString("varvalue");
    		 //System.out.println("[Real glseriescheck from MAXVARS] " + glseries);        
    	}
		
        if (glaccountseg[1].charAt(0)== glseries.charAt(0))//indexOf(glseries.charAt(0)) >= 0){
        {
        	isGL4000Series = true;
        }
	}
    //System.out.println("End isGL4000Series [isGL4000Series] " + isGL4000Series);
    return isGL4000Series;
}

**** <END>
*/

/**** 02-10-2020 BCT		New logic is applied in the below method
	*<START> 
	*/
public boolean isGL4000Series() throws MXException, RemoteException
{
    boolean checkOAdetails = false;
    String finalGLAccount = getString("glaccount");
    
    if(!(finalGLAccount.equals(null) || finalGLAccount.equals("")) )
    {  
        MXServer mxserver = MXServer.getMXServer();
        UserInfo userinfo = getUserInfo();
        MboSetRemote glconfigureset = mxserver.getMboSet("GLCONFIGURE", userinfo);
        String gldelimiter = glconfigureset.getMbo(0).getString("delimiter");

        String[] glaccountseg = finalGLAccount.split(gldelimiter);
        MboSetRemote maxvarsset = mxserver.getMboSet("MAXVARS", userinfo);            
        SqlFormat sqlformat = new SqlFormat("varname = 'GLSERIESCHECK' AND orgid = '"+ getString("orgid")+"'");
        maxvarsset.setWhere(sqlformat.format());
        MboRemote maxvarsMboRemote = null;
        
		//Default values if the MAXVAR value is not set
        String[] glseries = "55XXXXX,77XXXXX".split(","); 
        
        if(!maxvarsset.isEmpty())
        {
            maxvarsMboRemote = maxvarsset.getMbo(0);
            glseries = maxvarsMboRemote.getString("varvalue").split(",");
        }
        
        for(int i=0;i<glseries.length;i++)
        {
            System.out.println("GL Series from MAXVARS @ "+i+ " is :"+glseries[i]);
           /* if((glaccountseg[1].charAt(0)==glseries[i].charAt(0)) && ((glaccountseg[1].charAt(1)==glseries[i].charAt(1))))
            {
                checkOAdetails = true;
                break;
            }*/
            if( (glaccountseg[1].equalsIgnoreCase("5440110")) ||((glaccountseg[1].charAt(0)==glseries[i].charAt(0)) && ((glaccountseg[1].charAt(1)==glseries[i].charAt(1))) && (!glaccountseg[1].equalsIgnoreCase("5539901")) ) )
            {
                checkOAdetails = true;
                break;
            }
        }
         
    
}
    return checkOAdetails;
}

/**** 02-10-2020 BCT		New logic is applied in the above method
	*<END> 
*/
	
	
//This function checks if the Oracle Asset Number (OAN) of the table LOCATIONS is populated

public boolean isLocationOANPopulated()
throws MXException, RemoteException
{   
	boolean populated = true;
	String  location = getString("location");
	//System.out.println("Start isLocationOANPopulated [location] " + location);
	if(location.equals(null) || location.equals("")){
		populated = false;
	}
	else{
    	
		MboSetRemote locationList = MXServer.getMXServer().getMboSet("LOCATIONS",getUserInfo());
    	SqlFormat sqlformat = new SqlFormat("location = '"+location+"' AND siteid = '"+getString("siteid")+ "' AND orgid = '"+ getString("orgid")+"'");
    	locationList.setWhere(sqlformat.format());
    	MboRemote locationMboRemote = null;
    	if (!locationList.isEmpty())	// only process if there's any NS
		{
    		locationMboRemote = locationList.getMbo(0);
    		String oracleAssetNum = locationMboRemote.getString("oaassetnum");
    		if(oracleAssetNum.equals(null) || oracleAssetNum.equals("")){
    			populated = false;
    		}
    		//System.out.println("isLocationOANPopulated [oracleAssetNum] " + oracleAssetNum);
		}
    	else
    		populated = false;
	}
	//System.out.println("End isLocationOANPopulated [populated] " + populated);
    return populated;
}

//This function checks if the Oracle Asset Number (OAN) of the table ASSET is populated
public boolean isAssetOANPopulated()
throws MXException, RemoteException
{
	boolean populated = true;
	String asset = getString("assetnum");
	//System.out.println("Start isAssetOANPopulated [asset] " + asset);
	
	if(asset.equals(null) || asset.equals("")){
		populated = false;
	}
	
	else{
    	
		MboSetRemote assetList = MXServer.getMXServer().getMboSet("ASSET",getUserInfo());
    	SqlFormat sqlformat = new SqlFormat("assetnum = '"+asset+"' AND siteid = '"+getString("siteid")+"' AND orgid = '"+ getString("orgid")+"'");
    	assetList.setWhere(sqlformat.format());
    	MboRemote assetMboRemote = null;
    	if (!assetList.isEmpty())	// only process if there's any NS
		{
    		assetMboRemote = assetList.getMbo(0);
    		String oracleAssetNum = assetMboRemote.getString("oaassetnum");
    		if(oracleAssetNum.equals(null) || oracleAssetNum.equals("")){
    			populated = false; 			
    		}
    		//System.out.println("isAssetOANPopulated [oracleAssetNum] " + oracleAssetNum);
		}
    	else
    		populated = false;
	}
	//System.out.println("End isAssetOANPopulated [populated] " + populated);
    return populated;
}

//End SR-105

//BCT Comment: getDefaultAssetFromLoc
public String getDefaultAssetFromLoc(String slocation)
throws MXException, RemoteException
{
	String defasset = null;
	
	MboSetRemote defaultAssetSet = MXServer.getMXServer().getMboSet("ASSET",getUserInfo());
  	SqlFormat sqlformat = new SqlFormat("LOCATION = '"+slocation+"' and PSA_DEFASSET=1 and SITEID='PSASG' and STATUS='OPERATING'");
  	System.out.println("***WOCustom.getDefaultAssetFromLoc.sqlformat:"+sqlformat);
  	defaultAssetSet.setWhere(sqlformat.format());
  	defaultAssetSet.reset();
  	
  	MboRemote defaultAssetMboRemote = null;
  	if (!defaultAssetSet.isEmpty() && defaultAssetSet.count() > 0)
	{
  		defaultAssetMboRemote = defaultAssetSet.getMbo(0);
  		defasset = defaultAssetMboRemote.getString("assetnum");
	}
  	
  	System.out.println("***WOCustom.getDefaultAssetFromLoc.defasset:"+defasset);
  return defasset;
}


//Begin Modification DR 63
public MboRemote createWorkorder()
throws MXException, RemoteException
{
    MboSet mboset = (MboSet)getMboServer().getMboSet("WORKORDER", getUserInfo());
   
    mboset.setInsertSite(getString("siteid"));
    mboset.setInsertOrg(getString("orgid"));
    MboRemote mboremote = mboset.add();
    
    //EMS-578 Start
    mboremote.setValue("origrecordid", getString("wonum"), 11L);   
    mboremote.setValue("origrecordclass", getString("woclass"), 11L);    
    mboremote.setValue("origwoid", getString("wonum"), 11L);   
    mboremote.setValue("FCPROJECTID",getString("FCPROJECTID"), 2L);    
    mboremote.setValue("FCTASKID",getString("FCTASKID"), 2L);     
    
    mboremote.setValueNull("WORKTYPE");
     
    mboremote.setValue("ASSETNUM", getString("ASSETNUM"), 11L); 
    //BCT Comment: set assetnum to default Asset num from location 
    //System.out.println("***WOCustom.getDefaultAssetFromLoc.Assetnum:"+getString("ASSETNUM"));
  	if((getString("ASSETNUM").isEmpty() || getString("ASSETNUM").trim().equalsIgnoreCase("")) && 
  	  ((!getString("LOCATION").isEmpty() && !getString("LOCATION").trim().equalsIgnoreCase(""))))
  	{
  		//System.out.println("***WOCustom.getDefaultAssetFromLoc.loc"+getString("LOCATION"));
  		mboremote.setValue("ASSETNUM",getDefaultAssetFromLoc(getString("LOCATION")), 11L);
  	}
  	//BCT EOF
    mboremote.setValue("CINUM", getString("CINUM"), 11L);
    mboremote.setValue("COMMODITY", getString("COMMODITY"), 11L);
    mboremote.setValue("COMMODITYGROUP", getString("COMMODITYGROUP"), 11L);
    mboremote.setValue("DESCRIPTION", getString("DESCRIPTION"), 11L);    
    mboremote.setValue("DESCRIPTION_LONGDESCRIPTION", getString("DESCRIPTION_LONGDESCRIPTION"), 11L);
    mboremote.setValue("ESTDUR", getString("ESTDUR"), 11L);    
    mboremote.setValue("JUSTIFYPRIORITY", getString("JUSTIFYPRIORITY"), 11L);
    mboremote.setValue("LOCATION", getString("LOCATION"), 11L); 
    mboremote.setValue("ONBEHALFOF", getString("ONBEHALFOF"), 11L);
    mboremote.setValue("OWNER", getString("OWNER"), 11L);
    mboremote.setValue("OWNERGROUP", getString("OWNERGROUP"), 11L);
    mboremote.setValue("PHONE", getString("PHONE"), 11L);   
    mboremote.setValue("SUPERVISOR", getString("SUPERVISOR"), 11L);
    mboremote.setValue("WOPRIORITY", getString("WOPRIORITY"), 11L);    
    mboremote.setValue("TEAMIC", getString("TEAMIC"), 11L);
    
    
    //EMS-578 End
    
    setValue("hasfollowupwork", true, 2L);
    MboSetRemote mbosetremote = mboremote.getMboSet("RELATEDRECORD");          
    MboRemote mboremote1 = mbosetremote.add();   
    mboremote1.setValue("relatedreckey", getString("wonum"), 11L);   
    mboremote1.setValue("relatedrecclass", getString("woclass"), 11L);    
    mboremote1.setValue("relatedrecsiteid", getString("siteid"), 11L);    
    mboremote1.setValue("relatedrecorgid", getString("orgid"), 11L);    
    mboremote1.setValue("relatetype", getTranslator().toExternalDefaultValue("RELATETYPE", "ORIGINATOR", mboremote1), 11L);
   
    mboset.save();
   
    MboSetRemote mbosetremote1 = getThisMboSet();
    
    int i = mbosetremote1.getCurrentPosition();
   
    mbosetremote1.save();
    mbosetremote1.reset();
    mbosetremote1.moveTo(i);
    
    
    String s = ((WORemote)mboremote).getWOClassDescription(mboremote);   
    Object aobj[] = {
        mboremote.getString("wonum"), s
    };
    
    ((MboSet)getThisMboSet()).addWarning(new MXApplicationException("workorder", "WorkorderCreated", aobj));   
    return mboremote;
    
}    
//End Modification DR 63
//Below code is written for selecting loaned items in rec WO
public void copyLoanSetForPlans(MboSetRemote invReserveSet)
	throws RemoteException, MXException
{
	String location = getString("LOCATION");
	String wonum = getString("WONUM");
	if(location == null)
		throw new MXApplicationException("workorder", "AddWorkorderLocation");
    	/*if(packageStatus.equalsIgnoreCase("CAN") || packageStatus.equalsIgnoreCase("ISSUED") || packageStatus.equalsIgnoreCase("TRANSFER"))
		throw new MXApplicationException("loanerror", "EnterLocationAndAssetofWorkOrder");*/
	WPMaterialCustomSetRemote packSet = (WPMaterialCustomSetRemote)getMboSet("WPMATERIAL");
	packSet.copyLoanReserveSet(invReserveSet, wonum);
	packSet.save();

}

//********************************PSA_REF4.1.4 Validation Start*************************************************************

public void editHistory()
throws MXException, RemoteException
{
	System.out.println("###Entering custom editHistory()###");
	String currentStatus = getTranslator().toInternalString("WOSTATUS", getString("status"));

	if(!currentStatus.equals("CLOSE"))
		{
			throw new MXAccessException("workorder", "NoEditHist");
		}
	else
		{
			System.out.println("###MBOSET OF THIS MBO"+getThisMboSet()+"###");
			//********************************PSA_REF4.1.3 Validation Start*************************************************************
			getThisMboSet().addWarning(new MXApplicationException("workorder","psahistoryedit"));
			super.editHistory();
			orgTotalCost = getDouble("actlabcost") + getDouble("acttoolcost") + getDouble("actmatcost") + getDouble("actservcost");
		    setFieldFlag("FAILURECODE", MboConstants.READONLY, false);
		    setFieldFlag("PROBLEMCODE", MboConstants.READONLY, false);
		}
/*	editHist = true;
	orgTotalCost = getDouble("actlabcost") + getDouble("acttoolcost") + getDouble("actmatcost") + getDouble("actservcost");
	setFlag(7L, false);
	String editable[] = {
    "actfinish", "actservcost", "actstart", "calendar", "changeby", "changedate", "contract", "crewid", "description", "disabled", 
    "downtime", "estdur", "estservcost", "faildate", "inspector", "interruptible", "measuredate", "measurementvalue", "observation", "parent", 
    "phone", "pointnum", "remdur", "reportedby", "reportdate", "respondby", "schedfinish", "schedstart", "supervisor", "targcompdate", "targstartdate", "taskid", "wolablnk", "wopriority", "worklocation", "worktype", "wosequence", "WOJO1", "WOJO2", "WOJO3", "WOJO4", "WOJO5", "WOJO6", "WOJO7", "WOJO8", "WOLO1", "WOLO2", "WOLO3", "WOLO4", "WOLO5", "WOLO6", "WOLO7", "WOLO8", "WOLO9", "WOLO10", "WORTS1", "WORTS2", "WORTS3", "WORTS4", "WORTS5", "OWNER", "OWNERGROUP", "failurecode", "problemcode"
						};
	System.out.println("###EDITABLE FIELDS LIST IS-- "+editable+"###");
	setFieldFlag(editable, 7L, false);
	if(getMboSet("WPMATERIAL").isEmpty())
		setFieldFlag("estmatcost", 7L, false);
	if(getMboSet("WPSERVICE").isEmpty())
		setFieldFlag("estservcost", 7L, false);
	if(getMboSet("WPLABOR").isEmpty())
	{
		setFieldFlag("estlabhrs", 7L, false);
		setFieldFlag("estlabcost", 7L, false);
	}
	if(getMboSet("WPTOOL").isEmpty())
		setFieldFlag("esttoolcost", 7L, false);
	setRelatedSetEditibilityFlags();
	String readonlyAttr[] = {
    "GLAccount", "assetnum", "Location", "chargestore", "status", "statusdate"};
	setFieldFlag(readonlyAttr, 7L, true);
	MboSetEnumeration mse = new MboSetEnumeration(getMboSet("LABTRANS"));
do
{
    if(!mse.hasMoreElements())
        break;
    MboRemote actLabRemote = mse.nextMbo();
    if(!actLabRemote.getBoolean("GENAPPRSERVRECEIPT"))
        actLabRemote.setFlag(7L, false);
} while(true);
super.modify();
*/
}


private void histEdit() throws MXException, RemoteException
{
	MboSetRemote wostatusrecSet = getMboSet("WOSTATUS");
	MboRemote wostatusrec = wostatusrecSet.add(2L);
	wostatusrec.setValue("status", getTranslator().toExternalDefaultValue("WOSTATUS", "HISTEDIT", wostatusrec), 2L);
	wostatusrec.setValue("changedate", getString("CHANGEDATE"), 2L);
	wostatusrec.setValue("changeby", getString("CHANGEBY"), 2L);
}
//********************************PSA_REF4.1.4 Validation END*************************************************************

//********************************PSA_REF4.1.1 Modification Code Starts*************************************************************
public void updateOriginator(String orgsiteid)
throws MXException, RemoteException
{
	
System.out.println("Entering IN Class CustWO CUSTOM METHOD updateOriginator ()###");
MboSetRemote relatedOrigSet = getMboSet("RELATEDORIGINATOR");
if(!isNull("ORIGRECORDID") && !isNull("ORIGRECORDCLASS"))
{
    if(relatedOrigSet.isEmpty())
    {
    	System.out.println("###IN Class CustWO CUSTOM METHOD updateOriginator () Related Orginator Set is empty###");
        MboRemote relatedOrig = relatedOrigSet.add();
        relatedOrig.setValue("relatedreckey", getString("ORIGRECORDID"), 11L);
        relatedOrig.setValue("relatedrecclass", getString("ORIGRECORDCLASS"), 11L);
        relatedOrig.setValue("relatedrecsiteid", orgsiteid, 11L);
        relatedOrig.setValue("relatedrecorgid", getString("orgid"), 11L);
        relatedOrig.setValue("relatetype", getTranslator().toExternalDefaultValue("RELATETYPE", "ORIGINATOR", relatedOrig), 11L);
        relatedOrig.setValue("SITEID", getString("SITEID"),11L);
        System.out.println("###IN Class CustWO CUSTOM METHOD updateOriginator () Added Originator Record in RELATEDRECORDS TABLE###");
    } else
    {
    	System.out.println("IN Class CustWO CUSTOM METHOD updateOriginator () There is already Orginator###");
        MboRemote oldrelatedOrig = relatedOrigSet.getMbo(0);
        oldrelatedOrig.delete(2L);
        MboRemote newrelatedOrig = relatedOrigSet.add();
        newrelatedOrig.setValue("relatedreckey", getString("ORIGRECORDID"), 11L);
        newrelatedOrig.setValue("relatedrecclass", getString("ORIGRECORDCLASS"), 11L);
        newrelatedOrig.setValue("relatedrecsiteid", orgsiteid, 11L);
        newrelatedOrig.setValue("relatedrecorgid",getString("orgid"), 11L);
        newrelatedOrig.setValue("relatetype", getTranslator().toExternalDefaultValue("RELATETYPE", "ORIGINATOR", newrelatedOrig), 11L);
        newrelatedOrig.setValue("siteid", getString("SITEID"), 11L);
        System.out.println("IN Class CustWO CUSTOM METHOD updateOriginator () added new Orginator & deleted old one###");
    }
    if(TicketWOUtility.getInternalWorkOrderClass(this, getString("ORIGRECORDCLASS")) != null)
    {
        MboSetRemote woSet = getMboSet("$WORKORDER", "WORKORDER", "wonum = :origrecordid and woclass = :origrecordclass");
        MboRemote origwo = woSet.getMbo(0);
        if(origwo != null)
        {
            origwo.setValue("hasfollowupwork", true, 11L);
        }
    }
} else
if((isNull("ORIGRECORDID") || isNull("ORIGRECORDCLASS")) && !relatedOrigSet.isEmpty())
{
    MboRemote relatedOrig = relatedOrigSet.getMbo(0);
    relatedOrig.delete(2L);
}
}

public MboRemote custDuplicate() throws MXException, RemoteException
{

	System.out.println("###Inside WOCustom custDuplicate() method###");
	if(!isHashSetLoaded)
	{
	    loadSkipFieldCopyHashSet();
	    skipFieldCopy.add("ISTASK");
	}
	    MboRemote newWORemote = copy();
	newWORemote.setValue("WOCLASS", "WORKORDER");
	newWORemote.setValueNull("SITEID", MboConstants.NOVALIDATION_AND_NOACTION);
	newWORemote.setValue("ORIGRECORDID", this.getString("WONUM"),MboConstants.NOVALIDATION_AND_NOACTION);
	newWORemote.setValue("ORIGRECORDCLASS", this.getString("WOCLASS"),MboConstants.NOVALIDATION_AND_NOACTION);
	System.out.println("###Exiting WOCustom custDuplicate() method###");
	return newWORemote;
}
//********************************PSA_REF4.1.1 Modification Code Ends*************************************************************

//++ Custom Code to call external API to send the status change (AMPR ARMG &7 AMPS QC)	
public void changeStatus(String status, Date date, String memo, long accessModifier, boolean comingFromReceiving)
    throws MXException, RemoteException
{	 
	super.changeStatus(status, date, memo, accessModifier, false);
	String workordernumber=getString("WONUM");
	String userinfo = getUserInfo().getUserName();
	//Date jsondate= MXServer.getMXServer().getDate();
	UserInfo userInfo = this.getUserInfo();
	if ((status.equals("INPRG") && !isNull("BLOCK_M") && isNull("AMPSQC_TYPE")) || (status.equals("WPLSCH") && !isNull("BLOCK_M") && isNull("AMPSQC_TYPE")) || (status.equals("COMP") && !isNull("BLOCK_M") && isNull("AMPSQC_TYPE")))
	{
		System.out.println("---------------------before json------------------------");
		Post_JSON(status,workordernumber,userinfo);
        System.out.println("---------------------after json-------------------------");
	}
	
	System.out.println("-------------------Status------------------"+status);
	System.out.println("-------------------date------------------"+date);
	System.out.println("-------------------AMPSQC_TYPE------------------"+this.getString("AMPSQC_TYPE"));
	System.out.println("-------------------BLOCK_M------------------"+this.getString("BLOCK_M"));
	System.out.println("-------------------APP_NAME------------------"+getThisMboSet().getApp());
	
	 if (((status.equals("INPRG") && isNull("BLOCK_M") && !isNull("AMPSQC_TYPE")) || (status.equals("WPLSCH") && isNull("BLOCK_M") && !isNull("AMPSQC_TYPE"))  || (status.equals("WPLSCH-PRG") && isNull("BLOCK_M") && !isNull("AMPSQC_TYPE")) || (status.equals("COMP") && isNull("BLOCK_M") && !isNull("AMPSQC_TYPE")))) // BCT commented this part because when escalation "CHKINTERPT" triggers WOWF1PRG workflow, throws null pointer exception. App name is null when triggered from escalation. Condition -- && (getThisMboSet().getApp().equalsIgnoreCase("WOTRACK") || getThisMboSet().getApp().equalsIgnoreCase("WOEVRPL1") || getThisMboSet().getApp().equalsIgnoreCase("WOEVRPL2")) 
	 {
		System.out.println("-------------------before json AMPS QC------------------");
		String statusUpate = getString("PSA_STATUSUPD");
		Post_JSON_AMPSQC(status,workordernumber,userinfo,statusUpate);
        System.out.println("-------------------after json AMPS QC--------------------");
	}		
}

public static void Post_JSON(String status,String workordernumber,String userinfo) throws RemoteException 
{
	
	Properties configData = MXServer.getMXServer().getConfig();
	String query_url = configData.getProperty("psa.amps.armg.webapp");
	String x_api_key = configData.getProperty("psa.amps.armg.x_api_key");
	if((!query_url.isEmpty()) || (query_url!=null))
	{

	SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	String jsondate = simpledateformat.format(new Date());
	String statuscode="";
	if (status.equals("INPRG"))
	{
		statuscode="S";
	}
	else if (status.equals("WPLSCH"))
	{
		statuscode="A";
	}
	else if (status.equals("COMP"))
	{
		statuscode="E";
	}
	System.out.println("query_url "+query_url);
	System.out.println("x_api_key "+x_api_key);
    //String query_url = "http://10.115.73.111:8173/AMPS/api/v1.0/statusUpdateFromMaximo";
    //String json = "{ \"job_id\" : \"5232135\", \"job_status\" : \"S\", \"user_id_m\" : \"maxadmin\" , \"event_dt\" : \"2019-11-06 10:45:00\" }";
    String json = "{ \"job_id\" : \""+workordernumber+"\", \"job_status\" : \""+statuscode+"\", \"user_id_m\" : \""+userinfo+"\" , \"event_dt\" : \""+jsondate+"\" }";
    System.out.println("json is "+json);
    try {
    URL url = new URL(query_url);
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    
    conn.setConnectTimeout(5000);
    conn.setRequestProperty("x-api-key", x_api_key);
    conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
    System.out.println("try5");
    conn.setDoOutput(true);
    conn.setDoInput(true);
    conn.setRequestMethod("POST");
    System.out.println("try1");

    OutputStream os = conn.getOutputStream();
    os.write(json.getBytes("UTF-8"));
    os.close(); 
    System.out.println("try2");

    // read the response
    BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
    System.out.println("try3");
    byte[] contents = new byte[1024];
    System.out.println("try31");
    int bytesRead=0;
    String result=null;
    System.out.println("try32");
    while((bytesRead = in.read(contents))!=-1)
    {
        System.out.println("try33");
        result += new String(contents,0,bytesRead);
    	
    }
    
    //String result = IOUtils.toString(in, "UTF-8");
    System.out.println(result);
    //System.out.println("result after Reading JSON Response");
    //JSONObject myResponse = new JSONObject(result);
    //System.out.println("jsonrpc- "+myResponse.getString("jsonrpc"));
    //System.out.println("id- "+myResponse.getInt("id"));
    //System.out.println("result- "+myResponse.getString("result"));
    in.close();
    conn.disconnect();
    } catch (Exception e) {
           System.out.println(e);
     }
}
    return;
}

public void Post_JSON_AMPSQC(String status, String workordernumber, String userinfo, String statusUpate) throws RemoteException 
{
	System.out.println("------Pthisost_JSON_AMPSQC()------------------status-----------------"+status);
	try 
	{
		if (statusUpate.isEmpty())
		{			
			setValue("PSA_STATUSUPD",status, 2L);
		}
		else
		{
			statusUpate = statusUpate + "," + status;
			
			setValue("PSA_STATUSUPD",statusUpate, 2L);				
		}
		
	}
	catch (RemoteException e) 
	{
		e.printStackTrace();
	} 
	catch (MXException e) 
	{
		e.printStackTrace();
	}
}

/*public static void Post_JSON_AMPSQC(String status,String workordernumber,String userinfo) throws RemoteException 
{		
	Properties configData = MXServer.getMXServer().getConfig();
	String query_url = configData.getProperty("psa.amps.qc.webapp");
	String x_api_key = configData.getProperty("psa.amps.qc.x_api_key");
	String AMPSQC_authorization = configData.getProperty("psa.amps.qc.authorization");
	
	if((!query_url.isEmpty()) || (query_url!=null))
	{
		SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyyMMddHHmmss");
		String jsondate = simpledateformat.format(new Date());
		
		System.out.println("------Post_JSON_AMPSQC()------------------query_url-----------------"+query_url);
		System.out.println("------Post_JSON_AMPSQC()------------------x_api_key-----------------"+x_api_key);
		System.out.println("------Post_JSON_AMPSQC()------------------AMPSQC_authorization------"+AMPSQC_authorization);
		
		String json = "{ \"wonum_m\" : \""+workordernumber+"\", \"user_id_m\" : \""+userinfo+"\", \"job_status_c\" : \""+status+"\" , \"update_dt\" : \""+jsondate+"\" }";
		
		System.out.println("------Post_JSON_AMPSQC()------------------json format-----------------"+json);
		try 
		{
			URL url = new URL(query_url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    
			conn.setConnectTimeout(5000);
			conn.setRequestProperty("x-api-key", x_api_key);
			conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			conn.setRequestProperty("Authorization", AMPSQC_authorization);
			System.out.println("try5");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			System.out.println("try1");

			OutputStream os = conn.getOutputStream();
			os.write(json.getBytes("UTF-8"));
			os.close(); 
			System.out.println("try2");

			// read the response
			BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
			System.out.println("try3");
			byte[] contents = new byte[1024];
			System.out.println("try31");
			int bytesRead=0;
			String result=null;
			System.out.println("try32");
			while((bytesRead = in.read(contents))!=-1)
			{
				System.out.println("try33");
				result += new String(contents,0,bytesRead);
    	
			}        
			//String result = IOUtils.toString(in, "UTF-8");
			System.out.println(result);
			//System.out.println("result after Reading JSON Response");
			//JSONObject myResponse = new JSONObject(result);
			//System.out.println("jsonrpc- "+myResponse.getString("jsonrpc"));
			//System.out.println("id- "+myResponse.getInt("id"));
			//System.out.println("result- "+myResponse.getString("result"));
			in.close();
			conn.disconnect();
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}
	}
    return;
}*/

//-- Custom Code to call external API to send the status change (AMPR ARMG && AMPS QC) 

}