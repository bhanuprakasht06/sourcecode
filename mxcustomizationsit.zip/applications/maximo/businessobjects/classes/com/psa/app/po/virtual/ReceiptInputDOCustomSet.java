package com.psa.app.po.virtual;

import java.rmi.RemoteException;


import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.NonPersistentMboSet;
import psdi.util.MXException;


public class ReceiptInputDOCustomSet extends NonPersistentMboSet
implements ReceiptInputDOCustomSetRemote
{

public ReceiptInputDOCustomSet(MboServerInterface serverinterface)
	throws MXException, RemoteException
{
super(serverinterface);
}


protected Mbo getMboInstance(MboSet mboset)
	throws MXException, RemoteException
{
return new ReceiptInputDOCustom(mboset);
}


public MboRemote setup()
	throws MXException, RemoteException
{
add();
getMbo(0).setValueNull("packingslipnum", MboConstants.NOACCESSCHECK);
return getMbo(0);
}

}
