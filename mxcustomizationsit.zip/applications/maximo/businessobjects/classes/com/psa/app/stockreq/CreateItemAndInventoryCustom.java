/*
 * Modiifcation History
 * 03-06-2011	  COMM-IT		Creation
 * 24-11-2021 UR-AP-IM-015 modified by BCT
 */
package com.psa.app.stockreq;

import java.rmi.RemoteException;
import java.util.Date;

import psdi.app.inventory.InventoryRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;



public class CreateItemAndInventoryCustom 
	implements ActionCustomClass
{
	public CreateItemAndInventoryCustom() 
	{
	}

	public void applyCustomAction(MboRemote mboremote, Object aobj[])
    	throws MXException, RemoteException
    {		
		try
		{
			ItemCreation(mboremote);
			InventoryCreation(mboremote);
		}
		catch (MXException e) 
		{
			e.printStackTrace();
			throw e;
		}
    }
	
	public void ItemCreation(MboRemote mboremote)
		throws MXException, RemoteException
	{
		try {
		Date currDate = MXServer.getMXServer().getDate();
		MboSetRemote itemsetremote = MXServer.getMXServer().getMboSet("ITEM", mboremote.getUserInfo());
		MboRemote itemremote = itemsetremote.addAtEnd();
		itemremote.setValue("ITEMNUM", mboremote.getString("ITEMNUM"));
		itemremote.setValue("DESCRIPTION", mboremote.getString("DESCRIPTION"));
		itemremote.setValue("DESCRIPTION_LONGDESCRIPTION", mboremote.getString("DESCRIPTION_LONGDESCRIPTION"));
		itemremote.setValue("COMMODITYGROUP", mboremote.getString("COMMODITYGROUP"));
		itemremote.setValue("COMMODITY", mboremote.getString("COMMODITY"));
		itemremote.setValue("CRTDATE", currDate);
		itemremote.setValue("ORDERUNIT", mboremote.getString("ISSUEUNIT"));
		itemremote.setValue("ISSUEUNIT", mboremote.getString("ISSUEUNIT"));
		itemremote.setValue("RECOND", mboremote.getBoolean("RECOND"));
		itemremote.setValue("CONDITIONENABLED", true);
		itemremote.setValue("IMS_COMMENTS", mboremote.getString("REQUESTEDBY"));
		itemremote.setValue("REQNUM", mboremote.getString("STOCKREQNUM"));
		itemremote.setValue("INSPECTIONREQUIRED", mboremote.getBoolean("INSPECTIONREQUIRED"));
		itemremote.setValue("RTSD", mboremote.getBoolean("RTSD"));
		itemremote.setValue("PSA_ITEMCATEGORY1", mboremote.getString("PSA_ITEMCATEGORY1"));
		itemremote.setValue("PSA_ITEMCATEGORY2", mboremote.getString("PSA_ITEMCATEGORY2"));
		itemremote.setValue("PSA_ITEMCATEGORY3", mboremote.getString("PSA_ITEMCATEGORY3"));
		itemremote.setValue("PSA_ITEMCATEGORY4", mboremote.getString("PSA_ITEMCATEGORY4"));
		itemremote.setValue("PSA_ITEMCATEGORY5", mboremote.getString("PSA_ITEMCATEGORY5"));
		//UR-AP-IM-015 modified by BCT
		itemremote.setValue("CLASSIFICATION", mboremote.getString("PSA_ESL"));
		itemremote.setValue("PSA_EST", mboremote.getString("PSA_EST"));
		itemremote.setValue("PSA_MATRIX", mboremote.getString("PSA_MATRIX"));
		itemremote.setValue("PSA_CATALOGCODE", mboremote.getString("CATALOGNUM"));
		itemremote.setValue("PSA_MODELNUM", mboremote.getString("SPARESBRAND"));
		itemremote.setValue("MANUFACTURER", mboremote.getString("SPARESBRAND"));
		itemremote.setValue("ORGID", mboremote.getString("ORGID"));
		
		MboSetRemote InvDetailSetremote = mboremote.getMboSet("STOCKINVDETAIL");
		if (InvDetailSetremote != null)
		{
				MboRemote InvDetailremote = InvDetailSetremote.getMbo(0);
				itemremote.setValue("VENDOR", InvDetailremote.getString("VENDOR"));
		}
		
		int itemid = itemremote.getInt("ITEMID");
		
		MboSetRemote ItemConditionsetremote = itemremote.getMboSet("ITEMCONDITION");
		String conditioncode[] = {"NEW", "RECOND", "FOC"};
		for (int i=0; i<3 ; i++)
		{
			MboRemote ItemConditionremote = ItemConditionsetremote.addAtEnd();
			ItemConditionremote.setValue("ITEMNUM", mboremote.getString("ITEMNUM"));
			ItemConditionremote.setValue("CONDITIONCODE", conditioncode[i]);	
		}
		
		MboSetRemote functionTypesetremote = itemremote.getMboSet("FUNCTIONTYPE");
		MboRemote functionTyperemote = functionTypesetremote.add();
		functionTyperemote.setValue("ITEMNUM", mboremote.getString("ITEMNUM"));
		functionTyperemote.setValue("FUNCTIONTYPE", mboremote.getString("EQTYPE"));
		
		MboSetRemote brandbatchSetremote = functionTyperemote.getMboSet("BRANDBATCH");
		MboRemote brandbatchremote = brandbatchSetremote.add();
		brandbatchremote.setValue("ITEMNUM", mboremote.getString("ITEMNUM"));
		brandbatchremote.setValue("FUNCTIONTYPE", mboremote.getString("EQTYPE"));
		brandbatchremote.setValue("BRANDBATCH", mboremote.getString("BRANDBATCH"));
	
		
		//++COMM-IT - Code to get the details from doclinks table with stockreqnum 
		MboSetRemote StockItemSet = MXServer.getMXServer().getMboSet("STOCKITEM", mboremote.getUserInfo());
		SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "stockreqnum = :1 and siteid = :2");
		sqlformat.setObject(1, "STOCKITEM", "STOCKREQNUM", mboremote.getString("stockreqnum"));
		sqlformat.setObject(2, "STOCKITEM", "SITEID", mboremote.getString("siteid"));
		StockItemSet.setWhere(sqlformat.format());
		MboSetRemote doclinkset = StockItemSet.getMbo(0).getMboSet("DOCLINKS");			
		addAttachments(doclinkset,itemid);		
		//--COMM-IT - Getting the details from doclinks table with stockreqnum 
		
		itemsetremote.save();		
		}
		catch (Exception e) {
	        if((mboremote.getString("ITEMNUM")).isEmpty())
	        	throw new MXApplicationException("item", "enterItem");
			e.printStackTrace();
	        System.out.println("Error in Item Creation!");
		}
		}
	
	private void InventoryCreation(MboRemote mboremote) 
	throws MXException, RemoteException
	{		
		MboSetRemote InvDetailSetremote = mboremote.getMboSet("STOCKINVDETAIL");
		int i = 0;
		if (InvDetailSetremote != null)
		{
			do
			{
				MboRemote InvDetailremote = InvDetailSetremote.getMbo(i);
				if (InvDetailremote == null)
				{
					break;
				}
				else
				{
					InventoryRemote inv = null;
					MboSetRemote invSet1 = null;
					invSet1 = mboremote.getMboSet("INVENTORY");			
					inv = (InventoryRemote)invSet1.add();					
					inv.setValue("ITEMSETID", InvDetailremote.getString("ITEMSETID"));
					inv.setValue("SITEID", InvDetailremote.getString("SITEID"));
					inv.setValue("ITEMNUM", InvDetailremote.getString("ITEMNUM"));
					inv.setValue("ORDERUNIT", mboremote.getString("ISSUEUNIT"));
					inv.setValue("ISSUEUNIT", mboremote.getString("ISSUEUNIT"));
					inv.setValue("LOCATION", InvDetailremote.getString("STORELOC"));
					inv.setValue("CONDITIONCODE", "NEW", 2L);
					inv.setValue("MINLEVEL", InvDetailremote.getDouble("ROP"));	
					inv.setValue("ORDERQTY", InvDetailremote.getDouble("EOQ"));
					inv.setValue("SSTOCK", InvDetailremote.getDouble("SSTOCK"));
				
					MboRemote InvVendorRemote = inv.getMboSet("INVVENDOR_ORA").getMbo(0);
					
					if (InvVendorRemote == null)
					{
						inv.setValue("VENDOR", InvDetailremote.getString("VENDOR"));
						inv.setValue("MANUFACTURER", InvDetailremote.getString("MANUFACTURER"));
						inv.setValue("CATALOGCODE", mboremote.getString("CATALOGNUM"));
						inv.setValue("MODELNUM", mboremote.getString("SPARESBRAND"));
					}					
				
					MboSetRemote InvCostSetremote = inv.getMboSet("INVCOST");
					String conditioncode[] = {"NEW", "RECOND", "FOC"};
					for (int a=0; a<3 ; a++)
					{
						MboRemote InvCostremote = InvCostSetremote.add();
						InvCostremote.setValue("ITEMNUM", InvDetailremote.getString("ITEMNUM"), 2L);
						InvCostremote.setValue("ITEMSETID", InvDetailremote.getString("ITEMSETID"), 2L);
						InvCostremote.setValue("SITEID", InvDetailremote.getString("SITEID"), 2L);
						InvCostremote.setValue("LOCATION", InvDetailremote.getString("STORELOC"), 2L);
						InvCostremote.setValue("CONDITIONCODE", conditioncode[a], 2L);	
						//InvCostremote.setValue("CONDRATE", 100, 11L);
						InvCostremote.setValue("stdcost", 0.0D, 2L);
					}
					
					MboSetRemote InvBalSetremote = inv.getMboSet("INVBALANCES");
					for (int b=0; b<3 ; b++)
					{
						MboRemote InvBalremote = InvBalSetremote.add();
						InvBalremote.setValue("ITEMNUM", InvDetailremote.getString("ITEMNUM"), 2L);
						InvBalremote.setValue("ITEMSETID", InvDetailremote.getString("ITEMSETID"), 2L);
						InvBalremote.setValue("LOCATION", InvDetailremote.getString("STORELOC"), 2L);
						InvBalremote.setValue("SITEID", InvDetailremote.getString("SITEID"), 2L); 
						InvBalremote.setValue("CONDITIONCODE", conditioncode[b], 2L);
					}
					
					invSet1.save();		
					i++;
				}					
			}
			while (true);				
		}
		
		// To set vendor and manufacture against inventory
		int j = 0;
		if (InvDetailSetremote != null)
		{
			do
			{
				MboRemote InvDetailremote = InvDetailSetremote.getMbo(j);
				if (InvDetailremote == null)
				{
					break;
				}
				else
				{
					//InventoryRemote inv = null;
					MboSetRemote invSet1 = null;
					invSet1 = mboremote.getMboSet("INVENTORY");
					int k = 0;
					if (invSet1 != null)
					{
						do
						{
							MboRemote Invremote = invSet1.getMbo(k);
							if (Invremote == null)
							{
								break;
							}
							else
							{
								String vendor = Invremote.getString("VENDOR");
								if (vendor != null)
								{
									Invremote.setValue("VENDOR", InvDetailremote.getString("VENDOR"), 7L);
									Invremote.setValue("MANUFACTURER", InvDetailremote.getString("MANUFACTURER"), 7L);
									Invremote.setValue("CATALOGCODE", mboremote.getString("CATALOGNUM"), 7L);
									Invremote.setValue("MODELNUM", mboremote.getString("SPARESBRAND"), 7L);
									invSet1.save();	
								}
								k++;
							}							
						} 
						while (true);
					}
					j++;
				}
			} 
			while (true);
		}
	}
	
	public void addAttachments(MboSetRemote doclinkset, int itemid)
	throws MXException, RemoteException
	{
		try
		{
			MboRemote temp;
			String ownertable="ITEM";
			//Inserting record into doclinks with itemid as ownerid and ITEM as ownertable
			for(int i=0;(temp=doclinkset.getMbo(i)) != null; i++)
			{
				MboRemote docremote;
				docremote = doclinkset.add();
				docremote.setValue("OWNERID", itemid);
				docremote.setValue("OWNERTABLE", ownertable);
				docremote.setValue("REFERENCE", temp.getString("REFERENCE"));
				docremote.setValue("DOCTYPE", temp.getString("DOCTYPE"));
				docremote.setValue("DOCVERSION", temp.getString("DOCVERSION"));
				docremote.setValue("PRINTTHRULINK", temp.getInt("PRINTTHRULINK"));
				docremote.setValue("COPYLINKTOWO", temp.getInt("COPYLINKTOWO"));
				docremote.setValue("DOCINFOID", temp.getInt("DOCINFOID"));
				docremote.setValue("DOCUMENT", temp.getString("DOCUMENT"));
				doclinkset.save();
			}			
		}
		catch (MXException e) 
		{
			e.printStackTrace();
			throw e;
		}
	}
}
 