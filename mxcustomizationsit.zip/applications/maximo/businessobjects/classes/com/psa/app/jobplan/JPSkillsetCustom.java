package com.psa.app.jobplan;

import java.rmi.RemoteException;

import psdi.app.jobplan.JobPlanRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.custapp.CustomMbo;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class JPSkillsetCustom extends CustomMbo 
	implements JPSkillsetCustomRemote 
{
	public JPSkillsetCustom (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void init() 
			throws MXException 
	{
		super.init();
		MboRemote JPRemote = getOwner();  	
		try 
		{
			if ((JPRemote == null) || (!(JPRemote instanceof JobPlanRemote))) 
				return;
			String JPStatus = JPRemote.getString("STATUS");
			
			String staff_readonly[] = {"MIN_STAFF_N","MAX_STAFF_N","EXACT_STAFF_N"};

			
			if (isNew())
			{
				setFieldFlag("SKILLSET_C", MboConstants.READONLY, false);
				setFieldFlag("SKILLSET_C", MboConstants.REQUIRED, true);
				setFieldFlag(staff_readonly, MboConstants.READONLY, true);
			}
			else
				setFieldFlag("SKILLSET_C", MboConstants.READONLY, true);
			
			if (toBeAdded())
				return;
			
			if (getBoolean("MIN_SKILLSET_REQUIRED_I"))
			{
				setFieldFlag("MIN_STAFF_N", MboConstants.READONLY, false);
				setFieldFlag("MIN_STAFF_N", MboConstants.REQUIRED, true);
				setFieldFlag("ALL_STAFF_I", MboConstants.READONLY, true);
			}
			else
			{
				setFieldFlag("MIN_STAFF_N", MboConstants.READONLY, true);
				setFieldFlag("MIN_STAFF_N", MboConstants.REQUIRED, false);
				setFieldFlag("ALL_STAFF_I", MboConstants.READONLY, false);
			}
			
			if (getBoolean("MAX_SKILLSET_REQUIRED_I"))
			{
				setFieldFlag("MAX_STAFF_N", MboConstants.READONLY, false);
				setFieldFlag("MAX_STAFF_N", MboConstants.REQUIRED, true);
				setFieldFlag("ALL_STAFF_I", MboConstants.READONLY, true);
			}
			else
			{
				setFieldFlag("MAX_STAFF_N", MboConstants.READONLY, true);
				setFieldFlag("MAX_STAFF_N", MboConstants.REQUIRED, false);
				setFieldFlag("ALL_STAFF_I", MboConstants.READONLY, false);
			}
			
			if (getBoolean("EXACT_SKILLSET_REQUIRED_I"))
			{
				setFieldFlag("EXACT_STAFF_N", MboConstants.READONLY, false);
				setFieldFlag("EXACT_STAFF_N", MboConstants.REQUIRED, true);
				setFieldFlag("ALL_STAFF_I", MboConstants.READONLY, true);
			}
			else
			{
				setFieldFlag("EXACT_STAFF_N", MboConstants.READONLY, true);
				setFieldFlag("EXACT_STAFF_N", MboConstants.REQUIRED, false);
				setFieldFlag("ALL_STAFF_I", MboConstants.READONLY, false);
			}
			
			String allstaff_readonly[] = {"MIN_SKILLSET_REQUIRED_I","MIN_STAFF_N","MAX_SKILLSET_REQUIRED_I","MAX_STAFF_N","EXACT_SKILLSET_REQUIRED_I","EXACT_STAFF_N"};
			if (getBoolean("ALL_STAFF_I"))
				setFieldFlag(allstaff_readonly, MboConstants.READONLY, true);
			
			
			String allreadonly[] = {"SKILLSET_C","SKILLTYPE_C","ALL_STAFF_I","MIN_SKILLSET_REQUIRED_I","MIN_STAFF_N","MAX_SKILLSET_REQUIRED_I","MAX_STAFF_N","EXACT_SKILLSET_REQUIRED_I","EXACT_STAFF_N"};
			if(JPStatus.equalsIgnoreCase("ACTIVE") || JPStatus.equalsIgnoreCase("INACTIVE") || JPStatus.equalsIgnoreCase("CANCEL") || JPStatus.equalsIgnoreCase("REVISED"))
				setFieldFlag(allreadonly, 7L, true);
			
		} 
		catch (RemoteException e) 
		{
			e.printStackTrace();
		}
	}

	public void add() 
			throws MXException, RemoteException 
	{
		super.add();
		setValue("all_staff_i", false, 11L);
		setValue("exact_skillset_required_i", false, 11L);
		setValue("min_skillset_required_i", false, 11L);
		setValue("max_skillset_required_i", false, 11L);
		JobPlanRemote jpOwner = (JobPlanRemote)getOwner();
		
		setValue("jpnum", jpOwner.getString("jpnum"), 11L);
		if ((jpOwner != null) && (jpOwner.getName().equals("JOBPLAN"))) 
		{
			setValue("pluscrevnum", jpOwner.getString("pluscrevnum"), 11L);
		}
		if (!jpOwner.isNull("jobplanid"))
			setValue("jobplanid", jpOwner.getLong("jobplanid"), 11L);
		
		
	}
	
	public void save() 
			throws MXException, RemoteException 
	{
		super.save();
	}
	
	public void canDelete()
			throws MXException, RemoteException
	{
		MboRemote JPRemote = getOwner();
		String JPStatus = JPRemote.getString("STATUS");
		if(JPStatus.equalsIgnoreCase("ACTIVE") || JPStatus.equalsIgnoreCase("INACTIVE") || JPStatus.equalsIgnoreCase("CANCEL") || JPStatus.equalsIgnoreCase("REVISED"))
			throw new MXApplicationException("jspmessages", "table_cannotdelete");
	}
}
