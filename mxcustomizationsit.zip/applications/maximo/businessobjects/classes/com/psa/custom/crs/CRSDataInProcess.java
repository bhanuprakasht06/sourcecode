/*
 * Modification history
 * 22-11-2012	WMJ	EMS-536	[Interface]Update conditions for incoming breakdowns to Maximo
 * 13-Dec-2012	WMJ	EMS-541	[C21gateway][Interface]Filter PM breakdowns based on the field equipment_type_c
 * 14-Dec-2015	DEZ EMS-1010 [C21gateway] Handle PMPC "F6" and "F13" Function in Maximo
 */

package com.psa.custom.crs;

import java.rmi.RemoteException;
//import java.util.Date;
import java.util.HashMap;
import com.psa.custom.common.EMSSite;
//import java.util.ArrayList;
import psdi.app.workorder.*;
import psdi.iface.mic.MicConstants;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
//import psdi.iface.proc.MaxIfaceControl;
//import psdi.custom.common.MxEmail;

/*
 * Author: BTE
 * Date: 28 FEB 2006
 * Comment: CRS data inbound classes to translate Breakdown type and fault code to CRS fault code 
 */
public class CRSDataInProcess extends MicSetIn {

	//private static final String SUBJECT = "[EMS-CRS] Error: Equipment Not Found!";
	private HashMap bdTypeHashMap;
		
	/*
	 * Author: BTE
	 * Date: 28 FEB 2006
	 * Comment: Constructor
	 */
    public CRSDataInProcess() throws MXException, RemoteException {
		super();
		
        validOrgSite = true;
		
		bdTypeHashMap = new HashMap();
		
		// Build Breakdown Type Hash map
		buildBreakDownType();
    }


    /*
     * Author: BTE
     * Date: 28 FEB 2006
     * Comment: Business rules
     * @see psdi.iface.mic.MicSetIn#checkBusinessRules()
     */
    public int checkBusinessRules() throws MXException, RemoteException {

		INTEGRATIONLOGGER.debug("Entering CRSDataInProcess.checkBusinessRules");
		
		//Check if Breakdown Type is E and Asset Type is PM
		
		//Start of modification for EMS-541 
		/*
		String assetid = struc.getCurrentData("LOCATION");
		//20060907 HCHA - Remove check for breakdown type E
		//if((assetid.substring(1,3).compareTo("PM")==0)&&(struc.getCurrentData("BREAKDOWNTYPE").compareToIgnoreCase("E")==0))
		if(assetid.substring(1,3).compareTo("PM")==0)
		{
			//Skip if asset type is PM
			INTEGRATIONLOGGER.info("Leaving CRSDataInProcess.checkBusinessRules, Skip proceesing as asset type is 'PM'");
			return MicConstants.SKIP;
		}
		*/
		//End of modification for EMS-541
		
		// Populate Site id based on location
		String siteid;
		if (struc.isCurrentDataNull("SITEID")) {
			    
			EMSSite site = new EMSSite (struc.getCurrentData("LOCATION"), getUserInfo());    		
			struc.setCurrentData("ORGID", site.getOrgID());
			siteid = site.getSiteID();
			
			//Location Not Found in Maximo
			if(siteid==null){
				INTEGRATIONLOGGER.error("[CRS]Location "+struc.getCurrentData("LOCATION")+" not found!");
				
			/*
				//Send email to a list of email address in Interface Control
				//Possible Problem: If the interface retries > 1, the email will be sent many times!
				try{
					MaxIfaceControl maxifacecontrol = MaxIfaceControl.getIfaceControl();
					if(maxifacecontrol.isControlExists(getSender(),"CRSADMINEMAIL")){
						
						ArrayList emaillst = maxifacecontrol.getListControl(getSender(),"CRSADMINEMAIL");
				        
						if(emaillst.size()==0)
				        	INTEGRATIONLOGGER.error("[CRS]No email address in Interface Control 'CRSADMINEMAIL'! No email sent!");
						
					    //Form Email Message
			            String emailMsg = "Date: " + new Date()+"\n";
			            emailMsg += "Error in CRS: \n";
			            emailMsg+="Location "+struc.getCurrentData("LOCATION")+" not found!";
			            			            
				        for (int i=0; i < emaillst.size(); i++) {
				        	String emailadd = (String) emaillst.get(i);
				        	MxEmail email = new MxEmail(emailadd);
				
				        	email.send(SUBJECT,emailMsg);
				        }
						
					}
					else{
						INTEGRATIONLOGGER.error("[CRS]Interface Control 'CRSADMINEMAIL' not found! Unable to send email!");
					}
				}
				catch(MXException e){
					INTEGRATIONLOGGER.error("[CRS]Unable to send email!",e);
				}
				throw new RemoteException("Location "+struc.getCurrentData("LOCATION")+" not found!");
			*/
				
				throw new MXApplicationException("locations", "invalidlocation");
			}
			
			struc.setCurrentData("SITEID", siteid );
		}
		else
			siteid = struc.getCurrentData("SITEID");
		
		//Start of EMS-536
		/*
		// Check if Normal WO with In-progress status exist
		if(chkExistInprgWorkOrder(struc.getCurrentData("LOCATION"),siteid)){
			//Skip when normal in-progress work order exist
			INTEGRATIONLOGGER.info("Leaving CRSDataInProcess.checkBusinessRules, Skip proceesing as normal in-progress Workorder exist");
			return MicConstants.SKIP;
		}
		*/
		//End of EMS-536
		
		//Populate Work Order Type
		//Start of EMS-536(shift this to be before chkExistBdnWorkOrder to set the worktype for new WOs, and to remove this set action if chkExistBdnWorkOrder is true)
		//struc.setCurrentData("WORKTYPE", "BDN");
		struc.setCurrentData("WORKTYPE", "TTT");
		//End of EMS-536
		
		//  Start of modification for EMS-1010
		// Check if Existing Outstanding WO exist
		String wonum = null;
		
		if(struc.getCurrentData("BREAKDOWNTYPE").equals(F13)) {
			// No check required because always generate new WO
		} else if (struc.getCurrentData("BREAKDOWNTYPE").equals(F6)) {
			wonum = chkExistF6BdnWorkOrder(struc.getCurrentData("LOCATION"),siteid); // Check for existing F6 Breakdown WO to replace
		} else {
			wonum = chkExistBdnWorkOrder(struc.getCurrentData("LOCATION"),siteid); // For all other breakdowns use existing logic of replacing WO regardless of CRSFault code
		}
		//  End of modification for EMS-1010
		
		
		if(wonum!=null){
			struc.setCurrentData("WONUM", wonum); //Add workorder number
			struc.setAction("Change"); //Change action to 'Change'
			actionInd="Change";
			
			struc.removeFromCurrentData("WORKTYPE");

			//Start of EMS-536
			/*
			// SR-18 : update only the fault code
			struc.removeFromCurrentData("MAINWORKLOCATION");
			struc.removeFromCurrentData("CRSREPORTEDDATE");
			struc.removeFromCurrentData("REPORTDATE");
			struc.removeFromCurrentData("REPORTEDBY");
			struc.removeFromCurrentData("WOPRIORITY");
			struc.removeFromCurrentData("PHONE");
			struc.removeFromCurrentData("DESCRIPTION");
			*/
			//End of EMS-536
			
			INTEGRATIONLOGGER.debug("CRSDataInProcess.checkBusinessRules: Replacing exisiting WO: "+wonum);
		}
		
		
		// Translation CRS fault
		String CRSfault = transCRSFault (struc.getCurrentData("BREAKDOWNTYPE"), struc.getCurrentData("CRSFAULT"));
		
		if (CRSfault != null ) {
			struc.setCurrentData("CRSFAULT", CRSfault);
			
		} else {
			throw new MXApplicationException("iface", "meter-nocrsfault");
		}
		
		INTEGRATIONLOGGER.debug("Leaving CRSDataInProcess.checkBusinessRules");

		return MicConstants.PROCESS;

    } //checkBusinessRules()
    
    
    private static final String A = "A";
    private static final String P = "P";
    private static final String E = "E";    
    private static final String QC = "QC";
    private static final String YC = "YC";
    private static final String APIS = "APIS";
    private static final String PC = "PC";
    private static final String OTHERWISE = "Otherwise";
    private static final String dat = "-";
	
	// Start of modification for EMS-1010
	private static final String F13 = "F13";
	private static final String F6 = "F6";
	private static final String PM_MAJORBDWN = "PM-06";
	private static final String PM_MINORBDWN = "PM-13";
	// End of modification for EMS-1010
    
    /*
     * Author: BTE
     * Date: 28 FEB 2006
     * Comment: Translation breakdown type and fault code to CRS fault
     */
    private String transCRSFault(String breakdownType, String faultcode) 
    	throws MXException, RemoteException
    {
    	
    	INTEGRATIONLOGGER.debug("Entering CRSDataInProcess.transCRSFault");
	
		String CRSfault = null;
		String assetid = struc.getCurrentData("LOCATION");
	    		
		if (bdTypeHashMap.get(breakdownType).equals(APIS)) {  
			
			CRSfault = bdTypeHashMap.get(breakdownType) + dat + faultcode;
			
		} else if (bdTypeHashMap.get(breakdownType).equals(PC)) {
			if(faultcode == null){
				CRSfault = (String)bdTypeHashMap.get(breakdownType);
			}
			else{
				CRSfault = bdTypeHashMap.get(breakdownType) + dat + faultcode;
			}
		// Start of modification for EMS-1010
		} else if (bdTypeHashMap.get(breakdownType).equals(PM_MINORBDWN) || bdTypeHashMap.get(breakdownType).equals(PM_MAJORBDWN)) {			
			
			CRSfault = (String)bdTypeHashMap.get(breakdownType);

		// End of modification for EMS-1010
		}  else if (bdTypeHashMap.get(breakdownType).equals(OTHERWISE)) {			
			// Get equipment type 
			String equipType = assetid.substring(1,3);
			
			if (equipType.equals(QC)) {
				CRSfault = equipType + dat + faultcode;
			} else {    				
				CRSfault = YC + dat + faultcode;
				
			}
		}
		
		INTEGRATIONLOGGER.debug("CRSDataInProcess.transCRSFault: breakdownType["+breakdownType+"] faultcode["+faultcode+"] >>> CRSfault["+CRSfault+"]");
		
		INTEGRATIONLOGGER.debug("Leaving CRSDataInProcess.transCRSFault");
		
		return CRSfault;
    }
    
    
    /*
     * Author: BTE
     * Date: 28 FEB 2006
     * Comment: Build Breakdown type hash map
     */
    private void buildBreakDownType () {
	    bdTypeHashMap.put(A, APIS);
	    bdTypeHashMap.put(P, PC);
		bdTypeHashMap.put(F13, PM_MINORBDWN); // Modification for EMS-1010
		bdTypeHashMap.put(F6, PM_MAJORBDWN); // Modification for EMS-1010
	    bdTypeHashMap.put(E, OTHERWISE);
    }
   
    /*
     * Author: HCHA
     * Date: 9 MAY 2006
     * Comment: Check if Outstanding Breakdown Work Order Exist
     */
    private String chkExistBdnWorkOrder(String location, String siteid) 
    	throws RemoteException, MXException
    {
    	
    	INTEGRATIONLOGGER.debug("Entering chkExistBdnWorkOrder: location="+location+" siteid="+siteid);
    	
    	WOSetRemote woSet = (WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", getUserInfo());
    	
    	//Start of EMS-536
    	//String sql = "LOCATION=:1 AND SITEID=:2 AND WORKTYPE='BDN' AND STATUS<>'COMP' AND STATUS<>'CLOSE' AND STATUS<>'CAN'";
    	String sql = "LOCATION=:1 AND SITEID=:2 AND STATUS in ('WAPPR-SR','INPRG-SR') ORDER BY WONUM DESC";
    	//End of EMS-536
    	SqlFormat sqlformat = new SqlFormat(getUserInfo(), sql);
    	
    	sqlformat.setObject(1, "WORKORDER", "LOCATION", location);
        sqlformat.setObject(2, "WORKORDER", "SITEID", siteid);
        woSet.setWhere(sqlformat.format());
        
        if(!woSet.isEmpty())
        {
        	WORemote workorder = (WORemote) woSet.getMbo(0);
        	INTEGRATIONLOGGER.debug("Leaving chkExistBdnWorkOrder, found "+woSet.count()+" BDN WO, replacing WO "+workorder.getString("WONUM"));
        	return workorder.getString("WONUM");
        }
        
        INTEGRATIONLOGGER.debug("Leaving chkExistBdnWorkOrder");
    	
        return null; 
    	
    }
	
    /*
     * Author: Desmond
     * Date: 19 Jan 2016
     * Comment: Check if Outstanding F6 Breakdown Work Order Exist
     */
    private String chkExistF6BdnWorkOrder(String location, String siteid) 
    	throws RemoteException, MXException
    {
    	
    	INTEGRATIONLOGGER.debug("Entering chkExistBdnWorkOrder: location="+location+" siteid="+siteid);
    	
    	WOSetRemote woSet = (WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", getUserInfo());
    	
    	//Start of EMS-536
    	//String sql = "LOCATION=:1 AND SITEID=:2 AND WORKTYPE='BDN' AND STATUS<>'COMP' AND STATUS<>'CLOSE' AND STATUS<>'CAN'";
    	String sql = "LOCATION=:1 AND SITEID=:2 AND CRSFAULT='"+PM_MAJORBDWN+"' AND STATUS in ('WAPPR-SR','INPRG-SR') ORDER BY WONUM DESC";
    	//End of EMS-536
    	SqlFormat sqlformat = new SqlFormat(getUserInfo(), sql);
    	
    	sqlformat.setObject(1, "WORKORDER", "LOCATION", location);
        sqlformat.setObject(2, "WORKORDER", "SITEID", siteid);
        woSet.setWhere(sqlformat.format());
        
        if(!woSet.isEmpty())
        {
        	WORemote workorder = (WORemote) woSet.getMbo(0);
        	INTEGRATIONLOGGER.debug("Leaving chkExistBdnWorkOrder, found "+woSet.count()+" BDN WO, replacing WO "+workorder.getString("WONUM"));
        	return workorder.getString("WONUM");
        }
        
        INTEGRATIONLOGGER.debug("Leaving chkExistBdnWorkOrder");
    	
        return null; 
    	
    }
    
    //Start of EMS-536
	/*
     * Author: HCHA
     * Date: 9 MAY 2006
     * Comment: Check if In-progress Normal Work Order Exist
     */
    /*
    private boolean chkExistInprgWorkOrder(String location, String siteid) 
    	throws RemoteException, MXException
    {
    	
    	INTEGRATIONLOGGER.debug("Entering chkExistInprgWorkOrder: location="+location+" siteid="+siteid);
    	
    	WOSetRemote woSet = (WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", getUserInfo());
    	
    	//20060919 HCHA - Add 'DOWNTIME = 1' to check if the current in progress job requires downtime before filtering. 
    	String sql = "LOCATION=:1 AND SITEID=:2 AND (WORKTYPE IS NULL OR WORKTYPE<>'BDN') AND STATUS='INPRG' AND DOWNTIME = 1";
    	SqlFormat sqlformat = new SqlFormat(getUserInfo(), sql);
    	
    	sqlformat.setObject(1, "WORKORDER", "LOCATION", location);
        sqlformat.setObject(2, "WORKORDER", "SITEID", siteid);
        woSet.setWhere(sqlformat.format());
        
        INTEGRATIONLOGGER.debug("Leaving chkExistInprgWorkOrder");
    	
        return (!woSet.isEmpty()); 
    	
    }
    */
	//End of EMS-536
    
	/*
	 * Author: BTE
	 * Date: 28 FEB 2006
	 * Comment: Finalize - Destructor
	 */
    /*
    public void finalize(){
    	
    	debug.msg("ORGID: " + struc.getCurrentData("ORGID"));
    	
    	debug.msg("SITEID: " + struc.getCurrentData("SITEID"));
    	
    	debug.msg("LOCATION: " + struc.getCurrentData("LOCATION"));
    	
    	debug.msg("WONUM: " + struc.getCurrentData("WONUM"));
    	
    	debug.msg("BREAKDOWNTYPE: " + struc.getCurrentData("BREAKDOWNTYPE"));
    	
    	debug.msg("CRSFAULT: " + struc.getCurrentData("CRSFAULT"));    	
    }
    */
}

