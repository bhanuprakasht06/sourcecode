package com.psa.custom.sms;

import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.List;

import org.jdom.Element;

import psdi.iface.mic.MicConstants;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXFormat;

/*
 * Author: BTE
 * 08 MAR 2006 - Initial version
 * 06 JUN 2006 - Refer to DR-142 
 * 08 JUN 2006 - Refer to DR-148
 */
public class SMSRosterDataInProcess extends MicSetIn {

	/*
	 * Variables
	 */
	private static SMSConstant SMS = new SMSConstant();
	
	
	/*
	 * Author: BTE
	 * 08 MAR 2006 - Constructor
	 */
	public SMSRosterDataInProcess() throws MXException, RemoteException {
		super();
	}
	
	
	/*
	 * Author: BTE
	 * 08 MAR 2006 - Check business rules for inbound roaster update
 	 * 06 JUN 2006 - Refer to DR-142 
	 */
    public int checkBusinessRules() throws MXException, RemoteException {
    	
        INTEGRATIONLOGGER.debug("Entering checkBusinessRules");
                
        // 06 JUN 2006 - DR-142: Set action to Add/Change if action is not a Delete.
        if (!actionInd.equals(MicConstants.ACTIONDELETE)) {
        	actionInd = MicConstants.ACTIONADDUPDATE; 
        }
        
    	// Check if ORGID is null
		if (struc.isCurrentDataNull(SMS.ORGID)) {
			throw new MXApplicationException(SMS.IFACE, SMS.CALNOORGID);
		}
    	
        // Check if IC is null    	
    	if (struc.isCurrentDataNull(SMS.IC)) {
    		throw new MXApplicationException(SMS.IFACE, SMS.CALNOIC);    		
		} else {    				
	    	// Search for PERSONID=LABORCODE=CALNUM in database to populate CALNUM
			SMSPerson person =  new SMSPerson(getUserInfo());
			String personid = person.getPersonID(struc.getCurrentData(SMS.IC)); 
			
			if (personid == null) {
				throw new MXApplicationException(SMS.IFACE, SMS.PERSONTNOPERSONID);
			} else {
				struc.setCurrentData(SMS.CALNUM, personid);
			}
		}    		    		    			    	  
    	
    	deleteWorkPeriod();
    	
        INTEGRATIONLOGGER.debug("Leaving checkBusinessRules");
        return MicConstants.PROCESS;    	
    }        

    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Set extra records for Calendar or Workperiod
	 */
    public void setAdditionalData(MboSetRemote MboSet, String tableName) throws MXException, RemoteException {
    	
    	INTEGRATIONLOGGER.debug("Entering setAdditionalData");
    	
	    if (tableName.equals(SMS.CALENDAR) && actionInd.equals(MicConstants.ACTIONADDUPDATE)) {
	    				
			MboSet.getMbo(0).setValue(SMS.STARTDATE, SMS.CALENDAR_START_DATE);
			MboSet.getMbo(0).setValue(SMS.ENDDATE, SMS.CALENDAR_END_DATE);
	    }	   
	    
	    if (tableName.equals(SMS.WORKPERIOD) && actionInd.equals(MicConstants.ACTIONADDUPDATE)) {
	    	SMSWorkPeriod workPeriod = new SMSWorkPeriod(getUserInfo());

	    	workPeriod.replaceWorkPeriod(MboSet.getMbo(0).getString(SMS.ORGID), 
	    			MboSet.getMbo(0).getString(SMS.CALNUM), 
	    			MboSet.getMbo(0).getString(SMS.WORKDATE));		 
	    	
	    	MboSet.save(0);	 
	    }	   
	    
        INTEGRATIONLOGGER.debug("Leaving setAdditionalData");
    }     
    
    
    /*
	 * Author: BTE
	 * 05 APR 2006 - Delete workperiod
	 * 08 JUN 2006 - Refer to DR-148
	 */
    public void deleteWorkPeriod() throws MXException, RemoteException {   	
    	
    	INTEGRATIONLOGGER.debug("Entering deleteWorkPeriod");
    	
    	// Remove delete record in database
    	List lst = struc.getChildrenData(SMS.WORKPERIOD);
    	Iterator iter = lst.iterator();
    	
    	for (int i = 0; iter.hasNext(); i++ ) {    
    		iter.next();
    		
    		String myAction = getAction(i);
    		
	    	if (myAction.equals(MicConstants.ACTIONDELETE)) {
	    		
				String orgid = struc.getCurrentData(SMS.ORGID);	
				String calNum = struc.getCurrentData(SMS.CALNUM);
				
				//String workDate = MXFormat.dateToSQLString(MXFormat.stringToDate(getWorkDate(i)));				
				
				
				String workDate = getWorkDate(i);
				/*
				workDate = workDate.substring(5,7) + 
						"/" + 
						workDate.substring(8,10) + 
						"/" +
						workDate.substring(0,4);
				*/
				workDate =  workDate.substring(8,10) + 
						"/" + 
						workDate.substring(5,7) + 
						"/" +
						workDate.substring(0,4);			
				
		    	INTEGRATIONLOGGER.debug("WorkD Date: " + workDate);
	    		MboSetRemote workPeriodSet = (MboSetRemote) MXServer.getMXServer().getMboSet(SMS.WORKPERIOD, getUserInfo());
	    		
	    		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	    		
	    		combinewhereclauses.addWhere("ORGID= :1");
	    		combinewhereclauses.addWhere("CALNUM= :2");
	    		combinewhereclauses.addWhere("WORKDATE= :3");	    		
	    		String s = combinewhereclauses.getWhereClause();
	    	
	    		if(s != null && s != ""){
	    			SqlFormat sqlformat = new SqlFormat(getUserInfo(), s);
	    		
	    			sqlformat.setObject(1, SMS.WORKPERIOD, SMS.ORGID, orgid);
	    			sqlformat.setObject(2, SMS.WORKPERIOD, SMS.CALNUM, calNum);
	    			sqlformat.setObject(3, SMS.WORKPERIOD, SMS.WORKDATE, workDate);  			
	    			workPeriodSet.setWhere(sqlformat.format());   
	    			
	    			if(!workPeriodSet.isEmpty()) {   				
	    				workPeriodSet.deleteAll(0L);
						
	    				workPeriodSet.save();
						workPeriodSet.commit();
						workPeriodSet.close();
					}							
	    		}	
	    	}	
    	}    	
    	
    	// Remove delete record in SturctureData
    	List lstStruc = struc.getChildrenData(SMS.WORKPERIOD);
    	Iterator iterStruc = lstStruc.iterator();
    	
    	for (int i = 0; iterStruc.hasNext(); ) {    
    		iterStruc.next();
    		
    		String myAction = getAction(i);    		
	    	if (myAction.equalsIgnoreCase(MicConstants.ACTIONDELETE)) {
	    		struc.getChildrenData(SMS.WORKPERIOD).remove(i);
	    		
	    		// Reset to start after delete one record in structure
	    		lstStruc = struc.getChildrenData(SMS.WORKPERIOD);
	    		iterStruc = lstStruc.iterator();
	    		i = 0;
	    	} else {
	    		i++;
	    	}
    	}
    	
        INTEGRATIONLOGGER.debug("Leaving deleteWorkPeriod");
    }
    
    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Getter for action in structureData
	 */
    public String getAction(int key) {
    	
    	INTEGRATIONLOGGER.debug("Entering getAction");
    	
    	List lst = struc.getChildrenData(SMS.WORKPERIOD);
    	Iterator iter = lst.iterator();
    	
    	for(int i = 0; iter.hasNext(); i++) {
    		Element childrenElement = (Element) iter.next();
    		
    		if (key == i) {
    			if (childrenElement.getAttribute(SMS.ACTION)!= null)
    		    	INTEGRATIONLOGGER.debug("Leaving getAction");
    				return childrenElement.getAttribute(SMS.ACTION).getValue();
    		}
    	}
    	
    	INTEGRATIONLOGGER.debug("Leaving getAction");    	
		return SMS.EMPTY;
    }  
    
    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Getter for workdate in structureData
	 */    
    public String getWorkDate(int key) {

    	INTEGRATIONLOGGER.debug("Entering getWorkDate");
    	
    	List lst = struc.getChildrenData(SMS.WORKPERIOD);
    	Iterator iter = lst.iterator();
    	
    	for(int i = 0; iter.hasNext(); i++) {
    		Element childrenElement = (Element) iter.next();
    		
    		List attrLst = childrenElement.getChildren();
    		Iterator attrIter = attrLst.iterator();

    		while (attrIter.hasNext()) {
    			Element attr = (Element)attrIter.next();
    			String attrValue = attr.getText();
    									
    			if (attr.getName().equalsIgnoreCase(SMS.WORKDATE)) {
    				
    				if (key == i) {
    			    	INTEGRATIONLOGGER.debug("Leaving getWorkDate");
    					return attrValue;
    				}
    			}    			
    		}
    	}
    	
    	INTEGRATIONLOGGER.debug("Leaving getWorkDate");
		return SMS.EMPTY;
    }
    
    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Getter for shiftnum in structureData
	 */
    public String getShiftNum(int key) {

    	INTEGRATIONLOGGER.debug("Entering getShiftNum");
    	
    	List lst = struc.getChildrenData(SMS.WORKPERIOD);
    	Iterator iter = lst.iterator();
    	
    	for(int i = 0; iter.hasNext(); i++) {
    		Element childrenElement = (Element) iter.next();
    		
    		List attrLst = childrenElement.getChildren();
    		Iterator attrIter = attrLst.iterator();

    		while (attrIter.hasNext()) {
    			Element attr = (Element)attrIter.next();
    			String attrValue = attr.getText();
    									
    			if (attr.getName().equalsIgnoreCase(SMS.SHIFTNUM)) {
    				
    				if (key == i) {
    			    	INTEGRATIONLOGGER.debug("Leaving getShiftNum");
    					return attrValue;
    				}
    			}    			
    		}
    	}
    	
    	INTEGRATIONLOGGER.debug("Leaving getShiftNum");    	
		return SMS.EMPTY;
    }    
}


