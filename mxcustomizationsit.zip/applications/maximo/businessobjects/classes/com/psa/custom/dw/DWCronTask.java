// Decompiled by DJ v3.0.0.63 Copyright 2002 Atanas Neshkov  Date: 3/18/2011 5:55:51 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   DWCronTask.java

package com.psa.custom.dw;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxZip;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxDatabase;
import com.psa.custom.ois.MxLog;
import java.io.*;
import java.rmi.RemoteException;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.mic.MicUtil;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

// Referenced classes of package com.psa.custom.dw:
//            DWFile

public class DWCronTask extends SimpleCronTask
{

    public DWCronTask()
    {
        initialized = false;
        qualifiedInstanceName = null;
        delimiter = null;
        adminEmail = null;
        emailSubj = null;
        logFilePath = null;
        zipExec = null;
        enableLog = false;
        purgeData = false;
        processDirectory = null;
        labOutputFilePath = null;
        matOutputFilePath = null;
        labArchiveFilePath = null;
        matArchiveFilePath = null;
        extractday = 1;
    }

    private void refreshSettings()
    {
        try
        {
			System.out.println("--inside refreshSettings()--");
            delimiter = getParamAsString("SPLITTAG");
            zipExec = getParamAsString("ZIPEXEC");
            adminEmail = getParamAsString("ALERTEMAIL");
			System.out.println("--inside DWronTask.java--adminEmail--" + adminEmail);
			/*below statement is commented to avoid email logicie..  email.setAdmin(adminEmail);*/
            //email.setAdmin(adminEmail);
			System.out.println("-after email.setAdmin method-");
            emailSubj = getParamAsString("ALERTEMAILSUBJ");
            DateFormat fileDateFormat = new SimpleDateFormat("yyyyMMdd");
            extractday = getParamAsInt("EXTRACTDAY");
            Date curDate = new Date();
            Date fileDate = new Date(curDate.getTime() - (long)(extractday - 1) * 24L * 60L * 60L * 1000L);
            String fileDateStr = fileDateFormat.format(fileDate);
            labOutputFilePath = getParamAsString("LABOUTPUTFILEPATH").replaceAll("yyyymmdd", fileDateStr);
            matOutputFilePath = getParamAsString("MATOUTPUTFILEPATH").replaceAll("yyyymmdd", fileDateStr);
            labArchiveFilePath = getParamAsString("LABARCHIVEFILEPATH").replaceAll("yyyymmdd", fileDateStr);
            matArchiveFilePath = getParamAsString("MATARCHIVEFILEPATH").replaceAll("yyyymmdd", fileDateStr);
            logFilePath = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd", fileDateStr);
            enableLog = getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0;
            mxLog.setEnabled(enableLog);
            mxLog.setLogFilePath(logFilePath);
            mxLog.setLogTag(getName());
            mxLog.createLogFile();
            processDirectory = getParamAsString("PROCESSDIRECTORY");
            purgeData = getParamAsString("PURGEDATA").toUpperCase().compareTo("Y") == 0;
			System.out.println("--end of refreshsetting()--");

        }
        catch(Exception exception)
        {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }

    public void init()
        throws MXException
    {
		System.out.println("--start of init()--");
        super.init();
        mxLog = new MxLog();
        email = new MxEmail(adminEmail);
        initialized = true;
    }

    public void start()
    {
        try
        {
			System.out.println("--inside start()--");
            refreshSettings();
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".start()").toString());
            MicUtil.INTEGRATIONLOGGER.info((new StringBuilder("[")).append(getName()).append("] Start").toString());
            setSleepTime(0L);
			System.out.println("--end of start()--");
        }
        catch(Exception exception)
        {
			System.out.println("--cach of start()--");
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }

    public void stop()
    {
		System.out.println("--start of stop()--");
        try
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".stop()").toString());
            mxLog.closeLogFile();
					System.out.println("--end of stop()--");

        }
        catch(Exception exception)
        {
					System.out.println("--catch of stop()--");
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
        MicUtil.INTEGRATIONLOGGER.info((new StringBuilder("[")).append(getName()).append("] Stop").toString());
    }

    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
    {
        try
        {
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = (new StringBuilder(String.valueOf(crontaskinstanceremote.getString("crontaskname")))).append(".").append(crontaskinstanceremote.getString("instancename")).toString();
        }
        catch(Exception exception)
        {
            integrationLogger.error(exception.getMessage(), exception);
        }
    }

    private boolean isReqParamSet()
    {
        if(adminEmail == null)
            return false;
        if(processDirectory == null)
            return false;
        if(labOutputFilePath == null)
            return false;
        if(matOutputFilePath == null)
            return false;
        if(labArchiveFilePath == null)
            return false;
        return matArchiveFilePath != null;
    }

    public void cronAction()
    {
			System.out.println("-start of cron action--");
        try
        {
			System.out.println("-inside try of cronAction--");
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".cronAction():[Info]Start CronTask Action").toString());
            if(!initialized)
            {
			System.out.println("-inside if  of cronAction--");
                mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".cronAction():[Error]CronTask not initialized!").toString());
                throw new Exception((new StringBuilder(String.valueOf(getName()))).append(".cronAction():[Error]CronTask not initialized!").toString());
            }

			System.out.println("-cronaction and refresh settings");
            refreshSettings();

			System.out.println("-cronaction and refresh settings***end");
            if(!isReqParamSet())
            {
                mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".cronAction(): Required parameters not set.").toString());
                throw new Exception("Required parameters not set.");
            }
            processData();
            depositFile();
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".cronAction():[Info]End CronTask Action").toString());
        }
        catch(Exception e)
        {
            mxLog.writeLog((new StringBuilder("[ERROR] ")).append(e.getMessage()).toString());
            MicUtil.INTEGRATIONLOGGER.error((new StringBuilder("[")).append(getName()).append("] ").append(e.getMessage()).toString(), e);
            String emailContent = genEmail(e);
            email.send(emailSubj, emailContent);
            mxLog.writeLog((new StringBuilder("Email Sent:\n")).append(emailContent).toString());
            stop();
        }
    }

    private void purgeTable(Connection conn)
        throws SQLException
    {
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".purgeTable():[Info]Start purging data from MXGLTXN_IFACE and MXOUT_INTER_TRANS").toString());
        Date curDate = new Date();
        Date prevDate = new Date(curDate.getTime() - (long)extractday * 24L * 60L * 60L * 1000L);
        DateFormat YmdDateFormat = new SimpleDateFormat("yyyyMMdd");
        String prevDateStr = YmdDateFormat.format(prevDate);
        String purgeIfaceSQL = (new StringBuilder("delete from MXGLTXN_IFACE where TO_CHAR(TRANSDATE,'YYYYMMDD') = ")).append(prevDateStr).append(" and SOURCEMBO <> 'LABTRANS'").toString();
        PreparedStatement purgeIfaceStmt = conn.prepareStatement(purgeIfaceSQL);
        purgeIfaceStmt.executeUpdate();
        purgeIfaceStmt.close();
        String purgeJobIfaceSQL = (new StringBuilder("delete from MXGLTXN_IFACE where TO_CHAR(PAYMENTTRANSDATE,'YYYYMMDD') = ")).append(prevDateStr).append(" and SOURCEMBO = 'LABTRANS'").toString();
        PreparedStatement purgeJobIfaceStmt = conn.prepareStatement(purgeJobIfaceSQL);
        purgeJobIfaceStmt.executeUpdate();
        purgeJobIfaceStmt.close();
        String purgeTxnSQL = "delete from MXOUT_INTER_TRANS where EXTSYSNAME  = 'DW'";
        PreparedStatement purgeTxnStmt = conn.prepareStatement(purgeTxnSQL);
        purgeTxnStmt.executeUpdate();
        purgeTxnStmt.close();
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".purgeTable():[Info]Finish purging data from MXGLTXN_IFACE and MXOUT_INTER_TRANS").toString());
    }

    private void depositFile()
        throws Exception
    {
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Info]Start depositing output file").toString());
        File chkMatArchFile = new File((new StringBuilder(String.valueOf(matArchiveFilePath))).append(".gz").toString());
        File chkLabArchFile = new File((new StringBuilder(String.valueOf(labArchiveFilePath))).append(".gz").toString());
        if(chkMatArchFile.exists() || chkLabArchFile.exists())
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Warning]Archive files already exist; transactions have been processed before").toString());
            return;
        }
        MxFileCopy.fileCopy((new StringBuilder(String.valueOf(processDirectory))).append("jcmat.txt").toString(), matOutputFilePath);
        MxFileCopy.fileCopy((new StringBuilder(String.valueOf(processDirectory))).append("jcmat.txt").toString(), matArchiveFilePath);
        MxFileCopy.fileCopy((new StringBuilder(String.valueOf(processDirectory))).append("jcjob.txt").toString(), labOutputFilePath);
        MxFileCopy.fileCopy((new StringBuilder(String.valueOf(processDirectory))).append("jcjob.txt").toString(), labArchiveFilePath);
        String cmd = (new StringBuilder(String.valueOf(zipExec))).append(" ").append(matOutputFilePath).toString();
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Info]Zip using cmd: ").append(cmd).toString());
        int retcode = MxZip.zipFile(cmd);
        if(retcode != 0)
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Error]Unable to zip file - ").append(matOutputFilePath).toString());
            throw new Exception((new StringBuilder(String.valueOf(getName()))).append(".depositFile(): Unable to zip file - ").append(matOutputFilePath).toString());
        }
        cmd = (new StringBuilder(String.valueOf(zipExec))).append(" ").append(matArchiveFilePath).toString();
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Info]Zip using cmd: ").append(cmd).toString());
        retcode = MxZip.zipFile(cmd);
        if(retcode != 0)
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Error]Unable to zip file - ").append(matArchiveFilePath).toString());
            throw new Exception((new StringBuilder(String.valueOf(getName()))).append(".depositFile(): Unable to zip file - ").append(matArchiveFilePath).toString());
        }
        cmd = (new StringBuilder(String.valueOf(zipExec))).append(" ").append(labOutputFilePath).toString();
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Info]Zip using cmd: ").append(cmd).toString());
        retcode = MxZip.zipFile(cmd);
        if(retcode != 0)
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Error]Unable to zip file - ").append(labOutputFilePath).toString());
            throw new Exception((new StringBuilder(String.valueOf(getName()))).append(".depositFile(): Unable to zip file - ").append(labOutputFilePath).toString());
        }
        cmd = (new StringBuilder(String.valueOf(zipExec))).append(" ").append(labArchiveFilePath).toString();
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Info]Zip using cmd: ").append(cmd).toString());
        retcode = MxZip.zipFile(cmd);
        if(retcode != 0)
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Error]Unable to zip file - ").append(labArchiveFilePath).toString());
            throw new Exception((new StringBuilder(String.valueOf(getName()))).append(".depositFile(): Unable to zip file - ").append(labArchiveFilePath).toString());
        } else
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".depositFile():[Info]Finish depositing output file").toString());
            return;
        }
    }

    private String genEmail(Exception e)
    {
        String emailMsg = (new StringBuilder("Date: ")).append(new Date()).append("\n").toString();
        emailMsg = (new StringBuilder(String.valueOf(emailMsg))).append("Error in CronTask: ").append(getName()).append("\n").toString();
        emailMsg = (new StringBuilder(String.valueOf(emailMsg))).append("Error Message: ").append(e.getMessage()).append("\n").toString();
        emailMsg = (new StringBuilder(String.valueOf(emailMsg))).append("Detail:\n").toString();
        emailMsg = (new StringBuilder(String.valueOf(emailMsg))).append(e.toString()).append("\n").toString();
        StackTraceElement element[] = e.getStackTrace();
        for(int i = 0; i < element.length; i++)
            emailMsg = (new StringBuilder(String.valueOf(emailMsg))).append("\tat ").append(element[i].toString()).append("\n").toString();

        return emailMsg;
    }

    private void writeJobTrans(Connection conn)
        throws SQLException, IOException
    {
        ResultSet rs;
        PreparedStatement pstmt;
        rs = null;
        pstmt = null;
        Date curDate;
        PreparedStatement assetPstmt;
        PreparedStatement locationPstmt;
        DWFile dwfile;
        long totalAmount;
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".writeJobTrans():[Info]Start processing labour transactions...").toString());
        curDate = new Date();
        Date prevDate = new Date(curDate.getTime() - (long)extractday * 24L * 60L * 60L * 1000L);
        DateFormat YmdDateFormat = new SimpleDateFormat("yyyyMMdd");
        String prevDateStr = YmdDateFormat.format(prevDate);
        String labSqlStmt = (new StringBuilder("SELECT GL.LINECOST, GL.TRANSDATE, GL.CURRENCYCODE, GL.GLCREDITACCT, GL.GLDEBITACCT, GL.ASSETNUM, GL.LOCATION, GL.WONUM, GL.REGULARHRS, GL.SITEID, GL.PAYMENTTRANSDATE, WO.DESCRIPTION, WO.ACTSTART, WO.ACTFINISH, WO.FAILURECODE, WO.PROBLEMCODE, WO.WORKTYPE FROM MXGLTXN_IFACE GL LEFT OUTER JOIN WORKORDER WO ON (GL.WONUM = WO.WONUM and GL.SITEID = WO.SITEID) WHERE TO_CHAR(GL.PAYMENTTRANSDATE,'YYYYMMDD') = '")).append(prevDateStr).append("' ").append("AND GL.SOURCEMBO = 'LABTRANS' ").append("ORDER BY GL.TRANSDATE").toString();
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".writeJobTrans():[Info]SQL Statement - ").append(labSqlStmt).toString());
        pstmt = conn.prepareStatement(labSqlStmt);
        rs = pstmt.executeQuery();
        String assetSqlStmt = "SELECT * FROM ASSET WHERE ASSETNUM = ? AND SITEID = ? ";
        assetPstmt = conn.prepareStatement(assetSqlStmt);
        String locationSqlStmt = "SELECT * FROM LOCATIONS WHERE SITEID = ? AND LOCATION = ? ";
        locationPstmt = conn.prepareStatement(locationSqlStmt);
        dwfile = new DWFile((new StringBuilder(String.valueOf(processDirectory))).append("jcjob.txt").toString(), delimiter);
        dwfile.writeHeader("Labour Job Cost");
        totalAmount = 0L;
        while(rs.next()) 
            try
            {
                ArrayList lst = new ArrayList();
                lst.add("1");
                double bdLinecost = rs.getDouble("LINECOST") * 100D;
                String lineCostSgn;
                if(bdLinecost < 0.0D)
                    lineCostSgn = "-";
                else
                    lineCostSgn = "0";
                long lLinecost = (long)bdLinecost;
                String sLinecost = (new StringBuilder(String.valueOf(lineCostSgn))).append(DWFile.padString((new Long(Math.abs(lLinecost))).toString(), "0", 15, true)).toString();
                totalAmount += lLinecost;
                lst.add(sLinecost);
                lst.add(DWFile.padString("", "0", 16, true));
                lst.add(DWFile.padString("JCJOB", " ", 25, false));
                Date transDate = rs.getDate("PAYMENTTRANSDATE");
                DateFormat DmyDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
                String transDateStr = DmyDateFormat.format(transDate);
                lst.add(transDateStr);
                lst.add(DWFile.padString("SGD", " ", 15, false));
                String curDateDmy = DmyDateFormat.format(curDate);
                lst.add(curDateDmy);
                lst.add("A");
                String glDebitAcct = rs.getString("GLDEBITACCT");
                String glDebitAcctComp[] = glDebitAcct.split("-");
                for(int i = 0; i < 8; i++)
                    lst.add(glDebitAcctComp[i]);

                lst.add(DWFile.padString("", "0", 15, true));
                lst.add("0");
                lst.add("5");
                lst.add(DWFile.padString("", " ", 30, true));
                lst.add(DWFile.padString("", " ", 11, true));
                lst.add(DWFile.padString("", "0", 15, true));
                String assetnum = rs.getString("ASSETNUM");
                String location = rs.getString("LOCATION");
                if(assetnum != null || location != null)
                {
                    if(location != null)
                    {
                        String siteid = rs.getString("SITEID");
                        locationPstmt.clearParameters();
                        locationPstmt.setString(1, siteid);
                        locationPstmt.setString(2, location);
                        ResultSet locationRS = locationPstmt.executeQuery();
                        if(locationRS.next())
                        {
                            String oaAssetNum = locationRS.getString("OAASSETNUM");
                            if(oaAssetNum != null)
                            {
                                String dwAssetnum = (new StringBuilder(String.valueOf(glDebitAcctComp[0]))).append(".").append(oaAssetNum).toString();
                                lst.add(dwAssetnum);
                            } else
                            if(assetnum != null)
                            {
                                assetPstmt.clearParameters();
                                assetPstmt.setString(1, assetnum);
                                assetPstmt.setString(2, siteid);
                                ResultSet assetRS = assetPstmt.executeQuery();
                                if(assetRS.next())
                                {
                                    oaAssetNum = assetRS.getString("OAASSETNUM");
                                    if(oaAssetNum != null)
                                    {
                                        String dwAssetnum = (new StringBuilder(String.valueOf(glDebitAcctComp[0]))).append(".").append(oaAssetNum).toString();
                                        lst.add(dwAssetnum);
                                    } else
                                    {
                                        lst.add("");
                                    }
                                } else
                                {
                                    lst.add("");
                                }
                            } else
                            {
                                lst.add("");
                            }
                        } else
                        {
                            lst.add("");
                        }
                    } else
                    if(assetnum != null)
                    {
                        String siteid = rs.getString("SITEID");
                        assetPstmt.clearParameters();
                        assetPstmt.setString(1, assetnum);
                        assetPstmt.setString(2, siteid);
                        ResultSet assetRS = assetPstmt.executeQuery();
                        if(assetRS.next())
                        {
                            String oaAssetNum = assetRS.getString("OAASSETNUM");
                            if(oaAssetNum != null)
                            {
                                String dwAssetnum = (new StringBuilder(String.valueOf(glDebitAcctComp[0]))).append(".").append(oaAssetNum).toString();
                                lst.add(dwAssetnum);
                            } else
                            {
                                lst.add("");
                            }
                        } else
                        {
                            lst.add("");
                        }
                    } else
                    {
                        lst.add("");
                    }
                } else
                {
                    lst.add("");
                }
                String wonum = rs.getString("WONUM");
                if(wonum != null)
                {
                    lst.add(wonum);
                    String woDesc = rs.getString("DESCRIPTION");
                    if(woDesc != null)
                        lst.add(woDesc);
                    else
                        lst.add("");
                    java.sql.Timestamp jobStartDate = rs.getTimestamp("ACTSTART");
                    if(jobStartDate != null)
                    {
                        DateFormat jobDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
                        String jobStartDateStr = jobDateFormat.format(jobStartDate);
                        lst.add(jobStartDateStr);
                    } else
                    {
                        lst.add(DWFile.padString("", " ", 12, true));
                    }
                    java.sql.Timestamp jobEndDate = rs.getTimestamp("ACTFINISH");
                    if(jobEndDate != null)
                    {
                        DateFormat jobDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
                        String jobEndDateStr = jobDateFormat.format(jobEndDate);
                        lst.add(jobEndDateStr);
                    } else
                    {
                        lst.add(DWFile.padString("", " ", 12, true));
                    }
                    String partcode1 = rs.getString("FAILURECODE");
                    String partcode2 = rs.getString("PROBLEMCODE");
                    String partcode = new String();
                    if((partcode1 == null) & (partcode2 == null))
                    {
                        lst.add("");
                    } else
                    {
                        if(partcode1 != null)
                            partcode = partcode1;
                        if(partcode2 != null)
                            partcode = (new StringBuilder(String.valueOf(partcode))).append(partcode2).toString();
                        lst.add(partcode);
                    }
                    String woType = rs.getString("WORKTYPE");
                    if(woType != null)
                        lst.add(woType);
                    else
                        lst.add("");
                } else
                {
                    lst.add("");
                    lst.add("");
                    lst.add(DWFile.padString("", " ", 12, true));
                    lst.add(DWFile.padString("", " ", 12, true));
                    lst.add("");
                    lst.add("");
                }
                float labHour = rs.getFloat("REGULARHRS") * 60F;
                int iLabHour = (new Float(labHour)).intValue();
                String sLabHour = (new Integer(Math.abs(iLabHour))).toString();
                String sgnLabHour;
                if(iLabHour < 0)
                    sgnLabHour = "-";
                else
                    sgnLabHour = "0";
                lst.add((new StringBuilder(String.valueOf(sgnLabHour))).append(DWFile.padString(sLabHour, "0", 8, true)).toString());
                lst.add("");
                lst.add("");
                lst.add("");
                lst.add("");
                lst.add("");
                String directLabour = (new StringBuilder(String.valueOf(lineCostSgn))).append(DWFile.padString((new Long(Math.abs(lLinecost))).toString(), "0", 8, true)).toString();
                lst.add(directLabour);
                lst.add(DWFile.padString("", "0", 9, true));
                lst.add(DWFile.padString("", "0", 9, true));
                lst.add(DWFile.padString("", "0", 9, true));
                lst.add(DWFile.padString("", "0", 9, true));
                lst.add(DWFile.padString("", "0", 7, true));
                lst.add(DWFile.padString("", "0", 9, true));
                lst.add(DWFile.padString("", "0", 9, true));
                dwfile.writeTransRec(lst);
                lst.set(1, DWFile.padString("", "0", 16, true));
                lst.set(2, sLinecost);
                String glCreditAcct = rs.getString("GLCREDITACCT");
                String glCreditAcctComp[] = glCreditAcct.split("-");
                for(int i = 0; i < 8; i++)
                    lst.set(i + 8, glCreditAcctComp[i]);

                dwfile.writeTransRec(lst);
            }
            catch(Exception e)
            {
                System.out.println((new StringBuilder("DWCronTask unhandled error: ")).append(e.getMessage()).toString());
                e.printStackTrace();
                return;
            }
        String sTotalAmount;
        if(totalAmount < 0L)
            sTotalAmount = (new StringBuilder("-")).append(DWFile.padString((new Long(Math.abs(totalAmount))).toString(), "0", 15, true)).toString();
        else
            sTotalAmount = DWFile.padString((new Long(Math.abs(totalAmount))).toString(), "0", 16, true);
        dwfile.writeTrailer(sTotalAmount, sTotalAmount);
        dwfile.close();
        rs.close();
        pstmt.close();
        mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".writeJobTrans():[Info]End processing labour transactions...").toString());
        
        SQLException e;
        
        if(rs != null)
            rs.close();
        if(pstmt != null)
            pstmt.close();
        
    }

    private void writeMatTrans(Connection conn)
        throws SQLException, IOException
    {
        ResultSet rs = null;
        PreparedStatement pstmt = null;
        try
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".writeMatTrans():[Info]Start processing material transactions...").toString());
            Date curDate = new Date();
            Date prevDate = new Date(curDate.getTime() - (long)extractday * 24L * 60L * 60L * 1000L);
            DateFormat YmdDateFormat = new SimpleDateFormat("yyyyMMdd");
            String prevDateStr = YmdDateFormat.format(prevDate);
            String matSqlStmt = (new StringBuilder("SELECT GL.LINECOST, GL.TRANSDATE, GL.CURRENCYCODE, GL.GLCREDITACCT, GL.GLDEBITACCT, GL.ASSETNUM, GL.LOCATION, GL.WONUM, GL.ITEMNUM, GL.INVTRANSID, GL.MATUSETRANSID, GL.MATRECTRANSID, GL.SOURCEMBO, GL.TRANSTYPE, GL.ISSUETYPE, GL.SITEID, GL.TOSITEID, WO.DESCRIPTION, WO.ACTSTART, WO.ACTFINISH, WO.FAILURECODE, WO.PROBLEMCODE, WO.WORKTYPE FROM MXGLTXN_IFACE GL LEFT OUTER JOIN WORKORDER WO ON (GL.WONUM = WO.WONUM and NVL(GL.TOSITEID, GL.SITEID) = WO.SITEID) WHERE TO_CHAR(GL.TRANSDATE,'YYYYMMDD') = '")).append(prevDateStr).append("' ").append("AND (GL.SOURCEMBO = 'INVTRANS' OR GL.SOURCEMBO = 'MATUSETRANS' OR (GL.SOURCEMBO = 'MATRECTRANS' AND GL.ISSUETYPE = 'TRANSFER')) ").append("ORDER BY GL.TRANSDATE").toString();
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".writeJobTrans():[Info]SQL Statement - ").append(matSqlStmt).toString());
            pstmt = conn.prepareStatement(matSqlStmt);
            rs = pstmt.executeQuery();
            String assetSqlStmt = "SELECT * FROM ASSET WHERE ASSETNUM = ? AND SITEID = ?";
            PreparedStatement assetPstmt = conn.prepareStatement(assetSqlStmt);
            String locationSqlStmt = "SELECT * FROM LOCATIONS WHERE SITEID = ? AND LOCATION = ? ";
            PreparedStatement locationPstmt = conn.prepareStatement(locationSqlStmt);
            DWFile dwfile = new DWFile((new StringBuilder(String.valueOf(processDirectory))).append("jcmat.txt").toString(), delimiter);
            dwfile.writeHeader("Material Cost");
            long totalAmount = 0L;
            ArrayList lst;
            for(; rs.next(); dwfile.writeTransRec(lst))
            {
                lst = new ArrayList();
                lst.add("1");
                double bdLinecost = rs.getDouble("LINECOST") * 100D;
                String lineCostSgn;
                if(bdLinecost < 0.0D)
                    lineCostSgn = "-";
                else
                    lineCostSgn = "0";
                long lLinecost = (long)bdLinecost;
                String sLinecost = (new StringBuilder(String.valueOf(lineCostSgn))).append(DWFile.padString((new Long(Math.abs(lLinecost))).toString(), "0", 15, true)).toString();
                totalAmount += lLinecost;
                lst.add(sLinecost);
                lst.add(DWFile.padString("", "0", 16, true));
                lst.add(DWFile.padString("JCMAT", " ", 25, false));
                Date transDate = rs.getDate("TRANSDATE");
                DateFormat DmyDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
                String transDateStr = DmyDateFormat.format(transDate);
                lst.add(transDateStr);
                String curCode = rs.getString("CURRENCYCODE");
                if(curCode == null)
                    curCode = "SGD";
                lst.add(DWFile.padString(curCode, " ", 15, false));
                String curDateDmy = DmyDateFormat.format(curDate);
                lst.add(curDateDmy);
                lst.add("A");
                String glDebitAcct = rs.getString("GLDEBITACCT");
                String glDebitAcctComp[] = glDebitAcct.split("-");
                for(int i = 0; i < 8; i++)
                    lst.add(glDebitAcctComp[i]);

                lst.add(DWFile.padString("", "0", 15, true));
                lst.add("0");
                lst.add("5");
                lst.add(DWFile.padString("", " ", 30, true));
                lst.add(DWFile.padString("", " ", 11, true));
                lst.add(DWFile.padString("", "0", 15, true));
                String assetnum = rs.getString("ASSETNUM");
                String location = rs.getString("LOCATION");
                if(assetnum != null || location != null)
                {
                    if(location != null)
                    {
                        String siteid = rs.getString("TOSITEID");
                        if(siteid == null)
                            siteid = rs.getString("SITEID");
                        locationPstmt.clearParameters();
                        locationPstmt.setString(1, siteid);
                        locationPstmt.setString(2, location);
                        ResultSet locationRS = locationPstmt.executeQuery();
                        if(locationRS.next())
                        {
                            String oaAssetNum = locationRS.getString("OAASSETNUM");
                            if(oaAssetNum != null)
                            {
                                String dwAssetnum = (new StringBuilder(String.valueOf(glDebitAcctComp[0]))).append(".").append(oaAssetNum).toString();
                                lst.add(dwAssetnum);
                            } else
                            if(assetnum != null)
                            {
                                assetPstmt.clearParameters();
                                assetPstmt.setString(1, assetnum);
                                assetPstmt.setString(2, siteid);
                                ResultSet assetRS = assetPstmt.executeQuery();
                                if(assetRS.next())
                                {
                                    oaAssetNum = assetRS.getString("OAASSETNUM");
                                    if(oaAssetNum != null)
                                    {
                                        String dwAssetnum = (new StringBuilder(String.valueOf(glDebitAcctComp[0]))).append(".").append(oaAssetNum).toString();
                                        lst.add(dwAssetnum);
                                    } else
                                    {
                                        lst.add("");
                                    }
                                } else
                                {
                                    lst.add("");
                                }
                            } else
                            {
                                lst.add("");
                            }
                        } else
                        {
                            lst.add("");
                        }
                    } else
                    if(assetnum != null)
                    {
                        String siteid = rs.getString("SITEID");
                        assetPstmt.clearParameters();
                        assetPstmt.setString(1, assetnum);
                        assetPstmt.setString(2, siteid);
                        ResultSet assetRS = assetPstmt.executeQuery();
                        if(assetRS.next())
                        {
                            String oaAssetNum = assetRS.getString("OAASSETNUM");
                            if(oaAssetNum != null)
                            {
                                String dwAssetnum = (new StringBuilder(String.valueOf(glDebitAcctComp[0]))).append(".").append(oaAssetNum).toString();
                                lst.add(dwAssetnum);
                            } else
                            {
                                lst.add("");
                            }
                        } else
                        {
                            lst.add("");
                        }
                    } else
                    {
                        lst.add("");
                    }
                } else
                {
                    lst.add("");
                }
                String wonum = rs.getString("WONUM");
                if(wonum != null)
                {
                    lst.add(wonum);
                    String woDesc = rs.getString("DESCRIPTION");
                    if(woDesc != null)
                        lst.add(woDesc);
                    else
                        lst.add("");
                    java.sql.Timestamp jobStartDate = rs.getTimestamp("ACTSTART");
                    if(jobStartDate != null)
                    {
                        DateFormat jobDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
                        String jobStartDateStr = jobDateFormat.format(jobStartDate);
                        lst.add(jobStartDateStr);
                    } else
                    {
                        lst.add(DWFile.padString("", " ", 12, true));
                    }
                    java.sql.Timestamp jobEndDate = rs.getTimestamp("ACTFINISH");
                    if(jobEndDate != null)
                    {
                        DateFormat jobDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
                        String jobEndDateStr = jobDateFormat.format(jobEndDate);
                        lst.add(jobEndDateStr);
                    } else
                    {
                        lst.add(DWFile.padString("", " ", 12, true));
                    }
                    String partcode1 = rs.getString("FAILURECODE");
                    String partcode2 = rs.getString("PROBLEMCODE");
                    String partcode = new String();
                    if((partcode1 == null) & (partcode2 == null))
                    {
                        lst.add("");
                    } else
                    {
                        if(partcode1 != null)
                            partcode = partcode1;
                        if(partcode2 != null)
                            partcode = (new StringBuilder(String.valueOf(partcode))).append(partcode2).toString();
                        lst.add(partcode);
                    }
                    String woType = rs.getString("WORKTYPE");
                    if(woType != null)
                        lst.add(woType);
                    else
                        lst.add("");
                } else
                {
                    lst.add("");
                    lst.add("");
                    lst.add(DWFile.padString("", " ", 12, true));
                    lst.add(DWFile.padString("", " ", 12, true));
                    lst.add("");
                    lst.add("");
                }
                lst.add(DWFile.padString("", "0", 9, true));
                String stockcode = rs.getString("ITEMNUM");
                if(stockcode != null)
                    lst.add(stockcode);
                else
                    lst.add("");
                lst.add("New");
                lst.add("");
                lst.add("");
                lst.add("");
                String directLabour = DWFile.padString("", "0", 9, true);
                lst.add(directLabour);
                lst.add(DWFile.padString("", "0", 9, true));
                lst.add(DWFile.padString("", "0", 9, true));
                String matcost = (new StringBuilder(String.valueOf(lineCostSgn))).append(DWFile.padString((new Long(Math.abs(lLinecost))).toString(), "0", 8, true)).toString();
                lst.add(matcost);
                lst.add(DWFile.padString("", "0", 9, true));
                lst.add(DWFile.padString("", "0", 7, true));
                lst.add(DWFile.padString("", "0", 9, true));
                lst.add(DWFile.padString("", "0", 9, true));
                dwfile.writeTransRec(lst);
                lst.set(1, DWFile.padString("", "0", 16, true));
                lst.set(2, sLinecost);
                String glCreditAcct = rs.getString("GLCREDITACCT");
                String glCreditAcctComp[] = glCreditAcct.split("-");
                for(int i = 0; i < 8; i++)
                    lst.set(i + 8, glCreditAcctComp[i]);

            }

            String sTotalAmount;
            if(totalAmount < 0L)
                sTotalAmount = (new StringBuilder("-")).append(DWFile.padString((new Long(Math.abs(totalAmount))).toString(), "0", 15, true)).toString();
            else
                sTotalAmount = DWFile.padString((new Long(Math.abs(totalAmount))).toString(), "0", 16, true);
            dwfile.writeTrailer(sTotalAmount, sTotalAmount);
            dwfile.close();
            rs.close();
            pstmt.close();
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".writeMatTrans():[Info]End processing material transactions...").toString());
        }
        catch(SQLException e)
        {
            if(rs != null)
                rs.close();
            if(pstmt != null)
                pstmt.close();
            throw e;
        }
    }

    private void processData()
        throws Exception
    {
        MxDatabase db = null;
        Connection conn = null;
        try
        {
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".processData():[Info]Start processing ...").toString());
            db = new MxDatabase(getRunasUserInfo());
            conn = db.getConn();
            writeJobTrans(conn);
            writeMatTrans(conn);
            if(purgeData)
                purgeTable(conn);
            db.releaseResources();
            mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(".processData():[Info]Finished processing ...").toString());
        }
        catch(Exception e)
        {
            if(db != null)
                db.releaseResources();
            throw e;
        }
    }

    public CrontaskParamInfo[] getParameters()
        throws MXException, RemoteException
    {
        return params;
    }

    private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
    private static final String SPACE = " ";
    private static final String LABTRANS_FILENAME = "jcjob.txt";
    private static final String MATTRANS_FILENAME = "jcmat.txt";
    private static final String ZIP_EXT = ".gz";
    protected String delimiter;
    protected String adminEmail;
    protected String emailSubj;
    protected String zipExec;
    protected boolean enableLog;
    protected String logFilePath;
    protected String processDirectory;
    protected String labOutputFilePath;
    protected String matOutputFilePath;
    protected String labArchiveFilePath;
    protected String matArchiveFilePath;
    protected boolean purgeData;
    protected int extractday;
    protected String qualifiedInstanceName;
    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
    protected MxLog mxLog;
    protected MxEmail email;
    protected boolean initialized;
    protected static CrontaskParamInfo params[];

    static 
    {
        params = null;
        params = new CrontaskParamInfo[13];
        params[0] = new CrontaskParamInfo();
        params[0].setName("SPLITTAG");
        params[0].setDescription("CommonCron", "DelimiterFlatFile");
        params[0].setDefault("~");
        params[1] = new CrontaskParamInfo();
        params[1].setName("ALERTEMAIL");
        params[1].setDescription("CommonCron", "Adminemailaddress");
        params[2] = new CrontaskParamInfo();
        params[2].setName("ALERTEMAILSUBJ");
        params[2].setDescription("CommonCron", "EmailSubject");
        params[3] = new CrontaskParamInfo();
        params[3].setName("ZIPEXEC");
        params[3].setDescription("CommonCron", "ExecutableZiping");
        params[3].setDefault("gzip -f -q");
        params[4] = new CrontaskParamInfo();
        params[4].setName("LABOUTPUTFILEPATH");
        params[4].setDescription("CommonCron", "LabourTransactionOutput");
        params[5] = new CrontaskParamInfo();
        params[5].setName("MATOUTPUTFILEPATH");
        params[5].setDescription("CommonCron", "MaterialTransactionOutput");
        params[6] = new CrontaskParamInfo();
        params[6].setName("LABARCHIVEFILEPATH");
        params[6].setDescription("CommonCron", "LabourTransactionArchive");
        params[7] = new CrontaskParamInfo();
        params[7].setName("MATARCHIVEFILEPATH");
        params[7].setDescription("CommonCron", "MaterialTransactionArchive");
        params[8] = new CrontaskParamInfo();
        params[8].setName("PROCESSDIRECTORY");
        params[8].setDescription("CommonCron", "DirectoryProcessing");
        params[9] = new CrontaskParamInfo();
        params[9].setName("ENABLELOG");
        params[9].setDescription("CommonCron", "EnableLog");
        params[9].setDefault("Y");
        params[10] = new CrontaskParamInfo();
        params[10].setName("LOGFILEPATH");
        params[10].setDescription("CommonCron", "LogDirectory");
        params[11] = new CrontaskParamInfo();
        params[11].setName("PURGEDATA");
        params[11].setDescription("CommonCron", "PurgeData");
        params[11].setDefault("N");
        params[12] = new CrontaskParamInfo();
        params[12].setName("EXTRACTDAY");
        params[12].setDescription("CommonCron", "IntegerNoofDays");
        params[12].setDefault("1");
    }
}