/**
 * 
 */
package com.psa.custom.ofrecon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

import javax.mail.MessagingException;

import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxZip;

import psdi.app.system.CrontaskParamInfo;
import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.iface.app.interror.MaxIntErrorMsg;
import psdi.iface.app.interror.MaxIntErrorMsgRemote;
import psdi.iface.app.interror.MaxIntErrorMsgSet;
import psdi.iface.app.interror.MaxIntErrorRemote;
import psdi.iface.app.interror.MaxIntErrorSetRemote;
import psdi.iface.jms.MessageUtil;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

/**
 * Custom Cron Task for sending email alerts to ED users for GFS Interface errors
 * 
 * @author descheon
 * @since 28 March 2019
 *
 */
public class GFSInterfaceErrorAlertCron1 extends SimpleCronTask {
	
	// Logging
	protected static final MXLogger cronLogger = MXLoggerFactory.getLogger("maximo.crontask.GFSInterfaceErrorAlertCron");
	private static final String LOG_IDF = " [GFSInterfaceErrorAlertCron]: ";
	
	// Date Formats
	private static final String DATE_TIME_FORMAT = "dd.MM.yyyy";
	private static final String LOG_DATE_TIME_FORMAT = "yyyyMMdd";
	
	// Static IDs
	private static final String TYPE_PR = "PR";
	private static final String TYPE_PO = "PO";
	private static final String TYPE_RCPT = "RCPT";
	
	// Private Attributes
	private String unzipCmd;

	private String filePathOutbound;
	private String fileOutbound;
	
	private String filePathInbound;
	private String fileInbound;
	private String prInfoFile;

	private String sendFrom;
	private String adminEmail;
	private String adminEmailSub;
	
	private String idfrPR;
	private String idfrPOout;
	private String idfrPOin;
	private String idfrRcpt;

	private String commTmpl;
	private String imsTo;
	private String imsCc;
		
	/**
	 * Constructor for GFSInterfaceErrorAlertCron
	 */
	public GFSInterfaceErrorAlertCron1() {
		
		super();
		unzipCmd = null;
		filePathOutbound = null;
		fileOutbound = null;
		filePathInbound = null;
		fileInbound = null;
		prInfoFile = null;
		sendFrom = null;
		adminEmail = null;
        adminEmailSub = null;
        idfrPR = null;
        idfrPOout = null;
        idfrPOin = null;
        idfrRcpt = null;
        commTmpl = null;
        imsTo = null;
        imsCc = null;
//      emailSubj = null;
//    	emailBody = null;
    	
	} // End GFSInterfaceErrorAlertCron()
	
	/**
	 * Override Method for standard Maximo CronTask method for retrieving Cron Task parameters
	 * 
	 * @return params - Array of Cron Task Parameter objects
	 */
	public CrontaskParamInfo[] getParameters() throws MXException, RemoteException {
		
		CrontaskParamInfo[] params = new CrontaskParamInfo[16];
		
		params[0] = new CrontaskParamInfo();
        params[0].setName("UNZIPCMD");
        params[0].setDescription("UNZIPCMD", "Command to Unzip File");
        params[0].setDefault("gunzip -f -q");
        
		params[1] = new CrontaskParamInfo();
        params[1].setName("FILEPATHOUTBOUND");
        params[1].setDescription("FILEPATHOUTBOUND", "File path to report for OUTBOUND transactions to GFS");
        params[1].setDefault("/opt/psa/data/maximo7.6/log/poscript/daily/");
        
		params[2] = new CrontaskParamInfo();
        params[2].setName("FILEOUTBOUND");
        params[2].setDescription("FILEOUTBOUND", "File Name of report for OUTBOUND transactions to GFS");
        params[2].setDefault("report.dd.MM.yyyy.txt.gz");
        
		params[3] = new CrontaskParamInfo();
        params[3].setName("FILEPATHINBOUND");
        params[3].setDescription("FILEPATHINBOUND", "File path to report for INBOUND transactions from GFS");
        params[3].setDefault("/opt/psa/data/maximo7.6/log/poscript/");
        
		params[4] = new CrontaskParamInfo();
        params[4].setName("FILEINBOUND");
        params[4].setDescription("FILEINBOUND", "File Name of report for INBOUND transactions from GFS");
        params[4].setDefault("po_report.dd.MM.yyyy.txt.gz");
        
		params[5] = new CrontaskParamInfo();
        params[5].setName("FILEINFOPR");
        params[5].setDescription("FILEINFOPR", "File Name of PR Info file corresponding to report for INBOUND transactions from GFS");
        params[5].setDefault("prinfo.dd.MM.yyyy.txt");

		params[6] = new CrontaskParamInfo();
        params[6].setName("SENDFROM");
        params[6].setDescription("SENDFROM", "Email Address used for sending out emails");
        params[6].setDefault("emsteam_req@psa.com.sg");
        
		params[7] = new CrontaskParamInfo();
        params[7].setName("ADMINEMAIL");
        params[7].setDescription("ADMINEMAIL", "Email Address of system support team");
        params[7].setDefault("emsteam_req@psa.com.sg");
        
		params[8] = new CrontaskParamInfo();
        params[8].setName("ADMINEMAILSUB");
        params[8].setDescription("ADMINEMAILSUB", "Email Subject for Admin Alert Email");
        params[8].setDefault("[PROD] Error occur GFS Interface Alert cron");
                
		params[9] = new CrontaskParamInfo();
        params[9].setName("IDFRPR");
        params[9].setDescription("IDFRPR", "Identifier for PR OUTbound to GFS");
        params[9].setDefault("PR(s) in");
        
		params[10] = new CrontaskParamInfo();
        params[10].setName("IDFRPOOUT");
        params[10].setDescription("IDFRPOOUT", "Identifier for PO OUTbound to GFS");
        params[10].setDefault("PO(s) in");
        
		params[11] = new CrontaskParamInfo();
        params[11].setName("IDFRPOIN");
        params[11].setDescription("IDFRPOIN", "Identifier for PO INbound from GFS");
        params[11].setDefault("PO(s) not in");
        
		params[12] = new CrontaskParamInfo();
        params[12].setName("IDFRRCPT");
        params[12].setDescription("IDFRRCPT", "Comms Template for sending email to users");
        params[12].setDefault("Receipt difference(s)");
        
		params[13] = new CrontaskParamInfo();
        params[13].setName("COMMTEMPLATE");
        params[13].setDescription("COMMTEMPLATE", "Comms�Template�for�sending�email�to�users");
        params[13].setDefault("GFSIFACERROR2USR");
        
		params[14] = new CrontaskParamInfo();
        params[14].setName("IMSTOLIST");
        params[14].setDescription("IMSTOLIST", "TO Recipient list for IMS Users (must have comma after each email address)");
        params[14].setDefault("keerlim@globalpsa.com,");
        
		params[15] = new CrontaskParamInfo();
        params[15].setName("IMSCCLIST");
        params[15].setDescription("IMSCCLIST", "CC Recipient list for IMS Users (must have comma after each email address)");
        params[15].setDefault("calvint@globalpsa.com,bensonl@globalpsa.com,");

		return params;
		
	} // End getParameters()
	
	
	/**
	 * Reload Cron Task Parameters
	 * 
	 * @throws RemoteException
	 * @throws MXException
	 */
	private void refreshSettings() throws RemoteException, MXException 	{
		
		final String MTD_IDF = "refreshSettings(): ";
		
		try
		{
			
			cronLogger.debug(LOG_IDF + MTD_IDF + " Refreshing Settings ... ");
			
			DateFormat fileDateFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
			String todayDate=fileDateFormat.format(new Date());
			
			unzipCmd=getParamAsString("UNZIPCMD");
			
			filePathOutbound=getParamAsString("FILEPATHOUTBOUND");
			fileOutbound=getParamAsString("FILEOUTBOUND");
			fileOutbound=fileOutbound.replaceAll(DATE_TIME_FORMAT, todayDate);
			
			filePathInbound=getParamAsString("FILEPATHINBOUND");
			fileInbound=getParamAsString("FILEINBOUND");
			fileInbound=fileInbound.replaceAll(DATE_TIME_FORMAT, todayDate);
			
			prInfoFile=getParamAsString("FILEINFOPR");
			prInfoFile=prInfoFile.replaceAll(DATE_TIME_FORMAT, todayDate);
			
			sendFrom=getParamAsString("SENDFROM");
			adminEmail=getParamAsString("ADMINEMAIL");
			adminEmailSub=getParamAsString("ADMINEMAILSUB");
			
	        idfrPR = getParamAsString("IDFRPR");
	        idfrPOout = getParamAsString("IDFRPOOUT");
	        idfrPOin = getParamAsString("IDFRPOIN");
	        idfrRcpt = getParamAsString("IDFRRCPT");
	        
	        commTmpl = getParamAsString("COMMTEMPLATE");
	        imsTo = getParamAsString("IMSTOLIST");
	        imsCc = getParamAsString("IMSCCLIST");
			
			cronLogger.debug(LOG_IDF + MTD_IDF + "Refresh Settings Completed.");
			
		} catch(Exception e) {
			
			cronLogger.error(LOG_IDF + MTD_IDF + "ERROR: "+e.getMessage());
			e.printStackTrace();
			
		}

	} // End refreshSettings()
	
	/**
	 * Check if all required parameters are set
	 * 
	 * @return FALSE if any parameter not set, TRUE otherwise
	 */
	private boolean isReqParamSet() {
		
		final String MTD_IDF = "isReqParamSet(): ";
		
		if (unzipCmd.equalsIgnoreCase("")) return false;
		if (filePathOutbound.equalsIgnoreCase("")) return false;
		if (fileOutbound.equalsIgnoreCase("")) return false;
		if (filePathInbound.equalsIgnoreCase("")) return false;
		if (fileInbound.equalsIgnoreCase("")) return false;
		if (prInfoFile.equalsIgnoreCase("")) return false;
		
		if (sendFrom.equalsIgnoreCase("")) return false;
		if (adminEmail.equalsIgnoreCase("")) return false;
		if (adminEmailSub.equalsIgnoreCase("")) return false;
		
		if (idfrPR.equalsIgnoreCase("")) return false;
		if (idfrPOout.equalsIgnoreCase("")) return false;
		if (idfrPOin.equalsIgnoreCase("")) return false;
		if (idfrRcpt.equalsIgnoreCase("")) return false;
		
		if (commTmpl.equalsIgnoreCase("")) return false;
		if (imsTo.equalsIgnoreCase("")) return false;
		if (imsCc.equalsIgnoreCase("")) return false;

		cronLogger.debug(LOG_IDF + MTD_IDF + "ALL Required Parameters loaded as below, ");
		cronLogger.debug(LOG_IDF + MTD_IDF + "unzipCmd: " + unzipCmd);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Filepath Outbound: " + filePathOutbound);
		cronLogger.debug(LOG_IDF + MTD_IDF + "File Outbound: " + fileOutbound);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Filepath Inbound: " + filePathInbound);
		cronLogger.debug(LOG_IDF + MTD_IDF + "File Inbound: " + fileInbound);
		cronLogger.debug(LOG_IDF + MTD_IDF + "PR Info File: " + prInfoFile);
		
		cronLogger.debug(LOG_IDF + MTD_IDF + "Send Email Using: " + sendFrom);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Admin Email Addr: " + adminEmail);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Admin Email Subject: " + adminEmailSub);
		
		cronLogger.debug(LOG_IDF + MTD_IDF + "Identifier PR: " + idfrPR);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Identifier PO (Out): " + idfrPOout);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Identifier PO (In): " + idfrPOin);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Identifier Receipt: " + idfrRcpt);
		
		cronLogger.debug(LOG_IDF + MTD_IDF + "Comm Template: " + commTmpl);
		cronLogger.debug(LOG_IDF + MTD_IDF + "IMS TO List: " + imsTo);
		cronLogger.debug(LOG_IDF + MTD_IDF + "IMS CC List: " + imsCc);
		
		// All above have values
		return true;
		
	} // End isReqParamSet()
	
	/**
	 * Check if file exists and sends alert email to administrator if required
	 * 
	 * @param abspath String representing absolute path to the gz report file
	 * @param sendEmail Boolean, TRUE to send alert email to admin, FALSE otherwise
	 * @return TRUE if file exists, FALSE otherwise
	 * @throws MessagingException
	 */
	public boolean checkFileExist (String abspath, boolean sendEmail) throws MessagingException {

		final String MTD_IDF = "checkFileExist(abspath): ";
		
		File f = new File(abspath); 
		
		if(f.exists() && f.isFile()) {
			
			cronLogger.debug(LOG_IDF + MTD_IDF + "File EXISTS: " + abspath);
			
			return true;
			
		} else {
			
			cronLogger.error(LOG_IDF + MTD_IDF + "WARNING - File does NOT exists: " + abspath);
			if(sendEmail) { MXServer.sendEMail(adminEmail, sendFrom, adminEmailSub,"File does NOT exists: " + abspath);}
			
			return false;
			
		}
		
	} // End checkFileExist (abspath)
	
	
	/**
	 * To unzip a file
	 * 
	 * @param abspath String representing absolute path to the gz report file
	 * @return TRUE if unzip operation successful, FALSE otherwise
	 */
	private boolean unZipFile(String abspath) {
		
		boolean fileUNZipCompleted=true;
		
		final String MTD_IDF="unZipFile(abspath): ";
		
		try{
			
			cronLogger.debug(LOG_IDF + MTD_IDF +"Unzipping File: " + abspath);
			
			String cmd = unzipCmd + " " + abspath;
			int retcode= MxZip.unzipFile(cmd);
			if (retcode != 0){
				fileUNZipCompleted=false;
			}

		} catch(Exception e) {
			cronLogger.error(LOG_IDF + MTD_IDF +"ERROR - File Unzip FAILED: "+e.getMessage());
		}
		
		return fileUNZipCompleted;

	} // End unZipFile(abspath)
	
	/**
	 * Action to be performed by this Custom Cron Task
	 */
	public void cronAction() {

		final String MTD_IDF = "cronAction(): ";
		
		final String TMPFILE_PREFIX = "GFS-";
		
		String abspath =null;
		String tmppath =null;
		String tmpFile =null;
		File processedFile = null;
		int dotPos = -1;
				
		try {
			
			refreshSettings(); // Reload Cron Task parameters every time cron task runs
			
			// Run rest of Cron Task only if required parameters are set
			if( isReqParamSet() ) {
				
				// ------------------------------------ Process OUTBOUND Report File ------------------------------------ //
				abspath = filePathOutbound+fileOutbound;
				tmppath = filePathOutbound+TMPFILE_PREFIX+fileOutbound;
				if( checkFileExist(abspath, true) ) {
					
					// Duplicate file as a temp file for unzipping
					MxFileCopy.fileCopy(abspath,tmppath);
					
					// Unzip duplicated temp file
					if ( unZipFile(tmppath) ) {
					
						// Remove ".gz" from the end of the absolute file path to get path to actual file
						dotPos = tmppath.lastIndexOf(".");
						tmpFile=tmppath.substring(0,dotPos);
						
						processOutboundRpt(tmpFile);
						
						// Delete temp file
						processedFile = new File(tmpFile);
						processedFile.delete();
						
					} else {
						cronLogger.error(LOG_IDF + MTD_IDF +"ERROR - Could NOT process OUTBOUND Report file !!!");
					}
					
				}			
				
				// ------------------------------------ Reset common variables ------------------------------------ //
				dotPos = -1;
				abspath =null;
				tmppath =null;
				tmpFile =null;
				processedFile = null;
				
				// ------------------------------------ Process INBOUND Report File ------------------------------------ //
			
				abspath = filePathInbound+fileInbound;
				tmppath = filePathInbound+TMPFILE_PREFIX+fileInbound;
				
				if( checkFileExist(abspath, true) && checkFileExist(filePathInbound+prInfoFile, true) ) {
					
					// Duplicate file BEFORE unzip
					MxFileCopy.fileCopy(abspath,tmppath);
					
					// Unzip file
					if ( unZipFile(tmppath) ) {
						
						// Remove ".gz" from the end of the absolute file path to get path to actual file
						dotPos = tmppath.lastIndexOf(".");
						tmpFile=tmppath.substring(0,dotPos);
					
						processInboundRpt(tmpFile);
						
						// Delete temp file
						processedFile = new File(tmpFile);
						processedFile.delete();
						
						
					} else {
						cronLogger.error(LOG_IDF + MTD_IDF +"ERROR - Could NOT process INBOUND Report file !!!");
					}
										
				}
				
			} // End if(isReqParamSet())
			
		} catch (MXException e) {

			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF + "ERROR: "+e.getMessage());
			
		} catch (Exception e) {
			
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF + "ERROR: "+e.getMessage());
			
		} finally {
			
			abspath =null;
			tmppath =null;
			tmpFile =null;
			processedFile = null;
						
		}
		
	} // End cronAction()
	
	/**
	 * Send email to Users with specified report as attachment
	 * 
	 * @param toList
	 * @param ccList
	 * @param bccList
	 * @param subj
	 * @param msg
	 * @param attachmt
	 */
	private void emailUsers(String toList, String ccList, String bccList, String replyTo, String subj, String msg, String attachmt) {
		
		final String MTD_IDF = "emailUsers(): ";
		
		try {
			
			cronLogger.debug(LOG_IDF + MTD_IDF +"toList: " + toList);
			cronLogger.debug(LOG_IDF + MTD_IDF +"ccList: " + ccList);
			cronLogger.debug(LOG_IDF + MTD_IDF +"bccList: " + bccList);
			cronLogger.debug(LOG_IDF + MTD_IDF +"replyTo: " + replyTo);
			cronLogger.debug(LOG_IDF + MTD_IDF +"subj: " + subj);
			cronLogger.debug(LOG_IDF + MTD_IDF +"msg: " + msg);
			cronLogger.debug(LOG_IDF + MTD_IDF +"attachmt: " + attachmt);
			
			// Send email only if attachment is available
			if ( checkFileExist(attachmt,true) ){
				
				String[] fileName = new String[1];
				fileName[0] = attachmt;
				
				cronLogger.debug(LOG_IDF + MTD_IDF +"fileName: " + fileName[0]);
								
				cronLogger.debug(LOG_IDF + MTD_IDF +"Sending email ...");
				
				//sendEMail(java.lang.String to, java.lang.String cc, java.lang.String bcc, java.lang.String from, java.lang.String subject, java.lang.String message, 
				//  java.lang.String ReplyTo, java.lang.String[] fileName, java.lang.String[] urlName) 
				MXServer.sendEMail(toList, ccList, bccList, sendFrom, subj, msg, replyTo, fileName, null); 
				
				cronLogger.debug(LOG_IDF + MTD_IDF +"After sending email");
				
			} else {
				cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: File to be attached does NOT exist: " + attachmt);
			}
						
		} catch (MessagingException e) {
			
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MessagingException: " + e.getMessage());
			
		}
		
	} // End emailUsers(toList, ccList, subj, msg, attachmt)
	
	/**
	 * Process report for OUTBOUND transactions to GFS
	 * 
	 * @param abspath String representing absolute path to the gz report file
	 * @throws MessagingException
	 */
	private void processOutboundRpt(String abspath) {
		
		final String MTD_IDF = "processOutboundRpt(): ";
		
		String DELIM = "\\s+"; // Default to single space first since PRs and POs uses that
		
		cronLogger.info(LOG_IDF + MTD_IDF +"Processing OUTBOUND Report... ");
		
		String currentLine;
		
		FileReader fileReader = null;
		BufferedReader bufReader = null;
		
		String type = "";
		
		String prList = "";
		String poList = "";
		String rcptList = "";
		
		String[] parts = null;
		String id = null;
		String emailAddr = null;

		String subj = null;
		String body = null;
		String toList = null;
		String ccList = null;
		String bccList = null;
		String emailSubj = null;
		String emailBody = null;
		String replyTo = null;
		CommTemplateRemote tempRemote= null;
		CommTemplateSetRemote commTemplateSet= null;
		
		DBShortcut dbShortcut = new DBShortcut();
		SqlFormat prToSql= null;
		SqlFormat prCcSql= null;
		SqlFormat poToSql= null;
		SqlFormat poCcSql= null;
		SqlFormat rcptToSql= null;
		SqlFormat rcptCcSql= null;
		SqlFormat woPrSql= null;
		SqlFormat woPoSql= null;
		//SqlFormat toListSql= null;
		//SqlFormat ccListSql= null;
		
		String query = "";
		
		//String prQuery = "SELECT DISTINCT personid FROM ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE prnum in (:idList) )";
		String prToQuery = "SELECT DISTINCT emailaddress,personid FROM email WHERE personid IN ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE prnum =':id' )";
		String prCcQuery = "SELECT DISTINCT emailaddress, personid FROM email WHERE personid IN (SELECT respparty FROM persongroupteam WHERE persongroup  IN ( SELECT sectionhead FROM person WHERE personid IN ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE prnum=':id' ) ) )";
		//String poQuery = "SELECT DISTINCT personid FROM ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE ponum in (:idList) )";
		String poToQuery = "SELECT DISTINCT emailaddress,personid FROM email WHERE personid IN ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE ponum=':id' )";
		String poCcQuery = "SELECT DISTINCT emailaddress, personid FROM email WHERE personid IN (SELECT respparty FROM persongroupteam WHERE persongroup  IN ( SELECT sectionhead FROM person WHERE personid IN ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE ponum=':id' ) ) )";
		//String rcptQuery = "SELECT DISTINCT personid FROM ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE ponum in (:idList) )";
		String rcptToQuery = "SELECT DISTINCT emailaddress,personid FROM email WHERE personid IN ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE ponum=':id' )";
		String rcptCcQuery = "SELECT DISTINCT emailaddress, personid FROM email WHERE personid IN (SELECT respparty FROM persongroupteam WHERE persongroup  IN ( SELECT sectionhead FROM person WHERE personid IN ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE ponum=':id' ) ) )";
		String woPrQuery = "SELECT distinct wonum, supervisor FROM workorder WHERE wonum IN (SELECT refwo FROM prline WHERE prnum=':id') ORDER BY wonum, supervisor";
		String woPoQuery = "SELECT distinct wonum, supervisor FROM workorder WHERE wonum IN (SELECT refwo FROM poline WHERE ponum=':id') ORDER BY wonum, supervisor";
		//String toListQuery = "SELECT DISTINCT emailaddress FROM email WHERE personid IN (:toList)";
		//String ccListQuery = "SELECT DISTINCT emailaddress FROM email WHERE personid IN (SELECT respparty FROM persongroupteam WHERE persongroup IN ( SELECT sectionhead FROM person WHERE personid IN (:ccList) ) )";
		
		ResultSet prToRSet=null;
		ResultSet prCcRSet=null;
		ResultSet poToRSet=null;
		ResultSet poCcRSet=null;
		ResultSet rcptToRSet=null;
		ResultSet rcptCcRSet=null;
		ResultSet woPrRSet=null;
		ResultSet woPoRSet=null;
				
		try {
			
			dbShortcut.connect(getRunasUserInfo().getConnectionKey());
			
			fileReader = new FileReader(abspath);
			bufReader = new BufferedReader(fileReader);
			
			// Read Outbound Report file Line by Line
			while( (currentLine=bufReader.readLine()) != null ) {
				
				if(currentLine.length() != 0) {
					
					cronLogger.debug(LOG_IDF + MTD_IDF +"RL>> " + currentLine);
					
					// ----------------------------- First check for headers / types and run query when type changes ----------------------------- //
					if( currentLine.startsWith(idfrPR) ) {
						
						cronLogger.debug(LOG_IDF + MTD_IDF +"Start of PR section detected");
						type = TYPE_PR;
						continue;
						
					} else if ( currentLine.startsWith(idfrPOout) ) {
						
						cronLogger.debug(LOG_IDF + MTD_IDF +"Start of PO (out) section detected");
						type = TYPE_PO;
						continue;
						
					} else if ( currentLine.startsWith(idfrRcpt) ) {
						
						cronLogger.debug(LOG_IDF + MTD_IDF +"Start of Receipts section detected");
						type = TYPE_RCPT;
						DELIM = ","; // Switch delimiter for Receipts (e.g. of receipt string from report: "< M312289,0001,8" or "> M312289,0001,4" )
						continue;
						
					} else {
						// Do nothing
					}
					
					cronLogger.debug(LOG_IDF + MTD_IDF +"Type: " + type);
					
					// ------------------------------------------ Look for PR/PO/Receipt Numbers ------------------------------------------ //
					
					// Handle line(s) containing PR numbers
					if ( type.equalsIgnoreCase("PR") && currentLine.matches("^[M][0-9]{4,}.*") ) {
						
						parts=currentLine.split(DELIM);
						
						if( parts.length > 0 ) {
						
							// Skip if already exist in idList to avoid duplicates, otherwise add to end of list
							if ( prList.contains(parts[0].trim()) ) {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping PR["+parts[0].trim()+"], already in list..");
							} else {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Adding PR: " + parts[0].trim());
								prList += parts[0].trim() + ",";
							}
						
						} else {
							cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: Could NOT split line using delimiter: \"" + DELIM + "\"");
						}
						
						continue;
						
					} // End if PR
					
					// Handle line(s) containing PO numbers
					if ( type.equalsIgnoreCase("PO") && currentLine.matches("^[M][0-9]{4,}.*") ) {
						
						parts=currentLine.split(DELIM);
						
						if( parts.length > 0 ) {
							
							// Skip if already exist in idList to avoid duplicates, otherwise add to end of list
							if ( poList.contains(parts[0].trim()) ) {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping PO["+parts[0].trim()+"], already in list..");
							} else {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Adding PO: " + parts[0].trim());
								poList += parts[0].trim() + ",";
							}
						
						} else {
							cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: Could NOT split line using delimiter: \"" + DELIM + "\"");
						}
						
						continue;
						
					} // End if PO
					
					// Handle line(s) containing Receipt-PO numbers
					if ( type.equalsIgnoreCase("RCPT") && currentLine.matches("^[<>]\\s[M0-9][0-9]{3,}.*") ) {
						
						parts = currentLine.split(DELIM);
						
						if(parts.length > 0) {
												
							id = parts[0].replaceAll("< ", "").replaceAll("> ", "").trim();
							
							// Skip if already exist in idList to avoid duplicates, otherwise add to end of list
							if ( rcptList.contains(id) ) {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping RECEIPT-PO["+id+"], already in list..");
							} else {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Adding RECEIPT-PO: " + id);
								rcptList += id + ",";
							}
														
						} else {
							cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: Could NOT split line using delimiter: \"" + DELIM + "\"");
						}
						
						continue;
						
					} // End if Receipt
					
				} // End if current line is NOT empty 
				
			} // End while (read lines)
						
			cronLogger.debug(LOG_IDF + MTD_IDF +"Done reading through file, " + abspath);
			
			cronLogger.info(LOG_IDF + MTD_IDF +"PR List: [" + prList + "]");
			cronLogger.info(LOG_IDF + MTD_IDF +"PO List: [" + poList + "]");
			cronLogger.info(LOG_IDF + MTD_IDF +"Rcpt List: [" + rcptList + "]");
			
			
	    	// Get relevant comm template 
	    	commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
			commTemplateSet.setWhere("TEMPLATEID='"+commTmpl+"'");
			commTemplateSet.reset();
			tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);
			
			cronLogger.info(LOG_IDF + MTD_IDF +"Using CommTemplate for emails to users: " + commTmpl);
			
			//String toMail=tempRemote.getString("TOLIST");
			//String ccTo=tempRemote.getString("CCLIST");
			//String fromMail=tempRemote.getString("SENDFROM");
			bccList=tempRemote.getString("BCCLIST");
			emailSubj=tempRemote.getString("SUBJECT");
			emailBody=tempRemote.getString("MESSAGE");
			replyTo=tempRemote.getString("REPLYTO");
			
			// -------------------------------------- Prep and send email for Outbound Report PRs -------------------------------------- //
			
			parts = prList.split(DELIM);
			cronLogger.info(LOG_IDF + MTD_IDF +"No. of PRs: " + parts.length);
			
			// Loop through PR
			for(int i=0; i < parts.length; i++) {
				
				id = parts[i];
				cronLogger.info(LOG_IDF + MTD_IDF +"Processing PR: " + id);
				
				emailAddr = "";
				toList = "";
				ccList = "";
				currentLine = ""; // Re-use variable for printing output in Email body
				
				// Prepare PR To List Query
				query = prToQuery.replaceFirst(":id", id);
				prToSql=new SqlFormat(query);
				cronLogger.debug(LOG_IDF + MTD_IDF +"Run PR To List SQL: " + query);
				prToRSet = dbShortcut.executeQuery(prToSql.format());
											
				// Loop through results of PR To List Query from DB if there are any
				if(prToRSet != null) {
					
					while(prToRSet.next()) {
						
						emailAddr = prToRSet.getString(1);
						
						// Replace MAXADMIN with IMS To List
						if( prToRSet.getString(2).equalsIgnoreCase("MAXADMIN") ) {
							emailAddr = imsTo;
							cronLogger.info(LOG_IDF + MTD_IDF +"Replaced To Email address with IMS TO List: " + emailAddr);
						}
						
						if( emailAddr.length() > 0 ) {						
							
							// Skip if already in list to avoid duplicates
							if ( toList.contains(emailAddr) ) {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping for PR:"+id+" ["+emailAddr+"], already in list..");
							} else {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Adding for PR:"+id+" ["+emailAddr+":"+prToRSet.getString(2)+"]");
								toList += emailAddr + ",";
							}
							
						} else {
							cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: Empty/Null Person Id for PRs To List !!!");
						}
						
					}
					
					cronLogger.info(LOG_IDF + MTD_IDF +"Current To List for PRs: [" + toList + "]" );
					
					// Prepare PR Cc List Query
					query = prCcQuery.replaceFirst(":id", id);
					prCcSql=new SqlFormat(query);
					cronLogger.debug(LOG_IDF + MTD_IDF +"Run Cc List PR SQL: " + query);
					prCcRSet = dbShortcut.executeQuery(prCcSql.format());
												
					// Loop through results of PR Cc List Query from DB if there are any
					if(prCcRSet != null) {
						
						while(prCcRSet.next()) {
							
							if( prCcRSet.getString(1).length() > 0 ) {
								
								// Skip if already in list to avoid duplicates
								if ( ccList.contains(prCcRSet.getString(1)) ) {
									cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping for PR:"+id+" ["+prCcRSet.getString(1)+"], already in list..");
								} else {
									cronLogger.debug(LOG_IDF + MTD_IDF +"Adding for PR:"+id+" ["+prCcRSet.getString(1)+":"+prCcRSet.getString(2)+"]");
									ccList += prCcRSet.getString(1) + ",";
								}
								
							} else {
								cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: Empty/Null Person Id for PRs Cc List !!!");
							}
							
						}
						
						cronLogger.info(LOG_IDF + MTD_IDF +"Current Cc List for PRs: [" + ccList + "]" );
						
					} else {
						cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: No Person Ids for PRs Cc list!!!" );
					}
					
					if( toList.contains(imsTo) ) {
						ccList += imsCc;
						cronLogger.info(LOG_IDF + MTD_IDF +"Added IMS CC list, current Cc: List for PRs: [" + ccList + "]" );
					}
					
				} else {
					cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: No Person Ids for PRs To list!!!" );
				}
				
				// Send Email for PRs
				if( toList.length() > 0 ) {
										
					// Prepare PR WO Info Query
					query = woPrQuery.replaceFirst(":id", id);
					woPrSql=new SqlFormat(query);
					cronLogger.debug(LOG_IDF + MTD_IDF +"Run PR WO Info SQL: " + query);
					woPrRSet = dbShortcut.executeQuery(woPrSql.format());
												
					// Loop through results of PR WO Info Query from DB if there are any
					if(woPrRSet != null) {
						
						while(woPrRSet.next()) {
							currentLine += "WO#" + woPrRSet.getString(1) + ": " + woPrRSet.getString(2) + "<br/>";
						}
						
					} else {
						cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: No WO(s) found for PR: "+id+"!!!" );
					}
					
					if(currentLine.length() > 0 ) currentLine = "The following WOs might be affected: <br/><br/>" + currentLine;
					
					cronLogger.info(LOG_IDF + MTD_IDF +"WO List: " + currentLine );
					
					subj = emailSubj.replaceAll( "#ID", (TYPE_PR+"# "+id) );
					body = emailBody.replaceAll( "#ID", (TYPE_PR+"# "+id) ).replaceAll("#WOLIST", currentLine);
					
					emailUsers(toList, ccList, bccList, replyTo, subj, body, abspath);
					
				} else {
					cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: No To List to send emails to for PR: "+id+"!!!" );
				}
								
			} // End for loop send PRs emails
			
			// -------------------------------------- Prep and send email for Outbound Report POs -------------------------------------- //
			
			parts = poList.split(DELIM);
			cronLogger.info(LOG_IDF + MTD_IDF +"No. of POs: " + parts.length);
			
			// Loop through PO
			for(int i=0; i < parts.length; i++) {
				
				id = parts[i];
				cronLogger.info(LOG_IDF + MTD_IDF +"Processing PO: " + id);
				
				emailAddr = "";
				toList = "";
				ccList = "";
				currentLine = ""; // Re-use variable for printing output in Email body
				
				// Prepare PO To List Query
				query = poToQuery.replaceFirst(":id", id);
				poToSql=new SqlFormat(query);
				cronLogger.debug(LOG_IDF + MTD_IDF +"Run PR To List SQL: " + query);
				poToRSet = dbShortcut.executeQuery(poToSql.format());
											
				// Loop through results of PO To List Query from DB if there are any
				if(poToRSet != null) {
					
					while(poToRSet.next()) {
						
						emailAddr = poToRSet.getString(1);
						
						// Replace MAXADMIN with IMS To List
						if( poToRSet.getString(2).equalsIgnoreCase("MAXADMIN") ) {
							emailAddr = imsTo;
							cronLogger.info(LOG_IDF + MTD_IDF +"Replaced To Email address with IMS TO List: " + emailAddr);
						}
						
						if( emailAddr.length() > 0 ) {						
							
							// Skip if already in list to avoid duplicates
							if ( toList.contains(emailAddr) ) {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping for PO:"+id+" ["+emailAddr+"], already in list..");
							} else {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Adding for PO:"+id+" ["+emailAddr+":"+poToRSet.getString(2)+"]");
								toList += emailAddr + ",";
							}
							
						} else {
							cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: Empty/Null Person Id for POs To List !!!");
						}
						
					}
					
					cronLogger.info(LOG_IDF + MTD_IDF +"Current To List for POs: [" + toList + "]" );
					
					// Prepare PO Cc List Query
					query = poCcQuery.replaceFirst(":id", id);
					poCcSql=new SqlFormat(query);
					cronLogger.debug(LOG_IDF + MTD_IDF +"Run Cc List PO SQL: " + query);
					poCcRSet = dbShortcut.executeQuery(poCcSql.format());
												
					// Loop through results of PO Cc List Query from DB if there are any
					if(poCcRSet != null) {
						
						while(poCcRSet.next()) {
							
							if( poCcRSet.getString(1).length() > 0 ) {
								
								// Skip if already in list to avoid duplicates
								if ( ccList.contains(poCcRSet.getString(1)) ) {
									cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping for PO:"+id+" ["+poCcRSet.getString(1)+"], already in list..");
								} else {
									cronLogger.debug(LOG_IDF + MTD_IDF +"Adding for PO:"+id+" ["+poCcRSet.getString(1)+":"+poCcRSet.getString(2)+"]");
									ccList += poCcRSet.getString(1) + ",";
								}
																
							} else {
								cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: Empty/Null Person Id for POs Cc List !!!");
							}
							
						}
						
						cronLogger.info(LOG_IDF + MTD_IDF +"Current Cc List for POs: [" + ccList + "]" );
						
					} else {
						cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: No Person Ids for POs Cc list!!!" );
					}
					
					if( toList.contains(imsTo) ) {
						ccList += imsCc;
						cronLogger.info(LOG_IDF + MTD_IDF +"Added IMS CC list, current Cc: List for POs: [" + ccList + "]" );
					}
					
				} else {
					cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: No Person Ids for POs To list!!!" );
				}
				
				// Send Email for POs
				if( toList.length() > 0 ) {
										
					// Prepare PO WO Info Query
					query = woPoQuery.replaceFirst(":id", id);
					woPoSql=new SqlFormat(query);
					cronLogger.debug(LOG_IDF + MTD_IDF +"Run PO WO Info SQL: " + query);
					woPoRSet = dbShortcut.executeQuery(woPoSql.format());
												
					// Loop through results of PO WO Info Query from DB if there are any
					if(woPoRSet != null) {
						
						while(woPoRSet.next()) {
							currentLine += "WO#" + woPoRSet.getString(1) + ": " + woPoRSet.getString(2) + "<br/>";
						}
						
					} else {
						cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: No WO(s) found for PO: "+id+"!!!" );
					}
					
					if(currentLine.length() > 0 ) currentLine = "The following WOs might be affected: <br/><br/>" + currentLine;
					
					cronLogger.info(LOG_IDF + MTD_IDF +"WO List: " + currentLine );
					
					subj = emailSubj.replaceAll( "#ID", (TYPE_PO+"# "+id) );
					body = emailBody.replaceAll( "#ID", (TYPE_PO+"# "+id) ).replaceAll("#WOLIST", currentLine);
										
					emailUsers(toList, ccList, bccList, replyTo, subj, body, abspath);
					
				} else {
					cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: No To List to send emails to for PO: "+id+"!!!" );
				}
				
			} // End for loop send PO emails
			
			// -------------------------------------- Prep and send email for Outbound Report RECEIPTs -------------------------------------- //
			
			parts = rcptList.split(DELIM);
			cronLogger.info(LOG_IDF + MTD_IDF +"No. of Rcpt-POs: " + parts.length);
			
			// Loop through Rcpt-PO
			for(int i=0; i < parts.length; i++) {
				
				id = parts[i];
				cronLogger.info(LOG_IDF + MTD_IDF +"Processing Rcpt-PO: " + id);
				
				emailAddr = "";
				toList = "";
				ccList = "";
				currentLine = ""; // Re-use variable for printing output in Email body
				
				// Prepare Rcpt-PO To List Query
				query = rcptToQuery.replaceFirst(":id", id);
				rcptToSql=new SqlFormat(query);
				cronLogger.debug(LOG_IDF + MTD_IDF +"Run Rcpt-PO To List SQL: " + query);
				rcptToRSet = dbShortcut.executeQuery(rcptToSql.format());
											
				// Loop through results of Receipt-PO To List Query from DB if there are any
				if(rcptToRSet != null) {
					
					while(rcptToRSet.next()) {
						
						emailAddr = rcptToRSet.getString(1);
						
						// Replace MAXADMIN with IMS To List
						if( rcptToRSet.getString(2).equalsIgnoreCase("MAXADMIN") ) {
							emailAddr = imsTo;
							cronLogger.info(LOG_IDF + MTD_IDF +"Replaced To Email address with IMS TO List: " + emailAddr);
						}
						
						// Skip if already in list to avoid duplicates
						if ( toList.contains(emailAddr) ) {
							cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping for Rcpt-PO:"+id+" ["+emailAddr+"], already in list..");
						} else {
							cronLogger.debug(LOG_IDF + MTD_IDF +"Adding for Rcpt-PO:"+id+" ["+emailAddr+":"+rcptToRSet.getString(2)+"]");
							toList += emailAddr + ",";
						}
						
					}
					
					cronLogger.info(LOG_IDF + MTD_IDF +"Current To List for Rcpt-POs: [" + toList + "]" );
					
					// Prepare Receipt-PO Cc List Query
					query = rcptCcQuery.replaceFirst(":id", id);
					rcptCcSql=new SqlFormat(query);
					cronLogger.debug(LOG_IDF + MTD_IDF +"Run Cc List Rcpt-PO SQL: " + query);
					rcptCcRSet = dbShortcut.executeQuery(rcptCcSql.format());
												
					// Loop through results of PO Cc List Query from DB if there are any
					if(rcptCcRSet != null) {
						
						while(rcptCcRSet.next()) {
							
							// Skip if already in list to avoid duplicates
							if ( ccList.contains(rcptCcRSet.getString(1)) ) {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping for Rcpt-PO:"+id+" ["+rcptCcRSet.getString(1)+"], already in list..");
							} else {
								cronLogger.debug(LOG_IDF + MTD_IDF +"Adding for Rcpt-PO:"+id+" ["+rcptCcRSet.getString(1)+":"+rcptCcRSet.getString(2)+"]");
								ccList += rcptCcRSet.getString(1) + ",";
							}
							
						}
						
						cronLogger.info(LOG_IDF + MTD_IDF +"Current Cc List for Rcpt-POs: [" + ccList + "]" );
						
					} else {
						cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: No Person Ids for Rcpt-POs Cc list!!!" );
					}
					
					if( toList.contains(imsTo) ) {
						ccList += imsCc;
						cronLogger.info(LOG_IDF + MTD_IDF +"Added IMS CC list, current Cc List for Rcpt-POs: [" + ccList + "]" );
					}
					
				} else {
					cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: No Person Ids for Rcpt-POs To list!!!" );
				}
				
				// Send Email for Rcpt-POs
				if( toList.length() > 0 ) {
					
					// Prepare Rcpt-PO WO Info Query
					query = woPoQuery.replaceFirst(":id", id);
					woPoSql=new SqlFormat(query);
					cronLogger.debug(LOG_IDF + MTD_IDF +"Run Rcpt-PO WO Info SQL: " + query);
					woPoRSet = dbShortcut.executeQuery(woPoSql.format());
												
					// Loop through results of Rcpt-PO WO Info Query from DB if there are any
					if(woPoRSet != null) {
						
						while(woPoRSet.next()) {
							currentLine += "WO#" + woPoRSet.getString(1) + ": " + woPoRSet.getString(2) + "<br/>";
						}
						
					} else {
						cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: No WO(s) found for Rcpt-PO: "+id+"!!!" );
					}
					
					if(currentLine.length() > 0 ) currentLine = "The following WOs might be affected: <br/><br/>" + currentLine;
					
					cronLogger.info(LOG_IDF + MTD_IDF +"WO List: " + currentLine );
					
					subj = emailSubj.replaceAll( "#ID", ("Receipt("+TYPE_PO+")# "+id) );
					body = emailBody.replaceAll( "#ID", ("Receipt("+TYPE_PO+")# "+id) ).replaceAll("#WOLIST", currentLine);
					
					emailUsers(toList, ccList, bccList, replyTo, subj, body, abspath);
					
				} else {
					cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: No To List to send emails to for Rcpt-PO: "+id+"!!!" );
				}
				
			} // End for loop send Rcpt-PO emails
						
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"FileNotFoundException: " + e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"IOException: " + e.getMessage());
		} catch (MXApplicationException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MXApplicationException: " + e.getMessage());
		} catch (SQLException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"SQLException: " + e.getMessage());
		} catch (MXException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MXException: " + e.getMessage());
		} finally {
			
			try {

				prToRSet.close(); prToRSet=null;
				prCcRSet.close(); prCcRSet=null;
				poToRSet.close(); poToRSet=null;
				poCcRSet.close(); poCcRSet=null;
				rcptToRSet.close(); rcptToRSet=null;
				rcptCcRSet.close(); rcptCcRSet=null;
				woPrRSet.close(); woPrRSet=null;
				woPoRSet.close(); woPoRSet=null;
				
				prToSql= null; prCcSql= null;
				poToSql= null; poCcSql= null;
				rcptToSql= null; rcptCcSql= null;
				woPrSql= null; woPoSql= null;
				
				prToQuery = null; prCcQuery = null;
				poToQuery = null; poCcQuery = null;
				rcptToQuery = null; rcptCcQuery = null;
				woPrQuery = null; woPoQuery = null;
				
				query = null;
				
				dbShortcut.close();
				dbShortcut = null;
				
				bufReader.close();
				bufReader = null;
				
				fileReader.close();
				fileReader = null;
				
				currentLine = null;
				
				id = null;
				parts = null;

				subj = null;
				body = null;
				toList = null;
				ccList = null;
				bccList = null;
				emailSubj = null;
				emailBody = null;
				replyTo = null;
				tempRemote= null;
				commTemplateSet= null;
				
			} catch (IOException e) {
				
				e.printStackTrace();
				cronLogger.error(LOG_IDF + MTD_IDF +"IOException: " + e.getMessage());
				
			} catch (Exception e) {
				
				e.printStackTrace();
				cronLogger.error(LOG_IDF + MTD_IDF +"Exception: " + e.getMessage());
				
			}
			
		}
		
		cronLogger.info(LOG_IDF + MTD_IDF +"OUTBOUND Report processing completed.");
		
	} // End processOutboundRpt()
	
	/**
	 * Process report for INBOUND transactions to GFS (po report file for attaching to email, PR info file for who to send emails to)
	 * 
	 * @param abspath String representing absolute path to the gz report file
	 * @throws MessagingException
	 */
	private void processInboundRpt(String abspath) throws IOException {
		
		final String MTD_IDF = "processInboundRpt(): ";
		
		cronLogger.info(LOG_IDF + MTD_IDF +"Processing INBOUND Report... ");
		
		String DELIM = ","; // Default to comma
		String PAIR_SEP = ";"; // For splitting string into PR-PO Pairs
		String currentLine = null;
		
		String pair = null;
		String pairList = "";
		String[] parts = null;
		String[] prPoPair = null;
		String emailAddr = null;
		
		String subj = null;
		String body = null;
		String toList = null;
		String ccList = null;
		String bccList = null;
		String emailSubj = null;
		String emailBody = null;
		String replyTo = null;
		CommTemplateRemote tempRemote= null;
		CommTemplateSetRemote commTemplateSet= null;
		
		DBShortcut dbShortcut = new DBShortcut();
		SqlFormat prToSql= null;
		SqlFormat prCcSql= null;
		SqlFormat woPrSql= null;
		
		String query = "";		
		String prToQuery = "SELECT DISTINCT emailaddress,personid FROM email WHERE personid IN ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE prnum =':id' )";
		String prCcQuery = "SELECT DISTINCT emailaddress, personid FROM email WHERE personid IN (SELECT respparty FROM persongroupteam WHERE persongroup  IN ( SELECT sectionhead FROM person WHERE personid IN ( SELECT Nvl((SELECT supervisor FROM workorder WHERE workorder.wonum=prline.refwo),requestedby) personid FROM prline WHERE prnum=':id' ) ) )";
		String woPrQuery = "SELECT distinct wonum, supervisor FROM workorder WHERE wonum IN (SELECT refwo FROM prline WHERE prnum=':id') ORDER BY wonum, supervisor";
		
		ResultSet prToRSet=null;
		ResultSet prCcRSet=null;
		ResultSet woPrRSet=null;
		
		FileReader fileReader = null;
		BufferedReader bufReader = null;
				
		try {
			
			fileReader = new FileReader( filePathInbound + prInfoFile );
			bufReader = new BufferedReader(fileReader);
			
/*			// Sample Data for reference
			M780540,2,393322-121,3,13-Feb-2018 17:00,13-Feb-2018 17:00
			M780540,1,393322-121,16,13-Feb-2018 17:00,13-Feb-2018 17:00
			M780909,1,400855-137,9,13-Feb-2018 10:45,13-Feb-2018 10:45
*/
			// Read through PR info file to get unique PR-PO pairs
			while( (currentLine=bufReader.readLine()) != null ) {
				
				if(currentLine.length() != 0) {
					
					cronLogger.debug(LOG_IDF + MTD_IDF +"RL>> " + currentLine);
					
					parts=currentLine.split(DELIM);
						
					if( parts.length == 6 ) {
						
						// Assemble pair
						pair = parts[0].trim() + DELIM + parts[2].trim();
						
						// Skip if already exist in idList to avoid duplicates, otherwise send email for it
						if ( pairList.contains(pair) ) {
							cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping PR-PO pair["+pair+"], already in list..");
						} else {
							
							cronLogger.debug(LOG_IDF + MTD_IDF +"Adding PR-PO pair["+pair+"]");
							pairList += pair + PAIR_SEP;
							
						}
					
					} else {
						cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: Could NOT split line using delimiter: \"" + DELIM + "\"");
					}
					
				} // End if current line is NOT empty 
				
			} // End while (read lines)
			
			cronLogger.info(LOG_IDF + MTD_IDF +"Done processing file, Before processing PR-PO Pairs: [" + pairList + "]");
						
			// -------------------------------------------- Prep and send email for Inbound Report -------------------------------------------- //
			
	    	// Get relevant comm template 
	    	commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
			commTemplateSet.setWhere("TEMPLATEID='"+commTmpl+"'");
			commTemplateSet.reset();
			tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);
			
			cronLogger.info(LOG_IDF + MTD_IDF +"Using CommTemplate for emails to users: " + commTmpl);
			
			//String toMail=tempRemote.getString("TOLIST");
			//String ccTo=tempRemote.getString("CCLIST");
			//String fromMail=tempRemote.getString("SENDFROM");
			bccList=tempRemote.getString("BCCLIST");
			emailSubj=tempRemote.getString("SUBJECT");
			emailBody=tempRemote.getString("MESSAGE");
			replyTo=tempRemote.getString("REPLYTO");
			
			dbShortcut.connect(getRunasUserInfo().getConnectionKey()); // Establish connection to DB
			
			// Split pairList into pairs
			parts = pairList.split(PAIR_SEP);
			
			// Loop through each PR-PO pair
			for(int i=0; i < parts.length; i++) {
				
				prPoPair = parts[i].split(DELIM);
				
				// Prep Recipient List and send email only if PR-PO pair is complete
				if(prPoPair.length == 2) {
					
					//use PR to prep Recipients list (because PO NOT in Mx yet cannot determine recipients using it)
					cronLogger.info(LOG_IDF + MTD_IDF +"Processing PR: " + prPoPair[0]);
					
					emailAddr = "";
					toList = "";
					ccList = "";
					currentLine = ""; // Re-use variable for printing output in Email body
					
					// Prepare PR(Inbound POs) To List Query
					query = prToQuery.replaceFirst(":id", prPoPair[0]);
					prToSql=new SqlFormat(query);
					cronLogger.debug(LOG_IDF + MTD_IDF +"Run PR(Inbound POs) To: List SQL: " + query);
					prToRSet = dbShortcut.executeQuery(prToSql.format());
					
					// Loop through results of PR(Inbound POs) To List Query from DB if there are any
					if(prToRSet != null) {
						
						while(prToRSet.next()) {
							
							emailAddr = prToRSet.getString(1);
							
							// Replace MAXADMIN with IMS To List
							if( prToRSet.getString(2).equalsIgnoreCase("MAXADMIN") ) {
								emailAddr = imsTo;
								cronLogger.info(LOG_IDF + MTD_IDF +"Replaced To Email address with IMS TO List: " + emailAddr);
							}
							
							if( emailAddr.length() > 0 ) {	
								
								// Skip if already in list to avoid duplicates using Person Id
								if ( toList.contains(emailAddr) ) {
									cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping for PR:"+prPoPair[0]+" PO:"+prPoPair[1]+" ["+emailAddr+"], already in list..");
								} else {
									cronLogger.debug(LOG_IDF + MTD_IDF +"Adding for PR:"+prPoPair[0]+" PO:"+prPoPair[1]+" ["+emailAddr+":"+prToRSet.getString(2)+"]");
									toList += emailAddr + ",";
								}
								
							} else {
								cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: Empty/Null Person Id for Inbound POs To: List !!!");
							}
							
						}
						
						cronLogger.info(LOG_IDF + MTD_IDF +"Current To: List for Inbound POs: [" + toList + "]" );
						
						// Prepare PR(Inbound POs) Cc List Query
						query = prCcQuery.replaceFirst(":id", prPoPair[0]);
						prCcSql=new SqlFormat(query);
						cronLogger.debug(LOG_IDF + MTD_IDF +"Run Cc: List PR(Inbound POs) SQL: " + query);
						prCcRSet = dbShortcut.executeQuery(prCcSql.format());
													
						// Loop through results of PR Cc List Query from DB if there are any
						if(prCcRSet != null) {
							
							while(prCcRSet.next()) {
								
								if( prCcRSet.getString(1).length() > 0 ) {
									
									// Skip if already in list to avoid duplicates
									if ( ccList.contains(prCcRSet.getString(1)) ) {
										cronLogger.debug(LOG_IDF + MTD_IDF +"Skipping for pair PR:"+prPoPair[0]+" PO:"+prPoPair[1]+" ["+prCcRSet.getString(1)+"], already in list..");
									} else {
										cronLogger.debug(LOG_IDF + MTD_IDF +"Adding for pair PR:"+prPoPair[0]+" PO:"+prPoPair[1]+" ["+prCcRSet.getString(1)+":"+prCcRSet.getString(2)+"]");
										ccList += prCcRSet.getString(1) + ",";
									}
									
								} else {
									cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: Empty/Null Person Id for Inbound POs Cc: List !!!");
								}
								
							}
							
							cronLogger.info(LOG_IDF + MTD_IDF +"Current Cc: List for Inbound POs: [" + ccList + "]" );
							
						} else {
							cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: No Person Ids for Inbound POs Cc: list!!!" );
						}
						
						if( toList.contains(imsTo) ) {
							ccList += imsCc;
							cronLogger.info(LOG_IDF + MTD_IDF +"Added IMS CC list, current Cc: List for Inbound POs: [" + ccList + "]" );
						}
						
					} else {
						cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: No Person Ids for Inbound POs To: list!!!" );
					}
					
					// Send Email for Inbound POs based on corresponding PRs
					if( toList.length() > 0 ) {
											
						// Prepare PR (Inbound POs) WO Info Query
						query = woPrQuery.replaceFirst(":id", prPoPair[0]);
						woPrSql=new SqlFormat(query);
						cronLogger.debug(LOG_IDF + MTD_IDF +"Run PR (Inbound POs) WO Info SQL: " + query);
						woPrRSet = dbShortcut.executeQuery(woPrSql.format());
													
						// Loop through results of PR (Inbound POs) WO Info Query from DB if there are any
						if(woPrRSet != null) {
							
							while(woPrRSet.next()) {
								currentLine += "WO#" + woPrRSet.getString(1) + ": " + woPrRSet.getString(2) + "<br/>";
							}
							
						} else {
							cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: No WO(s) found for PR (Inbound POs): "+prPoPair[0]+"!!!" );
						}
						
						//TODO Add in Message Reprocessing messages here
/*						MaxIntErrorMsgSet errorSet= (MaxIntErrorMsgSet) MXServer.getMXServer().getMboSet("MAXINTERRORMSG", MXServer.getMXServer().getUserInfo("MAXADMIN"));
						errorSet.setWhere("messageid IN (SELECT messageid FROM MAXINTERROR WHERE extsysname ='OA12' AND ifacename LIKE 'MXPO%' AND changedate >= To_Date('20190301','yyyymmdd'))");
						
						cronLogger.debug(LOG_IDF + MTD_IDF +"Error Count: " + errorSet.count());
						
						String datastr = null;
						byte[] data = null;
						
						for(int j=0;j<errorSet.count();j++) {
							
							cronLogger.debug(LOG_IDF + MTD_IDF +"Reading Mbo("+j+")...");
							
							MaxIntErrorMsg error = (MaxIntErrorMsg) errorSet.getMbo(j);
							
							cronLogger.debug(LOG_IDF + MTD_IDF +"Message Id: " +  error.getString("MSGID"));
							
						}						
*/						
						if(currentLine.length() > 0 ) currentLine = "The following WOs might be affected: <br/><br/>" + currentLine;
						
						cronLogger.info(LOG_IDF + MTD_IDF +"WO List: " + currentLine );
						
						subj = emailSubj.replaceAll( "#ID", (TYPE_PO+"# "+prPoPair[1] + " ("+TYPE_PR+"# "+prPoPair[0]+")") );
						body = emailBody.replaceAll( "#ID", (TYPE_PO+"# "+prPoPair[1] + " ("+TYPE_PR+"# "+prPoPair[0]+")") ).replaceAll("#WOLIST", currentLine);
						
						emailUsers(toList, ccList, bccList, replyTo, subj, body, abspath);
						
					} else {
						cronLogger.error(LOG_IDF + MTD_IDF +"ERROR: No To: List to send emails to for pair PR:"+prPoPair[0]+" PO:"+prPoPair[1]+"!!!" );
					}					
										
				} else {
					cronLogger.warn(LOG_IDF + MTD_IDF +"WARNING: Incomplete PR-PO pair, size: "+prPoPair.length+"!!!");
				}
				
			} // for loop for PR-PO pairs		
						
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"FileNotFoundException: " + e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"IOException: " + e.getMessage());
		} catch (SQLException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"SQLException: " + e.getMessage());
		} catch (MXException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MXException: " + e.getMessage());
		} finally {
			
			try {

				subj = null;
				body = null;
				toList = null;
				ccList = null;
				bccList = null;
				emailSubj = null;
				emailBody = null;
				replyTo = null;
				tempRemote= null;
				commTemplateSet= null;
				
				prToSql= null;
				prCcSql= null;
				woPrSql= null;
				
				query = null;
				prToQuery = null;
				prCcQuery = null;
				woPrQuery = null;
				
				prToRSet.close(); prToRSet=null;
				prCcRSet.close(); prCcRSet=null;
				woPrRSet.close(); woPrRSet=null;
				
				dbShortcut.close();
				dbShortcut = null;
				
				bufReader.close();
				bufReader = null;
				
				fileReader.close();
				fileReader = null;
				
				currentLine = null;
				pairList = null;				
				pair = null;
				
				parts = null;
				prPoPair = null;
								
			} catch (IOException e) {
				
				e.printStackTrace();
				cronLogger.error(LOG_IDF + MTD_IDF +"IOException: " + e.getMessage());
				
			} catch (Exception e) {
				
				e.printStackTrace();
				cronLogger.error(LOG_IDF + MTD_IDF +"Exception: " + e.getMessage());
				
			}
		}
		
		cronLogger.info(LOG_IDF + MTD_IDF +"INBOUND Report processing completed.");
		
	} // End processInboundRpt()
	
} // End Class GFSInterfaceErrorAlertCron
