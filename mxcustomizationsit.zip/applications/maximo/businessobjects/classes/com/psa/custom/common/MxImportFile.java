package com.psa.custom.common;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class MxImportFile {

	// Constant
	private final static String YYYYMM = "YYYYMM";
	private final static String YYYYPM = "YYYYPM"; //Previous Month
	private final static String YYYYMMDD = "YYYYMMDD";
// START CHANGE
	
	private final static String YYYYMMPD = "YYYYMMPD";
	private static final String YYYYMMPD_Format = "yyyyMMdd";
	
// END CHANGE
	
	private final static String dotText = ".txt";
	
	private static final String YYYYMM_Format = "yyyyMM";    
	private static final String YYYYPM_Format = "yyyyMM";  
	private static final String YYYYMMDD_Format = "yyyyMMdd";
	
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	
	// Variable
	private String fileType = null;	
	//private MxDebug debug = null;
	
	
	/*
	 * Author: BTE
	 * Date: 02 MAR 2006
	 * Comment: Constructor
	 */
	public MxImportFile() {
		//debug = new MxDebug();
		//debug.setDebug(true);
		
	}
	
	
	/*
	 * Author: BTE
	 * Date: 02 MAR 2006
	 * Comment: Setter fileType
	 */
	public void setFileType(String type) {		
		//debug.msg("MxImportFile.setFileType");
		integrationLogger.debug("MxImportFile.setFileType:"+type);
		fileType = type;
	}
	
	
	/*
	 * Author: BTE
	 * Date: 02 MAR 2006
	 * Comment: Getter fileType
	 */
	public String getFileType() {		
		//debug.msg("MxImportFile.getFileType");
		
		return fileType;
	}
	
	
	/*
	 * Author: BTE
	 * Date: 02 MAR 2006
	 * Comment: Find file type 
	 */
	public boolean findFileType(File file) {
		//debug.msg("MxImportFile.findFileType");		
		
		if (fileType.equalsIgnoreCase(dotText)) {
			//debug.msg("MxImportFile.findFileType.dotText");			
			integrationLogger.debug("MxImportFile.findFileType: dotText");
			if (file.isFile() && file.getName().toLowerCase().endsWith(getFileType())) {
				return true;
			}			
			return false;
			
		} if (fileType.equalsIgnoreCase(YYYYPM)) {
			//Previous Month
			//debug.msg("MxImportFile.findFileType.YYYYPM");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYPM_Format);
			
			//Get previous month
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH,-1);
						
			String toMonth = timeStampFormat.format(cal.getTime());
						
			//debug.msg(toMonth);
			integrationLogger.debug("MxImportFile.findFileType: YYYYPM, "+toMonth);
			
			if (file.isFile() && contains(file.getName(), toMonth)) {
				return true;
			}
			return false;
			
		}  if (fileType.equalsIgnoreCase(YYYYMM)) {
			//debug.msg("MxImportFile.findFileType.YYYYMM");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMM_Format);
			String toMonth = timeStampFormat.format(new Date());
						
			//debug.msg(toMonth);
			integrationLogger.debug("MxImportFile.findFileType: YYYYMM, "+toMonth);
			
			if (file.isFile() && contains(file.getName(), toMonth)) {
				return true;
			}
			return false;
			
		}
		
 // START CHANGE
		
		if (fileType.equalsIgnoreCase(YYYYMMPD)) {
			//debug.msg("MxImportFile.findFileType.YYYYMMDD");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMMDD_Format);
			
			//Get previous DAY
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE,-1);
						
			String toDay = timeStampFormat.format(cal.getTime());
			
			//debug.msg(toDay);
			integrationLogger.debug("MxImportFile.findFileType: YYYYMMDD, "+toDay);
			
			if (file.isFile() && contains(file.getName(), toDay)) {
				return true;
			}
			return false;
			
		}
		
 // END CHANGE		
		
		if (fileType.equalsIgnoreCase(YYYYMMDD)) {
			//debug.msg("MxImportFile.findFileType.YYYYMMDD");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMMDD_Format);
			String toDay = timeStampFormat.format(new Date());
			
			//debug.msg(toDay);
			integrationLogger.debug("MxImportFile.findFileType: YYYYMMDD, "+toDay);
			
			if (file.isFile() && contains(file.getName(), toDay)) {
				return true;
			}
			return false;
			
		} else {
			//debug.msg("MxImportFile.findFileType.Exact");
			integrationLogger.debug("MxImportFile.findFileType: Exact, "+file.getName());
			
			if (file.isFile() && file.getName().equalsIgnoreCase(getFileType())) {				
				return true;
			}
		}
							
		return false;
	}
	
	
	/*
	 * Author: BTE
	 * Date: 03 MAR 2006
	 * Comment: Search for substring in string
	 */
	public boolean contains (String fileName, String pattern) {
		//debug.msg("MxImportFile.contains");
		
		int i = 0;
		int patternLen = pattern.length();
		int fileNameLen = fileName.length();
		
		if (fileNameLen < patternLen) {
			return false;
		}
		
		while ( i <= (fileNameLen - patternLen) ) {
		
			if (fileName.toLowerCase().startsWith(pattern, i)) {
				return true;
			}
			
			i++;
		}		
		
		return false;		
	}	
	
	
	/*
	 * Author: BTE
	 * Date: 03 MAR 2006
	 * Comment: Check cron task date if need to get new file (SCP).
	 */
	public boolean getNewFile (Date date) {
		//debug.msg("MxImportFile.getNewFile");				
		
		if (date == null) return true;
	
	// START CHANGE
		
		if (fileType.equalsIgnoreCase(YYYYMMPD)) {
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMMPD_Format);
			String toDay = timeStampFormat.format(date);
			
			//Get previous month
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE,-1);
			String currentDate = timeStampFormat.format(cal.getTime());
									
			if (currentDate.equalsIgnoreCase(toDay)) return false;			
			
		}
		
	// END CHANGE	
		
		if (fileType.equalsIgnoreCase(YYYYPM)) {
			//debug.msg("MxImportFile.getNewFile.YYYYPM");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYPM_Format);
			String toMonth = timeStampFormat.format(date);
			
			//Get previous month
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH,-1);
			String currentDate = timeStampFormat.format(cal.getTime());
									
			if (currentDate.equalsIgnoreCase(toMonth)) return false;			
			
		} if (fileType.equalsIgnoreCase(YYYYMM)) {
			//debug.msg("MxImportFile.getNewFile.YYYYMM");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMM_Format);
			String toMonth = timeStampFormat.format(date);
			
			String currentDate = timeStampFormat.format(new Date());
									
			if (currentDate.equalsIgnoreCase(toMonth)) return false;			
			
		} if (fileType.equalsIgnoreCase(YYYYMMDD)) {
			//debug.msg("MxImportFile.getNewFile.YYYYMMDD");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMMDD_Format);
			String toDay = timeStampFormat.format(date);
			
			String currentDate = timeStampFormat.format(new Date());
				
			if (currentDate.equalsIgnoreCase(toDay)) return false;								
		}			

		return true;		
	}		
		

	/* Author: BTE
	 * Date: 06 MAR 2006
	 * Comment: Get the file name
	 */
	public String getFileName() {
		//debug.msg("MxImportFile.getFileName");
		//debug.msg(getFileType());
	
		if (getFileType().equalsIgnoreCase(YYYYMM)) {
			//debug.msg("MxImportFile.getFileName.YYYYMM");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMM_Format);
			String toMonth = timeStampFormat.format(new Date());
			
			//debug.msg(toMonth);
			
			return toMonth;
	
		}if (getFileType().equalsIgnoreCase(YYYYPM)) {
			//debug.msg("MxImportFile.getFileName.YYYYPM");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYPM_Format);
			
			//Get previous month
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH,-1);
			String toMonth = timeStampFormat.format(cal.getTime());
			
			//debug.msg(toMonth);
			
			return toMonth;
	
		} if (getFileType().equalsIgnoreCase(YYYYMMDD)) {
			//debug.msg("MxImportFile.getFileName.YYYYMMDD");
			
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMMDD_Format);
			String toDay = timeStampFormat.format(new Date());
			
			//debug.msg(toDay);
			
			return toDay;
		}
		
	// START CUSTOM
		
		if (getFileType().equalsIgnoreCase(YYYYMMPD)) {
						
			DateFormat timeStampFormat = new SimpleDateFormat(YYYYMMPD_Format);
			
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE,-1);
						
			String toDay = timeStampFormat.format(cal.getTime());
			//debug.msg(toDay);
			
			return toDay;
		}	
		
	//END CUSTOM
		
		
		return getFileType();
	}	
	
	
	/* Author: BTE
	 * Date: 06 MAR 2006
	 * Comment: Get the YYYYMM
	 */
	public String getYYYYMM() {
		//debug.msg("MxImportFile.getYYYYMM");
		
		return YYYYMM;
	}
	
	/* Author: HCHA
	 * Date: 06 JUN 2006
	 * Comment: Get the YYYYPM
	 */
	public String getYYYYPM() {
		//debug.msg("MxImportFile.getYYYYPM");
		
		return YYYYPM;
	}
	
	
	/* Author: BTE
	 * Date: 06 MAR 2006
	 * Comment: Get the YYYYMMDD
	 */
	public String getYYYYMMDD() {
		//debug.msg("MxImportFile.getYYYYMMDD");		
		
		return YYYYMMDD;
	}
	
	
// START CHANGE
	
	/* Author: BTE
	 * Date: 13 JULY 2009
	 * Comment: Get the YYYYMMPD
	 */
	public String getYYYYMMPD() {
		
		return YYYYMMPD;
	}
	
	/* Author: BTE
	 * Date: 13 JULY 2009
	 * Comment: Get the YYYYMMPD format
	 */
	public String getYYYYMMPDFormat() {
		//debug.msg("MxImportFile.getYYYYMMDDFormat");
		
		return YYYYMMPD_Format;
	}
	
	
// END CHANGE	
	
	
	/* Author: BTE
	 * Date: 06 MAR 2006
	 * Comment: Get the YYYYMM format
	 */
	public String getYYYYMMFormat() {
		//debug.msg("MxImportFile.getYYYYMMFormat");
		
		return YYYYMM_Format;
	}
	
	/* Author: HCHA
	 * Date: 06 JUN 2006
	 * Comment: Get the YYYYPM format
	 */
	public String getYYYYPMFormat() {
		//debug.msg("MxImportFile.getYYYYPMFormat");
		
		return YYYYPM_Format;
	}
	
	/* Author: BTE
	 * Date: 06 MAR 2006
	 * Comment: Get the YYYYMMDD format
	 */
	public String getYYYYMMDDFormat() {
		//debug.msg("MxImportFile.getYYYYMMDDFormat");
		
		return YYYYMMDD_Format;
	}
}
