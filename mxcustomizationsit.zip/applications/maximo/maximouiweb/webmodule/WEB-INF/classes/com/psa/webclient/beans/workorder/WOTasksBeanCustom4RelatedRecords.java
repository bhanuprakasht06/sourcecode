package com.psa.webclient.beans.workorder;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.webclient.beans.workorder.WOTasksBean;


public class WOTasksBeanCustom4RelatedRecords extends WOTasksBean {
	
	 public WOTasksBeanCustom4RelatedRecords()
	    {
		 System.out.println("Inside WOTasksBeanCustom4RelatedRecords taskpend start");
	    }
	 
	  private int markAll(MboSetRemote mbosetremote, String s, boolean flag)
     throws MXException, RemoteException
 {
		  
     String s1 = s;
     System.out.println("Inside WOTasksBeanCustom4RelatedRecords markAll start");
     MboRemote mboremote;
    
     for(int i = 0; (mboremote = mbosetremote.getMbo(i)) != null; i++)
     {
    	 System.out.println("Inside WOTasksBeanCustom4RelatedRecords for loop");
         if(flag && mboremote.getBoolean(s1) || !flag && !mboremote.getBoolean(s1))
             continue;
         System.out.println("Inside WOTasksBeanCustom4RelatedRecords for loop start");
         try
         {
        	 System.out.println("Inside WOTasksBeanCustom4RelatedRecords for loop start 1");
             if(!mboremote.getMboValueData(s1).isReadOnly())
                 mboremote.setValue(s1, flag);
             System.out.println("Inside WOTasksBeanCustom4RelatedRecords for loop start 2");
             continue;
         }
         catch(Exception e)
         {
            e.printStackTrace();
         }
     }

     refreshTable();
     sessionContext.queueRefreshEvent();
     return 1;
 }
   public int taskcomplete() throws RemoteException, MXException
   {
	   //EMS-577 Start
	   //MboSet mboset = (MboSet)getMbo().getMboSet("WORKORDER", getUserWhere());	   
   	  //MboSetRemote mbosetremote = app.getDataBean("plans_task_table").getMboSet();  
	   MboSetRemote mbosetremote = getMboSet().getOwner().getMboSet("WOACTIVITY");   	  
	 //EMS-577 End
       return markAll(mbosetremote, "TASKCOMP", true);
   }
   

  public int taskpend() throws RemoteException, MXException
   {
	  //EMS-577 Start
	  	MboSetRemote mbosetremote = getMboSet().getOwner().getMboSet("WOACTIVITY");
	   	//MboSetRemote mbosetremote = app.getDataBean("plans_task_table").getMboSet();
	  //EMS-577 End 
       return markAll(mbosetremote, "TASKCOMP", false);
   }
}	
  
