/*
 * Modification history
 * 22-07-2013--4.2.6	Creation For Select Services For Return Button for PO validation in Receiving Application.  
 */

package com.psa.webclient.beans.receipts;

import java.rmi.RemoteException;

import psdi.app.po.POServiceRemote;
import psdi.util.MXException;
import psdi.util.MXSession;
import psdi.webclient.beans.receipts.ReceiptsTableBean;

public class CustomReceiptsTableBean extends ReceiptsTableBean

{
	 public CustomReceiptsTableBean()
	    {
	    }
	 
	 public int srvreturn()throws MXException, RemoteException
		 {
		 	 System.out.println("I am Inside srvreturn method checking for valid PO");
		     psdi.mbo.MboRemote mboremote = parent.getMbo();
		     MXSession s = getMXSession();
		     POServiceRemote poService = (POServiceRemote)s.lookup("PO");
		     poService.checkPOValidity(mboremote);
		     return 2;
		 }
	
}
