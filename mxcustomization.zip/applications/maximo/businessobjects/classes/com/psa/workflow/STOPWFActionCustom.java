
package com.psa.workflow;


import java.rmi.RemoteException;

import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.util.MXException;
import psdi.workflow.WFInstance;

public class STOPWFActionCustom
implements ActionCustomClass
{
public STOPWFActionCustom()
{
}

public void applyCustomAction(MboRemote mbo, Object params[]) throws MXException, RemoteException
{
	//getClass().
	//((MboRemote)getClass())
	//System.out.println(mbo.getMXTransaction().);
	//System.out.println(((Mbo)getClass()).getString("PROCESSNAME"));
	long id = mbo.getUniqueIDValue();
	
	String name = mbo.getName();
	
	String where = "ownerid ="+ id +" and ownertable = '" + name +"' and processname <> '" + params[0].toString() +"'";
	System.out.println(where);
	
	SqlFormat sqlf = new SqlFormat(mbo,where );
	MboSetRemote wfset = mbo.getMboSet("$WFINSTANCE","WFINSTANCE",sqlf.format());
	int cnt = wfset.count();
	if(wfset!= null && cnt>0)
	{
		for(int i =0; i<cnt;i++)
		{
    		MboRemote wf = wfset.getMbo(i);
			try
	    	{
	   		  if(mbo!=null)
	   		  {
	   			  ((WFInstance)wf).stopWorkflow("Stopped by Custom stop workflow action");
	   			  System.out.println("Workflow Stopped for [" + wf.getString("OWNERTABLE") + "][" + wf.getString("OWNERID")+"][" + wf.getString("PROCESSNAME") + "]");
	   		  }
	   		  
	   	  	}
		   	catch(Exception e)
		   	{
		   		System.out.println("Error While Stopping workflow :" + e.getMessage());
		   		e.printStackTrace();
		   	}
	   	}
	}
}
}
