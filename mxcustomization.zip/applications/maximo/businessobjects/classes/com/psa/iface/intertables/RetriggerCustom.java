package com.psa.iface.intertables;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import psdi.app.system.CrontaskParamInfo;
import com.psa.custom.ois.MxLog;
//import psdi.iface.mic.MaxEndPoint;//Updated by WMJ on 20120915
import psdi.iface.mic.EndPointCache;
import psdi.iface.mic.MaxEndPointInfo;
import psdi.iface.mic.MicService;
import psdi.iface.mic.MicUtil;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.MXServerRemote;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.MXFormat;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class RetriggerCustom extends SimpleCronTask
{
    public RetriggerCustom()
    {
        isOkToRun = true;
        url = "";
        username = "";
        password = "";
        driver = "";
        ifaceTable = null;
        inputFile = null;
        logFile = null;
        splitTag = null;
        endpointName = null;
        processUserInfo = null;
        errorUserInfo = null;
        errConn = null;
        isRemote = false;
        extSys = null;
        qualifiedInstanceName = null;
        retriggerProcess =null;
        conn = null;
        loadFile = null;
    }

    public void init()
    {
                mxLog = new MxLog();
    }

    public CrontaskParamInfo[] getParameters()
            throws MXException, RemoteException
        {
            return params;
        }

    public void start()
    {
        try
        {
                        refreshSettings();
                        mxLog.writeLog("Starting Re-Trigger Crontask");
                        MicUtil.INTEGRATIONLOGGER.info("Interface table polling task::" + qualifiedInstanceName + " started for system::" + extSys + " with dburl=" + url);
            setSleepTime(0L);
        }
        catch(Exception exception)
        {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }

    public void stop()
    {
        releaseDBResources();
        MicUtil.INTEGRATIONLOGGER.info("Interface table polling task::" + qualifiedInstanceName + " stopped for system::" + extSys + " with dburl=" + url);
                try
                {
                        mxLog.writeLog("Stopping Re-Trigger Crontask");
                        mxLog.closeLogFile();
                }
                catch (Exception e)
                {
                        integrationLogger.error(getName() + " " + e.getMessage(), e);
                }
    }

    private void refreshSettings()
    {
        try
        {
                ifaceTable = getParamAsString("IFACETABLE");
            if(ifaceTable != null && ifaceTable.trim().length() == 0)
                ifaceTable = null;

                extSys = getParamAsString("EXTSYSNAME");
            if(extSys != null && extSys.trim().length() == 0)
                extSys = null;

            endpointName = getParamAsString("ENDPOINT");
            if(endpointName != null && endpointName.trim().length() == 0)
                endpointName = null;

            inputFile = getParamAsString("INPUTFILE");
            if(inputFile != null && inputFile.trim().length() == 0)
                inputFile = null;

            splitTag = getParamAsString("SPLITTAG");
            if(splitTag != null && splitTag.trim().length() == 0)
                splitTag = null;

            logFile = getParamAsString("LOGFILE");
            if(logFile != null && logFile.trim().length() == 0)
                logFile = null;

                loadFile = new File(inputFile);
                File log = new File (logFile);

                if(log.exists())
                        log.delete();

                        mxLog.setEnabled(true);
                        mxLog.setLogFilePath(logFile);
                        mxLog.setLogTag(getName());

                        mxLog.createLogFile();

            cacheResources();
        }
        catch(Exception exception)
        {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }

    private void cacheResources()
        throws MXException, SQLException, RemoteException
        {
            //Updated by WMJ on 20120915
	        MaxEndPointInfo maxendpointinfo = EndPointCache.getInstance().getEndPointInfo(endpointName);
	        //End of Updated by WMJ on 20120915
            if(maxendpointinfo != null)
            {
                Map map = maxendpointinfo.getProperties();
                String s1 = (String)map.get("ISREMOTE");
                if(s1 != null)
                {
                    isRemote = MXFormat.stringToBoolean(s1);
                    if(isRemote)
                    {
                        driver = (String)map.get("DRIVER");
                        username = (String)map.get("USERNAME");
                        password = (String)map.get("PASSWORD");
                        url = (String)map.get("URL");
                    }
                }
            }
            if(!isRemote)
            {
                processUserInfo = ((MicService)MXServer.getMXServer().lookup("MIC")).getNewUserInfo();
                errorUserInfo = ((MicService)MXServer.getMXServer().lookup("MIC")).getNewUserInfo();
            }
            releaseDBResources();
            createDBResources();
        }

    private void createDBResources()
            throws SQLException, MXException
        {
            try
            {
                conn = getConnection(processUserInfo);
                errConn = getConnection(errorUserInfo);
            }
            catch(RemoteException remoteexception)
            {
                MicUtil.INTEGRATIONLOGGER.error(remoteexception.getMessage(), remoteexception);
            }
        }

    private Connection getConnection(UserInfo userinfo)
            throws SQLException, RemoteException
        {
            try
            {
                if(!isRemote)
                        return MXServer.getMXServer().getDBManager().getConnection(userinfo.getConnectionKey());
                    else
                    {
                        Class.forName(driver);
                        return DriverManager.getConnection(url, username, password);
                    }
        }
            catch (ClassNotFoundException classnotfoundexception)
            {
                MicUtil.INTEGRATIONLOGGER.error(classnotfoundexception.getMessage(), classnotfoundexception);
                return null;
            }
        }

    public void releaseDBResources()
    {
        try
        {
            if(retriggerProcess != null)
                retriggerProcess.close();

            if(isRemote)
            {
                try
                {
                    if(conn != null)
                        conn.close();
                }
                catch(Exception exception)
                {
                    MicUtil.INTEGRATIONLOGGER.warn("Error in releasing process connection::" + exception.getMessage());
                }
                try
                {
                    if(errConn != null)
                        errConn.close();
                }
                catch(Exception exception1)
                {
                    MicUtil.INTEGRATIONLOGGER.warn("Error in releasing error connection::" + exception1.getMessage());
                }
            } else
            {
                MXServer.getMXServer().getDBManager().freeConnection(processUserInfo.getConnectionKey());
                MXServer.getMXServer().getDBManager().freeConnection(errorUserInfo.getConnectionKey());
            }
        }
        catch(Exception exception2)
        {
            MicUtil.INTEGRATIONLOGGER.warn("ProcessIfaceTablesIn::releaseResources()::Error in releasing resources");
            MicUtil.INTEGRATIONLOGGER.error(exception2.getMessage(), exception2);
        }
    }

        public void cronAction()
        {
        if(!isOkToRun)
            return;

        try
        {
                if (ifaceTable == null || extSys == null || endpointName == null || splitTag == null)
                        throw new Exception("Required parameter not set.");

                if (inputFile != null)
                {
                        if (!checkFileExist())
                                throw new Exception("["+getName()+"]Unable to find input file.");
                }
                else {
                        throw new Exception("Required parameter not set.");
                }

            BufferedReader flatfileReader;
                flatfileReader = new BufferedReader(new FileReader(inputFile));

            int i = 0;

            while((flatfileReader.readLine()) != null)
            {
                i++;
            }

                mxLog.writeLog("No of transactions: " + i);

                for(int j = 0; j < i; j++)
                {
                        //String line = loadFile.toString();
//                      String line[] = loadFile.list();

//                              mxLog.writeLog("File Data: " + line[0]);

                                Collection col = parseFlatFile(inputFile);

                                Iterator iterParsedData = col.iterator();
                                while (iterParsedData.hasNext())
                                {
                                        Vector vec = (Vector)iterParsedData.next();

                                        String number = (String) vec.elementAt(0);
                                    String transid = (String) vec.elementAt(1);

//                                  mxLog.writeLog("Number: " + number);
//                                  mxLog.writeLog("Transid: " + transid);

                                    if(ifaceTable.equalsIgnoreCase("MXPR_IFACE"))
                                    {
                                        mxLog.writeLog("IN MXPR_FACE");
                                        mxLog.writeLog("===========================================");
                                        if(number != null && transid != null)
                                        {
                                                mxLog.writeLog("Query: UPDATE " + ifaceTable + " SET OA_IFACESTATUS = NULL, OA_IFACEMESSAGE = NULL, OA_IFACETIMESTAMP = NULL WHERE prnum = '" + number + "' and transid = " + transid);
                                                retriggerProcess = conn.prepareStatement("UPDATE " + ifaceTable + " SET OA_IFACESTATUS = NULL, OA_IFACEMESSAGE = NULL, OA_IFACETIMESTAMP = NULL WHERE prnum = ? and transid = ?");
                                                retriggerProcess.setString(1, number);
                                                retriggerProcess.setString(2, transid);

                                                int updateResult = retriggerProcess.executeUpdate();

                                                mxLog.writeLog("Update Successful: " + updateResult + " records updated");
                                                retriggerProcess.getConnection().commit();

                                                retriggerProcess = conn.prepareStatement("SELECT PRNUM, PRLINENUM, TRANSID, OA_IFACESTATUS, OA_IFACETIMESTAMP, OA_IFACEMESSAGE FROM " + ifaceTable + " WHERE prnum = ? and transid = ?");
                                                retriggerProcess.setString(1, number);
                                                retriggerProcess.setString(2, transid);

                                                mxLog.writeLog("Query: SELECT PRNUM, PRLINENUM, TRANSID, OA_IFACESTATUS, OA_IFACETIMESTAMP, OA_IFACEMESSAGE FROM " + ifaceTable + " WHERE prnum = '" + number + "' and transid = " + transid);

                                                ResultSet resultset = retriggerProcess.executeQuery();
                                                resultset.next();
                                                mxLog.writeLog("PRNUM: "+ resultset.getString(1));
                                                mxLog.writeLog("PRLINENUM: "+ resultset.getString(2));
                                                mxLog.writeLog("TRANSID: "+ resultset.getString(3));
                                                mxLog.writeLog("OA_IFACESTATUS: "+ resultset.getString(4));
                                                mxLog.writeLog("OA_IFACETIMESTAMP: "+ resultset.getDate(5));
                                                mxLog.writeLog("OA_IFACEMESSAGE: "+ resultset.getString(6));
                                                mxLog.writeLog("===========================================");
                                        }
                                    } else if(ifaceTable.equalsIgnoreCase("MXPO_IFACE"))
                                    {
                                        mxLog.writeLog("IN MXPO_FACE");
                                        mxLog.writeLog("===========================================");
                                        if(number != null && transid != null)
                                        {
                                                mxLog.writeLog("Query: UPDATE " + ifaceTable + " SET OA_IFACESTATUS = NULL, OA_IFACEMESSAGE = NULL, OA_IFACETIMESTAMP = NULL WHERE ponum = '" + number + "' and transid = " + transid);
                                                retriggerProcess = conn.prepareStatement("UPDATE " + ifaceTable + " SET OA_IFACESTATUS = NULL, OA_IFACEMESSAGE = NULL, OA_IFACETIMESTAMP = NULL WHERE ponum = ? and transid = ?");
                                                retriggerProcess.setString(1, number);
                                                retriggerProcess.setString(2, transid);

                                                int updateResult = retriggerProcess.executeUpdate();

                                                mxLog.writeLog("Update Successful: " + updateResult + " records updated");
                                                retriggerProcess.getConnection().commit();

                                                retriggerProcess = conn.prepareStatement("SELECT PONUM, POLINENUM, TRANSID, OA_IFACESTATUS, OA_IFACETIMESTAMP, OA_IFACEMESSAGE FROM " + ifaceTable + " WHERE ponum = ? and transid = ?");
                                                retriggerProcess.setString(1, number);
                                                retriggerProcess.setString(2, transid);

                                                mxLog.writeLog("Query: SELECT PONUM, POLINENUM, TRANSID, OA_IFACESTATUS, OA_IFACETIMESTAMP, OA_IFACEMESSAGE FROM " + ifaceTable + " WHERE ponum = '" + number + "' and transid = " + transid);

                                                ResultSet resultset = retriggerProcess.executeQuery();
                                                resultset.next();
                                                mxLog.writeLog("PONUM: "+ resultset.getString(1));
                                                mxLog.writeLog("POLINENUM: "+ resultset.getString(2));
                                                mxLog.writeLog("TRANSID: "+ resultset.getString(3));
                                                mxLog.writeLog("OA_IFACESTATUS: "+ resultset.getString(4));
                                                mxLog.writeLog("OA_IFACETIMESTAMP: "+ resultset.getDate(5));
                                                mxLog.writeLog("OA_IFACEMESSAGE: "+ resultset.getString(6));
                                                mxLog.writeLog("===========================================");
                                        }
                                    } else if(ifaceTable.equalsIgnoreCase("MXRECEIPT_IFACE"))
                                    {
                                        mxLog.writeLog("IN MXRECEIPT_FACE");
                                        mxLog.writeLog("===========================================");
                                        if(number != null && transid != null)
                                        {
                                                mxLog.writeLog("Query: UPDATE " + ifaceTable + " SET TRANSDATE=SYSDATE, OA_IFACESTATUS = NULL, OA_IFACEMESSAGE = NULL, OA_IFACETIMESTAMP = NULL WHERE ponum = '" + number + "' and transid = " + transid);
                                                retriggerProcess = conn.prepareStatement("UPDATE " + ifaceTable + " SET TRANSDATE=SYSDATE, OA_IFACESTATUS = NULL, OA_IFACEMESSAGE = NULL, OA_IFACETIMESTAMP = NULL WHERE ponum = ? and transid = ?");
                                                retriggerProcess.setString(1, number);
                                                retriggerProcess.setString(2, transid);

                                                int updateResult = retriggerProcess.executeUpdate();

                                                mxLog.writeLog("Update Successful: " + updateResult + " records updated");
                                                retriggerProcess.getConnection().commit();

                                                retriggerProcess = conn.prepareStatement("SELECT PONUM, POLINENUM, TRANSID, OA_IFACESTATUS, OA_IFACETIMESTAMP, OA_IFACEMESSAGE FROM " + ifaceTable + " WHERE ponum = ? and transid = ?");
                                                retriggerProcess.setString(1, number);
                                                retriggerProcess.setString(2, transid);

                                                mxLog.writeLog("Query: SELECT PONUM, POLINENUM, TRANSID, OA_IFACESTATUS, OA_IFACETIMESTAMP, OA_IFACEMESSAGE FROM " + ifaceTable + " WHERE ponum = '" + number + "' and transid = " + transid);

                                                ResultSet resultset = retriggerProcess.executeQuery();
                                                resultset.next();
                                                mxLog.writeLog("PONUM: "+ resultset.getString(1));
                                                mxLog.writeLog("POLINENUM: "+ resultset.getString(2));
                                                mxLog.writeLog("TRANSID: "+ resultset.getString(3));
                                                mxLog.writeLog("OA_IFACESTATUS: "+ resultset.getString(4));
                                                mxLog.writeLog("OA_IFACETIMESTAMP: "+ resultset.getDate(5));
                                                mxLog.writeLog("OA_IFACEMESSAGE: "+ resultset.getString(6));
                                                mxLog.writeLog("===========================================");
                                        }
                                    } else if(ifaceTable.equalsIgnoreCase("MXIN_INTER_TRANS"))
                                    {
                                        mxLog.writeLog("IN MXIN_INTERTRANS");
                                        mxLog.writeLog("===========================================");
                                        if(number != null && transid != null)
                                        {
                                                mxLog.writeLog("Query: INSERT INTO " + ifaceTable + " (EXTSYSNAME, IFACENAME, TRANSID) VALUES ('OAExtSys','" + number + "', " + transid);

                                                retriggerProcess = conn.prepareStatement("INSERT INTO " + ifaceTable + " (EXTSYSNAME, IFACENAME, TRANSID) VALUES ('OAExtSys',?,?)");
                                                retriggerProcess.setString(1, number);
                                                retriggerProcess.setString(2, transid);

                                                int insertResult = retriggerProcess.executeUpdate();

                                                mxLog.writeLog("Insert Successful: " + insertResult + " records updated");
                                                retriggerProcess.getConnection().commit();

                                                retriggerProcess = conn.prepareStatement("SELECT EXTSYSNAME, IFACENAME, TRANSID FROM " + ifaceTable + " WHERE IFACENAME = ? and TRANSID = ?");
                                                retriggerProcess.setString(1, number);
                                                retriggerProcess.setString(2, transid);

                                                mxLog.writeLog("Query: SELECT EXTSYSNAME, IFACENAME, TRANSID FROM " + ifaceTable + " WHERE IFACENAME = '" + number + "' and TRANSID = " + transid);

                                                ResultSet resultset = retriggerProcess.executeQuery();
                                                resultset.next();
                                                mxLog.writeLog("EXTSYSNAME: "+ resultset.getString(1));
                                                mxLog.writeLog("IFACENAME: "+ resultset.getString(2));
                                                mxLog.writeLog("TRANSID: "+ resultset.getString(3));
                                                mxLog.writeLog("===========================================");
                                        }
                                    } else
                                    {
                                        throw new Exception("Invalid Interface Table!!!");
                                    }
                                }
                }

                stop();
        }
        catch(SQLException sqlexception)
        {
                MicUtil.INTEGRATIONLOGGER.error(sqlexception.getMessage(), sqlexception);
                System.out.println("sqlexception");
            sqlexception.printStackTrace();
            mxLog.writeLog("ERROR " + sqlexception.getMessage() + "\n" + getStackTrace(sqlexception));
        }
        catch(Exception exception)
        {
            MicUtil.INTEGRATIONLOGGER.error(exception.getMessage(), exception);
            mxLog.writeLog("ERROR " + exception.getMessage() + "\n" + getStackTrace(exception));
        }
        return;

        }


    private Collection parseFlatFile(String file)
        throws Exception
    {
        integrationLogger.debug("DKMSCronTask: Entering parseFlatFile");

        // BTE: Parse the DKMS flat flat file first
        // Reading the import flat file
        BufferedReader flatfileReader;
        Collection col = new Vector();
                flatfileReader = new BufferedReader(new FileReader(file));
        String curLine = null;

        // Process record.
        StringTokenizer stringTokenizer = null;

        while((curLine = flatfileReader.readLine()) != null)
        {
            stringTokenizer = new StringTokenizer(curLine, splitTag);
                Vector vec = new Vector();

            mxLog.writeLog("Number of Token: " + stringTokenizer.countTokens());

                if (stringTokenizer.countTokens() == 2)
                {
                    while(stringTokenizer.hasMoreElements())
                    {
                        String curValue = String.valueOf(stringTokenizer.nextElement());
                        // Add to element to vector.
                        vec.add(curValue.trim());
                    }
                    // Add to a collection
                    col.add(vec);
                }
                else
                {
                        mxLog.writeLog("ERROR LINE: " + curLine);
                        mxLog.writeLog("ERROR: Invalid Number of Parameter at Line: " + curLine);
                }
        }
        integrationLogger.debug("DKMSCronTask: Leaving parseFlatFile");
        return col;
    }

        public boolean checkFileExist ()
        {
                integrationLogger.debug("DKMSCronTask: checkFileExist");

                if(loadFile.exists())
                        return true;
                else
                        return false;
        }

        private String getStackTrace(Exception e)
        {
                String stack = "";
                StackTraceElement element[] = e.getStackTrace();
                for (int i = 0; i < element.length; i++)
                        stack += "\tat " + element[i].toString() + "\n";
                return stack;
        }

    public synchronized boolean isOKToRun(MXServerRemote mxserverremote)
    {
        try
        {
                boolean flag = getParamAsBoolean("TARGETENABLED");

                if(flag)
                {
                        String s1 = System.getProperty(qualifiedInstanceName);
                        if(s1 == null || !MXFormat.stringToBoolean(s1))
                        {
                                isOkToRun = true;
                                return true;
                        }
                        else
                        {
                                isOkToRun = false;
                                return false;
                        }
                }
                else
                {
                        isOkToRun = true;
                return true;
                }

        }catch (Exception exception)
        {
                if(integrationLogger.isErrorEnabled())
                        integrationLogger.error(exception.getMessage(), exception);
                        isOkToRun = false;
                        return false;
        }
    }

    private static CrontaskParamInfo params[];
    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
    private boolean isOkToRun;
    private String url;
    private String username;
    private String password;
    private String driver;
    private String endpointName;
    private String ifaceTable;
    private String inputFile;
    private String logFile;
    private String splitTag;
    private boolean isRemote;
    private UserInfo processUserInfo;
    private UserInfo errorUserInfo;
    private String qualifiedInstanceName;
    private String extSys;
    private Connection conn;
    private Connection errConn;
    private PreparedStatement retriggerProcess;
    private MxLog mxLog;
    private File loadFile;

    static
    {
        params = null;
        params = new CrontaskParamInfo[7];

        params[0] = new CrontaskParamInfo();
        params[0].setName("IFACETABLE");
        params[0].setDescription("CommonCron","Interface Table to re-trigger: MXPR_IFACE, MXPO_IFACE, MXRECEIPT_IFACE, MXIN_INTER_TRANS");

        params[1] = new CrontaskParamInfo();
        params[1].setName("EXTSYSNAME");
        params[1].setDescription("CommonCron","External System.");

        params[2] = new CrontaskParamInfo();
        params[2].setName("TARGETENABLED");
        params[2].setDefault("0");

        params[3] = new CrontaskParamInfo();
        params[3].setName("ENDPOINT");
        params[3].setDescription("CommonCron","End Point.");

        params[4] = new CrontaskParamInfo();
        params[4].setName("INPUTFILE");
        params[4].setDescription("CommonCron","Input File with full directory");

        params[5] = new CrontaskParamInfo();
        params[5].setName("SPLITTAG");
        params[5].setDescription("CommonCron","Delimiter.");

        params[6] = new CrontaskParamInfo();
        params[6].setName("LOGFILE");
        params[6].setDescription("CommonCron","Log File with full directory");
    }
}
