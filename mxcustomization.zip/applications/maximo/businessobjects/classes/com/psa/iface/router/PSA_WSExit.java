package com.psa.iface.router;

import psdi.iface.router.DefaultWSExit;
import psdi.iface.router.WSExit;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.mail.MessagingException;
import javax.xml.rpc.soap.SOAPFaultException;

import com.psa.custom.ois.MxLog;

import psdi.mbo.MboConstants;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboRemote;

public class PSA_WSExit extends DefaultWSExit implements WSExit {
	protected MxLog mxLog;
	private String logFilePath; // Log Directory
	private String logFile; // Log file output
	private PrintStream logWriter;
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	

	public PSA_WSExit() {
        super(); // Calls the constructor of the parent class
		try
        {
		    MXServer mxServer = MXServer.getMXServer();
		    UserInfo userInfo = mxServer.getSystemUserInfo();
		    MboSetRemote propSet = mxServer.getMboSet("MAXPROPVALUE", userInfo);
		    propSet.setWhere("PROPNAME='OracleIDLogPath'");
		    propSet.reset();
        if (!propSet.isEmpty()) 
        {
        	MboRemote propMbo = propSet.getMbo(0);
		    logFilePath = propMbo.getString("PROPVALUE");
		    logFile = "Oracleresponses_yyyyMMdd.log";
        }

		Date curDate = new Date();
		DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
		String fileDateStr = fileDateTimeFormat.format(curDate);
		logFile = logFile.replaceAll("yyyyMMdd", fileDateStr);
		logFilePath = logFilePath + logFile;	
        }catch (Exception e) {
            e.printStackTrace();
            writeLog(" Error: "+e);
        }
    }
    
	public void writeLog(String s)
    {
	try {
		
		logWriter = new PrintStream(new FileOutputStream(logFilePath, true));
		String logline;
        logline = (new StringBuilder()).append(new Date()).append("----PSA_WSExit---").append(s).toString();
        
        if(logWriter == null)
            return;
        try
        {
            logWriter.println(logline);
            logWriter.flush();
            return;
        }
        catch(Exception e)
        {
            integrationLogger.error((new StringBuilder("[")).append(e.getMessage()).toString(), e);
        }
        
	} catch (FileNotFoundException e) {
		e.printStackTrace();
		writeLog(" Error: "+e);
	}
    }
	
   @Override
    public void responseOk(byte[] resp) throws MXException {
        try {
        	
            String responseString = new String(resp, "UTF-8");
            System.out.println("%%%%%%% RESPONSE IN STRING VIA UTF-8 %%%%%%%% - "+responseString);
            
            MXServer mxServer = MXServer.getMXServer();
            UserInfo userInfo = mxServer.getSystemUserInfo();
		    
		    String fromMail = "";
		    String subject = "";
			String toMail = "";
		    
		    MboSetRemote commSet = mxServer.getMboSet("COMMTEMPLATE", userInfo);
		    commSet.setWhere("TEMPLATEID='ORACLEIDERROR'");
		    commSet.reset();
	        if (!commSet.isEmpty()) 
	        {
	            MboRemote commMbo = commSet.getMbo(0);
		        fromMail=commMbo.getString("SENDFROM");
		        subject=commMbo.getString("SUBJECT");
		        toMail=commMbo.getString("TOLIST");
	        }

			if (responseString.contains("createJournalDetailsResponse")) {
                processJournalDetailsResponse(responseString, mxServer, userInfo,fromMail,subject,toMail);
            } else if (responseString.contains("createProjectMiscCostResponse")) {
                processProjectMiscCostResponse(responseString, mxServer, userInfo,fromMail,subject,toMail);
            } else if (responseString.contains("createReceiptDetailsResponse")) {
                processReceiptDetailsResponse(responseString, mxServer, userInfo,fromMail,subject,toMail);
            }

            if (responseString.contains("faultstring")) {
                handleFaultString(responseString);
            }

            super.responseOk(resp);
        } catch (SOAPFaultException e) {
            responseError(e);
            writeLog(" Error: "+e);
            throw e;
        } catch (UnsupportedEncodingException | RemoteException e) {
            e.printStackTrace();
            writeLog(" Error: "+e);
        } catch (Exception e) {
            e.printStackTrace();
            writeLog(" Error: "+e);
        }
    }


    private void processJournalDetailsResponse(String responseString, MXServer mxServer, UserInfo userInfo,String fromMail,String subject,String toMail) throws RemoteException, MXException, UnsupportedEncodingException {
        if (responseString.contains("nstrgmpr:result")) {
            try {
            	String transTable ="";
            	String GLrespNumber = extractValue(responseString, "nstrgmpr:result");
                String uniqueID = extractValue(responseString, "nstrgmpr:GroupID");
                String OracleNumber = GLrespNumber;
                String uniquetransID = uniqueID.split(":")[1].replaceAll("\\s", "");
                transTable = uniqueID.split(":")[0];
                
                writeLog("**********************PSA_WSExit-"+transTable+"************************");
                writeLog("Response String via UTF-8: " + responseString);
                writeLog("Oracle ID from XML <nstrgmpr:result> ->" + GLrespNumber);
                writeLog("Maximo Transaction tableID from XML <nstrgmpr:GroupID> ->" + uniqueID);
                
                if (uniquetransID != null && OracleNumber != null &&
                    (transTable.equals("LABTRANS") || transTable.equals("MATRECTRANS") || transTable.equals("MATUSETRANS") || transTable.equals("SERVRECTRANS"))) {
                    updateMboSet(mxServer, userInfo, uniquetransID, OracleNumber, transTable);
                }
            } catch (RemoteException e) {
                e.printStackTrace();
                String emailContent = genEmail(e);
                try {
					MXServer.sendEMail(toMail, null, null, fromMail, subject, emailContent, null, null, null);
				} catch (MessagingException e1) {
					e1.printStackTrace();
					writeLog(" Error: "+e1);
				}
            }
        }
    }

    private void processProjectMiscCostResponse(String responseString, MXServer mxServer, UserInfo userInfo,String fromMail,String subject,String toMail) throws RemoteException, MXException {
        if (responseString.contains("nstrgmpr:TransactionStatusResult")) {
            try {
            	String transTable ="";
                String respNumber = extractValue(responseString, "nstrgmpr:TransactionStatusResult");
                
                String OracleNumber = respNumber.split("-")[0];
                String uniquetransID = respNumber.split(":")[1].replaceAll("\\s", "");
                transTable = respNumber.split("-")[1].split(":")[0];
                
                writeLog("**********************PSA_WSExit-"+transTable+"************************");
                writeLog("Response String via UTF-8: " + responseString);
                writeLog("Oracle ID & Maximo Transaction tableID from XML <nstrgmpr:TransactionStatusResult> ->" + respNumber);

                if (uniquetransID != null && OracleNumber != null &&
                    (transTable.equals("LABTRANS") || transTable.equals("MATRECTRANS") || transTable.equals("MATUSETRANS") || transTable.equals("SERVRECTRANS"))) {
                    updateMboSet(mxServer, userInfo, uniquetransID, OracleNumber, transTable);
                }
            } catch (RemoteException e) {
                e.printStackTrace();
                String emailContent = genEmail(e);
                try {
					MXServer.sendEMail(toMail, null, null, fromMail, subject, emailContent, null, null, null);
				} catch (MessagingException e1) {
					e1.printStackTrace();
					writeLog(" Error: "+e1);
				}
            }
        }
    }

    private void processReceiptDetailsResponse(String responseString, MXServer mxServer, UserInfo userInfo,String fromMail,String subject,String toMail) throws RemoteException, MXException {
        if (responseString.contains("nstrgmpr:headerInterfaceId")) {
            try {
            	String transTable ="";
                String headerInterfaceId = extractValue(responseString, "nstrgmpr:headerInterfaceId");
                String receiptId = extractValue(responseString, "nstrgmpr:receiptNumber");
                String OracleNumber = headerInterfaceId;
                String uniquetransID = receiptId.split(":")[1].replaceAll("\\s", "");
                transTable = receiptId.split("-")[1].split(":")[0];
                
                writeLog("**********************PSA_WSExit-"+transTable+"************************");
                writeLog("Response String via UTF-8: " + responseString);
                writeLog("Oracle ID from XML <nstrgmpr:headerInterfaceId> ->" + headerInterfaceId);
                writeLog("Maximo Transaction tableID from XML <nstrgmpr:receiptNumber> ->" + receiptId);
               
                if (uniquetransID != null && OracleNumber != null &&
                    (transTable.equals("LABTRANS") || transTable.equals("MATRECTRANS") || transTable.equals("MATUSETRANS") || transTable.equals("SERVRECTRANS"))) {
                    updateMboSet(mxServer, userInfo, uniquetransID, OracleNumber, transTable);
                }
            } catch (RemoteException e) {
                e.printStackTrace();
                writeLog(" Error: "+e);
                String emailContent = genEmail(e);
                try {
					MXServer.sendEMail(toMail, null, null, fromMail, subject, emailContent, null, null, null);
				} catch (MessagingException e1) {
					e1.printStackTrace();
					writeLog(" Error: "+e1);
				}
            }
        }
    }

    private void updateMboSet(MXServer mxServer, UserInfo userInfo, String uniquetransID, String OracleNumber, String transTable) throws RemoteException, MXException {
    	writeLog("TransTable: " + transTable+" || "+transTable + "ID: " + uniquetransID + " || "+" OracleNumber: " + OracleNumber + ";");
    	MboSetRemote oracleSet = mxServer.getMboSet(transTable, userInfo);
        oracleSet.setWhere(transTable + "ID = '" + uniquetransID + "'");
        oracleSet.reset();
        writeLog("Query-> "+"Select * from "+transTable+" where "+oracleSet.getWhere());
        if (!oracleSet.isEmpty()) {
            MboRemote oracleMbo = oracleSet.getMbo(0);
            oracleMbo.setValue("ORACLEID", OracleNumber, MboConstants.NOACCESSCHECK);
            oracleSet.save();
            writeLog("OracleID updated in Maximo for "+transTable + "ID : " + uniquetransID +" is " + OracleNumber);
            writeLog("*********************End of Transaction*************************");
        }
    }

    private String extractValue(String responseString, String tag) {
        return responseString.substring(responseString.indexOf("<" + tag + ">") + tag.length() + 2, responseString.indexOf("</" + tag + ">"));
    }

    private void handleFaultString(String responseString) throws SOAPFaultException {
        String faultString = extractValue(responseString, "faultstring");
        writeLog("The Fault String is " + faultString);
        if (responseString.contains("reason")) {
            String soapFault = "GFS Error: " + extractValue(responseString, "reason");
            writeLog("The Fault String is " + soapFault);
            throw new SOAPFaultException(null, soapFault, null, null);
        }
    }
    
    private String genEmail(Exception e) 
	{
	  // Form Email Message
	  String emailMsg = "Date: " + new Date() + "\n";
	  emailMsg += "Error in CronTask: PSA_WSExit" + "\n";
	  emailMsg += "Error Message: " + e.getMessage() + "\n";
	  emailMsg += "Detail:\n";
	  emailMsg += e.toString() + "\n";
	  StackTraceElement element[] = e.getStackTrace();
	  for (int i = 0; i < element.length; i++) 
	  {
	  	emailMsg += "\tat " + element[i].toString() + "\n";
	  }
	
	  return emailMsg;
	}
   
}
