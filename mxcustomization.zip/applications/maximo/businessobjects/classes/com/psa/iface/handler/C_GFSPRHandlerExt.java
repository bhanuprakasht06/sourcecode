package com.psa.iface.handler;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.namespace.QName;
import javax.xml.ws.soap.SOAPFaultException;

import psdi.app.pr.PRRemote;
import psdi.app.workorder.WORemote;
import psdi.common.context.UIContext;
import psdi.iface.mic.MaxEndPointInfo;
import psdi.iface.mic.MicUtil;
import psdi.iface.router.BaseRouterHandler;
import psdi.iface.router.RouterPropsInfo;
import psdi.iface.router.WSExit;
import psdi.iface.router.WSExitHeader;
import psdi.iface.webservices.JAXWSClient;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXSystemException;

public class C_GFSPRHandlerExt extends BaseRouterHandler {
	public static final String SERVICENAME = "SERVICENAME";

	public static final String ENDPOINTURL = "ENDPOINTURL";

	public static final String WSEXIT = "WSEXIT";

	public static final String MEP = "MEP";

	public static final String SOAPACTION = "SOAPACTION";

	public static final String HTTPREADTIMEOUT = "HTTPREADTIMEOUT";

	public static final String HTTPHEADERS = "HTTPHEADERS";

	public static final String HTTPCONNTIMEOUT = "HTTPCONNTIMEOUT";

	public static final String REQ_SOAP_HEADERELEMENTS = "REQ_SOAP_HEADERELEMENTS";

	public static final String RES_SOAP_HEADERELEMENTS = "RES_SOAP_HEADERELEMENTS";

	public static final String HTTPVERSION = "HTTPVERSION";

	public static final String SOAPVERSION = "SOAPVERSION";

	public static final String ENABLEAPPCONTEXT = "ENABLEAPPCONTEXT";

	private static List<RouterPropsInfo> props = new ArrayList<>(9);

	static {
		props.add(new RouterPropsInfo("SERVICENAME"));
		props.add(new RouterPropsInfo("ENDPOINTURL"));
		props.add(new RouterPropsInfo("WSEXIT"));
		props.add(new RouterPropsInfo("USERNAME"));
		props.add(new RouterPropsInfo("PASSWORD", true));
		props.add(new RouterPropsInfo("MEP"));
		props.add(new RouterPropsInfo("SOAPACTION"));
		props.add(new RouterPropsInfo("SOAPVERSION"));
		props.add(new RouterPropsInfo("HTTPREADTIMEOUT"));
		props.add(new RouterPropsInfo("HTTPCONNTIMEOUT"));
		props.add(new RouterPropsInfo("HTTPHEADERS"));
		props.add(new RouterPropsInfo("ENABLEAPPCONTEXT"));
	}

	public C_GFSPRHandlerExt() {}

	public C_GFSPRHandlerExt(MaxEndPointInfo endPointInfo) {
		super(endPointInfo);
	}

	public List<RouterPropsInfo> getProperties() {
		return props;
	}

	protected Object getEJBObject() throws MXException {
		Object homeObj = null;
		String ejbRefName = null;
		InitialContext context = null;
		try {
			context = new InitialContext();
			ejbRefName = "ejb/maximo/remote/jaxwsclient";
			homeObj = context.lookup(ejbRefName);
		} catch (NamingException name) {
			throw new MXSystemException("iface", "jnditreesetuperr", name);
		} finally {
			if (context != null)
				try {
					context.close();
				} catch (NamingException ignore) {
					MicUtil.INTEGRATIONLOGGER.error(ignore.getMessage(), ignore);
				}  
		} 
		try {
			Method createMethod = homeObj.getClass().getMethod("create", (Class[])null);
			return createMethod.invoke(homeObj, (Object[])null);
		} catch (Exception e) {
			throw new MXApplicationException("iface", "loadejb", e);
		} 
	}

	public byte[] invoke(Map<String, ?> metaData, byte[] data) throws MXException {
		try {
			data = super.invoke(metaData, data);
			JAXWSClient wsClient = new JAXWSClient();
			String exitClass = getWSExit();
			WSExit wsExit = null;
			if (exitClass != null)
				wsExit = (WSExit)Class.forName(exitClass).newInstance(); 
			try {
				byte[] resp = null;
				Map<QName, List<String>> soapRequestHeaders = null;
				Map<QName, List<String>> soapResponseHeaders = null;
				if (metaData != null && metaData.containsKey("REQ_SOAP_HEADERELEMENTS"))
					soapRequestHeaders = (Map<QName, List<String>>)metaData.get("REQ_SOAP_HEADERELEMENTS"); 
				if (wsExit != null && wsExit instanceof WSExitHeader)
					soapRequestHeaders = ((WSExitHeader)wsExit).getRequestSOAPHeaders(data, soapRequestHeaders); 
				if (metaData != null && metaData.containsKey("RES_SOAP_HEADERELEMENTS"))
					soapResponseHeaders = (Map<QName, List<String>>)metaData.get("RES_SOAP_HEADERELEMENTS"); 
				UIContext uiContext = UIContext.getCurrentContext();
				Set<String> headerSet = getHeadersToCopy();
				Map<String, List<String>> httpHeaders = null;
				if (headerSet != null && headerSet.size() > 0) {
					httpHeaders = new HashMap<>();
					for (String header : headerSet) {
						if (header.indexOf(':') > 0) {
							StringTokenizer strtk = new StringTokenizer(header, ":");
							List<String> list = new ArrayList<>();
							String httpHeader = strtk.nextToken().trim();
							list.add(strtk.nextToken().trim());
							httpHeaders.put(httpHeader, list);
							continue;
						} 
						if (uiContext == null)
							continue; 
						Enumeration<String> headerValues = uiContext.getHeader(header);
						if (headerValues == null)
							continue; 
						List<String> httpHeaderValues = new ArrayList<>();
						while (headerValues.hasMoreElements())
							httpHeaderValues.add(headerValues.nextElement()); 
						httpHeaders.put(header, httpHeaderValues);
					} 
				} 

				if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
					MicUtil.INTEGRATIONLOGGER.debug("Invoking Web service at url " + getEndpointURL() + " with soapAction " + getSoapAction()); 
				if (!isEnableAppContext()) {
					resp = wsClient.invoke(data, getServiceName(), getEndpointURL(), getSoapAction(), getSoapVersion(), getUserName(), getPassword(), getMsgExPtrn(), httpHeaders, getHttpReadTimeout(), soapRequestHeaders, soapResponseHeaders);
				} else {
					InitialContext context = new InitialContext();
					Object ejbObject = getEJBObject();
					Class[] parameterTypes = { 
							byte[].class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, Map.class, int.class, 
							Map.class, Map.class };
					Method method = ejbObject.getClass().getMethod("invoke", parameterTypes);
					Object[] params = { 
							data, getServiceName(), getEndpointURL(), getSoapAction(), getSoapVersion(), getUserName(), getPassword(), getMsgExPtrn(), httpHeaders, Integer.valueOf(getHttpReadTimeout()), 
							soapRequestHeaders, soapResponseHeaders };
					resp = (byte[])method.invoke(ejbObject, params);
				} 
				String respInString=new String(resp,"UTF-8");
				String reqInString = new String(data,"UTF-8");
				if(respInString.contains("faultstring"))
				{
					String faultString="";
					faultString = respInString.substring(respInString.indexOf("<detail>"), respInString.indexOf("</detail>"));
					System.out.println("%%%%%%%%%%%% The Fault String is %%%%%%%%%%%%%%%"+faultString);
					if (respInString!=null && (respInString.contains("budgetary") || respInString.contains("POR_REQ_IMPORT_FUND_ERR")))
					{
						System.out.println("%%%%%%  GETTING PRNUM %%%%%%");
						String prNum= reqInString.substring((reqInString.indexOf("<cre:RequisitionNumber>")+"<cre:RequisitionNumber>".length()), reqInString.indexOf("</cre:RequisitionNumber>"));
						System.out.println("%%%%%%%%%%%% The PR NUMBER is %%%%%%%%%%%%%%%"+prNum);
						MboSetRemote prSet=MXServer.getMXServer().getMboSet("PR", MXServer.getMXServer().getUserInfo("MAXADMIN"));
						prSet.setWhere("prnum='"+prNum+"' and status='APPR'");
						prSet.reset();
						System.out.println("##### PR SET is "+prSet);
						if(prSet!=null && prSet.count()>0)
						{
							System.out.println(" ******* INSIDE PR CHANGE STATUS ******* ");
							System.out.println(" ******* INSIDE PR CHANGE STATUSCOUNTIS ******* : "+prSet.count());
							PRRemote prRemote=(PRRemote) prSet.getMbo(0);
							//prRemote.changeStatus("CAN", MXServer.getMXServer().getDate(), "Automatically cancelled by the system due to insufficient budget", 11L);					
							MboSetRemote prLineSet=prRemote.getMboSet("PRLINE");
							//prSet.save(11L);
							if(prLineSet!=null && prLineSet.count()>0)
							{
								MboRemote prLineRemote=prLineSet.getMbo(0);
								String woNum=prLineRemote.getString("WONUM");
								String siteID=prLineRemote.getString("SITEID");
								MboSetRemote woSet=MXServer.getMXServer().getMboSet("WORKORDER", MXServer.getMXServer().getUserInfo("MAXADMIN"));
								woSet.setWhere("wonum='"+woNum+"' and siteid='"+siteID+"'");
								woSet.reset();
								if(woSet!=null && woSet.count()>0)
								{
									System.out.println(" ******* CHANGING WOSTATUSCODE ******* ");
									WORemote woRemote=(WORemote) woSet.getMbo(0);
									woRemote.changeStatus("PROFCAN", MXServer.getMXServer().getDate(), "Automatically changed by system (Ref. PR Number - "+prNum+") due to insufficent Budget", 2L);
								    woSet.save();
								}
							}
							prRemote.changeStatus("CAN", MXServer.getMXServer().getDate(), "Automatically cancelled by the system due to insufficient budget", 2L);					
						    prSet.save();
						}
					}
					else
					{
						throw new javax.xml.rpc.soap.SOAPFaultException(null, faultString, null, null);
					}
				}

				if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
					MicUtil.INTEGRATIONLOGGER.debug("Done invoking Web service at url " + getEndpointURL() + " with soapAction " + getSoapAction()); 
				if (resp != null)
					if (MicUtil.INTEGRATIONLOGGER.isDebugEnabled())
						MicUtil.INTEGRATIONLOGGER.debug("Webservice Called. Response is:" + new String(resp, "UTF-8"));  
				if (exitClass != null)
					wsExit.responseOk(resp); 
				if (soapResponseHeaders != null && wsExit instanceof WSExitHeader)
					((WSExitHeader)wsExit).setResponseHeaders(soapResponseHeaders); 
				return resp;
			} catch (Exception e) {
				if (exitClass != null)
					wsExit.responseError(e); 
				throw e;
			} 
		} catch (SOAPFaultException se) {
			se.printStackTrace();
			MicUtil.INTEGRATIONLOGGER.error("fault code " + se.getFault().getFaultCode() + " fault message " + se.getFault().getFaultString());
			throw new MXApplicationException("iface", "could_not_send", se);
		} catch (Exception e) {
			e.printStackTrace();
			if (e instanceof MXException)
				throw (MXException)e; 
			throw new MXSystemException("iface", "could_not_send", e);
		} 
	}

	private Set<String> getHeadersToCopy() {
		String headers = getPropertyValue("HTTPHEADERS");
		Set<String> set = null;
		if (headers != null && headers.trim().length() > 0) {
			set = new HashSet<>();
			StringTokenizer strtk = new StringTokenizer(headers, ",");
			while (strtk.hasMoreTokens())
				set.add(strtk.nextToken()); 
		} 
		return set;
	}

	private String getServiceName() {
		return getPropertyValue("SERVICENAME");
	}

	private String getSoapVersion() {
		return getPropertyValue("SOAPVERSION");
	}

	private String getWSExit() {
		return getPropertyValue("WSEXIT");
	}

	private String getEndpointURL() {
		return getPropertyValue("ENDPOINTURL");
	}

	private String getUserName() {
		return getPropertyValue("USERNAME");
	}

	private String getPassword() {
		return getPropertyValue("PASSWORD");
	}

	private String getSoapAction() {
		return getPropertyValue("SOAPACTION");
	}

	private String getMsgExPtrn() {
		return getPropertyValue("MEP");
	}

	private boolean isEnableAppContext() {
		return getBooleanPropertyValue("ENABLEAPPCONTEXT");
	}

	private int getHttpReadTimeout() {
		return getIntPropertyValue("HTTPREADTIMEOUT");
	}

	private int getHttpConnTimeout() {
		return getIntPropertyValue("HTTPCONNTIMEOUT");
	}
}
