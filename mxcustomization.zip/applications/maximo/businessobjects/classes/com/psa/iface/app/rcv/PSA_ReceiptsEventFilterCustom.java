package com.psa.iface.app.rcv;

import psdi.iface.app.rcv.RcvEventFilter;
import java.rmi.RemoteException;
import psdi.iface.mic.PublishInfo;

import psdi.mbo.MboRemote;

import psdi.util.MXException;


public class PSA_ReceiptsEventFilterCustom extends RcvEventFilter
{


  public PSA_ReceiptsEventFilterCustom(PublishInfo pubInfo) throws MXException {
		super(pubInfo);
		// TODO Auto-generated constructor stub
	}

  /**
   * This method stops recurrence, i.e it checks if this is incoming 
   * This method can be overriden by individual event filter classes to allow
   * recurrence.
   * 
   * @return - true for stopping the event and false otherwise.
   * @throws MXException
   *             MAXIMO exception
   * @throws RemoteException
   *             Remote exception
   */

  protected boolean stopRecurrence(MboRemote mbo) throws MXException, RemoteException
  {
                   return false;
           
  }


}


