package com.psa.iface.wsexit;

import javax.xml.rpc.soap.SOAPFaultException;

import psdi.iface.router.DefaultWSExit;
import psdi.util.MXException;

public class C_WSExitExt extends DefaultWSExit {

	public C_WSExitExt() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void responseOk(byte[] resp) throws MXException {
		// TODO Auto-generated method stub
		try
		{
			System.out.println("%%%%%%% Program control inside ResponseOK %%%%%%%%");
			System.out.println("%%%%%%% RESPONSE IN BYTE[] %%%%%%%% - "+resp);
			System.out.println("%%%%%%% RESPONSE IN STRING %%%%%%%% - "+resp.toString());
			String responseString=resp.toString();
			if(responseString.contains("faultstring"))
			{
				System.out.println("%%%%%% INSIDE IF %%%%%%");
				String faultString="";
				faultString = responseString.substring(responseString.indexOf("<faultstring>"), responseString.indexOf("</faultstring>"));
				System.out.println("%%%%%%%%%%%% The Fault String is %%%%%%%%%%%%%%%"+faultString);
				throw new SOAPFaultException(null, faultString, null, null);

			}
			super.responseOk(resp);
		}
		catch(SOAPFaultException e)
		{
			responseError(e);
			throw e;
		}
	}
	

}
