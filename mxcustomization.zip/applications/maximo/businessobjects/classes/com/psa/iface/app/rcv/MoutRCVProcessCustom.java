package com.psa.iface.app.rcv;

import java.rmi.RemoteException;
import java.util.Map;
import psdi.iface.app.rcv.MoutRCVProcess;
import psdi.app.po.POLineRemote;
import psdi.iface.mic.MicSetOut;
import psdi.iface.mos.ConversionUtil;
import psdi.iface.mos.MosDetailInfo;
import psdi.mbo.MaximoDD;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.Translate;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;

public class MoutRCVProcessCustom extends MoutRCVProcess
{
  private String inputTable;

  public MoutRCVProcessCustom()
    throws MXException, RemoteException
  {
  }

  public int checkBusinessRules(MboRemote mbo, MosDetailInfo mosDetInfo, Map<String, Object> ovrdColValueMap)
    throws MXException, RemoteException
  {
    INTEGRATIONLOGGER.debug("MoutRCVProcessCustom: Entering checkBusinessRules()");

    if (INTEGRATIONLOGGER.isDebugEnabled())
    {
      INTEGRATIONLOGGER.debug("Primary Mbo is " + mbo);
    }

    this.inputTable = mbo.getOwner().getName();
    
    if (INTEGRATIONLOGGER.isDebugEnabled())
    {
      INTEGRATIONLOGGER.debug("table is " + this.inputTable);
    }
    
    if (this.inputTable.equals("SERVRECTRANS"))
      {
        if (isActionUpdate(mbo)) 
        {
	        MboRemote parentMbo = mbo.getOwner();
	        
	        String prevStatus = parentMbo.getMboInitialValue("STATUS").toString();
	        if ( ( prevStatus.equals("COMP") ) && ( parentMbo.getString("STATUS").equals("COMP") ))
    	    {
        	    return 2;
          	}
        }
        
      }
 
    INTEGRATIONLOGGER.debug("Leaving MoutRCVProcessCustom to call super class");
    
    int x;
      
    x=super.checkBusinessRules(mbo, mosDetInfo, ovrdColValueMap);  
    
    return x;
        
  }
}