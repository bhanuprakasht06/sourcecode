package com.psa.iface.app.gl;

import java.rmi.RemoteException;
import java.util.Map;
import psdi.iface.app.gl.MoutGLProcess;
import psdi.iface.mic.MicSetOut;
import psdi.iface.mos.MosDetailInfo;
import psdi.mbo.MaximoDD;
import psdi.mbo.MboRemote;
import psdi.mbo.Translate;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.MaxType;
import psdi.util.logging.MXLogger;

public class MoutGLProcessCustom extends MoutGLProcess
{
  private String inputTable;

  public MoutGLProcessCustom()
    throws MXException, RemoteException
  {
  }

  public int checkBusinessRules(MboRemote mbo, MosDetailInfo mosDetInfo, Map<String, Object> ovrdColValueMap)
    throws MXException, RemoteException
  {
    INTEGRATIONLOGGER.debug("MoutGLProcessCustom: Entering checkBusinessRules ");

    MboRemote parentMbo = mbo.getOwner();

    if (INTEGRATIONLOGGER.isDebugEnabled())
    {
      INTEGRATIONLOGGER.debug("Primary Mbo is " + parentMbo);
    }

    this.inputTable = parentMbo.getName().toUpperCase();
    if (INTEGRATIONLOGGER.isDebugEnabled())
    {
      INTEGRATIONLOGGER.debug("table is " + this.inputTable);
    }
    
    if (this.inputTable.equals("MATUSETRANS"))
      {
        if (!isActionInsert(mbo)) {
          return 2;
        }
        
      }
      
    if (this.inputTable.equals("INVTRANS"))
      {
        if (!isActionInsert(mbo)) {
          return 2;
        }
      }
    
    INTEGRATIONLOGGER.debug("Leaving MoutGLProcessCustom to call super class");
    
    int x;
      
    x=super.checkBusinessRules(mbo, mosDetInfo, ovrdColValueMap);  
    
    return x;

	}
}
