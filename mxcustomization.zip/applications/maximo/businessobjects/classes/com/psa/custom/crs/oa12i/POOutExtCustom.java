/*     */ package com.psa.custom.oa12i;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.List;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.iface.oa12.POOutExt;
/*     */ import psdi.iface.proc.ControlsCache;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
/*     */ public class POOutExtCustom
/*     */   extends POOutExt
/*     */ {
/*  32 */   boolean debug = integrationLogger.isDebugEnabled();
/*     */   
/*     */   public StructureData setDataOut(StructureData structuredata)
/*     */     throws MXException, RemoteException
/*     */   {
/*  44 */     structuredata.breakData();
/*  45 */     integrationLogger.debug("Entering POOutExt.setDataOut");
/*  46 */     checkStatus(structuredata, "POSEND", structuredata.getCurrentData("ORGID"), structuredata.getCurrentData("SITEID"));
/*  47 */     setHeaderDataOut(structuredata);
/*     */     
/*     */ 
/*  50 */     MboSetRemote mbosetremote = structuredata.getCurrentMbo().getMboSet("POLINE");
/*  51 */     List list = structuredata.getChildrenData("POLINE");
/*  52 */     if ((list != null) && (list.size() > 0)) {
/*  54 */       for (int i = 0; i < list.size(); i++)
/*     */       {
/*  56 */         structuredata.setAsCurrent(list, i);
/*  57 */         MboRemote mboremote = mbosetremote.getMboForUniqueId(structuredata.getCurrentDataAsLong("POLINEID"));
/*  58 */         if ((!mboremote.getString("ASSETNUM").equals("")) || (!mboremote.getString("LOCATION").equals(""))) {
/*  59 */           setOAAssetNum(structuredata, mboremote);
/*     */         }
/*  60 */         if (this.debug) {
/*  61 */           integrationLogger.debug(" OAASSETNUM: " + structuredata.getCurrentData("OAASSETNUM"));
/*     */         }
/*     */       }
/*     */     }
/*  64 */     structuredata.setParentAsCurrent();
/*     */     
/*     */ 
/*  67 */     integrationLogger.debug("Leaving POOutExt.setDataOut");
/*  68 */     return structuredata;
/*     */   }
/*     */   
/*     */   public void setHeaderDataOut(StructureData structuredata)
/*     */     throws MXException, RemoteException
/*     */   {
/*  76 */     integrationLogger.debug("Entering POOutExt.setHeaderDataOut");
/*     */     
/*     */ 
/*     */ 
/*  80 */     ControlsCache maxifacecontrol = getMaxIfaceControl();
/*  81 */     Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
/*  82 */     String s = structuredata.getCurrentData("PONUM");
/*  83 */     String s1 = structuredata.getCurrentData("ORGID");
/*  84 */     String s2 = structuredata.getCurrentData("SITEID");
/*  85 */     String s3 = translate.toInternalString("POSTATUS", structuredata.getCurrentData("STATUS"), s2, s1);
/*  86 */     String s4 = translate.toInternalString("POTYPE", structuredata.getCurrentData("POTYPE"), s2, s1);
/*  87 */     String s5 = maxifacecontrol.getValueControl(getExtSystem(), "POAPI", s1, s2);
/*  88 */     if (this.debug) {
/*  89 */       integrationLogger.debug("PONUM: " + s);
/*     */     }
/*  90 */     if ((s3 != null) && ((s3.equals("WAPPR")) || (s3.equals("CLOSE"))))
/*     */     {
/*  92 */       if (this.debug) {
/*  93 */         integrationLogger.debug("Skipping transaction status " + s3);
/*     */       }
/*  94 */       throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*     */     }
/*  96 */     if (structuredata.getCurrentDataAsBoolean("INTERNAL"))
/*     */     {
/*  98 */       if (this.debug) {
/*  99 */         integrationLogger.debug("Skipping transaction INTERNAL");
/*     */       }
/* 100 */       throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*     */     }
/* 102 */     if ((s4 != null) && (!s4.equals("STD")) && (!s4.equals("CHG")) && (s5 != null) && (s5.equals("STD")))
/*     */     {
/* 104 */       if (this.debug) {
/* 105 */         integrationLogger.debug("Skipping transaction PO Type " + s4 + " for STD API");
/*     */       }
/* 106 */       throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*     */     }
/* 108 */     if ((s3 != null) && (s3.equals("CAN")) && (s5 != null) && (s5.equals("STD")))
/*     */     {
/* 110 */       if (this.debug) {
/* 111 */         integrationLogger.debug("Skipping transaction status " + s3 + " for STD API");
/*     */       }
/* 112 */       throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*     */     }
/* 114 */     structuredata.setCurrentData("ORGID", getXREFValue("ORGXREF", s1));
/* 115 */     structuredata.setCurrentData("SITEID", getXREFValue("SITEXREF", s2));
/* 116 */     if (!structuredata.isCurrentDataNull("VENDOR")) {
/* 117 */       checkVendor(structuredata.getCurrentMbo(), structuredata.getCurrentData("SITEID"), true, false, "PO_VENDOR");
/*     */     }
/* 118 */     if (structuredata.isCurrentDataNull("PAYMENTTERMS")) {
/* 119 */       throw new MXApplicationException("iface", "oa-nopaymentterms");
/*     */     }
/* 120 */     if ((structuredata.isCurrentDataNull("PURCHASEAGENT")) && (s5 != null) && (s5.equals("CAI"))) {
/* 121 */       throw new MXApplicationException("iface", "oa-nopurchaseagent");
/*     */     }
/* 122 */     if (structuredata.isCurrentDataNull("BILLTO")) {
/* 123 */       throw new MXApplicationException("iface", "oa-nobillto");
/*     */     }
/* 124 */     if (!structuredata.isCurrentDataNull("STATUS"))
/*     */     {
/* 126 */       if (this.debug) {
/* 127 */         integrationLogger.debug("Before STATUS: " + structuredata.getCurrentData("STATUS"));
/*     */       }
/* 128 */       structuredata.setCurrentData("STATUS", s3);
/* 129 */       if (this.debug) {
/* 130 */         integrationLogger.debug("After STATUS: " + structuredata.getCurrentData("STATUS"));
/*     */       }
/*     */     }
/* 132 */     if (!structuredata.isCurrentDataNull("POTYPE"))
/*     */     {
/* 134 */       if (this.debug) {
/* 135 */         integrationLogger.debug("Before POTYPE: " + structuredata.getCurrentData("POTYPE"));
/*     */       }
/* 136 */       structuredata.setCurrentData("POTYPE", s4);
/* 137 */       if (this.debug) {
/* 138 */         integrationLogger.debug("After POTYPE: " + structuredata.getCurrentData("POTYPE"));
/*     */       }
/*     */     }
/* 140 */     if (!isValueControlNull("GENUSR", s1, s2)) {
/* 141 */       structuredata.setCurrentData("CHANGEBY", maxifacecontrol.getValueControl(getExtSystem(), "GENUSR", s1, s2));
/*     */     }
/* 142 */     structuredata.setCurrentData("OA_POAPI", s5);
/* 143 */     if (this.debug) {
/* 144 */       integrationLogger.debug("OA_POAPI: " + structuredata.getCurrentData("OA_POAPI"));
/*     */     }
/* 145 */     structuredata.setCurrentData("OA_GLCURNCYTYPE", maxifacecontrol.getValueControl(getExtSystem(), "GLCURNCYTYPE", s1, s2));
/* 146 */     if (this.debug) {
/* 147 */       integrationLogger.debug("OA_GLCURNCYTYPE: " + structuredata.getCurrentData("OA_GLCURNCYTYPE"));
/*     */     }
/* 148 */     List list = structuredata.getChildrenData("POLINE");
/* 149 */     if ((list != null) && (list.size() > 0))
/*     */     {
/* 151 */       for (int i = 0; i < list.size(); i++)
/*     */       {
/* 153 */         structuredata.setAsCurrent(list, i);
/* 154 */         setLineDataOut(structuredata, s2);
/*     */       }
/* 157 */       structuredata.setParentAsCurrent();
/*     */     }
/* 159 */     integrationLogger.debug("Leaving POOutExt.setHeaderDataOut");
/*     */   }
/*     */   
/*     */   public void setLineDataOut(StructureData structuredata, String s)
/*     */     throws MXException, RemoteException
/*     */   {
/* 167 */     integrationLogger.debug("Entering POOutExt.setLineDataOut");
/*     */     
/*     */ 
/*     */ 
/* 171 */     ControlsCache maxifacecontrol = getMaxIfaceControl();
/* 172 */     Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
/* 173 */     String s1 = structuredata.getParentData("REQUIREDDATE");
/* 174 */     String s2 = structuredata.getParentData("VENDELIVERYDATE");
/* 175 */     String s3 = structuredata.getParentData("POTYPE");
/* 176 */     String s4 = structuredata.getParentData("SHIPTO");
/* 177 */     String s5 = structuredata.getCurrentData("ORGID");
/* 178 */     String s6 = structuredata.getCurrentData("POLINENUM");
/* 179 */     String[] as = { s6 };
/* 180 */     if (this.debug) {
/* 181 */       integrationLogger.debug("PO Line Number is " + s6);
/*     */     }
/* 182 */     structuredata.setCurrentData("ORGID", structuredata.getParentData("ORGID"));
/* 183 */     if (!structuredata.getCurrentData("TOSITEID").equals(s)) {
/* 184 */       throw new MXApplicationException("iface", "oa-multisitepo", as);
/*     */     }
/* 185 */     if (!structuredata.isGLDataNull("GLCREDITACCT")) {
/* 186 */       structuredata.setGL("GLCREDITACCT", getORAGLAccount(structuredata.getGL("GLCREDITACCT"), s5));
/*     */     } else {
/* 188 */       throw new MXApplicationException("iface", "oa-noglcreditacct", as);
/*     */     }
/* 189 */     if (!structuredata.isGLDataNull("GLDEBITACCT")) {
/* 190 */       structuredata.setGL("GLDEBITACCT", getORAGLAccount(structuredata.getGL("GLDEBITACCT"), s5));
/*     */     } else {
/* 192 */       throw new MXApplicationException("iface", "oa-nogldebitacct", as);
/*     */     }
/* 193 */     if (structuredata.isCurrentDataNull("ORDERUNIT")) {
/* 194 */       throw new MXApplicationException("iface", "oa-noorderunit", as);
/*     */     }
/* 195 */     if ((structuredata.isCurrentDataNull("SHIPTO")) && ((s4 == null) || (s4.equals("")))) {
/* 196 */       throw new MXApplicationException("iface", "oa-noshipto", as);
/*     */     }
/* 197 */     if (((s1 == null) || (s1.equals(""))) && ((s2 == null) || (s2.equals(""))) && 
/* 198 */       (structuredata.isCurrentDataNull("REQDELIVERYDATE")) && (structuredata.isCurrentDataNull("VENDELIVERYDATE"))) {
/* 199 */       throw new MXApplicationException("iface", "oa-nodeliverydate", as);
/*     */     }
/* 200 */     MboSetRemote mbosetremote = structuredata.getCurrentMbo().getMboSet("POLINE");
/* 201 */     MboRemote mboremote = mbosetremote.getMboForUniqueId(structuredata.getCurrentDataAsLong("POLINEID"));
/* 202 */     if (!structuredata.isCurrentDataNull("ITEMNUM")) {
/* 203 */       structuredata.setCurrentData("OA_ITEM_ID", getItemExtRefID(mboremote));
/*     */     }
/* 204 */     if (s3.equals("REL")) {
/* 205 */       structuredata.setCurrentData("POLINENUM", getContractLineNum(mboremote));
/*     */     }
/* 206 */     String s7 = translate.toInternalString("CATEGORY", structuredata.getCurrentData("CATEGORY"), s, s5);
/* 207 */     boolean flag = (s7 != null) && (s7.equals("STK"));
/* 208 */     if ((!structuredata.getCurrentDataAsBoolean("ISSUE")) && ((isValueControlNull("GENITEM", s5, s)) || (getOwnersysid(mboremote).equals("OA"))) && (isValueControlNull("GENSTORE", s5, s)) && (flag)) {
/* 209 */       structuredata.setCurrentData("OA_DEST_TYPE_CODE", maxifacecontrol.getValueControl(getExtSystem(), "DTC_INV", s5, s));
/*     */     } else {
/* 211 */       structuredata.setCurrentData("OA_DEST_TYPE_CODE", maxifacecontrol.getValueControl(getExtSystem(), "DTC_EXP", s5, s));
/*     */     }
/* 212 */     String s8 = translate.toInternalString("LINETYPE", structuredata.getCurrentData("LINETYPE"), s, s5);
/* 213 */     if (!s8.equals("ITEM")) {
/* 214 */       structuredata.setCurrentDataNull("ITEMNUM");
/* 215 */     } else if ((!isValueControlNull("GENITEM", s5, s)) && (!getOwnersysid(mboremote).equals("OA"))) {
/* 216 */       structuredata.setCurrentData("ITEMNUM", maxifacecontrol.getValueControl(getExtSystem(), "GENITEM", s5, s));
/*     */     }
/* 217 */     if ((!structuredata.isCurrentDataNull("STORELOC")) && (!isValueControlNull("GENSTORE", s5, s))) {
/* 218 */       structuredata.setCurrentData("STORELOC", maxifacecontrol.getValueControl(getExtSystem(), "GENSTORE", s5, s));
/*     */     }
/* 219 */     if (!isValueControlNull("GENUSR", s5, s)) {
/* 220 */       structuredata.setCurrentData("ENTERBY", maxifacecontrol.getValueControl(getExtSystem(), "GENUSR", s5, s));
/*     */     }
/* 221 */     structuredata.setCurrentData("OA_CATEGORYID", getXREFValue("OACATXREF", s5, s, structuredata.getCurrentData("LINETYPE")));
/* 222 */     structuredata.setCurrentData("LINETYPE", getXREFValue("LINETYPEXREF", s5, s, structuredata.getCurrentData("LINETYPE")));
/* 223 */     structuredata.setCurrentData("TOSITEID", structuredata.getParentData("SITEID"));
/* 224 */     if ((isProjectInstalled()) && (maxifacecontrol.isControlTrue(getExtSystem(), "PROJPO", s5, s)) && 
/* 225 */       (!structuredata.isCurrentDataNull("FINCNTRLID")))
/*     */     {
/* 227 */       if (structuredata.isCurrentDataNull("OA_CHARGE_ORG")) {
/* 228 */         structuredata.setCurrentData("OA_CHARGE_ORG", maxifacecontrol.getValueControl(getExtSystem(), "CHARGEORG", s5, s));
/*     */       }
/* 229 */       setProjTask(structuredata, mboremote);
/* 230 */       if (structuredata.isCurrentDataNull("OA_EXPENDTYPE")) {
/* 231 */         structuredata.setCurrentData("OA_EXPENDTYPE", getExpendType(structuredata.getCurrentData("ITEMNUM")));
/*     */       }
/*     */     }
/* 233 */     integrationLogger.debug("Leaving POOutExt.setLineDataOut");
/*     */   }
/*     */   
/*     */   public boolean isProjectInstalled()
/*     */     throws MXException
/*     */   {
/* 240 */     return getMaxIfaceControl().isControlExists(getExtSystem(), "PROJSEND");
/*     */   }
/*     */   
/*     */   public void setProjTask(StructureData structuredata, MboRemote po)
/*     */     throws MXException, RemoteException
/*     */   {
/* 247 */     ERPOutExtCustom erpout = new ERPOutExtCustom(getUserInfo());
/* 248 */     erpout.setProjTask(structuredata, po);
/*     */   }
/*     */   
/*     */   public void setOAAssetNum(StructureData structuredata, MboRemote po)
/*     */     throws MXException, RemoteException
/*     */   {
/* 255 */     ERPOutExtCustom erpout = new ERPOutExtCustom(getUserInfo());
/* 256 */     erpout.setOAAssetNum(structuredata, po);
/*     */   }
/*     */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.POOutExtCustom
 * JD-Core Version:    0.7.0.1
 */