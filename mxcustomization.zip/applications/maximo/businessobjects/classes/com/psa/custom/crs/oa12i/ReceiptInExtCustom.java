/*    */ package com.psa.custom.oa12i;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.iface.mic.StructureData;
/*    */ import psdi.iface.oa12.ReceiptInExt;
/*    */ import psdi.util.MXException;
/*    */ 
/*    */ public class ReceiptInExtCustom
/*    */   extends ReceiptInExt
/*    */ {
/*    */   public StructureData setDataIn(StructureData structuredata)
/*    */     throws MXException, RemoteException
/*    */   {
/* 27 */     structuredata = super.setDataIn(structuredata);
/* 28 */     structuredata.setCurrentData("ORGID", getXREFValue("ORGXREF", structuredata.getCurrentData("ORGID")));
/* 29 */     return structuredata;
/*    */   }
/*    */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.ReceiptInExtCustom
 * JD-Core Version:    0.7.0.1
 */