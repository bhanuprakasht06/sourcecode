/**
 * @author	HCHA
 * Date		Apr 26, 2006
 * Comment	 
 */
package com.psa.custom.common;

import psdi.security.UserInfo;
import java.rmi.RemoteException;
import java.sql.*;
import psdi.iface.mic.MicUtil;
import psdi.server.MXServer;
import psdi.util.*;

/**
 * @author		HCHA
 * @class		MxDatabase
 * @date		Apr 26, 2006
 * @function	
 */

public class MxDatabase {
	
	//Paramters for Remote DB 
    private String remoteDBdriver;
    private String remoteDBusername;
    private String remoteDBpassword;
    private String remoteDBurl;
    
    //Paramters for Local DB
    private UserInfo processUserInfo;
    
    //Database
    private Connection conn;
    
    private boolean isRemote;
    
    /**
     * @author		HCHA
     * @function	MxDatabase
     * @date		Apr 26, 2006
     * @comment		Constructor	for Remote DB
     */
	public MxDatabase(String remoteDBdriver, String remoteDBusername, String remoteDBpassword, String remoteDBurl) 
		throws SQLException, RemoteException, Exception
	{
		try{
			isRemote = true;
			this.remoteDBdriver = remoteDBdriver;
			this.remoteDBusername = remoteDBusername;
			this.remoteDBpassword = remoteDBpassword;
			this.remoteDBurl = remoteDBurl;
			processUserInfo=null;
			
			conn = getConnection(processUserInfo);
		}
		catch(SQLException sqlexception)
		{
		  	releaseResources();
		    MicUtil.INTEGRATIONLOGGER.error(sqlexception);
		    Object aobj[] = {
		     		(new Integer(sqlexception.getErrorCode())).toString()
		    };
		    throw new MXSystemException("system", "sql", aobj, sqlexception);
		}
	}

    /**
     * @author		HCHA
     * @function	MxDatabase
     * @date		Apr 26, 2006
     * @comment		Constructor	for Local DB
     */
	public MxDatabase(UserInfo processUserInfo) 
		throws SQLException, RemoteException, Exception
	{
		try{
			isRemote = false;
			this.processUserInfo = processUserInfo;
			conn = getConnection(processUserInfo);
		}
	    catch(SQLException sqlexception)
	    {
	    	releaseResources();
	        MicUtil.INTEGRATIONLOGGER.error(sqlexception);
	        Object aobj[] = {
	        		(new Integer(sqlexception.getErrorCode())).toString()
	        };
	        throw new MXSystemException("system", "sql", aobj, sqlexception);
	    }
	}
	
    /**
     * @author		HCHA
     * @function	getConnection
     * @date		Apr 26, 2006
     * @comment		Get database connection
     */
	private Connection getConnection(UserInfo userinfo)
	    throws SQLException, RemoteException, ClassNotFoundException
	{

		  if(!isRemote)
	          return MXServer.getMXServer().getDBManager().getConnection(userinfo.getConnectionKey());
		   
		  Connection connection;
	      Class.forName(remoteDBdriver);
	      connection = DriverManager.getConnection(remoteDBurl, remoteDBusername, remoteDBpassword);
	      connection.setAutoCommit(false);
		      
	      return connection;
	      
	}
	
    /**
     * @author		HCHA
     * @function	releaseResources
     * @date		Apr 26, 2006
     * @comment		Release DB Resources
     */
    public void releaseResources()
    {
        try
        {
            if(!isRemote)
                MXServer.getMXServer().getDBManager().freeConnection(processUserInfo.getConnectionKey());
            else
                conn.close();
        }
        catch(Exception exception)
        {
            MicUtil.INTEGRATIONLOGGER.warn("MxDatabase.releaseResources(): Error in releasing resources");
            MicUtil.INTEGRATIONLOGGER.error(exception.getMessage(), exception);
        }
    }

	public Connection getConn() {
		return conn;
	}
}
