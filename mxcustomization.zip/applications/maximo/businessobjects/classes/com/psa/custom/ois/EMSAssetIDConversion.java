package com.psa.custom.ois;

import java.io.*;
import java.util.StringTokenizer;
import java.util.Vector;

public class EMSAssetIDConversion {


private Vector vect;


public EMSAssetIDConversion (String fileName) throws Exception{

vect = new Vector();

BufferedReader reader = new BufferedReader(new FileReader(fileName));
String aId = reader.readLine();

while (aId != null){
vect.addElement(""+aId);
aId = reader.readLine();}

}


public String getRightAssetId(String assetid){

for (int i=0; i<vect.size(); i++){

StringTokenizer tok = new StringTokenizer(vect.elementAt(i).toString().trim(),",");
String firstToken = tok.nextToken().trim();
	
if (firstToken.equalsIgnoreCase(assetid)){
			return tok.nextToken().trim();
		}}

return assetid;

}



public static String OIStoEMSMappingUtil (String assetid) throws Exception {
	
	
	BufferedReader reader = new BufferedReader(new FileReader(getFileName()));
	String aId = reader.readLine();
	
	while (aId != null) {
		StringTokenizer tok = new StringTokenizer (aId.trim(), ",");
		String firstToken = tok.nextToken().trim();
		
		if (firstToken.equalsIgnoreCase(assetid)){
			return tok.nextToken().trim();
		}
		
		aId = reader.readLine();}
		
	return assetid;	
	
	
}



public static String EMStoOISMappingUtil (String assetid) throws Exception {

	BufferedReader reader = new BufferedReader(new FileReader(getFileName()));
	String aId = reader.readLine();

	while (aId != null) {
		StringTokenizer tok = new StringTokenizer (aId.trim(), ",");
		String firstToken = tok.nextToken().trim();
		String secondToken = tok.nextToken().trim();
		
		if (secondToken.equalsIgnoreCase(assetid)){
			return firstToken;
		}
		
		aId = reader.readLine();}
		
	return assetid;	
	
	
}
	
	
private static String getFileName() throws Exception{
	
		
	BufferedReader reader = new BufferedReader(new FileReader("config"));
	StringTokenizer tok = new StringTokenizer(reader.readLine(), "=");
	
	if (tok.nextToken().equalsIgnoreCase("data_path"))
		return tok.nextToken();


	return ""; }


	
	
	
	
	
	
	
	
	
	




}