/*
 * Modification history
 * xx-xx-2006	HYC	NA			Creation
 * xx-09-2007	AGD	SR-110	Make calculation of duration in double instead of int
 */
package com.psa.custom.ois;

import java.lang.Comparable;
import java.util.Date;
import java.util.GregorianCalendar;
import java.math.BigDecimal;


public class OISData implements Comparable {
	private String assetID;
	private int numContainer;
// Begin modification SR-110
//	private int duration; //in mins
	private double duration; //in mins
// End modification SR-110
	private String actLastReadingDT;


	public OISData() {
		super();

	}

//	Begin modification SR-110
//	public OISData(String assetID, int numContainer, int duration, String actLastReadingDT) {
	public OISData(String assetID, int numContainer, double duration, String actLastReadingDT) {
//	End modification SR-110
		super();

		this.assetID = assetID;
		this.numContainer = numContainer;
		this.duration = duration;
		this.actLastReadingDT = actLastReadingDT;
	}

// Begin modification SR-110
//	public OISData(String assetID, int numContainer, int duration) {
	public OISData(String assetID, int numContainer, double duration) {
//	End modification SR-110
		super();

		this.assetID = assetID;
		this.numContainer = numContainer;
		this.duration = duration;
	}

// Begin modification SR-110
//	public int getDuration() {
	public double getDuration() {
//	 End modification SR-110
		return duration;
	}

	public double getDurationHr() {

//	Begin modification SR-110
//		BigDecimal durDec = new BigDecimal(new Integer(duration).doubleValue() );
		BigDecimal durDec = new BigDecimal(duration);
//	End modification SR-110

		//Calculate duration in hr and round up to 2 decimal place
		return durDec.divide(new BigDecimal(60.0), 2, java.math.BigDecimal.ROUND_HALF_UP).doubleValue();
		
	}

// Begin modification SR-110
//	public void setDuration(int duration) {
	public void setDuration(double duration) {
//	End modification SR-110
		this.duration = duration;
	}

	public int getNumContainer() {
		return numContainer;
	}

	public void setNumContainer(int numContainer) {
		this.numContainer = numContainer;
	}

	public String getAssetID() {
		return assetID;
	}

	public void setAssetID(String assetID) {
		this.assetID = assetID;
	}

	public String getActLastReadingDT() {
		return actLastReadingDT;
	}

	public void setActLastReadingDT(String lastReadingDT) {
		this.actLastReadingDT = lastReadingDT;
	}

	public int compareTo(Object anotherOISData) throws ClassCastException {	    
		if (!(anotherOISData instanceof OISData))
	      throw new ClassCastException("A OISData object expected.");	
		
		//For sorting the object by Asset ID follow by 
		//Activity Start Date & Time
		String sortStr = this.getAssetID() + this.getActLastReadingDT();
		String anotherSortStr =  ((OISData)anotherOISData).getAssetID() +  ((OISData)anotherOISData).getActLastReadingDT();
		
	    return sortStr.compareTo(anotherSortStr) ;      
	}

	//Convert OIS formatted date to stardard Date class 
	public static Date convertDate(String oisDate)
	{
		
		if((oisDate!=null)&&oisDate.length()==12){
			//OIS Date Format: YYYYMMDDHHMM
			int oisYear = Integer.parseInt(oisDate.substring(0,4));
			int oisMonth = Integer.parseInt(oisDate.substring(4,6))-1;
			int oisDay = Integer.parseInt(oisDate.substring(6,8));
			int oisHr = Integer.parseInt(oisDate.substring(8,10));
			int oisMin = Integer.parseInt(oisDate.substring(10,12));
			
			Date stddate = new GregorianCalendar(oisYear,oisMonth,oisDay,oisHr, oisMin).getTime();
			
			return stddate;
		}
		
		return null;
		
	}

	/**
	 * 
	 * @author		HCHA
	 * @date		Mar 3, 2006
	 * @function	Calculate duration between 2 dates
	 * @param startDT Begin Date formated in yyyymmddhhmm
	 * @param endDT End Date formated in yyyymmddhhmm
	 * @return		duration
	 */
//	Begin modification SR-110
//	public static int calDuration(String startDT, String endDT){
	public static double calDuration(String startDT, String endDT){
//	End modification SR-110

		Date startDate = convertDate(startDT);
		Date endDate = convertDate(endDT);

//	Begin modification SR-110
//		return (int)((endDate.getTime() - startDate.getTime())/(1000 * 60));
		return (endDate.getTime() - startDate.getTime())/(1000 * 60);
//	End modification SR-110

	}

}
