/*    */ package com.psa.custom.oa12i;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.List;
/*    */ import psdi.iface.mic.StructureData;
/*    */ import psdi.iface.oa12.ERPOutExt;
/*    */ import psdi.iface.proc.ControlsCache;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.mbo.MboSetRemote;
/*    */ import psdi.util.MXApplicationException;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.logging.MXLogger;
/*    */ 
/*    */ public class MxItemOutExt
/*    */   extends ERPOutExt
/*    */ {
/*    */   public StructureData setDataOut(StructureData structuredata)
/*    */     throws MXException, RemoteException
/*    */   {
/* 35 */     structuredata.breakData();
/* 36 */     integrationLogger.debug("ItemOutExt: Entering setDataOut");
/*    */     
/*    */ 
/*    */ 
/* 40 */     ControlsCache maxifacecontrol = getMaxIfaceControl();
/* 41 */     if ((structuredata.getAction() != null) && (structuredata.getAction().equals("Delete"))) {
/* 42 */       throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*    */     }
/* 43 */     String s = structuredata.getCurrentData("OWNERSYSID");
/* 44 */     if ((s != null) && (s.equals("OA"))) {
/* 45 */       throw new MXApplicationException("iface", "oa-oaitemnochange");
/*    */     }
/* 46 */     MboSetRemote mbosetremote = structuredata.getCurrentMbo().getMboSet("ORGANIZATION");
/* 47 */     MboRemote mboremote = mbosetremote.moveFirst();
/* 48 */     StringBuffer stringbuffer = null;
/* 49 */     for (; mboremote != null; mboremote = mbosetremote.moveNext())
/*    */     {
/* 51 */       String s1 = mboremote.getString("ORGID");
/* 52 */       if (maxifacecontrol.doesXREFExist(getExtSystem(), "ORGXREF", s1, null, s1, true)) {
/* 54 */         if (stringbuffer == null) {
/* 55 */           stringbuffer = new StringBuffer(getXREFValue("ORGXREF", s1));
/*    */         } else {
/* 57 */           stringbuffer.append(",").append(getXREFValue("ORGXREF", s1));
/*    */         }
/*    */       }
/*    */     }
/* 60 */     structuredata.setCurrentData("OA_SET_OF_BKS_IDS", stringbuffer.toString());
/* 61 */     if (maxifacecontrol.doesXREFExist(getExtSystem(), "LANGXREF", null, null, structuredata.getCurrentData("TRANS_LANGCODE"), true)) {
/* 62 */       structuredata.setCurrentData("OA_SET_PROCESS_ID", getXREFValue("LANGXREF", structuredata.getCurrentData("TRANS_LANGCODE")));
/*    */     } else {
/* 64 */       structuredata.setCurrentData("OA_SET_PROCESS_ID", "1");
/*    */     }
/* 66 */     structuredata.removeChildren("ITEMCONDITION");
/* 67 */     structuredata.removeChildren("CONVERSION");
/*    */     
/* 69 */     List lst = structuredata.getChildrenData("INVENTORY");
/* 71 */     if (lst.size() > 0) {
/* 72 */       for (int i = 0; i < lst.size() - 1;)
/*    */       {
/* 73 */         structuredata.removeChildData("INVENTORY", 0);
/* 74 */         lst = structuredata.getChildrenData("INVENTORY");
/*    */       }
/*    */     }
/* 78 */     integrationLogger.debug("ItemOutExt: Leaving setDataOut");
/* 79 */     return structuredata;
/*    */   }
/*    */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.MxItemOutExt
 * JD-Core Version:    0.7.0.1
 */