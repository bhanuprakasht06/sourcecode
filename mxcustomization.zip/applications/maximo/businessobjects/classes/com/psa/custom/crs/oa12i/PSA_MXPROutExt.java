/* Modified by Karthikeyan(Comm-IT) for Maximo-GFS Integration Project*/

package com.psa.custom.oa12i;

/*     */ import java.rmi.RemoteException;
/*     */ import java.util.List;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.iface.oa12.PROutExt;
/*     */ import psdi.iface.proc.ControlsCache;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXSystemException;
/*     */ import psdi.util.logging.MXLogger;

public class PSA_MXPROutExt extends PROutExt {
	boolean debug = integrationLogger.isDebugEnabled();
	/*     */   String orgId;
	/*     */   String siteId;
	/*     */   String genitem;
	/*     */   String genstore;
	/*     */   
	/*     */   public PSA_MXPROutExt()
	/*     */   {
	/*  34 */     this.orgId = "";
	/*  35 */     this.siteId = "";
	/*  36 */     this.genitem = "";
	/*  37 */     this.genstore = "";
	/*     */   }
	/*     */   
	/*     */   public StructureData setDataOut(StructureData structuredata)
	/*     */     throws MXException, RemoteException
	/*     */   {
	/*  47 */     structuredata.breakData();
	/*  48 */     integrationLogger.debug("Entering PROutExt.setDataOut");
	/*  49 */     integrationLogger.debug("PR Number is " + structuredata.getCurrentData("PRNUM"));
	/*     */     
	/*     */ 
	/*     */ 
	/*  53 */     ControlsCache maxifacecontrol = getMaxIfaceControl();
	/*  54 */     Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
	/*  55 */     this.orgId = structuredata.getCurrentData("ORGID");
	/*  56 */     this.siteId = structuredata.getCurrentData("SITEID");
	/*  57 */     String s = maxifacecontrol.getValueControl(getExtSystem(), "GENUSR", this.orgId, this.siteId);
	/*  58 */     this.genitem = maxifacecontrol.getValueControl(getExtSystem(), "GENITEM", this.orgId, this.siteId);
	/*  59 */     this.genstore = maxifacecontrol.getValueControl(getExtSystem(), "GENSTORE", this.orgId, this.siteId);
	/*  60 */     String s1 = translate.toInternalString("PRSTATUS", structuredata.getCurrentData("STATUS"), this.siteId, this.orgId);
	/*  62 */     if (!maxifacecontrol.isControlEqual(getExtSystem(), "PRSEND", this.orgId, this.siteId, structuredata.getCurrentData("STATUS"))) {
	/*  63 */       throw new MXSystemException("iface", "skip_transaction");
	/*     */     }
	/*  64 */     structuredata.setCurrentData("ORGID", getXREFValue("ORGXREF", this.orgId));
	/*  65 */     if (this.debug) {
	/*  66 */       integrationLogger.debug("ORGID: " + structuredata.getCurrentData("ORGID"));
	/*     */     }
	/*  67 */     structuredata.setCurrentData("SITEID", getXREFValue("SITEXREF", this.siteId));
	/*  68 */     if (this.debug) {
	/*  69 */       integrationLogger.debug("SITEID: " + structuredata.getCurrentData("SITEID"));
	/*     */     }
	/*  70 */     if (this.debug) {
	/*  71 */       integrationLogger.debug("Before STATUS: " + structuredata.getCurrentData("STATUS"));
	/*     */     }
	/*  72 */     structuredata.setCurrentData("STATUS", getXREFValue("PRSTATUSXREF", s1));
	/*  73 */     if (this.debug) {
	/*  74 */       integrationLogger.debug("After STATUS: " + structuredata.getCurrentData("STATUS"));
	/*     */     }
	/*  75 */     if (structuredata.isCurrentDataNull("REQUESTEDBY"))
	/*     */     {
	/*  77 */       String s2 = getUserInfo().getPersonId();
	/*  78 */       structuredata.setCurrentData("REQUESTEDBY", s2);
	/*     */     }
	/*  80 */     if ((!structuredata.getCurrentDataAsBoolean("INTERNAL")) && (!structuredata.isCurrentDataNull("VENDOR"))) {
	/*  81 */       checkVendor(structuredata.getCurrentMbo(), structuredata.getCurrentData("SITEID"), true, false);
	/*     */     }
	/*  82 */     if (structuredata.isCurrentDataNull("SHIPTOATTN")) {
	/*  83 */       throw new MXApplicationException("iface", "oa-noshiptoattn");
	/*     */     }
	/*  84 */     structuredata.setCurrentData("OA_GLCURNCY", maxifacecontrol.getValueControl(getExtSystem(), "GLCURNCY", this.orgId, this.siteId));
	/*  85 */     if (this.debug) {
	/*  86 */       integrationLogger.debug("OA_GLCURNCY: " + structuredata.getCurrentData("OA_GLCURNCY"));
	/*     */     }
	/*  87 */     structuredata.setCurrentData("OA_GLCURNCYTYPE", maxifacecontrol.getValueControl(getExtSystem(), "GLCURNCYTYPE", this.orgId, this.siteId));
	/*  88 */     if (this.debug) {
	/*  89 */       integrationLogger.debug("OA_GLCURNCYTYPE: " + structuredata.getCurrentData("OA_GLCURNCYTYPE"));
	/*     */     }
	/*  90 */     structuredata.setCurrentData("OA_USEPRNUM", maxifacecontrol.isControlTrue(getExtSystem(), "USEPRNUM", this.orgId, this.siteId) ? "1" : "0");
	/*  91 */     if (this.debug) {
	/*  92 */       integrationLogger.debug("OA_USEPRNUM: " + structuredata.getCurrentData("OA_USEPRNUM"));
	/*     */     }
	/*  93 */     List list = structuredata.getChildrenData("PRLINE");
	/*  94 */     if ((list != null) && (list.size() > 0))
	/*     */     {
	/*  96 */       for (int i = 0; i < list.size(); i++)
	/*     */       {
	/*  98 */         structuredata.setAsCurrent(list, i);
	/*  99 */         String s3 = structuredata.getCurrentData("PRLINENUM");
	/* 100 */         String s4 = "M";
	/*     */         
	/* 102 */         String s7 = "";
	/* 103 */         String[] as = { s3 };
	/* 104 */         if (this.debug) {
	/* 105 */           integrationLogger.debug("PR Line Number is " + s3);
	/*     */         }
	/* 106 */         if ((s != null) && (!s.equals(""))) {
	/* 107 */           structuredata.setCurrentData("ENTERBY", s);
	/*     */         }
	/* 108 */         if (!structuredata.isGLDataNull("GLCREDITACCT")) {
	/* 109 */           //structuredata.setGL("GLCREDITACCT", getORAGLAccount(structuredata.getGL("GLCREDITACCT"), this.orgId));
	/*     */         }
	/* 110 */         if (!structuredata.isGLDataNull("GLDEBITACCT")) {
	/* 111 */           //structuredata.setGL("GLDEBITACCT", getORAGLAccount(structuredata.getGL("GLDEBITACCT"), this.orgId));
	/*     */         } else {
	/* 113 */           throw new MXApplicationException("iface", "oa-nogldebitacct");
	/*     */         }
	/* 114 */         if (structuredata.isCurrentDataNull("ORDERUNIT")) {
	/* 115 */           throw new MXApplicationException("iface", "oa-noorderunit", as);
	/*     */         }
	/* 116 */         if (!structuredata.isCurrentDataNull("CATEGORY"))
	/*     */         {
	/* 118 */           String s6 = translate.toInternalString("CATEGORY", structuredata.getCurrentData("CATEGORY"));
	/* 119 */           structuredata.setCurrentData("CATEGORY", s6);
	/*     */         }
	/* 121 */         if (!structuredata.isCurrentDataNull("LINETYPE"))
	/*     */         {
	/* 123 */           structuredata.setCurrentData("OA_CATEGORYID", getXREFValue("OACATXREF", this.orgId, this.siteId, structuredata.getCurrentData("LINETYPE")));
	/* 124 */           s7 = translate.toInternalString("LINETYPE", structuredata.getCurrentData("LINETYPE"));
	/* 125 */           structuredata.setCurrentData("LINETYPE", getXREFValue("LINETYPEXREF", this.orgId, this.siteId, structuredata.getCurrentData("LINETYPE")));
	/*     */         }
	/* 127 */         MboSetRemote mbosetremote = structuredata.getCurrentMbo().getMboSet("PRLINE");
	/* 128 */         MboRemote mboremote = mbosetremote.getMboForUniqueId(structuredata.getCurrentDataAsLong("PRLINEID"));
	/* 129 */         s4 = getOwnersysid(mboremote);
	/* 130 */         //structuredata.setCurrentData("OA_ITEM_ID", getItemExtRefID(mboremote));
	/* 134 */         if ((s7.equals("SERVICE")) || (s7.equals("MATERIAL"))) {
	/* 136 */           structuredata.setCurrentDataNull("ITEMNUM");
	/* 137 */         } else if ((this.genitem != null) && (!this.genitem.equals("")) && (!s4.equals("OA"))) {
	/* 138 */           structuredata.setCurrentData("ITEMNUM", this.genitem);
	/*     */         }
	/* 139 */         structuredata.setCurrentData("OA_DEST_TYPE_CODE", "EXPENSE");
	/* 140 */         if ((!structuredata.isCurrentDataNull("STORELOC")) && (this.genstore != null) && (!this.genstore.equals(""))) {
	/* 141 */           structuredata.setCurrentData("STORELOC", this.genstore);
	/*     */         }
	/* 142 */         if (this.debug) {
	/* 143 */           integrationLogger.debug("itmOwnersysId: " + s4);
	/*     */         }
	/* 144 */         if (this.debug) {
	/* 145 */           integrationLogger.debug(" ITEMUM: " + structuredata.getCurrentData("ITEMNUM"));
	/*     */         }
	/* 146 */         if (this.debug) {
	/* 147 */           integrationLogger.debug(" STORELOC: " + structuredata.getCurrentData("STORELOC"));
	/*     */         }
	/* 152 */         if ((!mboremote.getString("ASSETNUM").equals("")) || (!mboremote.getString("LOCATION").equals(""))) {
	/* 153 */           setOAAssetNum(structuredata, mboremote);
	/*     */         }
	/* 155 */         if (this.debug) {
	/* 156 */           integrationLogger.debug(" OAASSETNUM: " + structuredata.getCurrentData("OAASSETNUM"));
	/*     */         }
	/* 159 */         if ((isProjectInstalled()) && (maxifacecontrol.isControlTrue(getExtSystem(), "PROJPR", this.orgId, this.siteId)) && (!structuredata.isCurrentDataNull("FINCNTRLID")))
	/*     */         {
	/* 161 */           if (structuredata.isCurrentDataNull("OA_CHARGE_ORG")) {
	/* 162 */             structuredata.setCurrentData("OA_CHARGE_ORG", maxifacecontrol.getValueControl(getExtSystem(), "CHARGEORG", this.orgId, this.siteId));
	/*     */           }
	/* 163 */           setProjTask(structuredata, mboremote);
	/* 164 */           if (structuredata.isCurrentDataNull("OA_EXPENDTYPE")) {
	/* 165 */             structuredata.setCurrentData("OA_EXPENDTYPE", getExpendType(structuredata.getCurrentData("ITEMNUM")));
	/*     */           }
	/*     */         }
	/*     */       }
	/* 167 */       structuredata.setParentAsCurrent();
	/*     */     }
	/* 169 */     integrationLogger.debug("Leaving PROutExt.setDataOut");
	/* 170 */     return structuredata;
	/*     */   }
	/*     */   
	/*     */   public boolean isProjectInstalled()
	/*     */     throws MXException
	/*     */   {
	/* 177 */     return getMaxIfaceControl().isControlExists(getExtSystem(), "PROJSEND");
	/*     */   }
	/*     */   
				//Modified by Comm-IT for GFS Integration project
	            /*public String getDestTypeCode(StructureData structuredata, String s)
	              throws MXException, RemoteException
	            {
		          integrationLogger.debug("Entering PROutExt.getDestTypeCode");
		          ControlsCache maxifacecontrol = getMaxIfaceControl();
		          Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
		          String s1 = "";
		          String s2 = translate.toInternalString("CATEGORY", structuredata.getCurrentData("CATEGORY"), this.siteId, this.orgId);
		          boolean flag = structuredata.getCurrentDataAsBoolean("ISSUE");
		          boolean flag1 = structuredata.getParentData("INTERNAL").equals("1");
		          if (this.debug) {
			          integrationLogger.debug("ISSUE: " + structuredata.getCurrentData("ISSUE"));
	              }
		          if (this.debug) {
			          integrationLogger.debug("INTERNAL: " + structuredata.getParentData("INTERNAL"));
	              }
		          if (this.debug) {
			          integrationLogger.debug("GENITEM: " + this.genitem);
	              }
		          if (this.debug) {
			          integrationLogger.debug("GENSTORE: " + this.genstore);
	              }
		          if ((flag) && (!flag1))
	              {
			          s1 = maxifacecontrol.getValueControl(getExtSystem(), "DTC_EXP", this.orgId, this.siteId);
	              }
		          else if ((!flag) && (s2 != null) && (s2.equals("STK")) && ((this.genitem == null) || (this.genitem.equals("")) || (s.equals("OA"))) && ((this.genstore == null) || (this.genstore.equals(""))))
	              {
		        	  s1 = maxifacecontrol.getValueControl(getExtSystem(), "DTC_INV", this.orgId, this.siteId);
	              }
		          else if ((!flag) && (!flag1))
	              {
		        	  s1 = maxifacecontrol.getValueControl(getExtSystem(), "DTC_EXP", this.orgId, this.siteId);
		        	  integrationLogger.debug("getDestTypeCode 3");
	              }
		          else if (flag1)
	              {
		        	  throw new MXApplicationException("iface", "oa-intreqerror");
	              }
		          if (this.debug) {
		        	  integrationLogger.debug("v_DestinationTypeCode  = " + s1);
	              }
		          integrationLogger.debug("Leaving PROutExt.getDestTypeCode");
		          return s1;
	            }*/
				//End of changes by Comm-IT for GFS Integration project
	/*     */   
	/*     */   public void setProjTask(StructureData structuredata, MboRemote pr)
	/*     */     throws MXException, RemoteException
	/*     */   {
	/* 224 */     ERPOutExtCustom erpout = new ERPOutExtCustom(getUserInfo());
	/* 225 */     erpout.setProjTask(structuredata, pr);
	/*     */   }
	/*     */   
	/*     */   public void setOAAssetNum(StructureData structuredata, MboRemote pr)
	/*     */     throws MXException, RemoteException
	/*     */   {
	/* 234 */     ERPOutExtCustom erpout = new ERPOutExtCustom(getUserInfo());
	/* 235 */     erpout.setOAAssetNum(structuredata, pr);
	/*     */   }

}
