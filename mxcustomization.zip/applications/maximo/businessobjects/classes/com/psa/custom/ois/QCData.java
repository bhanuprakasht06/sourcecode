/*
 * Modification history
 * xx-xx-2006	HYC	NA			Creation
 * xx-09-2007	AGD	SR-110	Make calculation of duration in double instead of int
 */
package com.psa.custom.ois;


public class QCData extends OISData  {

	private String actStartDT; //Format: YYYYMMDDHHMM
	private String actEndDT;   //Format: YYYYMMDDHHMM
	private boolean excluded;
	
	
	public QCData() {
		super();
	}


//	Begin modification SR-110
//	public QCData(String assetID, int numContainer, int duration,  String actStartDT, String actEndDT) {
	public QCData(String assetID, int numContainer, double duration,  String actStartDT, String actEndDT) {
//	End modification SR-110
		super(assetID, numContainer, duration);
		this.actStartDT = actStartDT;
		this.actEndDT = actEndDT;
	}


	public String getActEndDT() {
		return actEndDT;
	}


	public void setActEndDT(String actEndDT) {
		this.actEndDT = actEndDT;
	}


	public String getActStartDT() {
		return actStartDT;
	}


	public void setActStartDT(String actStartDT) {
		this.actStartDT = actStartDT;
	}


	public int compareTo(Object anotherQCData) throws ClassCastException {	    
		if (!(anotherQCData instanceof QCData))
	      throw new ClassCastException("A QCData object expected.");
	    
		//Sort the object by Asset ID follow by Activity Start Date & Time
		/*
		 * SR-45 AGD : add a new sorting field - end date/time
		 * This caters for cases of several readings with the same start time but with different end time
		 */
		String sortStr = this.getAssetID() + this.getActStartDT() + this.getActEndDT();
		String anotherSortStr = ((QCData)anotherQCData).getAssetID() + ((QCData)anotherQCData).getActStartDT()
				+ ((QCData)anotherQCData).getActEndDT();

	    return sortStr.compareTo(anotherSortStr) ;    
	}


	public boolean isExcluded() {
		return excluded;
	}


	public void setExcluded(boolean excluded) {
		this.excluded = excluded;
	}


	public boolean isActDateOverlapped(){
		
		//Assumation: Overlap is only between 2 days 
		//i.e. current day overlap to the next day
		
		String actStartDate = actStartDT.substring(0,8);
		String actEndDate = actEndDT.substring(0,8);
		String actEndTime = actEndDT.substring(8,12);
		
		if(actStartDate.compareTo(actEndDate)!=0 ){
			if(!(actEndTime.equals("0000"))){
				return true;
			}
		}
		
		return false;
		
	}
	
}
