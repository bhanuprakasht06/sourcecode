package com.psa.custom.sms;

import java.rmi.RemoteException;

import psdi.app.calendar.CalendarRemote;
import psdi.app.calendar.CalendarSetRemote;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXException;

/*
 * Author: BTE
 * 08 MAR 2006 - Initial version
 */
public class SMSCalendar extends MicSetIn {
	/*
	 * Variables
	 */
    private UserInfo userInfo;
    private static SMSConstant SMS = new SMSConstant();
    
    
	/*
	 * Author: BTE
	 * 08 MAR 2006 - Constructor
	 */    
    public SMSCalendar(UserInfo userInfo) throws MXException, RemoteException {
        this.userInfo = userInfo;
    }

    
	/*
	 * Author: BTE
	 * 08 MAR 2006 - Getter for CalNum 
	 */
    public String getCalNum(String orgid, String ic) throws MXException, RemoteException {

        INTEGRATIONLOGGER.debug("Entering getCalNum");
        
        if(orgid == null || ic == null)
            return null;
                
        CalendarSetRemote calendarSet = (CalendarSetRemote)MXServer.getMXServer().getMboSet(SMS.CALENDAR, userInfo);
        
        CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
        combinewhereclauses.addWhere("ORGID= :1");
        combinewhereclauses.addWhere("IC= :2");
        String s = combinewhereclauses.getWhereClause();
        
        if(s != null)
        {
            if(s != SMS.EMPTY)
            {
                SqlFormat sqlformat = new SqlFormat(userInfo, s);
                sqlformat.setObject(1, SMS.CALENDAR, SMS.ORGID, orgid);
                sqlformat.setObject(2, SMS.CALENDAR, SMS.IC, ic);
                calendarSet.setWhere(sqlformat.format());
                if(!calendarSet.isEmpty())
                {
                    CalendarRemote labor = (CalendarRemote)calendarSet.getMbo(0);
                    
                    if(!labor.isNull(SMS.CALNUM)) {
                        INTEGRATIONLOGGER.debug("Leaving getCalNum");
                        return labor.getString(SMS.CALNUM);
                        
                    }
                }
            }
        }
        
        INTEGRATIONLOGGER.debug("Leaving getCalNum");
        return null;
    }

}