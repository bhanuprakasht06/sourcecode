/*    */ package com.psa.custom.oa12i;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.app.po.PORemote;
/*    */ import psdi.app.po.POSetRemote;
/*    */ import psdi.iface.mic.StructureData;
/*    */ import psdi.iface.migexits.UserExit;
/*    */ import psdi.mbo.SqlFormat;
/*    */ import psdi.server.MXServer;
/*    */ import psdi.util.CombineWhereClauses;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.logging.MXLogger;
/*    */ 
/*    */ public class ReceiptInUserExtCustom
/*    */   extends UserExit
/*    */ {
/*    */   public StructureData setUserValueIn(StructureData irData, StructureData erData)
/*    */     throws MXException, RemoteException
/*    */   {
/* 28 */     integrationLogger.debug("Entering setUserValueIn");
/* 30 */     if (!irData.isCurrentDataNull("PONUM"))
/*    */     {
/* 32 */       String ponum = irData.getCurrentData("PONUM");
/* 33 */       integrationLogger.debug("PONUM: " + ponum);
/*    */       
/* 35 */       String siteid = getSite(ponum);
/* 36 */       irData.setCurrentData("SITEID", siteid);
/* 37 */       irData.setCurrentData("POSITEID", siteid);
/*    */     }
/* 40 */     integrationLogger.debug("Leaving setUserValueIn");
/* 41 */     return irData;
/*    */   }
/*    */   
/*    */   public String getSite(String ponum)
/*    */     throws MXException, RemoteException
/*    */   {
/* 50 */     integrationLogger.debug("Entering getSite");
/*    */     
/* 52 */     POSetRemote poSet = (POSetRemote)MXServer.getMXServer().getMboSet("PO", this.userInfo);
/*    */     
/* 54 */     CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
/* 55 */     combinewhereclauses.addWhere("PONUM= :1");
/* 56 */     String s = combinewhereclauses.getWhereClause();
/* 58 */     if ((s != null) && (s != ""))
/*    */     {
/* 60 */       SqlFormat sqlformat = new SqlFormat(this.userInfo, s);
/* 61 */       sqlformat.setObject(1, "PO", "PONUM", ponum);
/* 62 */       poSet.setWhere(sqlformat.format());
/* 63 */       if (!poSet.isEmpty())
/*    */       {
/* 65 */         PORemote po = (PORemote)poSet.getMbo(0);
/* 66 */         if (!po.isNull("SITEID"))
/*    */         {
/* 68 */           integrationLogger.debug("SITEID: " + po.getString("SITEID"));
/* 69 */           integrationLogger.debug("Leaving getSite");
/* 70 */           return po.getString("SITEID");
/*    */         }
/*    */       }
/*    */     }
/* 75 */     integrationLogger.debug("Leaving getSite");
/* 76 */     return null;
/*    */   }
/*    */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.ReceiptInUserExtCustom
 * JD-Core Version:    0.7.0.1
 */