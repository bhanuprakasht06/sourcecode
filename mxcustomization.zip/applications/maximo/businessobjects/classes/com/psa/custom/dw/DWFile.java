/**
 * @author	HCHA
 * Date		Apr 28, 2006
 * Comment	Write DW Output File
 */
package com.psa.custom.dw;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.io.IOException;


/**
 * @author		HCHA
 * @class		DWFile
 * @date		Apr 28, 2006
 * @function	Write DW Output File
 */
public class DWFile {
	
	private String delimiter;
	private String outFileName;
	private File outFile;
	private FileWriter fWriter;
	private BufferedWriter bWriter;
	private long transRecCount;
	
	/**
	 * @param outFileName
	 * @param delimiter
	 */
	public DWFile(String outFileName, String delimiter) 
		throws IOException
	{	
		this.delimiter = delimiter;
		this.outFileName = outFileName;
		outFile = new File(this.outFileName);
		fWriter = new FileWriter(outFile);
		bWriter = new BufferedWriter(fWriter);
		transRecCount = 0;
	}
	
	public void writeHeader(String description)
		throws IOException
	{
		ArrayList lst = new ArrayList();
		
		//Record Type
		lst.add("0");
		
		//Processing Date Time
		Date curDate = new Date();
        DateFormat fileDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String curDateStr=fileDateFormat.format(curDate);
		lst.add(curDateStr);
		
		//Journal Source
		lst.add(padString("JC"," ",25,false));
		
		//Description
		lst.add(padString(description," ",60,false));	
		
		writeRecord(lst);
		
	}
	
	public void writeTrailer(String totalDebit, String totalCredit)
		throws IOException
	{
		ArrayList lst = new ArrayList();
		
		//Record Type
		lst.add("2");
		
		//No of Records
		Long count = new Long(transRecCount);
		lst.add(padString(count.toString(),"0",15,true));
		
		//No. of Amount Fields
		lst.add("2");
		
		//Total Debit Amt
		lst.add(totalDebit);
		
		//Total Credit Amt
		lst.add(totalCredit);
		
		writeRecord(lst);
		
	}
	
	public void writeRecord(ArrayList lst)
		throws IOException
	{
		String writeline= new String();
		
		for (int i=0; i < lst.size(); i++) {

        	writeline += (String)lst.get(i)+ delimiter;        	
        }

		bWriter.write(writeline);
		bWriter.newLine();
		
	}
	
	public void writeTransRec(ArrayList lst)
		throws IOException
	{
		
		transRecCount++;
		writeRecord(lst);	
	}
	
	
	public static String padString(String inputStr, String padChar, int opStrSize, boolean padFront)
	{
		String opStr = new String(); 
		
		for(int i=0; i<(opStrSize-inputStr.length()); i++){
			opStr+=padChar;
		}
		
		if(padFront){
			opStr = opStr + inputStr; 
		}
		else{
			opStr = inputStr + opStr;
		}
		
		return opStr;
	}
	
	public void close()
		throws IOException
	{
        bWriter.close();
        fWriter.close();
	}
	
}
