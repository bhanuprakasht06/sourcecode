package com.psa.custom.common;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.rmi.RemoteException;
import java.sql.*;
import psdi.app.location.*;
import psdi.iface.mic.MicUtil;
import psdi.iface.mic.StructureData;
import psdi.iface.migexits.UserExit;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class Namespaceuser extends UserExit
{
	
	 public Namespaceuser() throws MXException, RemoteException
	 {
	 }	
	
	 public StructureData setUserValueOut(StructureData erData) throws MXException, RemoteException 
	 {
		erData.breakData();
	        StructureData irData = (StructureData)erData.clone();
	        irData.breakData();
		irData.setAsCurrent();


		
		// System.out.println("This is user exit class to remove namespace");
		 return cloneData(erData,"","",false);
	       
	 }
}