/*    */ package com.psa.custom.oa12i;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import psdi.iface.mic.StructureData;
/*    */ import psdi.iface.migexits.UserExit;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXException;
/*    */ 
/*    */ public class ProjTxnOutExtUser
/*    */   extends UserExit
/*    */ {
/*    */   public StructureData setUserValueOut(StructureData irData)
/*    */     throws MXException, RemoteException
/*    */   {
/* 28 */     ERPOutExtCustom erpoutext = new ERPOutExtCustom(getUserInfo());
/* 29 */     if (!irData.isCurrentDataNull("OA_EXPENDTYPE"))
/*    */     {
/* 31 */       MboRemote worktype = erpoutext.getWorkTypeMbo(irData.getCurrentDataAsString("OA_EXPENDTYPE"), irData.getCurrentData("ORGID"));
/* 32 */       irData.setCurrentData("OA_EXPENDTYPE", worktype.getString("wtypedesc"));
/*    */     }
/* 34 */     return irData;
/*    */   }
/*    */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.ProjTxnOutExtUser
 * JD-Core Version:    0.7.0.1
 */