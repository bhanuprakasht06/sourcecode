/*
 * Created  by BCT 
 * 
 *  
 * This cron is used for  Reconciling check between OPA Oracel transaction to Maximo.
 * 
 * 
 * 
 */
package com.psa.custom.ofrecon;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.mail.MessagingException;

import java.lang.Math;
import java.math.BigDecimal;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.exchangerate.SimpleFilenameFilter;
import com.psa.custom.ois.MxLog;
import psdi.app.system.CrontaskParamInfo;
import com.psa.custom.common.MxZip;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class GFSPAInterfaceReconCron extends SimpleCronTask {
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	private static final String DATE_TIME_FORMAT = "yyyyMMdd";


	private String adminEmail;
	private String adminEmailSub;
	private String outPutDirectory;
	private String tempProcessFolder;
	private String processFolder;
	private String backupFileFolder;
	private String importFileName;
	private String splitTag;
	private String unzipCmd;
	private MxEmail email;
	protected MxLog mxLog;
	protected MxLog withOutIdLog;
	private String logFileName;
	private String logFilePath;
	private String withOutIdLogName;
	private String withOutIdLogPath;
	private boolean enableLog;
	private File fileDirctory;
	private String transId;
	private ArrayList parsdata;



	public GFSPAInterfaceReconCron() {
		adminEmail=null;
		adminEmailSub=null;
		outPutDirectory=null;
		tempProcessFolder=null;
		processFolder=null;
		backupFileFolder=null;
		importFileName=null;
		unzipCmd=null;
		email=null;
		mxLog=new MxLog();
		withOutIdLog=new MxLog();
		logFileName=null;
		logFilePath=null;
		withOutIdLogName=null;
		withOutIdLogPath=null;
		fileDirctory=null;
		enableLog=false;

	}


	public CrontaskParamInfo[] getParameters() throws MXException,
	RemoteException {

		CrontaskParamInfo[] params = new CrontaskParamInfo[12];

		params[0] = new CrontaskParamInfo();
		params[0].setName("ADMINEMAIL");
		params[0].setDescription("ADMINEMAIL", "Administrator Email ID");

		params[1] = new CrontaskParamInfo();
		params[1].setName("ADMINEMAILSUB");
		params[1].setDescription("ADMINEMAILSUB", "Administrator Email Subject");


		params[2] = new CrontaskParamInfo();
		params[2].setName("TEMPPROCESSFOLDER");
		params[2].setDescription("TEMPPROCESSFOLDER", " Temp Process folder file path");

		params[3] = new CrontaskParamInfo();
		params[3].setName("PROCESSFOLDER");
		params[3].setDescription("PROCESSFOLDER", "Process folder file path");

		params[4] = new CrontaskParamInfo();
		params[4].setName("BACKUPFILEFOLDER");
		params[4].setDescription("BACKUPFILEFOLDER", "Back Up file folder path");

		params[5] = new CrontaskParamInfo();
		params[5].setName("FILENAME");
		params[5].setDescription("FILENAME", "Processing file name");

		params[6] = new CrontaskParamInfo();
		params[6].setName("SPLITTAG");
		params[6].setDescription("SPLITTAG", "SPLITTAG");

		params[7] = new CrontaskParamInfo();
		params[7].setName("UNZIPCMD");
		params[7].setDescription("UNZIPCMD", "Unzip file command");

		params[8] = new CrontaskParamInfo();
		params[8].setName("LOGFILENAME");
		params[8].setDescription("LOGFILENAME", "Log File Name");

		params[9] = new CrontaskParamInfo();
		params[9].setName("LOGFILEPATH");
		params[9].setDescription("LOGFILEPATH", "Log File Path");

		params[10] = new CrontaskParamInfo();
		params[10].setName("ENABLELOG");
		params[10].setDescription("CommonCron","Enable log output('Y' or 'N').");
		params[10].setDefault("Y");
		
		params[11] = new CrontaskParamInfo();
		params[11].setName("WITHOUTIDLOGFILENAME");
		params[11].setDescription("WITHOUTIDLOGFILENAME", "Log File Path For Data Without Id");
		
		return params;
	}



	private void refreshSettings() throws RemoteException, MXException
	{

		try
		{
			adminEmail=getParamAsString("ADMINEMAIL");
			adminEmailSub=getParamAsString("ADMINEMAILSUB");
			tempProcessFolder=getParamAsString("TEMPPROCESSFOLDER");

			processFolder=getParamAsString("PROCESSFOLDER");
			fileDirctory=new File(processFolder);

			backupFileFolder=getParamAsString("BACKUPFILEFOLDER");
			//	importFileName=getParamAsString("FILENAME");

			DateFormat fileDateFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
			String todayDate=fileDateFormat.format(new Date());
			importFileName = getParamAsString("FILENAME");
			importFileName=importFileName.replaceAll("yyyyMMdd",todayDate);
			splitTag=getParamAsString("SPLITTAG");
			unzipCmd=getParamAsString("UNZIPCMD");
			logFileName=getParamAsString("LOGFILENAME");
			logFilePath=getParamAsString("LOGFILEPATH");
			enableLog=(getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
			withOutIdLogName=getParamAsString("WITHOUTIDLOGFILENAME");
			withOutIdLogPath=getParamAsString("LOGFILEPATH");
			Date curDate = new Date();
			DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
			String logFileDate = fileDateTimeFormat.format(curDate);
			logFileName = logFileName.replaceAll("yyyyMMdd",logFileDate);
			logFilePath =logFilePath+logFileName;
			withOutIdLogPath=withOutIdLogPath+withOutIdLogName;
			mxLog.setLogFilePath(logFilePath);
			mxLog.setLogTag(getName());
			mxLog.setEnabled(enableLog);
			mxLog.createLogFile();
			withOutIdLog.setLogFilePath(withOutIdLogPath);
			withOutIdLog.setLogTag(getName());
			withOutIdLog.setEnabled(enableLog);
			withOutIdLog.createLogFile();

		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}


	}

	private boolean isReqParamSet() {
		if (adminEmail.equalsIgnoreCase(""))
			return false;
		if (adminEmailSub.equalsIgnoreCase(""))
			return false;

		if (tempProcessFolder.equalsIgnoreCase(""))
			return false;
		if (processFolder.equalsIgnoreCase(""))
			return false;
		if (backupFileFolder.equalsIgnoreCase(""))
			return false;
		if (importFileName.equalsIgnoreCase(""))
			return false;
		if (splitTag.equalsIgnoreCase(""))
			return false;
		if (unzipCmd.equalsIgnoreCase(""))
			return false;
		if (logFileName.equalsIgnoreCase(""))
			return false;
		if (logFilePath.equalsIgnoreCase(""))
			return false;
		if (withOutIdLogName.equalsIgnoreCase(""))
			return false;
		
		return true;
	}
	public void init() throws MXException {
		super.init();

		email = new MxEmail(adminEmail);
		mxLog = new MxLog();

	}

	private String genEmail(Exception e) {

		// Form Email Message
		String emailMsg = "Date: " + new Date() + "\n";
		emailMsg += "Error in CronTask: " + getName() + "\n";
		emailMsg += "Error Message: " + e.getMessage() + "\n";
		emailMsg += "Detail:\n";
		emailMsg += e.toString() + "\n";
		StackTraceElement element[] = e.getStackTrace();
		for (int i = 0; i < element.length; i++) {
			emailMsg += "\tat " + element[i].toString() + "\n";
		}

		return emailMsg;
	}

	public void cronAction() {

		try
		{
			refreshSettings();
			if(isReqParamSet())
			{
				String fileRead=tempProcessFolder+importFileName;
				int dotPos = fileRead.lastIndexOf(".");
				String actualFile=fileRead.substring(0,dotPos);

				if(checkFileExist(importFileName))
				{
					MxFileCopy.fileCopy(processFolder+importFileName,tempProcessFolder+importFileName);
					
					//WMJ: do backup of file before processing
					MxFileCopy.fileCopy(processFolder+importFileName,backupFileFolder+importFileName);
					//WMJ: end backup of file before processing
					
					File deleteZipProcessed = new File(processFolder+importFileName);
					deleteZipProcessed.delete();
					if(unZipFileTemp())
					{
						processFolderData(actualFile);

						File processedFile = new File(actualFile);
						processedFile.delete(); 
						mxLog.writeLog("Cron:"+getName()+":File process is completed.");
					}

				}
				else
				{
					integrationLogger.debug("File does not found. cron job is Stopped.");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			genEmail(e);
		}

	}

	public boolean checkFileExist (String importFileName) throws MessagingException {

		SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);

		File checkFile[] = fileDirctory.listFiles(filter);

		String currentFileName=importFileName.substring(0,36);

		if(checkFile!=null)
		{
			for (int j = 0; j < checkFile.length; j++) 
			{
				if(checkFile[j].getName().startsWith(currentFileName)){
					integrationLogger.debug("File exists process the file data.");
					return true;
				}
			}


		}
		integrationLogger.debug("File does not exists.");
		mxLog.writeLog("File not found in Processing Folder");
		MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,"File not found in Processing Folder");
		return false;
	}

	private boolean unZipFileTemp() throws Exception
	{
		boolean fileUNZipCompleted=true;
		try{
			String zipoutputFilePath = tempProcessFolder+importFileName;
			String cmd = unzipCmd + " " + zipoutputFilePath;
			int retcode= MxZip.unzipFile(cmd);
			if (retcode != 0){
				fileUNZipCompleted=false;
			}	
		}
		catch(Exception e)
		{
			mxLog.writeLog("File Unzip is failed:"+getName()+":"+e.getMessage());
		}
		return fileUNZipCompleted;

	}

	public void processFolderData(String actualFile) throws MXException,Exception {

			
		try{
			String errorMessage="";
			BufferedReader  flatfileReader = new BufferedReader(new FileReader(actualFile));

			String currentLine;
			if((currentLine=flatfileReader.readLine())!=null)
			{

				String recHeadertype;
				int lineCount = 0;

				if(currentLine.length() != 0){
					String[] getHeaderInfo=currentLine.split(splitTag);

					int totalRecords=Integer.parseInt(getHeaderInfo[3].trim());
					
					BigDecimal acctRawCostHeader=new BigDecimal("0.00");
					BigDecimal acctRawCostLine=new BigDecimal("0.00");
					
					if(!(getHeaderInfo[4].equals("")))
					{
						acctRawCostHeader=new BigDecimal(getHeaderInfo[4]);
					}               	 
					recHeadertype = currentLine.substring(0, 1);
					String lineContent=null;
					if(recHeadertype.equals("0"))
					{
						while ((lineContent=flatfileReader.readLine())!= null) 
						{
							try {
								String[] lineData=lineContent.split(splitTag);
								if(!(lineData[12].equals("")))
								{
									acctRawCostLine=acctRawCostLine.add(new BigDecimal(lineData[12]));
								}
								lineCount++;
							
							} catch (Exception e) {
								mxLog.writeLog("Error on while Processing the folder data:"+getName()+":"+e.getMessage());
							}
						}
					}
					if(lineCount!=(totalRecords))
					{
						errorMessage=errorMessage+"\nTotal Record count is wrong. \n\n";
					}
					if((acctRawCostHeader.compareTo(acctRawCostLine))!= 0)
					{
						errorMessage=errorMessage+"\n Accounted RAW COST differs between header and line. \n\n";
					}

					if(errorMessage.length()>0)
					{
						flatfileReader.close();
						String fileRead=backupFileFolder+importFileName;
						int dotPos = fileRead.lastIndexOf(".");
						String backupfile=fileRead.substring(0,dotPos);
						File deleteProcessedFile = new File(actualFile);
						deleteProcessedFile.delete();
						mxLog.writeLog(errorMessage +" \nPlease check the Backup folder and process again."+backupfile);
						MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessage+" \nPlease check the Backup folder and process again."+backupfile);
					}


					else if((lineCount==(totalRecords))&&(acctRawCostHeader.compareTo(acctRawCostLine)==0))
					{

						Collection fileData=extractFileRead(actualFile);
						processOFTransData(fileData);
						fileData.clear();
						flatfileReader.close();               	 
					}           
				}

			}
		
		}
		catch (Exception e) {
			mxLog.writeLog("Error on while Processing the folder data:"+getName()+":"+e.getMessage());
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,"Error on while Processing the folder data:"+getName()+":"+e.getMessage());
		}
		

	}

	private void processOFTransData(Collection processdata) throws MXException,RemoteException,ParseException, MessagingException
	{
		String[] errorMessages={"","","","",""};

		

			Iterator processOFReconData=processdata.iterator();
			String OfaMessage;
			Date reconDate;
			String transidAndMbo;
			String recosileAmt;
			String objectName = null;
			
			List<String> transIDList=new ArrayList<String>();
			Set<String> reconSet=new LinkedHashSet<String>();
			while(processOFReconData.hasNext())
			{
				try{
				 parsdata=(ArrayList) processOFReconData.next();
				parsdata.size();
				recosileAmt=(String) parsdata.get(12);
				transidAndMbo=(String) parsdata.get(15);
				String[] getactualMbo=transidAndMbo.split(":");
				reconDate=MXServer.getMXServer().getDate();
				double reccosiledAmt=0.0;
				if(!(recosileAmt.equals("")))
				{
					reccosiledAmt=Double.parseDouble(recosileAmt);
				}

				if(getactualMbo!=null && !transidAndMbo.equalsIgnoreCase("") )
				{
					objectName=getactualMbo[0].trim();
					transId=getactualMbo[1].trim();

					if (!objectName.equalsIgnoreCase("")&& !transId.equalsIgnoreCase("")) {
						
					 if(objectName.trim().equalsIgnoreCase("MATUSETRANS") & !transId.trim().equalsIgnoreCase(""))
					{
						MboSetRemote getMatUseTransSet=MXServer.getMXServer().getMboSet("MATUSETRANS",getRunasUserInfo());
						SqlFormat matUseTransSql=new SqlFormat("MATUSETRANSID='"+transId+"'");
						getMatUseTransSet.setWhere(matUseTransSql.format());
						getMatUseTransSet.reset();
						if(!getMatUseTransSet.isEmpty() & getMatUseTransSet!=null)
						{
							MboRemote matUseTransMbo=getMatUseTransSet.getMbo(0);
							double loadedCost=matUseTransMbo.getDouble("LINECOST");
							boolean reconciliation=matUseTransMbo.getBoolean("RECONCILIATION");
							if (reconciliation && Collections.frequency(transIDList, transidAndMbo)==0 ) {
								
								if (errorMessages[0].equalsIgnoreCase("") ) {
									errorMessages[0]="Below Duplicate records were found in the file:"+"\n\n"+parsdata;
									mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
								}
								 
								else if (!errorMessages[0].contains(parsdata.toString())) {
									errorMessages[0]=errorMessages[0]+"\n\n"+parsdata;
									mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
									}
								if (!matUseTransMbo.getString("OFTRANSMESSAGE").contains("Duplicate record found.")&& !matUseTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
									matUseTransMbo.setValue("OFTRANSMESSAGE",matUseTransMbo.getString("OFTRANSMESSAGE")+"Duplicate record found. ",MboConstants.NOACCESSCHECK);
									getMatUseTransSet.save();
								}
								else if(!matUseTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
									matUseTransMbo.setValue("OFTRANSMESSAGE",matUseTransMbo.getString("OFTRANSMESSAGE").replaceAll("Duplicate record found. ", "Multiple Duplicate record found. "),MboConstants.NOACCESSCHECK);
									getMatUseTransSet.save();
								}	
								
							}
							if ((!reconciliation && Collections.frequency(transIDList, transidAndMbo)>=0)|| (reconciliation &&Collections.frequency(transIDList, transidAndMbo)>0) ) {
							if(Collections.frequency(transIDList, transidAndMbo)>=1)
							{
								if (errorMessages[0].equalsIgnoreCase("") ) {
									errorMessages[0]="Below Duplicate records were found in the file"+"\n\n"+parsdata;
									mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
								}
								 
								else if (!errorMessages[0].contains(parsdata.toString())) {
									errorMessages[0]=errorMessages[0]+"\n\n"+parsdata;
									mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
									}
								if (!matUseTransMbo.getString("OFTRANSMESSAGE").contains("Duplicate record found.")&& !matUseTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
									matUseTransMbo.setValue("OFTRANSMESSAGE",matUseTransMbo.getString("OFTRANSMESSAGE")+"Duplicate record found. ",MboConstants.NOACCESSCHECK);
									getMatUseTransSet.save();
								}
								else if(!matUseTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
									matUseTransMbo.setValue("OFTRANSMESSAGE",matUseTransMbo.getString("OFTRANSMESSAGE").replaceAll("Duplicate record found. ", "Multiple Duplicate record found. "),MboConstants.NOACCESSCHECK);
									getMatUseTransSet.save();
								}
								transIDList.add(transidAndMbo);
								continue;
							}
							if(reccosiledAmt!=loadedCost)
							{
								if (errorMessages[1].equalsIgnoreCase("") ) {
									errorMessages[1]="Line cost does not match with the credited/debited cost for these records:"+"\n\n"+parsdata;
									mxLog.writeLog("Line cost does not match with the credited/debited cost for the record:"+parsdata);
								}
								 
								else if (!errorMessages[1].contains(parsdata.toString())) {
									errorMessages[1]=errorMessages[1]+"\n\n"+parsdata;
									mxLog.writeLog("Line cost does not match with the credited/debited cost for the record:"+parsdata);
									}
								if (!matUseTransMbo.getString("OFTRANSMESSAGE").contains("Line cost does not match with the credited/debited cost.")) {
									matUseTransMbo.setValue("OFTRANSMESSAGE",matUseTransMbo.getString("OFTRANSMESSAGE")+ "Line cost does not match with the credited/debited cost. ",MboConstants.NOACCESSCHECK);
								}
								matUseTransMbo.setValue("RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
								matUseTransMbo.setValue("OFAMOUNT", recosileAmt,MboConstants.NOACCESSCHECK);
								matUseTransMbo.setValue("RECONCILIATION",true,MboConstants.NOACCESSCHECK);
								getMatUseTransSet.save();
								transIDList.add(transidAndMbo);
								continue;
							}
							matUseTransMbo.setValue("RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
							matUseTransMbo.setValue("OFAMOUNT", recosileAmt,MboConstants.NOACCESSCHECK);
							if (matUseTransMbo.getString("OFTRANSMESSAGE").equalsIgnoreCase("")) {
								matUseTransMbo.setValue("OFTRANSMESSAGE", "",MboConstants.NOACCESSCHECK);
							}

							if(loadedCost==reccosiledAmt && matUseTransMbo.getString("OFTRANSMESSAGE").equalsIgnoreCase(""))
							{
								matUseTransMbo.setValue("RECONCILIATION",true,MboConstants.NOACCESSCHECK);
							}
							else
							{
								matUseTransMbo.setValue("RECONCILIATION",false,MboConstants.NOACCESSCHECK);
							}


							getMatUseTransSet.save();
							transIDList.add(transidAndMbo);
							
							
						}
							else {
								if (!reconSet.contains(transidAndMbo)) {
									if (errorMessages[0].equalsIgnoreCase("") ) {
										errorMessages[0]="Below Duplicate records were found in the file"+"\n\n"+parsdata;
										mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
									}
									 
									else if (!errorMessages[0].contains(parsdata.toString())) {
										errorMessages[0]=errorMessages[0]+"\n\n"+parsdata;
										mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
										}
									if (!matUseTransMbo.getString("OFTRANSMESSAGE").contains("Duplicate record found.")&& !matUseTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
										matUseTransMbo.setValue("OFTRANSMESSAGE",matUseTransMbo.getString("OFTRANSMESSAGE")+"Duplicate record found. ",MboConstants.NOACCESSCHECK);
										getMatUseTransSet.save();
									}
									else if(!matUseTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
										matUseTransMbo.setValue("OFTRANSMESSAGE",matUseTransMbo.getString("OFTRANSMESSAGE").replaceAll("Duplicate record found. ", "Multiple Duplicate record found. "),MboConstants.NOACCESSCHECK);
										getMatUseTransSet.save();
									}
									reconSet.add(transidAndMbo);
							}
							}
							}else
						{
								if (errorMessages[2].equalsIgnoreCase("")) {
									errorMessages[2]="Invalid Transaction ID's Found for these records:"+parsdata;
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}
								else if (!errorMessages[2].contains(parsdata.toString())) {
									errorMessages[2] = errorMessages[2]+"\n\n"+parsdata;
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
									}
						}
					}

					else if(objectName.trim().equalsIgnoreCase("LABTRANS") & !transId.trim().equalsIgnoreCase(""))
					{
						MboSetRemote getLabTransSet=MXServer.getMXServer().getMboSet("LABTRANS",getRunasUserInfo());
						SqlFormat labTransSql=new SqlFormat("LABTRANSID='"+transId+"'");
						getLabTransSet.setWhere(labTransSql.format());
						getLabTransSet.reset();
						if(!getLabTransSet.isEmpty() & getLabTransSet!=null)
						{
							MboRemote labTransMbo=getLabTransSet.getMbo(0);
							double loadedCost=labTransMbo.getDouble("LINECOST");
							boolean reconciliation=labTransMbo.getBoolean("RECONCILIATION");
							if (reconciliation && Collections.frequency(transIDList, transidAndMbo)==0 ) {
								
								if (errorMessages[0].equalsIgnoreCase("") ) {
									errorMessages[0]="Below Duplicate records were found in the file:"+"\n\n"+parsdata;
									mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
								}
								 
								else if (!errorMessages[0].contains(parsdata.toString())) {
									errorMessages[0]=errorMessages[0]+"\n\n"+parsdata;
									mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
									}
								if (!labTransMbo.getString("OFTRANSMESSAGE").contains("Duplicate record found.")&& !labTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
									labTransMbo.setValue("OFTRANSMESSAGE",labTransMbo.getString("OFTRANSMESSAGE")+"Duplicate record found. ",MboConstants.NOACCESSCHECK);
									getLabTransSet.save();
								}
								else if(!labTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
									labTransMbo.setValue("OFTRANSMESSAGE",labTransMbo.getString("OFTRANSMESSAGE").replaceAll("Duplicate record found. ", "Multiple Duplicate record found. "),MboConstants.NOACCESSCHECK);
									getLabTransSet.save();
								}	
								
							}
							if ((!reconciliation && Collections.frequency(transIDList, transidAndMbo)>=0)|| (reconciliation &&Collections.frequency(transIDList, transidAndMbo)>0) ) {
							if(Collections.frequency(transIDList, transidAndMbo)>=1)
							{
								if (errorMessages[0].equalsIgnoreCase("") ) {
									errorMessages[0]="Below Duplicate records were found in the file"+"\n\n"+parsdata;
									mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
								}
								 
								else if (!errorMessages[0].contains(parsdata.toString())) {
									errorMessages[0]=errorMessages[0]+"\n\n"+parsdata;
									mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
									}
								if (!labTransMbo.getString("OFTRANSMESSAGE").contains("Duplicate record found.")&& !labTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
									labTransMbo.setValue("OFTRANSMESSAGE",labTransMbo.getString("OFTRANSMESSAGE")+"Duplicate record found. ",MboConstants.NOACCESSCHECK);
									getLabTransSet.save();
								}
								else if(!labTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
									labTransMbo.setValue("OFTRANSMESSAGE",labTransMbo.getString("OFTRANSMESSAGE").replaceAll("Duplicate record found. ", "Multiple Duplicate record found. "),MboConstants.NOACCESSCHECK);
									getLabTransSet.save();
								}
								transIDList.add(transidAndMbo);
								continue;
							}
							if(reccosiledAmt!=loadedCost)
							{
								if (errorMessages[1].equalsIgnoreCase("") ) {
									errorMessages[1]="Line cost does not match with the credited/debited cost for these records:"+"\n\n"+parsdata;
									mxLog.writeLog("Line cost does not match with the credited/debited cost for the record:"+parsdata);
								}
								 
								else if (!errorMessages[1].contains(parsdata.toString())) {
									errorMessages[1]=errorMessages[1]+"\n\n"+parsdata;
									mxLog.writeLog("Line cost does not match with the credited/debited cost for the record:"+parsdata);
									}
								if (!labTransMbo.getString("OFTRANSMESSAGE").contains("Line cost does not match with the credited/debited cost.")) {
									labTransMbo.setValue("OFTRANSMESSAGE",labTransMbo.getString("OFTRANSMESSAGE")+ "Line cost does not match with the credited/debited cost. ",MboConstants.NOACCESSCHECK);	
								}
								labTransMbo.setValue("RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
								labTransMbo.setValue("OFAMOUNT", recosileAmt,MboConstants.NOACCESSCHECK);
								labTransMbo.setValue("RECONCILIATION",true,MboConstants.NOACCESSCHECK);
								getLabTransSet.save();
								transIDList.add(transidAndMbo);
								continue;
							}
							labTransMbo.setValue("RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
							labTransMbo.setValue("OFAMOUNT", recosileAmt,MboConstants.NOACCESSCHECK);
							if (labTransMbo.getString("OFTRANSMESSAGE").equalsIgnoreCase("")) {
								labTransMbo.setValue("OFTRANSMESSAGE", "",MboConstants.NOACCESSCHECK);	
							}

							if(loadedCost==reccosiledAmt && labTransMbo.getString("OFTRANSMESSAGE").equalsIgnoreCase(""))
							{
								labTransMbo.setValue("RECONCILIATION",true,MboConstants.NOACCESSCHECK);
							}
							else
							{
								labTransMbo.setValue("RECONCILIATION",false,MboConstants.NOACCESSCHECK);
							}


							getLabTransSet.save();
							transIDList.add(transidAndMbo);

						}
							else {
								if (!reconSet.contains(transidAndMbo)) {
									if (errorMessages[0].equalsIgnoreCase("") ) {
										errorMessages[0]="Below Duplicate records were found in the file"+"\n\n"+parsdata;
										mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
									}
									 
									else if (!errorMessages[0].contains(parsdata.toString())) {
										errorMessages[0]=errorMessages[0]+"\n\n"+parsdata;
										mxLog.writeLog("Duplicate Record found for the record:"+parsdata);
										}
									if (!labTransMbo.getString("OFTRANSMESSAGE").contains("Duplicate record found.")&& !labTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
										labTransMbo.setValue("OFTRANSMESSAGE",labTransMbo.getString("OFTRANSMESSAGE")+"Duplicate record found. ",MboConstants.NOACCESSCHECK);
										getLabTransSet.save();
									}
									else if(!labTransMbo.getString("OFTRANSMESSAGE").contains("Multiple Duplicate record found.")) {
										labTransMbo.setValue("OFTRANSMESSAGE",labTransMbo.getString("OFTRANSMESSAGE").replaceAll("Duplicate record found. ", "Multiple Duplicate record found. "),MboConstants.NOACCESSCHECK);
										getLabTransSet.save();
									}
									reconSet.add(transidAndMbo);
								}
							}
							}else
						{
								if (errorMessages[2].equalsIgnoreCase("")) {
									errorMessages[2]="Invalid Transaction ID's Found for these records:"+parsdata;
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}
								else if (!errorMessages[2].contains(parsdata.toString())) {
									errorMessages[2] = errorMessages[2]+"\n\n"+parsdata;
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
									}
						}

					}
					}
					else {
						if (errorMessages[3].equalsIgnoreCase("") ) {
							errorMessages[3]="Unique Maximo ID's Missing for these records:"+"\n\n"+parsdata;
							withOutIdLog.writeLog("Data without Transaction ID:"+parsdata);
						}
						 
						else if (!errorMessages[3].contains(parsdata.toString())) {
							errorMessages[3]=errorMessages[3]+"\n\n"+parsdata;
							withOutIdLog.writeLog("Data without Transaction ID:"+parsdata);
							}
					}
				}
					else
					{
						if (errorMessages[3].equalsIgnoreCase("") ) {
							errorMessages[3]="Unique Maximo ID's Missing for these records:"+"\n\n"+parsdata;
							withOutIdLog.writeLog("Data without Transaction ID:"+parsdata);
						}
						 
						else if (!errorMessages[3].contains(parsdata.toString())) {
							errorMessages[3]=errorMessages[3]+"\n\n"+parsdata;
							withOutIdLog.writeLog("Data without Transaction ID:"+parsdata);
							}
					}
			
			
				}
				catch(Exception e)
				{
					
					if (errorMessages[4].equalsIgnoreCase("") ) {
						errorMessages[4]="Error on while Updating the data into Maximo for these records:"+"\n\n"+parsdata;
						mxLog.writeLog("Erron on while updating data into maximo for this record:"+parsdata);
					}
					 
					else if (!errorMessages[4].contains(parsdata.toString())) {
						errorMessages[4]=errorMessages[4]+"\n\n"+parsdata;
						mxLog.writeLog("Erron on while updating data into maximo for this record:"+parsdata);
						}
					
					
				}
				}
			
			if(errorMessages[0].length()>0)
			{
				MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[0]);
			}
			if(errorMessages[1].length()>0)
			{
				MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[1]);
			}
			if(errorMessages[2].length()>0)
			{
				MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[2]);
			}
			if(errorMessages[3].length()>0)
			{
				MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[3]);
			}
			if(errorMessages[4].length()>0)
			{
				MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[4]);
			}
			
		}

	private Collection extractFileRead(String file) throws IOException {


		Collection col = new ArrayList();
		try
		{

			BufferedReader  flatfileReader = new BufferedReader(new FileReader(file));
			String curLine = flatfileReader.readLine();

			while((curLine = flatfileReader.readLine()) != null)
			{
				String[] data = curLine.split(splitTag);

				ArrayList list =new ArrayList();

				for(int i=0;i<data.length;i++){

					list.add(data[i].trim());
				}


				col.add(list);
			}

			integrationLogger.debug("Flat file parsing is completed");
			flatfileReader.close();
		}
		catch(Exception e)
		{

			mxLog.writeLog("Error On Parsing a flat file:"+getName()+":"+e.getMessage());
			e.printStackTrace();

		}
		return col;
	}


}
