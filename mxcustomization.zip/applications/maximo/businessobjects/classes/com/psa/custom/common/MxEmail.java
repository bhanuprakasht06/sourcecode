/*
 * Modification history
 * xx-xx-2006   BTE     Creation
 * xx-xx-2007   AGD     SR-062
 * 25-07-2007   AGD     SR-103
 * 23-08-2007   AGD     SR-112
 * 17-09-2007   AGD     SR-108  Send T&C for RFQ faxes
 * 15-07-2014	WMJ		EMS-820	[UMS]Switch to using common UMS libraries for sending of faxes
 */
package com.psa.custom.common;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Properties;

import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.Resolver;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


//start of EMS-820
/*import com.psa.common.ums.Contact;
import com.psa.common.ums.Message;
import com.psa.common.ums.MessageRequest;
import com.psa.common.ums.Recipient;
import com.psa.common.ums.Request;
import com.psa.common.ums.CommonUmsProxy;*/
//end of EMS-820

public class MxEmail
{
        // Variables
        private String                          toMail  = null;
        private String                          fromMail        = null;
        private MXServer                        mxserver;
        private static String   UMSSMTP;
        private static boolean  DELTEMPFILE;
        private static String           TERMS;
//      private static final String             UMSSENDER                       = "EMS";
        private static final String             UMSCFGFILE                      = "/opt/psa/rel/config/ums/cfg/ums.cfg";
        private static final String             UMSDEFAULTFOLDER        = "/opt/psa/data/rw/ums/temp/";
        private static final String             UMSDEFAULTFILE          = "EMS";
        private static final String             UMSDEFAULTEXT           = ".html";
        private static final MXLogger   mxLogger                                = MXLoggerFactory.getLogger("maximo.mail");


        /*
         * Author: BTE
         * Date 23 FEB 2006
         * Comment: Constructor
         */
        public MxEmail()
        {
                try {
                        mxserver = MXServer.getMXServer();
                }
                catch (RemoteException e) {
                        mxLogger.error(e.getMessage(), e);
                }

                Properties properties = mxserver.getConfig();
                setFromMail(properties.getProperty("mxe.adminEmail", null));
        }


        /*
         * Author: BTE
         * Date 23 FEB 2006
         * Comment: Constructor
         */
        public MxEmail(String Admin)
        {
                try {
                        mxserver = MXServer.getMXServer();
                }
                catch (RemoteException e) {
                        mxLogger.error(e.getMessage(), e);
                }

                Properties properties = mxserver.getConfig();

                setAdmin(Admin);
                setFromMail(properties.getProperty("mxe.adminEmail", null));
        }


        /*
         * Author: BTE
         * Date 23 FEB 2006
         * Comment: Set administrator
         */
        public void setAdmin(String admin)
        {
                setToMail(admin);
        }


        /*
         * Same as setAdmin but more understandable
         * Author : AGD
         */
        public void setToMail(String to)
        {
                toMail = to;
        }


        /*
         * Author: BTE
         * Date 23 FRB 2006
         * Comment: Set from mail
         */
        public void setFromMail(String from)
        {
                fromMail = from;
        }


        /* Author: BTE
         * Date: 21 FEB 2006
         * Comment: Send email
         */
        public void send(String subject, String message)
        {
                send(subject, message, null, null);
/*              if ((administrator != null) && (fromMail != null))
                {
                        try {
                                MXServer.sendEMail(administrator, fromMail, subject, message);
                        }
                        catch (MessagingException e) {
                                mxLogger.error(e.getMessage(), e);
                        }
                }*/
        }


        /*
         * Send an email with attachment
         * Author : AGD
         */
        public void send(String subject, String message, String attachment, String filename)
        {
                if ((toMail != null) && (fromMail != null))
                {
                        try {
/*                              try {
                                        mxLogger.debug("SMTP="+MXServer.getMXServer().getSystemProperties().getProperty("mail.smtp.host"));
                                }
                                catch (Exception e) { } */
                                MXServer.sendEMail(toMail, fromMail, subject, message, attachment, filename);
                        }
                        catch (javax.mail.MessagingException e) {
                                mxLogger.error(e.fillInStackTrace());
                        }
                }
                else
                        mxLogger.warn("MxEmail.send - Email not sent to: " + toMail + ", from: " + fromMail);
        }
        
      //Start of VO - Add T&C to Email --- Comm-IT ----- Maximo 7.6 Change
        
        public String rfqPath(String filename, String message)
        		throws MXApplicationException
        {
        	String rfqPath = null;
        	
        	if (filename != null)            
        	{
                if (filename.indexOf("/") == -1)
                	filename = UMSDEFAULTFOLDER + filename;
                if (filename.indexOf(".") == -1)
                	filename = filename + UMSDEFAULTEXT;
        	}
        	
        	System.out.println("MxEmail - File " + filename + " created");
        	try
            {
                // Create the temp file attachment that Email will send
                File file = new File(filename);
                FileWriter filewriter = new FileWriter(file);
                filewriter.write(message);
                filewriter.close();
                mxLogger.debug("MxEmail - File " + filename + " created");
            }
        	catch (IOException e)
            {
                    mxLogger.error("MxEmail - File - I/O Exception");
                    String[] param = { filename };
                    throw new MXApplicationException("iface", "ioexception", param, e.fillInStackTrace());
            }   	
        	rfqPath = filename;
            
        	return rfqPath;
        }
        public void send(String subject, String message, String attachment, String filename, String termPath)
        {
            if ((toMail != null) && (fromMail != null))
            {
            	try 
            	{
            		String[] filenames = {filename, termPath};
            		//MXServer.sendEMail(toMail, fromMail, subject, message, attachment, filename);
            		MXServer.sendEMail(toMail, null, null, fromMail, subject, message, null, filenames, null, null);
                }
            	catch (javax.mail.MessagingException e) 
            	{
            		mxLogger.error(e.fillInStackTrace());
            	}
            }
            else
            	mxLogger.warn("MxEmail.send - Email not sent to: " + toMail + ", from: " + fromMail);
        }
      //End of VO - Add T&C to Email --- Comm-IT ----- Maximo 7.6 Change

/*
 * 29-10-2020 BCT: Removal of UMS starts here:
 * 
 */
        

        /*
         * Send data via UMS using email submission
         * Author : AGD
         */
// Begin modification SR-103
//      public void sendViaUMS(String subject, String message, String contactno, int type, String filename)
// Begin modification SR-108
//      public void sendViaUMS(String subject, String message, String contactno, int type, String filename, String userid)
     
 /*       
        public void sendViaUMS(String subject, String message, String contactno, int type, String filename, String userid, String source)
// End modification SR-108
// End modification SR-103
                        throws MXApplicationException
        {
                // Validate a few thing on the file passed in parameter
                if (filename == null)
                        filename = UMSDEFAULTFOLDER + UMSDEFAULTFILE + UMSDEFAULTEXT;
                else
                {
                        if (filename.indexOf("/") == -1)
                                filename = UMSDEFAULTFOLDER + filename;
                        if (filename.indexOf(".") == -1)
                                filename = filename + UMSDEFAULTEXT;
                }

                // Read the UMS configuration file
                try
                {
                        readUMSConfigFile();
                }
                catch (IOException ioe)
                {
                        mxLogger.error("MxEmail.sendViaUMS - Problem reading the UMS configuration file. Exiting");
                        String[] param = { UMSCFGFILE };
                        throw new MXApplicationException("iface", "ioexception", param, ioe);
                }

                try
                {
                        // Create the temp file attachment that UMS will send
                        File file = new File(filename);
                        FileWriter filewriter = new FileWriter(file);
                        filewriter.write(message);
                        filewriter.close();
                        mxLogger.debug("MxEmail.sendViaUMS - File " + filename + " created");

                        // Create the UMS message
                        Message msg = new Message(subject, file);

                        // Create the UMS recipient
                        Contact contact = new Contact(type, contactno);
//      Begin modification SR-103
//                      Recipient recipient = new Recipient(null, null, contact);
                        Recipient recipient = new Recipient(userid, null, contact);
//      End modification SR-103

                        // Create the UMS request
                        MessageRequest msgrequest = new MessageRequest(
//      02-04-07 Requested by CTSD to avoid timeouts
//                      UMSSENDER, subject, msg, MessageRequest.NORMAL_PRIORITY, 0, null, recipient);
//      19-04-07 Requested by CTSD to avoid blank cover page
//                      UMSSENDER, subject, msg, MessageRequest.NORMAL_PRIORITY, 60, null, recipient);
                        null, subject, msg, MessageRequest.NORMAL_PRIORITY, 60, null, recipient);

// Begin modification SR-108
                        if (source.equalsIgnoreCase("rfq"))
                        {
                                Message terms = new Message("Terms & Conditions", (new File(TERMS)));
                                msgrequest.addMessage(terms);
                        }
//      End modification SR-108

                        // Send the message to UMS
                        //start of EMS-820
                        CommonUmsProxy email = new CommonUmsProxy(UMSSMTP, fromMail, toMail);
                        if (email.sendRequest(msgrequest) != CommonUmsProxy.SENT)
                        //end of EMS-820
                        {
                                mxLogger.error("MxEmail.sendViaUMS - Could not send message '" + subject + "' to UMS");
                                throw new MXApplicationException("system", "unknownerror", email.getLastException());
                        }
                        // Delete the temp attachment file except in debug mode
                        if (DELTEMPFILE)
                                file.delete();

//      Begin modification SR-085
/*                      // Create the control file containing the sending options (recipient, method, subject)
                        File controlfile = new File(filename.substring(0, filename.indexOf(".")) + ".ctl");
                        FileWriter controlfilewriter = new FileWriter(controlfile);
                        controlfilewriter.write(subject + "|" + type + "|" + contactno + "\n");
                        controlfilewriter.close();
                        mxLogger.debug("MxEmail.sendViaUMS - Control file " + filename + " created");
*/// End modification SR-085
                //}*/
        /*
                catch (IOException e)
                {
                        mxLogger.error("MxEmail.sendViaUMS - I/O Exception");
                        String[] param = { filename };
                        throw new MXApplicationException("iface", "ioexception", param, e.fillInStackTrace());
                }

                mxLogger.debug("MxEmail.sendViaUMS - Message '" + subject + "' sent to '" + contactno + "' via UMS");
        }

*/
        /*
         * Read the UMS configuration file (path hard-coded, no choice)
        
        private void readUMSConfigFile()
                        throws IOException
        {
                BufferedReader reader = new BufferedReader(new FileReader(UMSCFGFILE));
                for(String line; (line = reader.readLine()) != null; )
                {
                        StringTokenizer tok = new StringTokenizer(line.trim(), "=");
                        String parameter        = tok.nextToken().trim();
                        String value            = tok.nextToken().trim();
                        if (parameter.equalsIgnoreCase("UMSSMTP"))
                                UMSSMTP = value;
                        else if (parameter.equalsIgnoreCase("DELTEMPFILE"))
                                DELTEMPFILE = value.toLowerCase() == "true" ? true : false;
                        // Ignore any other parameter
//      Begin modification SR-108
                        else if (parameter.equalsIgnoreCase("TERMS"))
                                TERMS = value;
//      End modification SR-108
                }
        }
 */

/*
 * 29-10-2020 BCT: Removal of UMS ends here
 * 
 */
      
// Begin modification SR-112
        public void emailForActionError(String action, Object[] param)
        {
                setToMail(fromMail);
                String message = Resolver.getResolver().getMessage("action", "failedcustomaction").getMessage(param);
                send("Error while executing custom action " + action, message);
        }
// End modification SR-112

}

