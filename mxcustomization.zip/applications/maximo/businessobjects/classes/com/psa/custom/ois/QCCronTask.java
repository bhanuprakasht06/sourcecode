/**
 * @author	HCHA
 * Date		Feb 28, 2006
 * Modifications :
 * 	08-01-2007	AGD	SR-45 :	catch lines with error
 * 										force the end date to be midnight of the date of the data
 * 										several readings with the same start time but with different end times
 */
package com.psa.custom.ois;

import java.io.IOException;
import java.rmi.RemoteException;


import psdi.app.system.CrontaskParamInfo;
import psdi.util.MXException;


/**
 * @author		HCHA
 * @class		QCCronTask
 * @date		Feb 28, 2006
 * @function	
 */
public class QCCronTask extends OISCronTask {
	
	//Default values
	private static String isdelta = "Y"; //Set reading type as delta 
	//private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
	private static String locNotFoundEmailSubj = "[EMS-OIS]Warning: Locations Not Found."; //Email Subject for Location not found
	private static String finalExt = ".final"; //File extension for final calculation
	// SR-45 AGD : catch lines with error
	private static String linesWithErrorEmailSubj = "[EMS-OIS]Warning: Lines with errors";	// Email Subject for lines with error

	//Parameters 
    private String splitTag;		//Delimiter of input flat file
    private String contCntMeter;	//Name of the container count meter
    private String runngHrsMeter;	//Name of the running hours meter 
    private String contCntMeterM;	//Name of the container count meter (Modifiable by User)
    private String runngHrsMeterM;	//Name of the running hours meter (Modifiable by User)
    private String exclTypeFile;
    private boolean noZeroVin;

    public QCCronTask() {
		super();
	    splitTag=",";
	    contCntMeter=null;
	    runngHrsMeter=null; 
	    contCntMeterM=null;
	    runngHrsMeterM=null; 
	    exclTypeFile=null;
	    noZeroVin=true;
	}

	/* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function] Get the parameter from Cron Task.  
     */
	public CrontaskParamInfo[] getParameters() 
    	throws MXException, RemoteException 
    {
    	return params;
	}

	/* Author: HCHA
     * Date: 28 FEB 2006
     * Comment: Refresh Cron Task setting.  
     */
   protected void refreshSettings()
    {
System.out.println("--inside refreshSettings--");

    	super.refreshSettings();
    	
        try {
        	
            splitTag = getParamAsString("SPLITTAG");        	
         
            contCntMeter = getParamAsString("CONTCNTMETER");
            runngHrsMeter = getParamAsString("RUNNGHRSMETER");
            
            contCntMeterM = getParamAsString("CONTCNTMETERM");
            runngHrsMeterM = getParamAsString("RUNNGHRSMETERM");
            
            exclTypeFile = getParamAsString("EXCLUDETYPEFILENAME");
          
            noZeroVin = (getParamAsString("NO_ZERO_VIN").trim().equalsIgnoreCase("Y")); 
            System.out.println("--end refreshSettings--");            
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }

    /* Author: HCHA
     * Date: 28 FEB 2006
     * Comment: returns true if all required parameter is set
     */
    protected boolean isReqParamSet()
    {
        
        if(adminEmail==null) return false;
        if(contCntMeter==null) return false;
        if(runngHrsMeter==null) return false;
        if(contCntMeterM==null) return false;
        if(runngHrsMeterM==null) return false;
        if(intIface==null) return false;
        if(intObject==null) return false;
        if(extSys==null) return false;
        if(scpConfigFile==null) return false;
        if(remoteFilePath==null) return false;
        if(remoteServer==null) return false;        
        
    	return true;
    }

    /* Author: HCHA
     * Date: 28 FEB 2006
     * Comment: Process the import flat file   
     */
	protected void parseFlatFile(String file)
		throws MXException, RemoteException, IOException, InterruptedException, Exception
	{
		System.out.println("--inside parseFlatFile()--file--" + file);
		mxLog.writeLog(getName()+".parseFlatFile(): Parsing "+file);
       	
		String locNotFoundErrMsg = null;
		// SR-45 AGD : catch lines with error
    	String[] returnMsg;
		String errorLines = null;

		OISQuayCrane qc = new OISQuayCrane(noZeroVin,exclTypeFile, splitTag, getRunasUserInfo(), contCntMeter, runngHrsMeter, contCntMeterM, runngHrsMeterM, mxLog );
		System.out.println("--extsys--" + extSys + "-intIface-" + intIface + "-isdelta-" + isdelta +"-inspector-" + inspector + "-EMSAssetIDCfgFile-"+EMSAssetIDCfgFile);
		// SR-45 : Changed method return type
		returnMsg = qc.processFile(file,extSys,intIface,intObject,isdelta,inspector, EMSAssetIDCfgFile);
		locNotFoundErrMsg = returnMsg[0];
		errorLines = returnMsg[1];
		//locNotFoundErrMsg = qc.processFile(file,extSys,intIface,intObject,isdelta,inspector, EMSAssetIDCfgFile);

		if(locNotFoundErrMsg!=null){
            email.send(locNotFoundEmailSubj, locNotFoundErrMsg);
            mxLog.writeLog("Email Sent:\n"+ locNotFoundErrMsg);
		}

		// SR-45 : Send an email if some lines have error
		if (errorLines != null) {
			errorLines = "Error in file " + file + " for the following lines:\n" + errorLines;
			email.send(linesWithErrorEmailSubj, errorLines);
         mxLog.writeLog("Email Sent:\n" + errorLines);
		}

		if(enableLog){
			//Write final calcution into a flat file
			qc.writeFinalFile(file+finalExt);
		}
		
		qc.clearResult();

	}
	
    //CronTask Parameters
	protected static CrontaskParamInfo params[];
    static 
    {
    	// BTE: Set the number of the parameter.  
        params = null;
        params = new CrontaskParamInfo[24];
        
        // BTE: All the parameter configurable from Cron Task user interface 
        params[0] = new CrontaskParamInfo();
        params[0].setName("SPLITTAG");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[0].setDescription("Delimiter for flat file.");
        params[0].setDescription("CommonCron","DelimiterFlatFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[0].setDefault(",");
        
        params[1] = new CrontaskParamInfo();
        params[1].setName("EXTSYSNAME");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[1].setDescription("External System Name.");
        params[1].setDescription("CommonCron","ExternalSystem");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[1].setDefault("OISGW");
        
        params[2] = new CrontaskParamInfo();
        params[2].setName("INTERFACE");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[2].setDescription("Location Integration Interface Name.");
        params[2].setDescription("CommonCron","LocIntInterfaceName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[2].setDefault("MXOISInterface");
        
        params[3] = new CrontaskParamInfo();
        params[3].setName("INTOBJECT");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[3].setDescription("Integration Object Name.");
        params[3].setDescription("CommonCron","IntegrationObjectName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[3].setDefault("MXLOCMETER");
        
        params[4] = new CrontaskParamInfo();
        params[4].setName("LOCALDIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[4].setDescription("Local directory to transfer the flat file to.");
        params[4].setDescription("CommonCron","LocalDirectoryToTransferTo");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[5] = new CrontaskParamInfo();
        params[5].setName("SCPCONFIGFILE");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[5].setDescription("SCP Config File.");
        params[5].setDescription("CommonCron","SCPConfigFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[6] = new CrontaskParamInfo();
        params[6].setName("ALERTEMAIL");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[6].setDescription("Admin email address for notification of error.");
        params[6].setDescription("CommonCron","Adminemailaddress");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[7] = new CrontaskParamInfo();
        params[7].setName("UNZIPEXEC");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[7].setDescription("Executable for unziping the input flat file.");
        params[7].setDescription("CommonCron","ExecutableUnziping");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[7].setDefault("gunzip -f -q");
        
        params[8] = new CrontaskParamInfo();
        params[8].setName("REMOTEFILEPATH");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[8].setDescription("Remote Path of the input flat file.");
        params[8].setDescription("CommonCron","RemotePathFlatFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[9] = new CrontaskParamInfo();
        params[9].setName("REMOTESERVER");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[9].setDescription("Remote server name.");
        params[9].setDescription("CommonCron","RemoteServerName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
         
        params[10] = new CrontaskParamInfo();        
        params[10].setName("CONTCNTMETER");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[10].setDescription("Container Count Meter Name(Read-Only Meter).");
        params[10].setDescription("CommonCron","CountMeterReadOnly");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[10].setDefault("CONTCOUNT");
    
        params[11] = new CrontaskParamInfo();
        params[11].setName("RUNNGHRSMETER");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[11].setDescription("Running Hours Meter Name(Meter Reading Modifiable by User).");
        params[11].setDescription("CommonCron","runnghrsmeterm");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[11].setDefault("RUNHOURS");
        
        params[12] = new CrontaskParamInfo();
        params[12].setName("EXCLUDETYPEFILENAME");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[12].setDescription("Path and filename for list of code of equipment required.");
        params[12].setDescription("CommonCron","PathAndFilename");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[13] = new CrontaskParamInfo();
        params[13].setName("ENABLELOG");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[13].setDescription("Enable log output('Y' or 'N').");
        params[13].setDescription("CommonCron","EnableLog");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[13].setDefault("Y");
        
        params[14] = new CrontaskParamInfo();
        params[14].setName("IMPBASEFILENAME");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[14].setDescription("Base file name of the input flat file.(End with 'yyyymmdd' for current day file.)");
        params[14].setDescription("CommonCron","BaseFileName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[15] = new CrontaskParamInfo();
        params[15].setName("IMPFILEEXT");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[15].setDescription("Extension of the input flat file package.");
        params[15].setDescription("CommonCron","impfileext");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[15].setDefault(".gz");

        params[16] = new CrontaskParamInfo();
        params[16].setName("ALERTEMAILSUBJ");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[16].setDescription("Email Subject for the Alert Email.");
        params[16].setDescription("CommonCron","EmailSubject");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[17] = new CrontaskParamInfo();
        params[17].setName("NO_ZERO_VIN");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[17].setDescription("['Y' or 'N']Do not take into account VIN with value of 0 for calculation..");
        params[17].setDescription("CommonCron","noZeroVIN");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[17].setDefault("Y");
        
        params[18] = new CrontaskParamInfo();
        params[18].setName("INSPECTOR");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[18].setDescription("Meter Reading Inspector.");
        params[18].setDescription("CommonCron","inspector");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[18].setDefault("MXINTADMIN");
        
        params[19] = new CrontaskParamInfo();
        params[19].setName("PROCESSDIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[19].setDescription("Directory where processing will be done.");
        params[19].setDescription("CommonCron","processdirectory");

        params[20] = new CrontaskParamInfo();        
        params[20].setName("CONTCNTMETERM");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[20].setDescription("Container Count Meter Name(Meter Reading Modifiable by User).");
        params[20].setDescription("CommonCron","contcntmeterm");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[20].setDefault("ACONTCOUNT");
    
        params[21] = new CrontaskParamInfo();
        params[21].setName("RUNNGHRSMETERM");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[21].setDescription("Running Hours Meter Name(Meter Reading Modifiable by User).");
        params[21].setDescription("CommonCron","runnghrsmeterm");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[21].setDefault("ARUNHOURS");
        
        params[22] = new CrontaskParamInfo();
        params[22].setName("LOGDIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[21].setDescription("Log Directory.");
        params[21].setDescription("CommonCron","logdir");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[23] = new CrontaskParamInfo();
        params[23].setName("EMSASSETIDCFGFILE");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[23].setDescription("Config Filename for Location Conversion.");
        params[23].setDescription("CommonCron","emsassetidcfgfile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

    }
}
