package com.psa.custom.oa12i;

import java.rmi.RemoteException;
import psdi.app.inventory.MatRecTrans;
import psdi.iface.mic.StructureData;
import psdi.iface.oa12.ERPOutExt;
import psdi.iface.proc.ControlsCache;
import psdi.mbo.MaximoDD;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.Translate;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXSystemException;
import psdi.util.logging.MXLogger;

public class PSA_ReceiptOutExt
  extends ERPOutExt
{
  protected static final String VOID_RECEIPT = "VOIDRECEIPT";
  protected static final String WAIT_INSP = "WINSP";
  
  public StructureData setDataOut(StructureData paramStructureData)
    throws MXException, RemoteException
  {
    integrationLogger.debug("Entering ReceiptOutExt.setDataOut");
    
    ControlsCache localControlsCache = getMaxIfaceControl();
    Translate localTranslate = MXServer.getMXServer().getMaximoDD().getTranslator();
    
    MboRemote localMboRemote1 = paramStructureData.getCurrentMbo();
    
    MboRemote localMboRemote2 = null;
    MboRemote localMboRemote3 = null;
    
    String str1 = paramStructureData.getCurrentData("ORGID");
    String str2 = paramStructureData.getCurrentData("SITEID");
    String str3 = localControlsCache.getValueControl(getExtSystem(), "GENITEM", str1, str2);
    String str4 = localControlsCache.getValueControl(getExtSystem(), "GENSTORE", str1, str2);
    String str5 = "";
    if ((localMboRemote1.getOwner().getMboSet("POLINE") != null) && (!localMboRemote1.getOwner().getMboSet("POLINE").isEmpty()))
    {
      localMboRemote2 = localMboRemote1.getOwner().getMboSet("POLINE").getMbo(0);
      if ((!localMboRemote2.isNull("OA_RATELINE")) && (localMboRemote2.getBoolean("OA_RATELINE"))) {
        throw new MXApplicationException("iface", "oa_ratetype_poline", new String[] { localMboRemote2.getString("polinenum") });
      }
    }
    if (integrationLogger.isDebugEnabled())
    {
      integrationLogger.debug("PONUM: " + paramStructureData.getCurrentData("PONUM"));
      integrationLogger.debug("POLINENUM: " + paramStructureData.getCurrentData("POLINENUM"));
      integrationLogger.debug("ACTION: " + paramStructureData.getAction());
    }
    if (paramStructureData.isCurrentDataNull("PONUM"))
    {
      integrationLogger.debug("PONUM is null, only send receipts for POs to Oracle - skipping transaction");
      throw new MXSystemException("iface", "skip_transaction");
    }
    String str6 = localTranslate.toInternalString("RECEIPTSTATUS", paramStructureData.getCurrentData("STATUS"), str2, str1);
    paramStructureData.setCurrentData("STATUS", str6);
    String str7 = localTranslate.toInternalString("LINETYPE", paramStructureData.getCurrentData("LINETYPE"));
    String str8 = localTranslate.toInternalString("ISSUETYP", paramStructureData.getCurrentData("ISSUETYPE"));
    paramStructureData.setCurrentData("LINETYPE", str7);
    paramStructureData.setCurrentData("ISSUETYPE", str8);
    if (str8.equals("RETURN"))
    {
      if ((!paramStructureData.isCurrentDataNull("SERVRECTRANSID")) && (!paramStructureData.isCurrentDataNull("CHANGEBY")))
      {
        integrationLogger.debug("Return to Inspection for service");
        throw new MXSystemException("iface", "skip_transaction");
      }
      if ((!paramStructureData.isCurrentDataNull("MATRECTRANSID")) && (((MatRecTrans)localMboRemote1.getOwner()).isReject()))
      {
        integrationLogger.debug("Return to Inspection");
        paramStructureData.setCurrentData("ISSUETYPE", "REJECT");
      }
    }
    paramStructureData.setCurrentData("ORGID", getXREFValue("ORGXREF", str1));
    
    String str9 = getOPUnitCol("PO", "OFOPUNIT");
    /*if (!paramStructureData.isGLDataNull("GLCREDITACCT")) {
      paramStructureData.setGL("GLCREDITACCT", getORAGLAccount(paramStructureData.getGL("GLCREDITACCT"), str1));
    }
    if (!paramStructureData.isGLDataNull("GLDEBITACCT")) {
      paramStructureData.setGL("GLDEBITACCT", getORAGLAccount(paramStructureData.getGL("GLDEBITACCT"), str1));
    }*/
    if (!isValueControlNull("GENUSR", str1, str2)) {
      paramStructureData.setCurrentData("ENTERBY", localControlsCache.getValueControl(getExtSystem(), "GENUSR", str1, str2));
    }
    localMboRemote2 = localMboRemote1.getOwner();
    if ((localMboRemote2 == null) || (!localMboRemote2.getName().equals("POLINE"))) {
      localMboRemote2 = localMboRemote1.getMboSet("POLINE").moveFirst();
    }
    paramStructureData.setCurrentData("OA_ITEM_ID", getItemExtRefID(localMboRemote2));
    paramStructureData.setCurrentData("OA_CATEGORYID", getXREFValue("OACATXREF", str1, str2, paramStructureData.getCurrentData("LINETYPE")));
    
    String str10 = getOwnersysid(localMboRemote2);
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("itmOwnersysId: " + str10);
    }
    if ((!str7.equals("ITEM")) && (!str7.equals("SPORDER")))
    {
      paramStructureData.setCurrentDataNull("ITEMNUM");
    }
    else if ((str3 != null) && (!str3.equals("")) && (!str10.equals("OA")))
    {
      if (integrationLogger.isDebugEnabled()) {
        integrationLogger.debug("genitem: " + str3);
      }
      paramStructureData.setCurrentData("ITEMNUM", str3);
      if ((localControlsCache.isControlExists(getExtSystem(), "SKIPLOTSERIAL")) && (localControlsCache.isControlTrue(getExtSystem(), "SKIPLOTSERIAL", str1, str2)))
      {
        if (!paramStructureData.isCurrentDataNull("ROTASSETNUM"))
        {
          integrationLogger.debug("Skipping RotAssetnum record as item is masked");
          throw new MXSystemException("iface", "skip_transaction");
        }
        if (!paramStructureData.isCurrentDataNull("TOLOT"))
        {
          integrationLogger.debug("Setting TOLOT to null as item is masked");
          paramStructureData.setCurrentDataNull("TOLOT");
        }
      }
    }
    if (localMboRemote2 != null)
    {
      paramStructureData.setCurrentData("OA_SHIPTO", localMboRemote2.getString("SHIPTO"));
      paramStructureData.setCurrentData("OA_CONTRACTNUM", localMboRemote2.getString("CONTRACTREFNUM"));
      if (paramStructureData.isCurrentDataNull("RECEIVEDUNIT")) {
        paramStructureData.setCurrentData("RECEIVEDUNIT", localMboRemote2.getString("ORDERUNIT"));
      }
      if (str8.equals("RETURN")) {
        paramStructureData.setCurrentData("TOSTORELOC", localMboRemote2.getString("STORELOC"));
      }
      localMboRemote3 = localMboRemote2.getOwner();
    }
    if ((localMboRemote3 == null) || (!localMboRemote3.getName().equals("PO"))) {
      localMboRemote3 = localMboRemote1.getMboSet("PO").moveFirst();
    }
    if (localMboRemote3 != null)
    {
      paramStructureData.setCurrentData("OA_VENDOR", localMboRemote3.getString("VENDOR"));
      paramStructureData.setCurrentData("OA_POTYPE", localTranslate.toInternalString("POTYPE", localMboRemote3.getString("POTYPE"), str2, str1));
      paramStructureData.setCurrentData("OA_OWNERSYSID", localMboRemote3.getString("OWNERSYSID"));
      if (paramStructureData.isCurrentDataNull("OA_SHIPTO")) {
        paramStructureData.setCurrentData("OA_SHIPTO", localMboRemote3.getString("SHIPTO"));
      }
      if (paramStructureData.isCurrentDataNull("OA_CONTRACTNUM")) {
        paramStructureData.setCurrentData("OA_CONTRACTNUM", localMboRemote3.getString("CONTRACTREFNUM"));
      }
      if (!localMboRemote3.isNull("REQUIREDDATE")) {
        paramStructureData.setCurrentData("OA_REQUIREDDATE", localMboRemote3.getDate("REQUIREDDATE"));
      }
      if ((str9 != null) && (!str9.equals(""))) {
        str5 = localMboRemote3.getString(str9);
      }
    }
    if ((str5 != null) && (!str5.equals(""))) {
      paramStructureData.setCurrentData("SITEID", str5);
    } else {
      paramStructureData.setCurrentData("SITEID", getXREFValue("SITEXREF", str2));
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("SITEID: " + paramStructureData.getCurrentData("SITEID"));
    }
    if (paramStructureData.getCurrentData("OA_POTYPE").equals("REL")) {
      paramStructureData.setCurrentData("OA_CONTRACTLINENUM", getContractLineNum(localMboRemote2));
    }
    if (!paramStructureData.isCurrentDataNull("TOSTORELOC"))
    {
      if ((str4 != null) && (!str4.equals("")) && (!str10.equals("OA"))) {
        paramStructureData.setCurrentData("TOSTORELOC", str4);
      }
      /*if (((str10.equals("OA")) && (paramStructureData.isCurrentDataNull("TOBIN"))) || (!str10.equals("OA"))) {
        paramStructureData.setCurrentData("TOBIN", getXREFValue("ITMSUBXREF", str1, str2, paramStructureData.getCurrentData("TOSTORELOC")));
      }
      splitBinNum(paramStructureData, paramStructureData.getCurrentData("TOBIN"), str1, str2);*/
    }
    if ((!paramStructureData.isCurrentDataNull("MATRECTRANSID")) && ((paramStructureData.getCurrentData("ISSUETYPE").equals("TRANSFER")) || (paramStructureData.getCurrentData("ISSUETYPE").equals("REJECT"))))
    {
      MboRemote localMboRemote4 = ((MatRecTrans)localMboRemote1.getOwner()).getReceiptForThisReturn();
      paramStructureData.setCurrentData("OA_INSP_RCV_QTY", localMboRemote4.getDouble("RECEIPTQUANTITY"));
      if (!localMboRemote1.isNull("INSPECTED")) {
        paramStructureData.setCurrentData("INSPECTED", localMboRemote1.getBoolean("INSPECTED") ? "1" : "0");
      }
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("ORGID: " + paramStructureData.getCurrentData("ORGID"));
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("SITEID: " + paramStructureData.getCurrentData("SITEID"));
    }
    integrationLogger.debug("Leaving ReceiptOutExt.setDataOut");
    return paramStructureData;
  }
}

