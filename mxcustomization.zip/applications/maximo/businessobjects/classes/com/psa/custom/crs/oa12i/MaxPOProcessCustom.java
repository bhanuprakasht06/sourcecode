/*    */ package com.psa.custom.oa12i;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import com.psa.custom.common.MxDatabase;
/*    */ import psdi.iface.app.po.MaxPOProcess;
/*    */ import psdi.iface.mic.StructureData;
/*    */ import psdi.security.UserInfo;
/*    */ import psdi.txn.MXTransaction;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.MXSystemException;
/*    */ import psdi.util.logging.MXLogger;
/*    */ 
/*    */ public class MaxPOProcessCustom
/*    */   extends MaxPOProcess
/*    */ {
/*    */   public MaxPOProcessCustom()
/*    */     throws MXException, RemoteException
/*    */   {}
/*    */   
/*    */   public void processExternalData(StructureData structuredata, String ifacename, String ifacetype, String intpointname, UserInfo userinfo, MXTransaction mxtransaction, String senderid)
/*    */     throws MXException, RemoteException
/*    */   {
/* 46 */     super.processExternalData(structuredata, ifacename, userinfo, mxtransaction);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 51 */     this.struc.setAsCurrent(this.struc.getPrimaryObject());
/* 52 */     if (!this.struc.isCurrentDataNull("CONTRACTREFNUM"))
/*    */     {
/* 54 */       INTEGRATIONLOGGER.info("MaxPOProcessCustom - Updating Contract # in PO " + this.struc.getCurrentData("PONUM") + " to reflect GFS Contract #");
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 60 */       MxDatabase db = null;
/* 61 */       Connection conn = null;
/* 62 */       String sql = "UPDATE poline SET contractrefnum='" + 
/* 63 */         this.struc.getCurrentData("CONTRACTREFNUM") + "' " + 
/* 64 */         "WHERE ponum='" + this.struc.getCurrentData("PONUM") + "'";
/* 65 */       INTEGRATIONLOGGER.debug("MaxPOProcessCustom - Updating DB using query='" + sql + "'");
/*    */       try
/*    */       {
/*    */         try
/*    */         {
/* 68 */           db = new MxDatabase(userinfo);
/*    */         }
/*    */         catch (Exception e)
/*    */         {
/* 71 */           throw new MXSystemException("system", "sql", e);
/*    */         }
/* 73 */         conn = db.getConn();
/* 74 */         PreparedStatement stmt = conn.prepareStatement(sql);
/* 75 */         int norowupdated = stmt.executeUpdate();
/* 76 */         stmt.close();
/* 77 */         INTEGRATIONLOGGER.debug("MaxPOProcessCustom - " + norowupdated + " row(s) updated");
/*    */       }
/*    */       catch (SQLException sqle)
/*    */       {
/* 80 */         Object[] aobj = {
/* 81 */           new Integer(sqle.getErrorCode()).toString() };
/*    */         
/* 83 */         throw new MXSystemException("system", "sql", aobj, sqle);
/*    */       }
/*    */       finally
/*    */       {
/* 86 */         if (db != null) {
/* 87 */           db.releaseResources();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.MaxPOProcessCustom
 * JD-Core Version:    0.7.0.1
 */