 package com.psa.custom.common;

import java.rmi.RemoteException;
import psdi.util.CombineWhereClauses;
import psdi.util.MXException;
import psdi.app.location.*;
import psdi.mbo.*;
import psdi.server.MXServer;
import psdi.security.UserInfo;
import java.util.Date;

import com.psa.custom.common.EMSSite;

public class MxLocMeter  {

	   private UserInfo userInfo;
	   
	   public MxLocMeter(UserInfo userInfo)
	      throws MXException, RemoteException
	   {
		   this.userInfo=userInfo;
		   
	   }
	   

	   public Date getLastReadingDate(String location, String metername)
  		throws MXException, RemoteException
  		{
		   EMSSite site = new EMSSite(location,userInfo);
		   
		   return getLastReadingDate(site.getOrgID(),site.getSiteID(),location,metername);
  		}
	   
	   public Date getLastReadingDate(String orgid, String siteid, String location, String metername)
	   		throws MXException, RemoteException
	   {

			if(orgid==null || siteid==null || location==null || metername==null )
				return null;
			
		   	LocationMeterSetRemote locMeterSet = (LocationMeterSetRemote) MXServer.getMXServer().getMboSet("LOCATIONMETER", userInfo);
						
			CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
			
			combinewhereclauses.addWhere("ORGID= :1");
			combinewhereclauses.addWhere("SITEID= :2");
			combinewhereclauses.addWhere("LOCATION= :3");
			combinewhereclauses.addWhere("METERNAME= :4");
			String s = combinewhereclauses.getWhereClause();
			
		    if(s != null && !s.equalsIgnoreCase(""))
	        {
	            SqlFormat sqlformat = new SqlFormat(userInfo, s);
	            
	            sqlformat.setObject(1, "LOCMETERREADING", "ORGID", orgid);
	            sqlformat.setObject(2, "LOCMETERREADING", "SITEID", siteid);
	            sqlformat.setObject(3, "LOCMETERREADING", "LOCATION", location);
	            sqlformat.setObject(4, "LOCMETERREADING", "METERNAME", metername);
	            
	            locMeterSet.setWhere(sqlformat.format());
	            if(!locMeterSet.isEmpty())
		        {
	            	LocationMeterRemote locMeter = (LocationMeterRemote) locMeterSet.getMbo(0);
	            	
	            	if(!locMeter.isNull("LASTREADINGDATE")){
	            		return locMeter.getDate("LASTREADINGDATE");
	            	}
		        }
	        }

		   return null;
		   
	   }
}
