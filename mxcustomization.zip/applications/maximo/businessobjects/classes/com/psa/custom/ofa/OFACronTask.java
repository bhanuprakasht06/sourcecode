/*
 * Modification history
 * 13-Feb-2006  BTE     NA                      Initial version
 * 27-Jun-2006  BTE     DR-165
 *                                              DR-168
 * 19-Apr-2007  AGD     SR-094  Input file has hhmiss after hhmmdd
 * 19-Apr-2007  AGD     DR-018  Need to blank GL A/c segments 2, 3 and 8 (blank meaning ?)
 * 23-Apr-2007  AGD     SR-095  Set asset GL A/c
 * 26-Jun-2007  LS              SR-105  Populate the Oracle asset number to Location and Asset
 * 12-Jul-2007 RHA      SR-104  Send an email when a problem is encountered during the processing
 * 12-Oct-2007  AGD     DR-051  DR-018 fixed only the case where the function type exists, not the other case --> moved the fix outside the loop
 * 12-Oct-2007  AGD     SR-122  All assets to be imported are expected to have locations and follow the same processing, except for the asset naming that keeps the current logic
 */
package com.psa.custom.ofa;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import psdi.app.location.LocHierarchyRemote;
import psdi.app.location.LocHierarchySetRemote;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.app.control.MaxIfaceControl;
import psdi.iface.jms.MEAQueueProcessor;
import psdi.iface.load.LoadCronTask;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;

import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.MaxVarServiceRemote;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import java.text.ParseException;

import com.psa.custom.common.EMSSite;
import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxXml;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;

import psdi.iface.migexits.*;
import psdi.iface.proc.ControlsCache;


public class OFACronTask extends LoadCronTask {

        private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";

    // EMAIL Subject
    private static final String SUBJECT = "[EMS-OFA] Error: Error occured in flat file import.";

        // Variables
    private static final String SPACE = " ";

    private static CrontaskParamInfo params[];
    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");

    private boolean isOkToRun;
    private MEAQueueProcessor queueProcessor;
    private String qualifiedInstanceName;
    private String extSys;
    private String locIfaceName;
    private String assetIfaceName;
    private File loadDir;
    private String directory;
    private String splitTag;
    private RecoveryService recoveryService;


    private String administrator;
    private String importFileName;
    private String unzipExec;                   //Executable/Command for unzip function
    private String processDirectory;    //Directory where processing are done

    private MxEmail email;
    private MxXml mxXml;

    // BTE - 27 JUN 2006 - DR-165 and DR-168
    private boolean toEmail;
    private StringBuffer errMessage;
    private static final String NEWLINE = "\n\r";


    /*
     * Author: BTE
     * 13 FEB 2006 - OFA Cron task constructor initialize default value
     */
    public OFACronTask() {

        isOkToRun = true;
            recoveryService = null;
            queueProcessor = null;
            qualifiedInstanceName = null;
            queueProcessor = new MEAQueueProcessor();

        extSys = null;
        locIfaceName = null;
        assetIfaceName = null;
        loadDir = null;
        directory = null;
        splitTag = null;

        // BTE: Extra parameter to configure cron task.
        administrator = null;
        importFileName = null;
        unzipExec = null;
        processDirectory = null;

        // BTE - 27 JUN 2006 - DR-165 and DR-168
                errMessage = null;
                toEmail = false;
    }


    /*
     * Author: BTE
     * 13 FEB 2006 - Send data to JMS queue
     */
    //START SR-104
    public boolean splitPerformed(byte[] abyte0, String ifaceName, int i, String file) throws Exception {
        //public boolean splitPerformed(byte[] abyte0, String ifaceName, int i) throws Exception {
        //END SR-104
                integrationLogger.debug("Entering splitPerformed");

        try {
                        sendMessage(abyte0, ifaceName, i);

                } catch (Exception e) {

                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                        //START SR-104
                        toEmail = true;
                        errMessage.append("[OFA] In file "+ file +":"+e.getMessage());
                        errMessage.append(NEWLINE);
                if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue")){
                //if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
                        errMessage.append("[OFA] In file "+ file +":File Load Task: Unable to write to queue: Going to sleep");
                        errMessage.append(NEWLINE);
                    //END SR-104
                    MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");
                //START SR-104
                }
                //END SR-104

                throw new Exception(e.getMessage());
                }

                integrationLogger.debug("Leaving splitPerformed");
                return true;
    }


    /*
     * Author: BTE
     * 13 FEB 2006 - Send a collection of XML data to JMS queue
     */
        //START SR-104
        public void multiSplitPerformed(Collection col, int i, String file) throws Exception {
        //public void multiSplitPerformed(Collection col, int i) throws Exception {
        //END SR-104
                integrationLogger.debug("Entering multiSplitPerformed");

        try {

                        Iterator iter = col.iterator();
                        while (iter.hasNext()) {
                                String xmlData = (String)iter.next();

                                if(!xmlData.matches("")){
                                        //
                                        //splitPerformed(xmlData.getBytes(), assetIfaceName, i);
                                        splitPerformed(xmlData.getBytes(), assetIfaceName, i, file);
                                        //
                                }

                                xmlData = (String)iter.next();

                                if(!xmlData.matches("")){
                                        //START SR-104
                                        //splitPerformed(xmlData.getBytes(), locIfaceName, i);
                                        splitPerformed(xmlData.getBytes(), locIfaceName, i, file);
                                        //END SR-104
                                }
                        }

                        // Clear collection
                        col.clear();

                        integrationLogger.debug("Leaving multiSplitPerformed");

                } catch (Exception e) {
                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                //START SR-104
                        toEmail = true;
                        errMessage.append("[OFA] In file "+ file +": "+e.getMessage());
                        errMessage.append(NEWLINE);
                        if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue")){
                //if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
                                errMessage.append("[OFA] In file "+ file +": File Load Task: Unable to write to queue: Going to sleep");
                                errMessage.append(NEWLINE);
                //END SR-104
                    MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");
                //START SR-104
                }
                //END SR-104
                throw new Exception(e.getMessage());
                }

        }


        /*
         * Author: BTE
     * 13 FEB 2006 - Initialize cron task
     */
    public void init() {
        email = new MxEmail(administrator);
        mxXml = new MxXml();

    }


    /*
     * Author: BTE
     * 13 FEB 2006 - Start cron task
     */
    public void start() {

        integrationLogger.debug("Entering start");

        try {
            refreshSettings();

            MicUtil.INTEGRATIONLOGGER.info("Load task::" + qualifiedInstanceName + " started for system::" + extSys + " and interface=" + locIfaceName + ", " +assetIfaceName);

            //integrationLogger.debug("Previous SleepTime: " + getSleepTime());
            //setSleepTime(getSleepTime() - ((new Date()).getTime() - getLastRunDate().getTime()));
            integrationLogger.debug("Current SleepTime: " + getSleepTime());

            integrationLogger.debug("Leaving start");
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }


        /*
         * Author: BTE
     * 13 FEB 2006 - Get the parameter value setting from maximo User Interface in configuration
     */
    private void refreshSettings()
    {

        integrationLogger.debug("Entering refreshSettings");

        try {
            splitTag = getParamAsString("SPLITTAG");
            extSys = getParamAsString("EXTSYSNAME");
            locIfaceName = getParamAsString("LOCATIONSINTERFACENAME");
            assetIfaceName = getParamAsString("ASSETINTERFACENAME");
            directory = getParamAsString("DIRECTORY");
            loadDir = new File(directory);
            //Removed by WMJ 20120820 for MX7 recoveryService    
            //recoveryService = new RecoveryService(loadDir);

            /* BTE: Require for getting flat file in remote server and email
             * alert administrator. Require for configuration throught Maximo
             * User Interface.
             */

            administrator = getParamAsString("ALERTEMAIL");
            email.setAdmin(administrator);

            //Replace filename by today's date if "yyyymmdd" is specified in import file base name
            DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
            String todayDate=fileDateFormat.format(new Date());
            importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmdd",todayDate);

            //Paramater for Unzip
            unzipExec = getParamAsString("UNZIPEXEC");

            //Directory where processing are done
            processDirectory= getParamAsString("PROCESSDIRECTORY");

            integrationLogger.debug("Leaving refreshSettings");

        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
            //START SR-104
            toEmail = true;
            errMessage.append("[OFA] "+exception.getMessage());
            errMessage.append(NEWLINE);
            //END SR-104
        }
    }


    /*
     * Author: BTE
     * 13 FEB 2006 - Stop cron task
     */
    public void stop() {

        integrationLogger.debug("stop");

                MicUtil.INTEGRATIONLOGGER.info("Flat file polling task::" +
                qualifiedInstanceName +
                " stopped for system::" +
                extSys +
                " and interface=" +
                locIfaceName +
                ", " +
                assetIfaceName);
    }


    /*
     * Author: BTE
     * 13 FEB 2006 - Set cron task instance
     */
    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {

        try {
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") +
                "." + crontaskinstanceremote.getString("instancename");
        }
        catch(Exception exception) {
            integrationLogger.error(exception.getMessage(), exception);
        }
    }


    /*
     * Author: BTE
     * 13 FEB 2006 - Cron task function - Retrieve flat file from remote server,
     *               process flat file, convert to xml format and import to maximo.
     */
        public void cronAction() {

                integrationLogger.debug("Entering cronAction");

        // BTE - 27 JUN 2006 - DR-165 and DR-168
        errMessage = new StringBuffer();
        //START SR-104
                //errMessage.append("[EMS-OFA] Warning: Location hierarchy error for the following: ");
                errMessage.append("[EMS-OFA] Warning(s) and Error(s): ");
                //END SR-104
                errMessage.append(NEWLINE);

        if(!isOkToRun) return;

        // Refresh setting before perform cron action
        refreshSettings();

        try {
                        // BTE: Get the Administrator email
                        if (administrator == null) throw new Exception("Required parameter not set.");

                        // BTE: Get the import flat file from remote server
                        if ((importFileName != null) && (directory != null)) {

                                // Check file is in local drive?
                                if (!checkFileExist(importFileName)) {

                                        throw new Exception("["+getName()+"]Unable to read input file '"+importFileName+"'");
                                }

                        } else {
                                throw new Exception("Required parameter not set.");
                        }

                        // Process the import flat file
                        processFolderData();

                        integrationLogger.debug("Leaving cronAction");
        }
        catch(Exception e) {
            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);

            email.send(SUBJECT, e.getMessage());
        }
        }


        /*
         * Author: BTE
         * 21 FEB 2006 - Check file exist in local directory
         */
        public boolean checkFileExist (String fileExtension) {

                integrationLogger.debug("Entering checkFileExist");

//      Begin modification SR-094
//              File afile[] = loadDir.listFiles();
                SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
                File afile[] = loadDir.listFiles(filter);
//      End modification SR-094

                if(afile != null) {
                        int i = afile.length;

//      Begin modification SR-094
//                      for(int j = 0; j < i; j++) {
//
//                              if(afile[j].isFile() && afile[j].getName().endsWith(importFileName)) {
                        if (i > 0)
                        {
                                        integrationLogger.debug("File found. Leaving checkFileExist");
                                        return true;
//                              }
//      End modification SR-094
                        }
                }

                integrationLogger.debug("File not found. Leaving checkFileExist");
                return false;
        }


        /*
         * Author: BTE
     * 13 FEB 2006 - Get the parameter from Cron Task.
     */
    public CrontaskParamInfo[] getParameters() throws MXException, RemoteException {
            return params;
        }


        /* Author: BTE
         * 13 FEB 2006 - Process the import flat file
         */
        public void processFolderData() throws Exception {

                integrationLogger.debug("Entering processFolderData");

                try {
// Begin modification SR-094
//                      File afile[] = loadDir.listFiles();
                        SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
                        File afile[] = loadDir.listFiles(filter);
//      End modification SR-094

                        if(afile != null) {

                                int i = afile.length;
                                int fileprocessed = 0;

                                for(int j = 0; j < i; j++) {

//      Begin modification SR-094
//                                      if(afile[j].isFile() && afile[j].getName().endsWith(importFileName)) {
//      End modification SR-094

                                integrationLogger.info("["+getName()+"] Processing '" + afile[j].getName() + "'" );

                                //Added by WMJ 20120820 for MX7 RecoveryService
                                recoveryService = new RecoveryService(afile[j]); 
                                //recoveryService.startRecovery();

                                try {                                                                                                                        

                                        // Parse OFA flat file
                                String file = processDirectory + afile[j].getName();

                                //Copy file to process directory
                                MxFileCopy.fileCopy(afile[j].toString(), processDirectory + afile[j].getName());

                                //Unzip File
                                String cmd = unzipExec + SPACE + file;
                                if ( MxZip.unzipFile(cmd)== 0 )
                                        {

                                        //Get filename without extension
                                        int dotPos = file.lastIndexOf(".");
                                        String extractedFile = file.substring(0,dotPos);

                                        Collection col = parseFlatFile(extractedFile);


                                        // Create a XML document based on the data from the flat file.
//                                      START SR-104
                                        Collection xmlCol = generateXMLDocument(col,afile[j].getName());
//                                      END SR-104

                                        // Important BufferedInputStream has a size of 2000byte only.
                                        //START SR-104
                                        //multiSplitPerformed(xmlCol, j);
                                        multiSplitPerformed(xmlCol, j, afile[j].getName());
                                        //END SR-104

                                        //Delete Extracted File
                                        File fExtractedFile = new File(extractedFile);
                                        fExtractedFile.delete();

                                        }
                                else{
                                                throw new Exception("["+getName()+"]Unable to unzip file - " + file);
                                        }

                                }
                                finally {
                                        try {
                                                integrationLogger.debug("processFolderData: End Recovery");

                                                recoveryService.endRecovery();
                                        }
                                        catch(Exception e){
                                                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                                                //START SR-104
                                                toEmail = true;
                                                errMessage.append("[OFA]Error in file "+afile[j].getName()+" :"+e.getMessage());
                                        errMessage.append(NEWLINE);
                                                //END SR-104
                                        }
                                }

                                fileprocessed++;
// Begin modification SR-094
//                      }
//      End modification SR-094
                    }//End of for(int j = 0; j < i; j++)

                                if(fileprocessed!=0){
                                        integrationLogger.info("["+getName()+"] "+fileprocessed+ " file(s) processed." );
                                }
                                else{
                                        throw new Exception("["+getName()+"]No files was processed!");
                                }

                                // BTE - 27 JUN 2006 - DR-165 and DR-168
                                if (toEmail) {
                            email.send(SUBJECT, errMessage.toString());
                                }
                                //SR-104 - observed that toEmail is always false BEFORE SR-104

                }//End of if(afile != null)
                }
        catch(Exception e)
        {
            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
            email.send(SUBJECT, e.getMessage());
        }

        integrationLogger.debug("Leaving processFolderData");
        }


    /* Author: BTE
     * 13 FEB 2006 - Parse OFA flat file.
     */
    private Collection parseFlatFile(String file) throws IOException {

        integrationLogger.debug("Entering parseFlatFile");

        // BTE: Parse the OFA flat flat file first
        // Reading the import flat file
        BufferedReader flatfileReader;
        Collection col = new Vector();

                flatfileReader = new BufferedReader(new FileReader(file));

        // Ignore first line of text as its the file header
        String curLine = flatfileReader.readLine();

        // Process record.
        //StringTokenizer stringTokenizer = null;

        while((curLine = flatfileReader.readLine()) != null)
        {
            //stringTokenizer = new StringTokenizer(curLine, splitTag);
                String[] str = curLine.split(splitTag);

                Vector vec = new Vector();

                if(str.length!=8){
                        integrationLogger.error("[OFA]Invalid line:'"+curLine+"'");
                        //BEGIN SR-104
                        toEmail = true;
                        errMessage.append("[OFA]Invalid line in file "+file+" :'"+curLine+"'");
                        errMessage.append(NEWLINE);
                        //END SR-104
                        continue;
                }

                for(int i=0;i<str.length;i++){
                        //Add to element to vector.
                        vec.add(str[i].trim());
                }
              /*
            while(stringTokenizer.hasMoreElements())
            {
                String curValue = String.valueOf(stringTokenizer.nextElement());

                 //Add to element to vector.
                vec.add(curValue.trim());

            }
          */

            // Add to a collection
            col.add(vec);
        }

        integrationLogger.debug("Leaving parseFlatFile");
        return col;
    }


        // XML tag's
    private final String MSG_START_INTERFACE =
        " xmlns=\"http://www.ibm.com/maximo\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" creationDateTime=\"2009-01-12T06:23:20-05:00\" transLanguage=\"EN\" baseLanguage=\"EN\" maximoVersion=\"7 1 20100522-0325 V7117-47\" event=\"1\">";

        private final String TAG_START_HEADER ="<Header operation=\"Notify\" event=\"0\">";
        private final String TAG_END_HEADER = "</Header>";

        private final String TAG_SENDERID = "SenderID";

        private final String TAG_START_CONTENT = "<Content>";
        private final String TAG_END_CONTENT = "</Content>";

        private final String TAG_MXLOCATIONSET = "MXLOCATIONSSet";
        private final String TAG_LOCATIONS = "LOCATIONS";

        private final String TAG_ORGID = "ORGID";

        private final String TAG_SITEID = "SITEID";

        private final String TAG_LOCATION = "LOCATION";

        private final String TAG_DESCRIPTION = "DESCRIPTION";

        //private final String TAG_TYPE = "TYPE";

        private final String TAG_START_GLACCOUNT = "<GLACCOUNT>";
        private final String TAG_END_GLACCOUNT = "</GLACCOUNT>";

        private final String TAG_VALUE = "VALUE";

        private final String TAG_MXASSETSET = "MXASSETSet";
        private final String TAG_ASSET = "ASSET";

        private final String TAG_ASSETNUM = "ASSETNUM";

        //private final String TAG_ASSETTYPE = "ASSETTYPE";

        private final String TAG_INSTALLDATE = "INSTALLDATE";

        private final String TAG_CHANGEDATE = "CHANGEDATE";

        private final String TAG_OAASSETNUM = "OAASSETNUM";

        // Format definitions
        private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+08:00'";


    /*
     * Author: BTE
     * 13 FEB 2006 - Create a XML document
     */
        //START SR-104
        //private Collection generateXMLDocument(Collection col) throws Exception
    private Collection generateXMLDocument(Collection col, String file) throws Exception
    //END SR-104
    {
        integrationLogger.debug("Entering generateXMLDocument");

        Collection xmlCol = new Vector();

        Iterator iterParsedData = col.iterator();
        while (iterParsedData.hasNext()) {

                // Get new record to convert to XML
                Vector vec = (Vector)iterParsedData.next();

                //Skip row is number of field is not 8
                if(vec.size()!=8) {
                        integrationLogger.debug((String) vec.elementAt(3));
                        continue;
                }

                String location = (String) vec.elementAt(3);

//Begin modification SR-122 - Blend the logic of normal and special assets
                                boolean isinvalidlocation = false;
//End modification SR-122 - Blend the logic of normal and special assets
                                if (location.length() >= 3) {

//Begin modification DR-018
                                        // Get the GL configuration to merge correctly
                                        MXServer mxserver = MXServer.getMXServer();
                                        UserInfo userinfo = getRunasUserInfo();
                                        MboSetRemote glconfigureset = mxserver.getMboSet("GLCONFIGURE", userinfo);
                                        String gldelimiter = glconfigureset.getMbo(0).getString("delimiter");
                                        MaxVarServiceRemote maxvarserviceremote = (MaxVarServiceRemote)MXServer.getMXServer().lookup("MAXVARS");
//Begin modification DR-051
//                  String glquestion = maxvarserviceremote.getString("GLQUESTION", site.getOrgID());
                                        String glquestion = maxvarserviceremote.getString("GLQUESTION", "");
//End modification DR-051
                                        /*
                                 * Merge the 2 GL account as follows :
                                 *      if the segment of the template contains ?, set the segment to ?
                                 *      otherwise, set the segment of the GL account from the file
                                 */
                                        String glaccount = (String) vec.elementAt(6);
                                        String[] glaccountseg = glaccount.split(gldelimiter);
                                        String glactemplate = getParamAsString("GLACTEMPLATE");
                                        String[] glactemplateseg = glactemplate.split(gldelimiter);
                                        // Verify format of crontask parameter
                                        if (glactemplateseg.length != glconfigureset.count())
                                                throw new Exception("GLACTEMPLATE parameter does not contain the correct number of segments");
                                        for (int i = 0; i < glactemplateseg.length; i ++)
                                        {
                                                if (glactemplateseg[i].indexOf(glquestion) >= 0)
                                                        glaccountseg[i] = glactemplateseg[i];
                                        }
                                        // Rebuild the GL account
                                        glaccount = "";
                                        for (int i = 0; i < glaccountseg.length; i ++)
                                        {
                                                glaccount += glaccountseg[i];
                                                // Delimiter after that except for the last segment
                                                if (i < glaccountseg.length - 1)
                                                        glaccount += gldelimiter;
                                        }
                                        // Set the GL account back in to the vector
                                        vec.setElementAt(glaccount, 6);
//End modification DR-018

//Begin modification SR-122 - Blend the logic of normal and special assets
/*                              if (searchList(null, location.substring(1,3))) {
                                try {
                                        //Normal Asset
                                        EMSSite site = new EMSSite((String) vec.elementAt(3), getRunasUserInfo());

                                        //Check if location exist. If location exist, site id is not null
                                        if(site.getSiteID()!=null){

                                                String assetXml = genAssetXml(TAG_MXASSET, TAG_ASSET, vec);
                                                xmlCol.add(assetXml);

                                                String locXml = genLocXml(TAG_MXLOCATIONS, TAG_LOCATIONS, vec);
                                                xmlCol.add(locXml);

                                        } else {
                                        throw new Exception("Location missing.");
                                        }

                                } catch(Exception e) {
                                        // BTE - 27 JUN 2006 - DR-165 and DR-168
                                        //[OFA]
                                                //BEGIN SR-104
                                                toEmail = true;
                                                //errMessage.append(vec.elementAt(3) + SPACE + "-" + SPACE + e.getMessage());
                                                errMessage.append("[OFA] In file "+file+": "+vec.elementAt(3) + SPACE + "-" + SPACE + e.getMessage());
                                                //END SR-104
                                                errMessage.append(NEWLINE);

                            }

                        } else {
                                String assetSpXml = genSpAssetXml(TAG_MXASSET, TAG_ASSET, vec);
                                if(assetSpXml!=null){
                                        xmlCol.add(assetSpXml); //Add asset xml
                                        xmlCol.add("");                 //Add dummy location xml
                                }
                        }
*/
                                EMSSite site = new EMSSite(location, getRunasUserInfo());
                                // Check if location exists. If location exists, site id is not null. Otherwise, ignore this record
                                if (site.getSiteID() != null)
                                {
                                        try
                                        {
                                                // Check function type to know which asset type it is : normal (crane, etc) or special (spreader, etc)
                                                boolean isnormalasset = true;
                                                if (!searchList(null, location.substring(1,3)))
                                                {
                                                        // Special asset : spreader, etc
                                                        isnormalasset = false;
                                                }


                                                // Create XML interface messages for asset and location
                                        String assetXml = genAssetXml(TAG_MXASSETSET, TAG_ASSET, vec, isnormalasset);
                                                System.out.println("--xml--" + assetXml);
                                                xmlCol.add(assetXml);
                                        String locXml = genLocXml(TAG_MXLOCATIONSET, TAG_LOCATIONS, vec);
                                                System.out.println("--xml--" + locXml);
                                        xmlCol.add(locXml);
                                        }
                                        catch (Exception e)
                                        {
                                                        toEmail = true;
                                                        errMessage.append("[OFA] In file " + file + ": " + location + " - " + e.getMessage());
                                                        errMessage.append(NEWLINE);
                                                }
                                }
                                else
                                        isinvalidlocation = true;
//End modification SR-122

                } else {
//Begin modification SR-122
                                isinvalidlocation = true;
                        }
                        if (isinvalidlocation)
                        {
//End modification SR-122
                                //BEGIN SR-104
                                toEmail = true;
                                errMessage.append("[OFA] In file "+file+": "+vec.elementAt(3) + SPACE + "-" + SPACE + "Invalid location.");
                                //errMessage.append(vec.elementAt(3) + SPACE + "-" + SPACE + "Invalid location.");
                                //END SR-104

                                errMessage.append(NEWLINE);
                }
        }

        // Clear collection
        col.clear();

        integrationLogger.debug("Leaving generateXMLDocument");

        return xmlCol;
    }


    /*
     * Author: BTE
     * 23 FEB 2006 - Generate Locations XML
     */
    private String genLocXml(String TAG_MXLOCATIONSET, String TAG_LOCATIONS, Vector vec) throws Exception {

        integrationLogger.debug("Entering genLocXml");

        // Site id
        String siteId =  null;
        EMSSite site = null;

                site = new EMSSite((String) vec.elementAt(3), getRunasUserInfo());
                siteId = site.getSiteID();


                if (siteId == null) {
                        siteId = "";
                }

                // Xml value
                String orgId = site.getOrgID();
                String location = (String) vec.elementAt(3);
                //String type = (String) vec.elementAt(5);
                //String description = (String) vec.elementAt(4);
                String glAccount = (String) vec.elementAt(6);
//      Begin modification SR-105
                String oaAssetnum = getOAAssetNum((String)vec.elementAt(2));
//      End modification SR-105




System.out.println("generating xml for locations");

        // Create XML
        String xml =
                "<SyncMXLOCATIONS"+ // Interface name
                        MSG_START_INTERFACE +
                        /*TAG_START_HEADER +
                        mxXml.genTagSting(TAG_SENDERID, extSys) + // External system
                        TAG_END_HEADER +
                        TAG_START_CONTENT +*/
                        "<"+TAG_MXLOCATIONSET+">" + //Integration object
                        "<" + TAG_LOCATIONS + " action=\"AddChange\">" + // object
                        mxXml.genTagSting(TAG_ORGID, orgId) +
                        mxXml.genTagSting(TAG_SITEID, siteId) +
                        mxXml.genTagSting(TAG_LOCATION, location) +
//      Begin modification SR-105
                        mxXml.genTagSting(TAG_OAASSETNUM, oaAssetnum) +
//      End modification SR-105
                        //mxXml.genTagSting(TAG_TYPE, type) +
                        //mxXml.genTagSting(TAG_DESCRIPTION, description) +
                        TAG_START_GLACCOUNT +
                        mxXml.genTagSting(TAG_VALUE, glAccount) +
                        TAG_END_GLACCOUNT +
                        "</"+TAG_LOCATIONS+">" + // object
                        "</" +TAG_MXLOCATIONSET+ ">" + //Integration object
                        "</SyncMXLOCATIONS>"; // Interface name


System.out.println("location xml ***"+xml);

                integrationLogger.debug("Leaving genLocXml"+xml);
                return xml;
    }


        /*
         * Generate Asset XML
         */
//Begin modification SR-122
//    private String genAssetXml(String intObject, String obj, Vector vec) throws Exception {
        private String genAssetXml(String TAG_MXASSETSET, String TAG_ASSET, Vector vec, boolean isnormalasset)
                        throws Exception
        {
//End modification SR-122

        integrationLogger.debug("Entering genAssetXml");

        DateFormat timeStampFormat = new SimpleDateFormat(DATE_TIME_FORMAT);

        // Convert string to date
        String dateStr = (String) vec.elementAt(7);
        Date date = convertDate(dateStr);

        if (date == null) {
                date = new Date();
        }

        // Site id
        String siteId =  null;
        EMSSite site = null;

                site = new EMSSite((String) vec.elementAt(3), getRunasUserInfo());
                siteId = site.getSiteID();

                if (siteId == null) {
                        siteId = "";
                }

                // Xml value
                String orgId = site.getOrgID();
                String location = (String) vec.elementAt(3);
                String oaAssetnum = getOAAssetNum((String)vec.elementAt(2));

//Begin modification SR-122
//              String assetNum = location.substring(1,3) + oaAssetnum;
                String assetNum = (isnormalasset) ? location.substring(1,3) + oaAssetnum : location;
//End modification SR-122
                //String assetNum = getL2LocId(location) + oaAssetnum;

                //String assetType = (String) vec.elementAt(5);
                String description = (String) vec.elementAt(4);
                String installDate = timeStampFormat.format(date);
                String changeDate = timeStampFormat.format(date);

// Begin modification SR-095
                String glAccount = (String) vec.elementAt(6);
//      End modification SR-095

System.out.println("generating location xml ***");

        // Create XML - merged object
        String xml =
                "<SyncMXASSET "+MSG_START_INTERFACE +
                        "<" + TAG_MXASSETSET + ">" + //Integration object
                        "<" + TAG_ASSET + " action=\"AddChange\">" + // object
                        mxXml.genTagSting(TAG_ORGID, orgId) +
                        mxXml.genTagSting(TAG_SITEID, siteId) +
                        mxXml.genTagSting(TAG_LOCATION, location) +
                        mxXml.genTagSting(TAG_OAASSETNUM, oaAssetnum) +
                        mxXml.genTagSting(TAG_ASSETNUM, assetNum)+
                        //mxXml.genTagSting(TAG_ASSETTYPE, assetType) +
                        mxXml.genTagSting(TAG_DESCRIPTION, description) +
                        mxXml.genTagSting(TAG_INSTALLDATE, installDate) +
                        mxXml.genTagSting(TAG_CHANGEDATE, changeDate) +
//      Begin modification SR-095
                        TAG_START_GLACCOUNT +
                        mxXml.genTagSting(TAG_VALUE, glAccount) +
                        TAG_END_GLACCOUNT +
//      End modification SR-095
                        "</"+ TAG_ASSET+">" + // object
                        "</"+TAG_MXASSETSET+">" + //Integration object
                        "</SyncMXASSET>"; // Interface name


                System.out.println("location xml ***"+xml);
                integrationLogger.debug("Leaving genAssetXml"+xml);
                return xml;
    }


//Begin modification SR-122 - method now obsolete

        /*
         * Generate Asset XML for Spreader
         */
/*    private String genSpAssetXml(String intObject, String obj, Vector vec) throws Exception {

        integrationLogger.debug("Entering genSpAssetXml");

        DateFormat timeStampFormat = new SimpleDateFormat(DATE_TIME_FORMAT);

        // Convert string to date
        String dateStr = (String) vec.elementAt(7);
        Date date = convertDate(dateStr);

        if (date == null) {
                date = new Date();
        }


                // Xml value
                //String orgId = site.getOrgID();
                String oaAssetnum = getOAAssetNum((String)vec.elementAt(2));
                String assetNum =  (String)vec.elementAt(3);
                String description = (String) vec.elementAt(4);
                String glAccount = (String) vec.elementAt(6);
                String installDate = timeStampFormat.format(date);
                String changeDate = timeStampFormat.format(date);

                // AssetType

                String assetType = "";
                String assetTypeCode = (String) vec.elementAt(5);
                if(assetTypeCode.compareTo("SL SPREADER")==0){
                        assetType = "SP";
                }
                else if(assetTypeCode.compareTo("TL SPREADER")==0){
                        assetType = "TL";
                }

        // Site id
        String siteId=null;
                String siteIdPrefix = assetNum.substring(0,1) ;

                if(siteIdPrefix.compareTo("K")==0){
                siteId = "KT";
        }
        else if(siteIdPrefix.compareTo("P")==0){
                siteId = "PPT1";
        }
        else if(siteIdPrefix.compareTo("B")==0){
                siteId = "BT";
        }
        else if(siteIdPrefix.compareTo("T")==0){
                siteId = "TPT";
        }
        else
                return null;

        // Create XML - merged object
        String xml =
                "<" + assetIfaceName + // Interface name
                        MSG_START_INTERFACE +
                        TAG_START_HEADER +
                        mxXml.genTagSting(TAG_SENDERID, extSys) + // External system
                        TAG_END_HEADER +
                        TAG_START_CONTENT +
                        "<" + intObject + ">" + //Integration object
                        "<" + obj + " action=\"AddChange\">" + // object
                        //mxXml.genTagSting(TAG_ORGID, orgId) +
                        mxXml.genTagSting(TAG_SITEID, siteId) +
                        mxXml.genTagSting(TAG_OAASSETNUM, oaAssetnum) +
                        mxXml.genTagSting(TAG_ASSETNUM, assetNum)+
                        //mxXml.genTagSting(TAG_ASSETTYPE, assetType) +
                        mxXml.genTagSting(TAG_DESCRIPTION, description) +
                        mxXml.genTagSting(TAG_INSTALLDATE, installDate) +
                        mxXml.genTagSting(TAG_CHANGEDATE, changeDate) +
                        TAG_START_GLACCOUNT +
                        mxXml.genTagSting(TAG_VALUE, glAccount) +
                        TAG_END_GLACCOUNT +
                        "</" + obj + ">" + // object
                        "</" + intObject + ">" + //Integration object
                        TAG_END_CONTENT +
                        "</" + assetIfaceName + ">"; // Interface name

                integrationLogger.debug("Leaving genSpAssetXml");
                return xml;
    }
*/
//End modification SR-122 - method now obsolete


    /*
     * Author: HCHA
     * 15 May 2006 - Remove the company code from oa asset num
     *               E.g.: Input='101.102341', Ouput='102341'
     */
    private String getOAAssetNum(String assetnum){

        StringTokenizer stringTokenizer = new StringTokenizer(assetnum, ".");

        //Check if assetnum is in this format <company id>.<asset num>
        if(stringTokenizer.countTokens()!=2){
                return assetnum;
        }

        stringTokenizer.nextToken(); //ignore 1st token

        return stringTokenizer.nextToken(); //return 2nd token
    }


    /* Author: HCHA
     * 15 May 2006 - Convert Date
     */
    private Date convertDate(String inDate){
        SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");
        Date outDate = null;
        try{
             outDate = dateformat.parse(inDate);
        }catch(ParseException e){}

        return outDate;
    }


    /* Author: BTE
     * 13 FEB 2006 - Sending message to JMS queue.
     */
    private void sendMessage(byte abyte0[], String ifaceName, int i)
        throws Exception
    {

        integrationLogger.debug("Entering sendMessage"+extSys+"****"+ifaceName);

        try {


                /*
            HashMap hashmap = new HashMap();
            hashmap.put("SENDER", extSys);
            hashmap.put("INTERFACE", ifaceName);
            */
            if(queueProcessor == null)
                queueProcessor = new MEAQueueProcessor();

            queueProcessor.writeDataToQueueIn(abyte0, extSys,ifaceName);

            integrationLogger.debug("Leaving sendMessage");
            }
            catch(Exception exception) {

                throw exception;
            }                                                                                                                                                
        }


        /*
         * Author: BTE
         * 28 FEB 2006 - Get the top level 2 location code
         *                               Example:
         *                                      L1:     KT
         *                                              |
         *                              L2: QC <==
         *                                      |
         *                              L3:     KQC100
         */
        public String getL2LocId(String locId) throws Exception {

                integrationLogger.debug("Entering getL2LocId");

                String location = locId;
                String findLoc = null;
                String parentLoc = null;

                do {

                        parentLoc = searchLocHierarchy(locId);

                        if (parentLoc != null) {
                                findLoc = locId;
                                locId = parentLoc;
                        }

                } while (parentLoc != null);

                String topLocation = findLoc;
                if (topLocation.equalsIgnoreCase(location)) {
                         topLocation = "";
                }

                integrationLogger.debug("Leaving getL2LocId");
                return topLocation;
        }


        /*
         * Author: BTE
         * 28 FEB 2006 - Search location in location hierarchy
         */
        public synchronized String searchLocHierarchy(String locId) throws Exception {

                integrationLogger.debug("Entering searchLocHierarchy");

                String findLoc = null;
                LocHierarchySetRemote locSet;

                locSet = (LocHierarchySetRemote)MXServer.getMXServer().getMboSet("LOCHIERARCHY", getRunasUserInfo());

                String sql = "LOCATION= :1";
                SqlFormat sqlformat = new SqlFormat(getRunasUserInfo(), sql);
            sqlformat.setObject(1, "LOCHIERARCHY", "LOCATION", locId);

            locSet.setWhere(sqlformat.format());

            if(!locSet.isEmpty()) {

                LocHierarchyRemote locHie = (LocHierarchyRemote) locSet.getMbo(0);

                        if(!locHie.isNull("PARENT")){
                                findLoc = locHie.getString("PARENT");
                        }
            } else {

                // BTE - 27 JUN 2006 - DR-165 and DR-168
                        toEmail = true;
                throw new Exception("Location hierarchy cannot be found.");
            }

            integrationLogger.debug("Leaving searchLocHierarchy");
            return findLoc;
        }


        /*
         * Author: BTE
         * 28 FEB 2006 - Search location in location hierarchy
         */
        public boolean searchList(String siteId, String listItem) throws Exception {

                integrationLogger.debug("Entering searchXREF");

                BaseExit ee = new ExternalExit();

                ControlsCache maxifacecontrol = ee.getMaxIfaceControl();

        if(maxifacecontrol.isControlEqual("OFA", "EQUIPLIST", "PSAST", siteId, listItem)){

                integrationLogger.debug("Leaving searchXREF");
                return true;
        }

            integrationLogger.debug("Leaving searchXREF");

            return false;
        }


    /* Author: BTE
     * 13 FEB 2006 - Define Maximo parameter setting in Cron Task
     */
    static
    {
        // BTE: Set the number of the parameter.
        params = null;
        params = new CrontaskParamInfo[11];

        // BTE: All the parameter configurable from Cron Task user interface
        params[0] = new CrontaskParamInfo();
        params[0].setName("SPLITTAG");
        params[0].setDefault("~");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[0].setDescription("Delimiter for flat file.");
        params[0].setDescription("CommonCron","DelimiterFlatFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[1] = new CrontaskParamInfo();
        params[1].setName("EXTSYSNAME");
        params[1].setDefault("OFA");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[1].setDescription("External System Name.");
        params[1].setDescription("CommonCron","ExternalSystem");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[2] = new CrontaskParamInfo();
        params[2].setName("LOCATIONSINTERFACENAME");
        params[2].setDefault("MXLOCATIONSInterface");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[2].setDescription("Location Integration Interface Name.");
        params[2].setDescription("CommonCron","LocIntInterfaceName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[3] = new CrontaskParamInfo();
        params[3].setName("DIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[3].setDescription("Local directory where flat file will be read.");
        params[3].setDescription("CommonCron","LocalDirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[4] = new CrontaskParamInfo();
        params[4].setName("PROCESSDIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[4].setDescription("Temp Directory where processing will be done.");
        params[4].setDescription("CommonCron","TempDirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[5] = new CrontaskParamInfo();
        params[5].setName("ALERTEMAIL");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[5].setDescription("Admin email address for notification of error.");
        params[5].setDescription("CommonCron","Adminemailaddress");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[6] = new CrontaskParamInfo();
        params[6].setName("IMPORTFILENAME");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[6].setDescription("File name of the input file(Includes with 'yyyymmdd*' for current day file)");
        params[6].setDescription("CommonCron","FileNameOfTheInputFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[7] = new CrontaskParamInfo();
        params[7].setName("UNZIPEXEC");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[7].setDescription("Executable for unziping the input flat file.");
        params[7].setDescription("CommonCron","ExecutableUnziping");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[7].setDefault("gunzip -f -q");

        params[8] = new CrontaskParamInfo();
        params[8].setName("ASSETINTERFACENAME");
        params[8].setDefault("MXASSETInterface");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[8].setDescription("Asset Integration Interface Name.");
        params[8].setDescription("CommonCron","AssetIntInterfaceName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[9] = new CrontaskParamInfo();
        params[9].setName("TARGETENABLED");
        params[9].setDefault("0");

//      Begin modification DR-018
                        params[10] = new CrontaskParamInfo();
                        params[10].setName("GLACTEMPLATE");
                        params[10].setDefault("xxx-????-?-xx-xxx-xxxx-????-???");
                        //++ COMM-IT changed to make it compatible with Maximo 7 API
                //params[10].setDescription("GL account template used to define which segments need to be undefined in the location GL account. Only ? matter");
                params[10].setDescription("CommonCron","GLAccountTemplate");
              //-- COMM-IT changed to make it compatible with Maximo 7 API
//      End modification DR-018
    }
}

