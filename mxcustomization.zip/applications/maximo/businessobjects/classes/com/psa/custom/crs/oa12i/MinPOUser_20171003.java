/*     */ package com.psa.custom.oa12i;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import psdi.app.pr.PRRemote;
/*     */ import psdi.app.pr.PRSetRemote;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.iface.migexits.UserExit;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.CombineWhereClauses;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
/*     */ public class MinPOUser
/*     */   extends UserExit
/*     */ {
/*     */   public StructureData setUserValueIn(StructureData irData, StructureData erData)
/*     */     throws MXException, RemoteException
/*     */   {
/*  35 */     integrationLogger.debug("Entering setUserValueIn");
/*     */     
/*     */ 
/*  38 */     erData.breakData();
/*  39 */     erData.moveToFirstObjectStruture();
/*     */     do
/*     */     {
/*  41 */       List list = irData.getChildrenData("POLINE");
/*  42 */       if ((list != null) && (list.size() > 0))
/*     */       {
/*  45 */         String prnum = null;
/*  46 */         String siteid = null;
/*  47 */         Date vendordate = null;
/*  48 */         for (int i = 0; i < list.size(); i++)
/*     */         {
/*  51 */           irData.setAsCurrent(list, i);
/*  52 */           if (!irData.isCurrentDataNull("PRNUM"))
/*     */           {
/*  54 */             prnum = irData.getCurrentData("PRNUM");
/*  55 */             integrationLogger.debug("PRNUM: " + prnum);
/*     */             
/*  57 */             siteid = getSite(prnum);
/*     */             
/*  59 */             irData.setCurrentData("TOSITEID", siteid);
/*     */             
/*     */ 
/*  62 */             irData.setCurrentData("INSPECTIONREQUIRED", 
/*  63 */               getPRLine(prnum, siteid, irData.getCurrentDataAsInt("PRLINENUM")).getString("inspectionrequired"));
/*  66 */             if ((!irData.isCurrentDataNull("VENDELIVERYDATE")) && (vendordate != null)) {
/*  68 */               vendordate = irData.getCurrentDataAsDate("VENDELIVERYDATE");
/*     */             }
/*     */           }
/*     */         }
/*  82 */         if (prnum != null)
/*     */         {
/*  84 */           if (vendordate != null)
/*     */           {
/*  86 */             irData.setParentAsCurrent();
/*  87 */             irData.setCurrentData("VENDELIVERYDATE", vendordate);
/*     */           }
/*  90 */           irData.setAsCurrent(irData.getPrimaryObject());
/*     */           
/*  92 */           irData.setCurrentData("SITEID", siteid);
/*     */         }
/*     */       }
/*  40 */     } while (
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */       erData.moveToNextObjectStructure());
/*  99 */     integrationLogger.debug("Leaving setUserValueIn");
/* 100 */     return irData;
/*     */   }
/*     */   
/*     */   public String getSite(String prnum)
/*     */     throws MXException, RemoteException
/*     */   {
/* 110 */     integrationLogger.debug("Entering getSite");
/*     */     
/* 112 */     PRSetRemote prSet = (PRSetRemote)MXServer.getMXServer().getMboSet("PR", this.userInfo);
/*     */     
/* 114 */     CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
/* 115 */     combinewhereclauses.addWhere("PRNUM= :1");
/* 116 */     String s = combinewhereclauses.getWhereClause();
/* 118 */     if ((s != null) && (s != ""))
/*     */     {
/* 120 */       SqlFormat sqlformat = new SqlFormat(this.userInfo, s);
/* 121 */       sqlformat.setObject(1, "PR", "PRNUM", prnum);
/* 122 */       prSet.setWhere(sqlformat.format());
/* 123 */       if (!prSet.isEmpty())
/*     */       {
/* 125 */         PRRemote pr = (PRRemote)prSet.getMbo(0);
/* 126 */         if (!pr.isNull("SITEID"))
/*     */         {
/* 128 */           integrationLogger.debug("SITEID: " + pr.getString("SITEID"));
/* 129 */           integrationLogger.debug("Leaving getSite");
/* 130 */           return pr.getString("SITEID");
/*     */         }
/*     */       }
/*     */     }
/* 135 */     integrationLogger.debug("Leaving getSite");
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   public MboRemote getPRLine(String prnum, String siteid, int prlinenum)
/*     */     throws MXException, RemoteException
/*     */   {
/* 149 */     MboSetRemote prlineset = MXServer.getMXServer().getMboSet("PRLINE", this.userInfo);
/* 150 */     SqlFormat sqlformat = new SqlFormat("prnum=:1 AND siteid=:2 AND prlinenum=:3");
/* 151 */     sqlformat.setObject(1, "pr", "prnum", prnum);
/* 152 */     sqlformat.setObject(2, "pr", "siteid", siteid);
/* 153 */     sqlformat.setInt(3, prlinenum);
/*     */     
/* 155 */     prlineset.setWhere(sqlformat.format());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 160 */     MboRemote prline = prlineset.getMbo(0);
/* 161 */     prlineset.close();
/* 162 */     return prline;
/*     */   }
/*     */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.MinPOUser
 * JD-Core Version:    0.7.0.1
 */