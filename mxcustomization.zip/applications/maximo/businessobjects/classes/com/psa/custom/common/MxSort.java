/**
 * @author	HCHA
 * Date		Mar 2, 2006
 * Comment	Using Shell Sort Command to Sort Data in the file and output to another file
 */
package com.psa.custom.common;

import java.io.IOException;

/**
 * @author		HCHA
 * @class		MxSort
 * @date		Mar 2, 2006
 * @function	Using Shell Sort Command to Sort Data in the file and output to another file
 */
public class MxSort {

	/**
	 * 
	 * @author		HCHA
	 * @date		Mar 2, 2006
	 * @function	Using Shell Sort Command to Sort Data in the file and output to another file
	 * @param sortCmd
	 * @param inFile
	 * @param outFile
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	static public int sort(String sortCmd, String inFile, String opOpt, String outFile) 
		throws IOException, InterruptedException
	{
		Process proc;
		
		// Execute external command 
		try {
			
			String cmd = sortCmd + " " + inFile + " " + opOpt + " " + outFile;
			System.out.println("MxSort cmd: " + cmd);
			
			proc = Runtime.getRuntime().exec(cmd);
	        int exitVal = proc.waitFor();
	        
	        System.out.println("Process exitValue: " + exitVal); 
			
	        return exitVal;
			
		} catch (IOException e) {
			throw new IOException(e.getMessage());			 
		} catch (InterruptedException e) {
			throw new InterruptedException(e.getMessage());	
		}
	}
}
