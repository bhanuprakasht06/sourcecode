// Decompiled by DJ v3.0.0.63 Copyright 2002 Atanas Neshkov  Date: 3/22/2011 8:29:03 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   MxXml.java

package com.psa.custom.common;

import java.io.IOException;
import java.io.StringWriter;
import javax.xml.parsers.*;
//import org.apache.crimson.jaxp.DocumentBuilderFactoryImpl;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import psdi.iface.mic.MicUtil;
import psdi.util.logging.MXLogger;
import javax.xml.parsers.DocumentBuilderFactory;
public class MxXml
{

    public MxXml()
    {
    }

    public String genTagSting(String tag, String text)
    {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        Document xmlDoc = null;
        Element element = null;
        try
        {
            DocumentBuilder docBuilder = dbFactory.newDocumentBuilder();
            xmlDoc = docBuilder.newDocument();
            element = xmlDoc.createElement(tag);
            element.appendChild(xmlDoc.createTextNode(text));
        }
        catch(ParserConfigurationException e)
        {
            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
        }
        return genXMLString(element);
    }

    private String genXMLString(Element element)
    {
        String toRemove = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        String itemStr = null;
        String item = null;
        StringWriter strWriter = null;
        XMLSerializer msgSerializer = null;
        OutputFormat outFormat = null;
        try
        {
            msgSerializer = new XMLSerializer();
            strWriter = new StringWriter();
            outFormat = new OutputFormat();
            msgSerializer.setOutputCharStream(strWriter);
            msgSerializer.setOutputFormat(outFormat);
            msgSerializer.serialize(element);
            itemStr = strWriter.toString();
            item = itemStr.substring("<?xml version=\"1.0\" encoding=\"UTF-8\"?>".length() + 1);
            strWriter.close();
        }
        catch(IOException e)
        {
            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
        }
        return item;
    }
}