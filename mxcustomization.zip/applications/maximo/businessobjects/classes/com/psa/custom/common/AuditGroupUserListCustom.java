/*
 * Modification history
 * 15-11-2012	WMJ	Creation	EMS-534 [Security Group]Email to notify all Engineering Managers and DSC/s when there are any changes to the Engineering Manager or Section Head Maximo Security Groupings 
 *
 */
package com.psa.custom.common;

import java.rmi.RemoteException;
import java.sql.SQLException;
import javax.mail.MessagingException;

import psdi.common.action.ActionCustomClass;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboSet;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.common.commtmplt.CommTemplate;
import psdi.common.commtmplt.*;


public class AuditGroupUserListCustom
implements ActionCustomClass
{

	public AuditGroupUserListCustom() 
	{
	}

	public void applyCustomAction(MboRemote mboRemote, Object aobj[])
	throws MXException, RemoteException
	{
		//Get the commtemplate set to be sent out
		MboSetRemote commSetRemote = mboRemote.getMboSet("$commSetRemote", "COMMTEMPLATE", "templateid='EMSHGRPUSR'");
		
		if(commSetRemote.count() > 0)
		{
			//Get the commtemplate to be sent out
			CommTemplate commRemote = (CommTemplate)commSetRemote.getMbo(0);
			
			// mboRemote should be that object whose content wil be replaced in commtemplate. So, if your commtemplate sends out workorder information nand you have used :wonum in your template make sure mboRemote is that object whose information will be resolved/replaced
			//get subject of commtemplate
			SqlFormat sqf = new SqlFormat(mboRemote, commRemote.getString("subject"));
			
			//Set IgnoreUnresolved to true if you want to ignore any errors in commtemplate, errors for stuff like if you have used :wonum and it cannot resolve this attribute.
			sqf.setIgnoreUnresolved(true);
			
			//Resolve Content method below converts template in to the dynamic content, by resolving I mean instead of :wonum it will put the current records wonum.
			String subject = sqf.resolveContent();
			
			//Similarly do it for the message content
			sqf = new SqlFormat(mboRemote, commRemote.getString("message"));
			
			sqf.setIgnoreUnresolved(true);
			
			String message = sqf.resolveContent();
			
			if (message.length() > 0)
			{
				//add a new line to message content so that the list appears from the next line
				message = message + "\r\n";
				
				//get the mboset where the changes are to the security group RL_SECTHEAD or RL_ENGMAN
				
				/*
		    	 * 07-09-2020
		    	 * <START> - Code below has been commented as part of the DB migration from Oracle to SQL 
		    	SqlFormat sqlformat2 = new SqlFormat("GROUPNAME in ('RL_NCTSECTHEAD','RL_SECTHEAD','RL_ENGMAN') and trunc(EAUDITTIMESTAMP)=trunc(SYSDATE-1)");
				
				*/
				SqlFormat sqlformat2 = new SqlFormat("GROUPNAME in ('RL_NCTSECTHEAD','RL_SECTHEAD','RL_ENGMAN') and CONVERT(DATETIME, CONVERT(DATE, EAUDITTIMESTAMP))=CONVERT(DATETIME, CONVERT(DATE, dateadd(day,-1,getdate())))");
				
				
				MboSetRemote agroupuserset = mboRemote.getMboSet("$agroupuserset", "A_GROUPUSER", sqlformat2.format());
				int i = 0;
				for (MboRemote agroupuser; (agroupuser = agroupuserset.getMbo(i)) != null; i++)
				{
					if(agroupuser.getString("EAUDITTYPE").equals("I"))//if insert
					{
						message = message + agroupuser.getString("USERID") + " inserted into " + agroupuser.getString("GROUPNAME") + "\r\n";
					}
					else if (agroupuser.getString("EAUDITTYPE").equals("D"))//if delete
					{
						message = message + agroupuser.getString("USERID") + " deleted from " + agroupuser.getString("GROUPNAME") + "\r\n";
					}
				}
			}

			//try catch to send out email
			try 
			{
				//get sender email
				String sendFrom = commRemote.getString("sendFrom");
			
				//get receipent email strings
		  		String to = commRemote.convertSendTo("COMMTMPLT_TO", mboRemote);
		      	String cc = commRemote.convertSendTo("COMMTMPLT_CC", mboRemote);
      			String bcc = commRemote.convertSendTo("COMMTMPLT_BCC", mboRemote);

      			//Send out the email. Note the 2 nulls behind are for attachments(meaning attachments from commtemplate will not work)
				
      			//MXServer.sendEMail(to, cc, bcc, sendFrom, subject, message, sendFrom, null, null);
			
			}
			catch(/*Messaging*/Exception messagingexception)
			{
				messagingexception.printStackTrace();
            	String as[] = {
	                messagingexception.getMessage()
    	        };
	            throw new MXApplicationException("securgroup", "emailNotSent", as);
			}
		
		}
	
	}
	
}

