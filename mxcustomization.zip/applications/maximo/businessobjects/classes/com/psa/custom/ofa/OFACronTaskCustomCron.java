/*
 * Enhanced  by BCT 

 * 
 * Modified Existing class
 * 
 * integrating the OFA record to Maximo Using this cron task file
 * 
 * 16-03-16 WMJ EMS-1031 [Crontask]OFA crontask unable to pick up file to process
 * 
 */
/*
 * Modified  by Karthik (Comm-IT) 
 * 
 * Modified Existing class
 * 
 * This file has been modified to pick up the Maximo's 8 segment GL code, with the reference of 7 segment GL code passed by GFS.
 * 
 * This logic can be reverted back to the Original logic(OFACronTaskCustom) after Maximo starts following 7 segment GL code same as GFS.
 */
package com.psa.custom.ofa;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.mail.MessagingException;
import javax.management.loading.PrivateClassLoader;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;
import com.psa.custom.ois.MxLog;

import psdi.app.asset.AssetSetRemote;
import psdi.app.location.LocationSetRemote;

import psdi.app.system.CrontaskParamInfo;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;

import psdi.mbo.DBShortcut;
import psdi.mbo.MboAccessInterface;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.MaxVarServiceRemote;
import psdi.server.SimpleCronTask;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class OFACronTaskCustomCron extends SimpleCronTask {


	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	private static CrontaskParamInfo params[];
	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
	private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+08:00'";
	private static final String SPACE = " ";
	private static final String SUBJECT = "[EMS-OFA] Error: Error occured in OFA Cron.";
	private String directory;
	private	String unzipExec;              
	private  String processDirectory; 
	private String splitTag;
	private String glActTemplate;
	private File loadDir;
	private String importFileName;
	private int noOfDays;
	private String adminEmailId;
	private MxEmail email;
	private RecoveryService recoveryService;
	private Vector vec;
	private String logFile;
	private MxLog mxLog;
	private boolean enableLog;
	//private String OfaAssetLocationLen;


	public OFACronTaskCustomCron() {
		directory=null;
		processDirectory=null;
		splitTag=null;
		unzipExec=null;
		loadDir=null;
		importFileName=null;
		noOfDays=0;
		glActTemplate=null;
		adminEmailId=null;
		recoveryService=null;
		vec=null;
		logFile=null;
		enableLog=false;
		mxLog = new MxLog();
	}


	public CrontaskParamInfo[] getParameters() throws MXException,
	RemoteException {

		return params;
	}

	static
	{

		params = null;
		params = new CrontaskParamInfo[10];
		params[0] = new CrontaskParamInfo();
		params[0].setName("ALERTEMAIL");
		params[0].setDescription("CommonCron","Administrator Mail ID");
		params[1] = new CrontaskParamInfo();
		params[1].setName("DIRECTORY");
		params[1].setDescription("CommonCron","LocalDirectory");
		params[2] = new CrontaskParamInfo();
		params[2].setName("GLACTEMPLATE");
		params[2].setDescription("CommonCron","GLAccountTemplate");
		params[3] = new CrontaskParamInfo();
		params[3].setName("PROCESSDIRECTOR");
		params[3].setDescription("CommonCron","TempDirectory");
		params[4] = new CrontaskParamInfo();
		params[4].setName("IMPORTFILENAME");
		params[4].setDescription("CommonCron","FileNameOfTheInputFile");
		params[5] = new CrontaskParamInfo();
		params[5].setName("SPLITTAG");
		params[5].setDefault("~");
		params[5].setDescription("CommonCron","DelimiterFlatFile");
		params[6] = new CrontaskParamInfo();
		params[6].setName("UNZIPEXEC");
		params[6].setDescription("CommonCron","ExecutableUnziping");
		params[7] = new CrontaskParamInfo();
		params[7].setName("DAYS");
		params[7].setDefault("0");
		params[7].setDescription("CommonCron","No of days transaction has to be removed");
		params[8] = new CrontaskParamInfo();
		params[8].setName("LOGPATH");
		params[8].setDescription("CommonCron","LogDirectory");
		params[9] = new CrontaskParamInfo();
		params[9].setName("ENABLELOG");
		params[9].setDescription("CommonCron","Enable log output(\"Y\" or \"N\").");
		
	}


	// Refreshing Cron parameter

	private void refreshSettings() throws RemoteException, MXException
	{
		try
		{
			adminEmailId=getParamAsString("ALERTEMAIL");
			email.setAdmin(adminEmailId);
			directory=getParamAsString("DIRECTORY");
			loadDir = new File(directory);
			glActTemplate=getParamAsString("GLACTEMPLATE");
			processDirectory=getParamAsString("PROCESSDIRECTOR");
			DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
			String todayDate=fileDateFormat.format(new Date());
			importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmdd",todayDate);
			splitTag=getParamAsString("SPLITTAG");
			unzipExec=getParamAsString("UNZIPEXEC");
			noOfDays=getParamAsInt("DAYS");
			enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y")==0);
			logFile=getParamAsString("LOGPATH");
			String logFilePath="FAINTER_yyyyMMdd";
			String logReplace=logFilePath.replace("yyyyMMdd", todayDate);
			String lastLog=".log";
			String logFileName=logFile+logReplace+lastLog;
			System.out.println("OFA logFileName: "+logFileName);
			mxLog.setEnabled(enableLog);
			mxLog.setLogFilePath(logFileName);
			mxLog.setLogTag(getName());
			mxLog.createLogFile();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//	email.send(SUBJECT,e.getMessage());
		}

	}

	public void start()
	{
		try {
			refreshSettings();
		} catch (RemoteException e) {

			e.printStackTrace();
		} catch (MXException e) {

			e.printStackTrace();
		}

		super.start();
	}
	// Validating the parameter values 
	private boolean isReqParamSet() {
		if (adminEmailId == null)
			return false;
		if (directory == null)
			return false;
		if (glActTemplate == null)
			return false;
		if (processDirectory == null)
			return false;
		if (importFileName == null)
			return false;

		if (splitTag == null)
			return false;
		if (unzipExec == null)
			return false;
		//if (logfile == null)
			//return false;
		return true;
	}


	public void cronAction() {

		//start of EMS-1031
		try {
			refreshSettings();
		} catch (RemoteException e) {

			e.printStackTrace();
		} catch (MXException e) {

			e.printStackTrace();
		}
		//end of EMS-1031

		try
		{
			if(isReqParamSet())
			{
				mxLog.writeLog("----------OFACronTaskCustomCron----------");
				integrationLogger.debug("[OFA CRON] Loading");
				
				MboSetRemote ofa_backMboSet=MXServer.getMXServer().getMboSet("OFABACKUP", getRunasUserInfo());
				if(noOfDays>0)
				{
					//Deleting the data from backup table based on parameter 	
					DBShortcut dbShortcut = new DBShortcut();
					dbShortcut.connect(getRunasUserInfo().getConnectionKey());

					//String deletetodaysrecords="DELETE OFABACKUP WHERE TRUNC(TRANSDATE)<TRUNC(SYSDATE)-"+noOfDays+"";
					MboSetRemote ofabackup_Set = MXServer.getMXServer().getMboSet("OFABACKUP",getRunasUserInfo());
					ofabackup_Set.setWhere("CONVERT(DATETIME, CONVERT(DATE, TRANSDATE))<CONVERT(DATETIME, CONVERT(DATE, GETDATE()))-"+noOfDays+"");
					ofabackup_Set.reset(); 
					if(ofabackup_Set.count()>0)
					{
						String deletetodaysrecords="DELETE OFABACKUP WHERE  CONVERT(DATETIME, CONVERT(DATE, TRANSDATE)) < CONVERT(DATETIME, CONVERT(DATE, GETDATE()))-"+noOfDays+"";
						System.out.println(deletetodaysrecords);
						SqlFormat delRecSql=new SqlFormat(deletetodaysrecords);					
						dbShortcut.executeQuery(delRecSql.format());
						dbShortcut.commit();	
						dbShortcut.close();
					}

				}


				if ((importFileName != null) && (directory != null)) {

					if (!checkFileExist(importFileName)) {

						integrationLogger.debug("[OFA CRON] unable to read the input file");
						mxLog.writeLog("----OFACronTaskCustomCron------unable to read the input file");
					}
					else
					{
						processFolderData(ofa_backMboSet);

					}

				} 
			}
			else
			{
				integrationLogger.info("Required Parameters are not set.");
				mxLog.writeLog("----OFACronTaskCustomCron------Required Parameters are not set.");
			}
			System.out.println();
			integrationLogger.debug("[OFA CRON] End of cron");
		}
		catch(Exception e)
		{

			e.printStackTrace();
			//email.send(SUBJECT,e.getMessage());

		}

	}
	// Check the file is exist in the specified path 
	public boolean checkFileExist (String fileExtension) {

		SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
		File[] afile = loadDir.listFiles(filter);
		if(afile != null) {
			int i = afile.length;

			if (i > 0)
			{
				integrationLogger.debug("File found. Leaving checkFileExist");	
				return true;
			}
		}

		integrationLogger.debug("File not found. Leaving checkFileExist");
		mxLog.writeLog("----OFACronTaskCustomCron------File not found.");
		return false;
	}

	// Processing the OFA interface file
	public void processFolderData(MboSetRemote ofa_backMboSet) throws MXException,Exception {
		
		try {
			SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);

			//System.out.println("OFACronTaskCustomCron Inside processFolderData");

			integrationLogger.debug("[OFA CRON] Processing the folder data");
			mxLog.writeLog("----OFACronTaskCustomCron------Processing the folder data");
			
			File afile[] = loadDir.listFiles(filter);
			if(afile != null) {

				int i = afile.length;
				int fileprocessed = 0;

				for(int j = 0; j < i; j++) {

					recoveryService = new RecoveryService(afile[j]); 
					System.out.println("["+getName()+"] Processing '" + afile[j].getName() + "'" );
					mxLog.writeLog("----OFACronTaskCustomCron------["+getName()+"] Processing '" + afile[j].getName() + "'" );
					try {                                                                                                                        

						String file = processDirectory + afile[j].getName();

						System.out.println("OFACronTaskCustomCron Before filecopy"+afile[j].getName());
						//mxLog.writeLog("OFACronTaskCustomCron Before filecopy"+afile[j].getName());
						
						MxFileCopy.fileCopy(afile[j].toString(), processDirectory + afile[j].getName());

						//Unzip File
						String cmd = unzipExec + SPACE + file;
						System.out.println("OFACronTaskCustomCron Before unzip "+cmd);
						mxLog.writeLog("----OFACronTaskCustomCron------unzip "+cmd);
						int returnUnzipCmd=MxZip.unzipFile(cmd);

						System.out.println("OFACronTaskCustomCron After unzip returnUnzipCmd-->");
						System.out.println(returnUnzipCmd);
						mxLog.writeLog("----OFACronTaskCustomCron------unzip executed-->"+returnUnzipCmd);
						if (returnUnzipCmd==0)
						{

							//Get filename without extension

							int dotPos = file.lastIndexOf(".");

							String extractedFile = file.substring(0,dotPos);

							Collection col = parseFlatFile(extractedFile);
							System.out.println("OFACronTaskCustomCron Before ofaRecordProcessing");
							ofaRecordProcessing(col,ofa_backMboSet);
							System.out.println("OFACronTaskCustomCron After ofaRecordProcessing");
							File fExtractedFile = new File(extractedFile);

							fExtractedFile.delete();
						}
					}
					finally {
						try {
							integrationLogger.debug("processFolderData: End Recovery");
							mxLog.writeLog("----OFACronTaskCustomCron------processFolderData: End Recovery");
							recoveryService.endRecovery();
						}
						catch(Exception e){

						}
					}
					fileprocessed++;


					if(fileprocessed!=0){
						System.out.println("["+getName()+"] "+fileprocessed+ " file(s) processed." );
						mxLog.writeLog("----OFACronTaskCustomCron------["+getName()+"] "+fileprocessed+ " file(s) processed." );
					}



				}



			}

		}catch(Exception e)
		{
			e.printStackTrace();
			email.send(SUBJECT,e.getMessage());
		}
	}

	// Parse Interface file and store into the collection
	private Collection parseFlatFile(String file) throws IOException {

		System.out.println("Start parseFlatFile");	 
		mxLog.writeLog("----OFACronTaskCustomCron------Start parseFlatFile");
		Collection col = new Vector();
		try
		{
			System.out.println();
			BufferedReader flatfileReader;
			flatfileReader = new BufferedReader(new FileReader(file));

			String curLine = flatfileReader.readLine();

			System.out.println("Inside parseFlatFile FileName  --> "+file);	

			System.out.println("Inside parseFlatFile curLine  --> "+curLine);	

			while((curLine = flatfileReader.readLine()) != null)
			{

				String[] str = curLine.split(splitTag);

				Vector vec = new Vector();

				for(int i=0;i<str.length;i++){

					System.out.println("Inside parseFlatFile values in the file --> "+str[i].trim());     
					vec.add(str[i].trim());

				}

				System.out.println();
				System.out.println("End parseFlatFile");
				col.add(vec);
			}

			integrationLogger.debug("[OFA CRON] Flat file parsing completed");
			mxLog.writeLog("----OFACronTaskCustomCron------Flat file parsing completed");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//	email.send(SUBJECT,e.getMessage());
		}
		return col;
	}

	// Interface file has been updated into Asset and Location application if data don't exist in location and Asset. it will store into OFABACKUP table
	private void ofaRecordProcessing(Collection col,MboSetRemote ofa_backMboSet) throws MXException,RemoteException, ParseException, MessagingException, SQLException
	{
		System.out.println("OFACronTaskCustomCron Inside ofaRecordProcessing");
		DBShortcut dbShortcut = new DBShortcut();
		dbShortcut.connect(getRunasUserInfo().getConnectionKey());
		DateFormat timeStampFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
		String errorMessage="";
		MboRemote ofa_backMbo = null;
		Iterator iterParsedData = col.iterator();

		System.out.println("OFACronTaskCustomCron Inside ofaRecordProcessing numberOfRecords");
		System.out.println(col.size());

		while (iterParsedData.hasNext()) {

			System.out.println("OFACronTaskCustomCron Inside ofaRecordProcessing while loop");
			try {
				vec = (Vector)iterParsedData.next();

				if(vec.size()!=9) {
					integrationLogger.debug((String) vec.elementAt(3));
					continue;
				}
				
				String OfaAssetLocation = (String) vec.elementAt(3);
				String ofaAssetNum=getOAAssetNum((String) vec.elementAt(2));
				String description = (String) vec.elementAt(4);
				//Modified by BCT to identify spreader asset
				String assetDesc=(String) vec.elementAt(5);
				//Modified by Comm-IT for GFS Integration changes//
				String glacc = (String) vec.elementAt(6);
				String glformat = glActTemplate;
				String assetStatus = (String) vec.elementAt(8);
				System.out.println("----------------assetStatus------------------"+assetStatus);
				
				mxLog.writeLog("----OfaAssetLocation: "+OfaAssetLocation);
				//mxLog.writeLog("----OFACronTaskCustomCron------assetStatus------------------"+assetStatus);
				System.out.println("OFACronTaskCustomCron Before Formating GL"+glacc);
				mxLog.writeLog("----OFACronTaskCustomCron------Before Formating GL----"+glacc);
								
				if (!glacc.equalsIgnoreCase("")) {
					String[] segments = glacc.split("-");
					String firstComp = segments[0];
					glformat = glformat.replaceFirst("xxx", firstComp);
					//BCT - Modifying for GL account restructuring
					//glformat = glformat.replaceFirst("xx-xxx", "01-000");
					String lob = segments[2];
					String costCentre= segments[3];
					String replaceThreeSegments ="-"+lob+"-"+costCentre+"-"+segments[4]+"-";

					glformat = glformat.replaceFirst("-xxx-xxxx-xxx-", replaceThreeSegments);
					//System.out.println(glformat); 
					String future= segments[5]+"-"+segments[6];
					glformat = glformat.replaceFirst("xxxx-xxxx", future);
					System.out.println("glformat-->"+glformat);
					
				}
				String glaccount = glformat;

				integrationLogger.debug("[OFA CRON] OFACronTaskCustomCron After Formating GL"+ glaccount);
				mxLog.writeLog("----OFACronTaskCustomCron------After Formating GL----"+ glaccount);
				
				System.out.println("OFACronTaskCustomCron After Formating GL "+ glaccount);
				
				System.out.println("glaccount:"+glaccount);
				String dateStr = (String) vec.elementAt(7);
				SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");
				Date date = dateformat.parse(dateStr);
				String installedDate=timeStampFormat.format(date);
				String changeDate=timeStampFormat.format(date);
				//String glAccount=formatGLAccount(glaccount,vec);
				//OfaAssetLocationLen=OfaAssetLocation.length();
				//if(OfaAssetLocation != null && OfaAssetLocation.length()>0)
				if(OfaAssetLocation != null && !OfaAssetLocation.trim().isEmpty())
				{
					System.out.println("OfaAssetLocation is not null");
					if(!assetStatus.equalsIgnoreCase("ACTIVE"))
					{
						mxLog.writeLog("------The asset status in the file is not listed as Active for "+ofaAssetNum+"------");
						mxLog.writeLog("********************************************************************************************************");
					}
					else
					{
						mxLog.writeLog("------The asset status in the file is listed as Active for "+ofaAssetNum+"------");
						boolean updatedAssetLoc=assetLocationUpdate(OfaAssetLocation,ofaAssetNum,description,assetDesc,installedDate,changeDate,glaccount,assetStatus);

						if(!updatedAssetLoc)
							{
								System.out.println("if(!updatedAssetLoc)");
								integrationLogger.debug("[OFA CRON] Not Updated in Location or Asset"+ OfaAssetLocation);
								integrationLogger.debug("[OFA CRON] Not Updated in Location or Asset"+ ofaAssetNum);


								ofa_backMbo=ofa_backMboSet.addAtEnd();
								ofa_backMbo.setValue("OAASSETNUM",ofaAssetNum);
								ofa_backMbo.setValue("LOCATION",OfaAssetLocation);
								ofa_backMbo.setValue("DESCRIPTION",description);
								ofa_backMbo.setValue("ORGID","PSAST");
								ofa_backMbo.setValue("GLACCOUNT",glaccount);
								ofa_backMbo.setValue("INSTALLDATE",installedDate);
								ofa_backMboSet.save();
							}
					}
				}
				else
				{
					mxLog.writeLog("********************************************************************************************************");
				}
			} catch (Exception e) {
				e.printStackTrace();
				ofa_backMboSet.save();
				System.out.println("Error Message OFA-->"+e);
				integrationLogger.debug("[OFA CRON] Error Message OFA-->"+ e);
				mxLog.writeLog("----OFACronTaskCustomCron------Error Message OFA----"+ e);

				if (errorMessage.equalsIgnoreCase("")) {
					errorMessage="Error while processing the following data:\n\n"+vec;

				}
				else if (!errorMessage.contains(vec.toString())) {
					errorMessage = errorMessage+"\n"+vec;

				}
				if(ofa_backMbo!=null){
					MboSetRemote ofabackup_Set = MXServer.getMXServer().getMboSet("OFABACKUP",getRunasUserInfo());
					ofabackup_Set.setWhere("OFABACKUPID='"+ofa_backMbo.getInt("OFABACKUPID")+"'");
					ofabackup_Set.reset(); 
					if(ofabackup_Set.count()>0)
					{
						String deleteErrorRecords="DELETE FROM OFABACKUP WHERE OFABACKUPID='"+ofa_backMbo.getInt("OFABACKUPID")+"'";
						System.out.println(deleteErrorRecords);
						SqlFormat delRecSql=new SqlFormat(deleteErrorRecords);					
						dbShortcut.executeQuery(delRecSql.format());
						dbShortcut.commit();
					}
				}
			}

		}
		if (errorMessage.length()>0) {
			MXServer.sendEMail(adminEmailId, adminEmailId, "OFACron Error", errorMessage);
		}

		integrationLogger.debug("[OFA CRON] End of procesing record");
		mxLog.writeLog("----OFACronTaskCustomCron------End of procesing record");
	}
	// getting OFA asset first 2 char  	  
	private String getOAAssetNum(String assetnum){

		StringTokenizer stringTokenizer = new StringTokenizer(assetnum, ".");

		if(stringTokenizer.countTokens()!=2){
			return assetnum;
		}

		stringTokenizer.nextToken(); 

		return stringTokenizer.nextToken(); 
	}
	// Formatting the GL code 
	private String formatGLAccount(String glaccount, Vector vec) throws RemoteException,MXException
	{

		MboSetRemote glconfigureset = MXServer.getMXServer().getMboSet("GLCONFIGURE", getRunasUserInfo());
		MaxVarServiceRemote maxvarserviceremote = (MaxVarServiceRemote)MXServer.getMXServer().lookup("MAXVARS");
		String glquestion = maxvarserviceremote.getString("GLQUESTION", "");
		String gldelimiter = glconfigureset.getMbo(0).getString("delimiter");
		String[] glaccountseg = glaccount.split(gldelimiter);
		String glactemplate = getParamAsString("GLACTEMPLATE");
		String[] glactemplateseg = glactemplate.split(gldelimiter);
		if (glactemplateseg.length != glconfigureset.count())
			throw new MXApplicationException("GLACTEMPLATE","GLACTEMPLATE parameter does not contain the correct number of segments");
		for (int i = 0; i < glactemplateseg.length; i ++)
		{
			if (glactemplateseg[i].indexOf(glquestion) >= 0)
				glaccountseg[i] = glactemplateseg[i];
		}
		glaccount = "";
		for (int i = 0; i < glaccountseg.length; i ++)
		{
			glaccount += glaccountseg[i];

			if (i < glaccountseg.length - 1)
				glaccount += gldelimiter;
		}

		vec.setElementAt(glaccount, 6);
		String glAccount = (String) vec.elementAt(6);

		return glAccount;
	}
	// Updating the Asset and Location OFA Asset number and GL Code	  
	private boolean assetLocationUpdate(String OfaAssetLocation,String ofaAssetNum,String description,String assetDesc,String installedDate,String changeDate, String glaccount, String assetStatus)throws MXException,RemoteException
	{

		boolean fixedAssetupdated=true;
		int isAsset=0;	
		//Creating asset for spreaders,AGV batteries
		
		MboSetRemote ofaAssetSet=MXServer.getMXServer().getMboSet("ALNDOMAIN", getRunasUserInfo());
 	   	SqlFormat ofaAssetSetSql=new SqlFormat("DOMAINID in(select DOMAINID from MAXIFACECONTROL where IFACECONTROL='OFAASSET')");
 	   	//"EXTSYSNAME='OFA' and IFACECONTROL='OFAASSET'");
 	   	ofaAssetSet.setWhere(ofaAssetSetSql.format());
 	   	ofaAssetSet.reset();
 	   	
 	   	for (int i = 0; i < ofaAssetSet.count(); i++) 
 	   	{
 		    MboRemote ofaAssetmbo = ofaAssetSet.getMbo(i);
 
 		    // Get the value from the "VALUE" column
 		    //String value = ofaAssetmbo.getString("VALUE");
 		    //mxLog.writeLog("Value: "+value);
 		    
 		    String desc = ofaAssetmbo.getString("DESCRIPTION");
		    mxLog.writeLog("----OFACronTaskCustomCron------Valid domain in system----"+desc);
		    
		    //String masterAsset=OfaAssetLocation.substring(0,5);
	   		//boolean masterAsset1=masterAsset.contains(value);
	   		//mxLog.writeLog("----masterAsset contains SP----"+masterAsset+"----"+masterAsset1);
		    
 		    boolean spAsset=assetDesc.contains(desc);
 		    mxLog.writeLog("----OFACronTaskCustomCron------AssetItemCategory from file----"+assetDesc); 
 		    
 		    //Creating/updating asset
 		    if(spAsset==true)
 		    {
 		    	AssetSetRemote masterAssetMboSet = (AssetSetRemote)MXServer.getMXServer().getMboSet("ASSET",getRunasUserInfo());
 		    	isAsset=1;
 		    	SqlFormat masterAssetSql=new SqlFormat("ASSETNUM=:1 and siteid='PSASG'");
 				masterAssetSql.setObject(1, "ASSET", "ASSETNUM", OfaAssetLocation);
 				masterAssetMboSet.setWhere(masterAssetSql.format());
 				masterAssetMboSet.reset();
 				//mxLog.writeLog("----OFACronTaskCustomCron------Count of masterAssetMboSet----"+masterAssetMboSet.count());
 				
 				//Updating Oracle asset number, GL in existing asset
 				if(masterAssetMboSet.count()>0)
 				{
 					fixedAssetupdated=true;
 					
 					mxLog.writeLog("------"+desc+" Asset already exists------");			
 					MboRemote masterAssetMbo=masterAssetMboSet.getMbo(0);
 					masterAssetMbo.setValue("OAASSETNUM", ofaAssetNum, 2L);
 					masterAssetMbo.setValue("GLACCOUNT", glaccount, 2L);
 					masterAssetMbo.setValue("INSTALLDATE",installedDate,2L);
 					masterAssetMbo.setValue("CHANGEDATE",changeDate,2L);
 					masterAssetMboSet.save();
 					
 					mxLog.writeLog("------Updating GL,oracle assetnumber in master Asset------");
 					mxLog.writeLog("----OFACronTaskCustomCron------Existing Master Asset----"+OfaAssetLocation);
 					mxLog.writeLog("----OFACronTaskCustomCron------Master Asset OAASSETNUM----"+ofaAssetNum);
 					mxLog.writeLog("----OFACronTaskCustomCron------Master Asset GL account----"+glaccount);
 					mxLog.writeLog("----OFACronTaskCustomCron------Master Asset install date----"+installedDate);
 					mxLog.writeLog("----OFACronTaskCustomCron------Master Asset changedate----"+changeDate);
 					
 					assetMeterGroup(OfaAssetLocation,desc);
 					
 					mxLog.writeLog("------Asset updation completed------");
 							
 				}
 				//Creating asset and update Oracle asset number, GL to the asset
 				else if(masterAssetMboSet.count()==0)
 				{
 					fixedAssetupdated=true;
 					
 					try 
 					{
 						mxLog.writeLog("------"+desc+" Asset doesn't exists and creating new asset------");
 						integrationLogger.debug("[OFA CRON] -Asset doesn't exists and creating new asset");
 						
 						MboRemote masteAssetMbo=masterAssetMboSet.addAtEnd();		
 						masteAssetMbo.setValue("ASSETNUM",OfaAssetLocation,2L);
 						masteAssetMbo.setValue("OAASSETNUM",ofaAssetNum);
 						masteAssetMbo.setValue("DESCRIPTION",description);
 						masteAssetMbo.setValue("ORGID","PSAST");
 						masteAssetMbo.setValue("GLACCOUNT",glaccount);
 						masteAssetMbo.setValue("CHANGEDATE",changeDate,2L);
 						masteAssetMbo.setValue("INSTALLDATE",installedDate);
 						masteAssetMbo.setValue("STATUS","OPERATING",11L);
 						
 						mxLog.writeLog("------New Master Asset creation------");
 						mxLog.writeLog("----OFACronTaskCustomCron------ASSETNUM----"+OfaAssetLocation);
 						mxLog.writeLog("----OFACronTaskCustomCron------OAASSETNUM----"+ofaAssetNum);
 						mxLog.writeLog("----OFACronTaskCustomCron------INSTALLDATE----"+installedDate);
 						mxLog.writeLog("----OFACronTaskCustomCron------CHANGEDATE----"+changeDate);
 						mxLog.writeLog("----OFACronTaskCustomCron------GLACCOUNT----"+glaccount);

 						masterAssetMboSet.save();
 						
 						assetMeterGroup(OfaAssetLocation,desc);
 						
 						integrationLogger.debug("[OFA CRON] -assetLocationUpdate assetnum doesnt exist - Successfully saved New ASSET");
 								mxLog.writeLog("------Asset creation completed------");
 					}
 					catch (Exception e) 
 					{
 						// TODO: handle exception
 						e.printStackTrace();
 						System.out.println("Exception in addding new asset-->"+e);
 						integrationLogger.debug("[OFA CRON] Exception in addding new asset-->"+e);
 						mxLog.writeLog("----OFACronTaskCustomCron------Exception in addding new asset----"+e);

 					}
 							
 				}
 		     	mxLog.writeLog("********************************************************************************************************");	     		
 		    	break;
 		    }
 		    /*else if(masterAsset1==false || spAsset==false)
		    {
		    	mxLog.writeLog("Not a valid combination to create/update as an Asset");
		    	count++;
		    	mxLog.writeLog("Count of invalid combinations: "+count);
		    }*/
 		    
 	   	}
 	   	//Update GL account and oracle asset number to the existing location
		if(isAsset==0)
		{
			mxLog.writeLog("----Not a valid combination to create/update as an Asset. Hence this record consider as location----");
			
			boolean locCount=true;
			//Update oracle asset number, GL account to the location with respect to location received in the file
			LocationSetRemote locationMboSet = (LocationSetRemote)MXServer.getMXServer().getMboSet("LOCATIONS",getRunasUserInfo());
			SqlFormat locationSql=new SqlFormat("LOCATION=:1 and siteid='PSASG'");
			locationSql.setObject(1, "LOCATIONS", "LOCATION", OfaAssetLocation);
			locationMboSet.setWhere(locationSql.format());
			if(!locationMboSet.isEmpty()&& locationMboSet!=null)
			{
				System.out.println("Inside LocationUpdate");
				fixedAssetupdated=true;
				locCount=true;
				MboRemote locationMbo=locationMboSet.getMbo(0);
				locationMbo.setValue("OAASSETNUM",ofaAssetNum,2L);
				//locationMbo.setValue("DESCRIPTION",description,2L);
				locationMbo.setValue("GLACCOUNT",glaccount,2L);
				locationMboSet.save();
				//return fixedAssetupdated;	
				mxLog.writeLog("------Updating GL,oracle assetnumber in location------");
				mxLog.writeLog("----OFACronTaskCustomCron------Location OAASSETNUM----"+ofaAssetNum);
				mxLog.writeLog("----OFACronTaskCustomCron------Location INSTALLDATE----"+glaccount);
				mxLog.writeLog("------location updation completed------");
			}
			
			else
			{
				locCount=false;
				mxLog.writeLog("------Location "+OfaAssetLocation+" not exists------");
			}
			
			//Oracle asset validation
			if(locCount)
			{
				
			
			AssetSetRemote assetMboSet = (AssetSetRemote)MXServer.getMXServer().getMboSet("ASSET",getRunasUserInfo());
			SqlFormat assetSql=new SqlFormat("ASSETNUM=:1 and siteid='PSASG'");
			assetSql.setObject(1, "ASSET", "ASSETNUM", ofaAssetNum);
			assetMboSet.setWhere(assetSql.format());
			assetMboSet.reset();
			
			System.out.println("assetLocationUpdate OfaAssetLocation "+OfaAssetLocation);
			System.out.println("assetLocationUpdate OfaAssetLocation "+ofaAssetNum);
			System.out.println("assetLocationUpdate AssetCount");
			System.out.println(assetMboSet.count());
			//System.out.println("assetLocationUpdate assetNum"+assetMboSet.getMbo(0).getString("OAASSETNUM"));
			
			//update oracle asset number, GL to the existing oracle asset number
			if(assetMboSet.count()>0)
			{

				System.out.println(" OFACronTaskCustomCron-assetLocationUpdate oa assetnum exists");
				integrationLogger.debug("[OFA CRON] -assetLocationUpdate OA assetnum already exists");
				mxLog.writeLog("------OA assetnum already exists------");
				
				fixedAssetupdated=true;
				MboRemote assetMbo=assetMboSet.getMbo(0);
				assetMbo.setValue("OAASSETNUM",ofaAssetNum,2L);
				//assetMbo.setValue("DESCRIPTION",description,2L);
				assetMbo.setValue("INSTALLDATE",installedDate,2L);
				assetMbo.setValue("CHANGEDATE",changeDate,2L);
				assetMbo.setValue("GLACCOUNT",glaccount,2L);

				mxLog.writeLog("------Updateing GL account, Oracle assetnum to OAAsset------");
				mxLog.writeLog("----OFACronTaskCustomCron------OAASSETNUM----"+ofaAssetNum);
				mxLog.writeLog("----OFACronTaskCustomCron------INSTALLDATE----"+installedDate);
				mxLog.writeLog("----OFACronTaskCustomCron------CHANGEDATE----"+changeDate);
				mxLog.writeLog("----OFACronTaskCustomCron------GLACCOUNT----"+glaccount);
				
				
				String currentStatus = assetMbo.getString("STATUS");
				System.out.println("---------2--------OfaAssetLocation--------------------"+OfaAssetLocation);
				if (assetStatus!="")
				{
					System.out.println("-----------------status not null--------------------");
					System.out.println("-----------------assetStatus--------------------"+assetStatus);
					System.out.println("-----------------currentStatus--------------------"+currentStatus);
					if (assetStatus.equalsIgnoreCase("Retired") && !currentStatus.equalsIgnoreCase("Retired") && !currentStatus.equalsIgnoreCase("DECOMMISSIONED"))
					{
						System.out.println("-----------------Changing status to READYDECOM--------------------");
						assetMbo.setValue("STATUS","READYDECOM",11L);
					}
					if (assetStatus.equalsIgnoreCase("Active") && !currentStatus.equalsIgnoreCase("ACTIVE") && !currentStatus.equalsIgnoreCase("OPERATING"))
					{
						System.out.println("-----------------Changing status to OPERATING--------------------");
						assetMbo.setValue("STATUS","OPERATING",11L);
					}
					else
						System.out.println("-----------------status is not updated--------------------");
				}
				else
					System.out.println("-----------------status is null--------------------");
				
				assetMboSet.save();
				//return fixedAssetupdated;
				
				//Check meter group
				locMeterGroup(ofaAssetNum);
				
				System.out.println("[OFA CRON] -assetLocationUpdate OA assetnum already exists after save");
				mxLog.writeLog("------OAAsset updation completed------");
			}
			
			//Creating new asset with respect to oracle asset number from the file
			else
			{
				fixedAssetupdated=true;
				try {
					System.out.println(" OFACronTaskCustomCron-assetLocationUpdate oa assetnum doesnt exists");
					integrationLogger.debug("[OFA CRON] -assetLocationUpdate OA assetnum doesnt exists");
					mxLog.writeLog("------OA assetnum doesnt exists and creating New OAASSET------");
										
					MboRemote assetMbo=assetMboSet.addAtEnd();		
					assetMbo.setValue("ASSETNUM",ofaAssetNum,2L);
					assetMbo.setValue("OAASSETNUM",ofaAssetNum);
					assetMbo.setValue("LOCATION",OfaAssetLocation);
					assetMbo.setValue("DESCRIPTION",description);
					assetMbo.setValue("ORGID","PSAST");
					//assetMbo.setValue("SITEID","PSASG");
					assetMbo.setValue("GLACCOUNT",glaccount);
					assetMbo.setValue("CHANGEDATE",changeDate,2L);
					assetMbo.setValue("INSTALLDATE",installedDate);
					assetMbo.setValue("STATUS","OPERATING",11L);
					//assetMbo.changeStatus("OPERATING", MXServer.getMXServer().getDate(), "", MboConstants.NOACCESSCHECK);
					
					mxLog.writeLog("------OAAsset creation------");
					mxLog.writeLog("----OFACronTaskCustomCron------OAASSETNUM----"+ofaAssetNum);
					mxLog.writeLog("----OFACronTaskCustomCron------INSTALLDATE----"+installedDate);
					mxLog.writeLog("----OFACronTaskCustomCron------CHANGEDATE----"+changeDate);
					mxLog.writeLog("----OFACronTaskCustomCron------GLACCOUNT----"+glaccount);

					assetMboSet.save();
					//mxLog.writeLog("Successfully saved New OAASSET");
					
					//Check meter group
					locMeterGroup(ofaAssetNum);
					
					integrationLogger.debug("[OFA CRON] -assetLocationUpdate OA assetnum doesnt exists - Successfully saved New OAASSET");
					mxLog.writeLog("------OAAsset creation completed------");
				}
				catch (Exception e) 
				{
					// TODO: handle exception
					e.printStackTrace();
					System.out.println("Exception in addding new asset-->"+e);
					integrationLogger.debug("[OFA CRON] Exception in addding new asset-->"+e);
					mxLog.writeLog("----OFACronTaskCustomCron------Exception in addding new asset----"+e);
				}

			}
			}
			mxLog.writeLog("********************************************************************************************************");
		}
			
		return fixedAssetupdated;
	}
	
	//Update meter group to asset (Spreader and AGV) 
	//Modified by BCT
	
	private void assetMeterGroup(String OfaAssetLocation, String desc) throws RemoteException, MXException 
	{
		System.out.println("----To check meter group for respective oracle asset----");
		
		AssetSetRemote meterGrpMboSet = (AssetSetRemote)MXServer.getMXServer().getMboSet("ASSET",getRunasUserInfo());
		SqlFormat meterGrpSql=new SqlFormat("ASSETNUM=:1 and siteid='PSASG'");
		meterGrpSql.setObject(1, "ASSET", "ASSETNUM", OfaAssetLocation);
		meterGrpMboSet.setWhere(meterGrpSql.format());
		meterGrpMboSet.reset();
		//mxLog.writeLog("----OFACronTaskCustomCron------Oracle Asset count----"+meterGrpMboSet.count());
		if(meterGrpMboSet.count()>0)
		{
			MboRemote meterGrpMbo=meterGrpMboSet.getMbo(0);
			String mtrGroup = meterGrpMbo.getString("GROUPNAME");
			
			MboSetRemote ofaMeterSet=MXServer.getMXServer().getMboSet("ALNDOMAIN", getRunasUserInfo());
	 	   	SqlFormat ofaMeterSetSql=new SqlFormat("DOMAINID in(select DOMAINID from MAXIFACECONTROL where IFACECONTROL='OFAMETER')");
	 	   	ofaMeterSet.setWhere(ofaMeterSetSql.format());
	 	   	ofaMeterSet.reset();
	 	   	mxLog.writeLog("----OFACronTaskCustomCron------To match meter group from inetgration control-----");
	 	   	for (int m=0; m < ofaMeterSet.count(); m++)
	 	   	{
	 	   		MboRemote ofaMeterMbo=ofaMeterSet.getMbo(m);
	 	   		String meterValue=ofaMeterMbo.getString("VALUE");
	 	   		String meterDesc=ofaMeterMbo.getString("DESCRIPTION");
	 	   		mxLog.writeLog("----OFACronTaskCustomCron------Meter group from integration control----Value: "+meterValue+" | Description: "+meterDesc);
	 	   		//To match meter group domain with main asset domain
	 	   		boolean mtrDesc=meterValue.contains(desc);
	 	   		
	 	   		if ((mtrGroup=="" || mtrGroup.isEmpty()) && mtrDesc==true)
	 	   		{
	 	   			mxLog.writeLog("----OFACronTaskCustomCron------Asset Meter Group----"+ofaMeterMbo.getString("DESCRIPTION"));
	 	   			meterGrpMbo.setValue("GROUPNAME", meterDesc,3L);
	 	   			meterGrpMboSet.save();
	 	   			break;
	 	   		}
	 	   		else if (!mtrGroup.isEmpty() && mtrDesc==true)
	 	   		{
	 	   			if (mtrGroup.equalsIgnoreCase(meterDesc))
	 	   			{
	 	   				mxLog.writeLog("----OFACronTaskCustomCron------Asset Meter Group already exists with correct meter group----"+mtrGroup);
	 	   				break;
	 	   			}
	 	   			else if (!mtrGroup.equalsIgnoreCase(meterDesc))
	 	   			{
	 	   				mxLog.writeLog("----OFACronTaskCustomCron------Asset Meter Group already exists with incorrect meter group----"+mtrGroup);
	 	   				meterGrpMbo.setValue("GROUPNAME", meterDesc,3L);
	 	   				meterGrpMboSet.save();
	 	   				mxLog.writeLog("----OFACronTaskCustomCron------Asset Meter Group updated with correct meter group----"+meterGrpMbo.getString("GROUPNAME"));
	 	   				break;
	 	   			}
	 	   		}
	 	   		else if (!mtrGroup.isEmpty() && mtrDesc==false)
	 	   		{
	 	   			mxLog.writeLog("----OFACronTaskCustomCron------Existing asset meter group not matched with meter group integration control description----"+mtrGroup);
	 	   			continue; //To skip current iteration and move to next iteration
	 	   		}
	 	   	}
	 	   	
		}
		
	}	
	
	//Update meter group to asset with respect to locations tagged to the asset
	//Modified by BCT
	private void locMeterGroup(String ofaAssetNum) throws RemoteException, MXException 
	{
		System.out.println("----To check meter group for respective oracle asset----");
		
		AssetSetRemote locMeterGrpMboSet = (AssetSetRemote)MXServer.getMXServer().getMboSet("ASSET",getRunasUserInfo());
		SqlFormat locMeterGrpSql=new SqlFormat("ASSETNUM=:1 and siteid='PSASG'");
		locMeterGrpSql.setObject(1, "ASSET", "ASSETNUM", ofaAssetNum);
		locMeterGrpMboSet.setWhere(locMeterGrpSql.format());
		locMeterGrpMboSet.reset();
		mxLog.writeLog("----OFACronTaskCustomCron------Oracle Asset count----"+locMeterGrpMboSet.count());
		if(locMeterGrpMboSet.count()>0)
		{
			MboRemote locMeterGrpMbo=locMeterGrpMboSet.getMbo(0);
			String meterGroup = locMeterGrpMbo.getString("GROUPNAME");
			String assetLoc = locMeterGrpMbo.getString("LOCATION");
			String locMeterGrp=locMeterGrpMbo.getString("LOCATION.GROUPNAME");
			mxLog.writeLog("----OFACronTaskCustomCron------Oracle Asset Meter Group----"+meterGroup);
			mxLog.writeLog("----OFACronTaskCustomCron------Oracle Asset's Location----"+assetLoc);
			mxLog.writeLog("----OFACronTaskCustomCron------Oracle Asset's Location's Meter group----"+locMeterGrp);
			
			if (meterGroup=="")
			{
				mxLog.writeLog("----OFACronTaskCustomCron------Oracle Asset Meter Group not exists----");
				locMeterGrpMbo.setValue("GROUPNAME", locMeterGrp,3L);
				locMeterGrpMboSet.save();
				mxLog.writeLog("----OFACronTaskCustomCron------Asset Meter Group updated with correct meter group-----"+locMeterGrp);
			}
			else
			{
				mxLog.writeLog("----OFACronTaskCustomCron------Oracle Asset Meter Group already exists----");
				
			}
		}
		
	}


	public void init() {
		email = new MxEmail(adminEmailId);


	}

}


