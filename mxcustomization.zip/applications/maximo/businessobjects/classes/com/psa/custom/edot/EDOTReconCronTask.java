/*
 * Modification history
 *
 * 28-10-2011   YCH Creation This class is cron task to process received ED-OT records after parsing flat file from Resource System
 * 20-02-2013	WMJ	EMS-553	[EDOT][Crontask]Fix issue in EDOTReconCronTask where PSA_PROCESSDATE is updated wrongly
 *
 */

package com.psa.custom.edot;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Vector;

import com.psa.app.labor.LabTransCustomRemote;
import psdi.app.labor.LabTransSetRemote;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;

import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxImportFile;
import com.psa.custom.ois.MxLog;
import psdi.iface.mic.MicUtil;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class EDOTReconCronTask extends SimpleCronTask
{
	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
	private static final String NEWLINE = "\n\r";

	private static CrontaskParamInfo params[];
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");

	protected String otArchiveFilePath; //Filename and Full Path for OT Transaction Archive File

	private String qualifiedInstanceName;

	private String directory;            //Directory to retrieve the file from
	private String importFileName;       //Import Base File Name
	private String logDir;               //Directory where log file will be placed
	private boolean enableLog;           //Enable log

	private File loadDir;
	protected MxLog mxLog;
	private MxImportFile mxFile;

	private boolean isProcErr;
	private StringBuffer errMessage;

	protected boolean initialized;

	/*
	 * Author: YCH
	 * 28 Oct 2011 - Cron task constructor initialize default value
	 */
	public EDOTReconCronTask()
	{
		super();

		initialized = false;

		qualifiedInstanceName = null;
		loadDir = null;
		directory = null;
		importFileName = null;
		logDir = null;
		enableLog = false;

		errMessage = null;
		isProcErr = false;
		mxLog = new MxLog();
		mxFile = new MxImportFile();
	}

	/*
	 * Author: YCH
	 * Date: 28 Oct 2011
	 * Comment: [Standard Cron Task Function]Initialize cron task
	 */
	public void init()
			throws MXException
	{
		super.init();                
		initialized = true;                
	}

	/*
	 * Author: YCH
	 * 28 Oct 2011 - Get the parameter value setting from maximo in configuration
	 */
	private void refreshSettings()
	{
		integrationLogger.debug("Entering refreshSettings");

		try {
			directory = getParamAsString("DIRECTORY");
			loadDir = new File(directory);

			//Replace filename by today's date if "yyyymmdd" is specified in import file base name
			DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
			String todayDate = fileDateFormat.format(new Date());
			importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmdd", todayDate);

			Date curDate = new Date();
			Date fileDate = new Date(curDate.getTime());
			String fileDateStr = fileDateFormat.format(fileDate);

			otArchiveFilePath = getParamAsString("OTARCHIVEFILEPATH").replaceAll("yyyymmdd", fileDateStr);

			//Log
			logDir = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd", todayDate);
			enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
			mxLog.setEnabled(enableLog);
			mxLog.setLogFilePath(logDir);
			mxLog.setLogTag(getName());
			mxLog.createLogFile();

			integrationLogger.debug("Leaving refreshSettings");
		}
		catch (Exception exception)
		{
			if (integrationLogger.isErrorEnabled())
				integrationLogger.error(exception.getMessage(), exception);
		}
	}

	/*
	 * Author: YCH
	 * Date: 28 Oct 2011
	 * Comment: [Standard Cron Task Function] Start cron task
	 */
	public void start()
	{
		try {
			refreshSettings();

			MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Start - " + qualifiedInstanceName + " started");
			setSleepTime(0L);
		}
		catch (Exception exception) {
			if (integrationLogger.isErrorEnabled())
				integrationLogger.error(exception.getMessage(), exception);
		}
	}

	/*
	 * Author: YCH
	 * Date: 28 Oct 2011
	 * Comment: [Standard Cron Task Function]Stop cron task
	 */
	public void stop()
	{
		try {
			mxLog.closeLogFile();
		} catch (Exception exception) {
			if (integrationLogger.isErrorEnabled())
				integrationLogger.error(exception.getMessage(), exception);
		}
		mxLog.writeLog("[" + getName() + "] Stop - " + qualifiedInstanceName + " stopped");
		MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Stop - " +
				qualifiedInstanceName + " stopped");
	}

	/* Author: YCH
	 * Date: 28 Oct 2011
	 * Comment: [Standard Cron Task Function] Set cron task instance
	 */

	public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {

		try {
			super.setCrontaskInstance(crontaskinstanceremote);
			qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") +
					"." + crontaskinstanceremote.getString("instancename");
		}
		catch(Exception exception) {
			integrationLogger.error(exception.getMessage(), exception);
		}
	}

	/*
	 * Author: YCH
	 * Date: 31 Oct 2011
	 * Comment: returns true if all required parameter is set
	 */
	private boolean isReqParamSet()
	{
		if (importFileName == null)
			return false;
		if (directory == null)
			return false;
		return true;
	}

	/* Author: YCH
	 * Date: 31 Oct 2011
	 * Comment: Generate Formated Error Msg
	 */
	private String genErrMsg(Exception e, Vector vec){

		String errMsg = "Line:"+vec.toString() + "\n";
		errMsg += "Error Message: "+ e.getMessage() + "\n";
		errMsg += "Detail:" + "\n";
		errMsg += e.toString() + "\n";
		StackTraceElement element[] = e.getStackTrace();
		for(int i = 0; i< element.length; i++){
			errMsg += "\tat "+ element[i].toString() + "\n";
		}

		return errMsg;
	}

	/*
	 * Author: YCH
	 * 31 Oct 2011 - Get the parameter from Cron Task.
	 */
	public CrontaskParamInfo[] getParameters() throws MXException, RemoteException
	{
		return params;
	}

	/*
	 * Author: YCH
	 * Date: 31 Oct 2011
	 * Comment: [Standard Cron Task Function]
	 * Cron task function - Retrieve flat file from remote server,
	 * process flat file, update the corresponding mbo object according to the content
	 */
	public void cronAction()
	{
		integrationLogger.debug("Entering cronAction");
		mxLog.writeLog(" cronAction(): Start CronTask Action");

		try {

			if (!initialized) {
				mxLog.writeLog(" cronAction(): CronTask not initialized!");
				throw new Exception(getName() + ".cronAction(): CronTask not initialized!");
			}

			// Refresh setting before perform cron action
			refreshSettings();

			// Set parameter after refreshSetting
			mxFile.setFileType(importFileName);
			errMessage = new StringBuffer();

			if (isReqParamSet()) {

				// Check file is in local drive?
				if (checkFileExist()) {
					// Process the import flat file
					processData();

					//Copy Files to Archive Directory
					//depositFile();
				} else {
					mxLog.writeLog("[" + getName() + "]Unable to find input file.");
					throw new Exception("[" + getName() + "]Unable to find input file.");
				}

			} else {
				mxLog.writeLog(" cronAction(): Required parameters not set.");
				throw new Exception("Required parameters are not set.");
			}

		} catch (Exception e) {
			MicUtil.INTEGRATIONLOGGER.error("[" + getName() + "] " + e.getMessage(), e);

			stop();
		}

		integrationLogger.debug("Leaving cronAction");
		mxLog.writeLog(" cronAction(): End CronTask Action");

	}

	/* Author: YCH
	 * Date: 31 Oct 2011
	 * Comment: Check file exist in local directory
	 */
	public boolean checkFileExist () {

		integrationLogger.debug("EDOTReconCronTask: checkFileExist");

		File afile[] = loadDir.listFiles();

		if(afile != null) {
			int i = afile.length;
			for(int j = 0; j < i; j++) {
				//Below if condition is added as part of Boomi conversion to handle the EDOTError file names, earlier it was handled in Unix cron.
				if(afile[j].getName().startsWith(importFileName) && !afile[j].isDirectory()) 
				{
					//if(mxFile.findFileType(afile[j])) {
					integrationLogger.debug(">>>> EDOTReconCronTask: checkFileExist() :: " + afile[j].getName());
					return true;
				}
			}
		}

		return false;
	}

	/* Author: YCH
	 * Date: 31 Oct 2011
	 * Comment: Process the import flat file
	 */
	public void processData() throws Exception {

		integrationLogger.debug("EDOTReconCronTask: Entering processFileData");
		mxLog.writeLog(" processData(): Start Processing Data");
		try {
			File afile[] = loadDir.listFiles();

			if(afile != null) {
				int i = afile.length;

				for(int j = 0; j < i; j++) {

					errMessage = new StringBuffer();
					isProcErr = false;
					//Below if condition is added as part of Boomi conversion to handle the EDOTError file names, earlier it was handled in Unix cron.
					if(afile[j].getName().startsWith(importFileName) && !afile[j].isDirectory()) 
					{
					//if(mxFile.findFileType(afile[j])) {
						//debug.msg("Start reading flat file.");
						integrationLogger.debug("EDOTReconCronTask: Processing file '" + afile[j].getName() + "'");

						try {
							// Parse EDOT flat file
							String file = afile[j].toString();
							Collection col = parseFlatFile(file);

							// Process parsed flat file to update Labor Transactions.
							updateDB(col);
							//depositFile(file);
							integrationLogger.debug("EDOTReconCronTask: before archivefile " + afile[j].getName());
							depositFile(afile[j].getName());
							integrationLogger.debug("EDOTReconCronTask: after archivefile " + afile[j].getName());
						} catch(Exception e){
							MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
						}
					}

					if (isProcErr) {

						String errMsg = "Date: " + new Date() + "\n";
						errMsg += "Error in CronTask: "+getName() + "\n";
						errMsg += "File Processing: "+ afile[j].getName() + NEWLINE;
						errMsg += errMessage.toString();

						mxLog.writeLog("Error Message:\n" + errMsg);
					}
				}
			}
			else{
				mxLog.writeLog(" processData(): Unable to read input file '" + importFileName + "'");
				throw new Exception("[" + getName() + "] Unable to read input file '" + importFileName + "'");
			}
		}
		catch(Exception e)
		{
			MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);

			stop();
		}

		integrationLogger.debug("EDOTReconCronTask: Leaving processFileData");
		mxLog.writeLog(" processData(): Leaving Processing Data");
	}

	/*
	 * Author: YCH
	 * Date: 31 Oct 2011
	 * Comment: Parse EDOT flat file.
	 */
	private Collection parseFlatFile(String file) throws Exception {

		integrationLogger.debug("Entering parseFlatFile");
		mxLog.writeLog(" parseFlatFile(): Start Parse Flat File");

		// Parse the EDOT flat file first
		// Reading the import flat file
		BufferedReader flatfileReader;
		Collection col = new Vector();

		flatfileReader = new BufferedReader(new FileReader(file));

		// Ignore first line of text as its the file header
		//String curLine = flatfileReader.readLine();
		String curLine;
		int length = 129;
		int[] fieldFrom = {0, 12, 24, 29};
		int[] fieldTo = {12, 24, 29, 129};

		while((curLine = flatfileReader.readLine()) != null)
		{

			if (curLine.length() != length) {
				mxLog.writeLog("[" + getName() + "][Warning] The string message length is ["
						+ curLine.length() + "], it's different with the definition length ["
						+ length + "]");
			}

			//mxLog.writeLog("[" + getName() + "] curLine:'" + curLine+ "'");

			Vector vec = new Vector();
			for (int i = 0; i < 4; i++)
			{
				if (fieldFrom[i] > curLine.length())
				{
					isProcErr = true;
					String errMsg = NEWLINE + "Line:" + curLine + NEWLINE;
					errMsg += "Error Message: The field's start|end index is larger than message's total length: FieldFrom:["
							+ fieldFrom[i]  + "] FieldTo:[" + fieldTo[i] + "]" + NEWLINE;
					errMessage.append(errMsg);
					mxLog.writeLog("[" + getName() + "][ERROR] Invalid line:'" + curLine+ "'");
					break;
				}

				if (fieldTo[i] > curLine.length())
				{
					fieldTo[i] = curLine.length();
				}

				String fieldValue = curLine.substring(fieldFrom[i], fieldTo[i]);
				//mxLog.writeLog("[" + getName() + "] fieldValue:'" + fieldValue+ "'");
				vec.add(fieldValue.trim());
			}

			// Add to a collection
			col.add(vec);
		}

		integrationLogger.debug("parseFlatFile - Valid lines parsed: "+col.size());
		integrationLogger.debug("Leaving parseFlatFile");
		mxLog.writeLog(" parseFlatFile(): Valid lines parsed: "+col.size());
		mxLog.writeLog(" parseFlatFile(): Finish Parse Flat File");
		return col;
	}

	/*
	 * Author: YCH
	 * Date: 31 Oct 2011
	 * Comment: Process parsed flat file to update Lab Transactions for OT records
	 */
	private void updateDB(Collection col) throws Exception
	{
		integrationLogger.debug("EDOTReconCronTask: Starting processFlatFile");

		Iterator iterParsedData = col.iterator();

		while (iterParsedData.hasNext()) {

			//Vector Element
			//0. Maximo OT ID
			//1. Process Date
			//2. Status (Done/Error)
			//3. Message

			// Get new record to update into Lab Transactions
			Vector vec = (Vector) iterParsedData.next();
			try {
				integrationLogger.debug("Line: " + vec.toString());

				String maximoOTID = (String) vec.elementAt(0);
				//mxLog.writeLog("[" + getName() + "] maximoOTID:'" + maximoOTID+ "'");
				integrationLogger.debug("Process Maximo OT ID: " + maximoOTID);

				Date processDate = convertDate((String) vec.elementAt(1));
				//mxLog.writeLog("[" + getName() + "] processDate:'" + processDate+ "'");
				integrationLogger.debug("Process Date: " + processDate);

				String status = (String) vec.elementAt(2);
				//mxLog.writeLog("[" + getName() + "] status:'" + status+ "'");
				integrationLogger.debug("Process Status: " + status);

				String message = (String) vec.elementAt(3);
				//mxLog.writeLog("[" + getName() + "] message:'" + message+ "'");
				integrationLogger.debug("Process Message: " + message);

				//Check for existing OT record by specific maximo OT ID
				LabTransSetRemote labTransSet = (LabTransSetRemote) MXServer.getMXServer().getMboSet("LABTRANS", getRunasUserInfo());
				String sql = "LABTRANSID = :1";

				SqlFormat sqlformat = new SqlFormat(getRunasUserInfo(), sql);
				sqlformat.setObject(1, "LABTRANS", "LABTRANSID", maximoOTID);

				labTransSet.setWhere(sqlformat.format());

				if (labTransSet.isEmpty())
				{
					integrationLogger.debug("Can not find the existed record based on parsed OT ID: " + maximoOTID);
				} else {
					integrationLogger.debug("Updated Lab Transaction Start with Lab Transaction ID: " + maximoOTID);
					LabTransCustomRemote labTransMbo = (LabTransCustomRemote) labTransSet.getMbo(0);
					labTransMbo.setValue("PSA_PROCESSDATE", processDate, 2L);
					labTransMbo.setValue("PSA_IFACESTATUS", status, 2L);
					labTransMbo.setValue("PSA_IFACEMESSAGE", message, 2L);
					labTransSet.save();
					integrationLogger.debug("Updated Lab Transaction Finish");
				}
			}
			catch(Exception e) {
				isProcErr = true;
				String errMsg = genErrMsg(e, vec);
				errMessage.append(errMsg);
				errMessage.append(NEWLINE);
				mxLog.writeLog(" processFlatFile():[ERROR]" + errMsg);
			}
		}

		// Clear collection
		col.clear();
		integrationLogger.debug("Leaving processFlatFile");
		mxLog.writeLog(" processFlatFile(): Finish Update Lab Transaction.");
	}

	/* Author: YCH
	 * 31 Oct 2011 - Convert Date
	 */
	private Date convertDate(String inDate) throws Exception
	{
		//Start of EMS-553
		//SimpleDateFormat dateformat = new SimpleDateFormat("ddmmyyyy");
		SimpleDateFormat dateformat = new SimpleDateFormat("ddMMyyyy");
		//End of EMS-553
		Date outDate = null;
		outDate = dateformat.parse(inDate);

		return outDate;
	}

	/**
	 * @author YCH
	 * @function depositFile
	 * @date Oct 27, 2011
	 * @comment Copy and Zip Flat Files to Output and Archive Directory modification,
	 * Do not throw exception when the transaction has been processed
	 * @throws Exception
	 */
	/*
	 * 2023-01-11: KP - Changed the method arguments from depositFile() to depositFile(String file) during boomi conversion
	 * 
	 * */
		private void depositFile(String file) throws Exception
	{
		mxLog.writeLog(" depositFile(file) :: Entering to deposit files to archive location " + file);
		try
		{
			mxLog.writeLog(getName()+ ".depositFile():[Info]Start depositing output file");
			/*
			 * 2023-01-11: KP - Commented the below during boomi conversion
			 * 	
			 * File oldfile = new File(directory + importFileName) ;
			 * oldfile.renameTo(new File(otArchiveFilePath + importFileName));
			 */
			//File oldfile = new File(directory + file) ;
			//oldfile.renameTo(new File(otArchiveFilePath + file));
			mxLog.writeLog(getName()+ ".depositFile():[Info]Copied files to archive ::"+ otArchiveFilePath + file +" and starting to remove from process directory :: " + directory+file);
            MxFileCopy.fileCopy(directory + file,otArchiveFilePath + file);
            mxLog.writeLog(getName()+ ".depositFile():[Info]Copied files to archive ::"+ otArchiveFilePath + file +" and starting to remove from process directory :: " + directory+file);
			File deleteProcessedFile = new File(directory + file);
			deleteProcessedFile.delete();
			//MxFileCopy.fileCopy(directory + importFileName, otArchiveFilePath + importFileName);

			mxLog.writeLog(getName() + ".depositFile():[Info]Deleted from process and Finished depositing output file");
		}catch(Exception e)
		{
			mxLog.writeLog(" depositFile(file) :: Exception occured while deposit files to archive location ");
			e.printStackTrace();
		}
	}

	/* Author: YCH
	 * Date: 31 Oct 2011
	 * Comment: Define Maximo parameter setting in Cron Task
	 */
	static
	{
		// YCH: Set the number of the parameter.
		params = null;
		params = new CrontaskParamInfo[5];

		// YCH: All the parameter configurable from Cron Task

		params[0] = new CrontaskParamInfo();
		params[0].setName("DIRECTORY");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[0].setDescription("CommonCron","LocalDirectory");
		//-- COMM-IT changed to make it compatible with Maximo 7 API
		//params[0].setDescription("Local directory where flat file will be read.");


		params[1] = new CrontaskParamInfo();
		params[1].setName("IMPORTFILENAME");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[1].setDescription("CommonCron","FileNameOfTheInputFile");
		//-- COMM-IT changed to make it compatible with Maximo 7 API
		//params[1].setDescription("File name of the input file(Includes with 'yyyymmdd*' for current day file)");

		params[2] = new CrontaskParamInfo();
		params[2].setName("ENABLELOG");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[2].setDescription("CommonCron","EnableLog");
		//-- COMM-IT changed to make it compatible with Maximo 7 API
		//params[2].setDescription("Enable log output('Y' or 'N').");
		params[2].setDefault("Y");

		params[3] = new CrontaskParamInfo();
		params[3].setName("LOGFILEPATH");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[3].setDescription("CommonCron","LogDirectory");
		//-- COMM-IT changed to make it compatible with Maximo 7 API
		//params[3].setDescription("Log Directory and Filename.");

		params[4] = new CrontaskParamInfo();
		params[4].setName("OTARCHIVEFILEPATH");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[4].setDescription("CommonCron","OTTransactionArchive");
		//-- COMM-IT changed to make it compatible with Maximo 7 API
		//params[4].setDescription("OT Transaction Archive path and filename (Add 'yyyymmdd' to add date to filename)");

	}
}

