/**
 * @author	HCHA
 * Date		Mar 13, 2006
 * Comment	 
 */
package com.psa.custom.common;

import java.nio.channels.FileChannel;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


/**
 * @author		HCHA
 * @class		MxFileCopy
 * @date		Mar 13, 2006
 * @function	
 */
public class MxFileCopy {
    
	public static void fileCopy(String srcFilename, String dstFilename)
		throws IOException
	{

        // Create channel on the source
        FileChannel srcChannel = new FileInputStream(srcFilename).getChannel();
	    
        // Create channel on the destination
        FileChannel dstChannel = new FileOutputStream(dstFilename).getChannel();
	    
        // Copy file contents from source to destination
        dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
	    
        // Close the channels
        srcChannel.close();
        dstChannel.close();
	}


}
