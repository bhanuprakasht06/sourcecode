/**
 * @author	HCHA
 * Date		Jun 29, 2006
 * Comment	 
 */
package com.psa.custom.exchangerate;

import java.io.FilenameFilter;
import java.io.File;


/**
 * @author		HCHA
 * @class		SimpleFilenameFilter
 * @date		Jun 29, 2006
 * @function	Filename filter that handles only ONE "*" in filename	
 */

public class SimpleFilenameFilter 
	implements FilenameFilter
{

	private String searchFileName;
	private String searchFileNameSeg[];
	
	/**
	 * @param searchFileName
	 */
	public SimpleFilenameFilter(String searchFileName) 
	{
		setSearchFileName(searchFileName);
	}


	public String getSearchFileName() 
	{
		return searchFileName;
	}


	public void setSearchFileName(String searchFileName) 
	{
		this.searchFileName = searchFileName;
		searchFileNameSeg = searchFileName.split("\\u002a");
	}


	public boolean accept(File dir, String filename) 
	{
		
		if(!filename.startsWith(searchFileNameSeg[0])){
			return false;
		}
				
		if(searchFileNameSeg.length > 1){
			if(!filename.endsWith(searchFileNameSeg[searchFileNameSeg.length-1])){
				return false;
			}
				
		}
		
		return true;

	 }

}
