package com.psa.custom.sms;

import java.rmi.RemoteException;

import psdi.app.person.EmailRemote;
import psdi.app.person.EmailSetRemote;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXException;

/*
 * Author: BTE
 * 05 APR 2006 - Initial version
 */
public class SMSEmail extends MicSetIn {

	/*
	 * Variables
	 */
	 private UserInfo userInfo;
	 private static SMSConstant SMS = new SMSConstant();
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - constructor  
	 */
	 public SMSEmail(UserInfo userInfo) throws MXException, RemoteException {		 
		 this.userInfo = userInfo;
	 }
	 

	 /*
	 * Author: BTE
	 * 05 APR 2006 - Get email from database based on ic.  
	 */
	 public String getEmail(String personId) 
	 	throws MXException, RemoteException {
	   
		 INTEGRATIONLOGGER.debug("Entering getEmail");
		 
		 // Check if vaiables is null
		 if(personId == null ) {
			   return null;
		 }
		 
		 EmailSetRemote personSet = (EmailSetRemote) MXServer.getMXServer().getMboSet(SMS.EMAIL, userInfo);
				
		 CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		 combinewhereclauses.addWhere("PERSONID= :1");
		 String s = combinewhereclauses.getWhereClause();
	
		 if(s != null && s != SMS.EMPTY){
			 SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			 sqlformat.setObject(1, SMS.EMAIL, SMS.PERSONID, personId);
	
			 personSet.setWhere(sqlformat.format());
			 if(!personSet.isEmpty()) {
		
				 EmailRemote email = (EmailRemote) personSet.getMbo(0);
		
				 if(!email.isNull(SMS.EMAILADDRESS)){
					 INTEGRATIONLOGGER.debug("Leaving getEmail");
					 return email.getString(SMS.EMAILADDRESS);
				 }
			 }
		 }				
		 
		 INTEGRATIONLOGGER.debug("Leaving getEmail");
		 return null;		   
	 }	 	
}
