/*     */ package com.psa.custom.oa12i;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.List;
/*     */ import psdi.app.contract.ContractLineSetRemote;
/*     */ import psdi.app.contract.purch.PurchViewRemote;
/*     */ import psdi.app.contract.purch.PurchViewSetRemote;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.iface.migexits.UserExit;
/*     */ import psdi.mbo.MaximoDD;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.mbo.Translate;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
/*     */ public class MoutPRUser
/*     */   extends UserExit
/*     */ {
/*     */   private static final double MAX_SKIP_PR_COST = 10000.0D;
/*     */   
/*     */   public StructureData setUserValueOut(StructureData irData)
/*     */     throws MXException, RemoteException
/*     */   {
/*  34 */     irData.breakData();
/*     */     
/*     */ 
/*  37 */     ERPOutExtCustom erpoutext = new ERPOutExtCustom(getUserInfo());
/*  38 */     String orgid = irData.getCurrentData("ORGID");
/*  39 */     List prlinelist = irData.getChildrenData("PRLINE");
/*  40 */     if (prlinelist.size() > 0)
/*     */     {
/*  42 */       for (int i = 0; i < prlinelist.size(); i++)
/*     */       {
/*  44 */         irData.setAsCurrent(prlinelist, i);
/*  45 */         if (!irData.isCurrentDataNull("OA_EXPENDTYPE"))
/*     */         {
/*  47 */           MboRemote worktype = erpoutext.getWorkTypeMbo(irData.getCurrentData("OA_EXPENDTYPE"), orgid);
/*  48 */           irData.setCurrentData("OA_EXPENDTYPE", worktype.getString("wtypedesc"));
/*     */         }
/*     */       }
/*  51 */       irData.setParentAsCurrent();
/*     */     }
/*  56 */     if ((!irData.isCurrentDataNull("VENDOR")) && (irData.getCurrentDataAsString("VENDOR").equals("CPD")))
/*     */     {
/*  58 */       integrationLogger.debug("[MoutPrUser]Vendor is CPD, need to blank it and then send to oracle, continue..");
/*  59 */       irData.setCurrentDataNull("VENDOR");
/*  60 */       return irData;
/*     */     }
/*  74 */     double totalcost = irData.getCurrentDataAsDouble("TOTALCOST");
/*  75 */     integrationLogger.debug("[MoutPrUser]TotalCost = " + totalcost);
/*  77 */     if (totalcost > 10000.0D)
/*     */     {
/*  79 */       integrationLogger.debug("[MoutPrUser]total cost > 10k, need to send to oracle, continue..");
/*  80 */       return irData;
/*     */     }
/*  87 */     Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
/*  88 */     String orgId = irData.getCurrentData("ORGID");
/*  89 */     String itemnum = null;
/*  90 */     String linetype = null;
/*  91 */     String itemdesc = null;
/*     */     
/*  93 */     List list = irData.getChildrenData("PRLINE");
/*  94 */     if ((list != null) && (list.size() > 0))
/*     */     {
/*  97 */       irData.setAsCurrent(list, 0);
/*     */       
/*  99 */       linetype = irData.getCurrentData("LINETYPE");
/* 100 */       integrationLogger.debug("[MoutPrUser]linetype  = " + linetype);
/* 102 */       if (!irData.isCurrentDataNull("CATEGORY"))
/*     */       {
/* 104 */         String stockCategory = translate.toInternalString("CATEGORY", irData.getCurrentData("CATEGORY"));
/* 105 */         integrationLogger.debug("[MoutPrUser]stockCategory  = " + stockCategory);
/* 107 */         if (stockCategory.equalsIgnoreCase("NS"))
/*     */         {
/* 109 */           if (!irData.isCurrentDataNull("ITEMNUM"))
/*     */           {
/* 111 */             itemnum = irData.getCurrentData("ITEMNUM");
/* 112 */             integrationLogger.debug("[MoutPrUser]itemnum  = " + itemnum);
/*     */           }
/*     */           else
/*     */           {
/* 117 */             irData.setParentAsCurrent();
/* 118 */             integrationLogger.debug("[MoutPrUser]itemnum null?!, continue..");
/* 119 */             return irData;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 125 */           irData.setParentAsCurrent();
/* 126 */           integrationLogger.debug("[MoutPrUser]Stock Category not non-stock, continue..");
/* 127 */           return irData;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 132 */         itemnum = irData.getCurrentData("ITEMNUM");
/* 133 */         integrationLogger.debug("[MoutPrUser]itemnum  = " + itemnum);
/* 135 */         if (linetype != null)
/*     */         {
/* 137 */           if (linetype.equalsIgnoreCase("ITEM"))
/*     */           {
/* 140 */             irData.setParentAsCurrent();
/* 141 */             integrationLogger.debug("[MoutPrUser]Stock Category null.. linetype=ITEM.. assuming stock item, continue..");
/* 142 */             return irData;
/*     */           }
/* 144 */           if ((linetype.equalsIgnoreCase("MATERIAL")) || (linetype.equalsIgnoreCase("SERVICE")))
/*     */           {
/* 146 */             integrationLogger.debug("[MoutPrUser]Line Type = Material or Service");
/* 147 */             itemdesc = irData.getCurrentData("DESCRIPTION");
/* 148 */             integrationLogger.debug("[MoutPrUser]itemdesc  = " + itemdesc);
/*     */           }
/*     */           else
/*     */           {
/* 152 */             integrationLogger.debug("[MoutPrUser]Line Type = Std Service => non stock");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 159 */     irData.setParentAsCurrent();
/* 166 */     if (irData.isCurrentDataNull("VENDOR"))
/*     */     {
/* 168 */       integrationLogger.debug("[MoutPrUser]no vendor => no contract");
/* 169 */       integrationLogger.debug("[MoutPrUser]SKIP!!!!");
/* 170 */       throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*     */     }
/* 172 */     String vendor = irData.getCurrentData("VENDOR");
/* 173 */     integrationLogger.debug("[MoutPrUser]vendor= " + vendor);
/*     */     
/* 175 */     PurchViewSetRemote contractSet = (PurchViewSetRemote)MXServer.getMXServer().getMboSet("PURCHVIEW", getUserInfo());
/*     */     
/* 177 */     SqlFormat sqlformat = new SqlFormat(getUserInfo(), "vendor = :1 and orgid = :2 and status='APPR'");
/* 178 */     sqlformat.setObject(1, "PURCHVIEW", "VENDOR", vendor);
/* 179 */     sqlformat.setObject(2, "PURCHVIEW", "ORGID", orgId);
/*     */     
/* 181 */     contractSet.setWhere(sqlformat.format());
/* 183 */     for (PurchViewRemote contract = (PurchViewRemote)contractSet.moveFirst(); contract != null; contract = (PurchViewRemote)contractSet.moveNext())
/*     */     {
/* 188 */       String contractnum = contract.getString("CONTRACTNUM");
/* 189 */       String contractrev = contract.getString("REVISIONNUM");
/* 190 */       integrationLogger.debug("[MoutPrUser]contractnum  = " + contractnum);
/* 191 */       integrationLogger.debug("[MoutPrUser]contractrev  = " + contractrev);
/*     */       
/*     */ 
/* 194 */       ContractLineSetRemote contractlineSet = (ContractLineSetRemote)MXServer.getMXServer().getMboSet("CONTRACTLINE", getUserInfo());
/*     */       
/* 196 */       SqlFormat clSqlformat = null;
/* 198 */       if ((linetype.equalsIgnoreCase("MATERIAL")) || (linetype.equalsIgnoreCase("SERVICE")))
/*     */       {
/* 199 */         clSqlformat = new SqlFormat(getUserInfo(), "contractnum =:1 and revisionnum =:2 and orgid =:3 and description =:4 and linetype =:5");
/* 200 */         clSqlformat.setObject(1, "CONTRACTLINE", "CONTRACTNUM", contractnum);
/* 201 */         clSqlformat.setObject(2, "CONTRACTLINE", "REVISIONNUM", contractrev);
/* 202 */         clSqlformat.setObject(3, "CONTRACTLINE", "ORGID", orgId);
/* 203 */         clSqlformat.setObject(4, "CONTRACTLINE", "DESCRIPTION", itemdesc);
/* 204 */         clSqlformat.setObject(5, "CONTRACTLINE", "LINETYPE", linetype);
/*     */       }
/*     */       else
/*     */       {
/* 207 */         clSqlformat = new SqlFormat(getUserInfo(), "contractnum =:1 and revisionnum =:2 and orgid =:3 and itemnum =:4 ");
/* 208 */         clSqlformat.setObject(1, "CONTRACTLINE", "CONTRACTNUM", contractnum);
/* 209 */         clSqlformat.setObject(2, "CONTRACTLINE", "REVISIONNUM", contractrev);
/* 210 */         clSqlformat.setObject(3, "CONTRACTLINE", "ORGID", orgId);
/* 211 */         clSqlformat.setObject(4, "CONTRACTLINE", "ITEMNUM", itemnum);
/*     */       }
/* 214 */       contractlineSet.setWhere(clSqlformat.format());
/* 216 */       if (!contractlineSet.isEmpty())
/*     */       {
/* 218 */         integrationLogger.debug("[MoutPrUser]Contract item...continue..");
/* 219 */         return irData;
/*     */       }
/*     */     }
/* 226 */     integrationLogger.debug("[MoutPrUser]Item not found in any contract.....");
/* 227 */     integrationLogger.debug("[MoutPrUser]SKIP!!!!");
/* 228 */     throw new MXApplicationException("iface", "SKIP_TRANSACTION");
/*     */   }
/*     */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.MoutPRUser
 * JD-Core Version:    0.7.0.1
 */