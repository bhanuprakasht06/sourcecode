package com.psa.custom.dkms;
//import psdi.custom.common.MxXml;
public class Testxml {
	
	public static void main(String args[])
	
	{
		final String MSG_START_INTERFACE =
	    	" xmlns=\"http://www.ibm.com/maximo\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"creationDateTime=\"2009-01-12T06:23:20-05:00\" transLanguage=\"EN\" baseLanguage=\"EN\" maximoVersion=\"7 1 137 V7110-890\" event=\"1\">";    
	    		
		final String ifacename = "LOCMETERSet";	
		final String TAG_MXLOCMETER = "LOCMETERSet";
		final String TAG_LOCMETER = "METERDATA";	
		
		final String TAG_ORGID = "ORGID";
		 final String TAG_SITEID = "SITEID";
		 final String TAG_LOCATION = "LOCATION";
		 final String TAG_METERNAME = "METERNAME";
		 final String TAG_ISDELTA = "ISDELTA";
		 final String TAG_INSPECTOR = "INSPECTOR";
		 final String TAG_NEWREADINGDATE = "NEWREADINGDATE";
		 final String TAG_NEWREADING = "NEWREADING";
		
	//	MxXml mxXml=new MxXml();
		String xml =  
			"<Sync"+ifacename +MSG_START_INTERFACE+">" +
    		"<"+TAG_MXLOCMETER+">" +
 			"<"+TAG_LOCMETER+" action=\"AddChange\">" + // object 
 		
 			
 			"</" +TAG_LOCMETER+ ">" + // object			
 			"</" + TAG_MXLOCMETER + ">" + //Integration object
 			"</Sync"+ifacename+">"; 	
		
		System.out.println(xml);
		
	}
	
}
