/*    */ package com.psa.custom.oa12i;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.List;
/*    */ import psdi.iface.mic.StructureData;
/*    */ import psdi.iface.migexits.UserExit;
/*    */ import psdi.mbo.MboRemote;
/*    */ import psdi.util.MXException;
/*    */ import psdi.util.logging.MXLogger;
/*    */ 
/*    */ public class MoutPOUser
/*    */   extends UserExit
/*    */ {
/*    */   public StructureData setUserValueOut(StructureData irData)
/*    */     throws MXException, RemoteException
/*    */   {
/* 31 */     irData.breakData();
/* 32 */     integrationLogger.debug("Entering MoutPOUser");
/* 33 */     ERPOutExtCustom erpoutext = new ERPOutExtCustom(getUserInfo());
/* 34 */     String orgid = irData.getCurrentData("ORGID");
/* 35 */     List polinelist = irData.getChildrenData("POLINE");
/* 36 */     if (polinelist != null)
/*    */     {
/* 38 */       for (int i = 0; i < polinelist.size(); i++)
/*    */       {
/* 40 */         irData.setAsCurrent(polinelist, i);
/* 41 */         if (!irData.isCurrentDataNull("OA_EXPENDTYPE"))
/*    */         {
/* 43 */           MboRemote worktype = erpoutext.getWorkTypeMbo(irData.getCurrentData("OA_EXPENDTYPE"), orgid);
/* 44 */           irData.setCurrentData("OA_EXPENDTYPE", worktype.getString("wtypedesc"));
/*    */         }
/*    */       }
/* 47 */       irData.setParentAsCurrent();
/*    */     }
/* 49 */     integrationLogger.debug("Leaving MoutPOUser");
/* 50 */     return irData;
/*    */   }
/*    */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.MoutPOUser
 * JD-Core Version:    0.7.0.1
 */