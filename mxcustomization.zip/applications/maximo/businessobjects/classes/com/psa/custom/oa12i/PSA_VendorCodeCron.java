package com.psa.custom.oa12i;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;

import javax.mail.MessagingException;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.load.RecoveryService;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
 
public class PSA_VendorCodeCron extends SimpleCronTask {
	
	
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
 	private static CrontaskParamInfo params[];
 	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
 	private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+08:00'";
 	private static final String SPACE = " ";
 	private static final String NEWLINE = "\n";
 	private static final String SUBJECT = "[EMS-Vendor] Error: Error occured in Vendor Cron.";
	private String directory;
 	private	String unzipExec;              
	private String processDirectory; 
    private String splitTag;
    private String targetDirectory;
    private String backupDirectory;
    private File loadDir;
    private String importFileName;
    private String alertEmailId;
    private MxEmail email;
    private RecoveryService recoveryService;
    private Vector vec;	

	public PSA_VendorCodeCron() {
		
	}
	
	public CrontaskParamInfo[] getParameters() throws MXException,
		RemoteException {

		params = new CrontaskParamInfo[8];
		params[0] = new CrontaskParamInfo();
		params[0].setName("ALERTEMAIL");
		params[0].setDescription("CommonCron","Administrator Mail ID");
		params[1] = new CrontaskParamInfo();
		params[1].setName("DIRECTORY");
		params[1].setDescription("CommonCron","LocalDirectory");
		params[2] = new CrontaskParamInfo();
		params[2].setName("TARGETDIRECTORY");
		params[2].setDescription("CommonCron","TargetDirectory");
		params[3] = new CrontaskParamInfo();
		params[3].setName("PROCESSDIRECTOR");
		params[3].setDescription("CommonCron","TempDirectory");
		params[4] = new CrontaskParamInfo();
		params[4].setName("IMPORTFILENAME");
		params[4].setDescription("CommonCron","FileNameOfTheInputFile");
		params[5] = new CrontaskParamInfo();
		params[5].setName("SPLITTAG");
		params[5].setDefault("~");
		params[5].setDescription("CommonCron","DelimiterFlatFile");
		params[6] = new CrontaskParamInfo();
		params[6].setName("UNZIPEXEC");
		params[6].setDescription("CommonCron","ExecutableUnziping");
		params[7] = new CrontaskParamInfo();
		params[7].setName("BACKUPDIRECTORY");
		params[7].setDescription("CommonCron","BackupDirectory");
		return params;
	}


	//Refreshing Cron parameter
	 private boolean isReqParamSet() {
		 
		 try
			{
			 alertEmailId = getParamAsString("ALERTEMAIL");
			 //email.setAdmin(alertEmailId);
			 if (alertEmailId == null || alertEmailId.equalsIgnoreCase("")) {
			   	 return false;
			 }
			 directory = getParamAsString("DIRECTORY");
			 loadDir = new File(directory);
			 if (directory == null || directory.equalsIgnoreCase("")) {
			   	 return false;
			 }
			 targetDirectory = getParamAsString("TARGETDIRECTORY");
			 if (targetDirectory == null || targetDirectory.equalsIgnoreCase("")){
			   	 return false;
			 }
			 processDirectory = getParamAsString("PROCESSDIRECTOR");
			 if (processDirectory == null || processDirectory.equalsIgnoreCase("")){
			   	 return false;
			 }
			 DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
			 String todayDate=fileDateFormat.format(new Date());
			 importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmdd",todayDate);
			 if (importFileName == null || importFileName.equalsIgnoreCase("")){
			     return false;
			 }
			 splitTag = getParamAsString("SPLITTAG");
			 if (splitTag == null || splitTag.equalsIgnoreCase("")){
			   	 return false;
			 }
			 unzipExec = getParamAsString("UNZIPEXEC");
			 if (unzipExec == null || unzipExec.equalsIgnoreCase("")){
			   	 return false;
			 }
			 backupDirectory = getParamAsString("BACKUPDIRECTORY");
			 if (backupDirectory == null || backupDirectory.equalsIgnoreCase("")){
			   	 return false;
			 }
			}
			catch(Exception e)
			{
				e.printStackTrace();
				//	email.send(SUBJECT,e.getMessage());
			}
		 return true;
	}
	
	@Override
	public void cronAction() {
		// TODO Auto-generated method stub
		try
		{
			if(isReqParamSet())
			{
			integrationLogger.debug("Vendor file Processing Cron Loading");
			
			if ((importFileName != null) && (directory != null)) {          
				if (!checkFileExist(importFileName)) {

					integrationLogger.debug("Vendor file Processing Cron -- unable to read the input file");
             }
				else
				{
					
					//Process Vendor Interface file
		            SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);           
		            integrationLogger.debug("Vendor file Processing Cron - Processing the folder data");
		            File afile[] = loadDir.listFiles(filter);
		            if(afile != null) {
		                     int i = afile.length;
		                     int fileprocessed = 0;
		                     for(int j = 0; j < i; j++) 
		                     {
		                      	//recoveryService = new RecoveryService(afile[j]); 
		                        System.out.println("["+getName()+"] Processing '" + afile[j].getName() + "'" );
		                        try {
		                        	
		                        	String file = processDirectory + afile[j].getName();
		                        	String targetfile = targetDirectory + afile[j].getName();
		                       
		                        	MxFileCopy.fileCopy(afile[j].toString(), processDirectory + afile[j].getName());

		                        	//Unzip File
		                        	String cmd = unzipExec + SPACE + file;
		                        	int returnUnzipCmd=MxZip.unzipFile(cmd);
		                        	if (returnUnzipCmd==0)
		                        	{
		                                //Get filename without extension
		                                int dotPos = file.lastIndexOf(".");
		                                int tgtdotPos = targetfile.lastIndexOf(".");
		                                String extractedFile = file.substring(0,dotPos);
		                                String targetTxtFile = targetfile.substring(0,tgtdotPos);
		                                Collection col = parseFlatFile(extractedFile);
		                            
		                                VendorDataProcessing(col,targetTxtFile);
		                                File fExtractedFile = new File(extractedFile);
		                        
		                                fExtractedFile.delete();
		                        	}
		                        }
		                        catch(Exception e){
                                    
	                               }
		                           /*finally {
		                               try {
		                                       integrationLogger.debug("processFolderData: End Recovery");

		                                       recoveryService.endRecovery();
		                               }
		                               catch(Exception e){
		                                       
		                               }
		                       }*/
		                       fileprocessed++; 
		                       if(fileprocessed!=0){
		                               System.out.println("["+getName()+"] "+fileprocessed+ " file(s) processed." );
		                       }
		                       	//Code block to move zip file to backup folder and delete from source directory.
	                        	String srcFile = directory + "/" + afile[j].getName();
	                        	File FsrcFile = new File (srcFile);
	                        	MxFileCopy.fileCopy(afile[j].toString(), backupDirectory + afile[j].getName());
	                        	FsrcFile.delete();
		        }
		}
				}
     } 
			}
			else
			{
				integrationLogger.info("Required Parameters are not set.");
			}
			integrationLogger.debug("Vendor file Processing Cron - End of cron");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//email.send(SUBJECT,e.getMessage());	
		}
	}
	
    public boolean checkFileExist (String fileExtension) {
        SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
        File[] afile = loadDir.listFiles(filter);
        if(afile != null) {	
        	int i = afile.length;
        	if (i > 0){
                integrationLogger.debug("File found. Leaving checkFileExist");
                return true;
            }
        }
        integrationLogger.debug("File not found. Leaving checkFileExist");
        return false;
    }
    
		// Parse Interface file and store into the collection
	 private Collection parseFlatFile(String file) throws IOException {


	        Collection col = new Vector();
	        try
	        {
	        BufferedReader flatfileReader = new BufferedReader(new FileReader(file));
	        //int linenumber=0;
	        String curLine ;
	        while((curLine = flatfileReader.readLine()) != null)
	        {
                //String[] str = curLine.split(splitTag);
                String[] str = curLine.split(splitTag, -1);
                Vector vec = new Vector();

                for(int i=0;i<str.length;i++){
                       
                        vec.add(str[i].trim());
                }
                col.add(vec);
                //linenumber++;
        }

	        integrationLogger.debug("Vendor Flat file parsing completed");
	        flatfileReader.close();
	        }
	        catch(Exception e)
	        {
	        	e.printStackTrace();
			//	email.send(SUBJECT,e.getMessage());
	        }
	        return col;
	    }

// Code block to read vendor file and form unique COMPANY code value based on the values from 4 different fields in the format BUNAME-VENDORID-SITECODE(CURRENCY)
	 private void VendorDataProcessing(Collection col, String targetTxtFile) throws MXException,ParseException, MessagingException, SQLException, IOException
	 {
		 try
		 {

		 	String errorMessage="";
	        Iterator iterParsedData = col.iterator();
	        FileWriter fileWriter = new FileWriter(targetTxtFile);
	        BufferedWriter out = new BufferedWriter(fileWriter);
	        while (iterParsedData.hasNext()) {
	        	try {

		                vec = (Vector)iterParsedData.next(); 
		                String firstElement = (String) vec.firstElement();
		                if (firstElement.equalsIgnoreCase("PSA_GFS_MAXIMO") || firstElement.equalsIgnoreCase("ORGID")) {
		                	for (int i = 0; i < vec.size(); i++) {
			                	out.write((String)vec.elementAt(i));
			                	if (i != (vec.size()-1 )) {
			                		out.write(splitTag);
								}
							}
		                	out.write(NEWLINE);
		                	out.flush();
		                }
		                else {
		                	for (int j = 0; j < vec.size(); j++) {
		                		if (j != 10) {
		                			out.write((String)vec.elementAt(j));
								} else if (j == 10){
									String psa_gfsbuid = (String) vec.elementAt(11);
					                String psa_gfssitecode = (String) vec.elementAt(12);
					                String psa_gfssupplierid = (String) vec.elementAt(13);
					                String currencycode = (String) vec.elementAt(15);
					                String company = "";
					                if (!psa_gfsbuid.equalsIgnoreCase("") && !psa_gfssitecode.equalsIgnoreCase("") && !psa_gfssupplierid.equalsIgnoreCase("")) {
										company = psa_gfsbuid+"-"+psa_gfssupplierid+"-"+psa_gfssitecode;
										vec.setElementAt(company, 10);
										System.out.println("+++++++++++++++++++++++++++++company :"+company);
										out.write((String)vec.elementAt(10));
									}
					                else {
					                	vec.setElementAt(company, 10);
					                	System.out.println("+++++++++++++++++++++++++++++company :"+company);
					                	out.write((String)vec.elementAt(10));
									}
								}
		                		if (j != (vec.size()-1)) {
		                			out.write(splitTag);
		                		}
							}
		                	out.write(NEWLINE);
		                	out.flush();
		               
						}
		                
					} catch (Exception e) {
						
						if (errorMessage.equalsIgnoreCase("")) {
							errorMessage="Error while processing the following data:\n\n"+vec;
							
						}
						else if (!errorMessage.contains(vec.toString())) {
							errorMessage = errorMessage+"\n"+vec;
							
							}
					}

	                	}
	        out.close();
	        if (errorMessage.length()>0) {
	               	MXServer.sendEMail(alertEmailId, alertEmailId, "Vendor file Processing Cron Error", errorMessage);
				}
	       	                
	        integrationLogger.debug("Vendor file Processing Cron - End of procesing record");
		 }
		 catch (Exception e) {
			 e.printStackTrace();
			}
	 }	 
}