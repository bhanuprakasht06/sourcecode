/*     */ package com.psa.custom.oa12i;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.SQLException;
/*     */ import psdi.iface.app.pc.MaxPCProcess;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.logging.MXLogger;
/*     */ 
/*     */ public class MxPCProcess
/*     */   extends MaxPCProcess
/*     */ {
/*     */   public MxPCProcess()
/*     */     throws MXException, RemoteException
/*     */   {}
/*     */   
/*     */   public void setAdditionalData(MboSetRemote MboSet, String tableName)
/*     */     throws MXException, RemoteException
/*     */   {
/*  23 */     INTEGRATIONLOGGER.debug("Entering setAdditionalData" + tableName);
/*     */     
/*  25 */     super.setAdditionalData(MboSet, tableName);
/*  27 */     if (tableName.equals("CONTRACTAUTH"))
/*     */     {
/*  29 */       String contractnum = MboSet.getMbo(0).getString("CONTRACTNUM");
/*  30 */       String revisionnum = MboSet.getMbo(0).getString("REVISIONNUM");
/*  31 */       String vendor = MboSet.getMbo(0).getString("VENDOR");
/*  32 */       String billto = MboSet.getMbo(0).getString("BILLTO");
/*  33 */       String billtoattn = MboSet.getMbo(0).getString("BILLTOATTN");
/*     */       
/*  35 */       INTEGRATIONLOGGER.debug(contractnum);
/*  36 */       INTEGRATIONLOGGER.debug(revisionnum);
/*  37 */       INTEGRATIONLOGGER.debug(vendor);
/*  38 */       INTEGRATIONLOGGER.debug(billto);
/*  39 */       INTEGRATIONLOGGER.debug(billtoattn);
/*     */       try
/*     */       {
/*  42 */         if (!getContractAuth("BT", contractnum, revisionnum, vendor, billto, billtoattn)) {
/*     */           try
/*     */           {
/*  45 */             MboSet.save(0L);
/*  46 */             MboSet.commit();
/*     */             
/*  48 */             insertAuthSite("KT", 
/*  49 */               contractnum, 
/*  50 */               revisionnum, 
/*  51 */               vendor, 
/*  52 */               billto, 
/*  53 */               billtoattn);
/*  54 */             insertAuthSite("TPT", 
/*  55 */               contractnum, 
/*  56 */               revisionnum, 
/*  57 */               vendor, 
/*  58 */               billto, 
/*  59 */               billtoattn);
/*  60 */             insertAuthSite("PPT1", 
/*  61 */               contractnum, 
/*  62 */               revisionnum, 
/*  63 */               vendor, 
/*  64 */               billto, 
/*  65 */               billtoattn);
/*  66 */             insertAuthSite("PPT2", 
/*  67 */               contractnum, 
/*  68 */               revisionnum, 
/*  69 */               vendor, 
/*  70 */               billto, 
/*  71 */               billtoattn);
/*  72 */             insertAuthSite("MED", 
/*  73 */               contractnum, 
/*  74 */               revisionnum, 
/*  75 */               vendor, 
/*  76 */               billto, 
/*  77 */               billtoattn);
/*     */           }
/*     */           catch (SQLException e)
/*     */           {
/*  81 */             INTEGRATIONLOGGER.debug(e.getMessage());
/*     */           }
/*     */         } else {
/*  85 */           MboSet.remove();
/*     */         }
/*     */       }
/*     */       catch (SQLException e)
/*     */       {
/*  89 */         INTEGRATIONLOGGER.debug(e.getMessage());
/*     */       }
/*     */     }
/*  93 */     INTEGRATIONLOGGER.debug("Leaving setAdditionalData" + tableName);
/*     */   }
/*     */   
/*     */   public void insertAuthSite(String site, String contractnum, String revisionnum, String vendor, String billto, String billtoattn)
/*     */     throws RemoteException, MXException, SQLException
/*     */   {
/* 134 */     throw new Error("Unresolved compilation problem: \n\tThe method getSystemConnection() is undefined for the type DBManager\n");
/*     */   }
/*     */   
/*     */   public String getContractId(String contractnum)
/*     */     throws MXException, RemoteException, SQLException
/*     */   {
/* 172 */     throw new Error("Unresolved compilation problem: \n\tThe method getSystemConnection() is undefined for the type DBManager\n");
/*     */   }
/*     */   
/*     */   public boolean getContractAuth(String site, String contractnum, String revisionnum, String vendor, String billto, String billtoattn)
/*     */     throws MXException, RemoteException, SQLException
/*     */   {
/* 244 */     throw new Error("Unresolved compilation problem: \n\tThe method getSystemConnection() is undefined for the type DBManager\n");
/*     */   }
/*     */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.MxPCProcess
 * JD-Core Version:    0.7.0.1
 */