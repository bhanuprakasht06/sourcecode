package com.psa.custom.common;

import java.rmi.RemoteException;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.app.location.*;


/**
 * @author		HCHA
 * @class		EMSSite
 * @date		Feb 27, 2006
 * @function	Retrieve Maximo Organisation ID and Site ID based on location ID
 */
public class EMSSite {

	private String orgID;
	private String siteID;
	private String locID;

	//Note: Use getRunasUserInfo() to get userInfo  
	private UserInfo userInfo;
	
	public EMSSite(UserInfo userInfo) 
		throws MXException, RemoteException 
	{
		this.userInfo = userInfo;
		orgID=null;
		siteID=null;
	}
	
	public EMSSite(String locID, UserInfo userInfo) 
		throws MXException, RemoteException 
	{
		this.userInfo = userInfo;
		setlocID(locID);
	}

	public void setlocID(String locID) 
		throws MXException, RemoteException 
	{
		
		this.locID = locID;
		
		LocationSetRemote locSet =(LocationSetRemote) MXServer.getMXServer().getMboSet("LOCATIONS", userInfo);
		String sql = "LOCATION= :1 and SITEID='PSASG'";
		SqlFormat sqlformat = new SqlFormat(userInfo, sql);
        sqlformat.setObject(1, "LOCATIONS", "LOCATION", locID);
        
        locSet.setWhere(sqlformat.format());
        
        if(!locSet.isEmpty())
        {
        	LocationRemote location = (LocationRemote) locSet.getMbo(0);
        	
        	if(!location.isNull("ORGID")){
        		orgID = location.getString("ORGID");
        	}
        	else{
        		orgID = null;
        	}
        	
        	if(!location.isNull("SITEID")){
        		//siteID = location.getString("SITEID");
        		siteID="PSASG";
        	}
        	else{
        		siteID = null;
        	}
        }
        else{
        	orgID = null;
        	siteID = null;
        }
        
	}

	
	public String getlocID() {		
		return locID;
	}
	
	
	public String getOrgID() {
		return orgID;
	}
	
	public String getSiteID() {
		return "PSASG";
	}
	
	
}
