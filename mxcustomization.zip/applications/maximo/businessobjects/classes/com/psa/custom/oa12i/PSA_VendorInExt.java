package com.psa.custom.oa12i;

import java.rmi.RemoteException;
import java.util.List;
import psdi.iface.mic.StructureData;
import psdi.iface.oa12.ERPInExt;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.txn.MXTransaction;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
 
public class PSA_VendorInExt
  extends ERPInExt
{
  public StructureData setDataIn(StructureData paramStructureData)
    throws MXException, RemoteException
  {
    integrationLogger.debug("Entering VendorInExt.setDataIn");
    paramStructureData = super.setDataIn(paramStructureData);
    String company = paramStructureData.getCurrentData("COMPANY");
    String orgid = paramStructureData.getCurrentData("ORGID");
    List compcontact = paramStructureData.getChildrenData("COMPCONTACT");
    if ((compcontact != null) && (compcontact.size() > 0))
    {
      for (int i = (compcontact.size() - 1); i >= 0; i--)
      {
        paramStructureData.setAsCurrent(compcontact, i);
        MboSetRemote compcontSet = getMboSet("COMPCONTACT");
        MboRemote compcont = null;
        SqlFormat localSqlFormat2 = new SqlFormat(getUserInfo(), "company = :1 and orgid = :2");
        localSqlFormat2.setObject(1, "COMPCONTACT", "COMPANY", company);
        localSqlFormat2.setObject(2, "COMPCONTACT", "ORGID", orgid);
        compcontSet.setWhere(localSqlFormat2.format());
        compcont = compcontSet.moveFirst();
        if (compcont != null)
        {
          if (paramStructureData.isCurrentDataNull("CONTACT")) {
            paramStructureData.setCurrentData("CONTACT", compcont.getString("CONTACT"));
          }
          if ((!paramStructureData.getCurrentData("CONTACT").equals(compcont.getString("CONTACT"))) || ((!paramStructureData.isCurrentDataNull("OA_DISABLED")) && (paramStructureData.getCurrentDataAsBoolean("OA_DISABLED"))))
          {
        	  compcontSet.setMXTransaction(this.mxTrans);
        	  compcontSet.getMXTransaction().put("INTEGRATION", true);
        	  compcontSet.getMXTransaction().put("SENDER", getExtSystem());
        	  compcont.delete();
            if ((!paramStructureData.isCurrentDataNull("OA_DISABLED")) && (paramStructureData.getCurrentDataAsBoolean("OA_DISABLED"))) {
              paramStructureData.removeCurrentData();
            }
          }
        }
      }
      paramStructureData.setParentAsCurrent();
    }
    integrationLogger.debug("Leaving VendorInExt.setDataIn");
    return paramStructureData;
  }
}

