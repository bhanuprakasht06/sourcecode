package com.psa.custom.common;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import psdi.iface.mic.MicUtil;

public class MxDebug {
	
	private boolean onDebug = false;
	
	private String file = null;
	
	private static final String debugHeader = "---Debug--- ";
	
	
	/*
	 * Author: BTE 
	 * Date: 23 FEB 2006
	 * Comment: Set debug mode
	 */
	public void setDebug (boolean on) {
	
		onDebug = on;
	}	
	
	
	/*
	 * Author: BTE
	 * Date: 23 FEB 2006
	 * Comment: Display debug message
	 */
	public void msg (String msg) {
	
		if (onDebug == true) {
			System.out.println(debugHeader + msg);
		}
	}	 
	
	
	/* 
	 * Author: BTE
	 * Date: 23 FEB 2006
	 * Comment: Write to file
	 */
	public void file (String data) {
		if (onDebug == true) {
			
	        try {
	            BufferedWriter out = new BufferedWriter(new FileWriter(file));
	            out.write(data);
	            out.close();
	        } catch (IOException e) {	
	        	
	        		MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);    		
	        }
		}		
	}
	
	
	/*
	 * Author: BTE
	 * Date: 23 FEB 2006
	 * Comment: Set file name and path
	 */
	public void setPath (String path, String filename) {
		
		file = path + "//" + filename;
		
	}
	
}
