/*
 * Modification history
 * 16-10-2007	AGD	eRFQ		Creation
 */
package com.psa.custom.common;

import psdi.mbo.MboConstants;

public abstract interface MboConstantsCustom extends MboConstants
{
	public static final long DBSET = NOVALIDATION + NOACCESSCHECK + NOACTION;

	public static final long FORCESET = NOVALIDATION + NOACCESSCHECK;
}
