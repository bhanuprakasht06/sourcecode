package com.psa.custom.oa12i;

import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.List;
import psdi.iface.mic.StructureData;
import psdi.iface.migexits.UserExit;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.mbo.Translate;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXException;

public class PCInUserExt extends UserExit
{

	  public StructureData setUserValueIn(StructureData irData, StructureData erData)
	    throws MXException, RemoteException
	  {
	   
			erData.breakData();  
		    erData.moveToFirstObjectStruture();
		    List childLines = erData.getChildrenData("CONTRACTLINE");
		    
		     if ((childLines != null) && (childLines.size() > 0))
	        {
	         
		    	 int child = childLines.size() - 1;

	        	do{
	        		if(child<0)
	        			break;
	        	 	erData.setAsCurrent(childLines, child);
	        		Translate translator = MXServer.getMXServer().getMaximoDD().getTranslator();
	        		String intStatus = translator.toInternalString("CONTRACTSTATUS", erData.getCurrentData("LINESTATUS"));
	          	  if (intStatus.equalsIgnoreCase("CAN") ||intStatus.equalsIgnoreCase("CLOSE"))
	                {
	          		 
	                  erData.removeCurrentData();
	                  
	                }
	          	  
	          	child--;
	        		
	         
	        }  while(true);
		  
	        	erData.setAsCurrent();
	   do
	    {
	      updateContractAmt(irData);

	      List list = irData.getChildrenData("CONTRACTAUTH");
	      if (list.isEmpty())
	        return irData;
	      irData.setAsCurrent(list, 0);
	      String existingauthorizedsite = irData.getCurrentData("AUTHSITEID");
	      String orgid = irData.getCurrentData("AUTHORGID");
	      String vendor = irData.getCurrentData("VENDOR");
	      String billto = irData.getCurrentData("BILLTO");
	      irData.setParentAsCurrent();

	      MboSetRemote siteset = getSites(orgid);
	      int i = 0;
	      MboRemote site;
	      while ((site = siteset.getMbo(i++)) != null)
	      {
	    //    MboRemote site;
	        String siteid = site.getString("siteid");
	        if (siteid.equalsIgnoreCase(existingauthorizedsite))
	          continue;
	        irData.createChildrenData("CONTRACTAUTH", true);
	        irData.setCurrentData("AUTHORGID", orgid);
	        irData.setCurrentData("AUTHSITEID", siteid);
	        irData.setCurrentData("VENDOR", vendor);
	        irData.setCurrentData("BILLTO", billto);
	        irData.setParentAsCurrent();
	      }
	    }
	    while (
	      erData.moveToNextObjectStructure());
        }
	    
	    return irData;
	  }

	  private MboSetRemote getSites(String orgid)
	    throws MXException, RemoteException
	  {
	    MboSetRemote SiteSet = MXServer.getMXServer().getMboSet("SITE", getUserInfo());
	    SqlFormat sqlformat = new SqlFormat(getUserInfo(), "orgid=:1");
	    sqlformat.setObject(1, "SITE", "ORGID", orgid);
	    SiteSet.setWhere(sqlformat.format());
	    return SiteSet;
	  }

	  private void updateContractAmt(StructureData irData)
	    throws MXException, RemoteException
	  {
	    MboSetRemote contractset = getContractSet(irData);
	    if (contractset.isEmpty())
	    {
	      contractset.close();
	      return;
	    }
	    MboRemote contract = contractset.getMbo(0);
	    double totalamt = irData.getCurrentDataAsDouble("MAXVOL");
	    if (totalamt < contract.getDouble("maxvol"))
	    {
	      contract.setValue("maxvol", totalamt, 2L);
	      contract.setValue("maxrelvol", totalamt, 2L);
	      contractset.save();
	      irData.removeFromCurrentData("MAXVOL");
	    }
	    contractset.close();
	  }

	  private MboSetRemote getContractSet(StructureData irData)
	    throws MXException, RemoteException
	  {
	    UserInfo userinfo = getUserInfo();
	    MboSetRemote contractset = MXServer.getMXServer().getMboSet("PURCHVIEW", userinfo);
	    SqlFormat sqlformat = new SqlFormat(userinfo, "contractnum=:1 AND revisionnum=:2 AND orgid=:3");
	    sqlformat.setObject(1, "purchview", "contractnum", irData.getCurrentData("CONTRACTNUM"));
	    sqlformat.setInt(2, irData.getCurrentDataAsInt("REVISIONNUM"));
	    sqlformat.setObject(3, "purchview", "orgid", irData.getCurrentData("ORGID"));
	    contractset.setWhere(sqlformat.format());
	    return contractset;
	  }
    	
}
