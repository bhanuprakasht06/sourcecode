/*
 * Modification history
 * 22-11-2012	WMJ	EMS-515	[Interface]Peoplesoft Crontask
 */

package com.psa.custom.sms;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.jdom.Element;

import psdi.iface.mic.MicConstants;
import psdi.iface.mic.MicSetIn;
import psdi.iface.mic.MicSetInfo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

/*
 * Author: BTE
 * Version: 0.01
 * 08 MAR 2006 - Initial version
 * 06 JUN 2006 - Refer to DR-142
 * 06 JUN 2006 - Refer to DR-145
 * 06 JUN 2006 - Refer to DR-141
 * 06 JUN 2006 - Refer to DR-143
 */
public class SMSStaffDataInProcess extends MicSetIn {

        /*
         * Variables
         */
        private static SMSConstant SMS = new SMSConstant();
        String labid = null;
        /*
         * Author: BTE
         * 08 MAR 2006 - Constructor
         */
        public SMSStaffDataInProcess() throws MXException, RemoteException {
                super();
                String labid = null;
        }


        /*
         * Author: BTE
         * 08 MAR 2006 - Check business rules
         * 06 JUN 2006 - Refer to DR-142
         * 06 JUN 2006 - Refer to DR-145
         * 06 JUN 2006 - Refer to DR-143
         */
    public int checkBusinessRules() throws MXException, RemoteException {

        INTEGRATIONLOGGER.debug("Entering checkBusinessRules");

        // 06 JUN 2006 - DR-142: Set action to Add/Change if action is not a Delete.
        if (!actionInd.equalsIgnoreCase(MicConstants.ACTIONDELETE)) {
                actionInd = MicConstants.ACTIONADDUPDATE;
        }

                // Check if PERSONID is null
                if (struc.isCurrentDataNull(SMS.PERSONID)) {
                        throw new MXApplicationException(SMS.IFACE, SMS.PERSONTNOPERSONID);
                }

                // 06 JUN 2006 - DR-145: Skip checking of IC when deleting a Staff Infomation.
                if (!actionInd.equalsIgnoreCase(MicConstants.ACTIONDELETE)) {
                        // Check if IC is null
                        if (struc.isCurrentDataNull(SMS.IC)) {
                                throw new MXApplicationException(SMS.IFACE, SMS.PERSONNOIC);
                        }
                }

                setGLAccount();
                deleteLabor();

        INTEGRATIONLOGGER.debug("Leaving checkBusinessRules");

        return MicConstants.PROCESS;
    }


    /*
         * Author: BTE
         * 05 APR 2006 - create MBO set
         */
    public MboSetRemote createMboSet(boolean flag, MboRemote mboremote, MicSetInfo micsetinfo, String processTable)
        throws MXException, RemoteException {

        INTEGRATIONLOGGER.debug("Entering createMboSet");


        if (processTable.equals(SMS.LABOR)) {
                        INTEGRATIONLOGGER.debug("Entering LABOR");

                setLaborCode();

                        INTEGRATIONLOGGER.debug("Leaving LABOR");
        }

        INTEGRATIONLOGGER.debug("Leaving createMboSet");

        return super.createMboSet(flag, mboremote, micsetinfo, processTable);
    }


        public void setAdditionalData(MboSetRemote MboSet, String tableName) throws MXException, RemoteException{

                INTEGRATIONLOGGER.debug("Entering setAdditionalData");

                if (tableName.equals(SMS.PERSON)) {
                MboSet.save(0);
                MboSet.commit();
                }

                if (tableName.equals("LABORCRAFTRATE")) {

                        try {

                        INTEGRATIONLOGGER.debug("*****set additional data labid*******"+labid);
                        INTEGRATIONLOGGER.debug("*****set additional data struc.getcurrentdata*******"+struc.getCurrentData("PERSONID"));

                                INTEGRATIONLOGGER.debug("TITLE:" + getTitle(MboSet.getMbo(0).getString(SMS.LABORCODE)));

                                 //Take out to see if laborcraftrate can go in without title
                                /*if (!getTitle(labid).matches(".*TECH SPEC.*")) {
                                MboSet.remove();
                                INTEGRATIONLOGGER.debug("remove delLaborCraftRate");
                                }
                                */

                        } catch (SQLException e) {
                                INTEGRATIONLOGGER.info(e.getMessage());
                                INTEGRATIONLOGGER.debug(e.getMessage());
                        }
                }

            INTEGRATIONLOGGER.debug("Leaving setAdditionalData");
        }


    /*
         * Author: BTE
         * 05 APR 2006 - Set missing laborcode
         */
    public void setLaborCode() throws MXException, RemoteException {

        INTEGRATIONLOGGER.debug("*****Entering setLaborCode*******"+labid);
        INTEGRATIONLOGGER.debug("*****Entering setLaborCode*******"+struc.getCurrentData("PERSONID"));
        List lst = struc.getChildrenData("LABOR");
                for (int i = 0; i<lst.size(); i++ ) {
                        struc.setAsCurrent(lst, i);
                                struc.setCurrentData("LABORCODE",labid);
                                struc.setCurrentData("CALNUM",labid);
                                INTEGRATIONLOGGER.debug("*****Entering setLaborCode*******"+struc.getCurrentData("ORGID"));
                }
                INTEGRATIONLOGGER.debug("Leaving setLaborCode");
        }





    /*
         * Author: BTE
         * 05 APR 2006 - Set GL Account
         * 06 JUN 2006 - Refer DR-141
         */
    public void setGLAccount() throws MXException, RemoteException {

        INTEGRATIONLOGGER.debug("Entering setGLAccount");

        if (actionInd.equalsIgnoreCase(MicConstants.ACTIONADDUPDATE)) {
                modGLAccount();
        }

                INTEGRATIONLOGGER.debug("Leaving setGLAccount");
    }


    /*
         * Author: BTE
         * 13 JUN 2006 - Modify GL Account to 24 bytes
         */
    public String modGLAccount() throws MXException {

        INTEGRATIONLOGGER.debug("Entering modGLAccount");

        String glAccount = null;
        labid = struc.getCurrentData("PERSONID");
                // Get GL Account
                List laborLst = struc.getChildrenData("LABOR");
                INTEGRATIONLOGGER.debug("ENTERING LABOR LISTDATA");

                for (int i=0; i<laborLst.size(); i++)
                {
                        struc.setAsCurrent(laborLst, i);
                        List labCraftRateLst = struc.getChildrenData("LABORCRAFTRATE");

                        for (int j=0; j<labCraftRateLst.size(); j++) {
                                struc.setAsCurrent(labCraftRateLst, j);

                                INTEGRATIONLOGGER.debug("ENTERING LABORcraft LISTDATA");

                                List labControlacc = struc.getChildrenData("CONTROLACCOUNT");
                                for (int k=0; k<labControlacc.size(); k++) {
                                        struc.setAsCurrent(labControlacc, k);

                                                glAccount = struc.getCurrentData("VALUE");

                                                INTEGRATIONLOGGER.debug("GLACCOUNT"+glAccount);
                                                if ((glAccount != null) || (!glAccount.equalsIgnoreCase(SMS.EMPTY))) {                                    

                                                        glAccount ="101-2020-2-01-000-" + glAccount + "-2151-000";

                                                        INTEGRATIONLOGGER.debug("CONTROL ACCOUNT SET ***"+glAccount);
                                                        struc.removeFromCurrentData("VALUE");
                                                        struc.setCurrentData("CONTROLACCOUNT", glAccount);
                                                }

                                                break;
                                }
                                }
                                        }
        INTEGRATIONLOGGER.debug("Leaving modGLAccount");

                return glAccount;
                                }






    /*
         * Author: BTE
         * 05 APR 2006 - Get labor ORGID
         */
    public String getLaborOrgID() throws MXException, RemoteException {

        INTEGRATIONLOGGER.debug("Entering getLaborOrgID");

        //List lst = struc.getChildrenData(SMS.LABOR);
                List lst = struc.getChildrenData("LABOR");

        //Iterator iter = lst.iterator();

                for (int i=0; i<lst.size(); i++)
           {
                        struc.setAsCurrent(lst, i);
                    String attr = struc.getCurrentData("ORGID");
                                INTEGRATIONLOGGER.debug("Leaving getLaborOrgID");
                                return attr;

                }
                INTEGRATIONLOGGER.debug("Leaving getLaborOrgID");

                return null;
        }





        /*
         * Author: BTE
         * 05 APR 2006 - Delete LABOR
         * 13 JUN 2006 - Refer to DR-141.
         */
    public void deleteLabor() throws MXException, RemoteException {

        INTEGRATIONLOGGER.debug("Entering deleteLabor");

        if (actionInd.equalsIgnoreCase(MicConstants.ACTIONDELETE)) {

                // Remove delete record in SturctureData
                List lstStruc = struc.getChildrenData(SMS.LABOR);
                Iterator iterStruc = lstStruc.iterator();

                for (int i = 0; iterStruc.hasNext(); ) {
                        iterStruc.next();

                if (actionInd.equalsIgnoreCase(MicConstants.ACTIONDELETE)) {
                        struc.getChildrenData(SMS.LABOR).remove(i);

                        // Reset to start after delete one record in structure
                        lstStruc = struc.getChildrenData(SMS.LABOR);
                        iterStruc = lstStruc.iterator();
                        i = 0;
                } else {
                        i++;
                }
                }

                        String code = struc.getCurrentData(SMS.PERSONID);

                MboSetRemote labSet = (MboSetRemote) MXServer.getMXServer().getMboSet(SMS.LABOR, getUserInfo());

                CombineWhereClauses combinewhereclauses = new CombineWhereClauses();

                combinewhereclauses.addWhere("ORGID= :1");
                combinewhereclauses.addWhere("LABORCODE= :2");
                String s = combinewhereclauses.getWhereClause();

                if(s != null && s != ""){
                        SqlFormat sqlformat = new SqlFormat(getUserInfo(), s);

                        sqlformat.setObject(1, SMS.LABOR, SMS.ORGID, SMS.PSAST);
                        sqlformat.setObject(2, SMS.LABOR, SMS.LABORCODE, code);
                        labSet.setWhere(sqlformat.format());

                        if(!labSet.isEmpty()) {

                                labSet.deleteAll(0L);

                                labSet.save();
                                labSet.commit();
                                labSet.close();
                                }
                }

                StringBuffer stringbuffer = new StringBuffer();

            stringbuffer.append("delete from ");
            stringbuffer.append(SMS.LABORCRAFTRATE);
            stringbuffer.append(" where ");

            stringbuffer.append(SMS.LABORCODE);
            stringbuffer.append("='");
            stringbuffer.append(code);
            stringbuffer.append("'");

            PreparedStatement preparedstatement = null;
            String s3 = stringbuffer.toString();

            INTEGRATIONLOGGER.debug(s3);

                Connection connection = MXServer.getMXServer().getDBManager().getConnection(getUserInfo().getConnectionKey());

            try {
                        preparedstatement = connection.prepareStatement(s3);
                    preparedstatement.execute();
                } catch (SQLException e) {
                        INTEGRATIONLOGGER.error(e);
                }
                //20060814 HCHA - All close statements to connection and preparedstatement
                finally{
                        try {
                                if(preparedstatement !=null) preparedstatement.close();
                                //if(connection!=null) connection.close();
                                getMboServer().freeDBConnection(getUserInfo().getConnectionKey());
                                INTEGRATIONLOGGER.debug("closed db connections");
                        }catch(Exception e){}
                }

        }

        INTEGRATIONLOGGER.debug("Leaving deleteLabor");
    }


    public String getTitle(String personid) throws MXException, RemoteException, SQLException {

        INTEGRATIONLOGGER.debug("Entering getTitle");

            StringBuffer stringbuffer = new StringBuffer();

            stringbuffer.append("select * from person where personid='");
        stringbuffer.append(personid);
        stringbuffer.append("'");

            PreparedStatement preparedstatement = null;
            String s3 = stringbuffer.toString();

            INTEGRATIONLOGGER.debug(s3);

            Connection connection = MXServer.getMXServer().getDBManager().getConnection(getUserInfo().getConnectionKey());
                ResultSet rsTitle=null;

                String title = null;

            try {
                        preparedstatement = connection.prepareStatement(s3);
                        rsTitle=preparedstatement.executeQuery();

                //Check if there is any Inv Balance record
                        if(!rsTitle.next()){
                                INTEGRATIONLOGGER.debug("Record is not found in DB.");
                        }
                        else{
                                title = rsTitle.getString("TITLE");
                        }

                } catch (SQLException e) {
                        INTEGRATIONLOGGER.error(e);
                }
                //20060814 HCHA - All close statements to connection and preparedstatement
                finally{
                        try {
                                if(rsTitle != null) rsTitle.close();
                                if(preparedstatement != null) preparedstatement.close();
                                //if(connection!=null) connection.close();
                                 getMboServer().freeDBConnection(getUserInfo().getConnectionKey());
                                INTEGRATIONLOGGER.debug("closed db connections");
                        }catch(Exception e){
                                e.getMessage();
                        }
                }

                INTEGRATIONLOGGER.debug("Leaving getTitle");
                INTEGRATIONLOGGER.debug(title);

                return title;
    }
 }


