package com.psa.custom.oa12i;

import java.rmi.RemoteException;
import java.util.List;
import psdi.app.pr.PRRemote;
import psdi.app.pr.PRSetRemote;
import psdi.iface.mic.StructureData;
import psdi.iface.migexits.UserExit;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;

public class MinPOUserCustom extends MinPOUser
{

    public MinPOUserCustom()
    {
    }

    public StructureData setUserValueIn(StructureData irData, StructureData erData)
        throws MXException, RemoteException
    {
//  	    System.out.println("MinPOUserCustom: =======================================================================");

	    
//        System.out.println("MinPOUserCustom: Start of super");
				super.setUserValueIn(irData,erData);
//		System.out.println("MinPOUserCustom: End of super");

	    
//	    System.out.println("MinPOUserCustom: =======================================================================");
	    
	      integrationLogger.debug("Entering setUserValueIn");
		
        erData.breakData();
        erData.moveToFirstObjectStruture();
        do
        {
            List list = irData.getChildrenData("POLINE");
            if(list != null && list.size() > 0)
            {
			 					String prnum = null;
			 					String prlinenum = null;
								String siteid = null;
								double linecost = 0.0;
								double quantity = 0.0;
								double unitcost = 0.0;
								double newlinecost = 0.0;
								
								for(int i = 0; i < list.size(); i++)
                {
	                	irData.setAsCurrent(list, i);
	                
                		prnum = irData.getCurrentData("PRNUM");
                		prlinenum = irData.getCurrentData("PRLINENUM");
                		siteid = irData.getCurrentData("SITEID");
                		quantity = irData.getCurrentDataAsDouble("ORDERQTY");
                		unitcost = irData.getCurrentDataAsDouble("UNITCOST");
                		linecost = irData.getCurrentDataAsDouble("LINECOST");
                		
                		//System.out.println("MinPOUserCustom: quantity is " + quantity);
                		//System.out.println("MinPOUserCustom: unitcost is " + unitcost);
                		//System.out.println("MinPOUserCustom: linecost is " + linecost);
                		
                		integrationLogger.debug((new StringBuilder("PRNUM: ")).append(prnum).toString());
                		integrationLogger.debug((new StringBuilder("PRLINENUM ")).append(prlinenum).toString());
                		integrationLogger.debug((new StringBuilder("SITEID: ")).append(siteid).toString());
                		integrationLogger.debug((new StringBuilder("QUANTITY: ")).append(quantity).toString());
                		integrationLogger.debug((new StringBuilder("UNITCOST ")).append(unitcost).toString());
                		integrationLogger.debug((new StringBuilder("LINECOST: ")).append(linecost).toString());
                		
                		if(linecost==0 && quantity != 0 && unitcost != 0)
                		{
                					newlinecost = quantity * unitcost;
                					integrationLogger.debug((new StringBuilder("NEW LINECOST: ")).append(newlinecost).toString());
                					irData.setCurrentData("LINECOST", newlinecost);
                					//System.out.println("MinPOUserCustom: newlinecost is " + newlinecost);
                		}
                		
                		//System.out.println("MinPOUserCustom: =======================================================================");
                		
                }
           	}
        } while(erData.moveToNextObjectStructure());
        integrationLogger.debug("Leaving setUserValueIn");
        return irData;
    }

}

