/*
 * Modification history
 * xx-xx-2006	HYC	NA			Creation
 * xx-09-2007	AGD	SR-110	Make calculation of duration in double instead of int
 */
package com.psa.custom.ois;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;

import com.psa.custom.common.EMSSite;
import com.psa.custom.common.MxLocMeter;


import psdi.security.UserInfo;
import psdi.util.MXException;
import com.psa.custom.common.*;

public class OISQuayCrane {

	private boolean vsl_vin_i; //exclude entries with VIN=0 when vsl_vin_i is true
	private String qcExclFileName;
	private OISCheck qcMovExcl;
	private String inDelimiter;
	private String extractStartDate;
	private String extractEndDate;

	private String boxMeterName;
	private String operHrMeterName;
	private String boxMeterNameM;
	private String operHrMeterNameM;

	private UserInfo userInfo; //Maximo User Info 

	private ArrayList qcDataArray;
	private ArrayList qcFinalArray;

	private  MxLog mxLog;


	public OISQuayCrane(UserInfo userInfo) {

		
		mxLog = new MxLog();
		
		//Default Values
		vsl_vin_i = true;
		inDelimiter = ",";
		boxMeterName = new String("CONTCOUNT"); 
		operHrMeterName = new String("RUNHOURS");
		boxMeterNameM = new String("CONTCOUNTM"); 
		operHrMeterNameM = new String("RUNHOURSM");
		
		this.userInfo=userInfo;
		
		qcMovExcl = new OISCheck();
		qcDataArray = new ArrayList();
		qcFinalArray = new ArrayList();
	}
	
	public OISQuayCrane(boolean vsl_vin_i, String qcExclFileName, String inDelimiter, UserInfo userInfo,String boxMeterName, String operHrMeterName, String boxMeterNameM, String operHrMeterNameM, MxLog mxLog ) 
		throws Exception
	{ 

		this.mxLog = mxLog;
		
		this.boxMeterName = boxMeterName;
		this.operHrMeterName = operHrMeterName;
		this.boxMeterNameM = boxMeterNameM;
		this.operHrMeterNameM = operHrMeterNameM;
		
		this.vsl_vin_i = vsl_vin_i;
		this.qcExclFileName = qcExclFileName;
		this.inDelimiter = inDelimiter;
		this.userInfo=userInfo;
		
		qcMovExcl = new OISCheck(qcExclFileName);
		qcDataArray = new ArrayList();
		qcFinalArray = new ArrayList();

	}


	private boolean isQCEntriesExcluded(String actCode, String vin){
		System.out.println("--inside isQCEntriesExcluded--");
		if((vsl_vin_i)&&(vin.trim().equalsIgnoreCase("0"))){
			//exclude when vsl_vin_i = true and vin is 0
			return true;
		}
		else if (qcMovExcl.isInList(actCode)){
			//if the action code is in the list of action code to exclude
			return true;
		}
		
		return false;
	}
	
	private void addQCDataArray(ArrayList qcDataArray,QCData qcData)
		throws MXException, RemoteException
	{
		System.out.println("--inside addQCDataArray--");
		//Function: To QC activities to the arraylist
		//Additional Checks:
		//  1. Activity date and time overlaps to next day?
		//     -> If yes, split to 2 entries
		//  2. Activity date and time within the extaction range?
		
		
		if(qcData.isActDateOverlapped()){
			//Case: The activity overlaps to the next day
			//Assumation: Overlap is only between 2 days 
			//i.e. current day overlap to the next day
			
			//Date Format: YYYYMMDDHHMM
			int startYear = Integer.parseInt(qcData.getActStartDT().substring(0,4));
			int startMonth = Integer.parseInt(qcData.getActStartDT().substring(4,6))-1;
			int startDay = Integer.parseInt(qcData.getActStartDT().substring(6,8));
			int startHr = Integer.parseInt(qcData.getActStartDT().substring(8,10));
			int startMin = Integer.parseInt(qcData.getActStartDT().substring(10,12));
			
			int endYear = Integer.parseInt(qcData.getActEndDT().substring(0,4));
			int endMonth = Integer.parseInt(qcData.getActEndDT().substring(4,6))-1;
			int endDay = Integer.parseInt(qcData.getActEndDT().substring(6,8));
			int endHr = Integer.parseInt(qcData.getActEndDT().substring(8,10));
			int endMin = Integer.parseInt(qcData.getActEndDT().substring(10,12));
			
			Date startActDate = new GregorianCalendar(startYear,startMonth,startDay,startHr, startMin).getTime();
			Date endActDate = new GregorianCalendar(endYear,endMonth,endDay,endHr, endMin).getTime();
			Date midActDate = new GregorianCalendar(endYear,endMonth,endDay,00, 00).getTime();
			System.out.println("+--------------------startYear----------------------+"+startYear);
			System.out.println("+--------------------startMonth----------------------+"+startMonth);
			System.out.println("+--------------------startDay----------------------+"+startDay);
			System.out.println("+--------------------startHr----------------------+"+startHr);
			System.out.println("+--------------------startMin----------------------+"+startMin);
			System.out.println("+--------------------endYear----------------------+"+endYear);
			System.out.println("+--------------------endMonth----------------------+"+endMonth);
			System.out.println("+--------------------endDay----------------------+"+endDay);
			System.out.println("+--------------------endHr----------------------+"+endHr);
			System.out.println("+--------------------endMin----------------------+"+endMin);
			System.out.println("+--------------------startActDate----------------------+"+startActDate);
			System.out.println("+--------------------endActDate----------------------+"+endActDate);
			System.out.println("+--------------------midActDate----------------------+"+midActDate);
			//Day 1
			//Day Duration - the difference in time will be in msec, further calculated to min  
		    int dayduration1 = (int)((midActDate.getTime() - startActDate.getTime())/(1000 * 60));
		    System.out.println("+--------------------dayduration1----------------------+"+dayduration1);
		    QCData qcDataDay1 = new QCData();
		    qcDataDay1.setAssetID(qcData.getAssetID());
		    qcDataDay1.setDuration(dayduration1);
		    qcDataDay1.setNumContainer(qcData.getNumContainer());
		    qcDataDay1.setExcluded(qcData.isExcluded());
		    qcDataDay1.setActStartDT(qcData.getActStartDT());
		    //End Date Time of Day 1 = Date of Day 2 + Time(00:00)
		    String day1EndDT= new String(qcData.getActEndDT().substring(0,8).concat("0000"));
		    qcDataDay1.setActEndDT(day1EndDT);
		    if((extractStartDate.compareTo(qcDataDay1.getActStartDT().substring(0,8))<=0) &&(extractEndDate.compareTo(qcDataDay1.getActStartDT().substring(0,8))>=0))
		    	qcDataArray.add(qcDataDay1);
		    
		    //Day 2
		    int dayduration2 = (int)((endActDate.getTime() - midActDate.getTime())/(1000 * 60));
		    QCData qcDataDay2 = new QCData();
		    qcDataDay2.setAssetID(qcData.getAssetID());
		    qcDataDay2.setDuration(dayduration2);
		    qcDataDay2.setNumContainer(0);
		    qcDataDay2.setExcluded(qcData.isExcluded());
		    qcDataDay2.setActStartDT(day1EndDT);
		    qcDataDay2.setActEndDT(qcData.getActEndDT());
		    if((extractStartDate.compareTo(qcDataDay2.getActStartDT().substring(0,8))<=0) &&(extractEndDate.compareTo(qcDataDay2.getActStartDT().substring(0,8))>=0))
		    	qcDataArray.add(qcDataDay2);
			
		}
		else{
			//Case: The activity within one day
			if((extractStartDate.compareTo(qcData.getActStartDT().substring(0,8))<=0) &&(extractEndDate.compareTo(qcData.getActStartDT().substring(0,8))>=0)) 
				qcDataArray.add(qcData);
		}
		
		System.out.println("+--------------------qcDataArray.toString()----------------------+"+qcDataArray.toString());
		
	}


	/*
	 * SR-45 AGD : catch lines with error
	 * Change return type to String in order to return the list of lines with error
	 * Returns null or the lines separated by comma
	 */
//	public void readDataFile(String inFileName, String EMSAssetIDCfgFile)
	public String readDataFile(String inFileName, String EMSAssetIDCfgFile)
		throws MXException, RemoteException, Exception
	{

		mxLog.writeLog(getClass().getName()+".readDataFile()");
		System.out.println("+--------------------inside readDataFile----------------------+");
		String inputText=null;
		String splitText[]=new String[12]; //12 fields in the input file
		int linenum = 0;
		// SR-45 AGD : catch lines with error
		String errorLines = "";

		try{

			File inFile = new File(inFileName);
			if (!inFile.exists()){
				//mxLog.writeLog(getClass().getName()+".readDataFile(): Input file: '"+inFileName+"' not found!");
				throw new Exception(getClass().getName()+".readDataFile(): Input file: '"+inFileName+"' not found!");
			}

			FileReader fReader = new FileReader(inFile);
			BufferedReader bReader = new BufferedReader(fReader);


			EMSAssetIDConversion assetIDConv = new EMSAssetIDConversion(EMSAssetIDCfgFile);

			//QC File Format
			//==============
			//0 = QC_NO
			//1 = VIN
			//2 = QC_OPERATOR
			//3 = QC_START_TIME
			//4 = QC_END_TIME
			//5 = QC_ACTY_CODE
			//6 = MOVE_TYPE
			//7 = NO_OF_20FT
			//8 = NO_OF_40FT
			//9 = DURATION
			//10 = START_DATE
			//11 = END_DATE



			inputText = bReader.readLine();
			System.out.println("+--------------------inputText----------------------+"+inputText);
			if(inputText!=null){
				linenum++;
				splitText= inputText.split(inDelimiter);
				/*
				 * SR-45 : catch lines with error
				 * The next statements do nothing but throws an exception that will be caught if there's a conversion problem
				 * so it's actually used to verify that there's no data corruption
				 */
				try {
					Date dummyDate = OISData.convertDate(splitText[10]);
					dummyDate = OISData.convertDate(splitText[11]);
				}
				catch (Exception e) {
					errorLines = errorLines + ", " + linenum;
					String errormsg = getClass().getName()+".readDataFile(): Error at line "+linenum+" of '"+inFileName+"' - "+inputText+"("+e+")";
					mxLog.writeLog(errormsg);
				}
				extractStartDate= splitText[10];
				extractEndDate= splitText[11].trim();
			}

			while(inputText!=null) {

				QCData qcData= new QCData();

				/*
				 * SR-45 AGD : catch lines with error
				 * If a problem with the line format is found, skip the line (may not work for the 1st line as it's already been split outside the loop)
				 */
				try {
					splitText= inputText.split(inDelimiter);

					//20060823 HCHA - Add Conversion for Location
					String assetID= assetIDConv.getRightAssetId(splitText[0]);
					qcData.setAssetID(assetID);
					/*
					 * SR-45 : catch lines with error
					 * The next statement does nothing but throws an exception that will be caught if there's a conversion problem
					 * so it's actually used to verify that there's no data corruption
					 */
					Date dummyDate = OISData.convertDate(splitText[3]);
					dummyDate = OISData.convertDate(splitText[4]);
					qcData.setActStartDT(splitText[3]);
					qcData.setActEndDT(splitText[4]);
					qcData.setExcluded(isQCEntriesExcluded(splitText[5],splitText[1]));

					int contcount20 = 0;
					int contcount40 = 0;

					try{
						contcount20 = Integer.parseInt(splitText[7]);
					}
					catch(NumberFormatException e){
						contcount20 = 0;
					} 
					try{
						contcount40 = Integer.parseInt(splitText[8]);
					}
					catch(NumberFormatException e){
						contcount40 = 0;
					} 
					qcData.setNumContainer(contcount20 + contcount40);

					int dur = 0;
					try{
						dur = Integer.parseInt(splitText[9]);
					}
					catch(NumberFormatException e){
						dur = 0;
					} 
// Begin modification SR-110
//					qcData.setDuration(dur/60);
					qcData.setDuration(((double) dur)/60.0D);
// End modification SR-110

					addQCDataArray(qcDataArray,qcData);
				}
				catch (Exception e) {
					errorLines = errorLines + ", " + linenum;
					String errormsg = getClass().getName()+".readDataFile(): Error at line "+linenum+" of '"+inFileName+"' - "+inputText+"("+e+")";
					mxLog.writeLog(errormsg);
				}

				inputText = bReader.readLine();
				linenum++;
			}

			bReader.close();
			fReader.close();

			Collections.sort(qcDataArray);

		} 
		catch(IOException e) {
			String errormsg;
			if(inputText!=null){
				errormsg = getClass().getName()+".readDataFile(): I/O Error at line("+linenum+")of '"+inFileName+"' - "+inputText+"("+e+")";
			}
			else{
				errormsg = getClass().getName()+".readDataFile(): I/O Error reading text file '"+inFileName+"'"+"("+e+")";
			}
			//mxLog.writeLog(errormsg);
			throw new Exception(errormsg);
		}
		catch(Exception e) {
			String errormsg;
			if(inputText!=null){
				errormsg = getClass().getName()+".readDataFile(): Error at line("+linenum+")of '"+inFileName+"' - "+inputText+"("+e+")";
			}
			else{
				errormsg = getClass().getName()+".readDataFile(): Error reading text file '"+inFileName+"'"+"("+e+")";
			}
			//mxLog.writeLog(errormsg);
			throw new Exception(errormsg);
		}

		// SR-45 AGD : catch lines with error
		return (errorLines.equals(""))? null : errorLines.substring(2);
	}


	/**
	 * 
	 * @author		HCHA
	 * @date		Mar 2, 2006
	 * @function	[For debug purpose only] 
	 * 				Write file which contain the raw data before calculation
	 * 				(after readDataFile()) 	
	 * @param outFileName
	 */
	public void writeQcDataArrayToFile(String outFileName){

		try{
System.out.println("--inside writeQcDataArrayToFile--");
			File outFile = new File(outFileName);
			FileWriter fWriter = new FileWriter(outFile);
			BufferedWriter bWriter = new BufferedWriter(fWriter);
		
			//Write Header
        	String writeHdr = new String();
        	writeHdr = "AssetID," ;
        	writeHdr += "ActStartDT,ActEndDT,"; 
        	writeHdr +=  "NumContainer," ;
        	writeHdr+= "Duration,"; 
        	writeHdr += "isExcluded\n";
        	bWriter.write(writeHdr);
			
	        for (int j=0; j < qcDataArray.size(); j++) {

	        	QCData temp = (QCData) qcDataArray.get(j);
	        	
	        	String writeline = new String();
	        	writeline = "\n" + temp.getAssetID()+ "," ;
	        	writeline += temp.getActStartDT() + "," + temp.getActEndDT()+ ","; 
	        	writeline +=  String.valueOf(temp.getNumContainer())+"," ;
	        	writeline += String.valueOf(temp.getDuration())+ ","; 
	        	writeline += String.valueOf(temp.isExcluded()) ;
	        	
	            bWriter.write(writeline);
	        }
	
	        bWriter.close();
	        fWriter.close();
		}
		catch(IOException e) {
			mxLog.writeLog ( "OISQuayCrane.writeQcDataArrayToFile():Error writing text file : " + e); 
		}
		
		catch(Exception e) {
			mxLog.writeLog("OISQuayCrane.writeQcDataArrayToFile():Unexpected error writing text file : " + e);
		} 
		
	}


	/**
	 * 
	 * @author		HCHA
	 * @date		Mar 2, 2006
	 * @function	[For debug purpose only] 
	 * 				Write file which contain the data after calculation
	 * 				(after calTotal()) 	
	 * @param outFileName
	 */
	public void writeFinalFile(String outFileName){

		try{
			System.out.println("--inside writeFinalFile--");
			File outFile = new File(outFileName);
			FileWriter fWriter = new FileWriter(outFile);
			BufferedWriter bWriter = new BufferedWriter(fWriter);
			
			//Write Header
        	String writeHdr = new String();
        	writeHdr = "AssetID," ;
        	writeHdr += "ActLastReadingDT," ; 
        	writeHdr +=  "NumContainer," ;
        	writeHdr += "Duration"; 
            bWriter.write(writeHdr);
		
	        for (int j=0; j < qcFinalArray.size(); j++) {

	        	OISData temp = (OISData) qcFinalArray.get(j);
	        	
	        	String writeline = new String();
	        	writeline = "\n" + temp.getAssetID()+ "," ;
	        	writeline += temp.getActLastReadingDT() + "," ; 
	        	writeline +=  String.valueOf(temp.getNumContainer())+"," ;
	        	writeline += String.valueOf(temp.getDuration()); 
	        	
	            bWriter.write(writeline);
	        }
	
	        bWriter.close();
	        fWriter.close();
		}
		catch(IOException e) {
			mxLog.writeLog( "OISQuayCrane.writeFinalFile(): Error writing text file : " + e); 
		}
		
		catch(Exception e) {
			mxLog.writeLog("OISQuayCrane.writeFinalFile(): Unexpected error writing text file : " + e);
		} 
		
	}
	
	
	//Consoliate and calculate total container and duration
	//by per crane per day
	public void calTotal()
		throws MXException, RemoteException, Exception
	{
		System.out.println("--calTotal--");
			mxLog.writeLog(getClass().getName()+".calTotal(): Start Calculation");
			
			Iterator qcIter = qcDataArray.iterator();
			String assetID = new String();
			String actDate = new String();
			String actLastReadDT = new String();
			int numContainer=0;
//	Begin modification SR-110
//			int duration=0;
			double duration = 0;
//	End modification SR-110
			
			MxLocMeter locMeter = new MxLocMeter(userInfo);
			Date mxLastReadingDate=null;
			
			QCData qc=null;

			try{
				while (qcIter.hasNext()) {
					qc = (QCData) qcIter.next();
					System.out.println("+--------------------qc.getAssetID()----------------------+"+qc.getAssetID());
					System.out.println("+--------------------qc.getActStartDT()----------------------+"+qc.getActStartDT());
					//Check if current QC entry has the same AssetID and Date as the previous QC entry
					if((assetID.equals(qc.getAssetID()))&&(actDate.equals(qc.getActStartDT().substring(0,8)))){
						/*
						 * SR-45 AGD : base on start date/time instead of end date/time
						 * Use the start date instead of the end date as it's always the date of the data
						 */
						actLastReadDT = qc.getActStartDT();
						System.out.println("+--------------------actLastReadDT----------------------+"+actLastReadDT);
						//actLastReadDT = qc.getActEndDT();

						//Check if: 
						//1. current entry is not excluded, and
						//2. check if the  current reading is after the last reading in the database
						
						if( (!qc.isExcluded()) && (OISData.convertDate(actLastReadDT).after(mxLastReadingDate)) ){
							numContainer += qc.getNumContainer();
							duration += qc.getDuration();
							
							System.out.println("+--------------------numContainer----------------------+"+numContainer);
							System.out.println("+--------------------duration----------------------+"+duration);
						}
					}
					else{
						if((numContainer!=0) || (duration !=0)){
							//Add reading
							OISData qcFinalData= new OISData(assetID,numContainer,duration,actLastReadDT);
							qcFinalArray.add(qcFinalData);			
						}		
	
						assetID = qc.getAssetID();
						actDate = qc.getActStartDT().substring(0,8);
						
						System.out.println("+--------------------assetID----------------------+"+assetID);
						System.out.println("+--------------------actDate----------------------+"+actDate);
						/*
						 * SR-45 AGD : force the end date to be the date of the data
						 * Use the start date instead of the end date as it's always the date of the data
						 */
						actLastReadDT = qc.getActStartDT();
						System.out.println("+--------------------actLastReadDT----------------------+"+actLastReadDT);
						//actLastReadDT = qc.getActEndDT();
						
						//OPERHOURS should have the date last reading 
						//(due the algo to handling of overlapping days)
						mxLastReadingDate = locMeter.getLastReadingDate(assetID,operHrMeterName);
						System.out.println("+--------------------mxLastReadingDate----------------------+"+mxLastReadingDate);
						
						//No Last Reading in the Database, set it to "null" date.
						if (mxLastReadingDate==null){
							mxLastReadingDate = new GregorianCalendar(1,0,1,0, 0).getTime();
							System.out.println("+--------------------mxLastReadingDate null----------------------+"+mxLastReadingDate);
						}
						
						//Check if: 
						//1. current entry is not excluded, and
						//2. check if the  current reading is after the last reading in the database
						if( (!qc.isExcluded()) && (OISData.convertDate(actLastReadDT).after(mxLastReadingDate)) ){
							numContainer = qc.getNumContainer();
							duration = qc.getDuration();
							System.out.println("+--------------------OISData.convertDate(actLastReadDT).after(mxLastReadingDate)----------------------+");
						}
						else{
							System.out.println("+--------------------OISData.convertDate(actLastReadDT).after(mxLastReadingDate) else----------------------+");
							numContainer=0;
							duration = 0;					
						}
					}
				}
				
				//Write Last reading
				if((numContainer!=0) || (duration !=0)){
					OISData qcFinalData= new OISData(assetID,numContainer,duration,actLastReadDT);
					qcFinalArray.add(qcFinalData);			
				}
				
				System.out.println("+--------------------qcFinalArray----------------------+"+qcFinalArray.toString());
			}
			catch(Exception e){
				String errormsg;
				errormsg = getClass().getName()+".calTotal(): Unexpected Error - Current Processing:" +
						   "\n\tAssetID="+qc.getAssetID()+
						   "\n\tActStartDT="+qc.getActStartDT()+
						   "\n\tActEndDT="+qc.getActEndDT()+
						   "\n\tDuration="+qc.getDuration()+
						   "\n\tNumContainer="+qc.getNumContainer()+
						   "\n("+e+")";			
				//mxLog.writeLog(errormsg);
				throw new Exception(errormsg);
			}
			
			mxLog.writeLog(getClass().getName()+".calTotal(): Calculation Done");

	}


	/**
	 * 
	 * @author		HCHA
	 * @date		Feb 28, 2006
	 * @function	Process the input file and the send the result to Maximo
	 * @param filename
	 * @param extSys
	 * @param intIface
	 * @param intObject
	 * @param isdelta
	 * @param inspector
	 * @throws MXException
	 * @throws RemoteException
	 */
	/*
	 * SR-45 : catch lines with error
	 * Changed the return type to String[] to be able to return also the list of lines with error
	 */
	public String[] processFile(String filename,String extSys, String intIface, String intObject, String isdelta, String inspector, String EMSAssetIDCfgFile)
		throws MXException, RemoteException, Exception
	{
		System.out.println("--inside processFile--of OISQuayCrane--");
		mxLog.writeLog(getClass().getName()+".processFile()");

		// SR-45 AGD : catch lines with error
		String[] returnMsg = { null, null };
		returnMsg[1] = readDataFile(filename, EMSAssetIDCfgFile);
		calTotal();
		System.out.println("+--------------------acter calTotal()----------------------+");
		OISJmsMessage msg = new OISJmsMessage(extSys,intIface);
		System.out.println("+--------------------acter OISJmsMessage()----------------------+");
		MxXmlLocMeter xmlGen = new MxXmlLocMeter(extSys, intIface, intObject, boxMeterName, isdelta, inspector);
		System.out.println("+--------------------acter xmlGen()----------------------+");
		String locNotFound = new String();
		int nbLocNotFound = 0;
		
		OISData curData = null;
		try{
	        for (int j=0; j < qcFinalArray.size(); j++) {
	        	System.out.println("--inside for loop--of OISQuayCrane--qcFinalArray--" + qcFinalArray + "-j-" + j);

	        	
	        	curData = (OISData) qcFinalArray.get(j);
	        	
	        	System.out.println("+--------------------curData.getAssetID()---------------------+"+curData.getAssetID());
	        	
				EMSSite site = new EMSSite(curData.getAssetID(),userInfo);
				
				if(site.getOrgID()!=null && site.getSiteID()!=null){
					
					String xml;

					//Send Container Count Meter Data
					xmlGen.setMetername(boxMeterName);
					xml = xmlGen.genXml(site.getOrgID(),site.getSiteID(),curData.getAssetID(),curData.getActLastReadingDT(),String.valueOf(curData.getNumContainer()));
					msg.sendMessage(xml.getBytes());
					System.out.println("+--------------------msg.sendMessage(xml.getBytes())-------------boxMeterName--------+");
					//Send Operation Hour Meter Data
					xmlGen.setMetername(operHrMeterName);
					xml = xmlGen.genXml(site.getOrgID(),site.getSiteID(),curData.getAssetID(),curData.getActLastReadingDT(),String.valueOf(curData.getDurationHr()));
					msg.sendMessage(xml.getBytes());
					System.out.println("+--------------------msg.sendMessage(xml.getBytes())-------------operHrMeterName--------+");
					//Send Container Count Meter Data (Modifiable Meter)
					xmlGen.setMetername(boxMeterNameM);
					xml = xmlGen.genXml(site.getOrgID(),site.getSiteID(),curData.getAssetID(),curData.getActLastReadingDT(),String.valueOf(curData.getNumContainer()));
					msg.sendMessage(xml.getBytes());
					System.out.println("+--------------------msg.sendMessage(xml.getBytes())-------------boxMeterNameM--------+");
					//Send Operation Hour Meter Data (Modifiable Meter)
					xmlGen.setMetername(operHrMeterNameM);
					xml = xmlGen.genXml(site.getOrgID(),site.getSiteID(),curData.getAssetID(),curData.getActLastReadingDT(),String.valueOf(curData.getDurationHr()));
					msg.sendMessage(xml.getBytes());
					System.out.println("+--------------------msg.sendMessage(xml.getBytes())-------------operHrMeterNameM--------+");
				}
				else{
					nbLocNotFound++;
					locNotFound += curData.getAssetID()+ "\t" + curData.getActLastReadingDT()+ "\t" + String.valueOf(curData.getNumContainer()) + "\t" + String.valueOf(curData.getDurationHr()) + "\n";
				}
	        	
	        }
		}
		catch(Exception e)
		{
			String errormsg;
			errormsg = getClass().getName()+".processFile(): Unexpected Error - Currently Writing to Queue for:" +
					   "\n\tAssetID="+curData.getAssetID()+
					   "\n("+e+")";			
			//mxLog.writeLog(errormsg);
			throw new Exception(errormsg);
		}

		if(nbLocNotFound!=0){
        	mxLog.writeLog(getClass().getName()+".processFile(): "+nbLocNotFound+" Locations not found in the database!");
        	String title =
        		"[OIS Quay Crane]\n"+
        		"Date: "+ new Date()+"\n" +
        		"List of locations not found in the database:\n"+
        		"LocationID"+"\t"+"Last Reading"+"\t"+"Container Count"+"\t"+"Running Hrs"+"\n";
        	String locNotFoundErrMsg = title + locNotFound;

        	// SR-45 AGD : catch lines with error
        	returnMsg[0] = locNotFoundErrMsg;
        	//return locNotFoundErrMsg;
		}

		//	 SR-45 AGD : catch lines with error
		return returnMsg;
		//return null;

	}


	public String getInDelimiter() {
		return inDelimiter;
	}


	public void setInDelimiter(String inDelimiter) {
		this.inDelimiter = inDelimiter;
	}


	public String getQcExclFileName() {
		return qcExclFileName;
	}


	public void setQcExclFileName(String qcExclFileName) {
		this.qcExclFileName = qcExclFileName;
	}


	public boolean isVsl_vin_i() {
		return vsl_vin_i;
	}


	public void setVsl_vin_i(boolean vsl_vin_i) {
		this.vsl_vin_i = vsl_vin_i;
	}

	public String getBoxMeterName() {
		return boxMeterName;
	}

	public void setBoxMeterName(String boxMeterName) {
		this.boxMeterName = boxMeterName;
	}

	public String getOperHrMeterName() {
		return operHrMeterName;
	}

	public void setOperHrMeterName(String operHrMeterName) {
		this.operHrMeterName = operHrMeterName;
	}
	
	/*
	 * Clears Calculation Results stored in finalDataArray
	 */
	public void clearResult()
	{
		qcDataArray.clear();
		qcFinalArray.clear();
	}
}
