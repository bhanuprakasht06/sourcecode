/**
 * @author	HCHA
 * Date		Mar 2, 2006
 * Comment	Cron Task for Other Equipment Container Count
 * Modifications :
 * 	28-04-2025	MAS UPG :	Change in processing logic based on WebService file
 */
package com.psa.custom.ois;

import java.io.IOException;
import java.rmi.RemoteException;


import psdi.app.system.CrontaskParamInfo;

import psdi.util.MXException;

/**
 * @author		HCHA
 * @class		OthEquipCCCronTask
 * @date		Mar 2, 2006
 * @function	Cron Task for Other Equipment Container Count
 */
public class PSA_OthEquipCC_Custom extends OISCronTask 
{

	private static String isdelta = "Y"; //Set reading type as delta
	//private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
	private static String locNotFoundEmailSubj = "[EMS-OIS]Warning: Locations Not Found."; //Email Subject for Location not found
	private static String finalExt = ".final"; //File extension for final calculation
	// SR-45 AGD : catch lines with error
	private static String linesWithErrorEmailSubj = "[EMS-OIS]Warning: Lines with errors";	// Email Subject for lines with error

   private String contCntMeter;	//Name of the container count meter
   private String contCntMeterM;	//Name of the container count meter
   private String equipInclFile;
	private String sortCmd;
	private String sortOpOpt;
    
	
	public PSA_OthEquipCC_Custom() {
		super();
		contCntMeter=null;
		contCntMeterM=null;
		equipInclFile=null;
		sortCmd=null;
		sortOpOpt=null;

	}
	/* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function] Get the parameter from Cron Task.  
     */
	public CrontaskParamInfo[] getParameters() 
    	throws MXException, RemoteException 
    {
    	return params;
	}
	
	
	/* Author: HCHA
     * Date: 28 FEB 2006
     * Comment: Refresh Cron Task setting.  
     */
   protected void refreshSettings()
    {
    	
    	super.refreshSettings();
    	
        try {
        	
            contCntMeter = getParamAsString("CONTCNTMETER");
            contCntMeterM = getParamAsString("CONTCNTMETERM");
            equipInclFile = getParamAsString("EQUIPINCLFILENAME");
            
        	sortCmd = getParamAsString("SORTCMD");
        	sortOpOpt = getParamAsString("SORTOUTPUTOPT");
                        
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }


    /* Author: HCHA
     * Date: 28 FEB 2006
     * Comment: returns true if all required parameter is set
     */
    protected boolean isReqParamSet()
    {
        
        if(adminEmail==null) return false;
        if(contCntMeter==null) return false;
        if(contCntMeterM==null) return false;
        if(intIface==null) return false;
        if(intObject==null) return false;
        if(extSys==null) return false;
        if(scpConfigFile==null) return false;
        if(remoteFilePath==null) return false;
        if(remoteServer==null) return false;        
        
    	return true;
    }


    /* Author: HCHA
     * Date: 28 FEB 2006
     * Comment: Process the import flat file   
     */
	protected void parseFlatFile(String file)
		throws MXException, RemoteException, IOException, InterruptedException, Exception
	{
		mxLog.writeLog(getName()+".parseFlatFile(): Parsing "+file);

		String locNotFoundErrMsg = null;
		// SR-45 AGD : catch lines with error
		String[] returnMsg;
		String errorLines = null;

		PSA_OISOthEquipCC psa_othEquip = new PSA_OISOthEquipCC(equipInclFile,getRunasUserInfo(),contCntMeter, contCntMeterM, sortCmd, sortOpOpt, mxLog);		
		// SR-45 : Changed method return type
		returnMsg = psa_othEquip.processFile(file,extSys,intIface,intObject,isdelta,inspector, EMSAssetIDCfgFile);
		locNotFoundErrMsg = returnMsg[0];
		errorLines = returnMsg[1];
		//locNotFoundErrMsg = othEquip.processFile(file,extSys,intIface,intObject,isdelta,inspector, EMSAssetIDCfgFile);

		if(locNotFoundErrMsg!=null){
            email.send(locNotFoundEmailSubj, locNotFoundErrMsg); 
            mxLog.writeLog("Email Sent:\n"+ locNotFoundErrMsg);
		}

		// SR-45 : Send an email if some lines have error
		if (errorLines != null) {
			errorLines = "Error in file " + file + " for the following lines:\n" + errorLines;
			email.send(linesWithErrorEmailSubj, errorLines);
         mxLog.writeLog("Email Sent:\n" + errorLines);
		}

		if(enableLog){
			//Write final calcution into a flat file
			psa_othEquip.writeFinalArrayToFile(file+finalExt);
		}

		psa_othEquip.clearResult();
	}


	//CronTask Parameters
	protected static CrontaskParamInfo params[];
    static 
    {
    	// BTE: Set the number of the parameter.  
        params = null;
        params = new CrontaskParamInfo[22];
        
        // BTE: All the parameter configurable from Cron Task user interface 

        
        params[0] = new CrontaskParamInfo();
        params[0].setName("ALERTEMAILSUBJ");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[0].setDescription("Email Subject for the Alert Email.");
        params[0].setDescription("CommonCron","EmailSubject");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[1] = new CrontaskParamInfo();
        params[1].setName("EXTSYSNAME");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[1].setDescription("External System Name.");
        params[1].setDescription("CommonCron","ExternalSystem");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[1].setDefault("OISGW");
        
        params[2] = new CrontaskParamInfo();
        params[2].setName("INTERFACE");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[2].setDescription("Location Integration Interface Name.");
        params[2].setDescription("CommonCron","LocIntInterfaceName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[2].setDefault("MXOISInterface");
        
        params[3] = new CrontaskParamInfo();
        params[3].setName("INTOBJECT");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[3].setDescription("Integration Object Name.");
        params[3].setDescription("CommonCron","IntegrationObjectName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[3].setDefault("MXLOCMETER");
        
        params[4] = new CrontaskParamInfo();
        params[4].setName("LOCALDIRECTORY");        
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[4].setDescription("Local directory to transfer the flat file to.");
        params[4].setDescription("CommonCron","LocalDirectoryToTransferTo");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[5] = new CrontaskParamInfo();
        params[5].setName("SCPCONFIGFILE");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[5].setDescription("SCP Config File.");
        params[5].setDescription("CommonCron","SCPConfigFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[6] = new CrontaskParamInfo();
        params[6].setName("ALERTEMAIL");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[6].setDescription("Admin email address for notification of error.");
        params[6].setDescription("CommonCron","Adminemailaddress");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[7] = new CrontaskParamInfo();
        params[7].setName("UNZIPEXEC");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[7].setDescription("Executable for unziping the input flat file.");
        params[7].setDescription("CommonCron","ExecutableUnziping");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[7].setDefault("gunzip -f -q");
        
        params[8] = new CrontaskParamInfo();
        params[8].setName("REMOTEFILEPATH");
       //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[8].setDescription("Remote Path of the input flat file.");
        params[8].setDescription("CommonCron","RemotePathFlatFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[9] = new CrontaskParamInfo();
        params[9].setName("REMOTESERVER");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[9].setDescription("Remote server name.");
        params[9].setDescription("CommonCron","RemoteServerName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
         
        params[10] = new CrontaskParamInfo();        
        params[10].setName("CONTCNTMETER");        
        params[10].setDefault("CONTCOUNT");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[10].setDescription("Container Count Meter Name(Read-Only Meter).");
        params[10].setDescription("CommonCron","CountMeterReadOnly");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
    
        params[11] = new CrontaskParamInfo();
        params[11].setName("EQUIPINCLFILENAME");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[11].setDescription("Path and filename for list of code of equipment required.");
        params[11].setDescription("CommonCron","PathAndFilename");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[12] = new CrontaskParamInfo();
        params[12].setName("ENABLELOG");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[12].setDescription("Enable log output('Y' or 'N').");
        params[12].setDescription("CommonCron","EnableLog");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[12].setDefault("Y");
        
        
        params[13] = new CrontaskParamInfo();
        params[13].setName("IMPBASEFILENAME");        
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[13].setDescription("Base file name of the input flat file.(End with 'yyyymmdd' for current day file.)");
        params[13].setDescription("CommonCron","BaseFileName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[14] = new CrontaskParamInfo();
        params[14].setName("IMPFILEEXT");        
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[14].setDescription("Extension of the input flat file package.");
        params[14].setDescription("CommonCron","impfileext");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[14].setDefault(".gz");

        params[15] = new CrontaskParamInfo();
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[15].setDescription("Meter Reading Inspector.");
		params[15].setName("INSPECTOR");
        params[15].setDescription("CommonCron","inspector");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[15].setDefault("MXINTADMIN");
        
        params[16] = new CrontaskParamInfo();
        params[16].setName("SORTCMD");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[16].setDescription("Sort Command for sorting contend in file.");
        params[16].setDescription("CommonCron","sortcmd");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[16].setDefault("sort");
        
        params[17] = new CrontaskParamInfo();
        params[17].setName("SORTOUTPUTOPT");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[17].setDescription("Sort Command output option.");
        params[17].setDescription("CommonCron","sortoutputopt");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[17].setDefault("-o");
        
        params[18] = new CrontaskParamInfo();
        params[18].setName("PROCESSDIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[18].setDescription("Directory where processing will be done.");
        params[18].setDescription("CommonCron","processdirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[19] = new CrontaskParamInfo();        
        params[19].setName("CONTCNTMETERM");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[19].setDescription("Container Count Meter Name(Meter Reading Modifiable by User).");
        params[19].setDescription("CommonCron","contcntmeterm");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[19].setDefault("ACONTCOUNT");
        
        params[20] = new CrontaskParamInfo();
        params[20].setName("LOGDIRECTORY");        
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[20].setDescription("Log Directory.");
        params[20].setDescription("CommonCron","logdir");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[21] = new CrontaskParamInfo();
        params[21].setName("EMSASSETIDCFGFILE");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[21].setDescription("Config Filename for Location Conversion.");
        params[21].setDescription("CommonCron","emsassetidcfgfile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        

    }
}
