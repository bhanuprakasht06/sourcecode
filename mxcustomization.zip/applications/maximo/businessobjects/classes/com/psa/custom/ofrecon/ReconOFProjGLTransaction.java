/*
 * Created  by BCT 
 * 
 *  
 * This cron is used for  Reconciling check between OF GL transaction and Maximo
 * Maximo will receive the Flat file from Del Bomi and put into Location
 * The flat file first file contains all the Maximo objects
 * Flat file from the second contains the data
 * The flat file second line first compontent contians the object:attrbuteID (LABTRANS:12345)
 * Based on the Object and AttributeID, need to check in Maximo
 * if data is present need to check the cost(LOADEDCOST). 
 * If the value is matching, update the the following fields OA_RECONDATETIME,OA_COA,OA_LINECOST
 * if data is not present then send error message
 * 
 */
package com.psa.custom.ofrecon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.mail.MessagingException;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;
import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class ReconOFProjGLTransaction extends SimpleCronTask {
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	private static final String DATE_TIME_FORMAT = "yyyyMMdd";


	private String adminEmail;
	private String adminEmailSub;
	private String outPutDirectory;
	private String tempProcessFolder;
	private String processFolder;
	private String backupFileFolder;
	private String importFileName;
	private String splitTag;
	private String unzipCmd;
	private MxEmail email;
	protected MxLog mxLog;
	protected MxLog withOutIdLog;
	private String logFileName;
	private String logFilePath;
	private String withOutIdLogName;
	private String withOutIdLogPath;
	private boolean enableLog;
	private File fileDirctory;
	private String transId;
	private ArrayList parsdata;



	public ReconOFProjGLTransaction() {
		adminEmail=null;
		adminEmailSub=null;
		outPutDirectory=null;
		tempProcessFolder=null;
		processFolder=null;
		backupFileFolder=null;
		importFileName=null;
		unzipCmd=null;
		email=null;
		mxLog=new MxLog();
		withOutIdLog=new MxLog();
		logFileName=null;
		logFilePath=null;
		withOutIdLogName=null;
		withOutIdLogPath=null;
		fileDirctory=null;
		enableLog=false;

	}


	public CrontaskParamInfo[] getParameters() throws MXException,
	RemoteException {

		CrontaskParamInfo[] params = new CrontaskParamInfo[12];

		params[0] = new CrontaskParamInfo();
		params[0].setName("ADMINEMAIL");
		params[0].setDescription("ADMINEMAIL", "Administrator Email ID");

		params[1] = new CrontaskParamInfo();
		params[1].setName("ADMINEMAILSUB");
		params[1].setDescription("ADMINEMAILSUB", "Administrator Email Subject");


		params[2] = new CrontaskParamInfo();
		params[2].setName("TEMPPROCESSFOLDER");
		params[2].setDescription("TEMPPROCESSFOLDER", " Temp Process folder file path");

		params[3] = new CrontaskParamInfo();
		params[3].setName("PROCESSFOLDER");
		params[3].setDescription("PROCESSFOLDER", "Process folder file path");

		params[4] = new CrontaskParamInfo();
		params[4].setName("BACKUPFILEFOLDER");
		params[4].setDescription("BACKUPFILEFOLDER", "Back Up file folder path");

		params[5] = new CrontaskParamInfo();
		params[5].setName("FILENAME");
		params[5].setDescription("FILENAME", "Processing file name");

		params[6] = new CrontaskParamInfo();
		params[6].setName("SPLITTAG");
		params[6].setDescription("SPLITTAG", "SPLITTAG");

		params[7] = new CrontaskParamInfo();
		params[7].setName("UNZIPCMD");
		params[7].setDescription("UNZIPCMD", "Unzip file command");

		params[8] = new CrontaskParamInfo();
		params[8].setName("LOGFILENAME");
		params[8].setDescription("LOGFILENAME", "Log File Name");

		params[9] = new CrontaskParamInfo();
		params[9].setName("LOGFILEPATH");
		params[9].setDescription("LOGFILEPATH", "Log File Path");

		params[10] = new CrontaskParamInfo();
		params[10].setName("ENABLELOG");
		params[10].setDescription("CommonCron","Enable log output('Y' or 'N').");
		params[10].setDefault("Y");

		params[11] = new CrontaskParamInfo();
		params[11].setName("WITHOUTIDLOGFILENAME");
		params[11].setDescription("WITHOUTIDLOGFILENAME", "Log File Path For Data Without Id");

		return params;
	}



	private void refreshSettings() throws RemoteException, MXException
	{
		try
		{
			adminEmail=getParamAsString("ADMINEMAIL");
			adminEmailSub=getParamAsString("ADMINEMAILSUB");
			tempProcessFolder=getParamAsString("TEMPPROCESSFOLDER");

			processFolder=getParamAsString("PROCESSFOLDER");
			fileDirctory=new File(processFolder);

			backupFileFolder=getParamAsString("BACKUPFILEFOLDER");
			//	importFileName=getParamAsString("FILENAME");

			DateFormat fileDateFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
			String todayDate=fileDateFormat.format(new Date());
			//importFileName = getParamAsString("FILENAME");
			//importFileName=importFileName.replaceAll("yyyyMMdd",todayDate);
			
			// Modify to replace with by previous day's if "yyyymmpd" is specified in import file base name
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH,-1);
            String prevDate = fileDateFormat.format(cal.getTime());
            importFileName = getParamAsString("FILENAME").replaceAll("yyyymmpd", prevDate);
			
			splitTag=getParamAsString("SPLITTAG");
			unzipCmd=getParamAsString("UNZIPCMD");
			logFileName=getParamAsString("LOGFILENAME");
			logFilePath=getParamAsString("LOGFILEPATH");
			enableLog=(getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
			withOutIdLogName=getParamAsString("WITHOUTIDLOGFILENAME");
			withOutIdLogPath=getParamAsString("LOGFILEPATH");

			Date curDate = new Date();
			DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
			String logFileDate = fileDateTimeFormat.format(curDate);
			logFileName = logFileName.replaceAll("yyyyMMdd",logFileDate);
			logFilePath =logFilePath+logFileName;
			withOutIdLogPath=withOutIdLogPath+withOutIdLogName;
			mxLog.setLogFilePath(logFilePath);
			mxLog.setLogTag(getName());
			mxLog.setEnabled(enableLog);
			mxLog.createLogFile();
			withOutIdLog.setLogFilePath(withOutIdLogPath);
			withOutIdLog.setLogTag(getName());
			withOutIdLog.setEnabled(enableLog);
			withOutIdLog.createLogFile();

		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}


	}

	private boolean isReqParamSet() {
		if (adminEmail.equalsIgnoreCase(""))
			return false;
		if (adminEmailSub.equalsIgnoreCase(""))
			return false;

		if (tempProcessFolder.equalsIgnoreCase(""))
			return false;
		if (processFolder.equalsIgnoreCase(""))
			return false;
		if (backupFileFolder.equalsIgnoreCase(""))
			return false;
		if (importFileName.equalsIgnoreCase(""))
			return false;
		if (splitTag.equalsIgnoreCase(""))
			return false;
		if (unzipCmd.equalsIgnoreCase(""))
			return false;
		if (logFileName.equalsIgnoreCase(""))
			return false;
		if (logFilePath.equalsIgnoreCase(""))
			return false;
		if (withOutIdLogName.equalsIgnoreCase(""))
			return false;

		return true;
	}
	public void init() throws MXException {
		super.init();

		email = new MxEmail(adminEmail);
		mxLog = new MxLog();

	}

	private String genEmail(Exception e) {

		// Form Email Message
		String emailMsg = "Date: " + new Date() + "\n";
		emailMsg += "Error in CronTask: " + getName() + "\n";
		emailMsg += "Error Message: " + e.getMessage() + "\n";
		emailMsg += "Detail:\n";
		emailMsg += e.toString() + "\n";
		StackTraceElement element[] = e.getStackTrace();
		for (int i = 0; i < element.length; i++) {
			emailMsg += "\tat " + element[i].toString() + "\n";
		}

		return emailMsg;
	}

	public void cronAction() {

		try
		{
			refreshSettings();
			if(isReqParamSet())
				//System.out.println();
			{
				String fileRead=tempProcessFolder+importFileName;
				int dotPos = fileRead.lastIndexOf(".");
				String actualFile=fileRead.substring(0,dotPos);

				if(checkFileExist(importFileName))
				{
					//MxFileCopy.fileCopy(processFolder+importFileName,tempProcessFolder+importFileName);

					//WMJ: do backup of file before processing
					MxFileCopy.fileCopy(processFolder+importFileName,backupFileFolder+importFileName);
					//WMJ: end backup of file before processing

					


					if(unZipFileTemp())

					{
						processFolderData(actualFile);
						File processedFile = new File(actualFile);
						processedFile.delete(); 
						mxLog.writeLog("Cron:"+getName()+":File process is completed.");
					}
					File deleteZipProcessed = new File(processFolder+importFileName);
					deleteZipProcessed.delete();

				}
				else
				{
					integrationLogger.debug("File does not found. cron job is Stopped.");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			genEmail(e);
		}

	}

	public boolean checkFileExist (String importFileName) throws MessagingException {

		SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);

		File checkFile[] = fileDirctory.listFiles(filter);

		String currentFileName=importFileName.substring(0,36);

		if(checkFile!=null)
		{
			for (int j = 0; j < checkFile.length; j++) 
			{
				if(checkFile[j].getName().startsWith(currentFileName)){
					integrationLogger.debug("File exists process the file data.");
					return true;
				}
			}


		}
		integrationLogger.debug("File does not exists.");
		mxLog.writeLog("File not found in Processing Folder");
		MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,"File not found in Processing Folder");
		return false;
	}

	private boolean unZipFileTemp() throws Exception
	{
		boolean fileUNZipCompleted=true;
		try{
			//String zipoutputFilePath = tempProcessFolder+importFileName;
			//String cmd = unzipCmd + " " + zipoutputFilePath;
			String pglFileName=importFileName;
			int dotIndex = pglFileName.lastIndexOf('.');
			
        	if (dotIndex > 0) {
        		pglFileName = pglFileName.substring(0, dotIndex);
        		mxLog.writeLog("Text file name: "+pglFileName);
        	}
			String sourcePath=processFolder+importFileName;
			String destPath=tempProcessFolder+pglFileName;
			
			mxLog.writeLog("Source path: "+sourcePath);
			mxLog.writeLog("Destination path: "+destPath);
			
			String cmd = unzipCmd + " " + sourcePath + " " + destPath;
			int retcode= MxZip.unzipFile(cmd);
			
			mxLog.writeLog("Cmd: "+cmd);
			mxLog.writeLog("Return code: "+retcode);
			if (retcode != 0){
				fileUNZipCompleted=false;
			}


		}
		catch(Exception e)
		{
			mxLog.writeLog("File Unzip is failed:"+getName()+":"+e.getMessage());
		}
		return fileUNZipCompleted;

	}

	public void processFolderData(String actualFile) throws MXException,Exception {

		try {
			String errorMessage="";
			BufferedReader  flatfileReader = new BufferedReader(new FileReader(actualFile));
			String currentLine;
			ArrayList<String> headerList=new ArrayList<String>();
			ArrayList<String> lineList=new ArrayList<String>();

			while((currentLine=flatfileReader.readLine())!=null)
			{
				try{
					if(!(currentLine.equals("")))
					{
						String recHeadertype = currentLine.substring(0, 1);
						if(recHeadertype.equals("0"))
						{
							headerList.add(currentLine);
						}
						if(recHeadertype.equals("1"))
						{
							lineList.add(currentLine);
						}
					}
				}
				catch (Exception e) {
					mxLog.writeLog("Error on while Processing the folder data:"+getName()+":"+e.getMessage());
				}
			}

			for(int i=0;i<headerList.size();i++)
			{
				int totalRecordsHeaderLevel=0;
				int totalRecordsLineLevel=0;

				BigDecimal totalAmountHeaderLevel=new BigDecimal("0.00");
				BigDecimal totalAmountLineLevel=new BigDecimal("0.00");

				String headerData=headerList.get(i);
				String[] headerValues=headerData.split(splitTag);
				String headerCurrency=headerValues[2];
				if(!(headerValues[3].equals("")))
				{
					totalRecordsHeaderLevel=Integer.parseInt(headerValues[3]);
				}
				if(!(headerValues[4].equals("")))
				{
					totalAmountHeaderLevel=new BigDecimal(headerValues[4]);
				}


				for(int j=0;j<lineList.size();j++)
				{
					int size=lineList.size();

					String lineData=lineList.get(j);
					String[] lineValues=lineData.split(splitTag);
					if(headerCurrency.equals(lineValues[6]))
					{
						if(!(lineValues[9].equals("")))
						{
							totalAmountLineLevel=totalAmountLineLevel.add(new BigDecimal(lineValues[9]));
						}
						totalRecordsLineLevel++;
					}	
				}

				if(totalRecordsHeaderLevel!=totalRecordsLineLevel)
				{
					errorMessage=errorMessage+"\n Mismatch on total number of records between header and line for "+headerCurrency+" currency. \n";
				}
				if(totalAmountHeaderLevel.compareTo(totalAmountLineLevel) != 0)
				{
					errorMessage=errorMessage+"\n Mismatch on total amount between header and line for "+headerCurrency+" currency. \n";
				}

			}

			if (errorMessage.length()>0)
			{
				flatfileReader.close();
				String fileRead=backupFileFolder+importFileName;
				int dotPos = fileRead.lastIndexOf(".");
				String backupfile=fileRead.substring(0,dotPos);
				File deleteProcessedFile = new File(actualFile);
				deleteProcessedFile.delete();
				mxLog.writeLog(errorMessage);
				MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessage+" \nPlease check the Backup folder and process again."+backupfile);
			}
			else			
			{
				Collection fileData=extractFileRead(actualFile);
				processOFTransData(fileData);
				fileData.clear();
				flatfileReader.close();
			}
		}



		catch(Exception e)
		{
			mxLog.writeLog("Error on while Processing the folder data:"+getName()+":"+e.getMessage());
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,"Error on while Processing the folder data:"+getName()+":"+e.getMessage());
		}

	}

	private void processOFTransData(Collection processdata) throws MXException,RemoteException,ParseException, MessagingException
	{
		String[] errorMessages={"","","","","","",""};
		/*
		 * The different fields present in parsdata
		 *  parsdata.get(0) SOURCE
		 *	parsdata.get(1) oa_recondatetime
		 *	parsdata.get(2) oa_linecost
		 *	parsdata.get(3) OA_PROJECTID
		 *	parsdata.get(4) OA_TASKID
		 *	parsdata.get(5) OA-EXPTYPE
		 *	parsdata.get(6) OA_EXPORG
		 *	parsdata.get(7) OA_PERIOD		 *	
		 *	parsdata.get(8) OA_DEBITACCT
		 *	parsdata.get(9) OA_CREDITACC
		 * 	parsdata.get(10) OA_TRANSDATE
		 *	parsdata.get(11) OA_CATEGORY
		 *	parsdata.get(12) OA_SOURCE
		 *	parsdata.get(13) OA_JNAME
		 *	parsdata.get(14) OA_HEADER
		 * The Differnet Flags Present
		 * OA_RECON_AMT -->Verification between Maximo and OF for Line Cost
		 * OA_PROJECTID -->Verification between Maximo and OF for ProjectID
		 * OA_TASKID -->Verification between Maximo and OF for TaskID
		 * OA_EXPTYPE -->Verification between Maximo and OF for Expenditure Type
		 * The Different Error Message
		 * Error [2]: Cost Mismatch for the  Transaction:
		 * Error [3]: Project ID Mismatch for the  Transaction:
		 * Error [4]: Task ID Mismatch for the  Transaction:
		 * Error [5]: Expenditure Type Mismatch for the Labor Transaction
		 * 
		 */


		Iterator processOFReconData=processdata.iterator();
		String OfaMessage;
		Date reconDate;
		String transidAndMbo;
		String reconcile;
		String objectName = null;
		//String transId = null;
		// Create two Flags for Cost and COA
		boolean OA_RECON_AMT;
		boolean OA_PROJECTID;
		boolean OA_TASKID;
		boolean OA_EXPTYPE;
		List<String> transIDList=new ArrayList<String>();
		Set<String> reconSet=new LinkedHashSet<String>();
		while(processOFReconData.hasNext())
		{
			try{
				parsdata=(ArrayList) processOFReconData.next();
				OA_RECON_AMT = false;
				OA_PROJECTID = false;
				OA_TASKID = false;
				OA_EXPTYPE= false;
				//if(((String)parsdata.get(0)).equals("1"))
				if(((String)parsdata.get(0)).contains("TRANS"))
				{
					double oa_linecost=0.0;
					String of_projectID="";
					String of_taskID="";
					String of_expType="";
					String oa_exporg="";
					String oa_period="";
					String oa_transdate_of="";
					String oa_debitacct="";
					String oa_creditacc="";
					String oa_category="";
					String oa_source="";
					String oa_jname="";
					String oa_header="";
					Date transDate_OF;
					Date oa_transdate = null ;
					
					reconcile=(String) parsdata.get(2);
					if(!(reconcile.equals("")))
					{
						oa_linecost=Double.parseDouble(reconcile);
					}
					transidAndMbo=(String) parsdata.get(0);
					String[] getactualMbo=transidAndMbo.split(":");
					reconDate=MXServer.getMXServer().getDate();

					// To get the Line cost from the OF system
					//String oa_linecost=(String) parsdata.get(3);

					// To get the Line cost from the OF system
					of_projectID=(String) parsdata.get(3);
					of_taskID=(String) parsdata.get(4);
					of_expType=(String) parsdata.get(5);
					
					oa_exporg=(String) parsdata.get(6);
					oa_period=(String) parsdata.get(7);
					
					oa_transdate_of=(String) parsdata.get(10);
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					if(!(oa_transdate_of.equals("")))
					{
						oa_transdate = formatter.parse(oa_transdate_of);

					}
					
					oa_debitacct=(String) parsdata.get(8);
					oa_creditacc=(String) parsdata.get(9);
					oa_category=(String) parsdata.get(11);
					oa_source=(String) parsdata.get(12);
					oa_jname=(String) parsdata.get(13);
					oa_header=(String) parsdata.get(14);
					//OPS SGD line cost
					//String opslinecost=(String) parsdata.get(10);

					if(getactualMbo!=null && !transidAndMbo.equalsIgnoreCase(""))
					{
						objectName=getactualMbo[0].trim();
						transId=getactualMbo[1].trim();

						if (!objectName.equalsIgnoreCase("")&& !transId.equalsIgnoreCase(""))
						{

							if(objectName.equalsIgnoreCase("LABTRANS") && !transId.equalsIgnoreCase("") )
							{

								MboSetRemote getLabTransSet=MXServer.getMXServer().getMboSet("LABTRANS",getRunasUserInfo());
								SqlFormat labTransSql=new SqlFormat("LABTRANSID='"+transId+"'");
								getLabTransSet.setWhere(labTransSql.format());
								getLabTransSet.reset();
								if(!getLabTransSet.isEmpty() & getLabTransSet!=null)
								{
									MboRemote labTransMbo=getLabTransSet.getMbo(0);
									if(labTransMbo!= null) 
									{
										double loadedCost=labTransMbo.getDouble("LINECOST");
										String fcProjectid=labTransMbo.getString("FCPROJECTID");
										String fcTaskid=labTransMbo.getString("FCTASKID");
										String exptype=labTransMbo.getString("WORKORDER.WORKTYPE.WTYPEDESC");


										// To check if the OF Cost and Maximo Cost are matching
										// If they are equal set the flag to true
										if(oa_linecost ==loadedCost)
										{
											OA_RECON_AMT = true;

										}
										else
										{
											OA_RECON_AMT = false;
											errorMessages[2]=errorMessages[2]+parsdata+"\n";
											mxLog.writeLog("Cost Mismatch for the Labor Transaction:"+parsdata);
										}
										// To check if the ProjectID from OF and Maximo are same
										// If they are same, then set the flag as True
										if (!fcProjectid.equalsIgnoreCase("") && fcProjectid.equalsIgnoreCase(of_projectID))
										{
											OA_PROJECTID = true;
										}
										else
										{
											OA_PROJECTID = false;
											errorMessages[3]=errorMessages[3]+parsdata+"\n";
											mxLog.writeLog("Project ID  Mismatch for the Labor Transaction:"+parsdata);
										}

										// To check if the TaskID from OF and Maximo are same
										// If they are same, then set the flag as True
										if (!fcTaskid.equalsIgnoreCase("") && fcTaskid.equalsIgnoreCase(of_taskID))
										{
											OA_TASKID = true;
										}
										else
										{
											OA_TASKID = false;
											errorMessages[4]=errorMessages[4]+parsdata+"\n";
											mxLog.writeLog("Task ID Mismatch for the  Transaction:"+parsdata);
										}


										//  To check if the ExpenType from OF and Maximo are same
										if (!exptype.equalsIgnoreCase("") && exptype.equalsIgnoreCase(of_expType)) 
										{
											OA_EXPTYPE = true;
										} 
										else 
										{
											OA_EXPTYPE = false;
											errorMessages[5]=errorMessages[5]+parsdata+"\n";
											mxLog.writeLog("Expenditure Type Mismatch for the Labor Transaction"+parsdata);
										}


										if (OA_RECON_AMT == true && OA_PROJECTID == true && OA_TASKID ==true && OA_EXPTYPE==true)
										{
											labTransMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_PROJECTID",of_projectID,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_LINECOST",oa_linecost,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_TASKID",of_taskID,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_EXPTYPE_REC",of_expType,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_EXPORG",oa_exporg,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_PERIOD",oa_period,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_TRANSDATE",oa_transdate,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_DEBITACCT",oa_debitacct,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_CREDITACC",oa_creditacc,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_CATEGORY",oa_category,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_SOURCE",oa_source,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_JNAME",oa_jname,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_HEADER",oa_header,MboConstants.NOACCESSCHECK);
											labTransMbo.setValue("OA_FLAGREC",true,MboConstants.NOACCESSCHECK);
											
											getLabTransSet.save();
											// After creating the Labtrans fields, uncomment the above code
											System.out.println("Update the Labtrans fields");
										}



									}

								}
								else
								{
									errorMessages[1]=errorMessages[1]+"Invalid Transaction ID's Found for these records:\n\n"+parsdata;
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}

							}

//							else if(objectName.trim().equalsIgnoreCase("INVTRANS") & !transId.trim().equalsIgnoreCase(""))
//							{
//								MboSetRemote getInvTransTransSet=MXServer.getMXServer().getMboSet("INVTRANS",getRunasUserInfo());
//								SqlFormat invTransTransSql=new SqlFormat("INVTRANSID='"+transId+"'");
//								getInvTransTransSet.setWhere(invTransTransSql.format());
//								getInvTransTransSet.reset();
//								if(!getInvTransTransSet.isEmpty() & getInvTransTransSet!=null)
//								{
//
//									MboRemote invTransMbo=getInvTransTransSet.getMbo(0);
//									if(invTransMbo!= null)
//									{
//										double loadedCost=invTransMbo.getDouble("LINECOST");
//										String projectID=invTransMbo.getString("PROJECTID");
//										String taskID=invTransMbo.getString("TASKID");
//										String exptype=invTransMbo.getString("WORKORDER.WORKTYPE.WTYPEDESC");
//										if(reconcileAmt ==loadedCost)
//										{
//											OA_RECON_AMT = true;
//
//										}
//										else
//										{
//											OA_RECON_AMT = false;
//											errorMessages[2]=errorMessages[2] + "Cost Mismatch for the Inventory Transaction:\n"+parsdata+"\n";
//											mxLog.writeLog("Cost Mismatch for the Inventory Transaction:"+parsdata);
//										}
//										// To check if the COA from OF and Maximo are same
//										// If they are same, then set the flag as True
//										if (!projectID.equalsIgnoreCase("") && projectID.equalsIgnoreCase(of_projectID))
//										{
//											OA_PROJECTID = true;
//										}
//										else
//										{
//											OA_PROJECTID = false;
//											errorMessages[3]=errorMessages[3]+"Project ID Mismatch for the Inventory Transaction:\n\n"+parsdata+"\n";
//											mxLog.writeLog("Project ID Mismatch for the Labor Transaction:"+parsdata);
//										}
//
//										// To check if the TaskID from OF and Maximo are same
//										// If they are same, then set the flag as True
//										if (!taskID.equalsIgnoreCase("") && taskID.equalsIgnoreCase(of_taskID))
//										{
//											OA_TASKID = true;
//										}
//										else
//										{
//											OA_TASKID = false;
//											errorMessages[4]=errorMessages[4]+"Task ID Mismatch for the Inventory Transaction:\n\n"+parsdata+"\n";
//											mxLog.writeLog("Task ID Mismatch for the Labor Transaction:"+parsdata);
//										}
//
//
//										//  To check if the ExpenType from OF and Maximo are same
//										if (!exptype.equalsIgnoreCase("") && exptype.equalsIgnoreCase(of_expType)) 
//										{
//											OA_EXPTYPE = true;
//										} 
//										else 
//										{
//											OA_EXPTYPE = false;
//											errorMessages[5]=errorMessages[5]+"Expenditure Type Mismatch for the Inventory Transaction:\n"+parsdata+"\n";
//											mxLog.writeLog("Expenditure Type Mismatch for the Inventory Transaction:"+parsdata);
//										}
//
//
//										if (OA_RECON_AMT == true && OA_PROJECTID == true && OA_TASKID ==true && OA_EXPTYPE==true)
//										{
//											//invTransMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
//											//invTransMbo.setValue("OA_COA",oa_coa,MboConstants.NOACCESSCHECK);
//											//invTransMbo.setValue("OA_LINECOST",reconcileAmt,MboConstants.NOACCESSCHECK);
//											//invTransMbo.setValue("OA_FLAG",true,MboConstants.NOACCESSCHECK);
//											//	getInvTransTransSet.save();
//											System.out.println("Update inside In INVTRANS");
//										}
//									}
//
//								}
//								else
//								{
//									errorMessages[1] = errorMessages[1]+"Invalid Transaction ID's Found for these records:\n\n"+"\n\n"+parsdata+"\n";
//									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
//								}
//							}
							else if(objectName.trim().equalsIgnoreCase("MATUSETRANS") & !transId.trim().equalsIgnoreCase(""))
							{
								MboSetRemote matuseTransSet=MXServer.getMXServer().getMboSet("MATUSETRANS",getRunasUserInfo());
								SqlFormat matuseTransSetSQL=new SqlFormat("MATUSETRANSID='"+transId+"'");
								matuseTransSet.setWhere(matuseTransSetSQL.format());
								matuseTransSet.reset();
								if(!matuseTransSet.isEmpty() & matuseTransSet!=null)
								{

									MboRemote matusetransMbo=matuseTransSet.getMbo(0);
									if(matusetransMbo!= null)
									{
										double loadedCost=matusetransMbo.getDouble("LINECOST");
										String fcProjectid=matusetransMbo.getString("FCPROJECTID");
										String fcTaskid=matusetransMbo.getString("FCTASKID");
										String exptype=matusetransMbo.getString("WORKORDER.WORKTYPE.WTYPEDESC");
										if(oa_linecost ==loadedCost)
										{
											OA_RECON_AMT = true;

										}
										else
										{
											OA_RECON_AMT = false;
											errorMessages[2]=errorMessages[2] +parsdata+"\n";
											mxLog.writeLog("Cost Mismatch for the MATUSETRANS Transaction:"+parsdata);
										}
										// To check if the COA from OF and Maximo are same
										// If they are same, then set the flag as True
										if (!fcProjectid.equalsIgnoreCase("") && fcProjectid.equalsIgnoreCase(of_projectID.trim()))
										{
											OA_PROJECTID = true;
										}
										else
										{
											OA_PROJECTID = false;
											errorMessages[3]=errorMessages[3]+parsdata+"\n";
											mxLog.writeLog("Project ID Mismatch for the  Transaction:"+parsdata);
										}

										// To check if the TaskID from OF and Maximo are same
										// If they are same, then set the flag as True
										if (!fcTaskid.equalsIgnoreCase("") && fcTaskid.equalsIgnoreCase(of_taskID))
										{
											OA_TASKID = true;
										}
										else
										{
											OA_TASKID = false;
											errorMessages[4]=errorMessages[4]+parsdata+"\n";
											mxLog.writeLog("Task ID Mismatch for the  Transaction:"+parsdata);
										}


										//  To check if the ExpenType from OF and Maximo are same
										if (!exptype.equalsIgnoreCase("") && exptype.equalsIgnoreCase(of_expType)) 
										{
											OA_EXPTYPE = true;
										} 
										else 
										{
											OA_EXPTYPE = false;
											errorMessages[5]=errorMessages[5]+parsdata+"\n";
											mxLog.writeLog("Expenditure Type Mismatch for the Labor Transaction"+parsdata);
										}

										if (OA_RECON_AMT == true && OA_PROJECTID == true && OA_TASKID ==true && OA_EXPTYPE==true)
										{

											matusetransMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
											matusetransMbo.setValue("OA_PROJECTID",of_projectID,11L);
											matusetransMbo.setValue("OA_LINECOST",oa_linecost,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
											matusetransMbo.setValue("OA_TASKID",of_taskID,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
											matusetransMbo.setValue("OA_EXPTYPE_REC",of_expType,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
											matusetransMbo.setValue("OA_EXPORG",oa_exporg,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_PERIOD",oa_period,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_TRANSDATE",oa_transdate,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_DEBITACCT",oa_debitacct,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_CREDITACC",oa_creditacc,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_CATEGORY",oa_category,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_SOURCE",oa_source,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_JNAME",oa_jname,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_HEADER",oa_header,MboConstants.NOACCESSCHECK);
											matusetransMbo.setValue("OA_FLAGREC",true,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);

											matuseTransSet.save(MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
											System.out.println("Update Matusetrans transaction");
										}
									}

								}
								else
								{
									errorMessages[1] = errorMessages[1]+"Invalid Transaction ID's Found for these records:\n\n"+"\n\n"+parsdata+"\n";
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}
							}
							else if(objectName.trim().equalsIgnoreCase("MATRECTRANS") & !transId.trim().equalsIgnoreCase(""))
							{
								MboSetRemote matrecTransSet=MXServer.getMXServer().getMboSet("MATRECTRANS",getRunasUserInfo());
								SqlFormat matrecTransSetSQL=new SqlFormat("MATRECTRANSID='"+transId+"'");
								matrecTransSet.setWhere(matrecTransSetSQL.format());
								matrecTransSet.reset();
								if(!matrecTransSet.isEmpty() & matrecTransSet!=null)
								{

									MboRemote matrectransMbo=matrecTransSet.getMbo(0);
									if(matrectransMbo!= null)
									{
										double loadedCost=matrectransMbo.getDouble("LINECOST");
										String fcProjectid=matrectransMbo.getString("FCPROJECTID");
										String fcTaskid=matrectransMbo.getString("FCTASKID");
										String exptype=matrectransMbo.getString("WORKORDER.WORKTYPE.WTYPEDESC");
										if(oa_linecost ==loadedCost)
										{
											OA_RECON_AMT = true;

										}
										else
										{
											OA_RECON_AMT = false;
											errorMessages[2]=errorMessages[2] +parsdata;
											mxLog.writeLog("Cost Mismatch for the MATRECTRANS Transaction:"+parsdata);
										}
										// To check if the COA from OF and Maximo are same
										// If they are same, then set the flag as True
										if (!fcProjectid.equalsIgnoreCase("") && fcProjectid.equalsIgnoreCase(of_projectID))
										{
											OA_PROJECTID = true;
										}
										else
										{
											OA_PROJECTID = false;
											errorMessages[3]=errorMessages[3]+parsdata+"\n";
											mxLog.writeLog("Project ID Mismatch for the  Transaction:"+parsdata);
										}

										// To check if the TaskID from OF and Maximo are same
										// If they are same, then set the flag as True
										if (!fcTaskid.equalsIgnoreCase("") && fcTaskid.equalsIgnoreCase(of_taskID))
										{
											OA_TASKID = true;
										}
										else
										{
											OA_TASKID = false;
											errorMessages[4]=errorMessages[4]+parsdata+"\n";
											mxLog.writeLog("Task ID Mismatch for the  Transaction:"+parsdata);
										}


										//  To check if the ExpenType from OF and Maximo are same
										if (!exptype.equalsIgnoreCase("") &&  exptype.equalsIgnoreCase(of_expType)) 
										{
											OA_EXPTYPE = true;
										} 
										else 
										{
											OA_EXPTYPE = false;
											errorMessages[5]=errorMessages[5]+parsdata+"\n";
											mxLog.writeLog("Expenditure Type Mismatch for the MATRECTRANS Transaction:"+parsdata);
										}


										if (OA_RECON_AMT == true && OA_PROJECTID == true && OA_TASKID ==true && OA_EXPTYPE==true)
										{
										
											matrectransMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_PROJECTID",of_projectID,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_LINECOST",oa_linecost,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_TASKID",of_taskID,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_EXPTYPE_REC",of_expType,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_EXPORG",oa_exporg,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_PERIOD",oa_period,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_TRANSDATE",oa_transdate,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_DEBITACCT",oa_debitacct,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_CREDITACC",oa_creditacc,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_CATEGORY",oa_category,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_SOURCE",oa_source,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_JNAME",oa_jname,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_HEADER",oa_header,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_FLAGREC",true,MboConstants.NOACCESSCHECK);
												matrecTransSet.save();
											System.out.println("Updating Matrectrans transaction");
										}
									}

								}
								else
								{
									errorMessages[1] = errorMessages[1]+"Transaction Data not Present in Maximo:\n\n"+"\n\n"+ "\n\n"+parsdata+"\n";
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}
							}
							else if(objectName.trim().equalsIgnoreCase("SERVRECTRANS") && !transId.trim().equalsIgnoreCase(""))
							{
								MboSetRemote servrecTransSet=MXServer.getMXServer().getMboSet("SERVRECTRANS",getRunasUserInfo());
								SqlFormat servrecTransSetSQL=new SqlFormat("SERVRECTRANSID='"+transId+"'");
								servrecTransSet.setWhere(servrecTransSetSQL.format());
								servrecTransSet.reset();
								if(!servrecTransSet.isEmpty() & servrecTransSet!=null)
								{

									MboRemote servrectransMbo=servrecTransSet.getMbo(0);
									if(servrectransMbo!= null)
									{
										double loadedCost=servrectransMbo.getDouble("LINECOST");
										String fcProjectid=servrectransMbo.getString("FCPROJECTID");
										String fcTaskid=servrectransMbo.getString("FCTASKID");
										String exptype=servrectransMbo.getString("WORKORDER.WORKTYPE.WTYPEDESC");
										if(oa_linecost ==loadedCost)
										{
											OA_RECON_AMT = true;

										}
										else
										{
											OA_RECON_AMT = false;
											errorMessages[2]=errorMessages[2] +parsdata+"\n";
											mxLog.writeLog("Cost Mismatch for the SERVRECTRANS Transaction:"+parsdata);
										}
										// To check if the COA from OF and Maximo are same
										// If they are same, then set the flag as True
										if (!fcProjectid.equalsIgnoreCase("") && fcProjectid.equalsIgnoreCase(of_projectID))
										{
											OA_PROJECTID = true;
										}
										else
										{
											OA_PROJECTID = false;
											errorMessages[3]=errorMessages[3]+parsdata+"\n";
											mxLog.writeLog("Project ID Mismatch for the  Transaction:"+parsdata);
										}

										// To check if the TaskID from OF and Maximo are same
										// If they are same, then set the flag as True
										if (!fcTaskid.equalsIgnoreCase("") && fcTaskid.equalsIgnoreCase(of_taskID))
										{
											OA_TASKID = true;
										}
										else
										{
											OA_TASKID = false;
											errorMessages[4]=errorMessages[4]+parsdata+"\n";
											mxLog.writeLog("Task ID Mismatch for the  Transaction:"+parsdata);
										}


										//  To check if the ExpenType from OF and Maximo are same
										if (!exptype.equalsIgnoreCase("") &&  exptype.equalsIgnoreCase(of_expType)) 
										{
											OA_EXPTYPE = true;
										} 
										else 
										{
											OA_EXPTYPE = false;
											errorMessages[5]=errorMessages[5]+parsdata+"\n";
											mxLog.writeLog("Expenditure Type Mismatch for the SERVRECTRANS Transaction:"+parsdata);
										}


										if (OA_RECON_AMT == true && OA_PROJECTID == true && OA_TASKID ==true && OA_EXPTYPE==true)
										{
											
											servrectransMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_PROJECTID",of_projectID,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_LINECOST",oa_linecost,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_TASKID",of_taskID,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_EXPTYPE_REC",of_expType,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_EXPORG",oa_exporg,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_PERIOD",oa_period,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_TRANSDATE",oa_transdate,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_DEBITACCT",oa_debitacct,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_CREDITACC",oa_creditacc,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_CATEGORY",oa_category,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_SOURCE",oa_source,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_JNAME",oa_jname,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_HEADER",oa_header,MboConstants.NOACCESSCHECK);
											servrectransMbo.setValue("OA_FLAGREC",true,MboConstants.NOACCESSCHECK);
											servrecTransSet.save();
											System.out.println("Updating Servtrans transactions");
										}
									}

								}
								else
								{
									errorMessages[1] = errorMessages[1]+"Transaction Data not Present in Maximo:\n\n"+"\n\n"+"\n\n"+parsdata+"\n";
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}
							}
						}
						else
						{

							errorMessages[0] = errorMessages[0]+"Transaction Data not Present in Maximo:"+"\n\n"+"\n\n"+parsdata+"\n";
							mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
						}
					}
					else
					{

						errorMessages[0] = errorMessages[0]+"Transaction Data not Present in Maximo:"+"\n\n"+"\n\n"+parsdata+"\n";
						mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
					}
				}
				else
				{
					errorMessages[0]=errorMessages[0]+"\n\n"+"Transaction Data not Present in Maximo:"+"\n\n"+parsdata+"\n";
					mxLog.writeLog("Incorrect Data present in the file:"+parsdata);
				}
			}
			catch (Exception e) {				 

				errorMessages[0]=errorMessages[0]+"\n\n"+"Transaction Data not Present in Maximo:"+"\n\n"+parsdata+"\n\n"+e.getMessage()+"\n\n";
				mxLog.writeLog("Incorrect Data present in the file:"+parsdata+"\n\n"+e.getMessage()+"\n\n");

			}
		}
		if(errorMessages[0].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[0]);
		}
		if(errorMessages[1].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[1]);
		}
		if(errorMessages[2].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Cost Mismatch for the  Transaction:\n\n" + errorMessages[2]);
		}
		if(errorMessages[3].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Project ID Mismatch for the  Transaction:\n\n" +  errorMessages[3]);
		}
		if(errorMessages[4].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Task ID Mismatch for the  Transaction:\n\n" + errorMessages[4]);
		}
		if(errorMessages[5].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, " Expenditure Type Mismatch for the Labor Transaction:\n\n" + errorMessages[5]);
		}
		if(errorMessages[6].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[6]);
		}

	}

	private Collection extractFileRead(String file) throws IOException {


		Collection col = new ArrayList();
		try
		{

			BufferedReader  flatfileReader = new BufferedReader(new FileReader(file));
			String curLine = flatfileReader.readLine();

			while((curLine = flatfileReader.readLine()) != null)
			{
				String[] data = curLine.split(splitTag);

				ArrayList list =new ArrayList();

				for(int i=0;i<data.length;i++){

					list.add(data[i].trim());
				}


				col.add(list);
			}

			integrationLogger.debug("Flat file parsing is completed");
			flatfileReader.close();
		}
		catch(Exception e)
		{

			mxLog.writeLog("Error On Parsing a flat file:"+getName()+":"+e.getMessage());
			e.printStackTrace();

		}
		return col;
	}


}
