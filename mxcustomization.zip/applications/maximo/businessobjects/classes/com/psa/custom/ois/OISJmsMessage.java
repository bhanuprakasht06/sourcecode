/**
 * @author	HCHA
 * Date		Feb 27, 2006
 * Comment	 
 */
package com.psa.custom.ois;

import java.rmi.RemoteException;
import java.util.HashMap;
import psdi.iface.jms.MEAQueueProcessor;
import psdi.iface.mic.MicUtil;
import psdi.util.MXException;

/**
 * @author		HCHA
 * @class		OISJmsMessage
 * @date		Feb 27, 2006
 * @function	Send message to JMS queue
 */
public class OISJmsMessage {
	
    private MEAQueueProcessor queueProcessor;
    private String extSys; 		//Name of External System
    private String intIface;	//Name of Integration Interface

    
    /**
	 * @param extSys
	 * @param intIface
	 */
	public OISJmsMessage(String extSys, String intIface) {
		this.extSys = extSys;
		this.intIface = intIface;
	}



	public String getExtSys() {
		return extSys;
	}



	public void setExtSys(String extSys) {
		this.extSys = extSys;
	}



	public String getIntIface() {
		return intIface;
	}



	public void setIntIface(String intIface) {
		this.intIface = intIface;
	}

	/**
	 * 
	 * @author		HCHA
	 * @date		Feb 27, 2006
	 * @function	Send message to JMS queue
	 * @param abyte0 - message to send
	 * @param extSys - name of external system
	 * @param intIface - name of integration interface
	 * @throws Exception
	 * @throws MXException
	 * @throws RemoteException
	 * 
	 */
	

	public void sendMessage(byte abyte0[], String extSys, String intIface) 
		throws MXException, RemoteException, Exception
	{
		System.out.println("--inside sendmessage of oisjmsmessage--");

    	this.extSys = extSys;
    	this.intIface = intIface;
    	
    	sendMessage(abyte0);
	}
    
    
    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Sending message to JMS queue.   
     */

    public void sendMessage(byte abyte0[]) 
    	throws MXException, RemoteException,Exception
    {
		System.out.println("--inside sendmessage of oisjmsmessage--");

    	try {
    		System.out.println("-inside send message-");
           /* HashMap hashmap = new HashMap();
            hashmap.put("SENDER", extSys);
            hashmap.put("INTERFACE", intIface);*/
            	           
            if(queueProcessor == null)
                queueProcessor = new MEAQueueProcessor();
            
            queueProcessor.writeDataToQueueIn(abyte0, extSys, intIface);	            
	    }
    	catch (Exception e) {
    		MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
    		if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
    			MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");
        
    		throw new Exception(e.getMessage());
    	}
    	
    	/*try {
    		
            HashMap hashmap = new HashMap();
            hashmap.put("SENDER", extSys);
            hashmap.put("INTERFACE", intIface);
            	           
            if(queueProcessor == null)
                queueProcessor = new MEAQueueProcessor();
            
            queueProcessor.writeDataToQueueIn(abyte0, hashmap, true);	            
	    }
    	catch (Exception e) {
    		MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
    		if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
    			MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");
        
    		throw new Exception(e.getMessage());
    	}*/
																					
	}

}
