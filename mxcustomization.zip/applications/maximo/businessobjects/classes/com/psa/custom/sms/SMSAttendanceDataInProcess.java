package com.psa.custom.sms;

import java.rmi.RemoteException;

import com.psa.custom.common.MxEmail;

import psdi.iface.mic.MicConstants;
import psdi.iface.mic.MicSetIn;
import psdi.util.MXApplicationException;
import psdi.util.MXException;



/*
 * Author: BTE
 * 08 MAR 2006 - Initial version
 * 23 JUN 2006 - DR-161
 */
public class SMSAttendanceDataInProcess extends MicSetIn  {

	/*
	 * Variables
	 */ 	
	private static SMSConstant SMS = new SMSConstant();
	private MxEmail email;
	private static String SUBJECT = "ATTENDANCE: ";
	private static String EMAILMESSAGE = " - FAIL TO CLOCK-IN";
	
	
	/*
	 * Author: BTE
	 * 08 MAR 2006 - Constructor
	 */
	public SMSAttendanceDataInProcess() throws MXException, RemoteException {
		super();		
	}
	
	
	/*
	 * Author: BTE
	 * 08 MAR 2006 - Check business rules for inbound attendance
	 */
    public int checkBusinessRules() throws MXException, RemoteException {            				
	   	
        INTEGRATIONLOGGER.debug("Entering checkBusinessRules");     
        
		// Check if ORGID is null
		if (struc.isCurrentDataNull(SMS.ORGID)) {
			throw new MXApplicationException(SMS.IFACE, SMS.ATTNOORGID);
		}

		// Check if TRANSDATE is null
		if (struc.isCurrentDataNull(SMS.TRANSDATE)) {
			throw new MXApplicationException(SMS.IFACE, SMS.ATTNOTRANSDATE);
		}		
		
    	// Check if IC is null    	
    	if (struc.isCurrentDataNull(SMS.IC)) {
    		throw new MXApplicationException(SMS.IFACE, SMS.ATTNNOIC);
		} else {    	
	    	// Search for LABORCODE in database to populate LABORCODE
			SMSPerson person =  new SMSPerson(getUserInfo());
			String code = person.getPersonID(struc.getCurrentData(SMS.IC)); 
			
			if (code == null) {
				throw new MXApplicationException(SMS.IFACE, SMS.LABNOLABORCODE);
			} else {
				struc.setCurrentData(SMS.LABORCODE, code);
			}
		}   	
		    
    	// Check if StartTime is null in Transdate; 
    	if (!struc.isCurrentDataNull(SMS.TRANSDATE)) {
    		//String transDateTime = struc.getCurrentData(SMS.TRANSDATE).substring(0,4);
    		//transDateTime += SMS.SLASH;
    		//transDateTime += struc.getCurrentData(SMS.TRANSDATE).substring(5,7);
    		//transDateTime += SMS.SLASH;
    		//transDateTime += struc.getCurrentData(SMS.TRANSDATE).substring(8,10);
    		//transDateTime += SMS.SPACE;
    		//transDateTime += struc.getCurrentData(SMS.TRANSDATE).substring(11, struc.getCurrentData(SMS.TRANSDATE).length());
    		
    		String transDateTime = struc.getCurrentData(SMS.TRANSDATE);
    		struc.setCurrentData(SMS.TRANSDATE, transDateTime);    	
    	}
    	
    	// Check if StartTime and EndTime is null; notify supervisor  
    	if ((struc.isCurrentDataNull(SMS.STARTTIME) || struc.getCurrentData(SMS.STARTTIME).equals(SMS.EMPTY)) && 
    			(struc.isCurrentDataNull(SMS.FINISHTIME) || struc.getCurrentData(SMS.FINISHTIME).equals(SMS.EMPTY))) {

    		// Get email address
    		SMSPerson person =  new SMSPerson(getUserInfo());
			String supervisor = person.getSupervisor(struc.getCurrentData(SMS.IC)); 

			if (supervisor == null) {				
				throw new MXApplicationException(SMS.IFACE, SMS.PERSONNOSUPERVISOR);
			} 
			
			// Get person last name
			String personDisplayName = person.getDisplayName(struc.getCurrentData(SMS.IC));
			if (personDisplayName == null) {
				throw new MXApplicationException(SMS.IFACE, SMS.PERSONNODISPLAYNAME);
			} 			
			
			// Get supervisor email address
			SMSEmail smsEmail =  new SMSEmail(getUserInfo());
			String supEmail = smsEmail.getEmail(supervisor); 
			
			if (supEmail == null) {
				throw new MXApplicationException(SMS.IFACE, SMS.PERSONNOEMAIL);
			} 
			
    		// Notify if Start time is null
            email = new MxEmail(supEmail); 
            email.send(struc.getCurrentData(SMS.TRANSDATE) + 
            		SMS.SPACE + 
            		SUBJECT + 
            		personDisplayName + 
            		EMAILMESSAGE, SMS.EMPTY);         
    	} 

    	// Check if StartTime is null; 
    	if (!struc.isCurrentDataNull(SMS.TRANSDATE)) {
    		//String transDateTime = struc.getCurrentData(SMS.TRANSDATE).substring(0,4);
    		//transDateTime += SMS.SLASH;
    		//transDateTime += struc.getCurrentData(SMS.TRANSDATE).substring(5,7);
    		//transDateTime += SMS.SLASH;
    		//transDateTime += struc.getCurrentData(SMS.TRANSDATE).substring(8,10);
    		//transDateTime += SMS.SPACE;
    		//transDateTime += struc.getCurrentData(SMS.TRANSDATE).substring(11,struc.getCurrentData(SMS.TRANSDATE).length());
    		
    		String transDateTime = struc.getCurrentData(SMS.TRANSDATE);
    		struc.setCurrentData(SMS.TRANSDATE, transDateTime);    	
    	}
    	    	    	
    	// Check if StartTime is null; 
    	if (!struc.isCurrentDataNull(SMS.STARTTIME)) {
    		//String startDateTime = struc.getCurrentData(SMS.STARTTIME).substring(0,4);
    		//startDateTime += SMS.SLASH;
    		//startDateTime += struc.getCurrentData(SMS.STARTTIME).substring(5,7);
    		//startDateTime += SMS.SLASH;
    		//startDateTime += struc.getCurrentData(SMS.STARTTIME).substring(8,10);
    		//startDateTime += SMS.SPACE;
    		//startDateTime += struc.getCurrentData(SMS.STARTTIME).substring(11,struc.getCurrentData(SMS.TRANSDATE).length());
    		
    		String startDateTime = struc.getCurrentData(SMS.STARTTIME);
    		struc.setCurrentData(SMS.STARTTIME, startDateTime);
    		struc.setCurrentData(SMS.STARTDATE, startDateTime);
    	}
    	
    	// Check if EndTime is null
    	if (!struc.isCurrentDataNull(SMS.FINISHTIME)) {
    		//String endDateTime = struc.getCurrentData(SMS.FINISHTIME).substring(0,4);
    		//endDateTime += SMS.SLASH;
    		//endDateTime += struc.getCurrentData(SMS.FINISHTIME).substring(5,7);
    		//endDateTime += SMS.SLASH;
    		//endDateTime += struc.getCurrentData(SMS.FINISHTIME).substring(8,10);
    		//endDateTime += SMS.SPACE;
    		//endDateTime += struc.getCurrentData(SMS.FINISHTIME).substring(11,struc.getCurrentData(SMS.TRANSDATE).length());
    		
    		String endDateTime = struc.getCurrentData(SMS.FINISHTIME);
    		struc.setCurrentData(SMS.FINISHTIME, endDateTime);
    		struc.setCurrentData(SMS.FINISHDATE, endDateTime);
    	}
    	
    	
        INTEGRATIONLOGGER.debug("Leaving checkBusinessRules");
		return MicConstants.PROCESS;
    }
        
}
