/*
 * Modification history
 * 30-01-13 WMJ EMS-551 [Peoplesoft]To handle special characters when generating XML messages in Maximo Peoplesoft crontask
 *
 *
 */

/*
 * Modification history
 *
 * 28-Nov-11 YCH Creation
 *
 * This class is cron task to process received Peoplesoft records
 *
 */

package com.psa.custom.pplsoft;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import java.util.Comparator;

//WMJ:Added to convert List to Int Array
//import java.util.List;
//import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.LineNumberReader;//Added for check control totals

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxXml;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;
import com.psa.custom.ois.MxLog;

import psdi.iface.jms.MEAQueueProcessor;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


//Start of EMS-551
import org.apache.commons.lang3.StringEscapeUtils;
//End of EMS-551

/**
 *
 * @author YCH
 * @class PplsoftReconCronTask
 * @date Nov 28, 2011
 * @function
 */
public class NewPplsoftCronTask extends SimpleCronTask {

        private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
        private static final String SPACE = " ";
        private static final String NEWLINE = "\n\r";

        protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");

        // XML Message Generate Constants Begin
        private static final int RECORD_COUNT_BEGIN_INDEX = 16;
        private static final int RECORD_COUNT_END_INDEX = 21;
        private static final int TRANS_ID_BEGIN_INDEX = 1;
        private static final int TRANS_ID_END_INDEX = 16;
        private static final String TRANS_ID_JOB = "JOB";
        private static final String TRANS_ID_SNPCOSTC = "SNPCOSTC";
        // XML Message Generate Constants End

        private MEAQueueProcessor queueProcessor;
        private String qualifiedInstanceName;
        private RecoveryService recoveryService;

        //Crontask Parameters variable declarations
        private String extSys; // Name of External System
        private String ifaceName; // Name of Job Integration Interface
        private String personIfaceName;  // Name of Person Integration Interface
        private String intObject; // Name of Integration Object
        private String directory; // Directory to retrieve the file from
        protected String adminEmail; // Administrator Email
        protected String emailSubj; // Alert Email Subject
        private String importFileName; // Import Base File Name
        private String processDirectory; // Directory where processing are done
        private String logDir; // Directory where log file will be placed
        private boolean enableLog; // Enable Log
        private String costCStartPos;//String containing the cost centre message start positions
        private String costCEndPos;//String containing the cost centre message end positions
        private String jobStartPos;//String containing the job message start positions
        private String jobEndPos;//String containing the job message end positions
        private String personStore;//String containing the job message end positions

        private File loadDir;
        protected MxLog mxLog;
        private MxEmail email;
        private MxXml mxXml;

        private boolean isProcErr;
        private StringBuffer errMessage;

        private boolean initialized;

        /*
     * Author: YCH
     * 28 NOV 2011 - Pplsoft Cron task constructor initialize default value
     */
        public NewPplsoftCronTask() {
                super();

                initialized = false;

                recoveryService = null;
                queueProcessor = null;
                qualifiedInstanceName = null;
                queueProcessor = new MEAQueueProcessor();

                extSys = null;

                ifaceName = null;
                personIfaceName = null;
                intObject = null;
                loadDir = null;
                directory = null;
                adminEmail = null;
                emailSubj = null;
                importFileName = null;
                processDirectory = null;
                logDir = null;
                enableLog = false;
                costCStartPos = null;
                costCEndPos = null;
                jobStartPos = null;
                jobEndPos = null;
                personStore = null;

                errMessage = null;
                isProcErr = false;

        }

        /*
         * Author: YCH Date: 28 Nov 2011 Comment: [Standard Cron Task Function]
         * Initialize cron task
         */
        public void init() throws MXException {
                super.init();

                email = new MxEmail(adminEmail);
                mxXml = new MxXml();
                mxLog = new MxLog();
                initialized = true;
        }

        /*
         * Author: YCH 28 Nov 2011 - Get the parameter value setting from maximo
         * User Interface in configuration
         */
        private void refreshSettings() {
                integrationLogger.debug("[NewPplsoftCronTask] Entering refreshSettings");

                try {
                        extSys = getParamAsString("EXTSYSNAME");
                        ifaceName = getParamAsString("INTERFACENAME");
                        intObject = getParamAsString("INTOBJECT");

                        directory = getParamAsString("DIRECTORY");
                        loadDir = new File(directory);
                        //Removed by WMJ 20120819 for MX7 recoveryService
                        //recoveryService = new RecoveryService(loadDir);

                        adminEmail = getParamAsString("ALERTEMAIL");
                        email.setAdmin(adminEmail);
                        emailSubj = getParamAsString("ALERTEMAILSUBJ");

                        // Directory where processing are done
                        processDirectory = getParamAsString("PROCESSDIRECTORY");

                        // Log
                        DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
                        String todayDate = fileDateFormat.format(new Date());
                        logDir = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd", todayDate);
                        enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
                        mxLog.setEnabled(enableLog);
                        mxLog.setLogFilePath(logDir);
                        mxLog.setLogTag(getName());
                        mxLog.createLogFile();

                        // Modify to replace with by previous day's if "yyyymmpd" is specified in import file base name
                        Calendar cal = Calendar.getInstance();
                        cal.add(Calendar.DAY_OF_MONTH,-1);
                                String prevDate = fileDateFormat.format(cal.getTime());
                        importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmpd", prevDate);

                        //Start Position for Cost Centre Message
                        costCStartPos = getParamAsString("COSTCSTARTPOS");

                        //End Position for Cost Centre Message
                        costCEndPos = getParamAsString("COSTCENDPOS");

                        //Start Position for JOB Message
                        jobStartPos = getParamAsString("JOBSTARTPOS");

                        //End Position for JOB Message
                        jobEndPos = getParamAsString("JOBENDPOS");

                        //personStore for Job Messages
                        personStore = getParamAsString("PERSONSTORE");


                        integrationLogger.debug("[NewPplsoftCronTask] Leaving refreshSettings");
                        } catch (Exception exception) {
                        if (integrationLogger.isErrorEnabled()) {
                                integrationLogger.error(exception.getMessage(), exception);
                        }
                }
        }

        /*
        Author: WMJ
        Date: 20 Mar 2012
        Comment: To convert the String in crontaskparam to Int[]
        This is to get the positions(for both start and end) of the fields in the Pplsoft messages
        The delimiter used to split the string is comma
        */
        private int[] convertStringArraytoIntArray(String stringparam)
          {
                integrationLogger.debug("[NewPplsoftCronTask] Entering convertStringArraytoIntArray()");

                integrationLogger.debug("[NewPplsoftCronTask] convertStringArraytoIntArray(): stringparam read is :" + stringparam);

                //split the string based on the delimiter comma[,] into a String array. The slashes \\ are for escaping the comma
                String[] result= stringparam.split("\\,");
                //System.out.println("string array result is : " + Arrays.asList(result));
                integrationLogger.debug("[NewPplsoftCronTask] convertStringArraytoIntArray(): stringparam read is :" + stringparam);


            int[] intarray;
            intarray = new int[result.length];

            for(int i =0; i<result.length; i++)
            {
                    intarray[i]=Integer.parseInt(result[i]);
                    integrationLogger.debug("[NewPplsoftCronTask] convertStringArraytoIntArray(): Value added to int array at position " + i + " is :" + intarray[i]);
            }

                integrationLogger.debug("[NewPplsoftCronTask] Leaving convertStringArraytoIntArray()");

                return intarray;
          }

        /*
         * Author: YCH
         * Date: 28 Nov 2011
         * Comment: [Standard Cron Task Function]
         *
         * Start cron task
         */
        public void start() {
                try {
                        refreshSettings();
                        MicUtil.INTEGRATIONLOGGER.info("[" + getName() + "] Start - "
                                        + qualifiedInstanceName + " started for System:" + extSys
                                        + " and Interface:" + ifaceName);
                        setSleepTime(0L);
                } catch (Exception exception) {
                        if (integrationLogger.isErrorEnabled()) {
                                integrationLogger.error(exception.getMessage(), exception);
                        }
                }
        }

        /*
         * Author: YCH
         * Date: 28 Nov 2011
         * Comment: [Standard Cron Task Function]
         *
         * Stop cron task
         */
        public void stop() {
                try {
                        mxLog.closeLogFile();
                } catch (Exception exception) {
                        if (integrationLogger.isErrorEnabled()) {
                                integrationLogger.error(exception.getMessage(), exception);
                        }
                }

                MicUtil.INTEGRATIONLOGGER.info("[" + getName() + "] Stop - "
                                + qualifiedInstanceName + " stopped for System:" + extSys
                                + " and interface:" + ifaceName);
        }

        /*
         * Author: YCH
         * Date: 28 Nov 2011
         * Comment: [Standard Cron Task Function]
         *
         * Set cron task instance
         */
        public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
        {
                try {
                        super.setCrontaskInstance(crontaskinstanceremote);
                        qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname")
                                        + "." + crontaskinstanceremote.getString("instancename");
                } catch (Exception exception) {
                        integrationLogger.error(exception.getMessage(), exception);
                }
        }

        /*
         * Author: YCH
         * Date: 29 NOV 2011
         * Comment: returns true if all required parameter is set
         */
        private boolean isReqParamSet() {
        	    System.out.println("***NewPplsoftCronTask >> isReqParamSet: adminEmail="+adminEmail+",ifaceName="+ifaceName+
        	    		           ",extSys="+extSys+",processDirectory="+processDirectory+",importFileName="+importFileName+
        	    		           ",directory="+directory+",costCStartPos="+costCStartPos+",costCEndPos="+costCEndPos+
        	    		           ",jobStartPos="+jobStartPos+",jobEndPos="+jobEndPos+"personStore="+personStore+
        	    		           ",intObject="+intObject+",importFileName="+importFileName);
                if (adminEmail == null)
                        return false;
                if (ifaceName == null)
                        return false;
                if (extSys == null)
                        return false;
                if (processDirectory == null)
                        return false;
                if (importFileName == null)
                        return false;
                if (directory == null)
                        return false;
                if (costCStartPos == null)
                        return false;
                if (costCEndPos == null)
                        return false;
                if (jobStartPos == null)
                        return false;
                if (jobEndPos == null)
                        return false;
                if (personStore == null)
                        return false;
                                if (intObject == null)
                        return false;
                                if (importFileName == null)
                        return false;


                return true;
        }

        /*
         * Author: YCH
         * Date: 28 Nov 2011
         *
         * Comment: Generate Email
         */
        private String genEmail(Exception e) {

                // Form Email Message
                String emailMsg = "Date: " + new Date() + "\n";
                emailMsg += "Error in CronTask: " + getName() + "\n";
                emailMsg += "Error Message: " + e.getMessage() + "\n";
                emailMsg += "Detail:\n";
                emailMsg += e.toString() + "\n";
                StackTraceElement element[] = e.getStackTrace();
                for (int i = 0; i < element.length; i++) {
                        emailMsg += "\tat " + element[i].toString() + "\n";
                }

                return emailMsg;
        }

        /*
         * Author: YCH
         * Date: 28 NOV 2011
         *
         * Comment: Generate Formated Error Msg
         */
        private String genErrMsg(Exception e, Vector vec) {

                String errMsg = "Line:" + vec.toString() + "\n";
                errMsg += "Error Message: " + e.getMessage() + "\n";
                errMsg += "Detail:" + "\n";
                errMsg += e.toString() + "\n";
                StackTraceElement element[] = e.getStackTrace();
                for (int i = 0; i < element.length; i++) {
                        errMsg += "\tat " + element[i].toString() + "\n";
                }

                return errMsg;
        }

        /*
         * Author: YCH
         * Date: 28 Nov 2011
         * Comment: Get the parameter from Cron Task.
         */
        public CrontaskParamInfo[] getParameters() throws MXException,
                        RemoteException {
                return params;
        }

        /*
         * Author: YCH
         * Date : 28 Nov 2011
         * Comment: [Standard Cron Task Function]
         *
         * Cron task function -
         *       * 1. Refresh the setting from Parameters
         * 2. Get Required Parameters
         * 3. Process Folder Data for corresponding file
         * 4. Zip the processed file
         */
        public void cronAction() {
                integrationLogger.debug("[NewPplsoftCronTask] Entering cronAction");
                mxLog.writeLog(" cronAction(): Start CronTask Action");

                try {
                        if (!initialized) {
                                mxLog.writeLog(" cronAction(): CronTask not initialized!");
                                throw new Exception(getName() + ".cronAction(): NewPplsoftCronTask CronTask not initialized!");
                        }

                        // Refresh setting before perform cron action
                        refreshSettings();

                        if (isReqParamSet()) {

                                //Load the file store and process any message in it that reaches the effective date
                                processPersonStore();

                                //move chksum file to backup folder /opt/psa/data/rw/emsscp/incoming/pplsoft/backup
                                //to remove this function when implementing the usage of the chksum to verify the file in the future
                                moveChecksumFiles();

                                //Process the input flat files from Peoplesoft
                                processFolderData();

                                //Copy and Zip Flat Files to Output and Archive Directory
                                        //depositFile();
                        } else {
                                mxLog.writeLog(" cronAction(): Required parameters not set.");
                                throw new Exception("Required parameters not set.");
                        }

                } catch (Exception e) {
                        MicUtil.INTEGRATIONLOGGER.error("[" + getName() + "] " + e.getMessage(), e);

                        String emailContent = genEmail(e);
                        email.send(emailSubj, emailContent);
                        mxLog.writeLog("Email Sent: \n" + emailContent);

                        stop();
                }

                integrationLogger.debug("[NewPplsoftCronTask] Leaving cronAction");
                mxLog.writeLog(" cronAction(): End CronTask Action");
        }

        /*
         * Author: WMJ
         * Date: 20 Apr 2012 - Process the file store
         * 1. Load the messages in the file store
         * 2. Process the messages in the file store if new effective date is reached. Delete message after processing. Else skip the message.
         * 3. Close the file store
         */
        public void processPersonStore() throws Exception {

                integrationLogger.debug("[NewPplsoftCronTask] Entering processPersonStore");
                mxLog.writeLog(" processPersonStore(): Start processPersonStore");

                if(personStore != null) {

                        //process the personStore
                        ArrayList store = new ArrayList();//to store future effective messages
                        Collection col = parseFlatFile(personStore, store);

                        // Create a XML document based on the data from the flat file.
                        mxLog.writeLog(" processPersonStore(): Creating XML doc");
                        Map xmlMap = generateXMLDocument(col);

                        // Important BufferedInputStream has a size of 2000byte only.
                        mxLog.writeLog(" processPersonStore(): Running multiSplitPerformed(xmlMap, j)");
                        multiSplitPerformed(xmlMap, 0);

                        boolean append = false;
                        writeTransRec(store, append);

        }
        else{
                mxLog.writeLog(" processPersonStore(): Unable to read input file '" + personStore + "'");
            throw new Exception("[" + getName() + "] Unable to read input file '" + personStore + "'");
        }

        }

        /*
         * Author: WMJ
         * Date: 20 Apr 2012 - Write/Append to the file store
         * 1. Write the messages into the file store
         * 2. If append is true, append to file. Else re-write the whole file
         * 3. Close the file store
         */
        public void writeTransRec(ArrayList lst, boolean append) throws IOException {

                integrationLogger.debug("[NewPplsoftCronTask] Entering writeTransRec");
                mxLog.writeLog(" writeTransRec(): Start writeTransRec");

                FileWriter fWriter;
                        BufferedWriter bWriter;

                if(append){
                        mxLog.writeLog(" writeTransRec(): append is true, will append to file");
                        fWriter = new FileWriter(personStore, append);//the parameter true is for appending the file personStore instead of overwriting it
                        }
                else{
                        mxLog.writeLog(" writeTransRec(): append is false, create and write new file");
                        //delete the file and create a new one with the same filename
                        File filePersonStore = new File(personStore);
                        filePersonStore.delete();

                        fWriter = new FileWriter(personStore);

                        }

                        bWriter = new BufferedWriter(fWriter);


                                String writeline = new String();

                        for (int i = 0; i < lst.size(); i++) {
                            writeline = (String) lst.get(i);
                            mxLog.writeLog(" writeTransRec(): string being written at " +  i + " is: " + writeline);

                            bWriter.write(writeline);
                                bWriter.newLine();
                        }

                        bWriter.close();
                        fWriter.close();

                        }



                 /*
         * Author: WMJ
         * Date: 7 Dec 2012 - Move all checksum files to backup folder
         */
        public void moveChecksumFiles() throws Exception {

                integrationLogger.debug("[NewPplsoftCronTask] Entering moveChecksumFiles");
                mxLog.writeLog(" moveChecksumFiles(): Start moveChecksumFiles");

                //Run the unix command mv /opt/psa/data/rw/emsscp/incoming/pplsoft/*.cksum /opt/psa/data/rw/emsscp/incoming/pplsoft/backup/
                //"sh" is to run the command in a shell as the asterix * becomes a filename if this is not included
                String[] cmd = {"sh", "-c", "mv /opt/psa/data/rw/emsscp/incoming/pplsoft/*.cksum /opt/psa/data/rw/emsscp/incoming/pplsoft/backup/"};

                Process proc;

                                // Execute external command
                                try {
                                        proc = Runtime.getRuntime().exec(cmd);
                                        int exitVal = proc.waitFor();

                                        mxLog.writeLog(" moveChecksumFiles(): all chksum files moved to /opt/psa/data/rw/emsscp/incoming/pplsoft/backup/");
                                }
                                catch (IOException e) {
                                        throw new IOException(e.getMessage());
                                }
                                catch (InterruptedException e) {
                                        throw new InterruptedException(e.getMessage());
                                }

                integrationLogger.debug("[NewPplsoftCronTask] Leaving moveChecksumFiles");
                mxLog.writeLog(" moveChecksumFiles(): Leaving moveChecksumFiles");

                }

        /*
         * Author: YCH
         * Date: 28 Nov 2011 - Process the import flat file
         * 1. Copy file to process directory
         * 2. Unzip process file
         * 3. Parse the flat file
         * 4. Generate XML Document based on parsed collection
         * 5. Send XML Document Message to JMS Queue
         * 6. Delete Extracted File after processing
         */
        public void processFolderData() throws Exception {

                integrationLogger.debug("[NewPplsoftCronTask] Entering processFolderData");
                mxLog.writeLog(" processFolderData(): Start Processing Data");

                //Added by WANGMJ on 14 May 2012 to sort the File array afile according to file name(date) so that the earliest file is processed first
                //SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
                //File afile[] = loadDir.listFiles(filter);
                File afile[] = loadDir.listFiles();
                
                //Start of check control totals
                int fileexists = 0;
                
            	if(afile != null) {
            		
	            	for (int j = 0; j < afile.length; j++) 
	            	{
	            		if(afile[j].getName().startsWith(importFileName)){
		            		fileexists = 1;
		            	}
            		}
	            		
            	}
            	
            	if(fileexists == 0){
	            		throw new Exception("["+getName()+"]Unable to find input file.");
	            	}
                //End of check control totals

                //Added by WANGMJ on 14 May 2012 to sort the File array afile according to file name(date) so that the earliest file is processed first
                Comparator byFileName = new Comparator()
                {
                        public int compare(Object file1, Object file2){

                        String filename1 = ((File)file1).getName();
                        String filename2 = ((File)file2).getName();

                        return filename1.compareToIgnoreCase(filename2);
                        }
                };

                //before sorting
                mxLog.writeLog("processFolderData() - Before Sorting: " + Arrays.asList(afile));

                Arrays.sort(afile, byFileName);


                //after sorting
                mxLog.writeLog("processFolderData() - After Sorting: " + Arrays.asList(afile));

                //End of Added by WANGMJ on 14 May 2012 to sort the File array afile according to file name(date) so that the earliest file is processed first


                //Processing of File array
                if (afile != null && afile.length != 0) {

                        int fileprocessed = 0;

                        for (int j = 0; j < afile.length; j++) {

                                integrationLogger.info("[" + getName() + "] Processing '" + afile[j].getName() + "'");
                                mxLog.writeLog(" processFolderData(): Processing '"     + afile[j].getName() + "'");

                                errMessage = new StringBuffer();
                                errMessage = null;
                                isProcErr = false;

                                if(afile[j].getName().startsWith(importFileName)){

                                //Added by WMJ 20120819 for MX7 RecoveryService
                                recoveryService = new RecoveryService(afile[j]);
                                recoveryService.startRecovery();

                                try {
                                        // Copy file to process directory
                                        mxLog.writeLog(" processFolderData(): Copying file to process directory");
                                        String file = processDirectory + afile[j].getName();
                                        MxFileCopy.fileCopy(afile[j].toString(), processDirectory + afile[j].getName());

                                        //WMJ: Removing unzip part as Peoplesoft dat files are not zipped
                                        // Unzip File
                                        //mxLog.writeLog(" processFolderData(): Unzipping File");
                                        //String cmd = unzipExec + SPACE + file;
                                        //if (MxZip.unzipFile(cmd) == 0) {
                                                // Get filename without extension
                                                /*
                                                mxLog.writeLog(" processFolderData(): Getting filename without extension");
                                                int dotPos = file.lastIndexOf(".");
                                                String extractedFile = file.substring(0, dotPos);
                                                mxLog.writeLog(" processFolderData(): filename without extension is: " + extractedFile);
                                                */

                                                mxLog.writeLog(" processFolderData(): Running parseFlatFile(File)");
                                                ArrayList store = new ArrayList();//to store future effective messages
                                                //Collection col = parseFlatFile(extractedFile, store);
                                                                
                                                //Start of check control totals
                                                BufferedReader flatfileReader;
                                                
                                                flatfileReader = new BufferedReader(new FileReader(file));
                                                
                                                LineNumberReader reader  = new LineNumberReader(new FileReader(file));
                                                
								                String curLine;
								                if((curLine = flatfileReader.readLine()) != null)//use this to check if the file reaches the end
								                //for (int i = 0; i < count; i++)//old way of using the record to get the no of lines in file
								                {
								                        String rec_type;//to get the record type. If it is a header line it will not be processed.
								                        int rec_cnt;//to get record count in file
								                        int cnt = 0;//count of lines in file 
								                        
								                        if(curLine.length() != 0){
								                        rec_type = curLine.substring(0, 1);
								                        rec_cnt = Integer.parseInt(curLine.substring(15, 21).trim());
								                        
								                        mxLog.writeLog(" processFolderData(): Ctrl Total rec_type is: " + rec_type);
								
								                        if(rec_type.equals("0")){
									                        
															String lineRead = "";
															while ((lineRead = reader.readLine()) != null) {}
															
															cnt = reader.getLineNumber(); 
															reader.close();
															mxLog.writeLog(" processFolderData(): cnt(count of lines in file) is: " + cnt);
															mxLog.writeLog(" processFolderData(): rec_cnt(from header record) is: " + rec_cnt);
									                    }
									                    
									                    //check if control totals match
									                    if(cnt==(rec_cnt+1)){//header record adds one line to count
										                    
										                    //Process file
										                    Collection col = parseFlatFile(file, store);

			                                                // Create a XML document based on the data from the flat file.
			                                                mxLog.writeLog(" processFolderData(): Creating XML doc");
			                                                Map xmlMap = generateXMLDocument(col);
			
			                                                // Important BufferedInputStream has a size of 2000byte only.
			                                                mxLog.writeLog(" processFolderData(): Running multiSplitPerformed(xmlMap, j)");
			                                                multiSplitPerformed(xmlMap, j);
										                    
										                }
										                else{//record in log and send out email of file with incorrect control totals
										                
										                	mxLog.writeLog(" processFolderData(): file with incorrect control totals - " + file);
										                	String emailCtrlTotal = "Date: " + new Date() + "\n";
											                emailCtrlTotal += "Error in CronTask: " + getName() + "\n";
											                emailCtrlTotal += "Error Message: File with incorrect control totals - " + file + "\n";
										                	
           									                email.send(emailSubj, emailCtrlTotal);
                        								    mxLog.writeLog("Email Sent: \n" + emailCtrlTotal);
											                
											            }
								                        
							                        	}
                                            	}
               									//End of check control totals
                                                
                                                


                                                // Delete Extracted File
                                                //File fExtractedFile = new File(extractedFile);
                                                File fExtractedFile = new File(file);
                                                fExtractedFile.delete();

                                                //Write future transactions to personStore
                                                boolean append = true;
                                                writeTransRec(store, append);

                                        //} else {
                                        //        mxLog.writeLog(" processFolderData(): Unable to unzip file - " + file);
                                        //        throw new Exception("[" + getName()     + "]Unable to unzip file - " + file);
                                        //}
                                } finally {
                                        try {
                                                mxLog.writeLog(" processFolderData(): End Recovery");
                                                integrationLogger.debug("[NewPplsoftCronTask] processFolderData: End Recovery");

                                                recoveryService.endRecovery();
                                        } catch (Exception e) {
                                                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                                        }
                                }
                        }
                        else{
                                integrationLogger.info("[" + getName() + "] '" + afile[j].getName() + "' not processed as it does not fit importfilename");
                                mxLog.writeLog(" processFolderData(): '"        + afile[j].getName() + "' not processed as it does not fit importfilename");
                                }

                                fileprocessed++;

                                if (isProcErr) {
                                        String emailMsg = "Date: " + new Date() + "\n";
                                        emailMsg += "Error in CronTask: " + getName() + "\n";
                                        emailMsg += "File Processing: " + afile[j].getName() + NEWLINE;
                                        emailMsg += errMessage.toString();

                                        email.send(emailSubj, emailMsg);
                                        mxLog.writeLog("Email Sent:\n" + emailMsg);
                                }
                        }

                        if (fileprocessed != 0) {
                                mxLog.writeLog(" processFolderData(): " + fileprocessed + " file(s) processed.");
                                integrationLogger.info("[" + getName() + "] " + fileprocessed + " file(s) processed.");
                        } else {
                                mxLog.writeLog(" processFolderData(): No files was processed!");
                                throw new Exception("[" + getName()     + "]No files was processed!");
                        }
                } else {
                        mxLog.writeLog(" processFolderData(): Unable to read input file '" + importFileName + "'");
                        throw new Exception("[" + getName() + "]Unable to read input file '" + importFileName + "'");
                }

                integrationLogger.debug("[NewPplsoftCronTask] Leaving processFolderData");
                mxLog.writeLog(" processFolderData(): Leaving Processing Data");
        }

        /*
         * Author: YCH
         * Date: 24 Nov 2011 - Parse flat file.
         *
         * 1. Get the Transaction ID from message
         * 2. Process the message based on Transaction ID and Position indexes
         * 3. Add processed vector into collection
         */
        private Collection parseFlatFile(String file, ArrayList store) throws IOException
        {
                integrationLogger.debug("[NewPplsoftCronTask] Entering parseFlatFile");
                mxLog.writeLog(" parseFlatFile(): Start Parse Flat File");

                // Parse the flat file first
                // Reading the import flat file
                BufferedReader flatfileReader;
                Collection col = new Vector();

                //Declare int arrays for converting to get the positions of the fields needed in the messages JOB and SNPCOSTC
                int[] jobFieldFrom;
                int[] jobFieldTo;
                int[] costcFieldFrom;
                int[] costcFieldTo;


                //to call the function to convert paramstring array to int array
                jobFieldFrom = convertStringArraytoIntArray(jobStartPos);
                jobFieldTo = convertStringArraytoIntArray(jobEndPos);
                costcFieldFrom = convertStringArraytoIntArray(costCStartPos);
                costcFieldTo = convertStringArraytoIntArray(costCEndPos);

                flatfileReader = new BufferedReader(new FileReader(file));
                String curLine;
                
                while((curLine = flatfileReader.readLine()) != null)//use this to check if the file reaches the end
                //for (int i = 0; i < count; i++)//old way of using the record to get the no of lines in file
                {
                        String rec_type;//to get the record type. If it is a header line it will not be processed.
                        
                        if(curLine.length() != 0){
                        rec_type = curLine.substring(0, 1);
                        mxLog.writeLog(" parseFlatFile(): rec_type is: " + rec_type);

                        if(rec_type.equals("1"))//to ignore the first line if it is a header
                        //if ((curLine = flatfileReader.readLine()) != null)
                        {
                                integrationLogger.debug("[NewPplsoftCronTask] Read Line : " + curLine);
                                mxLog.writeLog(" parseFlatFile(): Line read is: " + curLine);
                                String transId = curLine.substring(TRANS_ID_BEGIN_INDEX, TRANS_ID_END_INDEX).trim();
                                mxLog.writeLog(" parseFlatFile(): transId is: " + transId);
                                Vector vector = null;
                                if (transId.equals(TRANS_ID_JOB)) {

                                        //to check if new effective date is in the future
                                        int eff_dt = Integer.parseInt(curLine.substring(134, 142).trim());
                                        mxLog.writeLog(" parseFlatFile(): eff_dt is :" + eff_dt);

                                        if(eff_dt>Integer.parseInt(getDateTime())){
                                                        mxLog.writeLog(" parseFlatFile(): Job message in the future ");
                                                        store.add(curLine);
                                                }
                                        else{
                                                vector = processMsg(curLine, jobFieldFrom, jobFieldTo);
                                                }

                                }
                                else if (transId.equals(TRANS_ID_SNPCOSTC)) {
                                	
                                	// Comment: skip old records if SNPCOSTS LOB is invalid and process other records as per normal starts   
                                	    boolean isValidCost =  isValidCostRecord(curLine, costcFieldFrom, costcFieldTo);
                                	    if(isValidCost) {
                                            vector = processMsg(curLine, costcFieldFrom, costcFieldTo);
                                	    }
                                    // Comment: skip old records if SNPCOSTS LOB is invalid and process other records as per normal ends   
                                } else {
                                        integrationLogger.debug("[NewPplsoftCronTask] Invalid transId: " + transId + ", cannot handle this record");
                                        mxLog.writeLog(" parseFlatFile(): Invalid transId: " + transId + ", cannot handle this record");
                                }
                                if (vector != null && vector.size() > 0)
                                {
                                        // Add to a collection
                                        col.add(vector);
                                }
                        }

                        }
                }

                integrationLogger.debug("[NewPplsoftCronTask] parseFlatFile - Valid lines parsed: " + col.size());
                integrationLogger.debug("[NewPplsoftCronTask] Leaving parseFlatFile");
                mxLog.writeLog(" parseFlatFile(): Valid lines parsed: " + col.size());
                mxLog.writeLog(" parseFlatFile(): Finish Parse Flat File");

                return col;
        }

        public String getDateTime()
        {
                DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
                Date date = new Date();
                return dateFormat.format(date);
        }

        /**
         * Process Message Based on length and position indexes.
         * Parse the message into vector
         *
         *
         * @param msg
         * @param length
         * @param startPos
         * @param endPos
         * @return
         *
         * WMJ: Since the startPos and endPos can be repeated and in any order, so the important part is to match the startPos and the endPos.
         * Preferably only the fields required should be processed and in the order of the Pplsoft Message format,
         * ie emplid is always before userid in most Pplsoft messages.
         *
         */
        private Vector processMsg(String msg, int[] startPos, int[] endPos) {

                //WMJ: To remove if loop below as the length of the message might increase, will no longer consider length of message
/*              if (msg.length() != length) {
                mxLog.writeLog("[" + getName() + "][Warning] The string message length is ["
                                                        + msg.length() + "], it's different with the definition length ["
                                                        + length + "]");
        }
*/
        Vector vec = new Vector();
        for (int i = 0; i < startPos.length; i++)
        {
                if (startPos[i] > msg.length())
                {
                        isProcErr = true;
                    String errMsg = NEWLINE + "Line:" + msg + NEWLINE;
                    errMsg += "Error Message: The field's start|end index is larger than message's total length: FieldFrom:["
                                        + startPos[i]   + "] FieldTo:[" + endPos[i] + "]" + NEWLINE;
                                errMessage.append(errMsg);
                        mxLog.writeLog("[" + getName() + "][ERROR] Invalid line:'" + msg+ "'");
                        break;
                }
                if (endPos[i] > msg.length())
                {
                        endPos[i] = msg.length();
                }

                String fieldValue = msg.substring(startPos[i], endPos[i]);
                
                vec.add(fieldValue.trim());
        }

        //code to print out vector for debugging
        for(Iterator i=vec.iterator(); i.hasNext();)
        {
                integrationLogger.debug("processMsg(): Element in vector is: " + i.next());
        }

                return vec;
        }

        
        
// Comment: skip old records if SNPCOSTS LOB is invalid and process other records as per normal starts         
        
    private boolean isValidCostRecord(String msg, int[] startPos, int[] endPos) {
            
    	    boolean isValid = false;
    	    
		    for (int i = 0; i < startPos.length; i++)
		    {
		            if (startPos[i] > msg.length())
		            {
		            	    isValid = true;
		                    break;
		            }
		            if (endPos[i] > msg.length())
		            {
		                    endPos[i] = msg.length();
		            }
		            
		            
		            if(startPos.length == i+1) {
		            	String fieldValue = msg.substring(startPos[i], endPos[i]);
		            	if(fieldValue !=null && fieldValue.length() == 10) {
		            		isValid = true;
		            	}else {
		            		isValid = false;		            
		                    mxLog.writeLog("[" + getName() + "][ERROR] Invalid line:'" + msg+ "'");
		                    break;
		            	}
		            	
		            }
		            
		               
		    }
		
		            return isValid;
        }
        
 // Comment: skip old records if SNPCOSTS LOB is invalid and process other records as per normal ends       
        
        /*
         * Author: YCH 28 NOV 2011 - Send data to JMS queue
         */
        public boolean splitPerformed(byte[] abyte0, String ifaceName, int i)
                        throws Exception {

                integrationLogger.debug("[NewPplsoftCronTask] Entering splitPerformed");

                try {
                        sendMessage(abyte0, ifaceName, i);

                } catch (Exception e) {
                        MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                        if ((e instanceof MXException) && ((MXException) e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
                                MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");
                        throw new Exception(e.getMessage());
                }

                integrationLogger.debug("[NewPplsoftCronTask] Leaving splitPerformed");
                return true;
        }

        /*
     * Author: YCH
     * 01 DEC 2011 - Send a collection of XML data to JMS queue
     *
     */
        public void multiSplitPerformed(Map map, int i) throws Exception {
                integrationLogger.debug("[NewPplsoftCronTask] Entering multiSplitPerformed");
                mxLog.writeLog(" multiSplitPerformed(): Start Sending XML data to queue");

                try {

                        Collection jobCol = (Collection) map.get(TRANS_ID_JOB);
                        Iterator iterJob = jobCol.iterator();
                        while (iterJob.hasNext()) {
                                String xmlData = (String) iterJob.next();
                                if (!xmlData.matches("")) {
                                        splitPerformed(xmlData.getBytes(), ifaceName, i);
                                }
                        }

                        // Clear Job collection
                        jobCol.clear();

                        Collection costcCol = (Collection) map.get(TRANS_ID_SNPCOSTC);
                        Iterator iterCostC = costcCol.iterator();
                        while (iterCostC.hasNext()) {
                                String xmlData = (String) iterCostC.next();
                                if (!xmlData.matches("")) {
                                        splitPerformed(xmlData.getBytes(), ifaceName, i);
                                }
                        }

                        // Clear Cost Center collection
                        costcCol.clear();

                        integrationLogger.debug("[NewPplsoftCronTask] Leaving multiSplitPerformed");
                        mxLog.writeLog(" multiSplitPerformed(): Finish Sending XML data to queue");
                } catch (Exception e) {
                        MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                        if ((e instanceof MXException) && ((MXException) e).getErrorKey().equalsIgnoreCase("unablewritetoqueue")) {
                                MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to spleep");
                        }

                        throw new Exception(e.getMessage());
                }
        }

        /**
         * Author: YCH
         * Create a XML document
         *
         * @param col
         * @return
         * @throws Exception
         */
        private Map generateXMLDocument(Collection col) throws Exception {
                integrationLogger.debug("[NewPplsoftCronTask] Entering generateXMLDocument");
                mxLog.writeLog(" generateXMLDocument(): Start Generating XML Documents");
                int processCount = 0;
                Map xmlMap = new HashMap();
                Collection jobCol = new Vector();
                Collection costcCol = new Vector();
                Iterator iterParsedData = col.iterator();
                while (iterParsedData.hasNext()) {
                        // Vector Element
                        // 0. Record Type
                        // 1. From Column 1
                        // 2. From Column 2
                        // 3. From Column 3
                        // 4. From Column 4

                        // Get new record to convert to XML
                        Vector vec = (Vector) iterParsedData.next();

                        try {
                                integrationLogger.debug("[NewPplsoftCronTask] Line:" + vec.toString());

                                String mboXml = "";

                                String header = (String) vec.elementAt(1);
                                integrationLogger.debug("[NewPplsoftCronTask] Header:" + header);

                                // Create XML interface messages for job, person and person based on the Transaction ID
                                if (header.equalsIgnoreCase("SNPCOSTC")) {
                                        // Process to generate Cost Center XML Message
                                        mboXml = genCostCenterXml(vec);
                                        // Add XML Object to a collection
                                        costcCol.add(mboXml);
                                } else if (header.equalsIgnoreCase("JOB")) {
                                        // Process to generate Job XML Message
                                        mboXml = genJobXml(vec);
                                        // Add XML Object to a collection
                                        jobCol.add(mboXml);
                                }

                        } catch (Exception e) {
                                isProcErr = true;
                                String errMsg = genErrMsg(e, vec);
                                errMessage.append(errMsg);
                                errMessage.append(NEWLINE);
                                mxLog.writeLog(" generateXMLDocument(): [ERROR]" + errMsg);
                        }
                }

                xmlMap.put(TRANS_ID_JOB, jobCol);
                xmlMap.put(TRANS_ID_SNPCOSTC, costcCol);

                processCount = jobCol.size() + costcCol.size();
                // Clear collection
                col.clear();
                integrationLogger.debug("[NewPplsoftCronTask] generateXMLDocument - Valid xml job doc generated: " + jobCol.size());
                integrationLogger.debug("[NewPplsoftCronTask] generateXMLDocument - Valid xml cost center doc generated: " + costcCol.size());
                integrationLogger.debug("[NewPplsoftCronTask] generateXMLDocument - Valid xml total doc generated: " + processCount);
                integrationLogger.debug("[NewPplsoftCronTask] Leaving generateXMLDocument");
                mxLog.writeLog(" generateXMLDocument(): Valid xml job doc generated: " + jobCol.size());
                mxLog.writeLog(" generateXMLDocument(): Valid xml cost center doc generated: " + costcCol.size());
                mxLog.writeLog(" generateXMLDocument(): Valid xml total doc generated: " + processCount);
                mxLog.writeLog(" generateXMLDocument(): Finish Generatering XML Documents");

                return xmlMap;
        }

        // XML tag's
        private final String MSG_START_INTERFACE = " xmlns=\"http://www.ibm.com/maximo\" >";

        private final String TAG_START_LABOR = "<LABOR>";
        private final String TAG_END_LABOR = "</LABOR>";
        private final String TAG_START_LABORCRAFTRATE = "<LABORCRAFTRATE>";
        private final String TAG_END_LABORCRAFTRATE = "</LABORCRAFTRATE>";

        private final String TAG_PERSON_MBO = "PERSON";
        private final String TAG_JOB_MBO = "JOB";
        private final String TAG_COSTC_MBO = "COSTCENTRE";
        private final String TAG_LABOR_MBO = "LABOR";
        private final String TAG_LABORCRAFTRATE_MBO = "LABORCRAFTRATE";

        private final String TAG_EMPLID = "IC";
        private final String TAG_USER_ID = "PERSONID";

        /*
         * Author: YCH 24 NOV 2011 - Generate Job XML
         */
        private String genJobXml(Vector vec) throws Exception {

                integrationLogger.debug("[NewPplsoftCronTask] Entering genJobXml");

                // Create XML
                String xml = "<Sync" + intObject + // Interface name
                                MSG_START_INTERFACE + // xmlns
                                "<" + intObject + "Set>" + // Integration object
                                "<" + TAG_PERSON_MBO + ">" + // Person object that is part of Integration object
                                mxXml.genTagSting(TAG_USER_ID, (String) vec.elementAt(9)) +
                                mxXml.genTagSting(TAG_EMPLID, (String) vec.elementAt(5)) +
                                "<DEPARTMENT>" +
                                //Start of EMS-551
                                StringEscapeUtils.escapeXml((String) vec.elementAt(7)) +
                                //End of EMS-551
                                "</DEPARTMENT>" +
                                "<TITLE>" +
                                StringEscapeUtils.escapeXml((String) vec.elementAt(39)) +
                                "</TITLE>" +
                                "<APPT_TY_C>" +
                                (String) vec.elementAt(25) +
                                "</APPT_TY_C>" +
                                //Start of EMS-551
                                TAG_START_LABOR + // Labor object that is part of Integration object
                                "<ORGID>PSAST</ORGID>" +
                                "<SECTION>"+
                                StringEscapeUtils.escapeXml((String) vec.elementAt(15)) +
                                "</SECTION>" +
                                /*<START> Below code has been modified as part of Oracle to SQL DB conversion 
                                * "<EXTERNAL>1</EXTERNAL>" +
                                */
                                "<PSA_EXTERNAL>1</PSA_EXTERNAL>" +
                                /*
                                 * <END> Above code has been modified as part of Oracle to SQL DB conversion
                                 */
                                "<NTS>0</NTS>" +
                                                                "<WORKWEEK></WORKWEEK>" +
                                                                "<SENIORITY></SENIORITY>" +
                                TAG_END_LABOR +
                                //End of EMS-551
                                "</" + TAG_PERSON_MBO + ">" + // object
                                "</" + intObject + "Set>" + // Integration object
                                "</Sync" + intObject + ">"; // Interface name

                mxLog.writeLog("genJobXml(): XML formed: << " + xml +" >>");
                integrationLogger.debug("[NewPplsoftCronTask] Leaving genJobXml");
                return xml;
        }

        /*
         * Author: YCH 24 NOV 2011 - Generate Cost Center XML
         */
        private String genCostCenterXml(Vector vec) throws Exception {

                integrationLogger.debug("[NewPplsoftCronTask] Entering genCostCenterXml");

                // Create XML
                String xml = "<Sync" + intObject + // Interface name
                                MSG_START_INTERFACE  + // xmlns
                                "<" + intObject + "Set>" + // Integration object
                                "<" + TAG_PERSON_MBO + ">" + // Person object that is part of Integration object
                                mxXml.genTagSting(TAG_USER_ID, (String) vec.elementAt(8)) +
                                mxXml.genTagSting(TAG_EMPLID, (String) vec.elementAt(5)) +
                                "<DEPARTMENT>" +
                                //Start of EMS-551
                                StringEscapeUtils.escapeXml((String) vec.elementAt(6)) +
                                //End of EMS-551
                                "</DEPARTMENT>" +
                                                                "<ICTYPE></ICTYPE>" +
                                TAG_START_LABOR + // Labor object that is part of Integration object
                                "<ORGID>PSAST</ORGID>" +
                                //Start of EMS-551
                                "<SECTION>"+
                                StringEscapeUtils.escapeXml((String) vec.elementAt(10)) +
                                "</SECTION>" +
                                //End of EMS-551
                                /*<START> Below code has been modified as part of Oracle to SQL DB conversion 
                                 * "<EXTERNAL>1</EXTERNAL>" +
                                 */
                                "<PSA_EXTERNAL>1</PSA_EXTERNAL>" +
                                /*<END> Above code has been modified as part of Oracle to SQL DB conversion
                                 */
                                "<NTS>1</NTS>" +
                                                                "<WORKWEEK></WORKWEEK>" +
                                                                "<SENIORITY></SENIORITY>" +
                                TAG_START_LABORCRAFTRATE + // Laborcraftrate object that is part of Integration object
                                "<CONTROLACCOUNT><VALUE>" +
                                //ORG:((String) vec.elementAt(11)).substring(5,9) +
                                //Comment: Add the LOB element
                                ((String) vec.elementAt(11)).substring(3,6) + "-" +
                                ((String) vec.elementAt(11)).substring(6,10) +
                                "</VALUE></CONTROLACCOUNT>" +
                                TAG_END_LABORCRAFTRATE +
                                TAG_END_LABOR +
                                "</" + TAG_PERSON_MBO + ">" + // object
                                "</" + intObject + "Set>" + // Integration object
                                "</Sync" + intObject + ">"; // Interface name

                mxLog.writeLog("genCostCenterXml(): XML formed: << " + xml +" >>");
                integrationLogger.debug("[NewPplsoftCronTask] Leaving genCostCenterXml");
                return xml;
        }

        
        /*
         * Author: YCH 24 NOV 2011 - Sending message to JMS queue.
         */
        private void sendMessage(byte abyte0[], String ifaceName, int i)
                        throws Exception {

                integrationLogger.debug("[NewPplsoftCronTask] Entering sendMessage");

                try {
                        HashMap hashmap = new HashMap();
                        hashmap.put("SENDER", extSys);
                        hashmap.put("INTERFACE", ifaceName);

                        if (queueProcessor == null)
                                queueProcessor = new MEAQueueProcessor();

                        queueProcessor.writeDataToQueueIn(abyte0, hashmap, true);

                        integrationLogger.debug("[NewPplsoftCronTask] Leaving sendMessage");
                } catch (Exception exception) {

                        throw exception;
                }
        }

        /*
         * Define Maximo parameter setting in Cron Task
         */
        private static CrontaskParamInfo params[];
        static {
                // BTE: Set the number of the parameter.
                params = null;
                params = new CrontaskParamInfo[15];

                // BTE: All the parameter configurable from Cron Task user interface
                params[0] = new CrontaskParamInfo();
                params[0].setName("EXTSYSNAME");
                params[0].setDefault("SMS");
                params[0].setDescription("CommonCron","External System Name.");

                params[1] = new CrontaskParamInfo();
                params[1].setName("INTERFACENAME");
                params[1].setDefault("MXSTAFFINFO");
                params[1].setDescription("CommonCron","Integration Interface Name.");

                params[2] = new CrontaskParamInfo();
                params[2].setName("INTOBJECT");
                params[2].setDefault("STAFFINFO");
                params[2].setDescription("CommonCron","Integration Object Name.");

                params[3] = new CrontaskParamInfo();
                params[3].setName("DIRECTORY");
                params[3].setDescription("CommonCron","Directory where input files from Peoplesoft are placed.");

                params[4] = new CrontaskParamInfo();
                params[4].setName("PROCESSDIRECTORY");
                params[4].setDescription("CommonCron","Temp Directory where processing will be done.");

                params[5] = new CrontaskParamInfo();
                params[5].setName("ALERTEMAIL");
                params[5].setDescription("CommonCron","Admin email address for notification of error.");

                params[6] = new CrontaskParamInfo();
                params[6].setName("IMPORTFILENAME");
                params[6].setDescription("CommonCron","File name of the input file(Include with 'yyyymmpd' for previous day files, exclude file extension)");

                params[7] = new CrontaskParamInfo();
                params[7].setName("ALERTEMAILSUBJ");
                params[7].setDescription("CommonCron","Email Subject for the Alert Email.");

                params[8] = new CrontaskParamInfo();
                params[8].setName("ENABLELOG");
                params[8].setDescription("CommonCron","Enable log output('Y' or 'N').");
                params[8].setDefault("Y");

                params[9] = new CrontaskParamInfo();
                params[9].setName("LOGFILEPATH");
                params[9].setDescription("CommonCron","Log Directory and Filename.");

                params[10] = new CrontaskParamInfo();
                params[10].setName("COSTCSTARTPOS");
                params[10].setDescription("CommonCron","Start Positions for CostC Message");

                params[11] = new CrontaskParamInfo();
                params[11].setName("COSTCENDPOS");
                params[11].setDescription("CommonCron","End Positions for CostC Message");

                params[12] = new CrontaskParamInfo();
                params[12].setName("JOBSTARTPOS");
                params[12].setDescription("CommonCron","Start Positions for Job Message");

                params[13] = new CrontaskParamInfo();
                params[13].setName("JOBENDPOS");
                params[13].setDescription("CommonCron","End Positions for Job Message");

                params[14] = new CrontaskParamInfo();
                params[14].setName("PERSONSTORE");
                params[14].setDescription("CommonCron","File store for Job Messages not effective yet");

        }
}
