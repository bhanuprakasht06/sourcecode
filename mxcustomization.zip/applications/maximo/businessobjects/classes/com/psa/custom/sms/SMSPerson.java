package com.psa.custom.sms;

import java.rmi.RemoteException;

import psdi.app.person.PersonRemote;
import psdi.app.person.PersonSetRemote;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXException;

/*
 * Author: BTE
 * 05 APR 2006 - Initial version
 */
public class SMSPerson extends MicSetIn {

	/*
	 * Variables
	 */
	 private UserInfo userInfo;
	 private static SMSConstant SMS = new SMSConstant();
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - constructor  
	 */
	 public SMSPerson(UserInfo userInfo) throws MXException, RemoteException {		 
		 this.userInfo = userInfo;
	 }
	 

	 /*
	 * Author: BTE
	 * 05 APR 2006 - Get supervisor from database based on ic.  
	 */
	 public String getSupervisor(String IC) 
	 	throws MXException, RemoteException {
	   
	     INTEGRATIONLOGGER.debug("Entering getSupervisor");	
	        
		 // Check if vaiables is null
		 if(IC == null ) {
			   return null;
		 }
		 
		 PersonSetRemote personSet = (PersonSetRemote) MXServer.getMXServer().getMboSet(SMS.PERSON, userInfo);
				
		 CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		 combinewhereclauses.addWhere("IC= :1");
		 String s = combinewhereclauses.getWhereClause();
	
		 if(s != null && s != SMS.EMPTY){
			 SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			 sqlformat.setObject(1, SMS.PERSON, SMS.IC, IC);
	
			 personSet.setWhere(sqlformat.format());
			 if(!personSet.isEmpty()) {
		
				 PersonRemote person = (PersonRemote) personSet.getMbo(0);
		
				 if(!person.isNull(SMS.SUPERVISOR)){
				     INTEGRATIONLOGGER.debug("Leaving getSupervisor");
					 return person.getString(SMS.SUPERVISOR);
				 }
			 }
		 }
		 
	     INTEGRATIONLOGGER.debug("Leaving getSupervisor");
		 return null;		   
	 }	 
	 
	 
	 /*
	 * Author: BTE
	 * 05 APR 2006 - Get displayname from database based on ic.  
	 */
	 public String getDisplayName(String IC) 
	 	throws MXException, RemoteException {
	   
	     INTEGRATIONLOGGER.debug("Entering getDisplayName");	
	     
		 // Check if vaiables is null
		 if(IC == null ) {
		     INTEGRATIONLOGGER.debug("Leaving getDisplayName");
			 return null;
		 }
		 
		 PersonSetRemote personSet = (PersonSetRemote) MXServer.getMXServer().getMboSet(SMS.PERSON, userInfo);
				
		 CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		 combinewhereclauses.addWhere("IC= :1");
		 String s = combinewhereclauses.getWhereClause();
	
		 if(s != null && s != SMS.EMPTY){
			 SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			 sqlformat.setObject(1, SMS.PERSON, SMS.IC, IC);
	
			 personSet.setWhere(sqlformat.format());
			 if(!personSet.isEmpty()) {
		
				 PersonRemote person = (PersonRemote) personSet.getMbo(0);
		
				 if(!person.isNull(SMS.DISPLAYNAME)){
				     INTEGRATIONLOGGER.debug("Leaving getDisplayName");
					 return person.getString(SMS.DISPLAYNAME);
				 }
			 }
		 }						
		 
	     INTEGRATIONLOGGER.debug("Leaving getDisplayName");
		 return null;		   
	 }	 
	 
	 
	 /*
	 * Author: BTE
	 * 05 APR 2006 - Get Personid from database based on orgid and ic.  
	 */
	 public String getPersonID(String IC) 
	 	throws MXException, RemoteException {
	   
	     INTEGRATIONLOGGER.debug("Entering getPersonID");
	     
		 // Check if vaiables is null
		 if(IC == null ) {
		     INTEGRATIONLOGGER.debug("Leaving getPersonID");
			 return null;
		 }
		 
		 PersonSetRemote personSet = (PersonSetRemote) MXServer.getMXServer().getMboSet(SMS.PERSON, userInfo);
				
		 CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		 combinewhereclauses.addWhere("IC= :1");
		 String s = combinewhereclauses.getWhereClause();
	
		 if(s != null && s != SMS.EMPTY){
			 SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			 sqlformat.setObject(1, SMS.PERSON, SMS.IC, IC);
	
			 personSet.setWhere(sqlformat.format());
			 if(!personSet.isEmpty()) {
		
				 PersonRemote person = (PersonRemote) personSet.getMbo(0);
		
				 if(!person.isNull(SMS.PERSONID)){
				     INTEGRATIONLOGGER.debug("Leaving getPersonID");
					 return person.getString(SMS.PERSONID);
				 }
			 }
		 }			
			
	     INTEGRATIONLOGGER.debug("Leaving getPersonID");
		 return null;		   
	 }
}

