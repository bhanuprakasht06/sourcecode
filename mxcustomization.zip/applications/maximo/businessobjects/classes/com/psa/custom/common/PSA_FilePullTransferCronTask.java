package com.psa.custom.common;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import com.psa.custom.ois.MxLog;





import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class PSA_FilePullTransferCronTask  extends SimpleCronTask {
	protected static final MXLogger logger = MXLoggerFactory.getLogger("maximo.custom.cronlogger");
	private static final String DATE_TIME_FORMAT_yyyyMMdd = "yyyyMMdd";
	private static final String DATE_TIME_FORMAT_yyyyMM = "yyyyMM";
	private static final String DATE_TIME_FORMAT_yyyy = "yyyy";
	private static final int BUFFER_SIZE = 4096;
	private static final int CONNECT_TIMEOUT = 5000;
	private MxEmail email;
	protected MxLog mxLog;
	
	
	
	//Parameters
	private String alertEmailTo; // Alert mail to
	private String emailSubj; // Alert mail subject
	
	private String archiveFilePath; //Processed directory
	private String inputFilePath; //Input directory with the encrypted files (pull in file path)
	private String outputFilePath; //output file path location with decrypted file
	private String multiFilesPath; // for multiple files (zip) for investigation. Boomi auto zip multiple files 
	
	private String sourcePullServer; // boomi ipaas Source server "DMZ" or "Internal"
	private String sourcePullFolder; // boomi ipaas pull folder path: etc: "/opt/psa/rel/DMZ/GFS-Cloud/EAMS/COA/"
	private String sourcePullFile; // boomi ipaas FilestoPull //can be wildcard for file name pattern-matching (* and ?)
	private String sourcePullFileExt; // Output file Extension
	

	
	private String logFilePath; //Log Directory
	private String logFile; //Log file output
	private String prefix; //Prefix for checking the file. 
	private String OSCmdExec1; //Executable first /Command for Unix command function
	private String OSCmdExec2; //Executable 2nd /Command for Unix command function
	private String OSCmdExec3; //Executable 3rd /Command for Unix command function
	private String OSCmdExec4; //Executable 4th /Command for Unix command function
	private String OSCmdExec5; //Executable 5th /Command for Unix command function
	private String OffsetDate; //Offset date for sourcepullfile date
	private String unzip;
	
	private ArrayList<String> downloadedfileNames;
	
	public CrontaskParamInfo[] getParameters() throws MXException, RemoteException
	{
		CrontaskParamInfo[] params = new CrontaskParamInfo[20];


        params[0] = new CrontaskParamInfo();
        params[0].setName("ALERTEMAILTO");
        params[0].setDescription("ALERTEMAILTO", "ALERT EMAIL");

        params[1] = new CrontaskParamInfo();
        params[1].setName("EMAILSUBJ");
        params[1].setDescription("EMAILSUBJ", "EMAIL SUBJ");

        params[2] = new CrontaskParamInfo();
        params[2].setName("ARCHIVEFILEPATH");
        params[2].setDescription("ARCHIVEFILEPATH", "ARCHIVE FILE PATH");
        
        params[3] = new CrontaskParamInfo();
        params[3].setName("INPUTFILEPATH");
        params[3].setDescription("INPUTFILEPATH", "INPUT FILE PATH");
        
        params[4] = new CrontaskParamInfo();
        params[4].setName("OUTPUTFILEPATH");
        params[4].setDescription("OUTPUTFILEPATH", "OUTPUT FILE PATH");
        
        params[5] = new CrontaskParamInfo();
        params[5].setName("MULTIFILESPATH");
        params[5].setDescription("MULTIFILESPATH", "MULTIPLE FILES PATH");
        
        
        
        params[6] = new CrontaskParamInfo();
        params[6].setName("SOURCEPULLSERVER");
        params[6].setDescription("SOURCEPULLSERVER", "SOURCE PULL SERVER TYPE");
		
        params[7] = new CrontaskParamInfo();
        params[7].setName("SOURCEPULLFOLDER");
        params[7].setDescription("SOURCEPULLFOLDER", "SOURCE PULL FOLDER PATH");

        params[8] = new CrontaskParamInfo();
        params[8].setName("SOURCEPULLFILE");
        params[8].setDescription("SOURCEPULLFILE", "SOURCE PULL FILE");
		
        params[9] = new CrontaskParamInfo();
        params[9].setName("SOURCEPULLFILEEXT");
        params[9].setDescription("SOURCEPULLFILEEXT", "SOURCE PULL FILE EXTENSION");
		
        params[10] = new CrontaskParamInfo();
        params[10].setName("LOGFILEPATH");
        params[10].setDescription("LOGFILEPATH", "LOG FILE PATH");
		

        params[11] = new CrontaskParamInfo();
        params[11].setName("LOGFILE");
        params[11].setDescription("LOGFILE", "LOG FILE");

        
        params[12] = new CrontaskParamInfo();
        params[12].setName("PREFIX");
        params[12].setDescription("PREFIX", "PREFIX");

        
        params[13] = new CrontaskParamInfo();
        params[13].setName("OSCMDEXEC1");
        params[13].setDescription("OSCMDEXEC1", "OS CMD EXEC 1");
        
        params[14] = new CrontaskParamInfo();
        params[14].setName("OSCMDEXEC2");
        params[14].setDescription("OSCMDEXEC2", "OS CMD EXEC 2");

        params[15] = new CrontaskParamInfo();
        params[15].setName("OSCMDEXEC3");
        params[15].setDescription("OSCMDEXEC3", "OS CMD EXEC 3");

        params[16] = new CrontaskParamInfo();
        params[16].setName("OSCMDEXEC4");
        params[16].setDescription("OSCMDEXEC4", "OS CMD EXEC 4");

        params[17] = new CrontaskParamInfo();
        params[17].setName("OSCMDEXEC5");
        params[17].setDescription("OSCMDEXEC5", "OS CMD EXEC 5");
        
        params[18] = new CrontaskParamInfo();
        params[18].setName("OFFSETDATE");
        params[18].setDescription("OFFSETDATE", "OffSet Date for Source PullFile. eg. YEAR:1, MONTH:-1, DAY: -7");
        
        params[19] = new CrontaskParamInfo();
        params[19].setName("UNZIP");
        params[19].setDescription("UNZIP", "Unzip muti-files");
		return params;
	}
	
public PSA_FilePullTransferCronTask() {
		
		super();
		
		alertEmailTo=null;
		emailSubj=null;
		
		archiveFilePath=null;
		inputFilePath=null;
		outputFilePath=null;
		multiFilesPath=null;
        

		sourcePullServer=null;
		sourcePullFolder=null;
		sourcePullFile=null;
		sourcePullFileExt=null;

		logFilePath=null;
		logFile=null;
		prefix=null;
		
		OSCmdExec1=null;
		OSCmdExec2=null;
		OSCmdExec3=null;
		OSCmdExec4=null;
		OSCmdExec5=null;
		OffsetDate=null;
		unzip=null;
	}


	 public void start()
	    {
	        try
	        {
	            refreshSettings();
	            setSleepTime(0L);
	        }
	        catch(Exception exception)
	        {
	        	mxLog.writeLog("Error in crontask : start():" +exception);
	        }
	    }

	 public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
	    {
	        try
	        {
	            super.setCrontaskInstance(crontaskinstanceremote);
	        }
	        catch(Exception exception)
	        {
	        	mxLog.writeLog("Error in crontask : setCrontaskInstance():" + exception);
	        }
	    }
	 
	public void cronAction()
	{
		try
		{
			logger.debug(" at cronAction()"); // Alert mail
			
			refreshSettings();
			
			processData();
			
		}
		catch (Exception e)
		{
			mxLog.writeLog("Error in crontask:" + e);
			String emailContent = genEmail(e);
            email.send(emailSubj, emailContent);
		}
	}
	
    public void init() throws MXException {
        super.init();

        email = new MxEmail(alertEmailTo);
        mxLog = new MxLog();
     
}

private void processData() throws Exception
{
    try
    {
    	mxLog.writeLog("***************  isReqParamSet *********************** ");
        if(isReqParamSet())
        {
        	String sourcepullFullfile = "";
	        DateFormat fileDateTimeFormat;
	        String todayDateTime;
	        DateFormat fDateTimeFormat = new SimpleDateFormat("yyyyMMddhhmmss");
	        String todayfDateTime = fDateTimeFormat.format(new Date());
	         
	        if (sourcePullFile.indexOf("yyyyMMdd") > -1)
	        {
	        	fileDateTimeFormat = new SimpleDateFormat(DATE_TIME_FORMAT_yyyyMMdd);
	        	if ((OffsetDate != null) && (!OffsetDate.trim().equalsIgnoreCase("")))
	        	{
		            todayDateTime = fileDateTimeFormat.format(getOffsetDate(OffsetDate));
	        	}
	        	else
	        	{
	        		todayDateTime = fileDateTimeFormat.format(new Date());
	        	}
	        	sourcePullFile = sourcePullFile.replaceAll(DATE_TIME_FORMAT_yyyyMMdd, todayDateTime);
	        	//sourcepullFullfile = spfile.replaceAll(DATE_TIME_FORMAT_yyyyMMdd, todayfDateTime);
	        }
	        else if (sourcePullFile.indexOf("yyyyMM") > -1)
	        {
	        	fileDateTimeFormat = new SimpleDateFormat(DATE_TIME_FORMAT_yyyyMM);
	        	if ((OffsetDate != null) && (!OffsetDate.trim().equalsIgnoreCase("")))
	        	{
		            todayDateTime = fileDateTimeFormat.format(getOffsetDate(OffsetDate));
	        	}
	        	else
	        	{
	        		todayDateTime = fileDateTimeFormat.format(new Date());
	        	}
	        	sourcePullFile = sourcePullFile.replaceAll(DATE_TIME_FORMAT_yyyyMM, todayDateTime);
	        	//sourcepullFullfile = spfile.replaceAll(DATE_TIME_FORMAT_yyyyMM, todayfDateTime);
	        }
	        else if (sourcePullFile.indexOf("yyyy") > -1)
	        {
	        	fileDateTimeFormat = new SimpleDateFormat(DATE_TIME_FORMAT_yyyy);
	        	if ((OffsetDate != null) && (!OffsetDate.trim().equalsIgnoreCase("")))
	        	{
		            todayDateTime = fileDateTimeFormat.format(getOffsetDate(OffsetDate));
	        	}
	        	else
	        	{
	        		todayDateTime = fileDateTimeFormat.format(new Date());
	        	}
	        	sourcePullFile = sourcePullFile.replaceAll(DATE_TIME_FORMAT_yyyy, todayDateTime);
	        	//sourcepullFullfile = spfile.replaceAll(DATE_TIME_FORMAT_yyyy, todayfDateTime);
	        }
	        sourcepullFullfile = sourcePullFile;
	        
	        String ipaas_weburl = null;
	        String ipaas_deleteurl =null;
	        String ipaas_x_api_key = null;
	        String ipaas_authorization = null;
	        String ipaas_contenttype = null;
	        
	        @SuppressWarnings("deprecation")
			Properties configData = MXServer.getMXServer().getConfig();
			
	        
	        if (sourcePullServer.trim().equalsIgnoreCase("Internal"))
	        {
	        	ipaas_weburl = configData.getProperty("psa.ipaas.pffc.int.weburl");
	        	ipaas_deleteurl = configData.getProperty("psa.ipaas.pffc.int.deleteurl");
	        	ipaas_x_api_key = configData.getProperty("psa.ipaas.pffc.int.x_api_key");
	        	ipaas_authorization = configData.getProperty("psa.ipaas.pffc.int.authorization");
	        	ipaas_contenttype = configData.getProperty("psa.ipaas.pffc.int.contenttype");
	        }
	        else
	        {
	        	ipaas_weburl = configData.getProperty("psa.ipaas.pffc.dmz.weburl");
	        	ipaas_deleteurl = configData.getProperty("psa.ipaas.pffc.dmz.deleteurl");
	        	ipaas_x_api_key = configData.getProperty("psa.ipaas.pffc.dmz.x_api_key");
	        	ipaas_authorization = configData.getProperty("psa.ipaas.pffc.dmz.authorization");
	        	ipaas_contenttype = configData.getProperty("psa.ipaas.pffc.dmz.contenttype");
	        }
	        
	        mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData > Post_JSON_IPAAS_PFFC().weburl:"+ipaas_weburl);
			//System.out.println("~~~PSA_FilePullTransferCronTask.processData > Post_JSON_IPAAS_PFFC().apikey:"+ipaas_x_api_key);
			//System.out.println("~~~PSA_FilePullTransferCronTask.processData > Post_JSON_IPAAS_PFFC().authorization:"+ipaas_authorization);
			//System.out.println("~~~PSA_FilePullTransferCronTask.processData > Post_JSON_IPAAS_PFFC().contenttype:"+ipaas_contenttype);

			if (!multiFilesPath.substring(multiFilesPath.length()-1).equalsIgnoreCase("/"))
			{
				multiFilesPath = multiFilesPath + "/";
				mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.multiFilesPath:"+multiFilesPath);
			}
			if (!outputFilePath.substring(outputFilePath.length()-1).equalsIgnoreCase("/"))
			{
				outputFilePath = outputFilePath + "/";
				mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.outputFilePath:"+outputFilePath);
			}
			if (!inputFilePath.substring(inputFilePath.length()-1).equalsIgnoreCase("/"))
			{
				inputFilePath = inputFilePath + "/";
				mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.inputFilePath:"+inputFilePath);
			}
			
			if (!archiveFilePath.substring(archiveFilePath.length()-1).equalsIgnoreCase("/"))
			{
				archiveFilePath = archiveFilePath + "/";
				mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.archiveFilePath:"+archiveFilePath);
			}
			
			if((!ipaas_weburl.isEmpty()) || (!ipaas_weburl.trim().equalsIgnoreCase("")))
			{
				
				String json = "{ \"Source_server\" : \""+sourcePullServer+
						     "\", \"Source_folder\" : \""+sourcePullFolder+
						     "\", \"FilesToPull\" : \""+sourcePullFile+"*\" }";
				
				mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData > json:"+json);
				
				String inputfile=downloadFile(ipaas_weburl,"POST",ipaas_x_api_key,ipaas_contenttype,ipaas_authorization,json,inputFilePath, false);
				mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData > inputfile:"+inputfile+",sourcepullFullfile:"+sourcepullFullfile);
				if ((inputfile != null) && (!inputfile.trim().equalsIgnoreCase("")))
				{
				        downloadedfileNames	= new ArrayList<>();
						//Comment: if multiple files zip is found move the file to the multiple file path for investigation 
						if (inputfile.indexOf(sourcepullFullfile.replace("*", "")) < 0)
						{
							mxLog.writeLog("~~~001 PSA_FilePullTransferCronTask.processData > inputfile.indexOf(sourcepullFullfile) < 0): true");
							//Comment: Rename file and move the multifile zip to the multiple files folder
							String multifile=null;
							
							if (inputfile.indexOf(".zip") >= 0)
							{
								multifile= multiFilesPath+inputfile.substring(0, inputfile.indexOf(".zip"))+"_"+todayfDateTime+".zip";
							}
							if (inputfile.indexOf(".ZIP") >= 0)
							{
								multifile= multiFilesPath+inputfile.substring(0, inputfile.indexOf(".ZIP"))+"_"+todayfDateTime+".ZIP";
							}
							mxLog.writeLog("~~~002 PSA_FilePullTransferCronTask.processData > inputfile:"+inputFilePath+inputfile+",multifile:"+multifile);
							MxFileCopy.fileCopy(inputFilePath+inputfile,multifile);
							
			    			File deleteMultiFile = new File(inputFilePath+inputfile);
			    			deleteMultiFile.delete();
			    			
			    			
			    			   try (ZipFile zipFile = new ZipFile(multifile)) {
			    		            Enumeration<? extends ZipEntry> entries = zipFile.entries();

			    		            while (entries.hasMoreElements()) {
			    		                ZipEntry entry = entries.nextElement();
			    		                if (!entry.isDirectory()) { // Check if the entry is not a directory
			    		                    String fileName = entry.getName();
			    		                    downloadedfileNames.add(fileName);
			    		                    mxLog.writeLog("~~~002 PSA_FilePullTransferCronTask.InsideZip > ZipInputfile:"+fileName);
			    		                }
			    		            }
			    			   }
			    			   catch (IOException e) {
			    		            e.printStackTrace();
			    		        }
			    			unzipMultiFiles(unzip, multifile);
			    			email.send(emailSubj, "Multiple files are being downloaded, Please investigate zip file:"+multifile);
						}
						else {
							mxLog.writeLog("~~~002 PSA_FilePullTransferCronTask.downloadedFile.Non_Zip_File > NonZipInputfile:"+inputfile);
							downloadedfileNames.add(inputfile);
						}
		
						
						// Enhancement: After processing all the files, We will start deleting the files in Boomi
						
						mxLog.writeLog(getName() + ".cronAction(): Before Deleting Files in Boomi:"+inputFilePath);	
						
						/*mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.deleteFilesParams:ipaas_deleteurl "+ipaas_deleteurl);
						mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.deleteFilesParams:ipaas_x_api_key "+ipaas_x_api_key);
						mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.deleteFilesParams:ipaas_contenttype "+ipaas_contenttype);
						mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.deleteFilesParams:ipaas_authorization "+ipaas_authorization);
						mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.deleteFilesParams:json "+json);*/
						
						deleteFile(ipaas_deleteurl,"POST",ipaas_x_api_key,ipaas_contenttype,ipaas_authorization,false);
						
						mxLog.writeLog(getName() + ".cronAction(): After Deleting Files in Boomi:"+inputFilePath);	
						
											
						//Process it based on the unix commands
						//	else 
						//	{
							mxLog.writeLog("~~~001 PSA_FilePullTransferCronTask.processData > inputfile.indexOf(sourcepullFullfile) < 0): false");
							
							File processdir = new File(inputFilePath);
							//Comment: List of all files and directories.
							String contents[] = processdir.list();
							String sfile = null;
							int iprocess = 0;
							Boolean lprocessunixcmd = false;
							for (int i=0; i<contents.length;i++)
							{
								lprocessunixcmd = false;
								iprocess = 0;
								sfile = contents[i];
								//if sfile.substring(sfile.length()-4, 4).equalsIgnoreCase(".zip")
								mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.folder:"+inputFilePath+", file:"+sfile);
								if (sfile.substring(sfile.length()-(1 + sourcePullFileExt.length())).equalsIgnoreCase("."+sourcePullFileExt))
								{
									if ((prefix != null) && !prefix.trim().equalsIgnoreCase(""))
									{
										if (sfile.startsWith(prefix))
										{
											//Comment: Processing file
											mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.processing file:"+inputFilePath+", file:"+sfile);
											iprocess = 1;
										}
										else { iprocess = 0; }
										
									}
									else { iprocess = 1; }
									if (iprocess == 1)
									{
										if ((OSCmdExec1 != null) && !OSCmdExec1.trim().equalsIgnoreCase(""))
										{
											
											//gpg -q --batch -a -r MAXIMO-GFS --armor --output "${DECRYPT_DIR}${FILENAME}" --decrypt "${OUTPUT_DIR}${FILENAME}"
											//gpg -q --batch -a -r MAXIMO-GFS-2020-05-13 --armor --output "/opt/psa/data/rw/emsscp/incoming/COA/PC_20210201075725.TXT.zip" --decrypt "/opt/psa/data/rw/emsscp/incoming/COA/ENCRYPTED/PC_20210201075725.TXT.zip"
											String cmd = OSCmdExec1;
											cmd = cmd.replace("${OUTPUTFILEPATH}", outputFilePath);
											cmd = cmd.replace("${INPUTFILEPATH}", inputFilePath);
											cmd = cmd.replace("${ARCHIVEFILEPATH}", archiveFilePath);
											cmd = cmd.replace("${FILENAME}", sfile);
											
											mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.cmd 01:"+cmd);
											int retcode= execUnixCmd(cmd);
											if (retcode != 0){
												lprocessunixcmd=false;
												mxLog.writeLog(getName()+".processData.execUnixCmd(): Unable to execute command 01 - " +cmd);
												email.send(emailSubj, "File["+sfile+"]: Unable to execute command 01:"+cmd+", Please check the logs.");
											}
											else lprocessunixcmd = true;
										}
										
										if ((lprocessunixcmd) && (OSCmdExec2 != null) && !OSCmdExec2.trim().equalsIgnoreCase(""))
										{
											
											//mv "${INPUTFILEPATH}${FILENAME}" "${ARCHIVEFILEPATH}${FILENAME}"
											//mv "/opt/psa/data/rw/emsscp/incoming/COA/ENCRYPTED/PC_20210201075725.TXT.zip" "/opt/psa/data/rw/emsscp/incoming/COA/ARCHIVE/PC_20210201075725.TXT.zip"
											String cmd = OSCmdExec2;
											cmd = cmd.replace("${OUTPUTFILEPATH}", outputFilePath);
											cmd = cmd.replace("${INPUTFILEPATH}", inputFilePath);
											cmd = cmd.replace("${ARCHIVEFILEPATH}", archiveFilePath);
											cmd = cmd.replace("${FILENAME}", sfile);
											
											mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.cmd 02:"+cmd);
											int retcode= execUnixCmd(cmd);
											if (retcode != 0){
												lprocessunixcmd=false;
												mxLog.writeLog(getName()+".processData.execUnixCmd(): Unable to execute command 02- " +cmd);
												email.send(emailSubj, "File["+sfile+"]: Unable to execute command 02:"+cmd+", Please check the logs.");
											}
											else lprocessunixcmd = true;
										}
										
										if ((lprocessunixcmd) && (OSCmdExec3 != null) && !OSCmdExec3.trim().equalsIgnoreCase(""))
										{
											
											//gunzip -S .zip "${OUTPUTFILEPATH}${FILENAME}"
											//gunzip -S .zip "/opt/psa/data/rw/emsscp/incoming/COA/PC_20210201075725.TXT.zip"
											String cmd = OSCmdExec3;
											cmd = cmd.replace("${OUTPUTFILEPATH}", outputFilePath);
											cmd = cmd.replace("${INPUTFILEPATH}", inputFilePath);
											cmd = cmd.replace("${ARCHIVEFILEPATH}", archiveFilePath);
											cmd = cmd.replace("${FILENAME}", sfile);
											
											mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.cmd 03:"+cmd);
											int retcode= execUnixCmd(cmd);
											if (retcode != 0){
												lprocessunixcmd=false;
												mxLog.writeLog(getName()+".processData.execUnixCmd(): Unable to execute command 03- " +cmd);
												email.send(emailSubj, "File["+sfile+"]: Unable to execute command 03:"+cmd+", Please check the logs.");
											}
											else lprocessunixcmd = true;
										}
										
										if ((lprocessunixcmd) && (OSCmdExec4 != null) && !OSCmdExec4.trim().equalsIgnoreCase(""))
										{
											String cmd = OSCmdExec4;
											cmd = cmd.replace("${OUTPUTFILEPATH}", outputFilePath);
											cmd = cmd.replace("${INPUTFILEPATH}", inputFilePath);
											cmd = cmd.replace("${ARCHIVEFILEPATH}", archiveFilePath);
											cmd = cmd.replace("${FILENAME}", sfile);
											
											mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.cmd 04:"+cmd);
											int retcode= execUnixCmd(cmd);
											if (retcode != 0){
												lprocessunixcmd=false;
												mxLog.writeLog(getName()+".processData.execUnixCmd(): Unable to execute command 04- " +cmd);
												email.send(emailSubj, "File["+sfile+"]: Unable to execute command 04:"+cmd+", Please check the logs.");
											}
											else lprocessunixcmd = true;
										}

										if ((lprocessunixcmd) && (OSCmdExec5 != null) && !OSCmdExec5.trim().equalsIgnoreCase(""))
										{
											String cmd = OSCmdExec5;
											cmd = cmd.replace("${OUTPUTFILEPATH}", outputFilePath);
											cmd = cmd.replace("${INPUTFILEPATH}", inputFilePath);
											cmd = cmd.replace("${ARCHIVEFILEPATH}", archiveFilePath);
											cmd = cmd.replace("${FILENAME}", sfile);
											
											mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.cmd 05:"+cmd);
											int retcode= execUnixCmd(cmd);
											if (retcode != 0){
												lprocessunixcmd=false;
												mxLog.writeLog(getName()+".processData.execUnixCmd(): Unable to execute command 05- " +cmd);
												email.send(emailSubj, "File["+sfile+"]: Unable to execute command 05:"+cmd+", Please check the logs.");
											}
											else lprocessunixcmd = true;
										}
										
										mxLog.writeLog(getName() + ".cronAction(): Finished processing file:"+sfile+", lprocessunixcmd="+lprocessunixcmd);
									}
								}
							}
							
						
						//} 
						//end of else
						
							mxLog.writeLog(getName() + ".cronAction(): Finished processing folder:"+inputFilePath);
				}
				else
				{
					//print statement
					mxLog.writeLog("~~~PSA_FilePullTransferCronTask:"+inputfile+" downloaded and saved in "+inputFilePath);
				}
				}
        }
        else
        {
        	logger.info("Required Parameters are not set.");
        }
        
    }
    catch(Exception e)
    {
    	mxLog.writeLog("Error in processData crontask:" + e);
    	mxLog.closeLogFile();
    	String emailContent = genEmail(e);
        email.send(emailSubj, emailContent);
    }
    finally
    {
    	mxLog.closeLogFile();
    }
}
    


	private void refreshSettings()
	{
		try 
		{
			
			alertEmailTo = getParamAsString("ALERTEMAILTO");
			email.setAdmin(alertEmailTo);
			emailSubj = getParamAsString("EMAILSUBJ");
			
			archiveFilePath = getParamAsString("ARCHIVEFILEPATH");
			inputFilePath = getParamAsString("INPUTFILEPATH");
			outputFilePath = getParamAsString("OUTPUTFILEPATH");
			multiFilesPath = getParamAsString("MULTIFILESPATH");
	        

			sourcePullServer = getParamAsString("SOURCEPULLSERVER");
			sourcePullFolder = getParamAsString("SOURCEPULLFOLDER");
			sourcePullFile = getParamAsString("SOURCEPULLFILE");
			sourcePullFileExt = getParamAsString("SOURCEPULLFILEEXT");

			logFilePath = getParamAsString("LOGFILEPATH");
			logFile = getParamAsString("LOGFILE");
			prefix = getParamAsString("PREFIX");
				 
			Date curDate = new Date();
			DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
			String fileDateStr = fileDateTimeFormat.format(curDate);
			logFile = logFile.replaceAll("yyyyMMdd", fileDateStr);
				 
			logFilePath =logFilePath+logFile;
			mxLog.setLogFilePath(logFilePath);
			mxLog.setLogTag(getName());
			mxLog.setEnabled(true);
			mxLog.createLogFile();
	             
			
			OSCmdExec1 = getParamAsString("OSCMDEXEC1");
			OSCmdExec2 = getParamAsString("OSCMDEXEC2");
			OSCmdExec3 = getParamAsString("OSCMDEXEC3");
			OSCmdExec4 = getParamAsString("OSCMDEXEC4");
			OSCmdExec5 = getParamAsString("OSCMDEXEC5");
			
			OffsetDate = getParamAsString("OFFSETDATE");
			unzip=getParamAsString("UNZIP");
		}
		catch(Exception exception) 
		{
			logger.info("exception.getMessage() crontask:" + exception);
		}
	}
	 
	private boolean isReqParamSet() 
	{
		if ((archiveFilePath == null) || (archiveFilePath.equalsIgnoreCase(""))) return false;
		if ((inputFilePath == null) || (inputFilePath.equalsIgnoreCase(""))) return false;
		if ((outputFilePath == null) || (outputFilePath.equalsIgnoreCase(""))) return false;
		if ((multiFilesPath == null) || (multiFilesPath.equalsIgnoreCase(""))) return false;
		if ((sourcePullServer == null) || (sourcePullServer.equalsIgnoreCase(""))) return false;
		if ((sourcePullFolder == null) || (sourcePullFolder.equalsIgnoreCase(""))) return false;
		if ((sourcePullFile == null) || (sourcePullFile.equalsIgnoreCase(""))) return false;
		if ((sourcePullFileExt == null) || (sourcePullFileExt.equalsIgnoreCase(""))) return false;
		if ((logFilePath == null) || (logFilePath.equalsIgnoreCase(""))) return false;
		if ((logFile == null) || (logFile.equalsIgnoreCase(""))) return false;
		if ((unzip == null) || (unzip.equalsIgnoreCase(""))) return false;
		return true;
	  
	}
	 
	private String genEmail(Exception e) 
	{
	  // Form Email Message
	  String emailMsg = "Date: " + new Date() + "\n";
	  emailMsg += "Error in CronTask: " + getName() + "\n";
	  emailMsg += "Error Message: " + e.getMessage() + "\n";
	  emailMsg += "Detail:\n";
	  emailMsg += e.toString() + "\n";
	  StackTraceElement element[] = e.getStackTrace();
	  for (int i = 0; i < element.length; i++) 
	  {
	  	emailMsg += "\tat " + element[i].toString() + "\n";
	  }
	
	  return emailMsg;
	}
	
	public String downloadFile(String fileURL,String Reqmethod,String api_key,String contenttype,String authvalue,String json, String saveDir,boolean lretfullfilepath)
    {
		
		URL url = null;
		HttpURLConnection httpConn = null;
		String result = null;
        try
        {
        	url = new URL(fileURL);
        	mxLog.writeLog("~~~PSA_FilePullTransferCronTask.downloadFile > fileURL = " + fileURL);
            httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setConnectTimeout(CONNECT_TIMEOUT);
            httpConn.setRequestProperty("x-api-key", api_key);
            httpConn.setRequestProperty("Content-Type", contenttype);
            httpConn.setRequestProperty("Authorization", authvalue);
			System.out.println("---------1---------");
			httpConn.setDoOutput(true);
			httpConn.setDoInput(true);
			httpConn.setRequestMethod(Reqmethod);
			System.out.println("---------2---------");

			OutputStream os = httpConn.getOutputStream();
			os.write(json.getBytes("UTF-8"));
			os.close(); 
			System.out.println("---------3---------");
	        int responseCode = httpConn.getResponseCode();
	 
	        // always check HTTP response code first
	        if (responseCode == HttpURLConnection.HTTP_OK) {
	            String fileName = "";
	            String disposition = httpConn.getHeaderField("Content-Disposition");
	            String contentType = httpConn.getContentType();
	            int contentLength = httpConn.getContentLength();
	 
	            if (disposition != null) {
	                // extracts file name from header field
	                int index = disposition.indexOf("filename=");
	                if (index > 0) {
	                    fileName = disposition.substring(index + 10,
	                            disposition.length() - 1);
	                }
	            } else {
	                // extracts file name from URL
	                fileName = fileURL.substring(fileURL.lastIndexOf("/") + 1,
	                        fileURL.length());
	            }
	 
	            mxLog.writeLog("~~~PSA_FilePullTransferCronTask.downloadFile > Content-Type = " + contentType);
	            mxLog.writeLog("~~~PSA_FilePullTransferCronTask.downloadFile > Content-Disposition = " + disposition);
	            mxLog.writeLog("~~~PSA_FilePullTransferCronTask.downloadFile > Content-Length = " + contentLength);
	            mxLog.writeLog("~~~PSA_FilePullTransferCronTask.downloadFile > fileName = " + fileName);
	 
	            // opens input stream from the HTTP connection
	            InputStream inputStream = httpConn.getInputStream();
	            
	            if (!saveDir.substring(saveDir.length()-1).equalsIgnoreCase("/"))
				{
	            	saveDir = saveDir + File.separator;
				}
	            String saveFilePath = saveDir + fileName;
	             
	            // opens an output stream to save into file
	            FileOutputStream outputStream = new FileOutputStream(saveFilePath);
	 
	            int bytesRead = -1;
	            byte[] buffer = new byte[BUFFER_SIZE];
	            while ((bytesRead = inputStream.read(buffer)) != -1) {
	                outputStream.write(buffer, 0, bytesRead);
	            }
	            outputStream.flush();
	            outputStream.close();
	            inputStream.close();
	            
	            System.out.println("~~~PSA_FilePullTransferCronTask.downloadFile > File downloaded :"+ saveFilePath);
	            mxLog.writeLog("PSA_FilePullTransferCronTask.downloadFile > File downloaded :"+ saveFilePath);
	            //To check the file extension
	            if (fileName.contains(".") && fileName.lastIndexOf(".") < fileName.length() - 1)
	            {
	            	if (lretfullfilepath) 
		            {
		            	result = saveFilePath; 
		            }
		            else 
		            {
		            	result = fileName;
		            }
	            }
	            else
	            {
	            	System.out.println("The file does not have an extension, returning null.");
	                mxLog.writeLog("PSA_FilePullTransferCronTask.downloadFile > "+fileName+ " does not have an extension, returning null.");
	                result = null;
	            }
	            
	            
	        } else {
	            System.out.println("~~~PSA_FilePullTransferCronTask.downloadFile > No file to download. Server replied HTTP code: " + responseCode);
	            BufferedInputStream errStream = new BufferedInputStream(httpConn.getErrorStream());
				byte[] contents = new byte[1024];
				mxLog.writeLog("PSA_FilePullTransferCronTask.downloadFile > Error return from httpcall:");
				int bytesRead=0;
				
				
				while((bytesRead = errStream.read(contents))!=-1)
				{
					result += new String(contents,0,bytesRead);
        	
				}        
				System.out.println("~~~PSA_FilePullTransferCronTask.downloadFile > ErrorStream:"+result);
				mxLog.writeLog("Error in crontask : DownloadFile: Download Error:" + result);
				errStream.close();
	            result=null;
	        }
        } 
		catch (Exception e) 
		{
			System.out.println(e);
			mxLog.writeLog("Error in crontask : DownloadFile: Download Exception:" + e);
			result=null;
		}
		finally
		{
			httpConn.disconnect();
		}
		return result;
        
    }
	
	
	private void deleteFile(String delete_url, String Reqmethod, String api_key, String contenttype,
			String authvalue, boolean response) {
		// TODO Auto-generated method stub
		URL url = null;
		HttpURLConnection httpConn = null;
		String result = null;
		
		
		mxLog.writeLog("~~~PSA_FilePullTransferCronTask.deleteFile");
		
		for (String delete_file_name : downloadedfileNames) {

        		mxLog.writeLog("~~~PSA_FilePullTransferCronTask.deleteFile:File Names~~~"+delete_file_name);
        		
        		String json_body = "{ \"Source_server\" : \""+sourcePullServer+
        			     "\", \"FilesToDelete\" : \""+sourcePullFolder+delete_file_name+"\" }";
        		
        		mxLog.writeLog("~~~PSA_FilePullTransferCronTask.deleteFile > Json: " + json_body);
        	
        		
                try
                {
                	url = new URL(delete_url);
                	mxLog.writeLog("~~~PSA_FilePullTransferCronTask.deleteFile > fileURL = " + delete_url);
                    httpConn = (HttpURLConnection) url.openConnection();
                    httpConn.setConnectTimeout(CONNECT_TIMEOUT);
                    httpConn.setRequestProperty("x-api-key", api_key);
                    httpConn.setRequestProperty("Content-Type", contenttype);
                    httpConn.setRequestProperty("Authorization", authvalue);
        			System.out.println("---------1---------");
        			httpConn.setDoOutput(true);
        			httpConn.setDoInput(true);
        			httpConn.setRequestMethod(Reqmethod);
        			System.out.println("---------2---------");

        			OutputStream os = httpConn.getOutputStream();
        			os.write(json_body.getBytes("UTF-8"));
        			os.close(); 
        			System.out.println("---------3---------");
        	        int responseCode = httpConn.getResponseCode();
        	 
        	        // always check HTTP response code first
        	        if (responseCode == HttpURLConnection.HTTP_OK) {
        	            String fileName = "";
        	            String disposition = httpConn.getHeaderField("Content-Disposition");
        	            String contentType = httpConn.getContentType();
        	            int contentLength = httpConn.getContentLength();
        	 
        	            if (disposition != null) {
        	                // extracts file name from header field
        	                int index = disposition.indexOf("filename=");
        	                if (index > 0) {
        	                    fileName = disposition.substring(index + 10,
        	                            disposition.length() - 1);
        	                }
        	            } else {
        	                // extracts file name from URL
        	                fileName = delete_url.substring(delete_url.lastIndexOf("/") + 1,
        	                		delete_url.length());
        	            }
        	 
        	            mxLog.writeLog("~~~PSA_FilePullTransferCronTask.deleteFile > Content-Type = " + contentType);
        	            mxLog.writeLog("~~~PSA_FilePullTransferCronTask.deleteFile > Content-Disposition = " + disposition);
        	            mxLog.writeLog("~~~PSA_FilePullTransferCronTask.deleteFile > Content-Length = " + contentLength);
        	            mxLog.writeLog("~~~PSA_FilePullTransferCronTask.deleteFile > fileName = " + fileName);
        	 
        	            
        	            System.out.println("~~~PSA_FilePullTransferCronTask.deleteFile > File deleted :"+ fileName);
        	            mxLog.writeLog("PSA_FilePullTransferCronTask.deleteFile > File deleted :"+ fileName);
        	            if (response) 
        	            {
        	            	result = fileName; 
        	            }
        	            else 
        	            {
        	            	result = fileName;
        	            }
        	            
        	        } else {
        	        	
        	            System.out.println("~~~PSA_FilePullTransferCronTask.downloadFile > No file to delete. Server replied HTTP code: " + responseCode);
        	            BufferedInputStream errStream = new BufferedInputStream(httpConn.getErrorStream());
        				byte[] contents1 = new byte[1024];
        				mxLog.writeLog("PSA_FilePullTransferCronTask.deleteFile > Error return from httpcall:");
        				int bytesRead=0;
        				
        				
        				while((bytesRead = errStream.read(contents1))!=-1)
        				{
        					result += new String(contents1,0,bytesRead);
                	
        				}        
        				System.out.println("~~~PSA_FilePullTransferCronTask.deleteFile > ErrorStream:"+result);
        				mxLog.writeLog("Error in crontask : DeleteFile: Delete Error:" + result);
        				errStream.close();
        	            result=null;
        	            continue;
        	        }
                } 
        		catch (Exception e) 
        		{
        			System.out.println(e);
        			mxLog.writeLog("Error in crontask : DeleteFile: Exception:" + e);
        			result=null;
        		}
        		finally
        		{
        			httpConn.disconnect();
        		}

        }
		
	}
	
	public int execUnixCmd(String cmd) 
			throws IOException,Exception, InterruptedException
	{
			Process proc;
			
			// Execute external command 
			try {
				mxLog.writeLog("PSA_FilePullTransferCronTask.execUnixCmd:"+cmd);
				
				proc = Runtime.getRuntime().exec(cmd);
				
		        int exitVal = proc.waitFor();
		        System.out.println("~~~PSA_FilePullTransferCronTask.execUnixCmd.exitVal:"+exitVal);
		        mxLog.writeLog("Execute Unix Command return:"+exitVal +",Cmd:"+ cmd);
		        int len;
		        if ((len = proc.getErrorStream().available()) > 0)
		        {
		        	byte[] buf=new byte[len];
		        	proc.getErrorStream().read(buf);
		        	System.out.println("~~~PSA_FilePullTransferCronTask.exitVal cmd error:\t\""+new String(buf)+"\"");
		        	mxLog.writeLog("Execute Unix Command ["+cmd+"] - return ["+exitVal+"] cmd error:\t\""+new String(buf)+"\"");
		        }
		        	
		        return exitVal;
				
			} 
			catch (IOException e) {
				throw new IOException(e.getMessage());			 
			} 
			catch (InterruptedException e) {
				throw new InterruptedException(e.getMessage());	
			}
			catch (Exception e) {
				throw new IOException(e.getMessage());			 
			}
	}
	
	public Date getOffsetDate(String OffsetDate) throws IOException,Exception
	{
		//Comment: Expected OffsetDate value: MONTH:-1 , YEAR:2, DAY:-5
		if ((OffsetDate != null) && (!OffsetDate.trim().equalsIgnoreCase("")))
		{
			Integer offvalue = 0;
			
			Calendar cal = Calendar.getInstance();
			if (OffsetDate.indexOf("YEAR:") > -1)
			{
				offvalue = Integer.parseInt(OffsetDate.substring(OffsetDate.indexOf("YEAR:")+5, OffsetDate.length())); 
				cal.add(Calendar.YEAR,offvalue);
			}
			else if (OffsetDate.indexOf("MONTH:") > -1)
			{
				offvalue = Integer.parseInt(OffsetDate.substring(OffsetDate.indexOf("MONTH:")+6, OffsetDate.length())); 
				cal.add(Calendar.MONTH,offvalue);
			}
			else if (OffsetDate.indexOf("DAY:") > -1)
			{
				offvalue = Integer.parseInt(OffsetDate.substring(OffsetDate.indexOf("DAY:")+4, OffsetDate.length())); 
				cal.add(Calendar.DAY_OF_YEAR,offvalue);
			}
				
			return cal.getTime();
		}
		else
		{
			return new Date();
		}
		 
	}
	public static void main( String[] args )
    {
		
        //JSONObject pullfileDetails = new JSONObject();
        //pullfileDetails.put("Source_server", "DMZ");
        //pullfileDetails.put("Source_folder", "/opt/psa/rel/DMZ/GFS-Cloud/EAMS/COA/");
        //pullfileDetails.put("FilesToPull", "*");
      //Add employees to list
        //JSONArray pullfileList = new JSONArray();
        //pullfileList.add(pullfileDetails);
        /*
		DateFormat fDateTimeFormat = new SimpleDateFormat("yyyyMMddhhmmss");
        String todayfDateTime = fDateTimeFormat.format(new Date());
        //System.out.println(pullfileList.toJSONString());
		String inputfile = "/opt/psa/rw/a.ZIP";
		//System.out.println(inputfile.substring(0, inputfile.indexOf(".zip"))+"_"+todayfDateTime+".zip");
		System.out.println(inputfile.substring(inputfile.length()-4));
		//sfile.substring(sfile.length()-4, 4).equalsIgnoreCase(".zip")
		String inputFilePath = "/opt/psa/rw/";
		System.out.println(inputFilePath.substring(inputFilePath.length()-1));
		if (!inputFilePath.substring(inputFilePath.length()-1).equalsIgnoreCase("/"))
		{
			inputFilePath = inputFilePath + "/";
			System.out.println("~~~PSA_FilePullTransferCronTask.processData.inputFilePath:"+inputFilePath);
		}
		*/
		/*
		String OffsetDate="MONTH:-1";
		System.out.println(OffsetDate.substring(OffsetDate.indexOf("MONTH:")+6, OffsetDate.length()));
		try {
			String todayDateTime;
	        DateFormat fDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
			todayDateTime = fDateTimeFormat.format(getOffsetDate(OffsetDate));
			System.out.println("~~~todayDateTime:"+todayDateTime);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 */
    }

public void unzipMultiFiles(String unzip, String multifile) throws Exception
{



unzip = unzip.replace("${MULTIFILE}", multiFilesPath);
unzip = unzip.replace("${INPUTFILE}", multifile);
unzip = unzip.replace("${OUTPUTDIR}", inputFilePath);

mxLog.writeLog("~~~PSA_FilePullTransferCronTask.processData.cmd unzip:"+unzip);

int retcode= execUnixCmd(unzip);
if (retcode != 0){
	mxLog.writeLog(getName()+".processData.execUnixCmd(): Unable to execute command multi file unzip - " +unzip);
	email.send(emailSubj, "File["+multifile+"]: Unable to execute unzip for muti-zip files:"+unzip+", Please check the logs.");
}


}

    
}

