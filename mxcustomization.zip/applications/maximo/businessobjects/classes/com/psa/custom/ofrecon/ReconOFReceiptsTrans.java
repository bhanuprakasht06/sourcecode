/*
 * Created  by BCT 
 * 
 *  
 * This cron is used for  Reconciling check between OF Receipts transaction and Maximo
 * Maximo will receive the Flat file from Del Bomi and put into Location
 * The flat file first file contains all the Maximo objects
 * Flat file from the second line contains the data
 * The flat file second line first component contains the object:attrbuteID (LABTRANS:12345)
 * Based on the Object and AttributeID, need to check in Maximo
 * if data is present need to check the cost(LOADEDCOST). 
 * If the value is matching, update the the following fields OA_RECONDATETIME,OA_COA,OA_LINECOST
 * if data is not present then send error message
 * 
 */
package com.psa.custom.ofrecon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.mail.MessagingException;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;
import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class ReconOFReceiptsTrans extends SimpleCronTask {
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	private static final String DATE_TIME_FORMAT = "yyyyMMdd";


	private String adminEmail;
	private String adminEmailSub;
	private String outPutDirectory;
	private String tempProcessFolder;
	private String processFolder;
	private String backupFileFolder;
	private String importFileName;
	private String splitTag;
	private String unzipCmd;
	private MxEmail email;
	protected MxLog mxLog;
	protected MxLog withOutIdLog;
	private String logFileName;
	private String logFilePath;
	private String withOutIdLogName;
	private String withOutIdLogPath;
	private boolean enableLog;
	private File fileDirctory;
	private String transId;
	private ArrayList parsdata;



	public ReconOFReceiptsTrans() {
		adminEmail=null;
		adminEmailSub=null;
		outPutDirectory=null;
		tempProcessFolder=null;
		processFolder=null;
		backupFileFolder=null;
		importFileName=null;
		unzipCmd=null;
		email=null;
		mxLog=new MxLog();
		withOutIdLog=new MxLog();
		logFileName=null;
		logFilePath=null;
		withOutIdLogName=null;
		withOutIdLogPath=null;
		fileDirctory=null;
		enableLog=false;

	}


	public CrontaskParamInfo[] getParameters() throws MXException,
	RemoteException {

		CrontaskParamInfo[] params = new CrontaskParamInfo[12];

		params[0] = new CrontaskParamInfo();
		params[0].setName("ADMINEMAIL");
		params[0].setDescription("ADMINEMAIL", "Administrator Email ID");

		params[1] = new CrontaskParamInfo();
		params[1].setName("ADMINEMAILSUB");
		params[1].setDescription("ADMINEMAILSUB", "Administrator Email Subject");


		params[2] = new CrontaskParamInfo();
		params[2].setName("TEMPPROCESSFOLDER");
		params[2].setDescription("TEMPPROCESSFOLDER", " Temp Process folder file path");

		params[3] = new CrontaskParamInfo();
		params[3].setName("PROCESSFOLDER");
		params[3].setDescription("PROCESSFOLDER", "Process folder file path");

		params[4] = new CrontaskParamInfo();
		params[4].setName("BACKUPFILEFOLDER");
		params[4].setDescription("BACKUPFILEFOLDER", "Back Up file folder path");

		params[5] = new CrontaskParamInfo();
		params[5].setName("FILENAME");
		params[5].setDescription("FILENAME", "Processing file name");

		params[6] = new CrontaskParamInfo();
		params[6].setName("SPLITTAG");
		params[6].setDescription("SPLITTAG", "SPLITTAG");

		params[7] = new CrontaskParamInfo();
		params[7].setName("UNZIPCMD");
		params[7].setDescription("UNZIPCMD", "Unzip file command");

		params[8] = new CrontaskParamInfo();
		params[8].setName("LOGFILENAME");
		params[8].setDescription("LOGFILENAME", "Log File Name");

		params[9] = new CrontaskParamInfo();
		params[9].setName("LOGFILEPATH");
		params[9].setDescription("LOGFILEPATH", "Log File Path");

		params[10] = new CrontaskParamInfo();
		params[10].setName("ENABLELOG");
		params[10].setDescription("CommonCron","Enable log output('Y' or 'N').");
		params[10].setDefault("Y");

		params[11] = new CrontaskParamInfo();
		params[11].setName("WITHOUTIDLOGFILENAME");
		params[11].setDescription("WITHOUTIDLOGFILENAME", "Log File Path For Data Without Id");

		return params;
	}



	private void refreshSettings() throws RemoteException, MXException
	{
		try
		{
			adminEmail=getParamAsString("ADMINEMAIL");
			adminEmailSub=getParamAsString("ADMINEMAILSUB");
			tempProcessFolder=getParamAsString("TEMPPROCESSFOLDER");

			processFolder=getParamAsString("PROCESSFOLDER");
			fileDirctory=new File(processFolder);

			backupFileFolder=getParamAsString("BACKUPFILEFOLDER");
			//	importFileName=getParamAsString("FILENAME");

			DateFormat fileDateFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
			String todayDate=fileDateFormat.format(new Date());
			//importFileName = getParamAsString("FILENAME");
			//importFileName=importFileName.replaceAll("yyyyMMdd",todayDate);
			
			// Modify to replace with by previous day's if "yyyymmpd" is specified in import file base name
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH,-1);
            String prevDate = fileDateFormat.format(cal.getTime());
            importFileName = getParamAsString("FILENAME").replaceAll("yyyymmpd", prevDate);
			
			splitTag=getParamAsString("SPLITTAG");
			unzipCmd=getParamAsString("UNZIPCMD");
			logFileName=getParamAsString("LOGFILENAME");
			logFilePath=getParamAsString("LOGFILEPATH");
			enableLog=(getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
			withOutIdLogName=getParamAsString("WITHOUTIDLOGFILENAME");
			withOutIdLogPath=getParamAsString("LOGFILEPATH");

			Date curDate = new Date();
			DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
			String logFileDate = fileDateTimeFormat.format(curDate);
			logFileName = logFileName.replaceAll("yyyyMMdd",logFileDate);
			logFilePath =logFilePath+logFileName;
			withOutIdLogPath=withOutIdLogPath+withOutIdLogName;
			mxLog.setLogFilePath(logFilePath);
			mxLog.setLogTag(getName());
			mxLog.setEnabled(enableLog);
			mxLog.createLogFile();
			withOutIdLog.setLogFilePath(withOutIdLogPath);
			withOutIdLog.setLogTag(getName());
			withOutIdLog.setEnabled(enableLog);
			withOutIdLog.createLogFile();

		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}


	}

	private boolean isReqParamSet() {
		if (adminEmail.equalsIgnoreCase(""))
			return false;
		if (adminEmailSub.equalsIgnoreCase(""))
			return false;

		if (tempProcessFolder.equalsIgnoreCase(""))
			return false;
		if (processFolder.equalsIgnoreCase(""))
			return false;
		if (backupFileFolder.equalsIgnoreCase(""))
			return false;
		if (importFileName.equalsIgnoreCase(""))
			return false;
		if (splitTag.equalsIgnoreCase(""))
			return false;
		if (unzipCmd.equalsIgnoreCase(""))
			return false;
		if (logFileName.equalsIgnoreCase(""))
			return false;
		if (logFilePath.equalsIgnoreCase(""))
			return false;
		if (withOutIdLogName.equalsIgnoreCase(""))
			return false;

		return true;
	}
	public void init() throws MXException {
		super.init();

		email = new MxEmail(adminEmail);
		mxLog = new MxLog();

	}

	private String genEmail(Exception e) {

		// Form Email Message
		String emailMsg = "Date: " + new Date() + "\n";
		emailMsg += "Error in CronTask: " + getName() + "\n";
		emailMsg += "Error Message: " + e.getMessage() + "\n";
		emailMsg += "Detail:\n";
		emailMsg += e.toString() + "\n";
		StackTraceElement element[] = e.getStackTrace();
		for (int i = 0; i < element.length; i++) {
			emailMsg += "\tat " + element[i].toString() + "\n";
		}

		return emailMsg;
	}

	public void cronAction() {

		try
		{
			refreshSettings();
			if(isReqParamSet())
			{
				String fileRead=tempProcessFolder+importFileName;
				int dotPos = fileRead.lastIndexOf(".");
				String actualFile=fileRead.substring(0,dotPos);

				if(checkFileExist(importFileName))
				{
					MxFileCopy.fileCopy(processFolder+importFileName,tempProcessFolder+importFileName);

					//WMJ: do backup of file before processing
					MxFileCopy.fileCopy(processFolder+importFileName,backupFileFolder+importFileName);
					//WMJ: end backup of file before processing

					File deleteZipProcessed = new File(processFolder+importFileName);
					deleteZipProcessed.delete();

					if(unZipFileTemp())
					{
					processFolderData(actualFile);
					File processedFile = new File(actualFile);
					processedFile.delete(); 
					mxLog.writeLog("Cron:"+getName()+":File process is completed.");
					}
					
				}
				else
				{
					integrationLogger.debug("File does not found. cron job is Stopped.");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			genEmail(e);
		}

	}

	public boolean checkFileExist (String importFileName) throws MessagingException {

		SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);

		File checkFile[] = fileDirctory.listFiles(filter);

		String currentFileName=importFileName.substring(0,36);

		if(checkFile!=null)
		{
			for (int j = 0; j < checkFile.length; j++) 
			{
				if(checkFile[j].getName().startsWith(currentFileName)){
					integrationLogger.debug("File exists process the file data.");
					return true;
				}
			}


		}
		integrationLogger.debug("File does not exists.");
		mxLog.writeLog("File not found in Processing Folder");
		MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,"File not found in Processing Folder");
		return false;
	}

	private boolean unZipFileTemp() throws Exception
	{
		boolean fileUNZipCompleted=true;
		try{
			String zipoutputFilePath = tempProcessFolder+importFileName;
			String cmd = unzipCmd + " " + zipoutputFilePath;
			int retcode= MxZip.unzipFile(cmd);
			if (retcode != 0){
				fileUNZipCompleted=false;
			}


		}
		catch(Exception e)
		{
			mxLog.writeLog("File Unzip is failed:"+getName()+":"+e.getMessage());
		}
		return fileUNZipCompleted;

	}

	public void processFolderData(String actualFile) throws MXException,Exception {

		try {
			String errorMessage="";
			BufferedReader  flatfileReader = new BufferedReader(new FileReader(actualFile));
			String currentLine;
			ArrayList<String> headerList=new ArrayList<String>();
			ArrayList<String> lineList=new ArrayList<String>();

			while((currentLine=flatfileReader.readLine())!=null)
			{
				try{
					if(!(currentLine.equals("")))
					{
						String recHeadertype = currentLine.substring(0, 1);
						if(recHeadertype.equals("0"))
						{
							headerList.add(currentLine);
						}
						if(recHeadertype.equals("1"))
						{
							lineList.add(currentLine);
						}
					}
				}
				catch (Exception e) {
					mxLog.writeLog("Error on while Processing the folder data:"+getName()+":"+e.getMessage());
				}
			}

			for(int i=0;i<headerList.size();i++)
			{
				int totalRecordsHeaderLevel=0;
				int totalRecordsLineLevel=0;

				BigDecimal totalAmountHeaderLevel=new BigDecimal("0.00");
				BigDecimal totalAmountLineLevel=new BigDecimal("0.00");

				String headerData=headerList.get(i);
				String[] headerValues=headerData.split(splitTag);
				String headerCurrency=headerValues[2];
				if(!(headerValues[3].equals("")))
				{
					totalRecordsHeaderLevel=Integer.parseInt(headerValues[3]);
				}
				if(!(headerValues[4].equals("")))
				{
					totalAmountHeaderLevel=new BigDecimal(headerValues[4]);
				}


				for(int j=0;j<lineList.size();j++)
				{
					int size=lineList.size();

					String lineData=lineList.get(j);
					String[] lineValues=lineData.split(splitTag);
					if(headerCurrency.equals(lineValues[6]))
					{
						if(!(lineValues[9].equals("")))
						{
							totalAmountLineLevel=totalAmountLineLevel.add(new BigDecimal(lineValues[9]));
						}
						totalRecordsLineLevel++;
					}	
				}

				if(totalRecordsHeaderLevel!=totalRecordsLineLevel)
				{
					errorMessage=errorMessage+"\n Mismatch on total number of records between header and line for "+headerCurrency+" currency. \n";
				}
				if(totalAmountHeaderLevel.compareTo(totalAmountLineLevel) != 0)
				{
					errorMessage=errorMessage+"\n Mismatch on total amount between header and line for "+headerCurrency+" currency. \n";
				}

			}

			if (errorMessage.length()>0)
			{
				flatfileReader.close();
				String fileRead=backupFileFolder+importFileName;
				int dotPos = fileRead.lastIndexOf(".");
				String backupfile=fileRead.substring(0,dotPos);
				File deleteProcessedFile = new File(actualFile);
				deleteProcessedFile.delete();
				mxLog.writeLog(errorMessage);
				MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessage+" \nPlease check the Backup folder and process again."+backupfile);
			}
			else			
			{
				Collection fileData=extractFileRead(actualFile);
				processOFTransData(fileData);
				fileData.clear();
				flatfileReader.close();
			}
		}



		catch(Exception e)
		{
			mxLog.writeLog("Error on while Processing the folder data:"+getName()+":"+e.getMessage());
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,"Error on while Processing the folder data:"+getName()+":"+e.getMessage());
		}

	}

	private void processOFTransData(Collection processdata) throws MXException,RemoteException,ParseException, MessagingException
	{
		String[] errorMessages={"","","","",""};

		/*
		 * The different fields present in parsdata
		 *  parsdata.get(0) SOURCE
		 *	parsdata.get(1) oa_recondatetime
		 *	parsdata.get(2) OA_EXCHANGERATE
		 *	parsdata.get(3) OA_CURRENCYCODE
		 *	parsdata.get(4) OA_LOADEDCOST
		 *	parsdata.get(5) OA_TRANSDATE
		 *	parsdata.get(6) OA_PO
		 *	parsdata.get(7) OA_POLINE
		 *	parsdata.get(8) OA_DEBITACC
		 *	parsdata.get(9) OA_CREDITACC
		 *	parsdata.get(10) OA_QUANTITY
		 *	parsdata.get(11) OA_PRICE
		 *	parsdata.get(12) OA_SGPRICE

		 * The Differnet Flags Present
		 * OA_RECON_AMT -->Verification between Maximo and OF for Line Cost
		 * OA_RECON_EXCHG -->Verification between Maximo and OF for Exchange Rate
		 * OA_RECON_CURRENCY -->Verification between Maximo and OF for Currency Code

		 * The Different Error Message
		 * Error [2]: Cost Mismatch for the  Transaction:
		 * Error [3]: Currency Code Mismatch for the Transaction:
		 * Error [4]: Exchange Rate Mismatch for the Transaction:
		 * 
		 */
		
		
		Iterator processOFReconData=processdata.iterator();
		String OfaMessage;
		Date reconDate;
		String transidAndMbo;
		String reconcile_OF;
		String exchangeRateValue_OF;
		String objectName = null;
		String currenyCode_OF;
		String oa_transdate_of;
		String reconcile_quantity;
		String reconcile_price;
		String reconcile_sgprice;
		String oa_po;
		String oa_poline;
		String oa_debitacc;
		String oa_creditacc;
		//String transId = null;
		boolean OA_RECON_AMT;
		boolean OA_RECON_EXCHG;
		boolean OA_RECON_CURRENCY;
		Date transDate_OF;
		Date oa_transdate = null ;
		List<String> transIDList=new ArrayList<String>();
		Set<String> reconSet=new LinkedHashSet<String>();

		while(processOFReconData.hasNext())
		{
			try{
				parsdata=(ArrayList) processOFReconData.next();
				OA_RECON_AMT=false;
				OA_RECON_EXCHG=false;
				OA_RECON_CURRENCY=false;
				if(((String)parsdata.get(0)).contains("TRANS"))
				{
					double oa_loadedcost=0.0;
					double exchangeRate_OF=0.0;
					double oa_quantity=0.0;
					double oa_price=0.0;
					double oa_sgprice=0.0;
					//	String oa_coa="";
					reconcile_OF=(String) parsdata.get(4);
					if(!(reconcile_OF.equals("")))
					{
						oa_loadedcost=Double.parseDouble(reconcile_OF);
					}
					transidAndMbo=(String) parsdata.get(0);
					String[] getactualMbo=transidAndMbo.split(":");
					reconDate=MXServer.getMXServer().getDate();



					//OF exchange rate
					exchangeRateValue_OF=(String)parsdata.get(2);
					if(!(exchangeRateValue_OF.equals("")))
					{
						exchangeRate_OF=Double.parseDouble(exchangeRateValue_OF);
					}

					//OPS Currency Code
					currenyCode_OF=(String) parsdata.get(3);
					oa_transdate_of=(String) parsdata.get(5);
					
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					if(!(oa_transdate_of.equals("")))
					{
						oa_transdate = formatter.parse(oa_transdate_of);
		
					}
					oa_po=(String) parsdata.get(6);
					oa_poline=(String) parsdata.get(7);
					oa_debitacc=(String) parsdata.get(8);
					oa_creditacc=(String) parsdata.get(9);
					reconcile_quantity=(String) parsdata.get(10);
					if(!(reconcile_quantity.equals("")))
					{
						oa_quantity=Double.parseDouble(reconcile_quantity);
					}
					
					reconcile_price=(String) parsdata.get(11);
					if(!(reconcile_price.equals("")))
					{
						oa_price=Double.parseDouble(reconcile_price);
					}					
					
					reconcile_sgprice=(String) parsdata.get(12);
					if(!(reconcile_sgprice.equals("")))
					{
						oa_sgprice=Double.parseDouble(reconcile_sgprice);
					}	
					

					//		oa_coa=(String) parsdata.get(2);

					if(getactualMbo!=null && !transidAndMbo.equalsIgnoreCase(""))
					{
						objectName=getactualMbo[0].trim();
						transId=getactualMbo[1].trim();
						
						if (!objectName.equalsIgnoreCase("")&& !transId.equalsIgnoreCase("")) {

							if(objectName.trim().equalsIgnoreCase("MATRECTRANS") & !transId.trim().equalsIgnoreCase("") )
							{
								MboSetRemote matrecTransSet=MXServer.getMXServer().getMboSet("MATRECTRANS",getRunasUserInfo());
								SqlFormat matrecTransSetSQL=new SqlFormat("MATRECTRANSID='"+transId+"'");
								matrecTransSet.setWhere(matrecTransSetSQL.format());
								matrecTransSet.reset();
								if(!matrecTransSet.isEmpty() & matrecTransSet!=null)
								{

									MboRemote matrectransMbo=matrecTransSet.getMbo(0);
									if(matrectransMbo!= null)
									{
										double loadedCost=matrectransMbo.getDouble("LINECOST");
										double of_exchangeRate = matrectransMbo.getDouble("EXCHANGERATE");
										String currencyCode = matrectransMbo.getString("CURRENCYCODE");
										String issueType= matrectransMbo.getString("ISSUETYPE");
										String matrectrnid= matrectransMbo.getString("MATRECTRANSID");
										String matrectransid=matrectrnid.replace(",", "");
										//System.out.println("Matrectras ID-->"+matrectransid);
										//System.out.println("Issuetype-->"+issueType);
										//System.out.println("trans ID from file-->"+transId);
										
										if(!issueType.equalsIgnoreCase("TRANSFER"))
										{
											//System.out.println(">>>>>>>>>>Transaction not equal to Transfer<<<<<<<<<<");
											matrectransMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_EXCHANGERATE",exchangeRate_OF,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_CURRENCYCODE",currenyCode_OF,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_LINECOST",oa_loadedcost,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_TRANSDATE",oa_transdate,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_PO",oa_po,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_POLINE",oa_poline,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_DEBITACCT",oa_debitacc,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_CREDITACC",oa_creditacc,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_QUANTITY",oa_quantity,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_PRICE",oa_price,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_SGPRICE",oa_sgprice,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_FLAGREC",true,MboConstants.NOACCESSCHECK);
											matrecTransSet.save();
											System.out.println("Update Matrec transaction");
										}
										else if(issueType.equalsIgnoreCase("TRANSFER"))
										{
											//System.out.println(">>>>>>>>>>Transaction equal to Transfer<<<<<<<<<<");
											matrectransMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_EXCHANGERATE",exchangeRate_OF,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_CURRENCYCODE",currenyCode_OF,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_LINECOST",oa_loadedcost,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_TRANSDATE",oa_transdate,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_PO",oa_po,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_POLINE",oa_poline,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_DEBITACCT",oa_debitacc,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_CREDITACC",oa_creditacc,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_QUANTITY",oa_quantity,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_PRICE",oa_price,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_SGPRICE",oa_sgprice,MboConstants.NOACCESSCHECK);
											matrectransMbo.setValue("OA_FLAGREC",true,MboConstants.NOACCESSCHECK);
											matrecTransSet.save();
											System.out.println("Update Matrec transaction");
											
											//System.out.println(">>>>>>>>>Receipt transaction updation starts here<<<<<<<<<<");
											String receiptRef= matrectransMbo.getString("RECEIPTREF");
											String receiptRefNum=receiptRef.replace(",", "");
											//System.out.println("Receipt reference for transfer record-->"+receiptRefNum);
											
											MboSetRemote matrecTransSet1=MXServer.getMXServer().getMboSet("MATRECTRANS",getRunasUserInfo());
											SqlFormat matuseTransSetSQL1=new SqlFormat("MATRECTRANSID='"+receiptRefNum+"'");
											matrecTransSet1.setWhere(matuseTransSetSQL1.format());
											matrecTransSet1.reset();
											//System.out.println("Count of matrectranset1-->"+matrecTransSet1.count());
											if(matrecTransSet1.count()>0)
											{
												MboRemote matrectransMbo1=matrecTransSet1.getMbo(0);
												if(matrectransMbo1 != null)
												{
													matrectransMbo1.setValue("OA_FLAGREC", true, MboConstants.NOACCESSCHECK);
													//matrecTransSet1.save();
													//System.out.println(">>>>>>>>Updated receipt transaction with reference to Transfer transaction");
												}
											}
											matrecTransSet1.save();
											//System.out.println(">>>>>>>>Updated receipt transaction with reference to Transfer transaction");
											//matrecTransSet.save();
											//System.out.println("Update Matrec transaction");
											
										}
										
									}

								}
								else
								{
									errorMessages[1] = errorMessages[1] + "Transaction Data not Present in Maximo:"+"\n\n"+parsdata+"\n";
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}
							}

							else if(objectName.trim().equalsIgnoreCase("SERVRECTRANS") & !transId.trim().equalsIgnoreCase(""))
							{
								MboSetRemote servrecTransSet=MXServer.getMXServer().getMboSet("SERVRECTRANS",getRunasUserInfo());
								SqlFormat servrecTransSetSQL=new SqlFormat("SERVRECTRANSID='"+transId+"'");
								servrecTransSet.setWhere(servrecTransSetSQL.format());
								servrecTransSet.reset();
								if(!servrecTransSet.isEmpty() & servrecTransSet!=null)
								{

									MboRemote servrectransMbo=servrecTransSet.getMbo(0);
									if(servrectransMbo!= null)
									{
										double loadedCost=servrectransMbo.getDouble("LINECOST");
										double exchangeRate = servrectransMbo.getDouble("EXCHANGERATE");
										String currencyCode = servrectransMbo.getString("CURRENCYCODE");
										String servrectid= servrectransMbo.getString("SERVRECTRANSID");
										String servrectrnid=servrectid.replace(",", "");
										System.out.println("Servrectrans id-->"+servrectrnid);
										
										/*if(oa_loadedcost ==loadedCost)
										{
											OA_RECON_AMT = true;

										}
										else
										{
											OA_RECON_AMT = false;
											errorMessages[2]=errorMessages[2] +parsdata+"\n";
											mxLog.writeLog("Cost Mismatch for the SERVRECTRANS Transaction:"+parsdata);
										}
										// To check if the COA from OF and Maximo are same
										// If they are same, then set the flag as True
										if ((currencyCode.equalsIgnoreCase(currenyCode_OF)))
										{
											OA_RECON_EXCHG = true;
										}
										else
										{
											OA_RECON_EXCHG = false;
											errorMessages[3]=errorMessages[3] +parsdata+"\n";
											mxLog.writeLog("Exchange Mismatch for the SERVRECTRANS Transaction:"+parsdata);
										}
										if (exchangeRate == exchangeRate_OF)
										{
											OA_RECON_CURRENCY = true;
										}
										else
										{
											OA_RECON_CURRENCY = false;
											errorMessages[4]=errorMessages[4] +parsdata+"\n";
											mxLog.writeLog("Currency Mismatch for the SERVRECTRANS Transaction:"+parsdata);
										}

										if (OA_RECON_AMT == true && OA_RECON_CURRENCY == true && OA_RECON_EXCHG == true)*/
										//System.out.println(">>>>>>>>>>>>before entering into contiditon<<<<<<<<<<<<<<");
										//if(transId==servrectrnid)
										//{
										//System.out.println(">>>>>>>>>>>>entering into contiditon<<<<<<<<<<<<<<");
										servrectransMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_EXCHANGERATE",exchangeRate_OF,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_CURRENCYCODE",currenyCode_OF,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_LINECOST",oa_loadedcost,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_TRANSDATE",oa_transdate,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_PO",oa_po,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_POLINE",oa_poline,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_DEBITACCT",oa_debitacc,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_CREDITACC",oa_creditacc,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_QUANTITY",oa_quantity,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_PRICE",oa_price,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_SGPRICE",oa_sgprice,MboConstants.NOACCESSCHECK);
										servrectransMbo.setValue("OA_FLAGREC",true,MboConstants.NOACCESSCHECK);
										servrecTransSet.save();
										System.out.println("Update SERVRECTRANS  transaction.");
										//}
									}

								}
								else
								{
									errorMessages[1] = errorMessages[1]+"Transaction Data not Present in Maximo:"+"\n\n"+parsdata+"\n";
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}
							}
						}
						else
						{
							errorMessages[0]=errorMessages[0]+"Transaction Data not Present in Maximo:"+"\n\n"+parsdata+"\n";
							mxLog.writeLog("Incorrect Data present in the file:"+parsdata);
						}
					}
					else
					{
						errorMessages[0]=errorMessages[0]+"Transaction Data not Present in Maximo:"+"\n\n"+parsdata+"\n";
						mxLog.writeLog("Incorrect Data present in the file:"+parsdata);
					}
				}
			}
			catch (Exception e) {
				errorMessages[0]=errorMessages[0]+"Error in Transaction Data:"+"\n\n"+parsdata+"\n\n"+e.getMessage()+"\n\n";
				mxLog.writeLog("Incorrect Data present in the file:"+parsdata+"\n\n"+e.getMessage()+"\n\n");
			}
		}
		if(errorMessages[0].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[0]);
		}
		if(errorMessages[1].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[1]);
		}
		if(errorMessages[2].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Cost Mismatch for the  Transaction:\n\n" + errorMessages[2]);
		}
		if(errorMessages[3].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Currency Code Mismatch for the Transaction:\n\n" + errorMessages[3]);
		}
		if(errorMessages[4].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Exchange Rate Mismatch for the Transaction:\n\n" + errorMessages[4]);
		}

	}

	private Collection extractFileRead(String file) throws IOException {


		Collection col = new ArrayList();
		try
		{

			BufferedReader  flatfileReader = new BufferedReader(new FileReader(file));
			String curLine = flatfileReader.readLine();

			while((curLine = flatfileReader.readLine()) != null)
			{
				String[] data = curLine.split(splitTag);

				ArrayList list =new ArrayList();

				for(int i=0;i<data.length;i++){

					list.add(data[i].trim());
				}


				col.add(list);
			}

			integrationLogger.debug("Flat file parsing is completed");
			flatfileReader.close();
		}
		catch(Exception e)
		{

			mxLog.writeLog("Error On Parsing a flat file:"+getName()+":"+e.getMessage());
			e.printStackTrace();

		}
		return col;
	}


}
