package com.psa.custom.oa12i;

import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import psdi.iface.mic.StructureData;
import psdi.iface.migexits.UserExit;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
 
public class PSA_ProjTxnOutExtUser
  extends UserExit
{
  public StructureData setUserValueOut(StructureData irData)
    throws MXException, RemoteException
  {
     ERPOutExtCustom erpoutext = new ERPOutExtCustom(getUserInfo());
     if (!irData.isCurrentDataNull("OA_EXPENDTYPE"))
    {
    	 System.out.println("+++++++++++++++++++++++++ProjTxn UserExit - ORGID:"+irData.getCurrentData("ORGID"));
       MboRemote worktype = erpoutext.getWorkTypeMbo(irData.getCurrentDataAsString("OA_EXPENDTYPE"), irData.getCurrentData("ORGID"));
       irData.setCurrentData("OA_EXPENDTYPE", worktype.getString("wtypedesc"));
    }
     if (irData.isCurrentDataNull("OA_JE_CATEGORY"))
    {
    	 DateFormat fileDateFormat = new SimpleDateFormat("yyMMdd");
         String todayDate=fileDateFormat.format(new Date());
         System.out.println("+++++++++++++++++++today's Date : "+todayDate);
         String sourceMbo = irData.getCurrentData("SOURCEMBO");
         System.out.println("+++++++++++++++++++Source MBO : "+sourceMbo);
         if (sourceMbo.equalsIgnoreCase("LABTRANS")) {
        	 String batchName = "J-"+todayDate+"";
        	 System.out.println("+++++++++++++++++++Batchname:"+batchName);
        	 irData.setCurrentData("OA_JE_CATEGORY", batchName);
         }
         else if (sourceMbo.equalsIgnoreCase("MATUSETRANS")) {
        	 String batchName = "M-"+todayDate+"";
        	 System.out.println("+++++++++++++++++++Batchname:"+batchName);
        	 irData.setCurrentData("OA_JE_CATEGORY", batchName);
		}   
    }
     
     if (!irData.isGLDataNull("GLDEBITACCT")) {
    	 System.out.println("GLDEBIT--->"+irData.getGL("GLDEBITACCT"));
     }
     if (!irData.isGLDataNull("GLCREDITACCT")) {

    	 System.out.println("GLCREDIT--->"+irData.getGL("GLCREDITACCT"));
    	 }
     
     //BCT Commented as the GL Account is changed to 28-bit in NextGen Maximo 
     //GL mapping code for Maximo-GFS Fusion Integration//
   /*  if (!irData.isGLDataNull("GLDEBITACCT")) {
    	 String maximoDebGL = irData.getGL("GLDEBITACCT");
    	 MboSetRemote coaDebSet=MXServer.getMXServer().getMboSet("CHARTOFACCOUNTS", getUserInfo());
    	 coaDebSet.setWhere("glaccount='"+maximoDebGL+"' and active=1 and psa_gfsglaccount is not null");
    	 coaDebSet.reset();
    	 if (coaDebSet.count()>0) {
    		MboRemote coaDebMbo = coaDebSet.getMbo(0);
			String gfsDebGL=coaDebMbo.getString("PSA_GFSGLACCOUNT");
			irData.setCurrentData("GLDEBITACCT",gfsDebGL);
		} else {
			irData.setCurrentData("GLDEBITACCT",maximoDebGL);
		}
     }
     else {
	    throw new MXApplicationException("iface", "oa_nogldebitpa");
	}
     if (!irData.isGLDataNull("GLCREDITACCT")) {
    	 String maximoCredGL = irData.getGL("GLCREDITACCT");
    	 MboSetRemote coaCredSet=MXServer.getMXServer().getMboSet("CHARTOFACCOUNTS", getUserInfo());
    	 coaCredSet.setWhere("glaccount='"+maximoCredGL+"' and active=1 and psa_gfsglaccount is not null");
    	 coaCredSet.reset();
    	 if (coaCredSet.count()>0) {
    		MboRemote coaCredMbo = coaCredSet.getMbo(0);
			String gfsCredGL=coaCredMbo.getString("PSA_GFSGLACCOUNT");
			irData.setCurrentData("GLCREDITACCT",gfsCredGL);
		} else {
			irData.setCurrentData("GLCREDITACCT",maximoCredGL);
		}
     }
     else {
	    throw new MXApplicationException("iface", "oa_noglcreditpa");
	}
	//BCT comments ends here
	*/
     
     
     return irData;
  }
}
