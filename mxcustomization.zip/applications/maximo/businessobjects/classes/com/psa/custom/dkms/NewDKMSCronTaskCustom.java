package com.psa.custom.dkms;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import com.psa.custom.common.EMSSite;
import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxImportFile;
import com.psa.custom.common.MxLocMeter;
import com.psa.custom.common.MxXml;
import com.psa.custom.ois.EMSAssetIDConversion;
import com.psa.custom.common.MxZip;//added for gunzip

import com.psa.custom.exchangerate.SimpleFilenameFilter;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.jms.MEAQueueProcessor;
import psdi.iface.load.LoadCronTask;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class NewDKMSCronTaskCustom extends LoadCronTask {

    // EMAIL Subject
    private static final String SUBJECT = "[EMS-DKMS] Error: Error occured in flat file import. Cron task stopped.";
    private static final String PARTIAL = "[EMS-DKMS] Warning: Error occured in flat file import.";

        // Variables
    //private static final String SPACE = " ";
    private static final String NEWLINE = "\n\r";
    private static final String isdelta = "Y";
    private static final String inspector = "MXINTADM";

    private static final String SPACE = " ";//added for gunzip

    private static CrontaskParamInfo params[];
    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");

    private boolean isOkToRun;
    private boolean date_from_sourceFile;
    private MEAQueueProcessor queueProcessor;
    private String qualifiedInstanceName;
    private String extSys;
    private String ifaceName;
    private File loadDir;
    private String directory;
    private String splitTag;
    private RecoveryService recoveryService;

    private String administrator;
    private String importFileName;
    private String fullFileName; //Import Full File Name
    private static final String FILE_DATE_TIME_FORMAT = "yyyyMM";
    //private String importFilePath;
    //private String remoteServer;
    //private String scpConfigFile;

    private String metername;

    //private MxDebug debug;
    private MxEmail email;
    private MxXml mxXml;
    private MxImportFile mxFile;

    private StringBuffer errMessage;
    private boolean errEmail;
    private String EMSAssetIDCfgFile; //20060906 HCHA - Config Filename for Location

    EMSAssetIDConversion assetIDConv;

    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: DKMS Cron task constructor initialize default value
     */
    public NewDKMSCronTaskCustom() {

        isOkToRun = true;
        date_from_sourceFile=false;
            recoveryService = null;
            queueProcessor = null;
            qualifiedInstanceName = null;
            queueProcessor = new MEAQueueProcessor();

        extSys = null;
        ifaceName = null;
        loadDir = null;
        directory = null;
        splitTag = null;

        // BTE: Extra parameter to configure cron task.
        //scpConfigFile = null;
        administrator = null;
        importFileName = null;
        fullFileName = null; 
        //importFilePath = null;
        //remoteServer = null;

        metername = null;
                date_from_sourceFile=false;

        // Error handle
        errMessage = null;
        errEmail = false;

        //20060906 HCHA - Config Filename for Location Conversion
        EMSAssetIDCfgFile = null;
        assetIDConv = null;
    }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Send data to JMS queue
     */
        public boolean splitPerformed(byte[] abyte0, String ifaceName, int i) throws Exception {

                //debug.msg("DKMSCronTask.splitPerformed");
                integrationLogger.debug("DKMSCronTask: Entering splitPerformed");

        try {
                sendMessage(abyte0, ifaceName, i);

                } catch (Exception e) {
                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
                    MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");

                throw new Exception(e.getMessage());
                }

                integrationLogger.debug("DKMSCronTask: Leaving splitPerformed");
        return true;
    }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Send a collection of XML data to JMS queue
     */
        public void multiSplitPerformed(Collection col, int i) throws Exception {

                //debug.msg("DKMSCronTask.multiSplitPerformed");
                integrationLogger.debug("DKMSCronTask: Entering multiSplitPerformed");

        try {

                        Iterator iter = col.iterator();
                        while (iter.hasNext()) {
                                String xmlData = (String)iter.next();

                                System.out.println("------------MESSAGE SENT TO MAXIMO-------------");
                        System.out.println(xmlData);


                                splitPerformed(xmlData.getBytes(), ifaceName, i);
                        }

                        // Clear collection
                        col.clear();

                } catch (Exception e) {
                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
                    MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");

                throw new Exception(e.getMessage());
                }

                integrationLogger.debug("DKMSCronTask: Leaving multiSplitPerformed");

        }


        /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Initialize cron task
     */
    public void init() {
        //debug = new MxDebug();
        //debug.setDebug(false);

        //debug.msg("DKMSCronTask.init");
        integrationLogger.debug("DKMSCronTask: Init()");

        email = new MxEmail();
        mxXml = new MxXml();

        mxFile = new MxImportFile();
    }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Start cron task
     */
    public void start() {

        //debug.msg("DKMSCronTask.start");

        try {
            refreshSettings();

            MicUtil.INTEGRATIONLOGGER.info("Load task::" + qualifiedInstanceName + " started for system::" + extSys + " and interface=" + ifaceName);
            setSleepTime(0L);

        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }


        /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Get the parameter value setting from maximo User
     * Interface in configuration
     */
    private void refreshSettings()
    {

        //debug.msg("DKMSCronTask.refreshSettings");
        integrationLogger.debug("DKMSCronTask: Entering refreshSettings");

        try {

            splitTag = getParamAsString("SPLITTAG");

                        String sourcefiledate=getParamAsString("SOURCEFILEDATE");

                        if(sourcefiledate.equalsIgnoreCase("Y"))
                                date_from_sourceFile = true;
                        else
                                date_from_sourceFile = false;

            extSys = getParamAsString("EXTSYSNAME");
            ifaceName = getParamAsString("INTERFACENAME");
            directory = getParamAsString("DIRECTORY");
            loadDir = new File(directory);
            recoveryService = new RecoveryService(loadDir);
            //Removed by WMJ 20120626 for MX7 recoveryService//recoveryService = new RecoveryService(loadDir);
            
            
            //Replace filename by last month if "yyyypm" is specified in full file name
            DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
            //String todayDate=fileDateFormat.format(new Date());
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH,-1);
            String toMonth = fileDateFormat.format(cal.getTime());
            fullFileName = getParamAsString("FULLFILENAME").replaceAll("yyyypm",toMonth);            
            integrationLogger.debug("DKMSCronTask: fullFileName-" + fullFileName);

            /* BTE: Require for getting flat file in remote server and email
             * alert administrator. Require for configuration throught Maximo
             * User Interface.
             */

            administrator = getParamAsString("ALERTEMAIL");
            importFileName = getParamAsString("IMPORTFILENAME");
            metername = getParamAsString("METERNAME");
            //importFilePath = getParamAsString("IMPORTFILEPATH");
            //remoteServer = getParamAsString("REMOTESERVER");
            //scpConfigFile = getParamAsString("SCPCONFIGFILE");

            //20060906 HCHA - Config Filename for Location Conversion
            EMSAssetIDCfgFile = getParamAsString("EMSASSETIDCFGFILE");


        }
        catch(Exception exception) {

            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }

        integrationLogger.debug("DKMSCronTask: Leaving refreshSettings");
    }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Stop cron task
     */
    public void stop() {

                //debug.msg("DKMSCronTask.stop");

                MicUtil.INTEGRATIONLOGGER.info("Flat file polling task::" +
                qualifiedInstanceName +
                " stopped for system::" +
                extSys +
                " and interface=" +
                ifaceName);
    }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Set cron task instance
     */
    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {

        try {
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") +
                "." + crontaskinstanceremote.getString("instancename");
        }
        catch(Exception exception) {
            integrationLogger.error(exception.getMessage(), exception);
        }
    }


    //private static final String dotdot = ":";
    //private static final String asterisk = "*";

    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Cron task function - Retrieve flat file from remote server,
     * process flat file, convert to xml format and import to maximo.
     */
        public void cronAction() {


        //debug.msg("DKMSCronTask.cronAction");
        integrationLogger.info("DKMSCronTask: Entering cronAction");

        if(!isOkToRun) return;



        // Refresh setting before perform cron action
        refreshSettings();

        // Set parameter after refreshSetting
        email.setAdmin(administrator);
        mxFile.setFileType(importFileName);
        errMessage = new StringBuffer();


        try {

                // BTE: Get the Administrator email
                if (administrator == null) throw new Exception("Required parameter not set.");

                // BTE: Get the import flat file from remote server
                if ((importFileName != null) &&  (directory != null)) {



                        // Check file is in local drive?
                        if (!checkFileExist()) {

                                throw new Exception("["+getName()+"]Unable to find input file.");
                                // Get file from remote Server
                                //MxSCP scp = new MxSCP();

                                //String scpParam = scpConfigFile + SPACE +
                                //remoteServer + dotdot + importFilePath + asterisk + mxFile.getFileName() + asterisk + SPACE + directory;

                                //if (scp.getFlatFile(scpParam) != 0) {
                        //      throw new Exception("Cannot get remote file.");
                                //}
                        }

                } else {

                        throw new Exception("Required parameter not set.");
                }


            //20060906 HCHA - Config Filename for Location Conversion
            assetIDConv = new EMSAssetIDConversion(EMSAssetIDCfgFile);

                // Process the import flat file
                processFolderData();

        }
        catch(Exception e) {
            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
            email.send(SUBJECT, e.getMessage());
              stop();
        }

        integrationLogger.info("DKMSCronTask: Leaving cronAction");
        }


        /* Author: BTE
         * Date: 21 FEB 2006
         * Comment: Check file exist in local directory
         */
        public boolean checkFileExist () {

                //debug.msg("DKMSCronTask.checkFileExist");
                integrationLogger.debug("DKMSCronTask: checkFileExist");

                File afile[] = loadDir.listFiles();

                if(afile != null) {
                        int i = afile.length;

                        for(int j = 0; j < i; j++) {

                                if(mxFile.findFileType(afile[j])) {
                                        return true;
                                }
                        }
                }

                return false;
        }


        /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Get the parameter from Cron Task.
     */
    public CrontaskParamInfo[] getParameters() throws MXException, RemoteException {
            return params;
        }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Process the import flat file
     */
    public void processFolderData() throws Exception {

        //debug.msg("DKMSCronTask.processFolderData");
                integrationLogger.debug("DKMSCronTask: Entering processFolderData");
                
           		SimpleFilenameFilter filter = new SimpleFilenameFilter(fullFileName);
		  		
				File afile[] = loadDir.listFiles(filter);


                try {
                        //File afile[] = loadDir.listFiles();

                        if(afile != null) {

                                int i = afile.length;

                                for(int j = 0; j < i; j++) {

                                        if(mxFile.findFileType(afile[j])) {

                                //debug.msg("Start reading flat file.");
                                integrationLogger.debug("DKMSCronTask: Processing file '"+afile[j].getName()+"'");

                                //Added by WMJ 20120626 for MX7 RecoveryService
                                //recoveryService = new RecoveryService(afile[j]);
                                //recoveryService.startRecovery();
                                
                                try {

                                    //start gunzip for RFS file
                                    String filename = directory + afile[j].getName();
                                    String unzipExec = "gunzip -f -q";

                                    String cmd = unzipExec + SPACE + filename;
                                if ( MxZip.unzipFile(cmd)== 0 )
                                {

                                    //Get filename without extension
                                int dotPos = filename.lastIndexOf(".");
                                String file = filename.substring(0,dotPos);

                                        // Parse DKMS flat file
                                //String file = afile[j].toString();
                                Collection col = parseFlatFile(file);

                                // Create a XML document based on the data from the flat file.
                                Collection xmlCol = generateXMLDocument(col);
                                
                                //Delete Extracted File
	                   			File fExtractedFile = new File(file);
	                   			fExtractedFile.delete();

                                // Important BufferedInputStream has a size of 2000byte only.
                                multiSplitPerformed(xmlCol, j);

                                if (errEmail) {
                                        String msg = "[EMS-DKMS] Warning: File Parse error for the following: " +
                                                NEWLINE +
                                                errMessage;

                                                MicUtil.INTEGRATIONLOGGER.error(msg);
                                    email.send(PARTIAL, msg);

                                }

                                }
                                else
                                {
                                        throw new Exception("["+getName()+"]Unable to unzip file - " + filename);
                                }
                                //end gunzip for RFS file
                                
                                recoveryService = new RecoveryService(afile[j]);

                                } finally {
                                        try {
                                                recoveryService.endRecovery();

                                        } catch(Exception e){
                                                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);

                                        }
                                }
                        }
                    }
                }
                }
        catch(Exception e)
        {

            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
            email.send(SUBJECT, "[EMS-DKMS] Error: Error processing DKMS data.");

            stop();
        }

        integrationLogger.debug("DKMSCronTask: Leaving processFolderData");
        }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Parse DKMS flat file.
     */
    private Collection parseFlatFile(String file) throws Exception {

        //debug.msg("DKMSCronTask.parseFlatFile");
        integrationLogger.debug("DKMSCronTask: Entering parseFlatFile");


        // BTE: Parse the DKMS flat flat file first
        // Reading the import flat file
        BufferedReader flatfileReader;
        Collection col = new Vector();

                flatfileReader = new BufferedReader(new FileReader(file));

        String curLine = null;

        // Process record.
        StringTokenizer stringTokenizer = null;

           while((curLine = flatfileReader.readLine()) != null)
           {
 //Begin change
                 if(curLine.trim().length()==0)
                           break;


                 Vector vec = new Vector();


             if(date_from_sourceFile)
             {
                stringTokenizer = new StringTokenizer(curLine, splitTag);

                if (stringTokenizer.countTokens() == 4 )

                    {
                         while(stringTokenizer.hasMoreElements())
                    {
                        String curValue = String.valueOf(stringTokenizer.nextElement());

                        // Add to element to vector.

                        vec.add(curValue.trim());
                        //debug.msg(curValue.trim());
                    }

                    // Add to a collection
                    col.add(vec);
                } else{
                                errEmail = true;
                                errMessage.append(curLine + NEWLINE);
                          }
             }else if (!date_from_sourceFile)
             {
                stringTokenizer = new StringTokenizer(curLine, splitTag);

                if(stringTokenizer.countTokens() == 4){
                  curLine=curLine.substring(0,curLine.lastIndexOf(splitTag));
                   stringTokenizer = new StringTokenizer(curLine, splitTag);
                }

                if (stringTokenizer.countTokens() == 3)
                {
                                 while(stringTokenizer.hasMoreElements())
                    {
                       String curValue = String.valueOf(stringTokenizer.nextElement());

                        // Add to element to vector.

                        vec.add(curValue.trim());
                        //debug.msg(curValue.trim());
                       }

                    // Add to a collection
                    col.add(vec);
                } else{

                        errEmail = true;
                        errMessage.append(curLine + NEWLINE);
                }
             }
// END CHANGE

       }
        integrationLogger.debug("DKMSCronTask: Leaving parseFlatFile");
        return col;
    }



    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Create a XML document
     */
    private Collection generateXMLDocument(Collection col) throws Exception
    {
                //debug.msg("DKMSCronTask.generateXMLDocument");
                integrationLogger.debug("DKMSCronTask: Starting generateXMLDocument");
                String sDate=null;
                Collection xmlCol = new Vector();

        MxLocMeter locMeter = new MxLocMeter(getRunasUserInfo());
        DateFormat timeStampFormat = null;

  // START CHANGE

        if (importFileName.equalsIgnoreCase(mxFile.getYYYYMMPD())) {

                timeStampFormat = new SimpleDateFormat(mxFile.getYYYYMMPDFormat());
                sDate=mxFile.getFileName(); // START/STOP  CHANGE

        }else

 // END CHANGE

        if (importFileName.equalsIgnoreCase(mxFile.getYYYYPM())) {

                timeStampFormat = new SimpleDateFormat(mxFile.getYYYYPMFormat());
                sDate=mxFile.getFileName(); // START/STOP  CHANGE

        }else if (importFileName.equalsIgnoreCase(mxFile.getYYYYMM())) {

                timeStampFormat = new SimpleDateFormat(mxFile.getYYYYMMFormat());
                sDate=mxFile.getFileName(); // START/STOP  CHANGE

        } else if (importFileName.equalsIgnoreCase(mxFile.getYYYYMMDD())) {

                timeStampFormat = new SimpleDateFormat(mxFile.getYYYYMMDDFormat());
                sDate=mxFile.getFileName(); // START/STOP  CHANGE

        } else if(importFileName.length() > 15){

                int fileLength=importFileName.length();
                fileLength=fileLength-4;
                int index=importFileName.lastIndexOf("_");
                index=index+1;
                sDate=importFileName.substring(index,fileLength);
                if(sDate.length()==6)   // To make sure the date is in YYYYMMDD format
                {

                        sDate=sDate+"01";

                        DateFormat  format_date= new SimpleDateFormat("yyyyMMdd");
                        java.util.Date d=format_date.parse(sDate);

                        Calendar cal=Calendar.getInstance();
                cal.setTime(d);
                cal.add(Calendar.MONTH, 1);
                cal.add(Calendar.DATE, -1);

                sDate=format_date.format(cal.getTime());
                }


        }

        String locMeterXml = null;

                Iterator iterParsedData = col.iterator();
                while (iterParsedData.hasNext()) {

                //debug.msg("generateXMLDocument.Loop");

                        // Get new record to convert to XML
                Vector vec = (Vector)iterParsedData.next();
                locMeterXml = null;

                integrationLogger.debug("DKMSCronTask.generateXMLDocument: Processing Location: "+vec.elementAt(0));

                // ImportFile Name is YYYMM or YYYYMMDD or YYYYPM
                if (importFileName.equalsIgnoreCase(mxFile.getYYYYMM()) ||
                                importFileName.equalsIgnoreCase(mxFile.getYYYYMMDD()) ||
                                importFileName.equalsIgnoreCase(mxFile.getYYYYPM()) ||
                                importFileName.equalsIgnoreCase(mxFile.getYYYYMMPD()) ) {

                        Date readingDate = locMeter.getLastReadingDate((String) vec.elementAt(0), metername);

                        if (readingDate != null) {

                                //If file name is previous month format, change reading date to one month back
                                if(importFileName.equalsIgnoreCase(mxFile.getYYYYPM())){
                                        Calendar cal = Calendar.getInstance();
                                        cal.setTime(readingDate);
                                        cal.add(Calendar.MONTH,-1);
                                        readingDate = cal.getTime();
                                                }

                // START CHANGE

                                //If file name is previous date, change reading date to one DAY back
                                if(importFileName.equalsIgnoreCase(mxFile.getYYYYMMPD())){
                                        Calendar cal = Calendar.getInstance();
                                        cal.setTime(readingDate);
                                        cal.add(Calendar.DATE,-1);
                                        readingDate = cal.getTime();
                                                }

                // END CHANGE


                                String latestReadingDate = timeStampFormat.format(readingDate);


                                if (!latestReadingDate.equalsIgnoreCase(mxFile.getFileName())) {
                                        //debug.msg("generateXMLDocument.Loop.NotExist");
                                        integrationLogger.debug("DKMSCronTask.generateXMLDocument: New reading");

                                        locMeterXml = genLocMeterXml(TAG_MXLOCMETER, TAG_LOCMETER, vec,sDate);
                                }

                        } else { // No meter reading exists in location
                                //debug.msg("generateXMLDocument.Loop.FirstReading");
                                integrationLogger.debug("DKMSCronTask.generateXMLDocument: No existing meter reading");

                                locMeterXml = genLocMeterXml(TAG_MXLOCMETER, TAG_LOCMETER, vec,sDate);
                        }
                } else if (timeStampFormat == null) { // ImportFile Name is not YYYYMM or YYYYMMDD or YYYYPM
                        //debug.msg("generateXMLDocument.Loop.Exact");
                        integrationLogger.debug("DKMSCronTask.generateXMLDocument: Exact Filename");

                        locMeterXml = genLocMeterXml(TAG_MXLOCMETER, TAG_LOCMETER, vec,sDate);
                }

                if (locMeterXml != null) {
                        xmlCol.add(locMeterXml);
                }
        }


        // Clear collection
        col.clear();
        integrationLogger.debug("DKMSCronTask: Leaving generateXMLDocument");
        return xmlCol;
    }

        //updated by WMJ on 20120821
        // XML tag's
/*    private final String MSG_START_INTERFACE =
        " xmlns=\"http://www.ibm.com/maximo\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" language=\"EN\">";

        private final String TAG_START_HEADER ="<Header operation=\"Notify\" event=\"0\">";
        private final String TAG_END_HEADER = "</Header>";

        private final String TAG_SENDERID = "SenderID";

        private final String TAG_START_CONTENT = "<Content>";
        private final String TAG_END_CONTENT = "</Content>";

        private final String TAG_MXLOCMETER = "MXLOCMETER";
        private final String TAG_LOCMETER = "LOCATIONMETER";

        private final String TAG_ORGID = "ORGID";
        private final String TAG_SITEID = "SITEID";
        private final String TAG_LOCATION = "LOCATION";
        private final String TAG_METERNAME = "METERNAME";
        private final String TAG_ISDELTA = "ISDELTA";
        private final String TAG_INSPECTOR = "INSPECTOR";
        private final String TAG_NEWREADINGDATE = "NEWREADINGDATE";
        private final String TAG_NEWREADING = "NEWREADING";
*/
        private final String MSG_START_INTERFACE =
        " xmlns=\"http://www.ibm.com/maximo\" >";

        //private final String TAG_START_HEADER ="<Content>";
        //private final String TAG_END_HEADER = "</Content>";

        //private final String TAG_SENDERID = "SenderID";

        private final String TAG_START_CONTENT = "<MXLOCMETERSet>";
        private final String TAG_END_CONTENT = "</MXLOCMETERSet>";

        private final String TAG_MXLOCMETER = "MXLOCMETER";
        private final String TAG_LOCMETER = "LOCATIONMETER";

        private final String TAG_ORGID = "ORGID";
        private final String TAG_SITEID = "SITEID";
        private final String TAG_LOCATION = "LOCATION";
        private final String TAG_METERNAME = "METERNAME";
        private final String TAG_ISDELTA = "ISDELTA";
        private final String TAG_INSPECTOR = "INSPECTOR";
        private final String TAG_NEWREADINGDATE = "NEWREADINGDATE";
        private final String TAG_NEWREADING = "NEWREADING";

                // Format definitions
        private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+08:00'";

    /* Author: BTE
     * Date: 23 FEB 2006
     * Comment: Generate Locations XML
     */
    private String genLocMeterXml(String intObject, String obj, Vector vec,String sDate) throws Exception {

        //debug.msg("DKMSCronTask.genLocXml");
        integrationLogger.debug("DKMSCronTask: Entering genLocXml");

//        DateFormat timeStampFormat = new SimpleDateFormat(DATE_TIME_FORMAT);

                // Xml value

        String location = assetIDConv.getRightAssetId((String) vec.elementAt(0));
        String newReading = (String) vec.elementAt(2);


//Begin change

        String newReadingDate=null;
        DateFormat timeStampFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
        DateFormat  sourcefile_date= new SimpleDateFormat("yyyyMMdd");
        String sDate_local=null;

        if(date_from_sourceFile){
                try{
                sDate_local=(String) vec.elementAt(3);
                java.util.Date d=sourcefile_date.parse(sDate_local);
                Calendar cal=Calendar.getInstance();
                cal.setTime(d);

                newReadingDate=timeStampFormat.format(cal.getTime());


                }catch(Exception e)
                {
                        e.getMessage();
                }
        }
        else if(importFileName != null && !date_from_sourceFile)
        {
                try{
                        if(sDate.length()==6)
                        {
                                sDate=sDate+"01";

                        DateFormat  format_date= new SimpleDateFormat("yyyyMMdd");
                                java.util.Date d=format_date.parse(sDate);

                                Calendar cal=Calendar.getInstance();
                        cal.setTime(d);
                        cal.add(Calendar.MONTH, 1);
                        cal.add(Calendar.DATE, -1);

                        sDate=format_date.format(cal.getTime());
                }

                //int date_leng=sDate.length()-4;
                sDate_local=sDate;
                //sDate_local=sDate.substring(date_leng-8, date_leng);
                java.util.Date d=sourcefile_date.parse(sDate_local);
                Calendar cal=Calendar.getInstance();
                cal.setTime(d);
                newReadingDate = timeStampFormat.format(cal.getTime());


                }catch(Exception e)
                {
                        e.printStackTrace();
                }
        }
//End change

                // Site id
        String siteId =  null;
        EMSSite site = null;
                site = new EMSSite((String)location, getRunasUserInfo());
        siteId = site.getSiteID();
        String orgId = site.getOrgID();

                if (siteId == null) {

                errEmail = true;
                errMessage.append(location +
                                " does not exists." +
                                NEWLINE);

                return null;
                }

                //Updated by WMJ on 20120821
                // Create XML
                String xml =
                "<SyncMXLOCMETER" + // Interface name
                        MSG_START_INTERFACE +
                        //TAG_START_HEADER +
                        //mxXml.genTagSting(TAG_SENDERID, extSys) + // External system
                        //TAG_END_HEADER +
                        TAG_START_CONTENT +
                        //"<" + intObject + ">" + //Integration object
                        "<" + obj + ">" + // object
                        mxXml.genTagSting(TAG_ORGID, orgId) +
                        mxXml.genTagSting(TAG_SITEID, siteId) +
                        mxXml.genTagSting(TAG_LOCATION, location) +
                        mxXml.genTagSting(TAG_METERNAME, metername) +
                        mxXml.genTagSting(TAG_ISDELTA, isdelta) +
                        mxXml.genTagSting(TAG_INSPECTOR, inspector) +
                        mxXml.genTagSting(TAG_NEWREADINGDATE, newReadingDate) +
                        mxXml.genTagSting(TAG_NEWREADING, newReading) +
                        "</" + obj + ">" + // object
                        //"</" + intObject + ">" + //Integration object
                        TAG_END_CONTENT +
                        "</SyncMXLOCMETER>"; // Interface name

                integrationLogger.debug("DKMSCronTask: Leaving genLocXml");
        return xml;
    }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Sending message to JMS queue.
     */
    private void sendMessage(byte abyte0[], String ifaceName, int i) throws Exception {

        //debug.msg("DKMSCronTask.sendMessage");
        integrationLogger.debug("DKMSCronTask: Entering sendMessage");

        try {
            HashMap hashmap = new HashMap();
            hashmap.put("SENDER", extSys);
            hashmap.put("INTERFACE", ifaceName);

            if(queueProcessor == null)
                queueProcessor = new MEAQueueProcessor();

            queueProcessor.writeDataToQueueIn(abyte0, hashmap, true);
            }
            catch(Exception exception) {

                throw exception;
            }

            integrationLogger.debug("DKMSCronTask: Leaving sendMessage");
        }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Define Maximo parameter setting in Cron Task
     */
    static
    {
        // BTE: Set the number of the parameter.
        params = null;
        params = new CrontaskParamInfo[11];

        // BTE: All the parameter configurable from Cron Task user interface
        params[0] = new CrontaskParamInfo();
        params[0].setName("SPLITTAG");
        params[0].setDefault("~");
        params[1] = new CrontaskParamInfo();
        params[1].setName("EXTSYSNAME");
        params[1].setDefault("DKMS");
        params[2] = new CrontaskParamInfo();
        params[2].setName("INTERFACENAME");
        params[2].setDefault("MXLOCMETERInterface");
        params[3] = new CrontaskParamInfo();
        params[3].setName("DIRECTORY");
        params[4] = new CrontaskParamInfo();
        params[4].setName("ALERTEMAIL");
        params[5] = new CrontaskParamInfo();
        params[5].setName("IMPORTFILENAME");
        params[6] = new CrontaskParamInfo();
        params[6].setName("TARGETENABLED");
        params[6].setDefault("0");
        params[7] = new CrontaskParamInfo();
        params[7].setName("METERNAME");
        params[7].setDefault("DIESEL");

        //20060906 HCHA - Config Filename for Location
        params[8] = new CrontaskParamInfo();
        params[8].setName("EMSASSETIDCFGFILE");
        //params[8].setDescription("Config Filename for Location Conversion.");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
                params[8].setDescription("CommonCron","ConfigFilename");
                //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[9] = new CrontaskParamInfo();
        params[9].setName("SOURCEFILEDATE");
        params[9].setDefault("N");
        
        params[10] = new CrontaskParamInfo();
        params[10].setName("FULLFILENAME");
        params[10].setDefault("asx_monthly_fuel_yyyypm.txt.gz");

        //params[4] = new CrontaskParamInfo();
        //params[4].setName("SCPCONFIGFILE");
        //params[7] = new CrontaskParamInfo();
        //params[7].setName("IMPORTFILEPATH");
        //params[8] = new CrontaskParamInfo();
        //params[8].setName("REMOTESERVER");
    }

}
