// Decompiled by DJ v3.0.0.63 Copyright 2002 Atanas Neshkov  Date: 3/21/2011 3:11:58 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   MxLog.java

package com.psa.custom.ois;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Date;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class MxLog
{

    public String getLogTag()
    {
        return logTag;
    }

    public void setLogTag(String logTag)
    {
		System.out.println("--inside setLogTag--logTag--" + logTag);
        this.logTag = logTag;
    }

    public MxLog()
    {
        isEnabled = false;
        logFilePath = "stdout";
    }

    public MxLog(String logFilePath, boolean isEnabled)
    {
        this.logFilePath = logFilePath;
        this.isEnabled = isEnabled;
    }

    public void createLogFile()
        throws Exception
    {
		System.out.println("--inside create LogFile--");
        if(isEnabled)
            if(logFilePath.equalsIgnoreCase("stdout"))
                logWriter = System.out;
            else
            if(logFilePath.equalsIgnoreCase("stderr"))
            {
                logWriter = System.err;
            } else
            {
                isSystem = false;
                logWriter = new PrintStream(new FileOutputStream(logFilePath, true));
            }
		System.out.println("--end of  create LogFile--");
    }

    public void closeLogFile()
        throws Exception
    {
        if(logWriter == null)
            return;
        logWriter.println("");
        logWriter.flush();
        if(!isSystem)
            logWriter.close();
    }

    public void writeLog(String s)
    {
        String logline;
        logline = (new StringBuilder()).append(new Date()).append(" [").append(logTag).append("] ").append(s).toString();
        if(!isEnabled)
            
        if(logWriter == null)
            return;
        try
        {
            logWriter.println(logline);
            logWriter.flush();
            return;
        }
        catch(Exception e)
        {
            integrationLogger.error((new StringBuilder("[")).append(logTag).append("] Error Writing Log: ").append(e.getMessage()).toString(), e);
        }
    }

    public static String genError(Exception e)
    {
        String errMsg = e.toString();
        return errMsg;
    }

    public boolean isEnabled()
    {
        return isEnabled;
    }

    public void setEnabled(boolean isEnabled)
    {
		System.out.println("--MxLog.java...inside setEnabled--");
        this.isEnabled = isEnabled;
    }

    public String getLogFilePath()
    {
				System.out.println("--MxLog.java...inside getLogFilePath--");

        return logFilePath;
    }

    public void setLogFilePath(String logFilePath)
    {
						System.out.println("--MxLog.java...inside setLogFilePath--logFilePath--" + logFilePath);

        this.logFilePath = logFilePath;
    }

    private String logFilePath;
    private PrintStream logWriter;
    private boolean isSystem;
    private boolean isEnabled;
    private String logTag;
    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");

}