package com.psa.custom.common;

import java.io.IOException;

public class MxSCP{

	private MxDebug debug = null;	
	
	/*
	 * Author: BTE
	 * Date: 01 MAR 2006
	 * Comment: Constructor
	 */
	public MxSCP() {
        debug = new MxDebug();
        debug.setDebug(true);    	    	        		
	}
	
	
	/*
	 * Author: BTE
	 * Date: 09 FEB 2006
	 * Comment: Get flat file via SCP from remote server.
	 * Execute the SCP command in a shell script
	 */
	public int getFlatFile(String shell) throws IOException, InterruptedException{

		Process proc;
		
		// Execute external command 
		proc = Runtime.getRuntime().exec(shell);

        int exitVal = proc.waitFor();
        debug.msg("Process exitValue: " + exitVal); 	
        
        return exitVal;
	}
}