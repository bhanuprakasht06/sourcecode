
package com.psa.custom.sms;

import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.List;

import org.jdom.Element;

import psdi.iface.mic.MicConstants;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.MboSetRemote;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

/*
 * Author: BTE
 * 08 MAR 2006 - Initial version
 * 08 JUN 2006 - Refer to DR-147
 */
public class SMSShiftDataInProcess extends MicSetIn {

	/*
	 * Variables
	 */
	private static SMSConstant SMS = new SMSConstant();
			
	
	/*
	 * Author: BTE
	 * 08 MAR 2006 - Constructor
	 */
	public SMSShiftDataInProcess() throws MXException, RemoteException {
		super();	
	}
    
	
	/*
	 * Author: BTE
	 * 08 MAR 2006 - Check business rules 
	 */
    public int checkBusinessRules() throws MXException, RemoteException {	   	            			
	    	
        INTEGRATIONLOGGER.debug("Entering checkBusinessRules");
        
		// Check if ORGID is null
		if (struc.isCurrentDataNull(SMS.ORGID)) {
			throw new MXApplicationException(SMS.IFACE, SMS.SHIFTNOORG);
		}
		
		// Check if SHIFTNUM is null
		if (struc.isCurrentDataNull(SMS.SHIFTNUM)) {
			throw new MXApplicationException(SMS.IFACE, SMS.SHIFTNOSHIFT);
		}
		
		// Check if SHIFTSECTION is null
		if (struc.isCurrentDataNull(SMS.SHIFTSECTION)) {
			throw new MXApplicationException(SMS.IFACE, SMS.SHIFTNOSECTION);
		}		
		
		setStartEndTime();    	
    	 
        INTEGRATIONLOGGER.debug("Leaving checkBusinessRules");
        return MicConstants.PROCESS;
    }
    
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Set extra attribute
	 */    
    public void setAdditionalData(MboSetRemote MboSet, String tableName) throws MXException, RemoteException {
		
        INTEGRATIONLOGGER.debug("Entering setAdditionalData");
        
		if((tableName.equals(SMS.SHIFT)) && (actionInd.equalsIgnoreCase(MicConstants.ACTIONADD))) {			
			mxTrans.saveTransaction(mxTrans);
		}
		
        INTEGRATIONLOGGER.debug("Leaving setAdditionalData");
    }    
    
    
    /*
	 * Author: BTE
	 * 05 APR 2006 - Set missing start, end time and shiftnum
	 */
    public void setStartEndTime() throws MXException, RemoteException {
    	
        INTEGRATIONLOGGER.debug("Entering setStartEndTime");
        
    	List lst = struc.getChildrenData(SMS.SHIFTPATTERNDAY);
    	Iterator iter = lst.iterator();
    	
    	for (int i = 0; iter.hasNext(); i++ ) {    
    		Element childrenElement = (Element) iter.next();
    		
    		List attrLst = childrenElement.getChildren();
    		Iterator attrIter = attrLst.iterator();

    		for (int j = 0; attrIter.hasNext(); j++ ) { 
    			    			
       			Element attr = (Element)attrIter.next();
    			String attrValue = attr.getText();
    									
    			if (attr.getName().equalsIgnoreCase(SMS.STARTTIME)) {
    				((Element)((Element) struc.getChildrenData(SMS.SHIFTPATTERNDAY).get(i)).
    						getChildren().get(j)).setText(
    								"1990-01-01T" +
    								attrValue + 
    								":00+08:00");	
    			} else if (attr.getName().equalsIgnoreCase(SMS.ENDTIME)) {
    				((Element)((Element) struc.getChildrenData(SMS.SHIFTPATTERNDAY).get(i)).
    						getChildren().get(j)).setText(
    								"1990-01-01T" +
    								attrValue + 
    								":00+08:00");	
    			}     			    			
    		}
    	}
    	
        INTEGRATIONLOGGER.debug("Leaving setStartEndTime");
    } 
}
