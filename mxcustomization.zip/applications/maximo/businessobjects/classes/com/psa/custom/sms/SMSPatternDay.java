package com.psa.custom.sms;

import java.rmi.RemoteException;

import psdi.app.calendar.ShiftPatternDayRemote;
import psdi.app.calendar.ShiftPatternDaySetRemote;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

/*
 * Author: BTE
 * 05 APR 2006 - Initial version
 */
public class SMSPatternDay extends MicSetIn {

	/*
	 * Variables
	 */
	private UserInfo userInfo;
	private static SMSConstant SMS = new SMSConstant();
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - constructor  
	 */	
	public SMSPatternDay(UserInfo userInfo) throws MXException, RemoteException {		 
		this.userInfo = userInfo;
	}
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Check Shift Pattern Day exist  
	 */	
	public boolean isShiftPatternDayExist(String orgid, String shiftNum, String patternDaySeq) 
	 	throws MXException, RemoteException {
	   		
        INTEGRATIONLOGGER.debug("Entering isShiftPatternDayExist");
        
		// Check if vaiables is null
		if(orgid == null || shiftNum == null || patternDaySeq == null) {
	        INTEGRATIONLOGGER.debug("Leaving isShiftPatternDayExist");
	        return false;
		}
		 
		ShiftPatternDaySetRemote patternDaySet = (ShiftPatternDaySetRemote) MXServer.getMXServer().getMboSet(SMS.SHIFTPATTERNDAY, userInfo);
				
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("SHIFTNUM= :2");
		combinewhereclauses.addWhere("PATTERNDAYSEQ= :3");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != SMS.EMPTY){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.SHIFTPATTERNDAY, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.SHIFTPATTERNDAY, SMS.SHIFTNUM, shiftNum);
			sqlformat.setObject(3, SMS.SHIFTPATTERNDAY, SMS.PATTERNDAYSEQ, patternDaySeq);
			patternDaySet.setWhere(sqlformat.format());
			
			if(!patternDaySet.isEmpty()) {
		        INTEGRATIONLOGGER.debug("Leaving isShiftPatternDayExist");
				return true;
			}
		}			
			
        INTEGRATIONLOGGER.debug("Leaving isShiftPatternDayExist");
		return false;		   
	}
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Add or Change shiftPatternDay in database.  
	 */
	public void addChangeShiftPatternDay(String orgid, String shiftNum, String patternDaySeq, String startTime, String endTime, String workHours)
		throws MXException, RemoteException {
		
        INTEGRATIONLOGGER.debug("Entering addChangeShiftPatternDay");
        
		if (isShiftPatternDayExist(orgid, shiftNum, patternDaySeq)) {
			if (!updatePatternDay(orgid,  shiftNum, patternDaySeq, startTime, endTime, workHours)){
				throw new MXApplicationException(SMS.IFACE, SMS.PATTERNDAY_UPDATE_ERROR);
			}
			
		} else {
			if (!addPatternDay(orgid,  shiftNum, patternDaySeq, startTime, endTime, workHours)) {
				throw new MXApplicationException(SMS.IFACE, SMS.PATTERNDAY_CREATE_ERROR);
			}
		}		
		
        INTEGRATIONLOGGER.debug("Leaving addChangeShiftPatternDay");
	}	
	
	
	/*
	 * Author: BTE
	 * APR 2006 - Add ShiftPatternDay in database.  
	 */
	public boolean addPatternDay(String orgid, String shiftNum, String patternDaySeq, String startTime, String endTime, String workHours) 
 		throws MXException, RemoteException {
	   
        INTEGRATIONLOGGER.debug("Entering addPatternDay");
        
		// Check if vaiables is null
		if(orgid == null || shiftNum == null || patternDaySeq == null) {
	        INTEGRATIONLOGGER.debug("Leaving addPatternDay");
	        return false;
		}
		 
		ShiftPatternDaySetRemote patternDaySet = (ShiftPatternDaySetRemote) MXServer.getMXServer().getMboSet(SMS.SHIFTPATTERNDAY, userInfo);		
				
		patternDaySet.add(0);
		patternDaySet.setValue(SMS.ORGID, orgid);
		patternDaySet.setValue(SMS.SHIFTNUM, shiftNum);
		patternDaySet.setValue(SMS.PATTERNDAYSEQ, patternDaySeq);
		patternDaySet.setValue(SMS.STARTTIME, startTime);
		patternDaySet.setValue(SMS.ENDTIME, endTime);
		patternDaySet.setValue(SMS.WORKHOURS, workHours);
		
		patternDaySet.save(0);
		patternDaySet.commit();		
		patternDaySet.close();
					
        INTEGRATIONLOGGER.debug("Leaving addPatternDay");
		return true;													   
	}
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Change ShiftPatternDay in database.  
	 */
	public boolean updatePatternDay(String orgid, String shiftNum, String patternDaySeq, String startTime, String endTime, String workHours) 
 		throws MXException, RemoteException {
	   
        INTEGRATIONLOGGER.debug("Entering updatePatternDay");
        
		// Check if vaiables is null
		if(orgid == null || shiftNum == null || patternDaySeq == null) {			
	        INTEGRATIONLOGGER.debug("Leaving updatePatternDay");
	        return false;
		}
		 
		ShiftPatternDaySetRemote patternDaySet = (ShiftPatternDaySetRemote) MXServer.getMXServer().getMboSet(SMS.SHIFTPATTERNDAY, userInfo);
			
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
		
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("SHIFTNUM= :2");
		combinewhereclauses.addWhere("PATTERNDAYSEQ= :3");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.SHIFTPATTERNDAY, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.SHIFTPATTERNDAY, SMS.SHIFTNUM, shiftNum);
			sqlformat.setObject(2, SMS.SHIFTPATTERNDAY, SMS.PATTERNDAYSEQ, patternDaySeq);		
			patternDaySet.setWhere(sqlformat.format());

			
			if(!patternDaySet.isEmpty()) {
				
				ShiftPatternDayRemote patternDayRemote = (ShiftPatternDayRemote) patternDaySet.getMbo(0);
				
				if(!patternDayRemote.isNull(SMS.SHIFTNUM)){
					
					patternDaySet.getMbo(0).setValue(SMS.STARTTIME, startTime);			
					patternDaySet.getMbo(0).setValue(SMS.ENDTIME, endTime);
					patternDaySet.getMbo(0).setValue(SMS.SHIFTNUM, shiftNum);				

					patternDaySet.save(0);				
					patternDaySet.commit();	
					patternDaySet.close();	
					
			        INTEGRATIONLOGGER.debug("Leaving updatePatternDay");
					return true;
				}				
			}
		}			
			
        INTEGRATIONLOGGER.debug("Leaving updatePatternDay");
		return false;			   
	}		
}
