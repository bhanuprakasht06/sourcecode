/**
 * @author	HCHA
 * Date		Feb 27, 2006
 * Comment	Generation of XML file for Location Meter
 */
package com.psa.custom.ois;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.psa.custom.common.MxDebug;
import com.psa.custom.common.MxXml;


/**
 * @author		HCHA
 * @class		MxXmlLocMeter
 * @date		Feb 27, 2006
 * @function	Generation of XML file for Location Meter
 */
public class MxXmlLocMeter {
	    
    private MxDebug debug;
    private MxXml mxXml;
    
    private String intIface; 		//Name of Integration Interface
    private String intObject; 		//Name of Integration Object
    private String extSys; 			//Name of External System
    private String obj; 			//Name of Maximo Object 
    private String metername;   	//Meter Name
    private String isdelta;			//Whether the reading is delta type (Possible Value: 'Y' or 'N')
    private String inspector;		//Inspector of the meter reading

    
	public MxXmlLocMeter(String extSys, String intIface, String metername) {
        debug = new MxDebug();
        mxXml = new MxXml();
        
        //Enable debug
        debug.setDebug(true);
        
        this.extSys = extSys;
        this.intIface = intIface;
        this.metername = metername;
        
        //default value
        intObject = "MXLOCMETER";
        obj = "LOCATIONMETER";
        isdelta = "Y";
        inspector = "MXINTADM";
        
	}
	
	public MxXmlLocMeter(String extSys, String intIface, String intObject, String metername, String isdelta, String inspector) {
        debug = new MxDebug();
        mxXml = new MxXml();
        
        //Enable debug
        debug.setDebug(true);
        
        this.extSys = extSys;
        this.intIface = intIface;
        this.metername = metername;
        this.intObject = intObject;
        this.isdelta = isdelta;
        this.inspector = inspector;
        
        //default value
        obj = "LOCATIONMETER";
        
	}

	// XML tag's    
    //updated by WMJ on 20120909
	//private final String MSG_START_INTERFACE =
    //	" xmlns=\"http://www.ibm.com/maximo\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" creationDateTime=\"2008-09-29T09:49:45\" transLanguage=\"EN\" baseLanguage=\"EN\" maximoVersion=\"7 1 201005222-032 V7117-47\" event=\"1\">";    
	private final String MSG_START_INTERFACE =
    	" xmlns=\"http://www.ibm.com/maximo\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" transLanguage=\"EN\" baseLanguage=\"EN\" maximoVersion=\"7 1 201005222-032 V7117-47\" event=\"1\">";    
    
  /*  private final String MSG_START_INTERFACE =
    	" xmlns=\"http://www.mro.com/mx/integration\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" language=\"EN\">";    */
    
	private final String TAG_START_HEADER ="<Header operation=\"Notify\" event=\"0\">";
	private final String TAG_END_HEADER = "</Header>";
	
	private final String TAG_SENDERID = "SenderID";				
	
	private final String TAG_START_CONTENT = "<Content>";	
	private final String TAG_END_CONTENT = "</Content>";		
		
	
	private final String TAG_ORGID = "ORGID";
	private final String TAG_SITEID = "SITEID";
	private final String TAG_LOCATION = "LOCATION";
	private final String TAG_METERNAME = "METERNAME";
	private final String TAG_ISDELTA = "ISDELTA";
	private final String TAG_INSPECTOR = "INSPECTOR";
	private final String TAG_NEWREADINGDATE = "NEWREADINGDATE";
	private final String TAG_NEWREADING = "NEWREADING";
	
	// Format definitions
	private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+08:00'"; 
		

	public String genXml(String orgID, String siteID, String location, String newReadingDT, String newReading ) {
		System.out.println("--inside genXml of MxXmlLocMeter--");

    /*
     * Location Meter XML format
     * 
		<?xml version="1.0" encoding="UTF-8"?>
		<Interface xmlns="http://www.mro.com/mx/integration" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" language="EN">
		  <Header operation="Notify" event="0">
		    <SenderID type="MAXIMO" majorversion="6" minorversion="0" build="03" dbbuild="V600-341">ExtSys</SenderID>
		    <CreationDateTime>2006-02-25T13:30:01+08:00</CreationDateTime>
		  </Header>
		  <Content>
		    <MXLOCMETER>
		      <LOCATIONMETER>
		        <ORGID></ORGID>
		        <SITEID></SITEID>		      
		        <LOCATION></LOCATION>
		        <METERNAME></METERNAME>
		        <ISDELTA>Y</ISDELTA>
		        <INSPECTOR>MXINTADM</INSPECTOR>
		        <NEWREADINGDATE></NEWREADINGDATE>
		        <NEWREADING></NEWREADING>
		      </LOCATIONMETER>
		    </MXLOCMETER>
		  </Content>
		</MXOISInterface>
	 */
		
		debug.msg("MxXmlLocMeter.genXml(): Generate XML [MeterName="+metername+" site="+siteID+" loc="+location+" NewReading="+newReading+" NewReadingDate"+newReadingDT);
		
       DateFormat timeStampFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
        
       // Convert string to date
       // Format of newReadingDate: YYYYMMDDHHMM
       Date newReadingDate = OISData.convertDate(newReadingDT);
   	   
       // Create XML 
       String xml =  
   			"<SyncMXLOCMETER" + // Interface name
			MSG_START_INTERFACE +				
			"<" + intObject + ">" + //Integration object				
			"<" + obj + " action=\"AddChange\">" + // object 
			mxXml.genTagSting(TAG_ORGID, orgID) +
			mxXml.genTagSting(TAG_SITEID, siteID) +
			mxXml.genTagSting(TAG_LOCATION, location) +
			mxXml.genTagSting(TAG_METERNAME, metername) +
			mxXml.genTagSting(TAG_ISDELTA, isdelta) +
			mxXml.genTagSting(TAG_INSPECTOR, inspector) +
			mxXml.genTagSting(TAG_NEWREADINGDATE, timeStampFormat.format(newReadingDate)) +
			mxXml.genTagSting(TAG_NEWREADING, newReading) +	
			"</" + obj + ">" + // object			
			"</" + intObject + ">" + //Integration object
			"</SyncMXLOCMETER>"; // Interface name
   	System.out.println("--locmeter xml--" + xml);
  /*     String xml2 =  
  			"<" + intIface + // Interface name
			MSG_START_INTERFACE +				
			TAG_START_HEADER +
			mxXml.genTagSting(TAG_SENDERID, extSys) + // External system
			TAG_END_HEADER +
			TAG_START_CONTENT +
			"<" + intObject + ">" + //Integration object				
			"<" + obj + " >" + // object 
			mxXml.genTagSting(TAG_ORGID, orgID) +
			mxXml.genTagSting(TAG_SITEID, siteID) +
			mxXml.genTagSting(TAG_LOCATION, location) +
			mxXml.genTagSting(TAG_METERNAME, metername) +
			mxXml.genTagSting(TAG_ISDELTA, isdelta) +
			mxXml.genTagSting(TAG_INSPECTOR, inspector) +
			mxXml.genTagSting(TAG_NEWREADINGDATE, timeStampFormat.format(newReadingDate)) +
			mxXml.genTagSting(TAG_NEWREADING, newReading) +	
			"</" + obj + ">" + // object			
			"</" + intObject + ">" + //Integration object
			TAG_END_CONTENT +
			"</" + intIface + ">"; // Interface name   */
       
       
   		return xml;
   }





	public String getExtSys() {
		return extSys;
	}





	public void setExtSys(String extSys) {
		this.extSys = extSys;
	}





	public String getInspector() {
		return inspector;
	}





	public void setInspector(String inspector) {
		this.inspector = inspector;
	}





	public String getIntIface() {
		return intIface;
	}





	public void setIntIface(String intIface) {
		this.intIface = intIface;
	}





	public String getIntObject() {
		return intObject;
	}





	public void setIntObject(String intObject) {
		this.intObject = intObject;
	}





	public String getIsdelta() {
		return isdelta;
	}





	public void setIsdelta(String isdelta) {
		this.isdelta = isdelta;
	}





	public String getMetername() {
		return metername;
	}





	public void setMetername(String metername) {
		this.metername = metername;
	}



	public String getObj() {
		return obj;
	}





	public void setObj(String obj) {
		this.obj = obj;
	}

}

