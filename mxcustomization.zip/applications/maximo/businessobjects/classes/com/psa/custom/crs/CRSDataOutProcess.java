package com.psa.custom.crs;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.StringTokenizer;
//import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.iface.mic.StructureData;
import psdi.iface.migexits.ExternalExit;


/*
 * Author: BTE
 * Date: 28 FEB 2006
 * Comment: CRS data inbound classes to translate Breakdown type and fault code to CRS fault code 
 */
public class CRSDataOutProcess extends ExternalExit {

	private HashMap bdTypeHashMap;
	
	/*
	 * Author: BTE
	 * Date: 28 FEB 2006
	 * Comment: Constructor
	 */
    public CRSDataOutProcess() throws MXException, RemoteException {
		super();
		
		bdTypeHashMap = new HashMap();
		
		// Build Breakdown Type Hash map
		buildBreakDownType();
    }


    /*
     * Author: BTE
     * Date: 28 FEB 2006
     * Comment: Business rules
     */
    public StructureData setDataOut(StructureData structuredata)
    	throws MXException, RemoteException
    {

    	integrationLogger.debug("Entering CRSDataOutProcess.setDataOut");

		if(!structuredata.isCurrentDataNull("CRSFAULT")) {
			
			// Translation break down type from CRS fault
			String breakdownType = trans2BreakDownType(structuredata.getCurrentData("CRSFAULT"));		
			if (breakdownType != null ) {
				structuredata.setCurrentData("BREAKDOWNTYPE",breakdownType);
			} 
			else {
				integrationLogger.debug("Breakdown Type is Null");
				structuredata.setCurrentDataNull("BREAKDOWNTYPE");
				//throw new MXApplicationException("iface", "Incorrect CRS Fault Code");
			}
			
			// Translation fault code from CRS fault
			String faultcode = trans2FaultCode(structuredata.getCurrentData("CRSFAULT"));		
			if (faultcode != null ) {
				structuredata.setCurrentData("CRSFAULT", faultcode);
			} 
			else {
				integrationLogger.debug("Fault Code is Null");
				structuredata.setCurrentDataNull("CRSFAULT");
				//throw new MXApplicationException("iface", "Incorrect CRS Fault Code");
			}
		}
		
		integrationLogger.debug("Leaving CRSDataOutProcess.setDataOut");
		
		return structuredata;

    } //setDataOut()
    
    
    private static final String A = "A";
    private static final String P = "P";
    private static final String E = "E";    
    private static final String QC = "QC";
    private static final String YC = "YC";
    private static final String APIS = "APIS";
    private static final String PC = "PC";
    private static final String dat = "-";
    
    /*
     * Author: BTE
     * Date: 28 FEB 2006
     * Comment: Translation CRS fault to breakdown type
     */
    private String trans2BreakDownType(String CRSfault) {

		integrationLogger.debug("Entering CRSDataOutProcess.trans2BreakDownType");
		
        StringTokenizer stringTokenizer = null;        
        stringTokenizer = new StringTokenizer(CRSfault, dat);
        
        if ((stringTokenizer.countTokens()!=1)&&(stringTokenizer.countTokens()!=2)){
        	integrationLogger.debug("CRSDataOutProcess.transCRSFault: Invalid CRS Fault - "+CRSfault);
        	return null;
        }
             
        //String bdType = null;
        String breakdownType = String.valueOf(stringTokenizer.nextElement());         	        
        
        //Remove conversion
        //bdType =bdTypeHashMap.get(breakdownType).toString();
    	//integrationLogger.debug("Leaving CRSDataOutProcess.trans2BreakDownType: BndTypeIn="+breakdownType+" BndTypeOut="+bdType);
		//return bdType;
        integrationLogger.debug("Leaving CRSDataOutProcess.trans2BreakDownType: BndType="+breakdownType);
        
        return breakdownType;
    }
    
    
    /*
     * Author: BTE
     * Date: 28 FEB 2006
     * Comment: Translation CRS fault to fault code
     */
    private String trans2FaultCode(String CRSfault) {
    	integrationLogger.debug("Entering CRSDataOutProcess.transCRSFault");
		
        StringTokenizer stringTokenizer = null;        
        stringTokenizer = new StringTokenizer(CRSfault, dat);
        
        if (stringTokenizer.countTokens()!=2){
        	if(!CRSfault.equalsIgnoreCase("PC")){
        		integrationLogger.debug("CRSDataOutProcess.transCRSFault: Invalid CRS Fault - "+CRSfault);
        	}
        	return null;
        }
        	
        String.valueOf(stringTokenizer.nextElement());         	        
        String faultCode = String.valueOf(stringTokenizer.nextElement());
        
    	integrationLogger.debug("Leaving CRSDataOutProcess.transCRSFault: faultCode="+faultCode);
        		
		return faultCode;
    }
    
    
    /*
     * Author: BTE
     * Date: 28 FEB 2006
     * Comment: Build Breakdown type hash map
     */
    private void buildBreakDownType () {
	    bdTypeHashMap.put(APIS, A);
	    bdTypeHashMap.put(PC, P);
	    bdTypeHashMap.put(QC, E);
	    bdTypeHashMap.put(YC, E);	    
    }
   
}