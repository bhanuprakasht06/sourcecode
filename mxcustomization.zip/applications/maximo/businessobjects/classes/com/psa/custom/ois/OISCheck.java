package com.psa.custom.ois;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

//Check Class to check whether a string is in the loaded list
public class OISCheck {
	//Array List which inlcude the movement type that are excluded
	private ArrayList list;

	public OISCheck() {
		list = new ArrayList();
	}
	
	public OISCheck(String fileName) 
		throws Exception
	{
		list = new ArrayList();
		readList(fileName);
	}
	
	public void readList(String fileName) 
		throws Exception
	{
		
		String inputText;
		
		try{

			File inFile = new File(fileName);
			FileReader fReader = new FileReader(inFile);
			BufferedReader bReader = new BufferedReader(fReader);
			
			inputText = bReader.readLine().trim();

			while(inputText!=null) {				
				list.add(inputText);
				inputText = bReader.readLine();
			}
			
			bReader.close();
			fReader.close();
			
			//Sort Exclude List
			Collections.sort(list);
			
		}
		catch(IOException e) {
			throw new Exception(getClass().getName()+".readList(): Error reading file: "+fileName);
		}
		
		catch(Exception e) {
			throw new Exception(getClass().getName()+".readList():Unexpected error reading text file : " + e);
		} 
	}
	
	public boolean isInList(String checkValue){
		//if found the return value by the binary search is >=0
		return (Collections.binarySearch(list,checkValue)>=0);
	}
	
	
}
