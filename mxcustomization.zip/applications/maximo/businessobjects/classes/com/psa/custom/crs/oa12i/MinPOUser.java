package com.psa.custom.oa12i;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;
import psdi.app.pr.PRRemote;
import psdi.app.pr.PRSetRemote;
import psdi.iface.mic.StructureData;
import psdi.iface.migexits.UserExit;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;

public class MinPOUser extends UserExit 
{
	String po_contractnum = "";
	String po_contractrevnum = "";
	String po_num = "";

	public StructureData setUserValueIn(StructureData irData, StructureData erData) 
			throws MXException, RemoteException 
	{
		integrationLogger.debug("Entering setUserValueIn");

		erData.breakData();
		erData.moveToFirstObjectStruture();

		this.po_contractnum = irData.getCurrentData("CONTRACTREFNUM");
		this.po_contractrevnum = irData.getCurrentData("CONTRACTREFREV");
		this.po_num = irData.getCurrentData("PONUM");
		
		integrationLogger.debug("po_contractnum = " + this.po_contractnum);
		integrationLogger.debug("po_contractrevnum = " + this.po_contractrevnum);
		do 
		{
			List list = irData.getChildrenData("POLINE");
			if ((list != null) && (list.size() > 0)) 
			{
				String prnum = null;
				String siteid = null;
				Date vendordate = null;
				for (int i = 0; i < list.size(); i++) 
				{
					irData.setAsCurrent(list, i);
					if (!irData.isCurrentDataNull("PRNUM")) 
					{
						prnum = irData.getCurrentData("PRNUM");
						integrationLogger.debug("PRNUM: " + prnum);

						siteid = getSite(prnum);

						irData.setCurrentData("TOSITEID", siteid);

						irData.setCurrentData("INSPECTIONREQUIRED",	getPRLine(prnum, siteid,irData.getCurrentDataAsInt("PRLINENUM")).getString("inspectionrequired"));
						if ((!irData.isCurrentDataNull("VENDELIVERYDATE")) && (vendordate != null)) 
						{
							vendordate = irData.getCurrentDataAsDate("VENDELIVERYDATE");
						}
					}
				}
				if (prnum != null) 
				{
					if (vendordate != null) 
					{
						irData.setParentAsCurrent();
						irData.setCurrentData("VENDELIVERYDATE", vendordate);
					}
					irData.setAsCurrent(irData.getPrimaryObject());

					irData.setCurrentData("SITEID", siteid);
				}
			}
		} while (erData.moveToNextObjectStructure());
		integrationLogger.debug("Leaving setUserValueIn");
		return irData;
	}

	public String getSite(String prnum) throws MXException, RemoteException 
	{
		integrationLogger.debug("Entering getSite");

		PRSetRemote prSet = (PRSetRemote) MXServer.getMXServer().getMboSet("PR", this.userInfo);

		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
		combinewhereclauses.addWhere("PRNUM= :1");
		String s = combinewhereclauses.getWhereClause();
		if ((s != null) && (s != "")) 
		{
			SqlFormat sqlformat = new SqlFormat(this.userInfo, s);
			sqlformat.setObject(1, "PR", "PRNUM", prnum);
			prSet.setWhere(sqlformat.format());
			if (!prSet.isEmpty()) 
			{
				PRRemote pr = (PRRemote) prSet.getMbo(0);
				if (!pr.isNull("SITEID")) 
				{
					integrationLogger.debug("SITEID: " + pr.getString("SITEID"));
					integrationLogger.debug("Leaving getSite");
					return pr.getString("SITEID");
				}
			}
		}
		integrationLogger.debug("Leaving getSite");
		return null;
	}

	public MboRemote getPRLine(String prnum, String siteid, int prlinenum)
			throws MXException, RemoteException 
	{
		MboSetRemote prlineset = MXServer.getMXServer().getMboSet("PRLINE",	this.userInfo);
		SqlFormat sqlformat = new SqlFormat("prnum=:1 AND siteid=:2 AND prlinenum=:3");
		sqlformat.setObject(1, "pr", "prnum", prnum);
		sqlformat.setObject(2, "pr", "siteid", siteid);
		sqlformat.setInt(3, prlinenum);

		prlineset.setWhere(sqlformat.format());

		MboRemote prline = prlineset.getMbo(0);

		String prline_contractnum = prline.getString("CONTRACTREFNUM");
		String prline_contractrevnum = prline.getString("CONTRACTREFREV");
		integrationLogger.debug("prline_contractnum = " + prline_contractnum);
		integrationLogger.debug("prline_contractrevnum = " + prline_contractrevnum);
		
		//System.out.println("this.po_contractnum###########"+this.po_contractnum);
		//System.out.println("this.po_contractrevnum###########"+this.po_contractrevnum);
		//System.out.println("this.prline_contractnum###########"+prline_contractnum);
		//System.out.println("this.prline_contractrevnum###########"+prline_contractrevnum);
		
		/*if(this.po_contractnum == null || this.po_contractnum =="" || this.po_contractrevnum == null || this.po_contractrevnum ==""){
			prline.setFieldFlag("CONTRACTREFID", 7L, false);
			prline.setValueNull("CONTRACTREFID",9L);
			prline.setValueNull("CONTRACTREFNUM", 9L);
			prline.setFieldFlag("CONTRACTREFREV", 7L, false); 
			prline.setValueNull("CONTRACTREFREV", 9L);
			prlineset.save();
			prlineset.close();
		}		*/
		if ((prline_contractnum != null) && (!prline_contractnum.equals("")) && (prline_contractrevnum != null)	&& (!prline_contractrevnum.equals(""))) 
		{
			if ((!prline_contractnum.equals(this.po_contractnum)) || (!prline_contractrevnum.equals(this.po_contractrevnum))) 
			{
				System.out.println("inside #############################");
				integrationLogger.debug("reset PRLines contract numbers to PO contract number.");
				MboSetRemote mboSet = MXServer.getMXServer().getMboSet("CONTRACT", this.userInfo);

				CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
				combinewhereclauses.addWhere("CONTRACTNUM= :1 and REVISIONNUM= :2");
				String s1 = combinewhereclauses.getWhereClause();
				if ((s1 != null) && (s1 != "")) 
				{
					SqlFormat sqlformat1 = new SqlFormat(this.userInfo, s1);
					sqlformat1.setObject(1, "CONTRACT", "CONTRACTNUM", this.po_contractnum);
					sqlformat1.setObject(2, "CONTRACT", "REVISIONNUM", this.po_contractrevnum);
					mboSet.setWhere(sqlformat1.format());
				}
				if (!mboSet.isEmpty()) {
					MboRemote mbo = mboSet.getMbo(0);
					integrationLogger.debug("New contract id = "+ mbo.getLong("CONTRACTID"));
					prline.setFieldFlag("CONTRACTREFID", 7L, false);
					prline.setValue("CONTRACTREFID", mbo.getLong("CONTRACTID"),	9L);
					prline.setValue("CONTRACTREFNUM", this.po_contractnum, 9L);
					prline.setFieldFlag("CONTRACTREFREV", 7L, false);
					prline.setValue("CONTRACTREFREV", this.po_contractrevnum, 9L);
					prlineset.save();
				}
				integrationLogger.debug("After saving PRLines changes to DB.");
			}
		}
		prlineset.close();
		
		//String prline_acontractnum = prline.getString("CONTRACTREFNUM");
		///String prline_acontractrevnum = prline.getString("CONTRACTREFREV");
		
	//	System.out.println("this.prline_acontractnum###########"+prline_acontractnum);
	//	System.out.println("this.prline_acontractrevnum###########"+prline_acontractrevnum);
		return prline;
	}
}
