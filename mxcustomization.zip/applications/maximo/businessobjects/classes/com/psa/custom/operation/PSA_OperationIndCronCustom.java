/*
 * Enhanced  by BCT 
 * 
 * Modified Existing class
 * 
 * integrating the People soft  to Maximo Using this cron task file
 * equipment
 * 
 * 26-10-2020: BCT converted Oracle to SQL
 * 
 * 
 */
package com.psa.custom.operation;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxSCP;
import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;

import com.psa.custom.common.MxZip;

import psdi.mbo.DBShortcut;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import java.io.*;
import java.sql.*;

public class PSA_OperationIndCronCustom extends SimpleCronTask
{
	protected static final MXLogger logger = MXLoggerFactory.getLogger("maximo.custom.cronlogger");

	
	private MxEmail email;
	protected MxLog mxLog;

	//Parameters
	private String alertEmail; // Alert mail
	private String emailSubj; // Alert mail subject
	private String fileExtension; // Output file Extension
	private String fileName; //Output file Name
	private String locMapName;
	private String oiLocName;
	private String logFilePath; //Log Directory
	private String locMapPath;
	private String oiLocSqlPath;
	private String processDirectory; //Processed directory
	private String logFile; //Log file output
	private String scpLocalFilePath; //SCP Local file path
	private String scpRMFilePath; //SCP Remote file path
	private String scpConfigFile; //SCP Config file
	private String scpRMServerName; //SCP remote server name
	private String delimiter;				//Delimiter
	private String zipExec;				//Executable/Command for zip function
	private String terminal; //Terminal
	private String equipmentType; //Equipment Type
	private String fleetSizeCode; //Fleet size code
	//private String mhrsCode; //Maintenance Hrs Code
	private String bdnhrsCode;
	private String rfbhrsCode;
	private String rprhrsCode;
	private String newmhrsCode;
	private String tif; //Technical Interruption Frequency
	private String fuelCode; //Fuel Code
	private String workTypeTech; //Work type for technical
	private String outputFilePath; //output file path location
	private String SPACE = " ";

	public CrontaskParamInfo[] getParameters() throws MXException, RemoteException
	{
		CrontaskParamInfo[] params = new CrontaskParamInfo[28];

		params[0] = new CrontaskParamInfo();
        params[0].setName("WORKTYPETECH");
        params[0].setDescription("WORKTYPETECH", "WORK TYPE TECH");

        params[1] = new CrontaskParamInfo();
        params[1].setName("ALERTEMAIL");
        params[1].setDescription("ALERTEMAIL", "ALERT EMAIL");

        params[2] = new CrontaskParamInfo();
        params[2].setName("EMAILSUBJ");
        params[2].setDescription("EMAILSUBJ", "EMAIL SUBJ");

        params[3] = new CrontaskParamInfo();
        params[3].setName("FILEEXTENSION");
        params[3].setDescription("FILEEXTENSION", "FILE EXTENSION");

        params[4] = new CrontaskParamInfo();
        params[4].setName("FILENAME");
        params[4].setDescription("FILENAME", "FILE NAME");
        
        params[5] = new CrontaskParamInfo();
        params[5].setName("LOCMAPNAME");
        params[5].setDescription("LOCMAPNAME", "ass_id_yyyyMMdd");
        
        params[6] = new CrontaskParamInfo();
        params[6].setName("OILOCNAME");
        params[6].setDescription("OILOCNAME", "oi_location_yyyyMMdd");

        params[7] = new CrontaskParamInfo();
        params[7].setName("LOGFILEPATH");
        params[7].setDescription("LOGFILEPATH", "LOG FILE PATH");

        params[8] = new CrontaskParamInfo();
        params[8].setName("PROCESSDIRECTORY");
        params[8].setDescription("PROCESSDIRECTORY", "PROCESS DIRECTORY");


        params[9] = new CrontaskParamInfo();
        params[9].setName("LOGFILE");
        params[9].setDescription("LOGFILE", "LOG FILE");

        params[10] = new CrontaskParamInfo();
        params[10].setName("SCPLOCALFILEPATH");
        params[10].setDescription("SCPLOCALFILEPATH", "SCP LOCAL FILE PATH");

        params[11] = new CrontaskParamInfo();
        params[11].setName("SCPRMFILEPATH");
        params[11].setDescription("SCPRMFILEPATH", "SCP RM FILE PATH");

        params[12] = new CrontaskParamInfo();
        params[12].setName("SCPCONFIGFILE");
        params[12].setDescription("SCPCONFIGFILE", "SCP CONFIG FILE");

        params[13] = new CrontaskParamInfo();
        params[13].setName("SCPRMSERVERNAME");
        params[13].setDescription("SCPRMSERVERNAME", "SCP RM SERVER NAME");

        params[14] = new CrontaskParamInfo();
        params[14].setName("DELIMITER");
        params[14].setDescription("DELIMITER", "DELIMITER");

        params[15] = new CrontaskParamInfo();
        params[15].setName("ZIPEXEC");
        params[15].setDescription("ZIPEXEC", "ZIP EXEC");

        params[16] = new CrontaskParamInfo();
        params[16].setName("TERMINAL");
        params[16].setDescription("TERMINAL", "TERMINAL");

        params[17] = new CrontaskParamInfo();
        params[17].setName("EQUIPMENTTYPE");
        params[17].setDescription("EQUIPMENTTYPE", "EQUIPMENT TYPE");

        params[18] = new CrontaskParamInfo();
        params[18].setName("FLEETSIZECODE");
        params[18].setDescription("FLEETSIZECODE", "FLEET SIZE CODE");

        /*params[17] = new CrontaskParamInfo();
        params[17].setName("MHRSCODE");
        params[17].setDescription("MHRSCODE", "MHRS CODE");
        */

        params[19] = new CrontaskParamInfo();
        params[19].setName("TIF");
        params[19].setDescription("TIF", "TIF");

        params[20] = new CrontaskParamInfo();
        params[20].setName("FUELCODE");
        params[20].setDescription("FUELCODE", "FUEL CODE");
        
        params[21] = new CrontaskParamInfo();
        params[21].setName("OUTPUTFILEPATH");
        params[21].setDescription("OUTPUTFILEPATH", "OUTPUT FILE PATH ");
        
        params[22] = new CrontaskParamInfo();
        params[22].setName("BDNHRSCODE");
        params[22].setDescription("BDNHRSCODE", "BDNHRS CODE");
        
        params[23] = new CrontaskParamInfo();
        params[23].setName("RFBHRSCODE");
        params[23].setDescription("RFBHRSCODE", "RFBHRS CODE");
        
        params[24] = new CrontaskParamInfo();
        params[24].setName("RPRHRSCODE");
        params[24].setDescription("RPRHRSCODE", "RPRHRS CODE");
        
        params[25] = new CrontaskParamInfo();
        params[25].setName("NEWMHRSCODE");
        params[25].setDescription("NEWMHRSCODE", "NEWMHRS CODE");
        
        params[26] = new CrontaskParamInfo();
        params[26].setName("LOCMAPPATH");
        params[26].setDescription("LOCMAPPATH", "LOC MAP FILE PATH");

        params[27] = new CrontaskParamInfo();
        params[27].setName("OILOCSQLPATH");
        params[27].setDescription("OILOCSQLPATH", "OILOC SQL FILE PATH");
                
		return params;
	}

public PSA_OperationIndCronCustom() {
		
		super();
		
	
		alertEmail=null;
		emailSubj=null;
		fileExtension=null;
		fileName=null;
		locMapName=null;
		oiLocName=null;
		logFilePath=null;
		locMapPath=null;
		oiLocSqlPath=null;
		processDirectory=null;
		logFile=null;
		scpLocalFilePath=null;
		scpRMFilePath=null;
		scpConfigFile=null;
		scpRMServerName=null;
		delimiter=null;
		zipExec=null;
		terminal=null;
		equipmentType=null;		
		fleetSizeCode=null;
		//mhrsCode=null;
		bdnhrsCode=null;
		rfbhrsCode=null;
		rprhrsCode=null;
		newmhrsCode=null;
		tif=null;
		fuelCode=null;
		workTypeTech=null;
		outputFilePath=null;
	}


	 public void start()
	    {
	        try
	        {
	            refreshSettings();
	            setSleepTime(0L);
	        }
	        catch(Exception exception)
	        {
	        	mxLog.writeLog("Error in crontask : start():" +exception);
	        }
	    }

	 public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
	    {
	        try
	        {
	            super.setCrontaskInstance(crontaskinstanceremote);
	        }
	        catch(Exception exception)
	        {
	        	mxLog.writeLog("Error in crontask : setCrontaskInstance():" + exception);
	        }
	    }
	 
	public void cronAction()
	{
		try
		{
			logger.debug(" at cronAction()"); // Alert mail
			
			refreshSettings();
			
			processData();
			
		}
		catch (Exception e)
		{
			mxLog.writeLog("Error in crontask:" + e);
			String emailContent = genEmail(e);
            email.send(emailSubj, emailContent);
		}
	}
	
    public void init() throws MXException {
        super.init();

        email = new MxEmail(alertEmail);
        mxLog = new MxLog();
     
}

    private void processData()
    throws Exception
{
        
    try
    {
    	
    	System.out.println(" ***************  isReqParamSet *********************** ");
        if(isReqParamSet())
        {
        DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
        String todayDateTime = fileDateTimeFormat.format(new Date());
        fileName = fileName.replaceAll("yyyyMMdd", todayDateTime);
        locMapName = locMapName.replaceAll("yyyyMMdd", todayDateTime);
        oiLocName = oiLocName.replaceAll("yyyyMMdd", todayDateTime);
        DBShortcut dbShortcut = new DBShortcut();
       
        writeFile(dbShortcut);

        	try{
    		MxFileCopy.fileCopy(processDirectory + fileName+fileExtension,outputFilePath+fileName+fileExtension);
        	//Copy and Zip Flat Files to Output and Archive Directory 
    		boolean fileZipCompleted=depositFile();
    		
    	
    		if(fileZipCompleted)
    		{
    			 // to delete temp folder output file
    			File deleteZipProcessed = new File(outputFilePath+fileName+fileExtension);
    			deleteZipProcessed.delete();
    			
    			File dataFile = new File(outputFilePath + fileName+fileExtension+".gz");

    	          if ((dataFile.exists()) & scpConfigFile.trim().length() != 0 & scpLocalFilePath.trim().length() != 0 & scpRMServerName.trim().length() != 0 & scpRMFilePath.trim().length() != 0)
    	          {
    	        	  
    	        	  MxFileCopy.fileCopy(outputFilePath + fileName+fileExtension+".gz",scpLocalFilePath+fileName+fileExtension+".gz");
    	        	  
    	        	  System.out.println("Operation Indicator Test");
    	        	
    	        	  File deleteZipFile = new File(outputFilePath + fileName+fileExtension+".GZ");
    	        	  deleteZipFile.delete();
    	        	  
    	        	
    	        	  mxLog.writeLog(getName() + ".cronAction(): Starting SCP, getting " + fileName + " from " + scpRMServerName+ "...");
    	          
    	        	  MxSCP scp = new MxSCP();

    	        	  String scpParam = scpConfigFile + " "+scpLocalFilePath+fileName+fileExtension+".gz"+" "+scpRMServerName + ":" +scpRMFilePath +fileName+fileExtension+".gz";
    	        	  mxLog.writeLog("-------- SCP CMD   ----------------->"+scpParam);
    	            if (scp.getFlatFile(scpParam) != 0) {
    	              throw new Exception("Cannot get remote file - " + scpRMServerName + ":" + scpRMFilePath + fileName+fileExtension+".gz" + ".");
    	            }
    	            
    	          
    	            mxLog.writeLog(getName() + ".cronAction(): Finished SCP...");
    	            // to delete zip file from output directory
    	            File fZipedFile = new File(scpLocalFilePath+fileName+fileExtension+".gz");
    	           fZipedFile.delete();
  	        	  System.out.println("Operation Indicator End scp");
    	       
    	          }

    		}
    	}
        catch(Exception e)
        {
        	mxLog.writeLog("Error in depositFile():" + e);
        	//String emailContent = genEmail(e);
           // email.send(emailSubj, emailContent);
        }
    	
    	
    	mxLog.closeLogFile();
        }
        else
        {
        	logger.info("Required Parameters are not set.");
        }
    }
    catch(Exception e)
    {
    	mxLog.writeLog("Error in processData crontask:" + e);
    	mxLog.closeLogFile();
    	String emailContent = genEmail(e);
        email.send(emailSubj, emailContent);
    }
   
}
    
private boolean depositFile()
	throws Exception
{
	boolean fileZipCompleted=true;
	
    try {
		String zipoutputFilePath = outputFilePath+fileName;
		String cmd = zipExec + SPACE + zipoutputFilePath+fileExtension;
		int retcode= MxZip.zipFile(cmd);
		if (retcode != 0){
			fileZipCompleted=false;
			mxLog.writeLog(getName()+".depositFile(): Unable to zip file - " + outputFilePath);
			
			
		}
	} catch (Exception e) {
		e.printStackTrace();
		String emailContent = genEmail(e);
        email.send(emailSubj, emailContent);
		
	}
	
	return fileZipCompleted;
	
}

public static String readQueryFromFile(String filePath) {
    StringBuilder query = new StringBuilder();
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            query.append(line).append(" "); 
        }
    } catch (IOException e) {
        System.out.println("Error reading SQL file: " + e.getMessage());
    }
    return query.toString().trim();
}

    
private boolean writeFile(DBShortcut dbShortcut)
	throws Exception
{
	System.out.println();
	ResultSet fleetRSet=null;
	//ResultSet mhrsRSet=null;
	ResultSet bdnhrsRSet=null;
	ResultSet rfbhrsRSet=null;
	ResultSet rprhrsRSet=null;
	ResultSet newmhrsRSet=null;
	ResultSet tifRSet=null;
	ResultSet fuelRSet=null;
	ResultSet oiLocationSet=null;
	
	String[] terminalArray=terminal.split(delimiter);
	String[] equipmentTypeArray=equipmentType.split(delimiter);
	//String[] workTypeTechArray=workTypeTech.split(delimiter);
	workTypeTech="'"+workTypeTech.replaceAll(",", "','")+"'";
			
	File outFile = new File(processDirectory+fileName+fileExtension);
	File oioutFile = new File(outputFilePath+oiLocName+fileExtension);
	FileWriter fWriter = new FileWriter(outFile);
	FileWriter fWriter1 = new FileWriter(oioutFile);
	BufferedWriter bWriter =  new BufferedWriter(fWriter);
	BufferedWriter bWriter1 =  new BufferedWriter(fWriter1);
	String output="";
	String output1="";
	
	/*
	 * 07-SEP-2020: BCT modification starts 
	 * Oracle to SQL conversion
	 */
	try
	{
  	dbShortcut.connect(getRunasUserInfo().getConnectionKey());
		for(int terminalLen=0;terminalLen<terminalArray.length;terminalLen++)
		{
			for(int equipLen=0;equipLen<equipmentTypeArray.length;equipLen++)
			{
			   //for(int wrktyLen=0;wrktyLen<workTypeTechArray.length;wrktyLen++)
			   //{
				
				String subType=equipmentTypeArray[equipLen];
				String querySubType;
						
				if(subType.equalsIgnoreCase("RTG"))
						querySubType="TT";
				else if(subType.equalsIgnoreCase("ERTG"))
						querySubType="TT";
				else
						querySubType=subType;
				
				String fleetQuery = null;
				
				//BCT Modified the query from Oracle to SQL format.
				
				if(subType.equalsIgnoreCase("RTG"))
					fleetQuery ="select ISNULL((SELECT format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+terminal_c+','+(CASE SUBTYPE+LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1' THEN 'ERTG' ELSE SUBTYPE END) +',"+fleetSizeCode+",'+ltrim(str(count(1))) as result from locations where terminal_c is not null AND prefix is not null AND TYPE = 'OPERATING' AND status='OPERATING' AND functiontype<>'TR' AND functiontype in (SELECT DISTINCT functiontype  FROM locations where functiontype is not null and functiontype<>'TR' and 1=1 ) AND terminal_c='"+terminalArray[terminalLen]+"' AND subtype='"+querySubType+"' AND ertg_i=0 GROUP BY terminal_c,subtype,ertg_i), format(DATEADD(MONTH,-1,getdate()),'MMM_yyyy')+ ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+fleetSizeCode+",0')";
				else if(subType.equalsIgnoreCase("ERTG"))
					fleetQuery ="select ISNULL((SELECT format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+terminal_c+','+(CASE SUBTYPE+LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1' THEN 'ERTG' ELSE SUBTYPE END) +',"+fleetSizeCode+",'+ltrim(str(count(1))) as result from locations where terminal_c is not null AND prefix is not null AND TYPE = 'OPERATING' AND status='OPERATING' AND functiontype<>'TR' AND functiontype in (SELECT DISTINCT functiontype  FROM locations where functiontype is not null and functiontype<>'TR' and 1=1 ) AND terminal_c='"+terminalArray[terminalLen]+"' AND subtype='"+querySubType+"' AND ertg_i=1 GROUP BY terminal_c,subtype,ertg_i), format(DATEADD(MONTH,-1,getdate()),'MMM_yyyy')+ ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+fleetSizeCode+",0')";
				else
					fleetQuery ="select ISNULL((SELECT format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+terminal_c+','+(CASE SUBTYPE+LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1' THEN 'ERTG' ELSE SUBTYPE END) +',"+fleetSizeCode+",'+ltrim(str(count(1))) as result from locations where terminal_c is not null AND prefix is not null AND TYPE = 'OPERATING' AND status='OPERATING' AND functiontype<>'TR' AND functiontype in (SELECT DISTINCT functiontype  FROM locations where functiontype is not null and functiontype<>'TR' and 1=1 ) AND terminal_c='"+terminalArray[terminalLen]+"' AND subtype='"+querySubType+"' GROUP BY terminal_c,subtype,ertg_i), format(DATEADD(MONTH,-1,getdate()),'MMM_yyyy')+ ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+fleetSizeCode+",0')";
				
				SqlFormat fleetSql=new SqlFormat(fleetQuery);
				fleetRSet = dbShortcut.executeQuery(fleetSql.format());
				
				
				if(fleetRSet!=null)
				{
					if(fleetRSet.next())
					{
						output = fleetRSet.getString(1);
						String[] outputArray=(output).split(",");
						try
						{
						
								bWriter.write(output);// Output String is written into the file
								bWriter.newLine();
								mxLog.writeLog("Execute Query : "+fleetQuery);// log file writing
								mxLog.writeLog("Output : "+output);// log file writing
								
								String	bdnhrsQuery = null;
								
								if(subType.equalsIgnoreCase("RTG"))
									bdnhrsQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+bdnhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"' AND ertg_i = 0 GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype='BDN' AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 0 AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype='BDN' AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 0 AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+bdnhrsCode+",0')";
								else if(subType.equalsIgnoreCase("ERTG"))
									bdnhrsQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+bdnhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"' AND ertg_i = 1 GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype='BDN' AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 1 AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype='BDN' AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 1 AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+bdnhrsCode+",0')";
								else
									bdnhrsQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+bdnhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"'  GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype='BDN' AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"'  AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND workorder.worktype='BDN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"'  AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+bdnhrsCode+",0')";
								
								SqlFormat bdnhrsSql=new SqlFormat(bdnhrsQuery);
								bdnhrsRSet = dbShortcut.executeQuery(bdnhrsSql.format());
								if(bdnhrsRSet!=null)
								{
									if(bdnhrsRSet.next())
									{
										output = bdnhrsRSet.getString(1);						
										bWriter.write(output);// Output String is written into the file
										bWriter.newLine();
									}
									mxLog.writeLog("BDNHRS Execute Query : "+bdnhrsQuery);// log file writing
									mxLog.writeLog("Output : "+output);// log file writing
								}
								bdnhrsRSet.close();
								
								String	rfbQuery = null;
								
								if(subType.equalsIgnoreCase("RTG"))
									rfbQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+rfbhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"' AND ertg_i = 0 GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('FFF','CWIPP') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 0 AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('FFF','CWIPP') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 0 AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+rfbhrsCode+",0')";
								else if(subType.equalsIgnoreCase("ERTG"))
									rfbQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+rfbhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"' AND ertg_i = 1 GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('FFF','CWIPP') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 1 AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('FFF','CWIPP') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 1 AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+rfbhrsCode+",0')";
								else
									rfbQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+rfbhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"'  GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('FFF','CWIPP') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"'  AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('FFF','CWIPP') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"'  AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+rfbhrsCode+",0')";
								
								SqlFormat rfbhrsSql=new SqlFormat(rfbQuery);
								rfbhrsRSet = dbShortcut.executeQuery(rfbhrsSql.format());
								
								if(rfbhrsRSet!=null)
								{
									if(rfbhrsRSet.next())
									{
										output = rfbhrsRSet.getString(1);						
										bWriter.write(output);// Output String is written into the file
										bWriter.newLine();
									}
									mxLog.writeLog("RFBHRS Execute Query : "+rfbQuery);// log file writing
									mxLog.writeLog("Output : "+output);// log file writing
								}
								rfbhrsRSet.close();
								
								
                                String	rprQuery = null;
								
								if(subType.equalsIgnoreCase("RTG"))
									rprQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+rprhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"' AND ertg_i = 0 GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 0 AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 0 AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+rprhrsCode+",0')";
								else if(subType.equalsIgnoreCase("ERTG"))
									rprQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+rprhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"' AND ertg_i = 1 GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 1 AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 1 AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+rprhrsCode+",0')";
								else
									rprQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+rprhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"'  GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"'  AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype in ('CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"'  AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+rprhrsCode+",0')";
								
								SqlFormat rprhrsSql=new SqlFormat(rprQuery);
								rprhrsRSet = dbShortcut.executeQuery(rprhrsSql.format());
								
								if(rprhrsRSet!=null)
								{
									if(rprhrsRSet.next())
									{
										output = rprhrsRSet.getString(1);						
										bWriter.write(output);// Output String is written into the file
										bWriter.newLine();
									}
									mxLog.writeLog("RPRHRS Execute Query : "+rprQuery);// log file writing
									mxLog.writeLog("Output : "+output);// log file writing
								}
								rprhrsRSet.close();
								
								String	newmhrsQuery = null;
								
								
								//BCT Modified the query from Oracle to SQL format.
									
								
									if(subType.equalsIgnoreCase("RTG"))
										newmhrsQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+newmhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"' AND ertg_i = 0 GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype not in ('BDN','FFF','CWIPP','CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 0 AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype not in ('BDN','FFF','CWIPP','CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 0 AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+newmhrsCode+",0')";
									else if(subType.equalsIgnoreCase("ERTG"))
										newmhrsQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+newmhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"' AND ertg_i = 1 GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype not in ('BDN','FFF','CWIPP','CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 1 AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype not in ('BDN','FFF','CWIPP','CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"' AND ertg_i = 1 AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+newmhrsCode+",0')";
									else
										newmhrsQuery="SELECT isnull(( SELECT convert(varchar, format(dateadd(month, - 1, getdate()), 'MMM_yyyy')) + ',' + terminal_c + ',' + (CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END) + ',"+newmhrsCode+",' + ltrim(str(round((1 -(cast((totalavailhrs - isnull(machavail, 0) + isnull(intavailhrs, 0)) as float) / cast(totalavailhrs as float))) * totalavailhrs, 0))) FROM ( SELECT terminal_c, ertg_i, subtype, COUNT(1)*(SELECT format(dateadd(d, 0, eomonth(getdate(), - 1)), 'dd' ) ) * 24 AS totalavailhrs FROM locations WHERE locations.terminal_c IS NOT NULL AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING' AND locations.functiontype <> 'TR' AND locations.functiontype IN ( SELECT DISTINCT    functiontype  FROM  locations WHERE functiontype IS NOT NULL AND functiontype <> 'TR' AND 1 = 1) AND terminal_c = '"+terminalArray[terminalLen]+"' AND subtype = '"+querySubType+"'  GROUP BY terminal_c, subtype, ertg_i) fleet , (SELECT SUM(machavail) as machavail FROM ( SELECT datediff(day, isnull(( SELECT wo1.actstart FROM workorder wo1 WHERE wo1.wonum = workorder.wonum AND wo1.siteid =  workorder.siteid AND wo1.actstart >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wo.actfinish FROM workorder wo WHERE wo.wonum =workorder.wonum AND wo.siteid = workorder.siteid AND wo.actfinish <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) * 24 AS machavail FROM workorder,  locations  WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype not in ('BDN','FFF','CWIPP','CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"'  AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format (dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy' ) OR workorder.actfinish IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND workorder.istask = 0 AND workorder.downtime = 1) machhrs) machhrs, (SELECT SUM(intavailhrs) as intavailhrs FROM (SELECT ( datediff(day, isnull(( SELECT wi1.startdate FROM wointerrupt wi1 WHERE wi1.wointerruptid = wointerrupt.wointerruptid AND wi1.startdate >= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy')), isnull((SELECT wi.enddate FROM wointerrupt wi WHERE wi.wointerruptid = wointerrupt.wointerruptid AND wi.enddate <= format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy')), format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy'))) ) * 24 AS intavailhrs FROM workorder,locations,wointerrupt WHERE workorder.status <> 'CAN' AND locations.prefix IS NOT NULL AND locations.type = 'OPERATING' AND locations.status = 'OPERATING'  AND workorder.worktype not in ('BDN','FFF','CWIPP','CMT','APB','APN','CSB','CSN','STP','ACR','ACC','ACD','ACE','ACH','ACM','ACO','ACX','CSA','APA') AND locations.terminal_c = '"+terminalArray[terminalLen]+"' AND locations.subtype = '"+querySubType+"'  AND wointerrupt.interruptcode = '00'  AND ( ( wointerrupt.startdate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy'  ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.enddate BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy' ) AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') )  OR ( wointerrupt.startdate <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( wointerrupt.enddate >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR wointerrupt.enddate IS NULL ) ) ) AND workorder.location = locations.location AND workorder.siteid = locations.siteid AND ( ( workorder.actstart BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)), 'dd/MMM/yyyy') ) OR ( workorder.actfinish BETWEEN format(dateadd(d, 1, eomonth(getdate(), - 2)),'dd/MMM/yyyy') AND format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') ) OR ( workorder.actstart <= format(dateadd(d, 1, eomonth(getdate(), - 2)), 'dd/MMM/yyyy') AND ( workorder.actfinish >= format(dateadd(d, 1, eomonth(getdate(), - 1)),'dd/MMM/yyyy') OR workorder.actfinish IS NULL ) ) )  AND workorder.wonum = wointerrupt.wonum  AND workorder.siteid = wointerrupt.siteid  AND workorder.istask = 0 AND workorder.downtime = 1 ) intavail ) intavail  ) , format(dateadd(month,-1, getdate()), 'MMM_yyyy') + ',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+newmhrsCode+",0')";
										
									SqlFormat newmhrsSql=new SqlFormat(newmhrsQuery);
									newmhrsRSet = dbShortcut.executeQuery(newmhrsSql.format());
									if(newmhrsRSet!=null)
									{
										if(newmhrsRSet.next())
										{
											output = newmhrsRSet.getString(1);						
											bWriter.write(output);// Output String is written into the file
											bWriter.newLine();
										}
										mxLog.writeLog("Execute Query : "+newmhrsQuery);// log file writing
										mxLog.writeLog("Output : "+output);// log file writing
									}
									newmhrsRSet.close();

								String tifQuery = null;
								
								//BCT changed the below Query to SQL.

								if(subType.equalsIgnoreCase("RTG"))
									tifQuery ="SELECT isnull((format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+LOCATIONS.terminal_c+','+(CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END)+',"+ tif +",'+ltrim(str(count(1)))),format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+ tif +",0') FROM WORKORDER, LOCATIONS WHERE workorder.worktype in ("+workTypeTech+") and workorder.status<>'CAN' and locations.terminal_c='"+terminalArray[terminalLen]+"'  AND locations.prefix is not null and locations.subtype='"+querySubType+"' AND ertg_i=0 and workorder.reportdate >=  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-2)),'dd/MMM/yyyy') AND workorder.reportdate <  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-1)),'dd/MMM/yyyy') and workorder.location=locations.location and workorder.siteid=locations.siteid and workorder.istask=0 GROUP BY LOCATIONS.terminal_c,subtype,ertg_i";
								else if(subType.equalsIgnoreCase("ERTG"))
									tifQuery ="SELECT isnull((format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+LOCATIONS.terminal_c+','+(CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END)+',"+ tif +",'+ltrim(str(count(1)))),format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+ tif +",0') FROM WORKORDER, LOCATIONS WHERE workorder.worktype in ("+workTypeTech+") and workorder.status<>'CAN' and locations.terminal_c='"+terminalArray[terminalLen]+"'  AND locations.prefix is not null and locations.subtype='"+querySubType+"' AND ertg_i=1 and workorder.reportdate >=  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-2)),'dd/MMM/yyyy') AND workorder.reportdate <  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-1)),'dd/MMM/yyyy') and workorder.location=locations.location and workorder.siteid=locations.siteid and workorder.istask=0 GROUP BY LOCATIONS.terminal_c,subtype,ertg_i";
								else
									tifQuery ="SELECT isnull((format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+LOCATIONS.terminal_c+','+(CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END)+',"+ tif +",'+ltrim(str(count(1)))),format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+ tif +",0') FROM WORKORDER, LOCATIONS WHERE workorder.worktype in ("+workTypeTech+") and workorder.status<>'CAN' and locations.terminal_c='"+terminalArray[terminalLen]+"'  AND locations.prefix is not null and locations.subtype='"+querySubType+"' and workorder.reportdate >=  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-2)),'dd/MMM/yyyy') AND workorder.reportdate <  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-1)),'dd/MMM/yyyy') and workorder.location=locations.location and workorder.siteid=locations.siteid and workorder.istask=0 GROUP BY LOCATIONS.terminal_c,subtype,ertg_i";
								
								SqlFormat tifSql=new SqlFormat(tifQuery);
								tifRSet = dbShortcut.executeQuery(tifSql.format());
								if(tifRSet!=null)
								{
									//tifRSet = tifPStmt.executeQuery();
									if(tifRSet.next())
									{
										output = tifRSet.getString(1);
										bWriter.write(output);// Output String is written into the file
										bWriter.newLine();
									}
									mxLog.writeLog("Execute Query : "+tifQuery);// log file writing
									mxLog.writeLog("Output : "+output);// log file writing
								}
								tifRSet.close();
						
								
								if(querySubType.equalsIgnoreCase("TT") || subType.equalsIgnoreCase("FM"))
								{
									String	fuelQuery = null;
									if(subType.equalsIgnoreCase("RTG"))
										fuelQuery ="SELECT isnull((SELECT format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+TERMINAL_C+','+(CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END)+',"+fuelCode+",'+LTRIM(STR(Sum(Delta)))),format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+fuelCode+",0') FROM LOCMETERREADING, LOCATIONS WHERE locations.TERMINAL_C = '"+terminalArray[terminalLen]+"' and locmeterreading.metername='"+fuelCode+"' AND locations.prefix is not null AND locations.subtype='"+querySubType+"' AND ertg_i=0 and readingdate >=  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-2)),'dd/MMM/yyyy') AND readingdate <   FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-1)),'dd/MMM/yyyy') and locmeterreading.location=locations.location and locmeterreading.siteid=locations.siteid GROUP BY terminal_c,subtype,ertg_i";
									else if(subType.equalsIgnoreCase("ERTG"))
										fuelQuery ="SELECT isnull((SELECT format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+TERMINAL_C+','+(CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END)+',"+fuelCode+",'+LTRIM(STR(Sum(Delta)))),format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+fuelCode+",0') FROM LOCMETERREADING, LOCATIONS WHERE locations.TERMINAL_C = '"+terminalArray[terminalLen]+"' and locmeterreading.metername='"+fuelCode+"' AND locations.prefix is not null AND locations.subtype='"+querySubType+"' AND ertg_i=1 and readingdate >=  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-2)),'dd/MMM/yyyy') AND readingdate <   FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-1)),'dd/MMM/yyyy') and locmeterreading.location=locations.location and locmeterreading.siteid=locations.siteid GROUP BY terminal_c,subtype,ertg_i";
									else
										fuelQuery ="SELECT isnull((SELECT format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+','+TERMINAL_C+','+(CASE subtype + LTRIM(str(ERTG_I)) WHEN 'TT0' THEN 'RTG' WHEN 'TT1'   THEN 'ERTG' ELSE subtype END)+',"+fuelCode+",'+LTRIM(STR(Sum(Delta)))),format(DATEADD(MONTH,-1,GETDATE()),'MMM_yyyy')+',"+terminalArray[terminalLen]+","+equipmentTypeArray[equipLen]+","+fuelCode+",0') FROM LOCMETERREADING, LOCATIONS WHERE locations.TERMINAL_C = '"+terminalArray[terminalLen]+"' and locmeterreading.metername='"+fuelCode+"' AND locations.prefix is not null AND locations.subtype='"+querySubType+"' and readingdate >=  FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-2)),'dd/MMM/yyyy') AND readingdate <   FORMAT(DATEADD(d, 1, EOMONTH(getdate(),-1)),'dd/MMM/yyyy') and locmeterreading.location=locations.location and locmeterreading.siteid=locations.siteid GROUP BY terminal_c,subtype,ertg_i";
									
							/*
							 * 
							 * BCT Oracle to SQL conversion ends
							 * 		
							 */
									SqlFormat fuelSql=new SqlFormat(fuelQuery);
						
									fuelRSet = dbShortcut.executeQuery(fuelSql.format());
						
									if(fuelRSet!=null)
									{
										if(fuelRSet.next())
										{
		 									output = fuelRSet.getString(1);
											bWriter.write(output);// Output String is written into the file
											bWriter.newLine();
										}
										mxLog.writeLog("Execute Query : "+fuelQuery);// log file writing
										mxLog.writeLog("Output : "+output);// log file writing
									}
									
									fuelRSet.close();
								}
								
//							}
						}catch(Exception e)
						{
							mxLog.writeLog("fleetsize conversation error : "+e);// log file writing
					
						}
					}
					else
					{
						mxLog.writeLog("Execute Query : "+fleetQuery);// log file writing
					}
					fleetRSet.close();
				}
				//}
			}
		} 
		
		/* To generate Location mapping file*/
		{
		mxLog.writeLog("Mapping file copying to OutputfilePath");
		MxFileCopy.fileCopy(locMapPath,outputFilePath + locMapName+".dat");
		mxLog.writeLog("Mapping file copied to OutputfilePath");
		}
		
		/* To generate OI Location file*/
		
		String	oilocationQuery = null;
		
        oilocationQuery = readQueryFromFile(oiLocSqlPath);
		
		//oilocationQuery ="select isnull(location, '')+','+ISNULL(CASE ISNULL(SUBTYPE, '')+ISNULL(LTRIM(str(ERTG_I)), '') WHEN 'TT0' THEN 'RTG' WHEN 'TT1' THEN 'ERTG' ELSE SUBTYPE END, '') +','+isnull(prefix, '')+','+isnull(terminal_c, '') from [MAXIMO].[dbo].[locations] where (psa_department not in ('CTME', 'P123ME', 'P456ME') or SUBTYPE='FM') and terminal_c is not null and prefix is not null and SUBTYPE is not null and status='OPERATING' order by location;";
		
		SqlFormat oilocationSql=new SqlFormat(oilocationQuery);
		
		oiLocationSet = dbShortcut.executeQuery(oilocationSql.format());

		if(oiLocationSet!=null)
		{
			while(oiLocationSet.next())
			{
				output1 = oiLocationSet.getString(1);
				bWriter1.write(output1);// Output String is written into the file
				bWriter1.newLine();
				bWriter1.flush();
				mxLog.writeLog("Execute Query : "+oilocationQuery);// log file writing
				mxLog.writeLog("Output1 : "+output1);// log file writing
			}
			
		}		
		try {
			String zipoutputFilePath1 = outputFilePath+locMapName+".dat";
			String zipoutputFilePath2 = outputFilePath+oiLocName;
			String cmd1 = zipExec + SPACE + zipoutputFilePath1;
			String cmd2 = zipExec + SPACE + zipoutputFilePath2+fileExtension;
			mxLog.writeLog("cmd1 "+ cmd1);
		    mxLog.writeLog("cmd2 "+ cmd2);
			int retcode1= MxZip.zipFile(cmd1);
			int retcode2= MxZip.zipFile(cmd2);
			if (retcode1 != 0 || retcode2 != 0){
				mxLog.writeLog(getName()+".depositFile(): Unable to zip file - " + outputFilePath);	
			}
		} catch (Exception e) {
			e.printStackTrace();
			String emailContent = genEmail(e);
	        email.send(emailSubj, emailContent);
			
		}
		
		/*
		 * 07-SEP-2020: BCT modification ends
		 * Oracle to SQL conversion
		 */
	    
	}
	catch(Exception e)
	{
		e.getMessage();
		e.printStackTrace();
		String emailContent = genEmail(e);
        email.send(emailSubj, emailContent);
	}
	finally
	{
		bWriter1.close();
		fWriter1.close();
		bWriter.close();
		fWriter.close();
		fleetRSet.close();
		oiLocationSet.close();
		//mhrsRSet.close();
		bdnhrsRSet.close();
		rfbhrsRSet.close();
		rprhrsRSet.close();
		newmhrsRSet.close();
		tifRSet.close();
		fuelRSet.close();
		dbShortcut.close();
		MXServer.getMXServer().getDBManager().freeConnection(getRunasUserInfo().getConnectionKey());
	}
	return true;
}



private void refreshSettings()
{
	try 
	{
		alertEmail = getParamAsString("ALERTEMAIL");
		email.setAdmin(alertEmail);	 
		emailSubj = getParamAsString("EMAILSUBJ");
		fileExtension = getParamAsString("FILEEXTENSION");
		locMapPath=getParamAsString("LOCMAPPATH");
		oiLocSqlPath=getParamAsString("OILOCSQLPATH");
		processDirectory = getParamAsString("PROCESSDIRECTORY");
		fileName = getParamAsString("FILENAME");
		locMapName = getParamAsString("LOCMAPNAME");
		oiLocName = getParamAsString("OILOCNAME");
		logFilePath = getParamAsString("LOGFILEPATH");
		logFile = getParamAsString("LOGFILE");	 
		Date curDate = new Date();
		DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
	    String fileDateStr = fileDateTimeFormat.format(curDate);
		logFile = logFile.replaceAll("yyyyMMdd", fileDateStr);
			 
		logFilePath =logFilePath+logFile;
        mxLog.setLogFilePath(logFilePath);
        mxLog.setLogTag(getName());
        mxLog.setEnabled(true);
        mxLog.createLogFile();
             
		scpLocalFilePath = getParamAsString("SCPLOCALFILEPATH");
	    scpRMFilePath = getParamAsString("SCPRMFILEPATH");
		scpConfigFile = getParamAsString("SCPCONFIGFILE");
		scpRMServerName = getParamAsString("SCPRMSERVERNAME");
		delimiter = getParamAsString("DELIMITER");
		zipExec = getParamAsString("ZIPEXEC");			
		terminal =getParamAsString("TERMINAL");
		equipmentType=getParamAsString("EQUIPMENTTYPE");
		fleetSizeCode=getParamAsString("FLEETSIZECODE");
		//mhrsCode=getParamAsString("MHRSCODE");
		bdnhrsCode=getParamAsString("BDNHRSCODE");
		rfbhrsCode=getParamAsString("RFBHRSCODE");
		rprhrsCode=getParamAsString("RPRHRSCODE");
		newmhrsCode=getParamAsString("NEWMHRSCODE");
		tif=getParamAsString("TIF");
		fuelCode=getParamAsString("FUELCODE");
		workTypeTech=getParamAsString("WORKTYPETECH");
		outputFilePath=getParamAsString("OUTPUTFILEPATH");
	}
	catch(Exception exception) 
	{
		logger.info("exception.getMessage() crontask:" + exception);
	}
}
	 
private boolean isReqParamSet() 
{
  if (fileExtension.equalsIgnoreCase(""))
  	return false;
  if (processDirectory.equalsIgnoreCase(""))
  	return false;
  if (fileName.equalsIgnoreCase(""))
  	return false;
  if (locMapName.equalsIgnoreCase(""))
	  return false;
  if (oiLocName.equalsIgnoreCase(""))
	  return false;
  if (logFilePath.equalsIgnoreCase(""))
  	return false;
  if (locMapPath.equalsIgnoreCase(""))
	  	return false;
  if (oiLocSqlPath.equalsIgnoreCase(""))
	  	return false;
  if (logFile.equalsIgnoreCase(""))
  	return false;
  if (delimiter.equalsIgnoreCase(""))
  	return false;
  if (zipExec.equalsIgnoreCase(""))
  	return false;
  if (terminal.equalsIgnoreCase(""))
  	return false;
  if (equipmentType.equalsIgnoreCase(""))
  	return false;
  if (fleetSizeCode.equalsIgnoreCase(""))
  	return false;
  if (bdnhrsCode.equalsIgnoreCase(""))
	  	return false;
  if (rfbhrsCode.equalsIgnoreCase(""))
	  	return false;
  if (rprhrsCode.equalsIgnoreCase(""))
	  	return false;
  if (newmhrsCode.equalsIgnoreCase(""))
	  	return false;
  if (tif.equalsIgnoreCase(""))
  	return false;
  if (fuelCode.equalsIgnoreCase(""))
  	return false;
  if (workTypeTech.equalsIgnoreCase(""))
  	return false;
  if (outputFilePath.equalsIgnoreCase(""))
  	return false;
  return true;
}
	 
private String genEmail(Exception e) 
{
  // Form Email Message
  String emailMsg = "Date: " + new Date() + "\n";
  emailMsg += "Error in CronTask: " + getName() + "\n";
  emailMsg += "Error Message: " + e.getMessage() + "\n";
  emailMsg += "Detail:\n";
  emailMsg += e.toString() + "\n";
  StackTraceElement element[] = e.getStackTrace();
  for (int i = 0; i < element.length; i++) 
  {
  	emailMsg += "\tat " + element[i].toString() + "\n";
  }

  return emailMsg;
}
}