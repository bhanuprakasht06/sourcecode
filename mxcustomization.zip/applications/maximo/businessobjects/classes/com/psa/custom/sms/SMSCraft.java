package com.psa.custom.sms;

import java.rmi.RemoteException;

import psdi.app.craft.CraftRemote;
import psdi.app.craft.CraftSetRemote;
import psdi.app.craft.CraftSkillRemote;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXException;

/*
 * Author: BTE
 * 05 APR 2006 - Initial version
 */
public class SMSCraft extends MicSetIn  {

	/*
	 * Variables
	 */
	private UserInfo userInfo;

	private static SMSConstant SMS = new SMSConstant();
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - constructor  
	 */	
	public SMSCraft(UserInfo userInfo) throws MXException, RemoteException {		 
		this.userInfo = userInfo;
	}
	 
	 	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Check craft exists in database based on orgid and craft.  
	 */	
	public boolean isCraftExist(String orgid, String craft) 
	 	throws MXException, RemoteException {		
	   
		INTEGRATIONLOGGER.debug("Entering isCraftExist");
		
		// Check if vaiables is null
		if(orgid == null || craft == null ) {
		   return false;
		}
		 
		CraftSetRemote craftSet = (CraftSetRemote) MXServer.getMXServer().getMboSet(SMS.CRAFT, userInfo);
				
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("CRAFT= :2");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != SMS.EMPTY){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.CRAFT, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.CRAFT, SMS.CRAFT, craft);
			craftSet.setWhere(sqlformat.format());
			
			if(!craftSet.isEmpty()) {
		
				CraftRemote craftRemote = (CraftRemote) craftSet.getMbo(0);
		
				if(!craftRemote.isNull(SMS.CRAFT)){
					INTEGRATIONLOGGER.debug("Leaving isCraftExist");
					return true;
				}
			}
		}			
			
		INTEGRATIONLOGGER.debug("Leaving isCraftExist");
		return false;		   
	}
	 
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Check craftskill exists in database based on orgid, craft and skilllevel.  
	 */		
	public boolean isCraftSkillExist(String orgid, String craft, String skillLevel) 
		throws MXException, RemoteException {
	   
		INTEGRATIONLOGGER.debug("Entering isCraftSkillExist");
		
		// Check if vaiables is null
		if(orgid == null || craft == null || skillLevel == null) {
			return false;
		}
		 
		MboSetRemote craftSkillSet = (MboSetRemote) MXServer.getMXServer().getMboSet(SMS.CRAFTSKILL, userInfo);
				
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("CRAFT= :2");
		combinewhereclauses.addWhere("SKILLLEVEL= :3");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.CRAFTSKILL, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.CRAFTSKILL, SMS.CRAFT, craft);
			sqlformat.setObject(3, SMS.CRAFTSKILL, SMS.SKILLLEVEL, skillLevel);
			craftSkillSet.setWhere(sqlformat.format());
			
			if(!craftSkillSet.isEmpty()) {
		
				CraftSkillRemote craftSkillRemote = (CraftSkillRemote) craftSkillSet.getMbo(0);
		
				if(!craftSkillRemote.isNull(SMS.CRAFT)){
					INTEGRATIONLOGGER.debug("Leaving isCraftSkillExist");
					return true;
				}
			}
		}			
			
		INTEGRATIONLOGGER.debug("Leaving isCraftSkillExist");
		return false;		   
	}
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Add craft in database based on orgid and craft.  
	 */
	public boolean addCraft(String orgid, String craft, String description) 
 		throws MXException, RemoteException {
	   
		INTEGRATIONLOGGER.debug("Entering addCraft");
		
		// Check if vaiables is null
		if(orgid == null || craft == null ) {
			INTEGRATIONLOGGER.debug("Leaving addCraft");
			return false;
		}
		 
		CraftSetRemote craftSet = (CraftSetRemote) MXServer.getMXServer().getMboSet(SMS.CRAFT, userInfo);		
				
		craftSet.add(0);
		craftSet.setValue(SMS.ORGID, orgid);
		craftSet.setValue(SMS.CRAFT, craft);
		craftSet.setValue(SMS.DESCRIPTION, description);
		
		craftSet.save(0);
		craftSet.commit();		
		craftSet.close();
			
		INTEGRATIONLOGGER.debug("Leaving addCraft");
		return true;													   
	}
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Add craft in database based on orgid and craft.  
	 */
	public boolean updateCraft(String orgid, String craft, String description) 
 		throws MXException, RemoteException {
	   
		INTEGRATIONLOGGER.debug("Entering updateCraft");
		
		// Check if vaiables is null
		if(orgid == null || craft == null ) {
		   return false;
		}
		 
		CraftSetRemote craftSet = (CraftSetRemote) MXServer.getMXServer().getMboSet(SMS.CRAFT, userInfo);

		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
		
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("CRAFT= :2");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.CRAFT, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.CRAFT, SMS.CRAFT, craft);
			craftSet.setWhere(sqlformat.format());
			
			if(!craftSet.isEmpty()) {
		
				CraftRemote craftRemote = (CraftRemote) craftSet.getMbo(0);
		
				if(!craftRemote.isNull(SMS.CRAFT)){
					craftSet.getMbo(0).setValue(SMS.DESCRIPTION, description);
					
					craftSet.save(0);	
					craftSet.commit();	
					craftSet.close();

					INTEGRATIONLOGGER.debug("Leaving updateCraft");
					return true;
				}
			}
		}	

		INTEGRATIONLOGGER.debug("Leaving updateCraft");
		return true;		   
	}		
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Add craftskill in database based on orgid and craft.  
	 */
	public boolean addCraftSkill(String orgid, String craft, String description, String skillLevel) 
 		throws MXException, RemoteException {
	   
		INTEGRATIONLOGGER.debug("Entering addCraftSkill");
		
		// Check if vaiables is null
		if(orgid == null || craft == null ) {
			INTEGRATIONLOGGER.debug("Leaving addCraftSkill");			
			return false;
		}
		
		// Add CRAFTSKILL
		MboSetRemote craftSkillSet = (MboSetRemote) MXServer.getMXServer().getMboSet(SMS.CRAFTSKILL, userInfo);
	
		craftSkillSet.add(0);		
		craftSkillSet.setValue(SMS.ORGID, orgid);
		craftSkillSet.setValue(SMS.CRAFT, craft);
		craftSkillSet.setValue(SMS.SKILLLEVEL, skillLevel);		
		craftSkillSet.setValue(SMS.DESCRIPTION, description);
		craftSkillSet.setValue(SMS.RANK, 1);
	
		MboSetRemote craftRateSet = (MboSetRemote)craftSkillSet.getMbo(0).getMboSet(SMS.CRAFTRATE);
		craftRateSet.add(0);
		craftRateSet.setValue(SMS.ORGID, orgid);
		craftRateSet.setValue(SMS.CRAFT, craft);
		craftRateSet.setValue(SMS.SKILLLEVEL, skillLevel);			
		craftRateSet.setValue(SMS.VENDOR, SMS.EMPTY);
		craftRateSet.setValue(SMS.CONTRACTNUM, SMS.EMPTY);
		craftRateSet.setValue(SMS.REVISIONNUM, SMS.EMPTY);
					
		craftRateSet.save(0);	
		craftRateSet.commit();	
		craftRateSet.close();
		
		craftSkillSet.save(0);	
		craftSkillSet.commit();	
		craftSkillSet.close();
		
		INTEGRATIONLOGGER.debug("Leaving addCraftSkill");
		return true;		   
	}
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Add craftskill in database based on orgid and craft.  
	 */
	public boolean updateCraftSkill(String orgid, String craft, String description, String skillLevel) 
 		throws MXException, RemoteException {
	   
		INTEGRATIONLOGGER.debug("Entering updateCraftSkill");
		
		// Check if vaiables is null
		if(orgid == null || craft == null ) {
		   return false;
		}
		 
		MboSetRemote craftSkillSet = (MboSetRemote) MXServer.getMXServer().getMboSet(SMS.CRAFTSKILL, userInfo);
		
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
		
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("CRAFT= :2");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.CRAFT, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.CRAFT, SMS.CRAFT, craft);
			craftSkillSet.setWhere(sqlformat.format());
			
			for (int i=0; i < craftSkillSet.count(); i++) {
							
				CraftSkillRemote craftSkillRemote = (CraftSkillRemote) craftSkillSet.getMbo(i);		
							
				if(!craftSkillRemote.isNull(SMS.CRAFT)){
										
					craftSkillSet.getMbo(i).setValue(SMS.DESCRIPTION, description);					
				}							
			}
			
			if (craftSkillSet.count() != 0) {
				craftSkillSet.save();
				craftSkillSet.commit();						
				craftSkillSet.close();		
				
				INTEGRATIONLOGGER.debug("Leaving updateCraftSkill");
				return true;
			}
		}	

		INTEGRATIONLOGGER.debug("Leaving updateCraftSkill");		
		return false;			   
	}		
}
