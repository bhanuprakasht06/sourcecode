package com.psa.custom.oa12i;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;
import psdi.iface.mic.StructureData;
import psdi.iface.oa12.ERPInExt;
import psdi.iface.proc.ControlsCache;
import psdi.mbo.MaximoDD;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.mbo.Translate;
import psdi.security.UserInfo;
import psdi.server.AppService;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
 
public class PSA_PCInExt
  extends ERPInExt
{
  public StructureData setDataIn(StructureData paramStructureData)
    throws MXException, RemoteException
  {
    integrationLogger.debug("Entering PCInExt.setDataIn");
    ControlsCache localControlsCache = getMaxIfaceControl();
    paramStructureData = super.setDataIn(paramStructureData);
    
    Translate localTranslate = MXServer.getMXServer().getMaximoDD().getTranslator();
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("CONTRACTNUM: " + paramStructureData.getCurrentData("PONUM"));
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("STATUSIFACE: " + paramStructureData.getCurrentData("STATUSIFACE"));
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("STATUS: " + paramStructureData.getCurrentData("STATUS"));
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("CONTRACTTYPE: " + paramStructureData.getCurrentData("POTYPE"));
    }
    paramStructureData.setCurrentData("ORGID", getXREFValue("ORGXREF", paramStructureData.getCurrentData("ORGID")));
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("ORGID: " + paramStructureData.getCurrentData("ORGID"));
    }
    paramStructureData.setCurrentData("CONTRACTTYPE", getXREFValue("PCTYPEXREF", paramStructureData.getCurrentData("ORGID"), null, paramStructureData.getCurrentData("CONTRACTTYPE")));
    List localObject1;
	if ((!paramStructureData.isCurrentDataNull("STATUS")) && (paramStructureData.getCurrentData("STATUS").equals("CAN")))
    {
      setRevisionNum(paramStructureData);
    }
    else if ((!paramStructureData.isCurrentDataNull("OA_LINESTATUSIFACE_FLG")) && (paramStructureData.getCurrentDataAsBoolean("OA_LINESTATUSIFACE_FLG") == true))
    {
      localObject1 = paramStructureData.getChildrenData("CONTRACTLINE");
      if ((localObject1 != null) && (((List)localObject1).size() > 0)) {
        for (int i = ((List)localObject1).size() - 1; i >= 0; i--)
        {
          paramStructureData.setAsCurrent((List)localObject1, i);
          if ((!paramStructureData.isCurrentDataNull("LINESTATUS")) && (paramStructureData.getCurrentData("LINESTATUS").equals("CAN")))
          {
            paramStructureData.setParentAsCurrent();
            setRevisionNum(paramStructureData);
            break;
          }
        }
      }
    }
    MboSetRemote localObject2;
	if ((!paramStructureData.isCurrentDataNull("OA_LINESTATUSIFACE_FLG")) && (paramStructureData.getCurrentDataAsBoolean("OA_LINESTATUSIFACE_FLG") == true))
    {
      localObject1 = (List) new SqlFormat(getUserInfo(), "contractnum = :1 and revisionnum = :2 and orgid = :3 ");
      
      ((SqlFormat)localObject1).setObject(1, "PURCHVIEW", "CONTRACTNUM", paramStructureData.getCurrentData("CONTRACTNUM"));
      ((SqlFormat)localObject1).setObject(2, "PURCHVIEW", "REVISIONNUM", paramStructureData.getCurrentData("REVISIONNUM"));
      ((SqlFormat)localObject1).setObject(3, "PURCHVIEW", "ORGID", paramStructureData.getCurrentData("ORGID"));
      
      localObject2 = MXServer.getMXServer().getMboSet("PURCHVIEW", getUserInfo());
      ((MboSetRemote)localObject2).setWhere(((SqlFormat)localObject1).format());
      MboRemote localMboRemote = ((MboSetRemote)localObject2).moveFirst();
      if (localMboRemote != null)
      {
        String str1 = localMboRemote.getString("STATUS");
        String str3 = localTranslate.toInternalString("CONTRACTSTATUS", str1);
        if ((str3 != null) && ((str3.equals("CAN")) || (str3.equals("CLOSE"))))
        {
          if (integrationLogger.isDebugEnabled()) {
            integrationLogger.debug("Skipping the line status change because the STATUS  of the Contract is CAN or CLOSE");
          }
          throw new MXApplicationException("iface", "SKIP_TRANSACTION");
        }
      }
      ((MboSetRemote)localObject2).close();
      setLineStatus(paramStructureData);
      integrationLogger.debug("Leaving PCInExt.setDataIn");
      return paramStructureData;
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("STATUS before Setting: " + paramStructureData.getCurrentData("STATUS"));
    }
    if (!paramStructureData.isCurrentDataNull("STATUS")) {
      paramStructureData.setCurrentData("STATUS", getXREFValue("PCSTATUSXREF", paramStructureData.getCurrentData("ORGID"), null, paramStructureData.getCurrentData("STATUS")));
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("STATUS after setting: " + paramStructureData.getCurrentData("STATUS"));
    }
    if (paramStructureData.isCurrentDataNull("EXCHANGEDATE")) {
      paramStructureData.setCurrentData("EXCHANGEDATE", new Date(((AppService)getMboServer()).getMXServer().getDate().getTime()));
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("EXCHANGEDATE after setting: " + paramStructureData.getCurrentData("EXCHANGEDATE"));
    }
    if (!isValueControlNull("GENUSR", paramStructureData.getCurrentData("ORGID"), null)) {
      paramStructureData.removeFromCurrentData("CHANGEBY");
    }
    if ((!paramStructureData.isCurrentDataNull("REVCOMMENTS")) && (paramStructureData.getCurrentData("REVCOMMENTS").startsWith("oa_")))
    {
      String localObject3 = MXServer.getMXServer().getMessage("iface", paramStructureData.getCurrentData("REVCOMMENTS"), getUserInfo().getLangCode());
      
      paramStructureData.setCurrentData("REVCOMMENTS", (String)localObject3);
    }
    
    /*
    List localObject11 = paramStructureData.getChildrenData("CONTRACTAUTH");
    int j;
    String str2;
    if (localObject11 != null)
    {
      paramStructureData.setAsCurrent(localObject11, 0);
      
      paramStructureData.setCurrentData("AUTHORGID", paramStructureData.getParentData("ORGID"));
      if (integrationLogger.isDebugEnabled()) {
        integrationLogger.debug("AUTHORGID: " + paramStructureData.getCurrentData("AUTHORGID"));
      }
      System.out.println("++++++++++++++++++++++++++++Authsiteid: "+paramStructureData.getCurrentData("AUTHSITEID"));
      String authSiteID = "BT";
      paramStructureData.setCurrentData("AUTHSITEID", authSiteID);
      if (integrationLogger.isDebugEnabled()) {
        integrationLogger.debug("AUTHSITEID: " + paramStructureData.getCurrentData("AUTHSITEID"));
      }
      paramStructureData.setCurrentData("VENDOR", paramStructureData.getParentData("VENDOR"));
      if (integrationLogger.isDebugEnabled()) {
        integrationLogger.debug("AUTHVENDOR: " + paramStructureData.getCurrentData("VENDOR"));
      }
      MboSetRemote SiteSet = MXServer.getMXServer().getMboSet("SITE", getUserInfo());
      SiteSet.setWhere("orgid = '"+paramStructureData.getParentData("ORGID")+"' and active = 1");
	  System.out.println("######################## SITESET SIZE: "+SiteSet.count());
      paramStructureData.setParentAsCurrent();
      j = ((List)localObject11).size();
      for (int i = 0; i < SiteSet.count(); i++) {
        //paramStructureData.removeChildData("CONTRACTAUTH", 1);
    	  String siteId = SiteSet.getMbo(i).getString("SITEID");
		  if (!authSiteID.equalsIgnoreCase(siteId)) {
			  paramStructureData.createChildrenData("CONTRACTAUTH", true);
		      paramStructureData.setCurrentData("AUTHORGID", paramStructureData.getParentData("ORGID"));
		      System.out.println("######################## AUTHORGID: "+paramStructureData.getCurrentData("AUTHORGID"));
		      if (integrationLogger.isDebugEnabled()) {
		        integrationLogger.debug("AUTHORGID: " + paramStructureData.getCurrentData("AUTHORGID"));
		      }
		      paramStructureData.setCurrentData("AUTHSITEID", siteId);
		      System.out.println("######################## AUTHSITEID: "+paramStructureData.getCurrentData("AUTHSITEID"));
		      if (integrationLogger.isDebugEnabled()) {
		        integrationLogger.debug("AUTHSITEID: " + paramStructureData.getCurrentData("AUTHSITEID"));
		      }
		      paramStructureData.setCurrentData("VENDOR", paramStructureData.getParentData("VENDOR"));
		      System.out.println("######################## AUTHVENDOR: "+paramStructureData.getCurrentData("VENDOR"));
		      if (integrationLogger.isDebugEnabled()) {
		        integrationLogger.debug("AUTHVENDOR: " + paramStructureData.getCurrentData("VENDOR"));
		      }
		      paramStructureData.setParentAsCurrent();
		  }
      }
      str2 = getOPUnitCol("PURCHVIEW", "OFOPUNIT");
      if ((str2 != null) && (!str2.equals(""))) {
        paramStructureData.setCurrentData(str2, authSiteID);
      }
      if (integrationLogger.isDebugEnabled()) {
        integrationLogger.debug("domainAttribute: " + str2 + " AUTHSITEID: " + authSiteID);
      }
    }
    */
    //*** Comment: ContractAuth
    String siteId="PSASG";
    paramStructureData.createChildrenData("CONTRACTAUTH", true);
    paramStructureData.setCurrentData("AUTHORGID", paramStructureData.getParentData("ORGID"));
    
    paramStructureData.setCurrentData("AUTHSITEID", siteId);
    System.out.println("######################## AUTHSITEID: "+paramStructureData.getCurrentData("AUTHSITEID"));
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("AUTHSITEID: " + paramStructureData.getCurrentData("AUTHSITEID"));
    }
    
    paramStructureData.setCurrentData("VENDOR", paramStructureData.getParentData("VENDOR"));
    System.out.println("######################## AUTHVENDOR: "+paramStructureData.getCurrentData("VENDOR"));
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("AUTHVENDOR: " + paramStructureData.getCurrentData("VENDOR"));
    }
    
    paramStructureData.setParentAsCurrent();
    
    System.out.println("######################## AUTHORGID: "+paramStructureData.getCurrentData("AUTHORGID"));
    
    //*** Comment: Contractline
    List localObject21 = paramStructureData.getChildrenData("CONTRACTLINE");
    if ((localObject21 != null) && (((List)localObject21).size() > 0))
    {
      for (int j1 = (localObject21.size() - 1); j1 >= 0; j1--)
      {
        paramStructureData.setAsCurrent(localObject21, j1);
        if (integrationLogger.isDebugEnabled()) {
          integrationLogger.debug("CONTRACTLINENUM: " + paramStructureData.getCurrentData("POLINENUM"));
        }
        if (integrationLogger.isDebugEnabled()) {
          integrationLogger.debug("ITEMNUM: " + paramStructureData.getCurrentData("ITEMNUM"));
        }
        if ((paramStructureData.getCurrentData("CONTRACTLINENUM") == null) || (paramStructureData.getCurrentData("CONTRACTLINENUM").equals("")))
        {
          paramStructureData.removeCurrentData();
        }
        else
        {
          if (!isValueControlNull("GENUSR", paramStructureData.getParentData("ORGID"), null)) {
            paramStructureData.removeFromCurrentData("ENTERBY");
          }
          String str21;
		if (doesPCExist(paramStructureData.getParentData("CONTRACTNUM"), paramStructureData.getCurrentData("CONTRACTLINENUM"), paramStructureData.getParentData("REVISIONNUM"), paramStructureData.getParentData("ORGID")))
          {
            paramStructureData.removeFromCurrentData("LINETYPE");
            paramStructureData.removeFromCurrentData("ITEMNUM");
          }
          else if (!paramStructureData.isCurrentDataNull("LINETYPE"))
          {
            str21 = localTranslate.toExternalDefaultValue("LINETYPE", paramStructureData.getCurrentData("LINETYPE"), null, paramStructureData.getParentData("ORGID"));
            
            paramStructureData.setCurrentData("LINETYPE", str21);
          }
          if (!paramStructureData.isCurrentDataNull("LINESTATUS"))
          {
            str21 = localTranslate.toExternalDefaultValue("CONTRACTSTATUS", paramStructureData.getCurrentData("LINESTATUS"), null, paramStructureData.getParentData("ORGID"));
            
            paramStructureData.setCurrentData("LINESTATUS", str21);
          }
          if (integrationLogger.isDebugEnabled()) {
            integrationLogger.debug("LINETYPE: " + paramStructureData.getCurrentData("LINETYPE"));
          }
          if (integrationLogger.isDebugEnabled()) {
            integrationLogger.debug("LINESTATUS: " + paramStructureData.getCurrentData("LINESTATUS"));
          }
          if (integrationLogger.isDebugEnabled()) {
            integrationLogger.debug("ITEMNUM: " + paramStructureData.getCurrentData("ITEMNUM"));
          }
          if (paramStructureData.isCurrentDataNull("ORDERUNIT"))
          {
            str21 = localControlsCache.getValueControl(getExtSystem(), "OAPCDEFORDERUNIT");
            if (str21 != null) {
              paramStructureData.setCurrentData("ORDERUNIT", str21);
            }
          }
          if ((paramStructureData.isCurrentDataNull("ORDERQTY")) && (paramStructureData.isCurrentDataNull("UNITCOST")) && (paramStructureData.isCurrentDataNull("LINECOST")))
          {
            paramStructureData.setCurrentDataNull("LINECOST");
            paramStructureData.setCurrentData("CHGQTYONUSE", 0);
            paramStructureData.setCurrentData("CHGPRICEONUSE", 1);
          }
          if (integrationLogger.isDebugEnabled()) {
            integrationLogger.debug("ORDERUNIT: " + paramStructureData.getCurrentData("ORDERUNIT"));
          }
        }
      }
      paramStructureData.setParentAsCurrent();
    }
    integrationLogger.debug("Leaving PCInExt.setDataIn");
    
    return paramStructureData;
  }
  
  public boolean doesPCExist(String paramString1, String paramString2, String paramString3, String paramString4)
    throws MXException, RemoteException
  {
    integrationLogger.debug("Entering PCInExt.doesPCExist");
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("CONTRACTNUM: " + paramString1);
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("CONTRACTLINENUM: " + paramString2);
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("REVISIONNUM: " + paramString3);
    }
    if (integrationLogger.isDebugEnabled()) {
      integrationLogger.debug("ORGID: " + paramString4);
    }
    boolean bool = false;
    if ((paramString1 != null) && (!paramString1.trim().equals("")) && (paramString2 != null) && (!paramString2.trim().equals("")))
    {
      SqlFormat localSqlFormat = new SqlFormat(getUserInfo(), "contractnum = :1 and revisionnum = :2 and orgid = :3 and contractlinenum = :4");
      
      localSqlFormat.setObject(1, "CONTRACTLINE", "CONTRACTNUM", paramString1);
      localSqlFormat.setObject(2, "CONTRACTLINE", "REVISIONNUM", paramString3);
      localSqlFormat.setObject(3, "CONTRACTLINE", "ORGID", paramString4);
      localSqlFormat.setObject(4, "CONTRACTLINE", "CONTRACTLINENUM", paramString2);
      
      MboSetRemote localMboSetRemote = MXServer.getMXServer().getMboSet("CONTRACTLINE", getUserInfo());
      localMboSetRemote.setWhere(localSqlFormat.format());
      
      MboRemote localMboRemote = localMboSetRemote.moveFirst();
      
      bool = localMboRemote != null;
      
      localMboSetRemote.close();
    }
    integrationLogger.debug("Leaving PCInExt.doesPCExist");
    return bool;
  }
  
  public void setLineStatus(StructureData paramStructureData)
    throws MXException, RemoteException
  {
    integrationLogger.debug("Entering PCInExt.setLineStatus");
    Translate localTranslate = MXServer.getMXServer().getMaximoDD().getTranslator();
    List localList = paramStructureData.getChildrenData("CONTRACTLINE");
    if (localList != null)
    {
      paramStructureData.setAsCurrent(localList, 0);
      if (!paramStructureData.isCurrentDataNull("LINESTATUS"))
      {
        String str = localTranslate.toExternalDefaultValue("CONTRACTSTATUS", paramStructureData.getCurrentData("LINESTATUS"), null, paramStructureData.getParentData("ORGID"));
        
        paramStructureData.setCurrentData("LINESTATUS", str);
      }
    }
    paramStructureData.setParentAsCurrent();
    integrationLogger.debug("Leaving PCInExt.setLineStatus");
  }
  
  public void setRevisionNum(StructureData paramStructureData)
    throws MXException, RemoteException
  {
    double l = 0L;
    
    SqlFormat localSqlFormat = new SqlFormat(getUserInfo(), "contractnum = :1 and orgid = :2 ");
    localSqlFormat.setObject(1, "PURCHVIEW", "CONTRACTNUM", paramStructureData.getCurrentData("CONTRACTNUM"));
    localSqlFormat.setObject(2, "PURCHVIEW", "ORGID", paramStructureData.getCurrentData("ORGID"));
    MboSetRemote localMboSetRemote = MXServer.getMXServer().getMboSet("PURCHVIEW", getUserInfo());
    if (localMboSetRemote != null)
    {
      localMboSetRemote.setWhere(localSqlFormat.format());
      l = localMboSetRemote.max("REVISIONNUM");
    }
    paramStructureData.setCurrentData("REVISIONNUM", l);
  }
}
