package com.psa.custom.sms;

/*
 * Author: BTE
 * 08 MAR 2006 - Initial version
 * 06 JUN 2006 - Add in PHONE constant
 */
public class SMSConstant {

	/*
	 * ORGID
	 */
	public final String ORGID = "ORGID";
	
	/*
	 * CALENDAR
	 */
	public final String CALENDAR = "CALENDAR";
	
	/*
	 * IC
	 */
	public final String IC = "IC";
	
	/*
	 * ATTENDANCEUPDATE
	 */
	public final String ATTENDANCEUPDATE = "ATTENDANCEUPDATE"; 

	/*
	 * CALNUM
	 */
	public final String CALNUM = "CALNUM";

	/*
	 * LABORCODE
	 */
	public final String LABORCODE = "LABORCODE";
	
	/*
	 * WORKDATE
	 */
	public final String WORKDATE = "WORKDATE";
	
	/*
	 * STARTTIME
	 */
	public final String STARTTIME = "STARTTIME";
	
	/*
	 * ENDTIME
	 */
	public final String ENDTIME = "ENDTIME";
	
	/*
	 * SHIFTNUM
	 */
	public final String SHIFTNUM = "SHIFTNUM";
	
	/*
	 * WORKPERIOD
	 */
	public final String WORKPERIOD = "WORKPERIOD";
	
	/*
	 * CRAFT
	 */
	public final String CRAFT = "CRAFT";
	
	/*
	 * CRAFTSKILL
	 */
	public final String CRAFTSKILL = "CRAFTSKILL";
	
	/*
	 * CRAFTRATE
	 */
	public final String CRAFTRATE = "CRAFTRATE";
	
	/*
	 * RANK
	 */
	public final String RANK = "RANK";	
	
	/*
	 * SKILLLEVEL
	 */
	public final String SKILLLEVEL = "SKILLLEVEL";
	
	/*
	 * DESCRIPTION
	 */
	public final String DESCRIPTION = "DESCRIPTION";
	
	/*
	 * VENDOR
	 */
	public final String VENDOR = "VENDOR";
	
	/*
	 * CONTRACTNUM
	 */
	public final String CONTRACTNUM = "CONTRACTNUM";
	
	/*
	 * REVISIONNUM
	 */
	public final String REVISIONNUM = "REVISIONNUM";
	
	/*
	 * EMPTY
	 */
	public final String EMPTY = "";		
	
	/*
	 * LABORCRAFTRATE
	 */
	public final String LABORCRAFTRATE = "LABORCRAFTRATE";
		
	/*
	 * SKILLACQUIREDATE
	 */
	public final String SKILLACQUIREDATE = "SKILLACQUIREDATE";
	
	/*
	 * iface
	 */
	public final String IFACE = "iface";
	
	/*
	 * calnoorgid
	 */
	public final String CALNOORGID = "calendar-noorgid";
	
	/*
	 * calnoIC
	 */
	public final String CALNOIC = "calendar-noIC";
	
	/*
	 * calnocalnum
	 */
	public final String CALNOCALNUM = "calendar-nocalnum";
	
	
	/*
	 * labnoorgid
	 */
	public final String LABNOORGID = "labor-noorgid";
	
	/*
	 * labnoIC
	 */
	public final String LABNOIC = "labor-noIC";
	
	/*
	 * labnolaborcode
	 */
	public final String LABNOLABORCODE = "labor-nolaborcode";
	
	/*
	 * LABOR
	 */
	public final String LABOR = "LABOR";
	
	/*
	 * CRAFTUPDATEERROR
	 */
	public final String CRAFT_UPDATE_ERROR = "craft-updateerror";
	
	/*
	 * CRAFTCREATEERROR
	 */
	public final String CRAFT_CREATE_ERROR = "craft-createerror";
	
	/*
	 * CRAFTSKILLUPDATEERROR
	 */
	public final String CRAFTSKILL_UPDATE_ERROR = "craftskill-updateerror";
	
	/*
	 * CRAFTSKILLUPDATEERROR
	 */
	public final String CRAFTSKILL_CREATE_ERROR = "craftskill-createerror";
		
	/*
	 * WORKPERIOD_UPDATE_ERROR
	 */
	public final String WORKPERIOD_UPDATE_ERROR = "workperiod-updateerror";
	
	/*
	 * WORKPERIOD_CREATE_ERROR
	 */
	public final String WORKPERIOD_CREATE_ERROR = "workperiod-createerror";
		
	/*
	 * CALENDAR_START_DATE
	 */
	public final String CALENDAR_START_DATE = "3/8/1950";
	
	/*
	 * CALENDAR_END_DATE
	 */
	public final String CALENDAR_END_DATE = "3/8/2099";
	
	/*
	 * STARTDATE
	 */
	public final String STARTDATE = "STARTDATE";
	
	/*
	 * ENDDATE
	 */
	public final String ENDDATE = "ENDDATE";
	
	/*
	 * CRAFTRATESKILL
	 */
	public final String CRAFTRATESKILL = "CRAFTRATESKILL";
	
	/*
	 * ACTION
	 */
	public final String ACTION = "action";
	
	/*
	 * SHIFT
	 */
	public final String SHIFT = "SHIFT";
	
	/*
	 * SHIFTPATTERNDAY
	 */
	public final String SHIFTPATTERNDAY = "SHIFTPATTERNDAY";
	
	/*
	 * PATTERNDAYSEQ
	 */
	public final String PATTERNDAYSEQ = "PATTERNDAYSEQ";	
	
	/*
	 * PATTERNDAY_CREATE_ERROR
	 */
	public final String PATTERNDAY_CREATE_ERROR = "shiftpatternDay-createerror";
	
	/*
	 * PATTERNDAY_UPDATE_ERROR
	 */
	public final String PATTERNDAY_UPDATE_ERROR = "shiftpatternDay-updateeerror";
	
	/*
	 * WORKHOURS
	 */
	public final String WORKHOURS = "WORKHOURS";
	
	/*
	 * SHIFTSECTION
	 */
	public final String SHIFTSECTION = "SHIFTSECTION";
	
	/*
	 * SHIFTNOORG
	 */
	public final String SHIFTNOORG = "shift-noorgid";
	
	/*
	 * SHIFTNOSHIFT
	 */
	public final String SHIFTNOSHIFT = "shift-noshiftnum";
	
	/*
	 * SHIFTNOSECTION
	 */
	public final String SHIFTNOSECTION = "shift-noshiftsection";

	/*
	 * ATTNOORGID
	 */
	public final String ATTNOORGID = "attendance-noorgid";
	
	/*
	 * ATTNNOIC
	 */
	public final String ATTNNOIC = "attendance-noIC";	
	
	/*
	 * ATTNOSTARTTIME
	 */
	public final String ATTNOSTARTTIME = "attendance-nostarttime";
	
	/*
	 * ATTNOENDTIME
	 */
	public final String ATTNOENDTIME = "attendance-noendtime";	
	
	/*
	 * PERSON
	 */
	public final String PERSON = "PERSON";
	
	/*
	 * SUPERVISOR
	 */
	public final String SUPERVISOR = "SUPERVISOR";	
	
	/*
	 * PERSONID
	 */
	public final String PERSONID = "PERSONID";
	
	/*
	 * EMAIL
	 */
	public final String EMAIL = "EMAIL";
	
	/*
	 * EMAILADDRESS
	 */
	public final String EMAILADDRESS = "EMAILADDRESS";
	
	/*
	 * PERSONNOSUPERVISOR
	 */
	public final String PERSONNOSUPERVISOR = "person-nosupervisor";
	
	/*
	 * PERSONNOEMAIL
	 */
	public final String PERSONNOEMAIL = "person-noemail";
	
	/*
	 * DISPLAYNAME
	 */
	public final String DISPLAYNAME = "DISPLAYNAME";	
	
	/*
	 * PERSONNOLASTNAME
	 */
	public final String PERSONNODISPLAYNAME = "person-nodisplayname";	
	
	/*
	 * TRANSDATE
	 */
	public final String TRANSDATE = "TRANSDATE";
	
	/*
	 * SLASH
	 */
	public final String SLASH = "/";		
	
	/*
	 * SPACE
	 */
	public final String SPACE = " ";	
	
	/*
	 * ATTNOTRANSDATE
	 */
	public final String ATTNOTRANSDATE = "attendance-notransdate";
	
	/*
	 * FINISHDATE
	 */
	public final String FINISHDATE = "FINISHDATE";
	
	/*
	 * FINISHTIME
	 */
	public final String FINISHTIME = "FINISHTIME";
	
	/*
	 * PERSONTNOPERSONID
	 */
	public final String PERSONTNOPERSONID = "person-nopersonid";
	
	/*
	 * PERSONNOIC
	 */
	public final String PERSONNOIC = "person-noIC";
	
	/*
	 * GLACCOUNT
	 */
	public final String GLACCOUNT = "GLACCOUNT";
	
	/*
	 * PHONE
	 */
	public final String PHONE = "PHONE";
	
	/*
	 * PSAST
	 */
	public final String PSAST = "PSAST";
	
	/*
	 * PHONENUM
	 */
	public final String PHONENUM = "PHONENUM";
	
	/*
	 * TECH
	 */
	public final String TECH = "TECH";
	
	/*
	 * CONTROLACCOUNT
	 */
	public final String CONTROLACCOUNT = "CONTROLACCOUNT";
}

