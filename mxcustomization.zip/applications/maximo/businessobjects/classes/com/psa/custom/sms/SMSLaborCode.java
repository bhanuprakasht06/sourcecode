package com.psa.custom.sms;

import java.rmi.RemoteException;

import psdi.app.labor.LaborRemote;
import psdi.app.labor.LaborSetRemote;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXException;

/*
 * Author: BTE
 * 05 APR 2006 - Initial version
 */
public class SMSLaborCode extends MicSetIn {

	/*
	 * Variables
	 */
	 private UserInfo userInfo;
	 private static SMSConstant SMS = new SMSConstant();
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - constructor  
	 */
	 public SMSLaborCode(UserInfo userInfo) throws MXException, RemoteException {		 
		 this.userInfo = userInfo;
	 }
	 

	 /*
	 * Author: BTE
	 * 05 APR 2006 - Get laborCode from database based on orgid and ic.  
	 */
	 public String getLaborCode(String orgid, String IC) 
	 	throws MXException, RemoteException {
	   
		 INTEGRATIONLOGGER.debug("Entering getLaborCode");
		 
		 // Check if vaiables is null
		 if(orgid == null || IC == null ) {
			 INTEGRATIONLOGGER.debug("Leaving getLaborCode");
			 return null;
		 }
		 
		 LaborSetRemote laborSet = (LaborSetRemote) MXServer.getMXServer().getMboSet(SMS.LABOR, userInfo);
				
		 CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		 combinewhereclauses.addWhere("ORGID= :1");
		 combinewhereclauses.addWhere("IC= :2");
		 String s = combinewhereclauses.getWhereClause();
	
		 if(s != null && s != SMS.EMPTY){
			 SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			 sqlformat.setObject(1, SMS.LABOR, SMS.ORGID, orgid);
			 sqlformat.setObject(2, SMS.LABOR, SMS.IC, IC);
	
			 laborSet.setWhere(sqlformat.format());
			 if(!laborSet.isEmpty()) {
		
				 LaborRemote labor = (LaborRemote) laborSet.getMbo(0);
		
				 if(!labor.isNull(SMS.LABORCODE)){
					 INTEGRATIONLOGGER.debug("Leaving getLaborCode");
					 return labor.getString(SMS.LABORCODE);
				 }
			 }
		 }			
			
		 INTEGRATIONLOGGER.debug("Leaving getLaborCode");
		 return null;		   
	 }
	 
}
