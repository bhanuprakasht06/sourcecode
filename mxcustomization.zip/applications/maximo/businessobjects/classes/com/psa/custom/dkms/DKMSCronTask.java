package com.psa.custom.dkms;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import com.psa.custom.common.EMSSite;
import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxImportFile;
import com.psa.custom.common.MxLocMeter;
import com.psa.custom.common.MxXml;
import com.psa.custom.ois.EMSAssetIDConversion;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
//import psdi.custom.common.MxDebug;
//import psdi.custom.common.MxSCP;
import psdi.iface.jms.MEAQueueProcessor;
import psdi.iface.load.LoadCronTask;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class DKMSCronTask extends LoadCronTask {
	
    // EMAIL Subject
    private static final String SUBJECT = "[EMS-DKMS] Error: Error occured in flat file import. Cron task stopped.";
    private static final String PARTIAL = "[EMS-DKMS] Warning: Error occured in flat file import.";
        
	// Variables    
    //private static final String SPACE = " ";
    private static final String NEWLINE = "\n\r";
    private static final String isdelta = "Y";
    private static final String inspector = "MXINTADM";
    
    private static CrontaskParamInfo params[];
    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");    
    
    private boolean isOkToRun;
    private MEAQueueProcessor queueProcessor;
    private String qualifiedInstanceName;
    private String extSys;
    private String ifaceName;
    private File loadDir;
    private String directory;
    private String splitTag;
    private RecoveryService recoveryService;
        
    private String administrator;
    private String importFileName;            
    //private String importFilePath;            
    //private String remoteServer;
    //private String scpConfigFile;
    
    private String metername;
    
    //private MxDebug debug;
    private MxEmail email;
    private MxXml mxXml;
    private MxImportFile mxFile;
    
    private StringBuffer errMessage;
    private boolean errEmail;
    private String EMSAssetIDCfgFile; //20060906 HCHA - Config Filename for Location
    
    EMSAssetIDConversion assetIDConv;
    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: DKMS Cron task constructor initialize default value  
     */	
    public DKMSCronTask() {    	
    	
    	isOkToRun = true;
	    recoveryService = null;    	
	    queueProcessor = null;
	    qualifiedInstanceName = null;
	    queueProcessor = new MEAQueueProcessor();
	 
        extSys = null;
        ifaceName = null;   
        loadDir = null;
        directory = null;
        splitTag = null;        
        
        // BTE: Extra parameter to configure cron task.  
        //scpConfigFile = null;
        administrator = null;
        importFileName = null;            
        //importFilePath = null;            
        //remoteServer = null;
        
        metername = null;      
        
        // Error handle
        errMessage = null;
        errEmail = false;
        
        //20060906 HCHA - Config Filename for Location Conversion
        EMSAssetIDCfgFile = null;
        assetIDConv = null;
    }

    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Send data to JMS queue 
     */
	public boolean splitPerformed(byte[] abyte0, String ifaceName, int i) throws Exception {
	    
		//debug.msg("DKMSCronTask.splitPerformed");
		integrationLogger.debug("DKMSCronTask: Entering splitPerformed");
		
        try {				
			sendMessage(abyte0, ifaceName, i);
			
		} catch (Exception e) {
	        MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
	        if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
	            MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");
	        
	        throw new Exception(e.getMessage());
		}

		integrationLogger.debug("DKMSCronTask: Leaving splitPerformed");
        return true;
    }
	
	
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Send a collection of XML data to JMS queue
     */
	public void multiSplitPerformed(Collection col, int i) throws Exception {
		
		//debug.msg("DKMSCronTask.multiSplitPerformed");
		integrationLogger.debug("DKMSCronTask: Entering multiSplitPerformed");
		
        try {			
			
			Iterator iter = col.iterator(); 
			while (iter.hasNext()) {
				String xmlData = (String)iter.next();
				
				splitPerformed(xmlData.getBytes(), ifaceName, i);				
			}
		
			// Clear collection
			col.clear();
			
		} catch (Exception e) {
	        MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
	        if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
	            MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");
	        
	        throw new Exception(e.getMessage());
		}
		
		integrationLogger.debug("DKMSCronTask: Leaving multiSplitPerformed");
		
	}
	
	
	/* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Initialize cron task  
     */
    public void init() {
        //debug = new MxDebug();
        //debug.setDebug(false);    	    	
        
        //debug.msg("DKMSCronTask.init");
    	integrationLogger.debug("DKMSCronTask: Init()");
    	
        email = new MxEmail();        
        mxXml = new MxXml();
                
        mxFile = new MxImportFile();
    }

    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Start cron task   
     */
    public void start() {

    	//debug.msg("DKMSCronTask.start");

        try {
            refreshSettings();
            
            MicUtil.INTEGRATIONLOGGER.info("Load task::" + qualifiedInstanceName + " started for system::" + extSys + " and interface=" + ifaceName);
            setSleepTime(0L);
            
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }	  
	
    
	/* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Get the parameter value setting from maximo User 
     * Interface in configuration    
     */
    private void refreshSettings()
    {
    	
    	//debug.msg("DKMSCronTask.refreshSettings");
    	integrationLogger.debug("DKMSCronTask: Entering refreshSettings");
    	
        try {
            splitTag = getParamAsString("SPLITTAG");        	
            extSys = getParamAsString("EXTSYSNAME");
            ifaceName = getParamAsString("INTERFACENAME");
            directory = getParamAsString("DIRECTORY");
            loadDir = new File(directory);            
    		recoveryService = new RecoveryService(loadDir);
    		
            /* BTE: Require for getting flat file in remote server and email
             * alert administrator. Require for configuration throught Maximo 
             * User Interface.   
             */ 

            administrator = getParamAsString("ALERTEMAIL");
            importFileName = getParamAsString("IMPORTFILENAME");  
            metername = getParamAsString("METERNAME");  
            //importFilePath = getParamAsString("IMPORTFILEPATH");            
            //remoteServer = getParamAsString("REMOTESERVER");
            //scpConfigFile = getParamAsString("SCPCONFIGFILE");
            
            //20060906 HCHA - Config Filename for Location Conversion
            EMSAssetIDCfgFile = getParamAsString("EMSASSETIDCFGFILE");
   
                        
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
        
        integrationLogger.debug("DKMSCronTask: Leaving refreshSettings");
    }
	
    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Stop cron task  
     */
    public void stop() {
    	
		//debug.msg("DKMSCronTask.stop");
	
		MicUtil.INTEGRATIONLOGGER.info("Flat file polling task::" + 
    		qualifiedInstanceName + 
    		" stopped for system::" + 
    		extSys + 
    		" and interface=" + 
    		ifaceName);
    }
    
    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Set cron task instance  
     */
    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {
    	
        try {
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") + 
            	"." + crontaskinstanceremote.getString("instancename");
        }
        catch(Exception exception) {
            integrationLogger.error(exception.getMessage(), exception);
        }
    }

    
    //private static final String dotdot = ":"; 
    //private static final String asterisk = "*";
    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Cron task function - Retrieve flat file from remote server,
     * process flat file, convert to xml format and import to maximo.  
     */
	public void cronAction() {

    	//debug.msg("DKMSCronTask.cronAction");
    	integrationLogger.info("DKMSCronTask: Entering cronAction");
    	
        if(!isOkToRun) return;
        
    	// Refresh setting before perform cron action
        refreshSettings();
        
        // Set parameter after refreshSetting
        email.setAdmin(administrator);       
        mxFile.setFileType(importFileName);
    	errMessage = new StringBuffer();
    	
        try {
        	// BTE: Get the Administrator email
        	if (administrator == null) throw new Exception("Required parameter not set.");
	               	
        	// BTE: Get the import flat file from remote server        	
        	if ((importFileName != null) &&  (directory != null)) {
        		
        		// Check file is in local drive?
        		if (!checkFileExist()) {
        			
        			throw new Exception("["+getName()+"]Unable to find input file.");
	        		// Get file from remote Server
        			//MxSCP scp = new MxSCP();
        			
        			//String scpParam = scpConfigFile + SPACE +        				       				
    				//remoteServer + dotdot + importFilePath + asterisk + mxFile.getFileName() + asterisk + SPACE + directory;
        			
	        		//if (scp.getFlatFile(scpParam) != 0) {		        				            		
	            	//	throw new Exception("Cannot get remote file.");
	        		//}		  	        		
        		}
        		
        	} else {	        		
        		throw new Exception("Required parameter not set.");        	
        	}
        	
        	
            //20060906 HCHA - Config Filename for Location Conversion		
            assetIDConv = new EMSAssetIDConversion(EMSAssetIDCfgFile);
        	
        	// Process the import flat file
        	processFolderData();

        }
        catch(Exception e) {
            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);			
            email.send(SUBJECT, e.getMessage());
                        
            stop();
        }
        
        integrationLogger.info("DKMSCronTask: Leaving cronAction");
	}
	
	
	/* Author: BTE
	 * Date: 21 FEB 2006
	 * Comment: Check file exist in local directory
	 */
	public boolean checkFileExist () {
		
		//debug.msg("DKMSCronTask.checkFileExist");
		integrationLogger.debug("DKMSCronTask: checkFileExist");
		
		File afile[] = loadDir.listFiles();
        
	    	if(afile != null) {
		        int i = afile.length;
		        
		        for(int j = 0; j < i; j++) {
		        	
		        	if(mxFile.findFileType(afile[j])) {
	        			return true;
	        		}
	        	}
	    	}
		
		return false;		
	}
	
	
	/* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Get the parameter from Cron Task.  
     */
    public CrontaskParamInfo[] getParameters() throws MXException, RemoteException {
	    return params;
	}

    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Process the import flat file   
     */
    public void processFolderData() throws Exception {
   
    	//debug.msg("DKMSCronTask.processFolderData");
		integrationLogger.debug("DKMSCronTask: Entering processFolderData");

		try {    		
			File afile[] = loadDir.listFiles();
    
			if(afile != null) {
				    		
				int i = afile.length;
        
				for(int j = 0; j < i; j++) {
            	
					if(mxFile.findFileType(afile[j])) {
            		
                		//debug.msg("Start reading flat file.");
						integrationLogger.debug("DKMSCronTask: Processing file '"+afile[j].getName()+"'");
                	//	recoveryService.startRecovery();	                    
                		
                		try {
                			// Parse DKMS flat file 
	                    	String file = afile[j].toString();
	                    	Collection col = parseFlatFile(file);
	                        	      
	                        // Create a XML document based on the data from the flat file.
	                    	Collection xmlCol = generateXMLDocument(col);                                     
	                        
	                        // Important BufferedInputStream has a size of 2000byte only.	                        	                        
	                    	multiSplitPerformed(xmlCol, j);	 
	                    	
	                    	if (errEmail) {
	                    		String msg = "[EMS-DKMS] Warning: File Parse error for the following: " + 
	                    			NEWLINE +
                        			errMessage;
                				
                				MicUtil.INTEGRATIONLOGGER.error(msg);
	                            email.send(PARTIAL, msg);	                            
	                    	}	                    	
                		} finally {	                    	
                			try {
                				recoveryService.endRecovery();

                			} catch(Exception e){
                				MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
	                            
                			}
                		}
            		}
	            }
	        }
		}
        catch(Exception e)
        {        	
            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);            
            email.send(SUBJECT, "[EMS-DKMS] Error: Error processing DKMS data.");  
            
            stop();
        }
        
        integrationLogger.debug("DKMSCronTask: Leaving processFolderData");
	}
	

    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Parse DKMS flat file.    
     */
    private Collection parseFlatFile(String file) throws Exception {
    	
    	//debug.msg("DKMSCronTask.parseFlatFile");
    	integrationLogger.debug("DKMSCronTask: Entering parseFlatFile");
    	
    	
    	// BTE: Parse the DKMS flat flat file first
        // Reading the import flat file 	                        
        BufferedReader flatfileReader;
        Collection col = new Vector();   
        		
		flatfileReader = new BufferedReader(new FileReader(file));
                           
        String curLine = null;  

        // Process record.
        StringTokenizer stringTokenizer = null;
        
        while((curLine = flatfileReader.readLine()) != null)
        {	            	     
            stringTokenizer = new StringTokenizer(curLine, splitTag);
	        Vector vec = new Vector();
            
	        if (stringTokenizer.countTokens() == 3) {	        
	            while(stringTokenizer.hasMoreElements())
	            {                                	
	                String curValue = String.valueOf(stringTokenizer.nextElement());
	                	                
	                // Add to element to vector.
	                vec.add(curValue.trim());       
	                //debug.msg(curValue.trim());
	            }	            
	
	            // Add to a collection 
	            col.add(vec);
	        } else {
	        	errEmail = true;
	        	errMessage.append(curLine + NEWLINE);
	        }	        	
        }	            
		
        integrationLogger.debug("DKMSCronTask: Leaving parseFlatFile");
        return col;
    }    


	
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Create a XML document   
     */    
    private Collection generateXMLDocument(Collection col) throws Exception
    {
		//debug.msg("DKMSCronTask.generateXMLDocument");
		integrationLogger.debug("DKMSCronTask: Starting generateXMLDocument");
	
		Collection xmlCol = new Vector();    	
 
    	MxLocMeter locMeter = new MxLocMeter(getRunasUserInfo());
    	DateFormat timeStampFormat = null;
    	
    	if (importFileName.equalsIgnoreCase(mxFile.getYYYYPM())) {	    			
    		timeStampFormat = new SimpleDateFormat(mxFile.getYYYYPMFormat());
    	}if (importFileName.equalsIgnoreCase(mxFile.getYYYYPM())) {	    			
    		timeStampFormat = new SimpleDateFormat(mxFile.getYYYYMMFormat());
    	} else if (importFileName.equalsIgnoreCase(mxFile.getYYYYMMDD())) {
    		timeStampFormat = new SimpleDateFormat(mxFile.getYYYYMMDDFormat());
    	}	    	
				
    	String locMeterXml = null;
    	
		Iterator iterParsedData = col.iterator();         
		while (iterParsedData.hasNext()) {        	            
            	
    		//debug.msg("generateXMLDocument.Loop");
	            	
			// Get new record to convert to XML 
	    	Vector vec = (Vector)iterParsedData.next();		            	
	    	locMeterXml = null;
	    	
	    	integrationLogger.debug("DKMSCronTask.generateXMLDocument: Processing Location: "+vec.elementAt(0));
	    	
	    	// ImportFile Name is YYYMM or YYYYMMDD or YYYYPM
	    	if (importFileName.equalsIgnoreCase(mxFile.getYYYYMM()) || 
	    			importFileName.equalsIgnoreCase(mxFile.getYYYYMMDD()) || 
	    			importFileName.equalsIgnoreCase(mxFile.getYYYYPM())) {
	    		
	    		Date readingDate = locMeter.getLastReadingDate((String) vec.elementAt(0), metername);
	    		
	    		if (readingDate != null) {
	    			
	    			//If file name is previous month format, change reading date to one month back
	    			if(importFileName.equalsIgnoreCase(mxFile.getYYYYPM())){
	    				Calendar cal = Calendar.getInstance(); 
	    				cal.setTime(readingDate);
	    				cal.add(Calendar.MONTH,-1);
	    				readingDate = cal.getTime();
	    			}
	    				 
	    			String latestReadingDate = timeStampFormat.format(readingDate);
	    			
	    			if (!latestReadingDate.equalsIgnoreCase(mxFile.getFileName())) {	
		    			//debug.msg("generateXMLDocument.Loop.NotExist");
		    			integrationLogger.debug("DKMSCronTask.generateXMLDocument: New reading");
		    			
			        	locMeterXml = genLocMeterXml(TAG_MXLOCMETER, TAG_LOCMETER, vec);
	        		}
	    		} else { // No meter reading exists in location
	    			//debug.msg("generateXMLDocument.Loop.FirstReading");
	    			integrationLogger.debug("DKMSCronTask.generateXMLDocument: No existing meter reading");
	    			
		        	locMeterXml = genLocMeterXml(TAG_MXLOCMETER, TAG_LOCMETER, vec);
	    		}
	    	} else if (timeStampFormat == null) { // ImportFile Name is not YYYYMM or YYYYMMDD or YYYYPM
	    		//debug.msg("generateXMLDocument.Loop.Exact");
	    		integrationLogger.debug("DKMSCronTask.generateXMLDocument: Exact Filename");
	    		
	        	locMeterXml = genLocMeterXml(TAG_MXLOCMETER, TAG_LOCMETER, vec);
	        }
	    	
	    	if (locMeterXml != null) { 
	    		xmlCol.add(locMeterXml);
	    	}
        }
        
        // Clear collection
        col.clear();
        integrationLogger.debug("DKMSCronTask: Leaving generateXMLDocument");
        return xmlCol;
    } 

	// XML tag's    
    private final String MSG_START_INTERFACE =
    	" xmlns=\"http://www.ibm.com/maximo\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" creationDateTime=\"2009-01-12T06:23:20-05:00\" transLanguage=\"EN\" baseLanguage=\"EN\" maximoVersion=\"7 1 20100522-0325 V7117-47\" event=\"1\">";    
    		
		
	private final String TAG_MXLOCMETER = "MXLOCMETERSet";
	private final String TAG_LOCMETER = "LOCATIONMETER";	
	
	private final String TAG_ORGID = "ORGID";
	private final String TAG_SITEID = "SITEID";
	private final String TAG_LOCATION = "LOCATION";
	private final String TAG_METERNAME = "METERNAME";
	private final String TAG_ISDELTA = "ISDELTA";
	private final String TAG_INSPECTOR = "INSPECTOR";
	private final String TAG_NEWREADINGDATE = "NEWREADINGDATE";
	private final String TAG_NEWREADING = "NEWREADING";
	
	// Format definitions
	private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+08:00'";    
    
    /* Author: BTE
     * Date: 23 FEB 2006
     * Comment: Generate Locations XML   
     */    
    private String genLocMeterXml(String intObject, String obj, Vector vec) throws Exception {
    	
    	//debug.msg("DKMSCronTask.genLocXml");
    	integrationLogger.debug("DKMSCronTask: Entering genLocXml");

        DateFormat timeStampFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
        
		// Xml value	
        String location = assetIDConv.getRightAssetId((String) vec.elementAt(0));;
        String newReading = (String) vec.elementAt(2);		
		String newReadingDate = timeStampFormat.format(new Date());

		// Site id
        String siteId =  null;
        EMSSite site = null;
		site = new EMSSite((String)location, getRunasUserInfo());
        siteId = site.getSiteID();
        String orgId = site.getOrgID();	
        
		if (siteId == null) {
        	errEmail = true;
        	errMessage.append(location + 
        			" does not exists." +
        			NEWLINE);
        	
        	return null;
		}	
	

		// Create XML 
		String xml =  
    		"<SyncMXLOCMETER "+MSG_START_INTERFACE+
    		"<"+TAG_MXLOCMETER+">" +
 			"<"+TAG_LOCMETER+" action=\"AddChange\">" + // object 
 			mxXml.genTagSting(TAG_ORGID, orgId) +
 			mxXml.genTagSting(TAG_SITEID, siteId) +
 			mxXml.genTagSting(TAG_LOCATION, location) +
 			mxXml.genTagSting(TAG_METERNAME, metername) +
 			mxXml.genTagSting(TAG_ISDELTA, isdelta) +
 			mxXml.genTagSting(TAG_INSPECTOR, inspector) +
 			mxXml.genTagSting(TAG_NEWREADINGDATE, newReadingDate) +
 			mxXml.genTagSting(TAG_NEWREADING, newReading) +	
 			"</"+TAG_LOCMETER+">" + // object			
 			"</"+TAG_MXLOCMETER+">" + //Integration object
 			"</SyncMXLOCMETER>"; // Interface name
        integrationLogger.debug("DKMSCronTask: XML GENERATED"+xml);
		integrationLogger.debug("DKMSCronTask: Leaving genLocXml");
    	return xml;
    }   
        
   
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Sending message to JMS queue.   
     */
    private void sendMessage(byte abyte0[], String ifaceName, int i) throws Exception {

    	//debug.msg("DKMSCronTask.sendMessage");
    	integrationLogger.debug("DKMSCronTask: Entering sendMessage");
    	
    	try {
    		/*
            HashMap hashmap = new HashMap();
            hashmap.put("SENDER", extSys);
            hashmap.put("INTERFACE", ifaceName);
            */	            
            if(queueProcessor == null)
                queueProcessor = new MEAQueueProcessor();
            
            queueProcessor.writeDataToQueueIn(abyte0,extSys,ifaceName);	            
	    }
	    catch(Exception exception) {
	        
	        throw exception;
	    }
	    
	    integrationLogger.debug("DKMSCronTask: Leaving sendMessage");
	}

    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Define Maximo parameter setting in Cron Task 
     */     
    static 
    {
    	// BTE: Set the number of the parameter.  
        params = null;
        params = new CrontaskParamInfo[9];
        
        // BTE: All the parameter configurable from Cron Task user interface 
        params[0] = new CrontaskParamInfo();
        params[0].setName("SPLITTAG");
        params[0].setDefault("~");
        params[1] = new CrontaskParamInfo();
        params[1].setName("EXTSYSNAME");
        params[1].setDefault("DKMS");       
        params[2] = new CrontaskParamInfo();
        params[2].setName("INTERFACENAME");
        params[2].setDefault("MXLOCMETERInterface");
        params[3] = new CrontaskParamInfo();
        params[3].setName("DIRECTORY");
        params[4] = new CrontaskParamInfo();
        params[4].setName("ALERTEMAIL");
        params[5] = new CrontaskParamInfo();
        params[5].setName("IMPORTFILENAME");
        params[6] = new CrontaskParamInfo();        
        params[6].setName("TARGETENABLED");
        params[6].setDefault("0");
        params[7] = new CrontaskParamInfo();        
        params[7].setName("METERNAME");
        params[7].setDefault("DIESEL");    

        //20060906 HCHA - Config Filename for Location
        params[8] = new CrontaskParamInfo();
        params[8].setName("EMSASSETIDCFGFILE");
        //params[8].setDescription("Config Filename for Location Conversion.");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
		params[8].setDescription("CommonCron","ConfigFilename");
		//-- COMM-IT changed to make it compatible with Maximo 7 API
        //params[4] = new CrontaskParamInfo();
        //params[4].setName("SCPCONFIGFILE");
        //params[7] = new CrontaskParamInfo();
        //params[7].setName("IMPORTFILEPATH");
        //params[8] = new CrontaskParamInfo();
        //params[8].setName("REMOTESERVER");
    }

}

