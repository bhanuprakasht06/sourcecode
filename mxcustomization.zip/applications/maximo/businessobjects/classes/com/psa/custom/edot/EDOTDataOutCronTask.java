/*
 * Modification history 
 * 
 * 27-10-11 YCH Creation
 * 
 * This class is cron task to retrieve ED-OT records as flat file for Resource System
 * 
 * 03-09-20 :  BCT Modified (Oracle to SQL conversion)
 * 
 */

package com.psa.custom.edot;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;

import com.psa.custom.common.MxDatabase;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.ois.MxLog;

import psdi.iface.mic.MicUtil;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class EDOTDataOutCronTask extends SimpleCronTask 
{
	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
	private static final String SPACE = " ";
	private static final String OTTRANS_FILENAME = "edot.txt";
	//Parameters
	protected String zipExec; //Executable/Command for zip function
	protected boolean enableLog; //Enable Log
	protected String logFilePath; //Filename and Directory where log file will be placed
	protected String processDirectory; // Directory where processing are done
	
	protected String otOutputFilePath; //Filename and Full Path for OT Transaction Output File
	protected String otArchiveFilePath; //Filename and Full Path for OT Transaction Archive File
	
	protected boolean purgeData; //Purge data from table.?
	
	protected int extractday; //No. of days before current date to extract data
	
	//For Cron Task
	protected String qualifiedInstanceName;
	
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	protected MxLog mxLog;
	
	protected boolean initialized;
	
	public EDOTDataOutCronTask() {
		super();
		
		initialized = false;
		qualifiedInstanceName = null;
		
		//Init Parameters
		zipExec = null;
		logFilePath = null;
		enableLog = false;
		purgeData = false;
		processDirectory = null;
		otOutputFilePath = null;
		
		extractday = 1;
		mxLog = new MxLog();
	}
	
	/**
	 * @author YCH
	 * @function refreshSettings
	 * @date Oct 27, 2011
	 * @comment Refresh Cron Task setting
	 */
	private void refreshSettings()
	{
		try
		{
			//Parameter for zip
			zipExec = getParamAsString("ZIPEXEC");
			
			//Output Path and File Name
			DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
			
			//No. of days before current date to extract data
			extractday = getParamAsInt("EXTRACTDAY");
			// Set to able how many days before to extract
			Date curDate = new Date();
			Date fileDate = new Date(curDate.getTime() - ((extractday - 1) * 24L * 60L * 60L * 1000L));
			
			String fileDateStr = fileDateFormat.format(fileDate);
			
			otOutputFilePath = getParamAsString("OTOUTPUTFILEPATH").replaceAll("yyyymmdd", fileDateStr);
			otArchiveFilePath = getParamAsString("OTARCHIVEFILEPATH").replaceAll("yyyymmdd", fileDateStr);
			
			//Log
			logFilePath = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd", fileDateStr);
			enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
			
			mxLog.setEnabled(enableLog);
			mxLog.setLogFilePath(logFilePath);
			mxLog.setLogTag(getName());
			mxLog.createLogFile();
			
			//Directory where processing are done
			processDirectory = getParamAsString("PROCESSDIRECTORY");
			
		}
		catch (Exception exception)
		{
			if (integrationLogger.isErrorEnabled())
				integrationLogger.error(exception.getMessage(), exception);
		}
	}
	
	/**
	 * @author YCH
	 * @function init
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function] Initialize cron task
	 */
	public void init() throws MXException
	{
		super.init();		
		initialized = true;
	}

	/**
	 * @author YCH
	 * @function start
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function] Start cron task
	 */
	public void start()
	{
		try
		{
			refreshSettings();
			
			mxLog.writeLog(getName() + ".start() ");
			
			integrationLogger.info("[" + getName() + "] Start");
			setSleepTime(0L);
		}
		catch (Exception exception)
		{
			if (integrationLogger.isErrorEnabled())
				integrationLogger.error(exception.getMessage(), exception);
		}
	}
	
	/**
	 * @author YCH
	 * @function stop
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function]Stop cron task
	 */
	public void stop()
	{
		try
		{
			mxLog.writeLog(getName() + ".stop()");
			mxLog.closeLogFile();
		}
		catch (Exception exception)
		{
			if (integrationLogger.isErrorEnabled()) 
				integrationLogger.error(exception.getMessage(), exception);
		}
		
		integrationLogger.info("[" + getName() + "] Stop");
	}
	
	/**
	 * @author YCH
	 * @function setCrontaskInstance
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function] Set cron task instance
	 */
	public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
	{
		try
		{
			super.setCrontaskInstance(crontaskinstanceremote);
			qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") + "." + crontaskinstanceremote.getString("instancename");
		}
		catch (Exception exception)
		{
			integrationLogger.error(exception.getMessage(), exception);
		}
	}
	
	/**
	 * @author YCH
	 * @function isReqParamSet
	 * @date Oct 27, 2011
	 * @comment returns true if all required parameter is set
	 */
	private boolean isReqParamSet()
	{
		if (processDirectory == null)
			return false;
		if (otOutputFilePath == null)
			return false;
		if (otArchiveFilePath == null)
			return false;
		return true;
	}
	
	
	/**
	 * @author YCH
	 * @function cronAction
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function]
	 */
	public void cronAction() 
	{
		try
		{
			mxLog.writeLog(getName() + ".cronAction():[info]Start CronTask Action");
			
			if (!initialized)
			{
				mxLog.writeLog(getName() + " .cronAction():[Error]CronTask not initialized!");
				throw new Exception(getName() + ". cronAction():[Error]CronTask not initialized!");
			}
			
			// Refresh setting before perform cron action
			refreshSettings();
			
			if (!isReqParamSet())
			{
				mxLog.writeLog(getName() + ".cronAction(): Required parameters not set.");
				throw new Exception("Required parameters not set.");
			}
			
			//Generate the output flat files
			processData();
			
			//Copy and Zip Flat Files to Output and Archive Directory
			depositFile();
			
			mxLog.writeLog(getName() + ".cronAction():[Info]End CronTask Action");
		}
		catch (Exception e)
		{
			mxLog.writeLog("[ERROR] " + e.getMessage());
			
			integrationLogger.error("[" + getName() + "] " + e.getMessage(), e);
			
			stop();
		}
	}
	
	/**
	 * @author YCH
	 * @function depositFile
	 * @date Oct 27, 2011
	 * @comment Copy and Zip Flat Files to Output and Archive Directory modification, 
	 * Do not throw exception when the transaction has been processed
	 * @throws Exception
	 */
	private void depositFile() throws Exception
	{
		mxLog.writeLog(getName() + ".depositFile():[Info]Start depositing output file");
		
/*		File chkOTArchFile = new File(otArchiveFilePath + ZIP_EXT);
		if (chkOTArchFile.exists())
		{
			//Transaction for the day has been processed before.
			//Do not throw exception when the transaction has been processed
			mxLog.writeLog(getName() + ".depositFile():[Warning]Archive files already exist; transactions have been processed before");
			return;
		}
*/		
		//MxFileCopy.fileCopy(processDirectory + OTTRANS_FILENAME, otArchiveFilePath);
		MxFileCopy.fileCopy(processDirectory + OTTRANS_FILENAME, otOutputFilePath);
		
		//Zip Flat Files
/*		String cmd = zipExec + SPACE + otOutputFilePath;
		mxLog.writeLog(getName() + ".depositFile():[Info]Zip using cmd: " + cmd);
		int retcode = MxZip.zipFile(cmd);
		if (retcode != 0)
		{
			mxLog.writeLog(getName() + ".depositFile():[Error] Unable to zip file - " + otOutputFilePath);
			throw new Exception(getName() + ".depositFile(): Unable to zip file - " + otOutputFilePath);
		}
		
		cmd = zipExec + SPACE + otArchiveFilePath;
		mxLog.writeLog(getName() + ".depositFile():[Info]Zip using cmd: " + cmd);
		retcode = MxZip.zipFile(cmd);
		if (retcode != 0)
		{
			mxLog.writeLog(getName() + ".depositFile():[Error] Unable to zip file - " + otArchiveFilePath);
			throw new Exception(getName() + ".depositFile(): Unable to zip file - " + otArchiveFilePath);
		}
*/		
		mxLog.writeLog(getName() + ".depositFile():[Info]Finish depositing output file");
	}
	
	/**
	 * @author YCH
	 * @function writeOTTrans
	 * @date Oct 27, 2011
	 * @comment Generate the OT Transaction flat file Modification
	 * 
	 * @param conn
	 * @throws SQLException
	 * @throws IOException
	 */
	private void writeOTTrans(Connection conn) throws SQLException, IOException
	{
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		EDOTFile edotfile = null;
		try
		{
			mxLog.writeLog(getName() + ".writeJobTrans():[Info]Start processing OT transactions...");

/*
 * 03-09-2020
 * <START> - Code below has been commented as part of the DB migration from Oracle to SQL 
 * 
 
			String otSqlStmt = "SELECT "
				+ "(SELECT IC FROM PERSON WHERE PERSONID = LABORCODE) AS ICNO, " //IC No. 
				+ "REFWO, "  //Reference Work Order
				+ "to_char(STARTDATETIME, 'ddmmyyyyhh24mi') AS STARTTIME, " //OT Start Time 
				+ "to_char(FINISHDATETIME, 'ddmmyyyyhh24mi') AS FINISHTIME, " //OT Finish Time
				+ "LABORCODE, " //User ID
				+ "PSA_VERIFIEDBY AS VERIFIED_ID, " //Verified By User ID
				+ "(SELECT DISPLAYNAME FROM PERSON WHERE PERSONID = PSA_VERIFIEDBY) AS VERIFIED_NAME, " //Verified By User Name
				+ "to_char(PSA_VERIFIEDDATE, 'ddmmyyyyhh24mi') AS VERIFIED_DATE, " //Verified Date
				+ "PSA_APPROVEDBY AS APPROVED_ID, " //Approved By User ID
				+ "(SELECT DISPLAYNAME FROM PERSON WHERE PERSONID = PSA_APPROVEDBY) AS APPROVED_NAME, " //Approved By User Name 
				+ "to_char(PAYMENTTRANSDATE, 'ddmmyyyyhh24mi') AS APPROVED_DATE, " //Approved Date
				+ "LABTRANSID, " //Maximo OT ID
				+ "PSA_REMARKS " //OT Remarks
				+ "FROM "
				+ "LABTRANS WHERE TRUNC(PAYMENTTRANSDATE) = TRUNC(SYSDATE) - "
				+ extractday
				+ " AND PSA_OT_FLAG = 1 "
				+ "AND PAYMENTTRANSDATE < TRUNC(SYSDATE) "  
				+ "AND GENAPPRSERVRECEIPT = 1 "
				+ "AND PSA_VERIFIED = 1";
			
				<END>
*/
				

/*
 * 
 * 03-09-2020 - Updated the Query to be compatible to SQL DB
 * <START>
 * 
 */
			
			String otSqlStmt = "SELECT "
					+ " (SELECT IC FROM PERSON WHERE PERSONID = LABORCODE) AS ICNO, " //IC No. 
					+ " REFWO, "  //Reference Work Order
					+ " FORMAT (startdatetime, 'ddMMyyyyHHmm') as starttime, " //OT Start Time 
					+ " FORMAT (finishdatetime, 'ddMMyyyyHHmm') as finishtime, " //OT Finish Time
					+ " LABORCODE, " //User ID
					+ " PSA_VERIFIEDBY AS VERIFIED_ID, " //Verified By User ID
					+ " (SELECT DISPLAYNAME FROM PERSON WHERE PERSONID = PSA_VERIFIEDBY) AS VERIFIED_NAME, " //Verified By User Name
					+ " FORMAT (psa_verifieddate, 'ddMMyyyyHHmm') as verified_date, " //Verified Date
					+ " PSA_APPROVEDBY AS APPROVED_ID, " //Approved By User ID
					+ " (SELECT DISPLAYNAME FROM PERSON WHERE PERSONID = PSA_APPROVEDBY) AS APPROVED_NAME, " //Approved By User Name 
					+ " FORMAT (paymenttransdate, 'ddMMyyyyHHmm') as approved_date, " //Approved Date
					+ " LABTRANSID, " //Maximo OT ID
					+ " PSA_REMARKS " //OT Remarks
					+ " FROM "
					+ " LABTRANS WHERE "
					+ " CONVERT(DATETIME, CONVERT(DATE, paymenttransdate)) = CONVERT(DATETIME, CONVERT(DATE, dateadd(day,-"+extractday+",getdate())))"
					+ " AND PSA_OT_FLAG = 1 "
					+ " AND CONVERT(DATETIME, CONVERT(DATE, paymenttransdate)) < CONVERT(DATETIME, CONVERT(DATE, getdate())) "  
					+ " AND GENAPPRSERVRECEIPT = 1 "
					+ " AND PSA_VERIFIED = 1";	
			
 /* 03-09-2020
  * <END> - Update end. 
  */
			
			mxLog.writeLog(getName() + ".writeJobTrans():[Info]SQL Statement - " + otSqlStmt);
			pstmt = conn.prepareStatement(otSqlStmt);
			rs = pstmt.executeQuery();
			
			edotfile = new EDOTFile(processDirectory + OTTRANS_FILENAME);
			
			int count = 0;
			
			while (rs.next())
			{
				ArrayList lst = new ArrayList();
				
				// IC No.
				String icNo = rs.getString("ICNO");
				String sIcNo = EDOTFile.padString(icNo, SPACE, 20, false);
				lst.add(sIcNo);
				
				// Ref WO
				String refWO = rs.getString("REFWO");
				lst.add(EDOTFile.padString(refWO, SPACE, 10, false));
				
				// OT Start Time
				String otStratTime = rs.getString("STARTTIME");
				lst.add(EDOTFile.padString(otStratTime, SPACE, 12, false));
				
				// OT Finish Time
				String otFinishTime = rs.getString("FINISHTIME");
				lst.add(EDOTFile.padString(otFinishTime, SPACE, 12, false));
				
				// User ID
				String userID = rs.getString("LABORCODE");
				lst.add(EDOTFile.padString(userID, SPACE, 30, false));
				
				// Verify User ID
				String verifyUserID = rs.getString("VERIFIED_ID");
				lst.add(EDOTFile.padString(verifyUserID, SPACE, 30, false));
				
				// Verify User Name
				String verifyUserName = rs.getString("VERIFIED_NAME");
				lst.add(EDOTFile.padString(verifyUserName, SPACE, 62, false));
				
				// Verify Date
				String verifyDate = rs.getString("VERIFIED_DATE");
				lst.add(EDOTFile.padString(verifyDate, SPACE, 12, false));
				
				// Approval User ID
				String approvedUserID = rs.getString("APPROVED_ID");
				lst.add(EDOTFile.padString(approvedUserID, SPACE, 30, false));
				
				// Approval User Name
				String approvedUserName = rs.getString("APPROVED_NAME");
				lst.add(EDOTFile.padString(approvedUserName, SPACE, 62, false));
				
				// Approval Date
				String approvedDate = rs.getString("APPROVED_DATE");
				lst.add(EDOTFile.padString(approvedDate, SPACE, 12, false));
				
				// Maximo OT ID
				int mxOTId = rs.getInt("LABTRANSID");
				lst.add(EDOTFile.padString(String.valueOf(mxOTId), SPACE, 12, false));
				
				// Remarks
				String remarks = rs.getString("PSA_REMARKS");
				lst.add(EDOTFile.padString(remarks, SPACE, 100, false));
				
				 //Write OT Transaction Line
				edotfile.writeTransRec(lst);
				count = count + 1;
			}
			
			mxLog.writeLog(getName() + ".writeOTTrans():[Info]Total number of records: " + count);
						
			edotfile.close();
			
			rs.close();
			pstmt.close();
			
			mxLog.writeLog(getName() + ".writeOTTrans():[Info]End processing OT transactions...");
		}
		catch (SQLException e)
		{
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			throw e;						
		} 
		finally {	                    	
       		try {
       			if (rs != null)
    				rs.close();
    			if (pstmt != null)
    				pstmt.close();
    			if (edotfile != null)
    				edotfile.close();
       		} 
       		catch(Exception e){
       			MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
       		}
       	}
	}
	
	/**
	 * @author YCH
	 * @function processData
	 * @date Oct 27, 2011
	 * @comment Generate the flat file
	 * @throws Exception
	 */
	private void processData() throws Exception
	{
		MxDatabase db = null;
		Connection conn = null;
		
		try
		{
			mxLog.writeLog(getName() + ".processData():[Info]Start processing ...");
			
			db = new MxDatabase(getRunasUserInfo());
			conn = db.getConn();
			
			writeOTTrans(conn);
			
			db.releaseResources();
			mxLog.writeLog(getName() + ".processData():[Info]Finished processing ...");
		}
		catch (Exception e)
		{
			if (db != null)
				db.releaseResources();
			throw e;
		}
	}
	
	/**
	 * @author YCH
	 * @function getParameters
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function] Get the parameter from Cron Task.
	 */
	public CrontaskParamInfo[] getParameters() throws MXException, RemoteException
	{
		return params;
	}
	
	//CronTask Parameters
	protected static CrontaskParamInfo params[];
	static
	{
		//Set the number of the parameter.  
	      params = null;
	      params = new CrontaskParamInfo[7];

	      //All the parameter configurable from Cron Task user interface 

	      params[0] = new CrontaskParamInfo();
	      params[0].setName("ZIPEXEC");
	      //++ COMM-IT changed to make it compatible with Maximo 7 API
	      params[0].setDescription("CommonCron","CodeCommented");
	      //-- COMM-IT changed to make it compatible with Maximo 7 API
	      //params[0].setDescription("Code Commented - Executable for ziping the flat file.");
	      params[0].setDefault("gzip -f -q");

	      params[1] = new CrontaskParamInfo();
	      params[1].setName("OTOUTPUTFILEPATH");
	      //++ COMM-IT changed to make it compatible with Maximo 7 API
	      params[1].setDescription("CommonCron","OTTransactionOutput");
	      //-- COMM-IT changed to make it compatible with Maximo 7 API
	      //params[1].setDescription("OT Transaction Output path and filename(Add 'yyyymmdd' to add date to filename)");

	      params[2] = new CrontaskParamInfo();
	      params[2].setName("OTARCHIVEFILEPATH");
	      //++ COMM-IT changed to make it compatible with Maximo 7 API
	      params[2].setDescription("CommonCron","OTTransactionArchive");
	      //-- COMM-IT changed to make it compatible with Maximo 7 API
	      //params[2].setDescription("OT Transaction Archive path and filename (Add 'yyyymmdd' to add date to filename)");

	      params[3] = new CrontaskParamInfo();
	      params[3].setName("PROCESSDIRECTORY");
	      //++ COMM-IT changed to make it compatible with Maximo 7 API
	      params[3].setDescription("CommonCron","DirectoryProcessing");
	      //-- COMM-IT changed to make it compatible with Maximo 7 API
	      //params[3].setDescription("Directory where processing will be done.");

	      params[4] = new CrontaskParamInfo();
	      params[4].setName("ENABLELOG");
	      //++ COMM-IT changed to make it compatible with Maximo 7 API
	      params[4].setDescription("CommonCron","EnableLog");
	      //-- COMM-IT changed to make it compatible with Maximo 7 API
	      //params[4].setDescription("Enable log output('Y' or 'N').");
	      params[4].setDefault("Y");
	      
	      params[5] = new CrontaskParamInfo();
	      params[5].setName("LOGFILEPATH");
	      //++ COMM-IT changed to make it compatible with Maximo 7 API
	      params[5].setDescription("CommonCron","LogDirectory");
	      //-- COMM-IT changed to make it compatible with Maximo 7 API
	      //params[5].setDescription("Log Directory and Filename.");

	      params[6] = new CrontaskParamInfo();
	      params[6].setName("EXTRACTDAY");
	      //++ COMM-IT changed to make it compatible with Maximo 7 API
	      params[6].setDescription("CommonCron","IntegerNoofDays");
	      //-- COMM-IT changed to make it compatible with Maximo 7 API
	      //params[6].setDescription("[Integer]No. of days before current date to extract data (default:1 for yesterday).");
	      params[6].setDefault("1");
	}
}
