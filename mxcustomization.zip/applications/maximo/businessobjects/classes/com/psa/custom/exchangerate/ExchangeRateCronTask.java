/*
 * Modification history
 * 30-01-13 WMJ EMS-550 [Exchange]Set Expire Date for exchange rate to be one day later 
 *
 *
 */


/**
 * @author      HCHA
 * Date         Jun 28, 2006
 * Comment
 */
package com.psa.custom.exchangerate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

//Start of EMS-550
import java.util.Calendar;
//End of EMS-550


import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxXml;
import com.psa.custom.common.MxZip;
import com.psa.custom.ois.MxLog;


import psdi.app.currency.*;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.jms.MEAQueueProcessor;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

/**
 * @author              HCHA
 * @class               ExchangeRateCronTask
 * @date                Jun 28, 2006
 * @function
 */
public class ExchangeRateCronTask extends SimpleCronTask
{

        private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
    private static final String SPACE = " ";
    private static final String NEWLINE = "\n\r";
    private static final int NO_OF_FIELDS = 9;
    private static final int NO_OF_MFIELDS = 8;
    private static final String DEFAULT_ORGID = "PSAST";


    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");

    private MEAQueueProcessor queueProcessor;
    private String qualifiedInstanceName;
    private RecoveryService recoveryService;

    private String extSys;                              //Name of External System
    private String ifaceName;                   //Name of Integration Interface
    private String intObject;                   //Name of Integration Object
    private String directory;                   //Directory to retrieve the file from
    private String delimiter;                   //Delimiter of input flat file
    protected String adminEmail;                //Adminstrator Email
    protected String emailSubj;                 //Alert Email Subject
    private String importFileName;              //Import Base File Name
    private String unzipExec;                   //Executable/Command for unzip function
    private String processDirectory;    //Directory where processing are done
    private String logDir;                              //Directory where log file will be placed
    private boolean enableLog;                  //Enable Log

    private File loadDir;
    protected MxLog mxLog;
    private MxEmail email;
    private MxXml mxXml;

    private boolean isProcErr;
    private StringBuffer errMessage;

    private boolean updatedRate;
    private StringBuffer updateRateMsg;


    protected boolean initialized;

    /*
     * Author: HCHA
     * 28 JUN 2006 - Cron task constructor initialize default value
     */
        public ExchangeRateCronTask()
        {
                super();

                initialized = false;

            recoveryService = null;
            queueProcessor = null;
            qualifiedInstanceName = null;
            queueProcessor = new MEAQueueProcessor();

        extSys = null;
        ifaceName = null;
        intObject = null;
        loadDir = null;
        directory = null;
        delimiter = null;
        adminEmail = null;
        emailSubj = null;
        importFileName = null;
        unzipExec = null;
        processDirectory = null;
        logDir = null;
        enableLog=false;

                errMessage = null;
                isProcErr = false;

            updatedRate = false;
            updateRateMsg=null;
        }

        /* Author: HCHA
     * Date: 29 Jun 2006
     * Comment: [Standard Cron Task Function]Initialize cron task
     */
    public void init()
        throws MXException
    {
        System.out.println("--inside init()--" + getName());
        super.init();

        email = new MxEmail(adminEmail);
        mxXml = new MxXml();
        mxLog = new MxLog();
        initialized = true;
    }

        /*
         * Author: HCHA
     * 29 Jun 2006 - Get the parameter value setting from maximo User Interface in configuration
     */
    private void refreshSettings()
    {
        System.out.println("--inside refreshsettings--");
        integrationLogger.debug("Entering refreshSettings");

        try {

                delimiter = getParamAsString("SPLITTAG");
            extSys = getParamAsString("EXTSYSNAME");
            ifaceName = getParamAsString("INTERFACENAME");
            intObject = getParamAsString("INTOBJECT");
            directory = getParamAsString("DIRECTORY");
            loadDir = new File(directory);
            //Removed by WMJ 20120820 for MX7 recoveryService
            //recoveryService = new RecoveryService(loadDir);

            adminEmail = getParamAsString("ALERTEMAIL");
            email.setAdmin(adminEmail);
            emailSubj = getParamAsString("ALERTEMAILSUBJ");
                System.out.println("delimiter" + delimiter + "extsys" + extSys+"ifacename"+ifaceName+"intObject"+intObject+"directory"+directory+"loadDir"+loadDir+"recoveryService"+recoveryService+"adminEmail"+adminEmail+"emailSubj"+emailSubj);
            //Replace filename by today's date if "yyyymmdd" is specified in import file base name
            DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
            String todayDate=fileDateFormat.format(new Date());
            importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmdd",todayDate);
                      System.out.println("importFileName-"+importFileName);
            //Paramater for Unzip
            unzipExec = getParamAsString("UNZIPEXEC");

            //Directory where processing are done
            processDirectory= getParamAsString("PROCESSDIRECTORY");

            //Log
            logDir = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd",todayDate);
            enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y")==0);
            mxLog.setEnabled(enableLog);
            mxLog.setLogFilePath(logDir);
            mxLog.setLogTag(getName());
            mxLog.createLogFile();

            integrationLogger.debug("Leaving refreshSettings");
                System.out.println("--end of refreshsetting()--");

        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }

    /* Author: BTE
     * Date: 29 Jun 2006
     * Comment: [Standard Cron Task Function] Start cron task
     */

    public void start() {
        System.out.println("--start if start()--");
        try {
            refreshSettings();

            MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Start - " + qualifiedInstanceName + " started for System:" + extSys + " and Interface:" + ifaceName );
            setSleepTime(0L);
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }

    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function]Stop cron task
     */

    public void stop()
    {
        System.out.println("--start if stop()--");

        try{
                mxLog.closeLogFile();
        }
        catch(Exception exception){
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }

        MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Stop - " +
                        qualifiedInstanceName +
                        " stopped for System:" +
                        extSys +
                        " and interface:" +
                        ifaceName );
    }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function] Set cron task instance
     */

    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {
        System.out.println("--start of setCrontaskInstance()--");

        try {
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") +
                "." + crontaskinstanceremote.getString("instancename");
        }
        catch(Exception exception) {
            integrationLogger.error(exception.getMessage(), exception);
        }
        System.out.println("--end of setCrontaskInstance()--");

    }

    /* Author: HCHA
     * Date: 29 Jun 2006
     * Comment: returns true if all required parameter is set
     */

    private boolean isReqParamSet()
    {

        if(adminEmail==null) return false;
        if(ifaceName==null) return false;
        if(extSys==null) return false;
        if(processDirectory==null) return false;
        if(importFileName==null) return false;
        if(directory==null) return false;

        return true;
    }

        /* Author: HCHA
     * Date: 16 MAR 2006
     * Comment: Generate Email
     */

        private String genEmail(Exception e){
        System.out.println("--start of genEmail()--");

        //Form Email Message
        String emailMsg = "Date: " + new Date()+"\n";
        emailMsg += "Error in CronTask: "+getName()+ "\n";
        emailMsg+="Error Message: "+ e.getMessage()+"\n";
        emailMsg+="Detail:\n";
        emailMsg+=e.toString()+"\n";
        StackTraceElement element[] = e.getStackTrace();
        for(int i=0; i< element.length; i++){
                emailMsg+="\tat "+ element[i].toString()+"\n";
        }
        System.out.println("--end of genEmail()--");

        return emailMsg;
        }

        /* Author: HCHA
     * Date: 30 JUN 2006
     * Comment: Generate Formated Error Msg
     */

        private String genErrMsg(Exception e, Vector vec){

        String errMsg = "Line:"+vec.toString()+ "\n";
        errMsg+="Error Message: "+ e.getMessage()+"\n";
        errMsg+="Detail:"+"\n";
        errMsg+=e.toString()+"\n";
        StackTraceElement element[] = e.getStackTrace();
        for(int i=0; i< element.length; i++){
                errMsg+="\tat "+ element[i].toString()+"\n";
        }

        return errMsg;
        }

        /*
         * Author: BTE
     * 29 JUN 2006 - Get the parameter from Cron Task.
     */
    public CrontaskParamInfo[] getParameters() throws MXException, RemoteException {
            return params;
        }

    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function]
     * Cron task function - Retrieve flat file from remote server,
     * process flat file, convert to xml format and import to maximo.
     */
        public void cronAction()
        {
        System.out.println("-start of cronAction()-"+getName());
                integrationLogger.debug("Entering cronAction");
                mxLog.writeLog(" cronAction(): Start CronTask Action");

        try {
                System.out.println("-inside try of initialized-");
            if(!initialized){
                mxLog.writeLog(" cronAction(): CronTask not initialized!");
                throw new Exception(getName()+".cronAction(): CronTask not initialized!");
            }

                // Refresh setting before perform cron action
            refreshSettings();

                if (isReqParamSet()) {
                        processFolderData();
                }
                else {
                        mxLog.writeLog(" cronAction(): Required parameters not set.");
                        throw new Exception("Required parameters not set.");
                }

        }
        catch(Exception e) {

            MicUtil.INTEGRATIONLOGGER.error("["+getName()+"] "+e.getMessage(), e);

            String emailContent = genEmail(e);
            email.send(emailSubj,emailContent );
                mxLog.writeLog("Email Sent:\n"+emailContent);

            stop();
        }

        integrationLogger.debug("Leaving cronAction");
        mxLog.writeLog(" cronAction(): End CronTask Action");

        }

    /* Author: HCHA
     * 29 JUN 2006 - Process the import flat file
     */
    public void processFolderData() throws Exception {
        System.out.println("--start of processFolderData()--importFileName--"+ importFileName);

        integrationLogger.debug("Entering processFolderData");
        mxLog.writeLog(" processFolderData(): Start Processing Data");

                SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);

                File afile[] = loadDir.listFiles(filter);

                if(afile != null && afile.length!=0) {

                        int fileprocessed = 0;

                        for(int j = 0; j < afile.length; j++)
                        {

                        integrationLogger.info("["+getName()+"] Processing '" + afile[j].getName() + "'" );
                        mxLog.writeLog(" processFolderData(): Processing '" + afile[j].getName() + "'");



                errMessage = new StringBuffer();
                isProcErr = false;

                updateRateMsg = new StringBuffer();
                updatedRate = false;

                try {                                                                                                                                     

                        //Copy file to process directory
                        String file = processDirectory + afile[j].getName();
                        //MxFileCopy.fileCopy(afile[j].toString(), processDirectory + afile[j].getName());
                        
						//Unzip File
						//int lastPos = file.lastIndexOf(".");
                		//String destPathWithoutZipExt = (lastPos > 0) ? destPath.substring(0, lastPos) : destPath;
					
                        String exchangeRateFile=afile[j].getName();
						int dotIndex = exchangeRateFile.lastIndexOf('.');
                    	if (dotIndex > 0) 
                    	{
                    		exchangeRateFile = exchangeRateFile.substring(0, dotIndex);
                    	}
						String sourcePath=directory + afile[j].getName();
						String destPath=processDirectory + exchangeRateFile;
						
						String cmd = unzipExec + SPACE + sourcePath + SPACE + destPath;
						int retCode=MxZip.unzipFile(cmd);
						mxLog.writeLog("Exchange Rate source path: "+sourcePath);
						mxLog.writeLog("Exchange Rate destination path: "+destPath);
						mxLog.writeLog("Cmd: "+cmd);
						mxLog.writeLog("Return code: "+retCode);
						
                        //Unzip File
                        //String cmd = unzipExec + SPACE + file;
                        if ( retCode== 0 )
                        {

                                //Get filename without extension
                                int dotPos = file.lastIndexOf(".");
                                String extractedFile = file.substring(0,dotPos);

                                Collection col = parseFlatFile(extractedFile);

                            // Create a XML document based on the data from the flat file.
                                Collection xmlCol = generateXMLDocument(col);

                            // Important BufferedInputStream has a size of 2000byte only.
                                multiSplitPerformed(xmlCol, j);

                                //Delete Extracted File
                                File fExtractedFile = new File(extractedFile);
                                fExtractedFile.delete();

                        }
                        else{
                                mxLog.writeLog(" processFolderData(): Unable to unzip file - " + file);
                                throw new Exception("["+getName()+"]Unable to unzip file - " + file);
                        }

                                //Added by WMJ 20120820 for MX7 RecoveryService
                                recoveryService = new RecoveryService(afile[j]);
                                        //recoveryService.startRecovery();

                }
                finally {
                        try {
                                mxLog.writeLog(" processFolderData(): End Recovery");
                                integrationLogger.debug("processFolderData: End Recovery");

                                recoveryService.endRecovery();
                        }
                        catch(Exception e){
                                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                        }
                }

                fileprocessed++;

                if (isProcErr) {

                        String emailMsg = "Date: " + new Date()+"\n";
                        emailMsg += "Error in CronTask: "+getName()+ "\n";
                        emailMsg += "File Processing: "+afile[j].getName()+NEWLINE;
                        emailMsg +=errMessage.toString();

                        email.send(emailSubj,emailMsg );
                    mxLog.writeLog("Email Sent:\n"+emailMsg);
                        }

                if (updatedRate) {

                        String emailMsg = "Date: " + new Date()+ "\n";
                        emailMsg += "CronTask: "+getName()+ "\n";
                        emailMsg += "File Processing: "+afile[j].getName()+ NEWLINE;
                        emailMsg += "[IMPORTANT NOTICE]"+NEWLINE;
                        emailMsg += "Existing exchange rates have been updated!\n";
                        emailMsg += "Please check the following exchange rates:"+NEWLINE;
                        emailMsg += updateRateMsg.toString();

                        email.send("[EMS-EXCHANGE]IMPORTANT: Existing Exchange Rates Updated!", emailMsg);
                    mxLog.writeLog("Email Sent:"+NEWLINE+emailMsg);
                        }


            }

                        if(fileprocessed!=0){
                                mxLog.writeLog(" processFolderData(): "+fileprocessed+ " file(s) processed." );
                                integrationLogger.info("["+getName()+"] "+fileprocessed+ " file(s) processed." );
                        }
                        else{
                                mxLog.writeLog(" processFolderData(): No files was processed!");
                                throw new Exception("["+getName()+"]No files was processed!");
                        }

        }
                else{
                        mxLog.writeLog(" processFolderData(): Unable to read input file '"+importFileName+"'");
                        throw new Exception("["+getName()+"]Unable to read input file '"+importFileName+"'");
                }

        integrationLogger.debug("Leaving processFolderData");
        mxLog.writeLog(" processFolderData(): Leaving Processing Data");
        }

    /* Author: HCHA
     * 29 JUN 2006 - Parse flat file.
     */
    private Collection parseFlatFile(String file)
        throws IOException
    {
        integrationLogger.debug("Entering parseFlatFile");
        mxLog.writeLog(" parseFlatFile(): Start Parse Flat File");

        // BTE: Parse the OFA flat flat file first
        // Reading the import flat file
        BufferedReader flatfileReader;
        Collection col = new Vector();

                flatfileReader = new BufferedReader(new FileReader(file));

        // Ignore first line of text as its the file header
        String curLine = flatfileReader.readLine();

        while((curLine = flatfileReader.readLine()) != null)
        {
                String[] str = curLine.split(delimiter);

                Vector vec = new Vector();
                
                //ORG: if(str.length!=NO_OF_FIELDS){
                
                if((str.length < NO_OF_MFIELDS) || (str.length > NO_OF_FIELDS)){
                        isProcErr=true;
                    String errMsg = NEWLINE+ "Line:"+curLine+ NEWLINE;
                    errMsg+="Error Message: Invalid Number of Fields"+NEWLINE;
                                errMessage.append(errMsg);
                        mxLog.writeLog("["+getName()+"][ERROR] Invalid line:'"+curLine+"'");
                        continue;
                }

                for(int i=0;i<str.length;i++){
                        //Add to element to vector.
                        vec.add(str[i].trim());
                }

            // Add to a collection
            col.add(vec);
        }

        integrationLogger.debug("parseFlatFile - Valid lines parsed: "+col.size());
        integrationLogger.debug("Leaving parseFlatFile");
        mxLog.writeLog(" parseFlatFile(): Valid lines parsed: "+col.size());
        mxLog.writeLog(" parseFlatFile(): Finish Parse Flat File");
        return col;
    }

    /* Author: HCHA
     * 15 May 2006 - Convert Date
     */
    private Date convertDate(String inDate)
        throws Exception
    {
        System.out.println("--start of convertDate()--inDate--"+ inDate);
        SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy");
        Date outDate = null;
        outDate = dateformat.parse(inDate);

        return outDate;
    }

    /*
     * Author: BTE
     * 13 FEB 2006 - Send data to JMS queue
     */
        public boolean splitPerformed(byte[] abyte0, String ifaceName, int i) throws Exception {

                integrationLogger.debug("Entering splitPerformed");


        try {
                        sendMessage(abyte0, ifaceName, i);

                } catch (Exception e) {
                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
                    MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");

                throw new Exception(e.getMessage());
                }

                integrationLogger.debug("Leaving splitPerformed");
                return true;
    }


    /*
     * Author: BTE
     * 13 FEB 2006 - Send a collection of XML data to JMS queue
     */
        public void multiSplitPerformed(Collection col, int i) throws Exception {

                integrationLogger.debug("Entering multiSplitPerformed");
                mxLog.writeLog(" multiSplitPerformed(): Start Sending XML data to queue");

        try {

                        Iterator iter = col.iterator();
                        while (iter.hasNext()) {
                                String xmlData = (String)iter.next();

                                if(!xmlData.matches("")){
                                        splitPerformed(xmlData.getBytes(), ifaceName, i);
                                }
                        }

                        // Clear collection
                        col.clear();

                        integrationLogger.debug("Leaving multiSplitPerformed");
                        mxLog.writeLog(" multiSplitPerformed(): Finish Sending XML data to queue");

                } catch (Exception e) {
                MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                if((e instanceof MXException) && ((MXException)e).getErrorKey().equalsIgnoreCase("unablewritetoqueue"))
                    MicUtil.INTEGRATIONLOGGER.warn("File Load Task: Unable to write to queue: Going to sleep");

                throw new Exception(e.getMessage());
                }

        }


        // XML tag's
        //updated by WMJ on 20120909
        //private final String MSG_START_INTERFACE =
        //" xmlns=\"http://www.ibm.com/maximo\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" creationDateTime=\"2009-01-12T06:23:20-05:00\" transLanguage=\"EN\" baseLanguage=\"EN\" maximoVersion=\"7 1 20100522-0325 V7117-47\" event=\"1\">";
        private final String MSG_START_INTERFACE =
        " xmlns=\"http://www.ibm.com/maximo\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" transLanguage=\"EN\" baseLanguage=\"EN\" maximoVersion=\"7 1 20100522-0325 V7117-47\" event=\"1\">";
        private final String TAG_START_HEADER ="<Header operation=\"Notify\" event=\"0\">";
        private final String TAG_END_HEADER = "</Header>";
        private final String TAG_SENDERID = "SenderID";
        private final String TAG_START_CONTENT = "<Content>";
        private final String TAG_END_CONTENT = "</Content>";

        private final String TAG_MBO = "EXCHANGE";


        private final String TAG_MBOSET = "MXEXCHANGESet";



        private final String TAG_ORGID = "ORGID";
        private final String TAG_CURRENCYCODE = "CURRENCYCODE";
        private final String TAG_ACTIVEDATE = "ACTIVEDATE";
        private final String TAG_EXPIREDATE = "EXPIREDATE";
        private final String TAG_EXCHANGERATE = "EXCHANGERATE";
        private final String TAG_CURRENCYCODETO = "CURRENCYCODETO";


    /*
     * Author: HCHA
     * 26 JUN 2006 - Create a XML document
     */
    private Collection generateXMLDocument(Collection col)
        throws Exception
    {
        integrationLogger.debug("Entering generateXMLDocument");
        mxLog.writeLog(" generateXMLDocument(): Start Generatering XML Documents");

        Collection xmlCol = new Vector();

        Iterator iterParsedData = col.iterator();
        while (iterParsedData.hasNext()) {

                //Vector Element
                //0. Record Type
                //1. From Currency Code (EXCHANGE.CURRENCYCODE)
                //2. Conversion Date    (EXCHANGE.ACTIVEDATE & EXCHANGE.EXPIREDATE)
                //3. Conversion Rate    (EXCHANGE.EXCHANGERATE)
                //4. Conversion Type
                //5. Creation Date
                //6. Last Update Date
                //7. To Currency Code   (EXCHANGE.CURRENCYCODETO)

                //NOTE: EXCHANGE.ORGID to be default to "PSAST"

                // Get new record to convert to XML
                Vector vec = (Vector)iterParsedData.next();

                try {
                        integrationLogger.debug("Line:"+vec.toString());

                        String currencyFrom = (String) vec.elementAt(1);
                        integrationLogger.debug("Curenncy From:"+currencyFrom);

                        String currencyTo = (String) vec.elementAt(7);
                        integrationLogger.debug("Curenncy To:"+currencyTo);

                        Date conversionDate = convertDate((String) vec.elementAt(2));
                        integrationLogger.debug("Conversion Date:"+conversionDate);
                        
                        //Start of EMS-550
                        Date expiryDate = convertDate((String) vec.elementAt(2));
                        Calendar cal=Calendar.getInstance();
                        cal.setTime(expiryDate);
                        cal.add(Calendar.DATE, 1);  
                        DateFormat expYmdDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        String expiryDateStr=expYmdDateFormat.format(cal.getTime())+"T00:00:00+08:00";
                        integrationLogger.debug("Expiry Date:"+expiryDateStr);
                        //End of EMS-550
                        
                        float exchangeRate = Float.valueOf((String)vec.elementAt(3)).floatValue();
                        integrationLogger.debug("Exchange Rate:"+exchangeRate);

                        //Check for existing exchange rate record for same day
                        ExchangeSetRemote exchangeSet = (ExchangeSetRemote) MXServer.getMXServer().getMboSet("EXCHANGE", getRunasUserInfo());
                        String sql = "CURRENCYCODE=:1 AND CURRENCYCODETO=:2 AND EXPIREDATE=:3 AND ORGID=:4";

                        DateFormat YmdDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        //20060816 HCHA - Correct bug introducted by Maximo PO4
                        String conversionDateStr=YmdDateFormat.format(conversionDate)+"T00:00:00+08:00";

                SqlFormat sqlformat = new SqlFormat(getRunasUserInfo(), sql);
                sqlformat.setObject(1, "EXCHANGE", "CURRENCYCODE", currencyFrom);
                sqlformat.setObject(2, "EXCHANGE", "CURRENCYCODETO", currencyTo);
                //20060816 HCHA - Correct bug introducted by Maximo PO4
                //Start of EMS-550
                //sqlformat.setObject(3, "EXCHANGE", "EXPIREDATE", conversionDateStr);
                sqlformat.setObject(3, "EXCHANGE", "EXPIREDATE", expiryDateStr);
                //End of EMS-550
                sqlformat.setObject(4, "EXCHANGE", "ORGID", DEFAULT_ORGID);

                exchangeSet.setWhere(sqlformat.format());


                if(!exchangeSet.isEmpty())
                {
                        ExchangeRemote exchangeMbo = (ExchangeRemote) exchangeSet.getMbo(0);

                        float dbExchangeRate = exchangeMbo.getFloat("EXCHANGERATE");
                        if(dbExchangeRate != exchangeRate){
                                //Different Exchange Rate in flat file and database
                                String updateMsgStr = (String)vec.elementAt(2)+" - ["+currencyFrom+"-"+currencyTo+"] Current Rate:"+dbExchangeRate+" New Rate:"+ exchangeRate;
                                updateRateMsg.append(updateMsgStr);
                                updateRateMsg.append(NEWLINE);
                                updatedRate = true;
                                integrationLogger.debug("Updated Exchange rate..");
                                integrationLogger.debug(updateMsgStr);
                                mxLog.writeLog(" generateXMLDocument():[ERROR]Updated Rates -" + updateMsgStr);
                                String exchangeRateXml = genExchangeRateXml(currencyFrom, currencyTo, conversionDateStr, expiryDateStr, (String)vec.elementAt(3));
                                //End of EMS-550
                                xmlCol.add(exchangeRateXml);
                        }
                        integrationLogger.debug("Skip..Exchange rate already exist..");
                        continue;
                }

                //Start of EMS-550
                String exchangeRateXml = genExchangeRateXml(currencyFrom, currencyTo, conversionDateStr, expiryDateStr, (String)vec.elementAt(3));
                //End of EMS-550
                xmlCol.add(exchangeRateXml);

                }
                catch(Exception e) {
                        isProcErr=true;
                        String errMsg = genErrMsg(e, vec);
                                errMessage.append(errMsg);
                                errMessage.append(NEWLINE);
                                mxLog.writeLog(" generateXMLDocument():[ERROR]" + errMsg);
            }
        }


        // Clear collection
        col.clear();
        integrationLogger.debug("generateXMLDocument - Valid xml doc generated: "+xmlCol.size());
        integrationLogger.debug("Leaving generateXMLDocument");
        mxLog.writeLog(" generateXMLDocument():Valid xml doc generated: "+xmlCol.size());
        mxLog.writeLog(" generateXMLDocument(): Finish Generatering XML Documents");

        return xmlCol;
    }


    /*
     * Author: HCHA
     * 29 JUN 2006 - Generate XML
     */
	//Start of EMS-550
    //private String genExchangeRateXml(String currencyFrom, String currencyTo, String conversionDate, String exchangeRate )
    private String genExchangeRateXml(String currencyFrom, String currencyTo, String conversionDate, String expiryDate, String exchangeRate )
    //End of EMS-550
        throws Exception
    {

        integrationLogger.debug("Entering genExchangeRateXml");

        // Create XML
        String xml =
        "<" + intObject +MSG_START_INTERFACE+
                "<"+TAG_MBOSET+">" +
                        "<"+TAG_MBO+" action=\"AddChange\">"+
                        mxXml.genTagSting(TAG_ORGID, DEFAULT_ORGID) +
                        mxXml.genTagSting(TAG_CURRENCYCODE, currencyFrom) +
                        mxXml.genTagSting(TAG_CURRENCYCODETO, currencyTo) +
                        mxXml.genTagSting(TAG_ACTIVEDATE, conversionDate) +
                        mxXml.genTagSting(TAG_EXPIREDATE, expiryDate ) +
                        mxXml.genTagSting(TAG_EXCHANGERATE,exchangeRate) +
             "</" +TAG_MBO+ ">" + // object
                        "</" + TAG_MBOSET +">" + //Integration object
                "</" + intObject +  ">"; // Interface name

                integrationLogger.debug("Leaving genExchangeRateXml");
                System.out.println("--xml--" + xml);
                return xml;
    }











    /* Author: BTE
     * 13 FEB 2006 - Sending message to JMS queue.
     */
    private void sendMessage(byte abyte0[], String ifaceName, int i)
        throws Exception
    {

        integrationLogger.debug("Entering sendMessage");

        try {


                /*
            HashMap hashmap = new HashMap();
            hashmap.put("SENDER", extSys);
            hashmap.put("INTERFACE", ifaceName);
            */
            if(queueProcessor == null)
                queueProcessor = new MEAQueueProcessor();

            queueProcessor.writeDataToQueueIn(abyte0, extSys,ifaceName);

            integrationLogger.debug("Leaving sendMessage");
            }
            catch(Exception exception) {

                throw exception;
            }                                                                                                                                             
        }


    /*
     * Define Maximo parameter setting in Cron Task
     */
    private static CrontaskParamInfo params[];
    static
    {
        // BTE: Set the number of the parameter.
        params = null;
        params = new CrontaskParamInfo[12];

        // BTE: All the parameter configurable from Cron Task user interface
        params[0] = new CrontaskParamInfo();
        params[0].setName("SPLITTAG");
        params[0].setDefault("~");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[0].setDescription("Delimiter for flat file.");
        params[0].setDescription("CommonCron","DelimiterFlatFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[1] = new CrontaskParamInfo();
        params[1].setName("EXTSYSNAME");
        params[1].setDefault("EXCHANGE");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[1].setDescription("External System Name.");
        params[1].setDescription("CommonCron","ExternalSystem");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[2] = new CrontaskParamInfo();
        params[2].setName("INTERFACENAME");
        params[2].setDefault("MXEXCHNGInterface");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[2].setDescription("Integration Interface Name.");
        params[2].setDescription("CommonCron","IntegrationInterfaceName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[3] = new CrontaskParamInfo();
        params[3].setName("DIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[3].setDescription("Local directory where flat file will be read.");
        params[3].setDescription("CommonCron","LocalDirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[4] = new CrontaskParamInfo();
        params[4].setName("PROCESSDIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[4].setDescription("Temp Directory where processing will be done.");
        params[4].setDescription("CommonCron","TempDirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[5] = new CrontaskParamInfo();
        params[5].setName("ALERTEMAIL");
       //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[5].setDescription("Admin email address for notification of error.");
        params[5].setDescription("CommonCron","Adminemailaddress");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[6] = new CrontaskParamInfo();
        params[6].setName("IMPORTFILENAME");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[6].setDescription("File name of the input file(Includes with 'yyyymmdd*' for current day file)");
        params[6].setDescription("CommonCron","FileNameOfTheInputFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[7] = new CrontaskParamInfo();
        params[7].setName("UNZIPEXEC");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[7].setDescription("Executable for unziping the input flat file.");
        params[7].setDescription("CommonCron","ExecutableUnziping");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[7].setDefault("gunzip -f -q");

        params[8] = new CrontaskParamInfo();
        params[8].setName("ALERTEMAILSUBJ");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[8].setDescription("Email Subject for the Alert Email.");
        params[8].setDescription("CommonCron","EmailSubject");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[9] = new CrontaskParamInfo();
        params[9].setName("ENABLELOG");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[9].setDescription("Enable log output('Y' or 'N').");
        params[9].setDescription("CommonCron","EnableLog");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[9].setDefault("Y");

        params[10] = new CrontaskParamInfo();
        params[10].setName("LOGFILEPATH");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[10].setDescription("Log Directory and Filename.");
        params[10].setDescription("CommonCron","LogDirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[11] = new CrontaskParamInfo();
        params[11].setName("INTOBJECT");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[11].setDescription("Integration Object Name.");
        params[11].setDescription("CommonCron","IntegrationObjectName");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[11].setDefault("MXEXCHANGE");


    }

}

