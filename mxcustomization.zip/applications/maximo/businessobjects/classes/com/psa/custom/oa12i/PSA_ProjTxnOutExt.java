package com.psa.custom.oa12i;

import psdi.iface.oa12.ERPOutExt;
import java.rmi.RemoteException;
import psdi.iface.mic.StructureData;
import psdi.iface.proc.ControlsCache;
import psdi.mbo.MaximoDD;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.mbo.Translate;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
 
public class PSA_ProjTxnOutExt
  extends ERPOutExt
{
  Translate translator;
  ControlsCache controls;
  
  public StructureData setDataOut(StructureData paramStructureData)
    throws MXException, RemoteException
  {
    integrationLogger.debug("Entering ProjTxnOutExt.setDataOut");
    this.translator = MXServer.getMXServer().getMaximoDD().getTranslator();
    this.controls = getMaxIfaceControl();
    
    String str1 = paramStructureData.getCurrentData("ORGID");
    String str2 = paramStructureData.getCurrentData("SITEID");
    String str3 = paramStructureData.getCurrentData("SOURCEMBO");
    if (!this.controls.isControlEqual(getExtSystem(), "PROJSEND", str1, str2, str3))
    {
      integrationLogger.debug("Skipping transaction : PROJSEND does not list this transaction");
      throw new MXApplicationException("iface", "skip_transaction");
    }
    if (paramStructureData.isCurrentDataNull("FINCNTRLID"))
    {
      integrationLogger.debug("Skipping transaction : FINCNTRLID is null");
      throw new MXApplicationException("iface", "skip_transaction");
    }
    SqlFormat localSqlFormat = new SqlFormat(getUserInfo(), "orgid=:1 and fincntrlid = :2");
    localSqlFormat.setObject(1, "FINCNTRL", "ORGID", str1);
    localSqlFormat.setObject(2, "FINCNTRL", "FINCNTRLID", paramStructureData.getCurrentData("FINCNTRLID"));
    MboSetRemote localMboSetRemote = MXServer.getMXServer().getMboSet("FINCNTRL", getUserInfo());
    localMboSetRemote.setWhere(localSqlFormat.format());
    MboRemote localMboRemote = localMboSetRemote.moveFirst();
    if (localMboRemote == null)
    {
      localMboSetRemote.close();
      integrationLogger.debug("Skipping transaction : This FINCNTRL record not found for the FINCNTRLID");
      throw new MXApplicationException("iface", "skip_transaction");
    }
    if (!localMboRemote.getBoolean("ISCHARGEABLE"))
    {
      localMboSetRemote.close();
      integrationLogger.debug("Skipping transaction : This FINCNTRL record is not chargeble");
      throw new MXApplicationException("iface", "skip_transaction");
    }
    localMboSetRemote.close();
    if ((str3.equals("MATRECTRANS")) || (str3.equals("SERVRECTRANS"))) {
      checkAndSkipTransaction(paramStructureData, str3, str1, str2);
    }
    if (!paramStructureData.isGLDataNull("GLCREDITACCT")) {
      paramStructureData.setGL("GLCREDITACCT", getORAGLAccount(paramStructureData.getGL("GLCREDITACCT"), str1));
    } else {
      throw new MXApplicationException("iface", "oa_noglcreditpa");
    }
    if (!paramStructureData.isGLDataNull("GLDEBITACCT")) {
      paramStructureData.setGL("GLDEBITACCT", getORAGLAccount(paramStructureData.getGL("GLDEBITACCT"), str1));
    } else {
      throw new MXApplicationException("iface", "oa_nogldebitpa");
    }
    paramStructureData.setCurrentData("ORGID", getXREFValue("ORGXREF", str1));
    paramStructureData.setCurrentData("SITEID", getXREFValue("SITEXREF", str2));
    mapAdditionalData(paramStructureData, str3, str1, str2);
    
    return paramStructureData;
  }
  
  private void checkAndSkipTransaction(StructureData paramStructureData, String paramString1, String paramString2, String paramString3)
    throws MXException, RemoteException
  {
    SqlFormat localSqlFormat = null;
    String str1 = paramStructureData.getCurrentData("ISSUETYPE");
    String str2 = this.translator.toInternalString("ISSUETYP", str1, paramString3, paramString2);
    if ((str2 == null) || (paramStructureData.isCurrentDataNull("REFWO")) || ((str2.equalsIgnoreCase("RECEIPT")) && (str2.equalsIgnoreCase("RETURN")) && (str2.equalsIgnoreCase("INVOICE"))))
    {
      integrationLogger.debug("Skipping transaction : This transaction is not RECEIPT, RETURN or INVOICE OR not attached to WO");
      throw new MXApplicationException("iface", "skip_transaction");
    }
    if ((!paramStructureData.isCurrentDataNull("PONUM")) && ((str2.equalsIgnoreCase("RECEIPT")) || (str2.equalsIgnoreCase("RETURN"))))
    {
      if (this.controls.isControlTrue(getExtSystem(), "PROJAP", paramString2, paramString3))
      {
        integrationLogger.debug("Skipping transaction : The project info will be sent through INVOICE");
        throw new MXApplicationException("iface", "skip_transaction");
      }
      if (this.controls.isControlTrue(getExtSystem(), "PROJPO", paramString2, paramString3))
      {
        integrationLogger.debug("Skipping transaction : Project info is already sent to Oracle with the PO.");
        throw new MXApplicationException("iface", "skip_transaction");
      }
      MboSetRemote localMboSetRemote1 = paramStructureData.getCurrentMbo().getMboSet("PO");
      
      MboRemote localMboRemote1 = localMboSetRemote1.moveFirst();
      if ((localMboRemote1 != null) && (localMboRemote1.getString("OWNERSYSID").equals("OA")))
      {
        integrationLogger.debug("Skipping transaction : PO is created in Oracle.");
        throw new MXApplicationException("iface", "skip_transaction");
      }
      if (this.controls.isControlTrue(getExtSystem(), "PROJPR", paramString2, paramString3))
      {
        localSqlFormat = new SqlFormat(getUserInfo(), "siteid = :1 and ponum = :2 and polinenum = :3");
        localSqlFormat.setObject(1, "PRLINE", "SITEID", paramString3);
        localSqlFormat.setObject(2, "PRLINE", "PONUM", paramStructureData.getCurrentData("PONUM"));
        localSqlFormat.setObject(3, "PRLINE", "POLINENUM", paramStructureData.getCurrentData("POLINENUM"));
        MboSetRemote localMboSetRemote2 = MXServer.getMXServer().getMboSet("PRLINE", getUserInfo());
        localMboSetRemote2.setWhere(localSqlFormat.format());
        MboRemote localMboRemote2 = localMboSetRemote2.moveFirst();
        if (localMboRemote2 != null)
        {
          localMboSetRemote2.close();
          
          integrationLogger.debug("Skipping transaction : Project info is already sent to Oracle with the PR.");
          throw new MXApplicationException("iface", "skip_transaction");
        }
        localMboSetRemote2.close();
      }
    }
    if ((str2.equalsIgnoreCase("INVOICE")) && (this.controls.isControlTrue(getExtSystem(), "PROJAP", paramString2, paramString3)))
    {
      integrationLogger.debug("Skipping transaction : The project info is already sent through INVOICE");
      throw new MXApplicationException("iface", "skip_transaction");
    }
  }
  
  private void mapAdditionalData(StructureData paramStructureData, String paramString1, String paramString2, String paramString3)
    throws MXException, RemoteException
  {
    if (paramString1.equals("LABTRANS"))
    {
      paramStructureData.setCurrentData("OA_RESLEVELLABOR", this.controls.getValueControl(getExtSystem(), "RESLEVELLABOR", paramString2, paramString3));
      paramStructureData.setCurrentData("OA_TRANS_SOURCE", this.controls.getValueControl(getExtSystem(), "SRCTIM", paramString2, paramString3));
      if (paramStructureData.isCurrentDataNull("OA_EXPENDTYPE")) {
        paramStructureData.setCurrentData("OA_EXPENDTYPE", this.controls.getValueControl(getExtSystem(), "EXPENDLABOR", paramString2, paramString3));
      }
    }
    else
    {
      paramStructureData.setCurrentData("OA_TRANS_SOURCE", this.controls.getValueControl(getExtSystem(), "SRCUSE", paramString2, paramString3));
      if (paramStructureData.isCurrentDataNull("OA_CHARGE_ORG")) {
        paramStructureData.setCurrentData("OA_CHARGE_ORG", this.controls.getValueControl(getExtSystem(), "CHARGEORG", paramString2, paramString3));
      }
      if (paramStructureData.isCurrentDataNull("OA_NLR_ORG")) {
        paramStructureData.setCurrentData("OA_NLR_ORG", this.controls.getValueControl(getExtSystem(), "NLRORG", paramString2, paramString3));
      }
    }
    String str;
    /*if (paramString1.equals("TOOLTRANS")) {
      if (paramStructureData.isCurrentDataNull("OA_EXPENDTYPE"))
      {
        str = this.controls.getValueControl(getExtSystem(), "RESLEVELTOOL", paramString2, paramString3);
        if (str.equals("1")) {
          paramStructureData.setCurrentData("OA_EXPENDTYPE", this.controls.getValueControl(getExtSystem(), "EXPENDTOOL", paramString2, paramString3));
        } else {
          paramStructureData.setCurrentData("OA_EXPENDTYPE", paramStructureData.getCurrentData("ITEMNUM"));
        }
      }
    }*/
    if ((paramString1.equals("MATUSETRANS")) || (paramString1.equals("MATRECTRANS")) || (paramString1.equals("SERVRECTRANS"))) {
      if (paramStructureData.isCurrentDataNull("OA_EXPENDTYPE"))
      {
        str = this.controls.getValueControl(getExtSystem(), "RESLEVELITEM", paramString2, paramString3);
        if ((paramString1.equals("SERVRECTRANS")) || (str.equals("1")) || (paramStructureData.isCurrentDataNull("ITEMNUM"))) {
          paramStructureData.setCurrentData("OA_EXPENDTYPE", this.controls.getValueControl(getExtSystem(), "EXPENDITEM", paramString2, paramString3));
        } else {
          paramStructureData.setCurrentData("OA_EXPENDTYPE", paramStructureData.getCurrentData("ITEMNUM"));
        }
      }
    }
  }
}
