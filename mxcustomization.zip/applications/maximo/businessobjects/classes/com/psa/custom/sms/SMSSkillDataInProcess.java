package com.psa.custom.sms;

import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.List;

import org.jdom.Element;

import psdi.iface.mic.MicConstants;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

/*
 * Author: BTE
 * 05 APR 2006 - Initial version
 */
public class SMSSkillDataInProcess extends MicSetIn {
	
	/*
	 * Variables
	 */	
	private static SMSConstant SMS = new SMSConstant();
	

	/*
	 * Author: BTE
	 * 05 APR 2006 - Constructor
	 */
	public SMSSkillDataInProcess() throws MXException, RemoteException {
		super();
	}
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Check business rules for inbound Staff Skill information 
	 */
    public int checkBusinessRules() 
    	throws MXException, RemoteException {   	
    	 
        INTEGRATIONLOGGER.debug("Entering checkBusinessRules");     
        
    	// Set Action to AddChange
    	actionInd = MicConstants.ACTIONADDUPDATE;
    	
    	// Check if ORGID is null
		if (struc.isCurrentDataNull(SMS.ORGID)) {
			throw new MXApplicationException(SMS.IFACE, SMS.LABNOORGID);
		}
		
    	// Check if IC is null    	
    	if (struc.isCurrentDataNull(SMS.IC)) {
    		throw new MXApplicationException(SMS.IFACE, SMS.LABNOIC);
		} else {    	
	    	// Search for PERSONID=LABORCODE=CALNUM in database to populate LABORCODE
			SMSPerson person =  new SMSPerson(getUserInfo());
			String personid = person.getPersonID(struc.getCurrentData(SMS.IC)); 
			
			if (personid == null) {
				throw new MXApplicationException(SMS.IFACE, SMS.PERSONTNOPERSONID);
			} else {
				struc.setCurrentData(SMS.LABORCODE, personid);
			}
		}    	
    	       	    	
    	addChangeLaborCraftRate();
    	deleteLaborCraftRate();

        INTEGRATIONLOGGER.debug("Leaving checkBusinessRules");    	
        return MicConstants.PROCESS;
    }

        
	/*
	 * Author: BTE
	 * 05 APR 2006 - Add and update LABORCRAFTRATE
	 */
    public void addChangeLaborCraftRate() throws MXException, RemoteException {
    	
        INTEGRATIONLOGGER.debug("Entering addChangeLaborCraftRate");   
        
    	List lst = struc.getChildrenData(SMS.LABORCRAFTRATE);
    	Iterator iter = lst.iterator();
    	
    	for (int i = 0; iter.hasNext(); i++ ) {    
    		iter.next();
    		
    		String myAction = getAction(i);
    		
	    	if (!myAction.equals(MicConstants.ACTIONDELETE)) {	    			
				
				String orgid = struc.getCurrentData(SMS.ORGID);
				String craftid = getCraft(i);
				String description = getDescription(i);
				String skillAcqDate = getSkillAcqDate(i);
				
				SMSCraft craft = new SMSCraft(getUserInfo());
		    	
		    	// Handle additional data CRAFT, CRAFTSKILL and CRAFTRATE
		    	if ((craftid != null) && (skillAcqDate != null)) {
					
					// Check CRAFT record
					if (craft.isCraftExist(orgid, craftid)) {
						// If CRAFT do exist; update it.
						if (!craft.updateCraft(orgid, craftid, description)) {
							throw new MXApplicationException(SMS.IFACE, SMS.CRAFT_UPDATE_ERROR);
						}
						
					} else {
						// If CRAFT don't exist; add it.
						if (!craft.addCraft(orgid, craftid, description)) {
							throw new MXApplicationException(SMS.IFACE, SMS.CRAFT_CREATE_ERROR);
						}					
					}
				}		
	    	}
    	}
    	
        INTEGRATIONLOGGER.debug("Leaving addChangeLaborCraftRate");
    }
    
    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Delete LABORCRAFTRATE
	 */
    public void deleteLaborCraftRate() throws MXException, RemoteException {    	
    	
        INTEGRATIONLOGGER.debug("Entering deleteLaborCraftRate");
        
    	// Remove delete record in database
    	List lst = struc.getChildrenData(SMS.LABORCRAFTRATE);
    	Iterator iter = lst.iterator();
    	
    	for (int i = 0; iter.hasNext(); i++ ) {    
    		iter.next();
    		
    		String myAction = getAction(i);
    		
	    	if (myAction.equalsIgnoreCase(MicConstants.ACTIONDELETE)) {
	    		
				String orgid = struc.getCurrentData(SMS.ORGID);				
				String craftid = getCraft(i);					
				String code = struc.getCurrentData(SMS.LABORCODE);
				
	    		MboSetRemote labCraftRateSet = (MboSetRemote) MXServer.getMXServer().getMboSet(SMS.LABORCRAFTRATE, getUserInfo());
	    		
	    		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	    		
	    		combinewhereclauses.addWhere("ORGID= :1");
	    		combinewhereclauses.addWhere("CRAFT= :2");
	    		combinewhereclauses.addWhere("LABORCODE= :3");
	    		String s = combinewhereclauses.getWhereClause();
	    	
	    		if(s != null && s != ""){
	    			SqlFormat sqlformat = new SqlFormat(getUserInfo(), s);
	    		
	    			sqlformat.setObject(1, SMS.LABORCRAFTRATE, SMS.ORGID, orgid);
	    			sqlformat.setObject(2, SMS.LABORCRAFTRATE, SMS.CRAFT, craftid);
	    			sqlformat.setObject(3, SMS.LABORCRAFTRATE, SMS.LABORCODE, code);  			
	    			labCraftRateSet.setWhere(sqlformat.format());   
	    			
	    			if(!labCraftRateSet.isEmpty()) {  

						labCraftRateSet.deleteAll(0L);
						
						labCraftRateSet.save();
						labCraftRateSet.commit();
						labCraftRateSet.close();
					}							
	    		}	
	    	}	
    	}    	
    	
    	// Remove delete record in SturctureData
    	List lstStruc = struc.getChildrenData(SMS.LABORCRAFTRATE);
    	Iterator iterStruc = lstStruc.iterator();
    	
    	for (int i = 0; iterStruc.hasNext(); ) {    
    		iterStruc.next();
    		
    		String myAction = getAction(i);   
	    	if (myAction.equalsIgnoreCase(MicConstants.ACTIONDELETE)) {
	    		struc.getChildrenData(SMS.LABORCRAFTRATE).remove(i);

	    		// Reset to start after delete one record in structure	    		
	    		lstStruc = struc.getChildrenData(SMS.LABORCRAFTRATE);
	    		iterStruc = lstStruc.iterator();
	    		i = 0;
	    	} else {
	    		i++;
	    	}
    	}
    	
        INTEGRATIONLOGGER.debug("Leaving deleteLaborCraftRate");
    }        
    
    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Getter for Description in structureData
	 */
    public String getDescription(int key) {
    	
        INTEGRATIONLOGGER.debug("Entering getDescription");
        
    	List lst = struc.getChildrenData(SMS.LABORCRAFTRATE);
    	Iterator iter = lst.iterator();
    	
    	for(int i = 0; iter.hasNext(); i++) {
    		Element childrenElement = (Element) iter.next();
    		
    		List attrLst = childrenElement.getChildren();
    		Iterator attrIter = attrLst.iterator();

    		while (attrIter.hasNext()) {
    			Element attr = (Element)attrIter.next();
    			String attrValue = attr.getText();
    									
    			if (attr.getName().equalsIgnoreCase(SMS.DESCRIPTION)) {
    				
    				if (key == i) {
    			        INTEGRATIONLOGGER.debug("Leaving getDescription");
    					return attrValue;
    				}
    			}    			
    		}

    	}
    	
        INTEGRATIONLOGGER.debug("Leaving getDescription");    	
		return SMS.EMPTY;
    }    
    
    
    /*
	 * Author: BTE
	 * 05 APR 2006 - Getter for action in structureData
	 */
    public String getAction(int key) {
    	
        INTEGRATIONLOGGER.debug("Entering getAction");
        
    	List lst = struc.getChildrenData(SMS.LABORCRAFTRATE);
    	Iterator iter = lst.iterator();
    	
    	for(int i = 0; iter.hasNext(); i++) {
    		Element childrenElement = (Element) iter.next();
    		
    		if (key == i) {
    			if (childrenElement.getAttribute(SMS.ACTION)!= null)
    				
    		        INTEGRATIONLOGGER.debug("Leaving getAction");
    				return childrenElement.getAttribute(SMS.ACTION).getValue();
    		}
    	}
    	
        INTEGRATIONLOGGER.debug("Leaving getAction");    	
		return SMS.EMPTY;
    }  
    
    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Getter for Craft in structureData
	 */
    public String getCraft(int key) {
    	
    	INTEGRATIONLOGGER.debug("Entering getCraft");
    	
    	List lst = struc.getChildrenData(SMS.LABORCRAFTRATE);
    	Iterator iter = lst.iterator();
    	
    	for(int i = 0; iter.hasNext(); i++) {
    		Element childrenElement = (Element) iter.next();
    		
    		List attrLst = childrenElement.getChildren();
    		Iterator attrIter = attrLst.iterator();

    		while (attrIter.hasNext()) {
    			Element attr = (Element)attrIter.next();
    			String attrValue = attr.getText();
    									
    			if (attr.getName().equalsIgnoreCase(SMS.CRAFT)) {
    				
    				if (key == i) {
    			        INTEGRATIONLOGGER.debug("Leaving getCraft");
    					return attrValue;
    				}
    			}    			
    		}
    	}
    	
        INTEGRATIONLOGGER.debug("Leaving getCraft");    	
		return SMS.EMPTY;
    }
    
    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Getter for Skilllevel in structureData
	 */
    public String getSkillLevel(int key) {
    	
    	INTEGRATIONLOGGER.debug("Entering getSkillLevel");
    	
    	List lst = struc.getChildrenData(SMS.LABORCRAFTRATE);
    	Iterator iter = lst.iterator();
    	
    	for(int i = 0; iter.hasNext(); i++) {
    		Element childrenElement = (Element) iter.next();
    		
    		List attrLst = childrenElement.getChildren();
    		Iterator attrIter = attrLst.iterator();

    		while (attrIter.hasNext()) {
    			Element attr = (Element)attrIter.next();
    			String attrValue = attr.getText();
    									
    			if (attr.getName().equalsIgnoreCase(SMS.SKILLLEVEL)) {
    				
    				if (key == i) {
    			    	INTEGRATIONLOGGER.debug("Leaving getSkillLevel");
    					return attrValue;
    				}
    			}    			
    		}
    	}
    	
    	INTEGRATIONLOGGER.debug("Leaving getSkillLevel");
		return SMS.EMPTY;
    }  
    
    
    /*
	 * Author: BTE
	 * 05 APR 2006 - Getter for SkillAcquireDate in structureData
	 */
    public String getSkillAcqDate(int key) {
    	
    	INTEGRATIONLOGGER.debug("Entering getSkillAcqDate");
    	
    	List lst = struc.getChildrenData(SMS.LABORCRAFTRATE);
    	Iterator iter = lst.iterator();
    	
    	for(int i = 0; iter.hasNext(); i++) {
    		Element childrenElement = (Element) iter.next();
    		
    		List attrLst = childrenElement.getChildren();
    		Iterator attrIter = attrLst.iterator();

    		while (attrIter.hasNext()) {
    			Element attr = (Element)attrIter.next();
    			String attrValue = attr.getText();
    									
    			if (attr.getName().equalsIgnoreCase(SMS.SKILLACQUIREDATE)) {
    				
    				if (key == i) {
    			    	INTEGRATIONLOGGER.debug("Leaving getSkillAcqDate");
    					return attrValue;
    				}
    			}    			
    		}
    	}
    	
    	INTEGRATIONLOGGER.debug("Leaving getSkillAcqDate");
		return SMS.EMPTY;
    }  
}

