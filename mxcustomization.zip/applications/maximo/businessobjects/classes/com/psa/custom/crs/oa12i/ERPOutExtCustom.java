/*     */ package com.psa.custom.oa12i;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import psdi.iface.mic.StructureData;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.util.MXApplicationException;
/*     */ import psdi.util.MXException;
/*     */ 
/*     */ public class ERPOutExtCustom
/*     */ {
/*     */   UserInfo userinfo;
/*     */   
/*     */   public ERPOutExtCustom(UserInfo userinfo)
/*     */   {
/*  27 */     this.userinfo = userinfo;
/*     */   }
/*     */   
/*     */   public void setProjTask(StructureData structuredata, MboRemote prorpo)
/*     */     throws MXException, RemoteException
/*     */   {
/*  38 */     MboRemote projecttask = getTask(prorpo);
/*  39 */     String externalrefid = projecttask.getString("externalrefid");
/*  40 */     String projectid = getProjectID(prorpo.getString("siteid"), projecttask.getString("projectid"));
/*  41 */     structuredata.setCurrentData("OA_PROJECTID", projectid);
/*  42 */     structuredata.setCurrentData("OA_TASKID", externalrefid);
/*     */   }
/*     */   
/*     */   public MboRemote getTask(MboRemote prorpo)
/*     */     throws MXException, RemoteException
/*     */   {
/*  53 */     return getTask(prorpo.getString("siteid"), prorpo.getString("fincntrlid"));
/*     */   }
/*     */   
/*     */   public MboRemote getTask(String siteid, String fincntrlid)
/*     */     throws MXException, RemoteException
/*     */   {
/*  64 */     SqlFormat sqlformat = new SqlFormat(this.userinfo, "fincntrlid=:1");
/*  65 */     sqlformat.setObject(1, "fincntrl", "fincntrlid", fincntrlid);
/*  66 */     MboSetRemote projectset = MXServer.getMXServer().getMboSet("FINCNTRL", this.userinfo);
/*  67 */     projectset.setWhere(sqlformat.format());
/*  68 */     MboRemote projecttask = projectset.moveFirst();
/*  69 */     if (projecttask == null) {
/*  70 */       throw new MXApplicationException("iface", "oa-notaskleveldata");
/*     */     }
/*  73 */     projectset.close();
/*     */     
/*  75 */     return projecttask;
/*     */   }
/*     */   
/*     */   public String getProjectID(String siteid, String projectid)
/*     */     throws MXException, RemoteException
/*     */   {
/*  87 */     SqlFormat sqlformat = new SqlFormat(this.userinfo, "projectid=:1 AND taskid IS NULL");
/*  88 */     sqlformat.setObject(1, "fincntrl", "projectid", projectid);
/*  89 */     MboSetRemote projectset = MXServer.getMXServer().getMboSet("FINCNTRL", this.userinfo);
/*  90 */     projectset.setWhere(sqlformat.format());
/*  91 */     MboRemote project = projectset.moveFirst();
/*  92 */     if (project == null) {
/*  93 */       throw new MXApplicationException("iface", "oa-noprojectleveldata");
/*     */     }
/*  96 */     projectset.close();
/*     */     
/*  98 */     return project.getString("externalrefid");
/*     */   }
/*     */   
/*     */   public MboRemote getWorkTypeMbo(String worktype, String orgid)
/*     */     throws MXException, RemoteException
/*     */   {
/* 110 */     MboSetRemote worktypeset = MXServer.getMXServer().getMboSet("WORKTYPE", this.userinfo);
/* 111 */     SqlFormat sqlformat = new SqlFormat(this.userinfo, "worktype=:1 AND orgid=:2 AND woclass='WORKORDER'");
/* 112 */     sqlformat.setObject(1, "worktype", "worktype", worktype);
/* 113 */     sqlformat.setObject(2, "worktype", "orgid", orgid);
/* 114 */     worktypeset.setWhere(sqlformat.format());
/* 115 */     return worktypeset.getMbo(0);
/*     */   }
/*     */   
/*     */   public void setOAAssetNum(StructureData structuredata, MboRemote prorpo)
/*     */     throws MXException, RemoteException
/*     */   {
/* 125 */     String oaassetnum = null;
/* 129 */     if ((prorpo.getString("ASSETNUM") != "") && (prorpo.getString("location") == ""))
/*     */     {
/* 131 */       MboSetRemote mbosetremote = prorpo.getMboSet("ASSET");
/* 132 */       MboRemote mboremote = mbosetremote.getMbo(0);
/* 133 */       oaassetnum = mboremote.getString("OAASSETNUM");
/*     */     }
/* 135 */     else if ((prorpo.getString("ASSETNUM") != "") && (prorpo.getString("location") != ""))
/*     */     {
/* 137 */       MboSetRemote mbosetremote = prorpo.getMboSet("LOCATION");
/* 138 */       MboRemote mboremote = mbosetremote.getMbo(0);
/* 139 */       if ((!mboremote.isNull("OAASSETNUM")) || (mboremote.getString("OAASSETNUM").trim().length() != 0))
/*     */       {
/* 140 */         oaassetnum = mboremote.getString("OAASSETNUM");
/*     */       }
/*     */       else
/*     */       {
/* 143 */         MboSetRemote mbosetremote_asset = prorpo.getMboSet("ASSET");
/* 144 */         MboRemote mboremote_asset = mbosetremote_asset.getMbo(0);
/* 145 */         oaassetnum = mboremote_asset.getString("OAASSETNUM");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 150 */       MboSetRemote mbosetremote = prorpo.getMboSet("LOCATION");
/* 151 */       MboRemote mboremote = mbosetremote.getMbo(0);
/* 152 */       oaassetnum = mboremote.getString("OAASSETNUM");
/*     */     }
/* 154 */     structuredata.setCurrentData("OAASSETNUM", oaassetnum);
/*     */   }
/*     */ }


/* Location:           D:\PSA_MX7.1\applications\maximo\businessobjects\classes\
 * Qualified Name:     com.psa.custom.oa12i.ERPOutExtCustom
 * JD-Core Version:    0.7.0.1
 */