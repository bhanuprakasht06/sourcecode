/*
 * Modification history
 *
 * 28-10-2011   YCH Creation This class is cron task to process received ED-OT records after parsing flat file from Resource System
 * 20-02-2013   WMJ     EMS-553 [EDOT][Crontask]Fix issue in EDOTReconCronTask where PSA_PROCESSDATE is updated wrongly
 * 27-02-2014   WMJ     EMS-773 [EDOT]Gzip and gunzip EDOT files sent between Maximo and EDOT
 *
 */

package com.psa.custom.edot;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Vector;

import com.psa.app.labor.LabTransCustomRemote;
import psdi.app.labor.LabTransSetRemote;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import com.psa.custom.common.MxImportFile;
import com.psa.custom.ois.MxLog;
import psdi.iface.mic.MicUtil;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxSCP;
import com.psa.custom.common.MxZip;

public class EDOTReconGzipCronTask extends SimpleCronTask
{
        private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
   		private static final String NEWLINE = "\n\r";
        private static final String SPACE = " ";
	    private static final String dotdot = ":";

        private static CrontaskParamInfo params[];
        protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");

        protected String otArchiveFilePath; //Filename and Full Path for OT Transaction Archive File

        private String qualifiedInstanceName;

        private String processDirectory;     //Directory to retrieve the file from
        private String importFileName;       //Import Base File Name
        private String logDir;               //Directory where log file will be placed
        private boolean enableLog;           //Enable log
        
        protected String scpConfigFile;     //SCP - Configuration File
	    protected String remoteFilePath;    //Path where import file is
    	protected String remoteServer;              //Remote server tor retreive the flatfile
  	    protected String impFileExt;                //Import File Extension

   	    protected String unzipExec;                 //Executable/Command for unzip function

        private File loadDir;
        protected MxLog mxLog;
        private MxImportFile mxFile;

        private boolean isProcErr;
        private StringBuffer errMessage;

        protected boolean initialized;

        /*
         * Author: YCH
         * 28 Oct 2011 - Cron task constructor initialize default value
         */
        public EDOTReconGzipCronTask()
        {
                super();

                initialized = false;

                qualifiedInstanceName = null;
                loadDir = null;
                processDirectory = null;
                importFileName = null;
                logDir = null;
                enableLog = false;

                errMessage = null;
                isProcErr = false;
                
                unzipExec=null;
                
		        scpConfigFile=null;
		        remoteFilePath=null;
		        remoteServer=null;
		        impFileExt=null;
                
        }

        /*
         * Author: YCH
         * Date: 28 Oct 2011
         * Comment: [Standard Cron Task Function]Initialize cron task
         */
        public void init()
                throws MXException
        {
                super.init();

                mxLog = new MxLog();
                initialized = true;

                mxFile = new MxImportFile();
        }

        /*
         * Author: YCH
         * 28 Oct 2011 - Get the parameter value setting from maximo in configuration
         */
        private void refreshSettings()
        {
                integrationLogger.debug("Entering refreshSettings");

                try {
                        processDirectory = getParamAsString("DIRECTORY");
                        loadDir = new File(processDirectory);

                        //Replace filename by today's date if "yyyymmdd" is specified in import file base name
                        DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
                        String todayDate = fileDateFormat.format(new Date());
                        importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmdd", todayDate);

                        Date curDate = new Date();
                        Date fileDate = new Date(curDate.getTime());
                        String fileDateStr = fileDateFormat.format(fileDate);

                        otArchiveFilePath = getParamAsString("OTARCHIVEFILEPATH").replaceAll("yyyymmdd", fileDateStr);

                        //Log
                        logDir = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd", todayDate);
                        enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
                        mxLog.setEnabled(enableLog);
                        mxLog.setLogFilePath(logDir);
                        mxLog.setLogTag(getName());
                        mxLog.createLogFile();
                        
                        //Paramaters for SCP
		             	scpConfigFile = getParamAsString("SCPCONFIGFILE");
		             	remoteFilePath = getParamAsString("REMOTEFILEPATH");
		             	remoteServer = getParamAsString("REMOTESERVER");
		             	impFileExt = getParamAsString("IMPFILEEXT");
		             	
		             	//Paramater for Unzip
		             	unzipExec = getParamAsString("UNZIPEXEC");

                        integrationLogger.debug("Leaving refreshSettings");
                }
                catch (Exception exception)
                {
                        if (integrationLogger.isErrorEnabled())
                                integrationLogger.error(exception.getMessage(), exception);
                }
        }

        /*
         * Author: YCH
         * Date: 28 Oct 2011
         * Comment: [Standard Cron Task Function] Start cron task
         */
        public void start()
        {
                try {
                        refreshSettings();

                        MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Start - " + qualifiedInstanceName + " started");
                        setSleepTime(0L);
                }
                catch (Exception exception) {
                        if (integrationLogger.isErrorEnabled())
                                integrationLogger.error(exception.getMessage(), exception);
                }
        }

        /*
         * Author: YCH
         * Date: 28 Oct 2011
         * Comment: [Standard Cron Task Function]Stop cron task
         */
        public void stop()
        {
                try {
                        mxLog.closeLogFile();
                } catch (Exception exception) {
                        if (integrationLogger.isErrorEnabled())
                                integrationLogger.error(exception.getMessage(), exception);
                }
                mxLog.writeLog("[" + getName() + "] Stop - " + qualifiedInstanceName + " stopped");
                MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Stop - " +
                        qualifiedInstanceName + " stopped");
        }

        /* Author: YCH
     * Date: 28 Oct 2011
     * Comment: [Standard Cron Task Function] Set cron task instance
     */

    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {

        try {
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") +
                "." + crontaskinstanceremote.getString("instancename");
        }
        catch(Exception exception) {
            integrationLogger.error(exception.getMessage(), exception);
        }
    }

    /*
     * Author: YCH
     * Date: 31 Oct 2011
     * Comment: returns true if all required parameter is set
     */
    private boolean isReqParamSet()
    {
        if (importFileName == null)
                return false;
        if (processDirectory == null)
                return false;
        if (unzipExec == null)
                return false;
		if (impFileExt == null)
                return false;                
                
        return true;
    }

    /* Author: YCH
     * Date: 31 Oct 2011
     * Comment: Generate Formated Error Msg
     */
        private String genErrMsg(Exception e, Vector vec){

        String errMsg = "Line:"+vec.toString() + "\n";
        errMsg += "Error Message: "+ e.getMessage() + "\n";
        errMsg += "Detail:" + "\n";
        errMsg += e.toString() + "\n";
        StackTraceElement element[] = e.getStackTrace();
        for(int i = 0; i< element.length; i++){
                errMsg += "\tat "+ element[i].toString() + "\n";
        }

        return errMsg;
        }

        /*
         * Author: YCH
         * 31 Oct 2011 - Get the parameter from Cron Task.
         */
        public CrontaskParamInfo[] getParameters() throws MXException, RemoteException
        {
                return params;
        }

        /*
         * Author: YCH
         * Date: 31 Oct 2011
         * Comment: [Standard Cron Task Function]
         * Cron task function - Retrieve flat file from remote server,
         * process flat file, update the corresponding mbo object according to the content
         */
        public void cronAction()
        {
                integrationLogger.debug("Entering cronAction");
                mxLog.writeLog(" cronAction(): Start CronTask Action");

                try {

                        if (!initialized) {
                                mxLog.writeLog(" cronAction(): CronTask not initialized!");
                                throw new Exception(getName() + ".cronAction(): CronTask not initialized!");
                        }

                        // Refresh setting before perform cron action
                        refreshSettings();
                        
                        if (isReqParamSet()) {
                        
                        //Start of main part of EMS-773
                        
                        //Modify check if the file is already in backup folder
                        File checkBackupFile = new File(otArchiveFilePath+importFileName+impFileExt);
                        if(checkBackupFile.exists()){
                                mxLog.writeLog(getName()+".cronAction(): File is already in backup folder.");
                                mxLog.writeLog(getName()+".cronAction(): Stopping Crontask...");
                                return;
                        }
                        
                        //Check if file is in process directory. If not do a SCP pull
                        File dataFile = new File(processDirectory+importFileName+impFileExt);
                        
                        if (!dataFile.exists()) 
                        {
	                        //////////////////////
                            // Get File Using SCP
                            //////////////////////
 
                            mxLog.writeLog(getName()+".cronAction(): Starting SCP, getting "+importFileName+impFileExt+" from "+ remoteServer +"..." );        
 
                            // Get file from remote Server
                            MxSCP scp = new MxSCP();
 
                            String scpParam = scpConfigFile + SPACE + 
                                    remoteServer + dotdot +  remoteFilePath + importFileName + impFileExt + SPACE + processDirectory + importFileName + impFileExt;
                                    
							mxLog.writeLog(getName()+".cronAction(): SCP command executed: <"+ scpParam +">" );                                            
 
                            if (scp.getFlatFile(scpParam) != 0) {
                            throw new Exception("Cannot get remote file - "+remoteServer + dotdot +  remoteFilePath + importFileName + impFileExt + ".");
                            }
 
                            if (!dataFile.exists()) {
                                    throw new Exception("Remote file transfer not succesful. File '"+dataFile.toString()+"' cannot be found.");
                            }
 
                            mxLog.writeLog(getName()+".cronAction(): Finished SCP...");
	                        
                        }
                        
                        //Do a backup of the file to the archive folder
                        depositFile();
                        
                        //Do a gunzip of the file
                        String cmd = unzipExec + SPACE + processDirectory + dataFile.getName();
                        mxLog.writeLog(getName()+".processFolderData(): Unzip using cmd: " + cmd);
                        if ( MxZip.unzipFile(cmd)== 0 )
                        {

	                        String file = processDirectory + dataFile.getName();
	                        //String file = afile[j].toString();
	                        // Remove extension
	                        file=file.substring(0,file.length()-impFileExt.length());
	
	                        File unzippedFile = new File(file);
	                        if(!unzippedFile.exists()){
	                                mxLog.writeLog(getName()+".processFolderData(): Unable to find unzipped file - "+file+".");
	                                throw new Exception(getName()+".processFolderData(): Unable to find unzipped file- "+file+".");
                        }

                        //Process the import flat file
                        processData(unzippedFile);

                        //Delete unziped file
                        unzippedFile.delete();

                        }
                        else{
                                mxLog.writeLog(getName()+".processData(): Unable to unzip file - " + dataFile.getName());
                                throw new Exception(getName()+".processData(): Unable to unzip file - " + dataFile.getName());
                        }
                        
                        //End of main part of EMS-773
                        
/*
                        // Set parameter after refreshSetting
                        mxFile.setFileType(importFileName);
                        errMessage = new StringBuffer();


                                // Check file is in local drive?
                                if (checkFileExist()) {
                                        // Process the import flat file
                                        processData();

                                        //Copy Files to Archive Directory
                                        //depositFile();
                                } else {
                                        mxLog.writeLog("[" + getName() + "]Unable to find input file.");
                                        throw new Exception("[" + getName() + "]Unable to find input file.");
                                }
*/
                        } else {
                                mxLog.writeLog(" cronAction(): Required parameters not set.");
                                throw new Exception("Required parameters are not set.");
                        }

                } catch (Exception e) {
                        MicUtil.INTEGRATIONLOGGER.error("[" + getName() + "] " + e.getMessage(), e);

                        stop();
                }

                integrationLogger.debug("Leaving cronAction");
                mxLog.writeLog(" cronAction(): End CronTask Action");

        }

        /* Author: YCH
         * Date: 31 Oct 2011
         * Comment: Check file exist in local directory
         */
        public boolean checkFileExist () {

                integrationLogger.debug("EDOTReconCronTask: checkFileExist");

                File afile[] = loadDir.listFiles();

                if(afile != null) {
                        int i = afile.length;
                        for(int j = 0; j < i; j++) {

                                if(mxFile.findFileType(afile[j])) {
                                        return true;
                                }
                        }
                }

                return false;
        }

         /* Author: YCH
     * Date: 31 Oct 2011
     * Comment: Process the import flat file
     */
    public void processData(File dataFile) throws Exception {

                integrationLogger.debug("EDOTReconCronTask: Entering processFileData");
                mxLog.writeLog(" processData(): Start Processing Data");
                try {
	                
                    	errMessage = new StringBuffer();
                        isProcErr = false;   	
	                
		                // Parse EDOT flat file
	                	Collection col = parseFlatFile(dataFile.getName());
	                	
	                	// Process parsed flat file to update Labor Transactions.
                        updateDB(col);
                        
                        if (isProcErr) 
                        {
                        	String errMsg = "Date: " + new Date() + "\n";
                            errMsg += "Error in CronTask: "+getName() + "\n";
                            errMsg += "File Processing: "+ dataFile.getName() + NEWLINE;
                            errMsg += errMessage.toString();

                            mxLog.writeLog("Error Message:\n" + errMsg);
                        }
	                
/*	                	
	                	 File afile[] = loadDir.listFiles();

                        if(afile != null) {
                                int i = afile.length;

                                for(int j = 0; j < i; j++) {

                                        errMessage = new StringBuffer();
                                        isProcErr = false;
                                        if(mxFile.findFileType(afile[j])) {
                                //debug.msg("Start reading flat file.");
                                                integrationLogger.debug("EDOTReconCronTask: Processing file '" + afile[j].getName() + "'");

                                try {
                                        // Parse EDOT flat file
                                String file = afile[j].toString();
                                Collection col = parseFlatFile(file);

                                // Process parsed flat file to update Labor Transactions.
                                updateDB(col);

                                } catch(Exception e){
                                        MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
                                }
                        }

                                        if (isProcErr) {

                                String errMsg = "Date: " + new Date() + "\n";
                                errMsg += "Error in CronTask: "+getName() + "\n";
                                errMsg += "File Processing: "+ afile[j].getName() + NEWLINE;
                                errMsg += errMessage.toString();

                            mxLog.writeLog("Error Message:\n" + errMsg);
                                }
                    }
                }
                        else{
                                mxLog.writeLog(" processData(): Unable to read input file '" + importFileName + "'");
                                throw new Exception("[" + getName() + "] Unable to read input file '" + importFileName + "'");
                        }
*/                        
                }
        catch(Exception e)
        {
            MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);

            stop();
        }

        integrationLogger.debug("EDOTReconCronTask: Leaving processFileData");
        mxLog.writeLog(" processData(): Leaving Processing Data");
        }

    /*
     * Author: YCH
     * Date: 31 Oct 2011
     * Comment: Parse EDOT flat file.
     */
    private Collection parseFlatFile(String file) throws Exception {

        integrationLogger.debug("Entering parseFlatFile");
        mxLog.writeLog(" parseFlatFile(): Start Parse Flat File");

        // Parse the EDOT flat file first
        // Reading the import flat file
        BufferedReader flatfileReader;
        Collection col = new Vector();

                flatfileReader = new BufferedReader(new FileReader(file));

        // Ignore first line of text as its the file header
        //String curLine = flatfileReader.readLine();
        String curLine;
        int length = 129;
        int[] fieldFrom = {0, 12, 24, 29};
        int[] fieldTo = {12, 24, 29, 129};

        while((curLine = flatfileReader.readLine()) != null)
        {

                if (curLine.length() != length) {
                        mxLog.writeLog("[" + getName() + "][Warning] The string message length is ["
                                                                + curLine.length() + "], it's different with the definition length ["
                                                                + length + "]");
                }

                //mxLog.writeLog("[" + getName() + "] curLine:'" + curLine+ "'");

                Vector vec = new Vector();
                for (int i = 0; i < 4; i++)
                {
                        if (fieldFrom[i] > curLine.length())
                        {
                                isProcErr = true;
                    String errMsg = NEWLINE + "Line:" + curLine + NEWLINE;
                    errMsg += "Error Message: The field's start|end index is larger than message's total length: FieldFrom:["
                                                + fieldFrom[i]  + "] FieldTo:[" + fieldTo[i] + "]" + NEWLINE;
                                errMessage.append(errMsg);
                        mxLog.writeLog("[" + getName() + "][ERROR] Invalid line:'" + curLine+ "'");
                        break;
                        }

                        if (fieldTo[i] > curLine.length())
                        {
                                fieldTo[i] = curLine.length();
                        }

                        String fieldValue = curLine.substring(fieldFrom[i], fieldTo[i]);
                        //mxLog.writeLog("[" + getName() + "] fieldValue:'" + fieldValue+ "'");
                        vec.add(fieldValue.trim());
                }

            // Add to a collection
            col.add(vec);
        }

        integrationLogger.debug("parseFlatFile - Valid lines parsed: "+col.size());
        integrationLogger.debug("Leaving parseFlatFile");
        mxLog.writeLog(" parseFlatFile(): Valid lines parsed: "+col.size());
        mxLog.writeLog(" parseFlatFile(): Finish Parse Flat File");
        return col;
    }

    /*
     * Author: YCH
     * Date: 31 Oct 2011
     * Comment: Process parsed flat file to update Lab Transactions for OT records
     */
    private void updateDB(Collection col) throws Exception
    {
        integrationLogger.debug("EDOTReconCronTask: Starting processFlatFile");

        Iterator iterParsedData = col.iterator();

        while (iterParsedData.hasNext()) {

                //Vector Element
                //0. Maximo OT ID
                //1. Process Date
                //2. Status (Done/Error)
                //3. Message

                // Get new record to update into Lab Transactions
                Vector vec = (Vector) iterParsedData.next();
                try {
                        integrationLogger.debug("Line: " + vec.toString());

                        String maximoOTID = (String) vec.elementAt(0);
                        //mxLog.writeLog("[" + getName() + "] maximoOTID:'" + maximoOTID+ "'");
                        integrationLogger.debug("Process Maximo OT ID: " + maximoOTID);

                        Date processDate = convertDate((String) vec.elementAt(1));
                        //mxLog.writeLog("[" + getName() + "] processDate:'" + processDate+ "'");
                        integrationLogger.debug("Process Date: " + processDate);

                        String status = (String) vec.elementAt(2);
                        //mxLog.writeLog("[" + getName() + "] status:'" + status+ "'");
                        integrationLogger.debug("Process Status: " + status);

                        String message = (String) vec.elementAt(3);
                        //mxLog.writeLog("[" + getName() + "] message:'" + message+ "'");
                        integrationLogger.debug("Process Message: " + message);

                        //Check for existing OT record by specific maximo OT ID
                        LabTransSetRemote labTransSet = (LabTransSetRemote) MXServer.getMXServer().getMboSet("LABTRANS", getRunasUserInfo());
                        String sql = "LABTRANSID = :1";

                        SqlFormat sqlformat = new SqlFormat(getRunasUserInfo(), sql);
                        sqlformat.setObject(1, "LABTRANS", "LABTRANSID", maximoOTID);

                        labTransSet.setWhere(sqlformat.format());

                        if (labTransSet.isEmpty())
                        {
                                integrationLogger.debug("Can not find the existed record based on parsed OT ID: " + maximoOTID);
                        } else {
                                integrationLogger.debug("Updated Lab Transaction Start with Lab Transaction ID: " + maximoOTID);
                                LabTransCustomRemote labTransMbo = (LabTransCustomRemote) labTransSet.getMbo(0);
                                labTransMbo.setValue("PSA_PROCESSDATE", processDate, 2L);
                                labTransMbo.setValue("PSA_IFACESTATUS", status, 2L);
                                labTransMbo.setValue("PSA_IFACEMESSAGE", message, 2L);
                                labTransSet.save();
                                integrationLogger.debug("Updated Lab Transaction Finish");
                        }
                }
                catch(Exception e) {
                        isProcErr = true;
                        String errMsg = genErrMsg(e, vec);
                                errMessage.append(errMsg);
                                errMessage.append(NEWLINE);
                                mxLog.writeLog(" processFlatFile():[ERROR]" + errMsg);
            }
        }

        // Clear collection
        col.clear();
        integrationLogger.debug("Leaving processFlatFile");
        mxLog.writeLog(" processFlatFile(): Finish Update Lab Transaction.");
    }

    /* Author: YCH
     * 31 Oct 2011 - Convert Date
     */
    private Date convertDate(String inDate) throws Exception
    {
        //Start of EMS-553
            //SimpleDateFormat dateformat = new SimpleDateFormat("ddmmyyyy");
            SimpleDateFormat dateformat = new SimpleDateFormat("ddMMyyyy");
            //End of EMS-553
        Date outDate = null;
        outDate = dateformat.parse(inDate);

        return outDate;
    }

        /**
         * @author YCH
         * @function depositFile
         * @date Oct 27, 2011
         * @comment Copy and Zip Flat Files to Output and Archive Directory modification,
         * Do not throw exception when the transaction has been processed
         * @throws Exception
         */
        private void depositFile() throws Exception
        {
                try
                {
                        mxLog.writeLog(getName() + ".depositFile():[Info]Start depositing output file");

                        File oldfile = new File(processDirectory + importFileName) ;

                        oldfile.renameTo(new File(otArchiveFilePath + importFileName));
                        //MxFileCopy.fileCopy(directory + importFileName, otArchiveFilePath + importFileName);

                        mxLog.writeLog(getName() + ".depositFile():[Info]Finish depositing output file");
                }catch(Exception e)
                {
                        e.printStackTrace();
                }
        }

    /* Author: YCH
     * Date: 31 Oct 2011
     * Comment: Define Maximo parameter setting in Cron Task
     */
    static
    {
        // YCH: Set the number of the parameter.
        params = null;
        params = new CrontaskParamInfo[10];

        // YCH: All the parameter configurable from Cron Task

        params[0] = new CrontaskParamInfo();
        params[0].setName("DIRECTORY");
        params[0].setDescription("CommonCron","Local directory where flat file will be read.");
		params[0].setDefault("/opt/psa/data/rw/emsscp/incoming/edot/");

        params[1] = new CrontaskParamInfo();
        params[1].setName("IMPORTFILENAME");
        params[1].setDescription("CommonCron","File name of the input file(Includes with 'yyyymmdd*' for current day file)");
        params[1].setDefault("EDOTError_yyyymmdd");

        params[2] = new CrontaskParamInfo();
        params[2].setName("ENABLELOG");
        params[2].setDescription("CommonCron","Enable log output('Y' or 'N').");
        params[2].setDefault("Y");

        params[3] = new CrontaskParamInfo();
        params[3].setName("LOGFILEPATH");
        params[3].setDescription("CommonCron","Log Directory and Filename.");
        params[3].setDefault("/opt/psa/data/maximo/log/edot/EDOTRecon_yyyymmdd.log");

        params[4] = new CrontaskParamInfo();
        params[4].setName("OTARCHIVEFILEPATH");
        params[4].setDescription("CommonCron","OT Transaction Archive path and filename (Add 'yyyymmdd' to add date to filename)");
        params[4].setDefault("/opt/psa/data/rw/emsscp/incoming/edot/archive/");

        params[5] = new CrontaskParamInfo();
        params[5].setName("REMOTESERVER");
        params[5].setDescription("CommonCron","Username@RemoteServer to SCP pull from");
        params[5].setDefault("edotscp@ROSTER1be1");
        
        params[6] = new CrontaskParamInfo();
        params[6].setName("UNZIPEXEC");
        params[6].setDescription("CommonCron","Executable for unziping the input flat file.");
        params[6].setDefault("gunzip -f -q");

        params[7] = new CrontaskParamInfo();
        params[7].setName("SCPCONFIGFILE");
        params[7].setDescription("CommonCron","SCP Config File");
        params[7].setDefault("/opt/psa/rel/config/emsadm/scp.sh");

        params[8] = new CrontaskParamInfo();
        params[8].setName("IMPFILEEXT");
        params[8].setDescription("CommonCron","Extension of the input flat file package.");
        params[8].setDefault(".gz");
        
        params[9] = new CrontaskParamInfo();
        params[9].setName("REMOTEFILEPATH");
        params[9].setDescription("CommonCron","Remote Path of the input flat file.");
        params[9].setDefault("/opt/psa/rel/be/rms/ctrs/rosterfile/edot/error/");
        
    }
}

