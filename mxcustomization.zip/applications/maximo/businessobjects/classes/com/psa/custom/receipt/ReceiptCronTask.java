/**
 * @author	HCHA
 * Date		Aug 22, 2006
 * Comment	 
 */
package com.psa.custom.receipt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Vector;

import com.psa.custom.common.MxDatabase;
import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;
import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

/**
 * @author		HCHA
 * @class		ReceiptCronTask
 * @date		Aug 22, 2006
 * @function	
 */
public class ReceiptCronTask extends SimpleCronTask {

	
	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
    private static final String SPACE = " ";
    private static final String NEWLINE = "\n\r";
    private static final int NO_OF_FIELDS = 11;
    
    /*
     * 02-OCT-2020
     * BCT Modification Starts: GL account modification
     * 
     */
    
    private static final String GLACCOUNT = "???-????-1-??-???-????-????-003";
  /*  private static final String BT_CONTROLACC = "101-0091-0-00-000-0000-0007-000";
    private static final String KT_CONTROLACC = "101-0091-0-00-000-0000-0008-000";
    private static final String PPT1_CONTROLACC = "101-0091-0-00-000-0000-0010-000";
    private static final String PPT2_CONTROLACC ="101-0091-0-00-000-0000-0181-000";
    private static final String TPT_CONTROLACC = "101-0091-0-00-000-0000-0009-000";*/
    

    private static final String BT_CONTROLACC = "101-1510101-110-0000-000-0000-0000";
    private static final String KT_CONTROLACC = "101-1510102-110-0000-000-0000-0000";
    private static final String PPT1_CONTROLACC = "101-1510104-110-0000-000-0000-0000";
    private static final String PPT2_CONTROLACC ="101-1510105-110-0000-000-0000-0000";
    private static final String TPT_CONTROLACC = "101-1510103-110-0000-000-0000-0000";
    
    /*
     * 02-OCT-2020
     * BCT Modification Ends: GL account modification
     * 
     */
    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");    
    

    private String qualifiedInstanceName;
    private RecoveryService recoveryService;
    
    private String directory;			//Directory to retrieve the file from
    private String delimiter;			//Delimiter of input flat file
    protected String adminEmail;		//Adminstrator Email
    protected String emailSubj;			//Alert Email Subject
    private String importFileName;		//Import Base File Name
    private String logDir;				//Directory where log file will be placed
    private boolean enableLog;			//Enable Log
    private String unzipExec;			//Executable/Command for unzip function
    private String processDirectory;	//Directory where processing are done

    private File loadDir;
    protected MxLog mxLog;
    private MxEmail email;
    
    private boolean isProcErr;
    private StringBuffer errMessage;
    
    protected boolean initialized;
    
    /* 
     * Author: HCHA
     * 28 JUN 2006 - Cron task constructor initialize default value  
     */	
	public ReceiptCronTask() 
	{
		super();
		
		initialized = false;
		
	    recoveryService = null;    	

	    qualifiedInstanceName = null;
	 
        loadDir = null;
        directory = null;
        delimiter = null;        
        adminEmail = null;
        emailSubj = null;
        importFileName = null;   
        logDir = null;
        enableLog=false;
        unzipExec = null;
        processDirectory = null;
        
		errMessage = null;
		isProcErr = false;
		
	}
	
	/* Author: HCHA
     * Date: 29 Jun 2006
     * Comment: [Standard Cron Task Function]Initialize cron task  
     */
    public void init() 
    	throws MXException
    {
    	super.init();
    	
        email = new MxEmail(adminEmail);        
        mxLog = new MxLog();
        initialized = true;
    }
    
	/* 
	 * Author: HCHA
     * 29 Jun 2006 - Get the parameter value setting from maximo User Interface in configuration    
     */
    private void refreshSettings()
    {
    	
    	integrationLogger.debug("Entering refreshSettings");
    	
        try {
            
        	delimiter = getParamAsString("SPLITTAG");        	
            directory = getParamAsString("DIRECTORY");
            loadDir = new File(directory);            
    		recoveryService = new RecoveryService(loadDir); 
            
            adminEmail = getParamAsString("ALERTEMAIL");
            email.setAdmin(adminEmail);
            emailSubj = getParamAsString("ALERTEMAILSUBJ");
            
            //Replace filename by today's date if "yyyymmdd" is specified in import file base name
            DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
            String todayDate=fileDateFormat.format(new Date());
            importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmdd",todayDate);            
                                  
            //Replace with by previous day's if "yyyymmpd" is specified in import file base name            	
    		Calendar cal = Calendar.getInstance();
    		cal.add(Calendar.DAY_OF_MONTH,-1);            					
    		String prevDate = fileDateFormat.format(cal.getTime());
    		importFileName=importFileName.replaceAll("yyyymmpd",prevDate);
            
            //Paramater for Unzip
            unzipExec = getParamAsString("UNZIPEXEC");  
            
            //Directory where processing are done
            processDirectory= getParamAsString("PROCESSDIRECTORY");
    		
            //Log
            logDir = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd",todayDate); 
            logDir = logDir.replaceAll("yyyymmpd",prevDate);
            enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y")==0); 
            mxLog.setEnabled(enableLog);
            mxLog.setLogFilePath(logDir);
            mxLog.setLogTag(getName());
            mxLog.createLogFile();
            
            integrationLogger.debug("Leaving refreshSettings");
                        
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }
    
    /* Author: BTE
     * Date: 29 Jun 2006
     * Comment: [Standard Cron Task Function] Start cron task   
     */

    public void start() {
    	
        try {
            refreshSettings();
            
            MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Start - " + qualifiedInstanceName );
            setSleepTime(0L);
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }
    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function]Stop cron task  
     */

    public void stop() 
    {
    	
    	try{
    		mxLog.closeLogFile();
    	}
    	catch(Exception exception){
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
    	}
    			
    	MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Stop - " + 
        		qualifiedInstanceName );
    }
    
    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function] Set cron task instance  
     */
    
    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {
    	
        try {
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") + 
            	"." + crontaskinstanceremote.getString("instancename");
        }
        catch(Exception exception) {
            integrationLogger.error(exception.getMessage(), exception);
        }
    }
    
    /* Author: HCHA
     * Date: 29 Jun 2006
     * Comment: returns true if all required parameter is set
     */
 
    private boolean isReqParamSet()
    {
        
        if(adminEmail==null) return false;
        if(importFileName==null) return false;
        if(directory==null) return false;  
        if(processDirectory==null) return false;
        
    	return true;
    }
    
	/* Author: HCHA
     * Date: 16 MAR 2006
     * Comment: Generate Email   
     */
	
	private String genEmail(Exception e){
		
        //Form Email Message
        String emailMsg = "Date: " + new Date()+"\n";
        emailMsg += "Error in CronTask: "+getName()+ "\n";
        emailMsg+="Error Message: "+ e.getMessage()+"\n";
        emailMsg+="Detail:\n";
        emailMsg+=e.toString()+"\n"; 
        StackTraceElement element[] = e.getStackTrace();
        for(int i=0; i< element.length; i++){
        	emailMsg+="\tat "+ element[i].toString()+"\n";	
        }
        
        return emailMsg;
	}

	/* Author: HCHA
     * Date: 30 JUN 2006
     * Comment: Generate Formated Error Msg   
     */
	
	private String genErrMsg(Exception e, Vector vec){
        
        String errMsg = "Line:"+vec.toString()+ "\n";
        errMsg+="Error Message: "+ e.getMessage()+"\n";
        errMsg+="Detail:"+"\n";
        errMsg+=e.toString()+"\n"; 
        StackTraceElement element[] = e.getStackTrace();
        for(int i=0; i< element.length; i++){
        	errMsg+="\tat "+ element[i].toString()+"\n";	
        }
        
        return errMsg;
	}
	
	/* 
	 * Author: BTE
     * 29 JUN 2006 - Get the parameter from Cron Task.  
     */
    public CrontaskParamInfo[] getParameters() throws MXException, RemoteException {
	    return params;
	}

    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function]
     * Cron task function - Retrieve flat file from remote server,
     * process flat file, convert to xml format and import to maximo.  
     */
	public void cronAction() 
	{
    	
		integrationLogger.debug("Entering cronAction");
		mxLog.writeLog(" cronAction(): Start CronTask Action");
		
        try {
        	
            if(!initialized){
            	mxLog.writeLog(" cronAction(): CronTask not initialized!");
                throw new Exception(getName()+".cronAction(): CronTask not initialized!");
            }

        	// Refresh setting before perform cron action
            refreshSettings();
   
        	if (isReqParamSet()) {
        		processFolderData();
        	} 
        	else { 
        		mxLog.writeLog(" cronAction(): Required parameters not set.");
        		throw new Exception("Required parameters not set.");        	
        	}

        }
        catch(Exception e) {
        	
            MicUtil.INTEGRATIONLOGGER.error("["+getName()+"] "+e.getMessage(), e);                   
            
            String emailContent = genEmail(e);
            email.send(emailSubj,emailContent );
          	mxLog.writeLog("Email Sent:\n"+emailContent); 
            
            stop();
        }
        
        integrationLogger.debug("Leaving cronAction");
        mxLog.writeLog(" cronAction(): End CronTask Action");
        
	} 
    
    /* Author: HCHA
     * 29 JUN 2006 - Process the import flat file   
     */
    public void processFolderData() throws Exception {
   
    	integrationLogger.debug("Entering processFolderData");
    	mxLog.writeLog(" processFolderData(): Start Processing Data");
	
		SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
		  		
		File afile[] = loadDir.listFiles(filter);
    
		if(afile != null && afile.length!=0) {
				    		
			int fileprocessed = 0;
				
			for(int j = 0; j < afile.length; j++) 
			{
				            		
           		integrationLogger.info("["+getName()+"] Processing '" + afile[j].getName() + "'" );
           		mxLog.writeLog(" processFolderData(): Processing '" + afile[j].getName() + "'");
    		
              	recoveryService.startRecovery();
              	
                errMessage = new StringBuffer();
                isProcErr = false;
                                		
               	try {	
               		
               		//Copy file to process directory
                   	String file = processDirectory + afile[j].getName();
                   	MxFileCopy.fileCopy(afile[j].toString(), processDirectory + afile[j].getName());
	                    	
                   	//Unzip File
                   	String cmd = unzipExec + SPACE + file;
                   	if ( MxZip.unzipFile(cmd)== 0 )
        	    	{
	                    	
                   		//Get filename without extension
                   		int dotPos = file.lastIndexOf(".");
                   		String extractedFile = file.substring(0,dotPos);
	                    	
                   		Collection col = parseFlatFile(extractedFile);
		                        	      
    	                // Update Database
    	                updateDB(col);
		                    	
	                  	//Delete Extracted File
	                   	File fExtractedFile = new File(extractedFile);
	                   	fExtractedFile.delete();
		                    	
        	    	}
                   	else{
                   		mxLog.writeLog(" processFolderData(): Unable to unzip file - " + file);
        	    		throw new Exception("["+getName()+"]Unable to unzip file - " + file);
        	    	}
	                                 	  
               	} 
               	finally {	                    	
               		try {
               			mxLog.writeLog(" processFolderData(): End Recovery");
               			integrationLogger.debug("processFolderData: End Recovery");
                  	
               			recoveryService.endRecovery();	                            
               		} 
               		catch(Exception e){
               			MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
               		}
               	}

               	fileprocessed++;

               	if (isProcErr) {										
    	            
               		String emailMsg = "Date: " + new Date()+"\n";
               		emailMsg += "Error in CronTask: "+getName()+ "\n";
               		emailMsg += "File Processing: "+afile[j].getName()+NEWLINE;
               		emailMsg +=errMessage.toString();
               		
               		email.send(emailSubj,emailMsg );
    	            mxLog.writeLog("Email Sent:\n"+emailMsg); 
    			}

           		
            }
			
			if(fileprocessed!=0){
				mxLog.writeLog(" processFolderData(): "+fileprocessed+ " file(s) processed." );
				integrationLogger.info("["+getName()+"] "+fileprocessed+ " file(s) processed." );
			}
			else{
				mxLog.writeLog(" processFolderData(): No files was processed!");
				throw new Exception("["+getName()+"]No files was processed!");
			}

        }
		else{
			mxLog.writeLog(" processFolderData(): Unable to read input file '"+importFileName+"'");
			throw new Exception("["+getName()+"]Unable to read input file '"+importFileName+"'");
		}
        
        integrationLogger.debug("Leaving processFolderData");
        mxLog.writeLog(" processFolderData(): Leaving Processing Data");
	} 
    
    /* Author: HCHA
     * 29 JUN 2006 - Parse flat file.    
     */
    private Collection parseFlatFile(String file) 
    	throws IOException 
    {
    	integrationLogger.debug("Entering parseFlatFile");    	
    	mxLog.writeLog(" parseFlatFile(): Start Parse Flat File");
    	
        // Reading the import flat file 	                        
        BufferedReader flatfileReader;
        Collection col = new Vector();   
        
		flatfileReader = new BufferedReader(new FileReader(file));
                           
        String curLine;
        
        while((curLine = flatfileReader.readLine()) != null)
        {	            	            	        	        	
        	String[] str = curLine.split(delimiter);
        		
	        Vector vec = new Vector();

	        if(str.length!=NO_OF_FIELDS){
	        	isProcErr=true;
	            String errMsg = NEWLINE+ "Line:"+curLine+ NEWLINE;
	            errMsg+="Error Message: Invalid Number of Fields"+NEWLINE;
				errMessage.append(errMsg);
	        	mxLog.writeLog("["+getName()+"][ERROR]Invalid line:'"+curLine+"'");
	        	continue;
	        }
	        
        	//External Req No. size is not 12 chars => diesel record, skip 
	        if(str[9].trim().length()!= 12 ){
	        	mxLog.writeLog("["+getName()+"][INFO]Invalid line (invalid External Req No.):'"+curLine+"'");
	        	continue;
	        }
	        
	        for(int i=0;i<str.length;i++){
	        	//Add to element to vector.
	        	vec.add(str[i].trim());
	        }	            
	        
            // Add to a collection 
            col.add(vec);
        }	            	 
        
        integrationLogger.debug("parseFlatFile - Valid lines parsed: "+col.size()); 
        integrationLogger.debug("Leaving parseFlatFile");
        mxLog.writeLog(" parseFlatFile(): Valid lines parsed: "+col.size());
        mxLog.writeLog(" parseFlatFile(): Finish Parse Flat File");
    	return col;
    }  
    
    /* Author: HCHA
     * 15 May 2006 - Convert Date   
     */       
    private Date convertDate(String inDate)
    	throws Exception
    {
        SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy");
        Date outDate = null;
        outDate = dateformat.parse(inDate);
        
        return outDate;
    }
    

    /* 
     * Author: HCHA
     * 26 JUN 2006 - Create a XML document
     * 20060904 HCHA - Adding of BINNUM = 'HOLDING' AND LOTNUM = 'HOLDING'
     * 20060904 HCHA - Read total inventory balance 
     * 20060904 HCHA - Change to 1 parameter receipt total cost
     * 20060904 HCHA - Get current avgcost
     * 20060904 HCHA - Adding of LotNum
     * 20060905 HCHA - Check Inventory record
     * 20061004 HCHA - Add try-catch pair for all the close statements
     * 20061012 HCHA - Adding of fields for matrectrans: oldavgcost, newavgcost, oldtotalbal, roundingerr
     * 
     */    
    private void updateDB(Collection col) 
    	throws Exception
    {
    	integrationLogger.debug("Entering updateDB");
    	mxLog.writeLog(" updateDB(): Start Updating DB");    	
    	
    	MxDatabase db = null;
		Connection conn = null;
		ResultSet rsReadInvBal=null;
		PreparedStatement pstmtReadInvBal = null;
		PreparedStatement pstmtUpdInvCostStmt = null;
		PreparedStatement pstmtInsInvCostStmt = null;		
		PreparedStatement pstmtUpdInvBalStmt = null;
		PreparedStatement pstmtInsInvBalStmt = null;
		PreparedStatement pstmtInsMatrectransStmt = null;
		ResultSet rsReadPoline=null;
		PreparedStatement pstmtReadPoline = null;
		ResultSet rsReadMRTTotalQty=null;
		PreparedStatement pstmtReadMRTTotalQty = null;
		ResultSet rsReadTotalPolines = null;
		PreparedStatement pstmtReadTotalPolines = null;
		ResultSet rsReadReceiptPolines = null;
		PreparedStatement pstmtReadReceiptPolines = null;
		PreparedStatement pstmtUpdpoline = null;
		PreparedStatement pstmtUpdpo = null;
		
		PreparedStatement pstmtReadTotalInvBal = null;
		ResultSet rsReadTotalInvBal=null;
		PreparedStatement pstmtReadInvCost = null;
		ResultSet rsReadInvCost=null;
		PreparedStatement pstmtReadInventory = null;
		ResultSet rsReadInventory = null;
		
		try {
			
			db = new MxDatabase(getRunasUserInfo());
			conn = db.getConn();
			conn.setAutoCommit(false);
			
			//20060904 HCHA - Adding of BINNUM = 'HOLDING' AND LOTNUM = 'HOLDING' 
			String readInvBalStmt = "SELECT "+
			 "INVBALANCESID, "+ 
			 "CURBAL," +
			 "BINNUM, " +
			 "LOTNUM "+
			 "FROM " + 
			 "INVBALANCES  " +
			 "WHERE " + 
			 "ITEMNUM = ? AND " +
			 "LOCATION = ? AND " +
			 "CONDITIONCODE = 'NEW' AND " +
			 "BINNUM = 'HOLDING' AND LOTNUM = 'HOLDING' ";			
			pstmtReadInvBal = conn.prepareStatement(readInvBalStmt);
			
			//20060904 HCHA - Read total inventory balance 
			String readTotalInvBalStmt = "SELECT "+			  
			 "SUM(CURBAL) as totalbal " +
			 "FROM " + 
			 "INVBALANCES  " +
			 "WHERE " + 
			 "ITEMNUM = ? AND " +
			 "LOCATION = ? AND " +
			 "CONDITIONCODE = 'NEW' ";			
			pstmtReadTotalInvBal = conn.prepareStatement(readTotalInvBalStmt);
			
			//20060904 HCHA - Change to 1 parameter receipt total cost
			String updInvCostStmt = "UPDATE " +
				 "INVCOST "+
				 "SET " + 
				 "AVGCOST = ?, " +
				 "LASTCOST = ? " +
				 "WHERE " + 
				 "ITEMNUM = ? AND " +
				 "LOCATION = ? AND " +
				 "CONDITIONCODE = 'NEW' ";	
			pstmtUpdInvCostStmt = conn.prepareStatement(updInvCostStmt);

			//20060904 HCHA - Get current avgcost
			String readInvCostStmt = "SELECT "+			  
			 "AVGCOST " +
			 "FROM " + 
			 "INVCOST  " +
			 "WHERE " + 
			 "ITEMNUM = ? AND " +
			 "LOCATION = ? AND " +
			 "CONDITIONCODE = 'NEW' ";			
			pstmtReadInvCost = conn.prepareStatement(readInvCostStmt);

			
			//20060905 HCHA - Check Inventory record
			String readInventory = "SELECT "+			  
			 "ITEMNUM," +
			 "LOCATION " +
			 "FROM " + 
			 "INVENTORY  " +
			 "WHERE " + 
			 "ITEMNUM = ? AND " +
			 "LOCATION = ? ";			
			pstmtReadInventory = conn.prepareStatement(readInventory);
			
			String insInvCostStmt = "INSERT INTO INVCOST " +
					"( ITEMNUM, LOCATION, CONDITIONCODE, CONDRATE, ITEMSETID, SITEID, STDCOST, " +
					"AVGCOST, LASTCOST, GLACCOUNT, CONTROLACC,  ORGID, INVCOSTID ) " +
					"VALUES ( ? , ?, 'NEW', 100, 'SET1', ?, ?, ?, ?, ?, ?,  'PSAST', INVCOSTSEQ.NEXTVAL) ";
			pstmtInsInvCostStmt = conn.prepareStatement(insInvCostStmt);  
	    			 	 
			
			String updInvBalStmt = "UPDATE " +
			 "INVBALANCES "+
			 "SET " + 
			 "CURBAL = (CURBAL + ?) " +
			 "WHERE " + 
			 "INVBALANCESID = ? ";	
			pstmtUpdInvBalStmt = conn.prepareStatement(updInvBalStmt);
			 
			//20060904 HCHA - Adding of LotNum
			String insInvBalStmt = "INSERT INTO INVBALANCES " +
			  "( ITEMNUM, LOCATION,  CURBAL, PHYSCNT, RECONCILED, ORGID, " +
			  "  SITEID, ITEMSETID, CONDITIONCODE, INVBALANCESID, BINNUM, LOTNUM ) " +
			  "VALUES (?, ?, ?, 0, 0, 'PSAST', ?, 'SET1', 'NEW', INVBALANCESSEQ.NEXTVAL, 'HOLDING', 'HOLDING') ";
			pstmtInsInvBalStmt = conn.prepareStatement(insInvBalStmt);
			
			/*
			 * 08-09-2020: BCT Modification Starts
			 * Oracle to SQL Conversion
			 * NextVal should be replaced
			 */
			
			//20061012 HCHA - Adding of fields: oldavgcost, newavgcost, oldtotalbal, roundingerr
			String insMatrectransStmt = "INSERT INTO MATRECTRANS " +
			  "( ITEMNUM, TOSTORELOC, TRANSDATE, ACTUALDATE, QUANTITY, ISSUETYPE, " +
			  "UNITCOST, ACTUALCOST, PONUM, ENTERBY,  LINECOST, CURRENCYCODE,  " +
			  "LOADEDCOST, CURBAL, MATRECTRANSID, ORGID, SITEID, " +
			  "COSTINFO, REFWO,  FROMSITEID, LINETYPE, ITEMSETID, CONDITIONCODE, FROMCONDITIONCODE, LANGCODE, POLINENUM, " +
			  "HASLD, ISSUE, OUTSIDE, PRORATED, REJECTQTY, ENTEREDASTASK, PACKINGSLIPNUM, REMARK, TOBIN, TOLOT, " +
/* Start modification 16-03-07 AGD  --  Set positeid (same value as siteid) and status */
/*			  "OLDAVGCOST, NEWAVGCOST, OLDTOTALBAL, ROUNDINGERR ) " + */
			  "OLDAVGCOST, NEWAVGCOST, OLDTOTALBAL, ROUNDINGERR, POSITEID, STATUS ) " +
			  "VALUES ( ?, ?,  getdate(), ?,  ?, ?, ? , ?, ?, ?, ?, ?, ?, ?, " +
			  "MATRECTRANSSEQ.NEXTVAL, ?, ?, 1, '0', ?, 'ITEM', 'SET1','NEW', 'NEW', 'EN', ?, " +
/*			  "0, 0, 0, 0, 0, 0, ?, ?, ?, ?, ?, ?, ?, ? ) "; */
			  "0, 0, 0, 0, 0, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'COMP' ) ";
/* End modification 16-03-07 AGD */
					
			pstmtInsMatrectransStmt = conn.prepareStatement(insMatrectransStmt);
			
			String readPoline = "SELECT polinenum, iscs_lastrecptqty, receiptscomplete, orderqty from poline " +
					"where ponum = ? and itemnum = ? and storeloc = ? and iscs_prlinenum = ?"; 
			pstmtReadPoline = conn.prepareStatement(readPoline);
			
			String readMRTTotalQty ="select sum(quantity) as totalqty from matrectrans where " +
					"ponum = ? and itemnum = ? and tostoreloc = ? and polinenum = ?";
			pstmtReadMRTTotalQty = conn.prepareStatement(readMRTTotalQty);
			
			String readTotalPolines = "SELECT polinenum FROM POLINE WHERE ponum = ? ";
			pstmtReadTotalPolines = conn.prepareStatement(readTotalPolines);
			
			String readReceiptPolines = "SELECT polinenum FROM POLINE " +
					"WHERE ponum = ? and RECEIPTSCOMPLETE ='1'";
			pstmtReadReceiptPolines = conn.prepareStatement(readReceiptPolines);
			
			String updpoline = "update poline set RECEIPTSCOMPLETE = ? " +
					"where ponum = ? and polinenum = ? and storeloc = ?";
			pstmtUpdpoline = conn.prepareStatement(updpoline);
			
			String updpo = "UPDATE PO SET receipts = ? WHERE ponum = ? "; 
			pstmtUpdpo = conn.prepareStatement(updpo);

/* Start modification 16-03-07 AGD  --  Get the site from the PO instead of from the delivery location */
			String podata = "SELECT siteid FROM po WHERE ponum=?";
			PreparedStatement pstmtpodata = conn.prepareStatement(podata);
   		ResultSet rsreadpodata = null;
/* End modification 16-03-07 AGD */

	        Iterator iterParsedData = col.iterator();         
	        while (iterParsedData.hasNext()) {        	                            	
		        
	        	//Vector Element
	        	//0. Item Number
	        	//1. PO Number 
	        	//2. PO Line Num	
	        	//3. Receipt Num
	        	//4. Location
	        	//5. Receipt Date
	        	//6. Quantity
	        	//7. Unit Price
	        	//8. Transaction Type
	        	//9. External Req No (ISCS PR line num)
	        	//10. Shipment Number
	        	
		        Vector vec = (Vector)iterParsedData.next();
		        
	        	try {
	        		
	        		integrationLogger.debug("Line:"+vec.toString());	        		
	        		
	        		////////////////////////////////////////////////////////////////////////////////////
	        		// Get data from vector
	        		
	        		String itemnum = ((String)vec.elementAt(0)).trim();
	        		integrationLogger.debug("ItemNum:"+itemnum);
	        
	        		String ponum = ((String)vec.elementAt(1)).trim();
	        		integrationLogger.debug("ponum:"+ponum);
	        		
	        		String iscs_polinenum = ((String)vec.elementAt(2)).trim();
	        		integrationLogger.debug("iscs_polinenum:"+iscs_polinenum);
	        		
	        		String recptnum = ((String)vec.elementAt(3)).trim();
	        		integrationLogger.debug("recptnum:"+recptnum);
	        		
	        		String oralocation = ((String)vec.elementAt(4)).trim();	        		
	        		integrationLogger.debug("oracle store location:"+oralocation);
	        		//Convert oracle location to EMS locaiton
	        		String location = null;
	        		String site = null;
	        		String controlacc = null;

/* Start modification 16-03-07 AGD  --  Get the site from the PO instead of from the delivery location */
	        		if(oralocation.compareToIgnoreCase("PSA-BTED-STORE")==0){
	        			location = "BTSTORE";
//	        			site = "BT";	
	        			controlacc = BT_CONTROLACC;
	        		}
	        		else if(oralocation.compareToIgnoreCase("PSA-KTED-STORE")==0){
	        			location = "KTSTORE";
//	        			site = "KT";
	        			controlacc = KT_CONTROLACC;
	        		}
	        		else if(oralocation.compareToIgnoreCase("PSA-PPT1ED-STORE")==0){
	        			location = "PPT1STORE";
//	        			site = "PPT1";
	        			controlacc = PPT1_CONTROLACC;
	        		}
	        		else if(oralocation.compareToIgnoreCase("PSA-PPT2ED-STORE")==0){
	        			location = "PPT2STORE";
//	        			site = "PPT2";
	        			controlacc = PPT2_CONTROLACC;
	        		}
	        		else if(oralocation.compareToIgnoreCase("PSA-TPTED-STORE")==0){
	        			location = "TPTSTORE";
//	        			site = "TPT";
	        			controlacc = TPT_CONTROLACC;
	        		}
	        		else{
	        			integrationLogger.debug("Site for found!");
	        			mxLog.writeLog("[ERROR]Site for found for line:"+vec.toString());
	        			continue;
	        		}
	        		pstmtpodata.clearParameters();
	        		pstmtpodata.setString(1, ponum);
	        		rsreadpodata = pstmtpodata.executeQuery();
	        		// Check if the PO exists
	        		if (!rsreadpodata.next())
	        		{
	        			integrationLogger.debug("PO not found in DB.");
	    				isProcErr = true;
	    				String errMsg = NEWLINE + "Line:" + vec.toString() + NEWLINE;
	    				errMsg += "Error Message: PO not found in DB." + NEWLINE;
	    				errMessage.append(errMsg);
	    	        	mxLog.writeLog("[" + getName() + "][ERROR]PO not found in DB:'" + vec.toString() + "'");
	    	        	continue;
	    			}
	    			else
	    				site = rsreadpodata.getString("siteid");
/* End modification 16-03-07 AGD */

	        		String transtype = ((String)vec.elementAt(8)).trim();
	        		integrationLogger.debug("Transcation Type:"+transtype);
	        		String issuetype = null;
	        		
	        		float qty = Float.valueOf((String)vec.elementAt(6)).floatValue();
	        		integrationLogger.debug("Quantity:"+qty);
	        		//Check transcation type
	        		if((transtype.compareToIgnoreCase("RETURN")==0)||(transtype.compareToIgnoreCase("CORRECT")==0)){
	        			issuetype = "RETURN";	        			
	        		}
	        		else if(transtype.compareToIgnoreCase("ADJUST")==0){
	        			issuetype = "RETURN";
	        			qty = ((float)-1.0*qty);
	        		}
	        		else{
	        			issuetype = "RECEIPT";
	        		}
	        		
	        		java.sql.Date receiptDate = new java.sql.Date(convertDate((String) vec.elementAt(5)).getTime());
	        		integrationLogger.debug("Receipt Date:"+receiptDate);
	        		
	        		float unitprice = Float.valueOf((String)vec.elementAt(7)).floatValue();
	        		integrationLogger.debug("Unit Price:"+unitprice);     

	        		float linecost = ((float)Math.round(qty*unitprice*100f))/100f;
	        		
	        		String iscs_prlinenum = ((String)vec.elementAt(9)).trim();
	        		integrationLogger.debug("ISCS PR Line Num:"+iscs_prlinenum);
	        		
	        		String shipmentnum = ((String)vec.elementAt(10)).trim();
	        		integrationLogger.debug("Shipment Number:"+shipmentnum);
	        		
	        		
	        		////////////////////////////////////////////////////////////////////////////////////
	        		// Get polinenum and last receipt qty
	        		/* 
	        		 * select polinenum, iscs_lastrecptqty, receiptscomplete, orderqty from poline 
	        		 * where ponum = ? and itemnum = ? and storeloc = ? and iscs_prlinenum = ? 
	        		 */
	        		
	        		pstmtReadPoline.clearParameters();
	        		pstmtReadPoline.setString(1, ponum );
	        		pstmtReadPoline.setString(2, itemnum );
	        		pstmtReadPoline.setString(3, location );
	        		pstmtReadPoline.setString(4, iscs_prlinenum );
	        		
	        		rsReadPoline = pstmtReadPoline.executeQuery();
	        		int polinenum = 0;
	        		float iscs_lastrecptqty = 0;
	        		float orderqty = 0;
	        		//int receiptscomplete = 0;

	        		//Check if there is any poline record
	        		if(!rsReadPoline.next()){
	    				integrationLogger.debug("PO Line not found in DB.");
	    				isProcErr=true;
	    	            String errMsg = NEWLINE+ "Line:"+vec.toString()+ NEWLINE;
	    	            errMsg+="Error Message: PO Line not found in DB."+NEWLINE;
	    				errMessage.append(errMsg);
	    	        	mxLog.writeLog("["+getName()+"][ERROR]PO Line not found in DB:'"+vec.toString()+"'");
	    	        	continue;
	    			}
	    			else{
	    				
	    				polinenum = rsReadPoline.getInt("polinenum");
	    				integrationLogger.debug("polinenum:"+polinenum);
	    				
	    				iscs_lastrecptqty = rsReadPoline.getFloat("iscs_lastrecptqty");
	    				integrationLogger.debug("iscs_lastrecptqty:"+iscs_lastrecptqty);
	
	       				orderqty = rsReadPoline.getFloat("orderqty");
	    				integrationLogger.debug("orderqty:"+orderqty);
	    				
	    				/*
	    				//REMOVED: no need because possible of return => delay check to total qty
	    				 
	    				receiptscomplete = rsReadPoline.getInt("receiptscomplete");
	    				integrationLogger.debug("iscs_lastrecptqty:"+iscs_lastrecptqty);
	    				//To check whether receipt complete	    				
	    				if(receiptscomplete==1){
	    					integrationLogger.debug("Receipt already completed!");
		    				isProcErr=true;
		    	            String errMsg = NEWLINE+ "Line:"+vec.toString()+ NEWLINE;
		    	            errMsg+="Error Message: Receipt already complete for this line."+NEWLINE;
		    				errMessage.append(errMsg);
		    	        	mxLog.writeLog("["+getName()+"][ERROR]Receipt already complete for this line:'"+vec.toString()+"'");
		    	        	continue;
	    				}
	    				*/
	    			}
	        		
	        		////////////////////////////////////////////////////////////////////////////////////////
	        		// Check if inventory record exisit
	        		// SELECT ITEMNUM, LOCATION FROM INVENTORY WHERE ITEMNUM = ? AND LOCATION = ? 
	        		
	        		pstmtReadInventory.clearParameters();
	        		pstmtReadInventory.setString(1, itemnum );
	        		pstmtReadInventory.setString(2, location );
	        		rsReadInventory = pstmtReadInventory.executeQuery();
	        		
	    			if(!rsReadInventory.next()){
	    				integrationLogger.debug("No Inventory Records for Store:"+location+" Item: "+itemnum);
	    				isProcErr=true;
	    	            String errMsg = NEWLINE+ "Line:"+vec.toString()+ NEWLINE;
	    	            errMsg+="Error Message: No Inventory Records for Store:"+location+" Item: "+itemnum+NEWLINE;
	    				errMessage.append(errMsg);
	    	        	mxLog.writeLog("["+getName()+"][ERROR]No Inventory Records for Store:"+location+" Item: "+itemnum + " for this line:'"+vec.toString()+"'");
	    	        	continue;
	    			}
	        		
	        		///////////////////////////////////////////////////////////////////////////////////////
	        		// Check matrectrans for qty receipt by this poline
	        		/*
	        		 * select sum(quantity) as totalqty from matrectrans where ponum = ? and itemnum = ? 
	        		 * and location = ? and polinenum = ?;
	        		 */
	        		pstmtReadMRTTotalQty.clearParameters();
	        		pstmtReadMRTTotalQty.setString(1, ponum );
	        		pstmtReadMRTTotalQty.setString(2, itemnum );
	        		pstmtReadMRTTotalQty.setString(3, location );
	        		pstmtReadMRTTotalQty.setInt(4, polinenum );
	        		rsReadMRTTotalQty = pstmtReadMRTTotalQty.executeQuery();
	        		
	        		float mrtTotalQty = 0;
	        		
	    			if(!rsReadMRTTotalQty.next()){
	    				integrationLogger.debug("No prevous receipt records in matrectrans.");
	    			}
	    			else{
	    				if(rsReadMRTTotalQty.getString("totalqty")!=null){
	    					mrtTotalQty = rsReadMRTTotalQty.getFloat("totalqty");	    					
	    				}
	    			}
	    			integrationLogger.debug("Matrectrans Total Quantity="+ mrtTotalQty);
	    			
	        		///////////////////////////////////////////////////////////////////////////////////////
	        		// Check receipt quantity with order quantity
	    			
	    			//Total Receipt Qty = Current Entry Recpt Qty + Matrectrans Recept Qty + ISCS last receipt qty
	    			float totalrecptqty = qty + mrtTotalQty + iscs_lastrecptqty;
	    			
	    			int receiptcompleted = 0;
	    			if(totalrecptqty == orderqty){
	    				//Receipt comlete
	    				receiptcompleted = 1;
	    			}
	    			else if(totalrecptqty < orderqty && totalrecptqty >= 0){
	    				//Partial receipt
	    				receiptcompleted = 0;
	    			}else if (totalrecptqty < 0)
	    			{
	    				//Will cause over receipt (totalrecptqty > orderqty) => ERROR!!
    					integrationLogger.debug("Returning stock that has not been receipted!");
	    				isProcErr=true;
	    	            String errMsg = NEWLINE+ "Line:"+vec.toString()+ NEWLINE;
	    	            errMsg+="Error Message: Returning stock that has not been receipted!."+NEWLINE;
	    				errMessage.append(errMsg);
	    	        	mxLog.writeLog("["+getName()+"][ERROR]Returning stock that has not been receipted:'"+vec.toString()+"'");
	    	        	continue;	
	    			}
	    			else{
	    				//Will cause over receipt (totalrecptqty > orderqty) => ERROR!!
    					integrationLogger.debug("Will cause over receipt!");
	    				isProcErr=true;
	    	            String errMsg = NEWLINE+ "Line:"+vec.toString()+ NEWLINE;
	    	            errMsg+="Error Message: Will cause over receipt!."+NEWLINE;
	    				errMessage.append(errMsg);
	    	        	mxLog.writeLog("["+getName()+"][ERROR]Will cause over receipt! for this line:'"+vec.toString()+"'");
	    	        	continue;
	    			}

	    			
	    			
	        		////////////////////////////////////////////////////////////////////////////////////
	        		pstmtReadInvBal.clearParameters();
	        		pstmtReadInvBal.setString(1, itemnum );
	        		pstmtReadInvBal.setString(2, location );

	        		
	        		rsReadInvBal = pstmtReadInvBal.executeQuery();
	        		
	        		float curBal = 0;
	        		String invBalID = null;
	    			boolean noInvBalRec = false;
	    			String bin = "";
	    			String lot = "";
	    			
	        		//Check if there is any Inv Balance record 
	    			if(!rsReadInvBal.next()){
	    				integrationLogger.debug("Inventory Balance Record is not found in DB.");
	    				noInvBalRec = true;
	    				bin= "HOLDING";
	    				lot= "HOLDING";
	    			}
	    			else{
	    				curBal = rsReadInvBal.getFloat("CURBAL");
	    				invBalID = rsReadInvBal.getString("INVBALANCESID"); //To ensure ONLY 1 invbalances record is updated
	    				if(rsReadInvBal.getString("BINNUM")!=null)
	    					bin = rsReadInvBal.getString("BINNUM");
	    				if(rsReadInvBal.getString("LOTNUM")!=null)
	    					lot = rsReadInvBal.getString("LOTNUM");
	    				
	    			}
	    			
	    			/////////////////////////////////////////
	    			// Read total inventory balance
	    			// SELECT SUM(CURBAL) as totalbal  FROM INVBALANCES WHERE ITEMNUM = ? AND LOCATION = ? 
	    			// AND CONDITIONCODE = 'NEW' 
	    			
	    			pstmtReadTotalInvBal.clearParameters();
	        		pstmtReadTotalInvBal.setString(1, itemnum );
	        		pstmtReadTotalInvBal.setString(2, location );
	        		
	        		rsReadTotalInvBal = pstmtReadTotalInvBal.executeQuery();
	    			float totalCurBal = 0;
	        		
	        		//Check if there is any Inv Balance record 
	    			if(!rsReadTotalInvBal.next()){
	    				integrationLogger.debug("Total Inventory Balance Record not found in DB.");
	    			}
	    			else{
	    				totalCurBal = rsReadTotalInvBal.getFloat("totalbal");
	    				integrationLogger.debug("Total Balance="+ totalCurBal);
	    			}
	        		
	        		
	    			//////////////////////////////////////
	    			// Check if return will cause negive balance in inventory for the line
	    			if((curBal+qty)<0 ){
	    				//Will cause inventory to go negative => ERROR!!
    					integrationLogger.debug("Returning stock will cause negative inventory!");
	    				isProcErr=true;
	    	            String errMsg = NEWLINE+ "Line:"+vec.toString()+ NEWLINE;
	    	            errMsg+="Error Message: Returning stock will cause negative inventory!!."+NEWLINE;
	    				errMessage.append(errMsg);
	    	        	mxLog.writeLog("["+getName()+"][ERROR]Returning stock will cause negative inventory!:'"+vec.toString()+"'");
	    	        	continue;	
	    			}
	    			
	    			
	    			//////////////////
	    			// Get avgcost
	    			//////////////////
	    			
	    			//SELECT AVGCOST FROM INVCOST WHERE ITEMNUM = ? AND LOCATION = ? AND CONDITIONCODE = 'NEW';	
	    			
	        		pstmtReadInvCost.clearParameters();
	        		pstmtReadInvCost.setString(1, itemnum );
	        		pstmtReadInvCost.setString(2, location );
	        		rsReadInvCost = pstmtReadInvCost.executeQuery();
	        		
	        		
	        		//Check if there is any Inv Balance record 
	        		
	        		//20061012 HCHA - Calculation of Rounding Error
	        		float avgcost = 0;
	        		float newAvgCostRnd = 0;
	        		float roundingErr = 0; 
	        		
	    			if(rsReadInvCost.next()){
	    				avgcost = rsReadInvCost.getFloat("AVGCOST");
	    				integrationLogger.debug("Average cost="+ avgcost);

		        		//////////////////////////
		        		// Update INVCOST table
		        		//////////////////////////
		    			
		        		/*
		    			 UPDATE INVCOST 
						 SET 
						  AVGCOST = ?, 
						  LASTCOST = ? 
						 WHERE 
						  ITEMNUM = ? AND 
						  LOCATION = ? AND
						  CONDITIONCODE = 'NEW';	
		    			*/
		    			pstmtUpdInvCostStmt.clearParameters();
		    			
		    			//return all balances stock => new balance = 0
		    			if((totalCurBal+qty)==0){
		    				newAvgCostRnd = unitprice;
		    				roundingErr = 0;
		    			}
		    			else{
		    				float newAvgCost = ( (totalCurBal*avgcost) + linecost) / (totalCurBal+qty);
		    				//20061012 HCHA - Calculation of Rounding Error
		    				newAvgCostRnd =((float)Math.round(newAvgCost*100f))/100f;
		    				roundingErr = (totalCurBal+qty) * (newAvgCostRnd - newAvgCost);
		    			}

		    			pstmtUpdInvCostStmt.setFloat(1, newAvgCostRnd );		    			
		    			pstmtUpdInvCostStmt.setFloat(2, unitprice );
		    			pstmtUpdInvCostStmt.setString(3, itemnum );
		    			pstmtUpdInvCostStmt.setString(4, location );
		    			pstmtUpdInvCostStmt.executeUpdate();

	    			}
	    			else{
	    				integrationLogger.debug("Inventory Cost Record is not found in DB.");
	    				 /*
		    			   INSERT INTO INVCOST ( ITEMNUM, LOCATION, CONDITIONCODE, CONDRATE, ITEMSETID, SITEID, STDCOST,
		    			 	AVGCOST, LASTCOST, GLACCOUNT, CONTROLACC,  ORGID, INVCOSTID )  
		    			 	VALUES ( ? , ?, 'NEW', 100, 'SET1', ?, ?, ?, ?, ?, ?,  'PSAST', INVCOSTSEQ.NEXTVAL); 
		    			 */
	    				
	    				//20061012 HCHA - Adding of fields: oldavgcost, newavgcost, oldtotalbal, roundingerr
	    				avgcost = unitprice;
	    				newAvgCostRnd = unitprice;
	    				roundingErr = 0;
	    				
	    				pstmtInsInvCostStmt.clearParameters();
	    				pstmtInsInvCostStmt.setString(1, itemnum );
	    				pstmtInsInvCostStmt.setString(2, location );
	    				pstmtInsInvCostStmt.setString(3, site );
	    				pstmtInsInvCostStmt.setFloat(4,unitprice );
	    				pstmtInsInvCostStmt.setFloat(5,unitprice );
	    				pstmtInsInvCostStmt.setFloat(6,unitprice );
	    				pstmtInsInvCostStmt.setString(7, GLACCOUNT );
	    				pstmtInsInvCostStmt.setString(8, controlacc );
		    			pstmtInsInvCostStmt.executeUpdate();	    				

	    			}
	        		
	  
	        		////////////////////////////
	        		// Update INVBALANCES table
	        		////////////////////////////
	    			
	    			if(noInvBalRec){
	    				
	    				/*
	    				 INSERT INTO INVBALANCES ( ITEMNUM, LOCATION,  CURBAL, PHYSCNT, RECONCILED, ORGID
	    				 	, SITEID, ITEMSETID, CONDITIONCODE, INVBALANCESID,  BINNUM, LOTNUM ) VALUES ( 
	    				 	?, ?, ?, 0, 0, 'PSAST', ?, 'SET1', 'NEW', INVBALANCESSEQ.NEXTVAL, 'HOLDING', 'HOLDING'); 
	    				 */
	    				
	    				pstmtInsInvBalStmt.clearParameters();
	    				pstmtInsInvBalStmt.setString(1,itemnum);
	    				pstmtInsInvBalStmt.setString(2,location);
	    				pstmtInsInvBalStmt.setFloat(3, qty);
	    				pstmtInsInvBalStmt.setString(4, site);
	    				pstmtInsInvBalStmt.executeUpdate();
	    				
	    			}
	    			else{
		    			/*
		    			    update INVBALANCES set CURBAL = (CURBAL + ?) 
		    			    where  INVBALANCESID = ? ; 
		    			 */
		    			pstmtUpdInvBalStmt.clearParameters();
		    			pstmtUpdInvBalStmt.setFloat(1, qty);
		    			pstmtUpdInvBalStmt.setString(2, invBalID );
		    			pstmtUpdInvBalStmt.executeUpdate();
		    			
		    			
	    			}
	    				    			
	        		////////////////////////////
	        		// Update MATRECTRANS table
	        		////////////////////////////
	        		
	    			pstmtInsMatrectransStmt.clearParameters();
	    			pstmtInsMatrectransStmt.setString(1, itemnum );
	    			pstmtInsMatrectransStmt.setString(2, location );
	    			pstmtInsMatrectransStmt.setDate(3, receiptDate );
	    			pstmtInsMatrectransStmt.setFloat(4, qty);
	    			pstmtInsMatrectransStmt.setString(5, issuetype);
	    			pstmtInsMatrectransStmt.setFloat(6, unitprice);
	    			pstmtInsMatrectransStmt.setFloat(7, unitprice);
	    			pstmtInsMatrectransStmt.setString(8, ponum);
	    			pstmtInsMatrectransStmt.setString( 9, "MAXINTADM");
	    			pstmtInsMatrectransStmt.setFloat(10, linecost);
	    			pstmtInsMatrectransStmt.setString(11, "SGD");
	    			pstmtInsMatrectransStmt.setFloat(12, linecost);
	    			pstmtInsMatrectransStmt.setFloat(13, curBal);
	    			pstmtInsMatrectransStmt.setString(14, "PSAST" );
	    			pstmtInsMatrectransStmt.setString(15, site );
	    			pstmtInsMatrectransStmt.setString(16, site );
	    			pstmtInsMatrectransStmt.setInt(17, polinenum );
	    			pstmtInsMatrectransStmt.setString(18, shipmentnum );
	    			pstmtInsMatrectransStmt.setString(19, recptnum );
	    			pstmtInsMatrectransStmt.setString(20, bin );
	    			//20060904 HCHA - Adding of Lotnum 
	    			pstmtInsMatrectransStmt.setString(21, lot );
	    			
	    			//20061012 HCHA - Adding of fields: oldavgcost, newavgcost, oldtotalbal, roundingerr
	    			pstmtInsMatrectransStmt.setFloat(22, avgcost );
	    			pstmtInsMatrectransStmt.setFloat(23, newAvgCostRnd  );
	    			pstmtInsMatrectransStmt.setFloat(24, totalCurBal );
	    			pstmtInsMatrectransStmt.setFloat(25, roundingErr );
/* Start modification 16-03-07 AGD -- set positeid as well */
	    			pstmtInsMatrectransStmt.setString(26, site );
/* End modification 16-03-07 AGD */
	    			
	    			pstmtInsMatrectransStmt.executeUpdate();
	    			
	        		//////////////////////////////////////////////
	        		// Update PO Line (for receipt complete field)
	        		//////////////////////////////////////////////
	    			
	    			/*
	    			 * update poline set RECEIPTSCOMPLETE = ? 
	    				where ponum = ? and polinenum = ? and storeloc = ?
	    			 */
	    			
	    			pstmtUpdpoline.clearParameters();
	    			pstmtUpdpoline.setInt(1, receiptcompleted );
	    			pstmtUpdpoline.setString(2, ponum);
	    			pstmtUpdpoline.setInt(3, polinenum );
	    			pstmtUpdpoline.setString(4, location );
	    			pstmtUpdpoline.executeUpdate();
	    			
	        		///////////////////////////////////////
	        		// Update PO (for receipt field)
	        		///////////////////////////////////////
	    			
	    			//Check total polines
	    			//SELECT * as totalpolines FROM POLINE WHERE ponum = ?;
	    			pstmtReadTotalPolines.clearParameters();
	    			pstmtReadTotalPolines.setString(1, ponum );	        		
	        		rsReadTotalPolines = pstmtReadTotalPolines.executeQuery();	    			
	        		
	        		int totalpolines = 0;
	        		while(rsReadTotalPolines.next()){
	        			totalpolines++;
	        		}
	    			integrationLogger.debug("totalpolines="+totalpolines);
	    			
	    			//check receipted polines
	    			//SELECT * as receiptedpoline FROM POLINE WHERE ponum = ? and RECEIPTSCOMPLETE ='1';
	        		pstmtReadReceiptPolines.clearParameters();
	        		pstmtReadReceiptPolines.setString(1, ponum );	        		
	        		rsReadReceiptPolines = pstmtReadReceiptPolines.executeQuery();
	        		
	        		int receiptedpolines = 0;
	        		while(rsReadReceiptPolines.next()){
	        			receiptedpolines++;
	        		}
	    			integrationLogger.debug("receiptedpolines="+receiptedpolines);
	        		
	    			//update po receipts field	        		
	        		/*
	    			 * UPDATE PO SET receipts = ? WHERE ponum = ?;
	    			 */
	    			
	    			String poreceiptstatus=null;
	    			if(receiptedpolines == 0){
	    				poreceiptstatus = "NONE";
	    			}
	    			else if(receiptedpolines < totalpolines ){
	    				poreceiptstatus = "PARTIAL";
	    			}
	    			else if(receiptedpolines == totalpolines){
	    				poreceiptstatus = "COMPLETE";
	    			}

	    			pstmtUpdpo.clearParameters();
	    			pstmtUpdpo.setString(1, poreceiptstatus );
	    			pstmtUpdpo.setString(2, ponum );
	    			pstmtUpdpo.executeUpdate();
	    			
	    			//commit all update at this point after verifying no errors
	    			conn.commit();
	    			integrationLogger.debug("Update commited.");
	        	} 
	        	catch(Exception e) {
		        	isProcErr=true;
	        		String errMsg = genErrMsg(e, vec);
					errMessage.append(errMsg);
					errMessage.append(NEWLINE);
					mxLog.writeLog(" updateDB():[ERROR]" + errMsg);
					
					try{
						//roll back the changes					
						conn.rollback();
						integrationLogger.debug("Error in processing transaction. Roll backed updates.");
					}
					catch(Exception connexp){
						isProcErr=true;
		        		String errMsg1 = genErrMsg(connexp, vec);
		        		errMessage.append("Error rolling back..");
		        		errMessage.append(NEWLINE);
		        		errMessage.append(errMsg1);
						errMessage.append(NEWLINE);
						mxLog.writeLog(" updateDB():[ERROR]" + errMsg);
					}
					
	            }
	        }
		}
		finally{
			//20061004 HCHA - Add try-catch pair for all the close statements
			try{
				if(rsReadInventory!=null) rsReadInventory.close();
			}
			catch(Exception e){};			
			try{
				if(pstmtReadInventory!=null)pstmtReadInventory.close();
			}
			catch(Exception e){};
			
			try{
				if(rsReadInvCost!=null)rsReadInvCost.close();
			}
			catch(Exception e){};
			try{
				if(pstmtReadInvCost!=null) pstmtReadInvCost.close();	
			}
			catch(Exception e){};
			try{
				if(rsReadTotalInvBal!=null)rsReadTotalInvBal.close();
			}
			catch(Exception e){};
			try{
				if(pstmtReadTotalInvBal!=null) pstmtReadTotalInvBal.close();
			}
			catch(Exception e){};
			try{
				if(rsReadPoline!=null)rsReadPoline.close();
			}
			catch(Exception e){};
			try{
				if(pstmtReadPoline!=null)pstmtReadPoline.close();
			}
			catch(Exception e){};
			try{
				if(rsReadMRTTotalQty!=null)rsReadMRTTotalQty.close();
			}
			catch(Exception e){};
			try{
				if(pstmtReadMRTTotalQty!=null)pstmtReadMRTTotalQty.close();
			}
			catch(Exception e){};
			try{
				if(rsReadTotalPolines!=null)rsReadTotalPolines.close();
			}
			catch(Exception e){};
			try{
				if(pstmtReadTotalPolines!=null)pstmtReadTotalPolines.close();
			}
			catch(Exception e){};
			try{
				if(rsReadReceiptPolines!=null)rsReadReceiptPolines.close();
			}
			catch(Exception e){};
			try{
				if(pstmtReadReceiptPolines!=null)pstmtReadReceiptPolines.close();
			}
			catch(Exception e){};
			try{
				if(pstmtUpdpoline!=null)pstmtUpdpoline.close();
			}
			catch(Exception e){};
			try{
				if(pstmtUpdpo!=null)pstmtUpdpo.close();	
			}
			catch(Exception e){};
			try{
				if(rsReadInvBal!=null)rsReadInvBal.close();
			}
			catch(Exception e){};
			try{
				if(pstmtReadInvBal!=null) pstmtReadInvBal.close();
			}
			catch(Exception e){};
			try{
				if(pstmtUpdInvCostStmt!=null) pstmtUpdInvCostStmt.close();
			}
			catch(Exception e){};
			try{
				if(pstmtInsInvCostStmt!=null) pstmtInsInvCostStmt.close();
			}
			catch(Exception e){};
			try{
				if(pstmtUpdInvBalStmt!=null) pstmtUpdInvBalStmt.close();
			}
			catch(Exception e){};
			try{
				if(pstmtInsInvBalStmt!=null) pstmtInsInvBalStmt.close();
			}
			catch(Exception e){};
			try{
				if(pstmtInsMatrectransStmt!=null) pstmtInsMatrectransStmt.close();
			}
			catch(Exception e){};
			//20061004 HCHA - Remove Close Connection (use freeConnection in provided by releaseResources())
			//if(conn!=null) 	conn.close();
			if(db!=null) 	db.releaseResources();
		}
        
        // Clear collection
        col.clear(); 
        integrationLogger.debug("Leaving updateDB");
        mxLog.writeLog(" updateDB(): Finish Updating DB");
        
    } 

     
    /* 
     * Define Maximo parameter setting in Cron Task 
     */
    private static CrontaskParamInfo params[];
    static 
    {
    	// BTE: Set the number of the parameter.  
        params = null;
        params = new CrontaskParamInfo[9];
        
        // BTE: All the parameter configurable from Cron Task user interface 
        params[0] = new CrontaskParamInfo();
        params[0].setName("SPLITTAG");
        params[0].setDefault("~");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[0].setDescription("Delimiter for flat file.");
        params[0].setDescription("CommonCron","DelimiterFlatFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[1] = new CrontaskParamInfo();
        params[1].setName("DIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[1].setDescription("Local directory where flat file will be read.");
        params[1].setDescription("CommonCron","LocalDirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
                
        params[2] = new CrontaskParamInfo();
        params[2].setName("ALERTEMAIL");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[2].setDescription("Admin email address for notification of error.");
        params[2].setDescription("CommonCron","Adminemailaddress");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[3] = new CrontaskParamInfo();
        params[3].setName("IMPORTFILENAME");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[3].setDescription("File name of the input file(Includes with 'yyyymmdd*' for current day file)");
        params[3].setDescription("CommonCron","FileNameOfTheInputFile");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[4] = new CrontaskParamInfo();
        params[4].setName("ALERTEMAILSUBJ");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[4].setDescription("Email Subject for the Alert Email.");
        params[4].setDescription("CommonCron","EmailSubject");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[5] = new CrontaskParamInfo();
        params[5].setName("ENABLELOG");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[5].setDescription("Enable log output('Y' or 'N').");
        params[5].setDescription("CommonCron","EnableLog");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[5].setDefault("Y");
        
        params[6] = new CrontaskParamInfo();
        params[6].setName("LOGFILEPATH");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[6].setDescription("Log Directory and Filename.");
        params[6].setDescription("CommonCron","LogDirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
                
        params[7] = new CrontaskParamInfo();
        params[7].setName("UNZIPEXEC");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[7].setDescription("Executable for unziping the input flat file.");
        params[7].setDescription("CommonCron","ExecutableUnziping");
      //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[7].setDefault("gunzip -f -q");
        
        params[8] = new CrontaskParamInfo();
        params[8].setName("PROCESSDIRECTORY");
      //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[7].setDescription("Temp Directory where processing will be done.");
        params[7].setDescription("CommonCron","TempDirectory");
      //-- COMM-IT changed to make it compatible with Maximo 7 API

    }

}
