/**
 * @author	YCH
 * Date		Oct 27, 2011
 * Comment	Write EDOT Output File
 */
package com.psa.custom.edot;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class EDOTFile {
	private String outFileName;
	private File outFile;
	private FileWriter fWriter;
	private BufferedWriter bWriter;
	private long transRecCount;

	/**
	 * @param outFileName
	 * @param delimiter
	 */
	public EDOTFile(String outFileName) throws IOException {
		this.outFileName = outFileName;
		outFile = new File(this.outFileName);
		fWriter = new FileWriter(outFile);
		bWriter = new BufferedWriter(fWriter);
		transRecCount = 0;
	}

	public void writeRecord(ArrayList lst) throws IOException {
		String writeline = new String();

		for (int i = 0; i < lst.size(); i++) {

			writeline += (String) lst.get(i);
		}

		bWriter.write(writeline);
		bWriter.newLine();

	}

	public void writeTransRec(ArrayList lst) throws IOException {

		transRecCount++;
		writeRecord(lst);
	}

	public static String padString(String inputStr, String padChar,
			int opStrSize, boolean padFront) {
		if (inputStr == null)
			inputStr = new String();
	
		String opStr = new String();

		for (int i = 0; i < (opStrSize - inputStr.length()); i++) {
			opStr += padChar;
		}

		if (padFront) {
			opStr = opStr + inputStr;
		} else {
			opStr = inputStr + opStr;
		}

		return opStr;
	}

	public void close() throws IOException {
		bWriter.close();
		fWriter.close();
	}

}
