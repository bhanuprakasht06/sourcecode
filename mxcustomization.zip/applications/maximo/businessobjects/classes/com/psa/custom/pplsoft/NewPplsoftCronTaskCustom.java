/*
 * Modification history
 * 30-01-13 WMJ EMS-551 [Peoplesoft]To handle special characters when generating XML messages in Maximo Peoplesoft crontask
 *
 *
 */

/*
 * Modification history
 *
 * 28-Nov-11 YCH Creation
 *
 * This class is cron task to process received Peoplesoft records
 *
 */

package com.psa.custom.pplsoft;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Vector;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.LineNumberReader;

import psdi.app.system.CrontaskParamInfo;
import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxXml;
import com.psa.custom.exchangerate.SimpleFilenameFilter;
import com.psa.custom.ois.MxLog;

import psdi.iface.load.RecoveryService;
import psdi.mbo.GLFormat;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class NewPplsoftCronTaskCustom extends SimpleCronTask {
	
	    MboSetRemote mxDepartmentSet = null;

        private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
        private static final String SPACE = " ";
        private static final String NEWLINE = "\n\r";

        protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");

        private static final int TRANS_ID_BEGIN_INDEX = 1;
        private static final int TRANS_ID_END_INDEX = 16;
        private static final String TRANS_ID_JOB = "JOB";
        private static final String TRANS_ID_SNPCOSTC = "SNPCOSTC";
 
        private String qualifiedInstanceName;
        private RecoveryService recoveryService;

        private String directory; // Directory to retrieve the file from
        protected String adminEmail; // Administrator Email
        protected String emailSubj; // Alert Email Subject
        private String importFileName; // Import Base File Name
        private String processDirectory; // Directory where processing are done
        private String logDir; // Directory where log file will be placed
        private boolean enableLog; // Enable Log
        private String costCStartPos;//String containing the cost centre message start positions
        private String costCEndPos;//String containing the cost centre message end positions
        private String jobStartPos;//String containing the job message start positions
        private String jobEndPos;//String containing the job message end positions
        private String personStore;//String containing the job message end positions
        private String defaultgl;
        
        private String ctdeptcraft;

        private File loadDir;
        protected MxLog mxLog;
        private MxEmail email;
        private MxXml mxXml;

        private boolean isProcErr;
        private StringBuffer errMessage;
        private StringBuffer sectionMissing;
        private boolean initialized;
    	private String calendarName;
    	 private String controlAcct;
    	    private String skill;
    	    protected String addSectionMap;
    	   protected String sectionMappingMissing;
    
    	  protected Vector sectionVec;
    
        public NewPplsoftCronTaskCustom() {
                super();

                initialized = false;

                recoveryService = null;
               
                qualifiedInstanceName = null;
                loadDir = null;
                directory = null;
                adminEmail = null;
                emailSubj = null;
                importFileName = null;
                processDirectory = null;
                logDir = null;
                enableLog = false;
                costCStartPos = null;
                costCEndPos = null;
                jobStartPos = null;
                jobEndPos = null;
                personStore = null;
                defaultgl=null;
                

                errMessage = null;
                isProcErr = false;
                sectionMissing=null;
                calendarName=null;
                controlAcct=null;
                skill="TECH-NCT";
                addSectionMap="Section Code and Craft Missing";
                sectionMissing=new StringBuffer();
               
        }

         @Override
		public void init() throws MXException {
                super.init();

                email = new MxEmail(adminEmail);
                mxLog = new MxLog();
                initialized = true;
        }
   
        private static CrontaskParamInfo params[];
        static {
              
                params = null;
                params = new CrontaskParamInfo[14];
                
                params[0] = new CrontaskParamInfo();
                params[0].setName("DIRECTORY");
                params[0].setDescription("CommonCron","Directory where input files from Peoplesoft are placed.");
                
                params[1] = new CrontaskParamInfo();
                params[1].setName("PROCESSDIRECTORY");
                params[1].setDescription("CommonCron","Temp Directory where processing will be done.");
                
                params[2] = new CrontaskParamInfo();
                params[2].setName("ALERTEMAIL");
                params[2].setDescription("CommonCron","Admin email address for notification of error.");
                
                params[3] = new CrontaskParamInfo();
                params[3].setName("IMPORTFILENAME");
                params[3].setDescription("CommonCron","File name of the input file(Include with 'yyyymmpd' for previous day files, exclude file extension)");

                params[4] = new CrontaskParamInfo();
                params[4].setName("ALERTEMAILSUBJ");
                params[4].setDescription("CommonCron","Email Subject for the Alert Email.");

                params[5] = new CrontaskParamInfo();
                params[5].setName("ENABLELOG");
                params[5].setDescription("CommonCron","Enable log output('Y' or 'N').");
                params[5].setDefault("Y");

                params[6] = new CrontaskParamInfo();
                params[6].setName("LOGFILEPATH");
                params[6].setDescription("CommonCron","Log Directory and Filename.");

                params[7] = new CrontaskParamInfo();
                params[7].setName("COSTCSTARTPOS");
                params[7].setDescription("CommonCron","Start Positions for CostC Message");

                params[8] = new CrontaskParamInfo();
                params[8].setName("COSTCENDPOS");
                params[8].setDescription("CommonCron","End Positions for CostC Message");

                params[9] = new CrontaskParamInfo();
                params[9].setName("JOBSTARTPOS");
                params[9].setDescription("CommonCron","Start Positions for Job Message");

                params[10] = new CrontaskParamInfo();
                params[10].setName("JOBENDPOS");
                params[10].setDescription("CommonCron","End Positions for Job Message");

                params[11] = new CrontaskParamInfo();
                params[11].setName("PERSONSTORE");
                params[11].setDescription("CommonCron","File store for Job Messages not effective yet");
                
                params[12] = new CrontaskParamInfo();
                params[12].setName("DEFAULTGL");
                params[12].setDescription("CommonCron","Default GL components");
                
               
                
                params[13] = new CrontaskParamInfo();
                params[13].setName("CTDEPTCRAFT");
                params[13].setDescription("CommonCron","Default GL Last component");
          
        }

   
        private void refreshSettings() {
                integrationLogger.debug("[NewPplsoftCronTask] Entering refreshSettings");

                try {
                      
                        directory = getParamAsString("DIRECTORY");
                        loadDir = new File(directory);
                        adminEmail = getParamAsString("ALERTEMAIL");
                       // //email.setAdmin(adminEmail);
                        emailSubj = getParamAsString("ALERTEMAILSUBJ");

                        // Directory where processing are done
                        processDirectory = getParamAsString("PROCESSDIRECTORY");

                        DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
                        String todayDate = fileDateFormat.format(new Date());
                        logDir = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd", todayDate);
                        enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
                        mxLog.setEnabled(enableLog);
                        mxLog.setLogFilePath(logDir);
                        mxLog.setLogTag(getName());
                        mxLog.createLogFile();
                        
                        // Modify to replace with by previous day's if "yyyymmpd" is specified in import file base name
                        Calendar cal = Calendar.getInstance();
                        cal.add(Calendar.DAY_OF_MONTH,-1);
                                String prevDate = fileDateFormat.format(cal.getTime());
                        importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmpd", prevDate);

                        //Start Position for Cost Centre Message
                        costCStartPos = getParamAsString("COSTCSTARTPOS");

                        //End Position for Cost Centre Message
                        costCEndPos = getParamAsString("COSTCENDPOS");

                        //Start Position for JOB Message
                        jobStartPos = getParamAsString("JOBSTARTPOS");

                        //End Position for JOB Message
                        jobEndPos = getParamAsString("JOBENDPOS");

                        //personStore for Job Messages
                        personStore = getParamAsString("PERSONSTORE");
                        
                        //Get Default GL components
                        defaultgl = getParamAsString("DEFAULTGL");
                        
                        
                        
                        //Get CTDEPT craft
                        ctdeptcraft = getParamAsString("CTDEPTCRAFT");


                        integrationLogger.debug("[NewPplsoftCronTask] Leaving refreshSettings");
                        } catch (Exception exception) {
                        if (integrationLogger.isErrorEnabled()) {
                                integrationLogger.error(exception.getMessage(), exception);
                        }
                }
        }


        private int[] convertStringArraytoIntArray(String stringparam)
          {
                integrationLogger.debug("[NewPplsoftCronTask] Entering convertStringArraytoIntArray()");

                integrationLogger.debug("[NewPplsoftCronTask] convertStringArraytoIntArray(): stringparam read is :" + stringparam);

                //split the string based on the delimiter comma[,] into a String array. The slashes \\ are for escaping the comma
                String[] result= stringparam.split("\\,");
                //System.out.println("string array result is : " + Arrays.asList(result));
                integrationLogger.debug("[NewPplsoftCronTask] convertStringArraytoIntArray(): stringparam read is :" + stringparam);


            int[] intarray;
            intarray = new int[result.length];

            for(int i =0; i<result.length; i++)
            {
                    intarray[i]=Integer.parseInt(result[i]);
                    integrationLogger.debug("[NewPplsoftCronTask] convertStringArraytoIntArray(): Value added to int array at position " + i + " is :" + intarray[i]);
            }

                integrationLogger.debug("[NewPplsoftCronTask] Leaving convertStringArraytoIntArray()");

                return intarray;
          }

        /*
         * Author: YCH
         * Date: 28 Nov 2011
         * Comment: [Standard Cron Task Function]
         *
         * Start cron task
         */
        @Override
		public void start() {
                try {
                        refreshSettings();
                       
                        setSleepTime(0L);
                } catch (Exception exception) {
                        if (integrationLogger.isErrorEnabled()) {
                                integrationLogger.error(exception.getMessage(), exception);
                        }
                }
        }


        private boolean isReqParamSet() {
                if (adminEmail == null)
                        return false;
                
                if (processDirectory == null)
                        return false;
                if (importFileName == null)
                        return false;
                if (directory == null)
                        return false;
                if (costCStartPos == null)
                        return false;
                if (costCEndPos == null)
                        return false;
                if (jobStartPos == null)
                        return false;
                if (jobEndPos == null)
                        return false;
                if (personStore == null)
                        return false;
                if (importFileName == null)
                        return false;
                if (defaultgl == null)
                    return false;
                

                return true;
        }

   
        private String genEmail(Exception e) {

                // Form Email Message
                String emailMsg = "Date: " + new Date() + "\n";
                emailMsg += "Error in CronTask: " + getName() + "\n";
                emailMsg += "Error Message: " + e.getMessage() + "\n";
                emailMsg += "Detail:\n";
                emailMsg += e.toString() + "\n";
                StackTraceElement element[] = e.getStackTrace();
                for (int i = 0; i < element.length; i++) {
                        emailMsg += "\tat " + element[i].toString() + "\n";
                }

                return emailMsg;
        }

        @Override
		public CrontaskParamInfo[] getParameters() throws MXException,
                        RemoteException {
                return params;
        }

        @Override
		public void cronAction() {
             
                try {
                      
                        refreshSettings();
                        if (isReqParamSet()) {
                        		processFolderData();
                        		processPersonStore();
                               

                        } else {
                                mxLog.writeLog(" cronAction(): Required parameters not set.");
                                throw new Exception("Required parameters not set.");
                        }

                } catch (Exception e) {
                		String emailContent = genEmail(e);
                        email.send(emailSubj, emailContent);
                        mxLog.writeLog("Email Sent: \n" + emailContent);

                        stop();
                }

                integrationLogger.debug("[NewPplsoftCronTask] Leaving cronAction");
                mxLog.writeLog(" cronAction(): End CronTask Action");
        }

// Processing the person data from pplsoft
        public void processPersonStore() throws Exception {

                integrationLogger.debug("[NewPplsoftCronTask] Entering processPersonStore");
                mxLog.writeLog(" processPersonStore(): Start processPersonStore");

                if(personStore != null) {

                        //process the personStore
                	 sectionVec=new Vector();
                     sectionVec.clear();
                     StringBuffer personStoreSectionMiss=new StringBuffer();
                        ArrayList store = new ArrayList();//to store future effective messages
                        Collection col = parseFlatFile(personStore, store);

                        processPersonData(col);
           
               for(int i=0;i<=sectionVec.size()-1;i++)
               {
            	   sectionMappingMissing="Section code is missing from Mapping table. Please create section code in Master Mapping application:"+sectionVec.get(i);
            	   personStoreSectionMiss.append(sectionMappingMissing);
            	   personStoreSectionMiss.append(NEWLINE);
               }
               if(sectionVec.size()>0)
               {
               email.send(addSectionMap,personStoreSectionMiss.toString());
               }
                  
                        boolean append = false;
                        writeTransRec(store, append);

        }
        else{
                mxLog.writeLog(" processPersonStore(): Unable to read input file '" + personStore + "'");
            throw new Exception("[" + getName() + "] Unable to read input file '" + personStore + "'");
        }

        }
//Future person data will be stored into personStore txt file.
        public void writeTransRec(ArrayList lst, boolean append) throws IOException {

                integrationLogger.debug("[NewPplsoftCronTask] Entering writeTransRec");
                mxLog.writeLog(" writeTransRec(): Start writeTransRec");

                FileWriter fWriter;
                        BufferedWriter bWriter;

                if(append){
                        mxLog.writeLog(" writeTransRec(): append is true, will append to file");
                        fWriter = new FileWriter(personStore, append);//the parameter true is for appending the file personStore instead of overwriting it
                        }
                else{
                        mxLog.writeLog(" writeTransRec(): append is false, create and write new file");
                        //delete the file and create a new one with the same filename
                        File filePersonStore = new File(personStore);
                        filePersonStore.delete();

                        fWriter = new FileWriter(personStore);

                        }

                        bWriter = new BufferedWriter(fWriter);


                                String writeline = new String();

                        for (int i = 0; i < lst.size(); i++) {
                            writeline = (String) lst.get(i);
                            mxLog.writeLog(" writeTransRec(): string being written at " +  i + " is: " + writeline);

                            bWriter.write(writeline);
                                bWriter.newLine();
                        }

                        bWriter.close();
                        fWriter.close();

                        }



    
        public void processFolderData() throws Exception {

           
            SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
           File afile[] = loadDir.listFiles(filter);
           
                //Start of check control totals
                int fileexists = 0;
                
            	if(afile != null) {
            		
	            	for (int j = 0; j < afile.length; j++) 
	            	{
	            		if(afile[j].getName().startsWith(importFileName)){
		            		fileexists = 1;
		            		mxLog.writeLog("|*****Filename: "+afile[j].getName());
		            	}
            		}
	            		
            	}
            	
            	if(fileexists == 0){
            		integrationLogger.debug("Unable to find the People soft interface txt file.");
	            	}
              
                //Processing of File array
                if (afile != null && afile.length != 0) {
                	 sectionVec=new Vector();
                     sectionVec.clear();

                        int fileprocessed = 0;
                       
                        for (int j = 0; j < afile.length; j++) {
                        	errMessage = new StringBuffer();
                        	
                                errMessage = null;
                                isProcErr = false;

                                if(afile[j].getName().startsWith(importFileName)){

                                recoveryService = new RecoveryService(afile[j]);
                                recoveryService.startRecovery();

                                try {
                                        String file = processDirectory + afile[j].getName();
                                        MxFileCopy.fileCopy(afile[j].toString(), processDirectory + afile[j].getName());
                                         ArrayList storeFutureRecord = new ArrayList();//to store future effective messages
                                                 //Start of check control totals
                                                BufferedReader flatfileReader;
                                                
                                                flatfileReader = new BufferedReader(new FileReader(file));
                                                
                                                LineNumberReader reader  = new LineNumberReader(new FileReader(file));
                                             
								                String curLine;
								                if((curLine = flatfileReader.readLine()) != null)
								                {
								                        String recHeadertype;//to get the record type. If it is a header line it will not be processed.
								                        int recordCntHeader;//to get record count in file
								                        int lineCount = 0;//count of lines in file 
								                        
								                        if(curLine.length() != 0){
								                        recHeadertype = curLine.substring(0, 1);
								                        recordCntHeader = Integer.parseInt(curLine.substring(15, 21).trim());
								                      
								                        if(recHeadertype.equals("0"))
								                        {
									                       
															while (reader.readLine()!= null) {}
															lineCount = reader.getLineNumber(); 
															reader.close();
															
									                    }
									                    
									                    //check if control totals match
									                    if(lineCount==(recordCntHeader+1)){
									                    	//header record adds one line to count
										                 
										                    Collection col = parseFlatFile(file, storeFutureRecord);

			                                                processPersonData(col);
			                                           
			                                               for(int i=0;i<=sectionVec.size()-1;i++)
			                                               {
			                                                sectionMappingMissing="Section code is missing from Mapping table. Please create section code in Master Mapping application:"+sectionVec.get(i);
			                                            	sectionMissing.append(sectionMappingMissing);
			                                            	sectionMissing.append(NEWLINE);
			                                               }
			                                              if(sectionVec.size()>0)
			                                              {
			                                            		  email.send(addSectionMap,sectionMissing.toString());
			                                              }
			                                               col.clear();
										                }
										                else{//record in log and send out email of file with incorrect control totals
										                
										                	mxLog.writeLog(" processFolderData(): file with incorrect control totals - " + file);
										                	String emailCtrlTotal = "Date: " + new Date() + "\n";
											                emailCtrlTotal += "Error in CronTask: " + getName() + "\n";
											                emailCtrlTotal += "Error Message: File with incorrect control totals - " + file + "\n";
										                	
           									                email.send(emailSubj, emailCtrlTotal);
                        								    mxLog.writeLog("Email Sent: \n" + emailCtrlTotal);
											                
											            }
								                        
							                        	}
                                            	}
               									
                                                File fExtractedFile = new File(file);
                                                fExtractedFile.delete();

                                                //Write future transactions to personStore
                                                boolean append = true;
                                                writeTransRec(storeFutureRecord, append);
                                           

                                } finally {
                                        try {
                                                recoveryService.endRecovery();
                                        } catch (Exception e) {
                                             e.printStackTrace();
                                        }
                                }
                        }
                        else{
                                integrationLogger.info("[" + getName() + "] '" + afile[j].getName() + "' not processed as it does not fit importfilename");
                                mxLog.writeLog(" processFolderData(): '"        + afile[j].getName() + "' not processed as it does not fit importfilename");
                                }

                                fileprocessed++;

                                if (isProcErr) {
                                        String emailMsg = "Date: " + new Date() + "\n";
                                        emailMsg += "Error in CronTask: " + getName() + "\n";
                                        emailMsg += "File Processing: " + afile[j].getName() + NEWLINE;
                                        emailMsg += errMessage.toString();

                                        email.send(emailSubj, emailMsg);
                                        mxLog.writeLog("Email Sent:\n" + emailMsg);
                                }
                        }

                        if (fileprocessed != 0) {
                                mxLog.writeLog(" processFolderData(): " + fileprocessed + " file(s) processed.");
                                integrationLogger.info("[" + getName() + "] " + fileprocessed + " file(s) processed.");
                        } else {
                                mxLog.writeLog(" processFolderData(): No files was processed!");
                             
                        }
                } else {
                        mxLog.writeLog(" processFolderData(): Unable to read input file '" + importFileName + "'");
                        
                        String emailMsg = "Date: " + new Date() + "<ul>";      
                        emailMsg += "<li>File Processing: " + importFileName + "</li>" + "</ul>" +"<ul>";
                        emailMsg += "<li>Error in CronTask: " + getName() + "</li>" + "</ul>" +"<ul>";
                        emailMsg += "<li>processFolderData(): Unable to read input file '" + importFileName + "'" + "</li>" + "</ul>" +"<ul>";
                        emailMsg += "<li>Mentioned File cannot be processed. Please contact your System Administrator to take a look on the file"  + "</li>" + "</ul>" +"<ul>";

                        CommTemplateSetRemote commTemplateSet = (CommTemplateSetRemote)MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
        	            commTemplateSet.setWhere("TEMPLATEID='PPLSOFTERROR'");
        	            commTemplateSet.reset();
        	            mxLog.writeLog("TEMPLATEID---> "+commTemplateSet.getMbo(0).getString("TEMPLATEID"));
        	            CommTemplateRemote tempRemote = (CommTemplateRemote)commTemplateSet.getMbo(0);
        	            String toMail = tempRemote.getString("TOLIST");
        	            String fromMail = tempRemote.getString("SENDFROM");
        	            String ccTo = tempRemote.getString("CCLIST");
        	            String bccTo = tempRemote.getString("BCCLIST");
        	            String subject = tempRemote.getString("SUBJECT");
        	            String message = tempRemote.getString("MESSAGE");
        	            String replyTo = tempRemote.getString("REPLYTO");
        	            message = message.replace("$msgdetails",emailMsg );
        	            toMail = tempRemote.convertSendTo("COMMTMPLT_TO", (MboRemote)tempRemote);
        	            ccTo = tempRemote.convertSendTo("COMMTMPLT_CC", (MboRemote)tempRemote);
        	            bccTo = tempRemote.convertSendTo("COMMTMPLT_BCC", (MboRemote)tempRemote);
        	            mxLog.writeLog("-----Before Sending Mail-----");
        	            mxLog.writeLog("TO ---> "+toMail);
        	            mxLog.writeLog("ccTo ---> "+ccTo);
        	            MXServer.sendEMail(toMail, ccTo, bccTo, fromMail, subject, message, replyTo, null, null);
        	            mxLog.writeLog("-----After Sending Mail-----");
        	            
                        mxLog.writeLog("Email Sent:\n" + emailMsg);
                     
                }
                integrationLogger.debug("[NewPplsoftCronTask] Leaving processFolderData");
                mxLog.writeLog(" processFolderData(): Leaving Processing Data");
        }
        
        


        private Collection parseFlatFile(String file, ArrayList store) throws IOException
        {
               
                BufferedReader flatfileReader;
                Collection col = new Vector();

                //Declare int arrays for converting to get the positions of the fields needed in the messages JOB and SNPCOSTC
                int[] jobFieldFrom;
                int[] jobFieldTo;
                int[] costcFieldFrom;
                int[] costcFieldTo;


                //to call the function to convert paramstring array to int array
                jobFieldFrom = convertStringArraytoIntArray(jobStartPos);
                jobFieldTo = convertStringArraytoIntArray(jobEndPos);
                costcFieldFrom = convertStringArraytoIntArray(costCStartPos);
                costcFieldTo = convertStringArraytoIntArray(costCEndPos);

                flatfileReader = new BufferedReader(new FileReader(file));
                String curLine;
                
                while((curLine = flatfileReader.readLine()) != null)
                {
                        String rec_type;//to get the record type. If it is a header line it will not be processed.
                        
                        if(curLine.length() != 0){
                        rec_type = curLine.substring(0, 1);
                        mxLog.writeLog(" parseFlatFile(): rec_type is: " + rec_type);

                        if(rec_type.equals("1"))//to ignore the first line if it is a header
                          {
                              
                                String transId = curLine.substring(TRANS_ID_BEGIN_INDEX, TRANS_ID_END_INDEX).trim();
                                Vector vector = null;
                                if (transId.equals(TRANS_ID_JOB)) {

                                        //to check if new effective date is in the future
                                        int effectiveDate = Integer.parseInt(curLine.substring(134, 142).trim());
                                        mxLog.writeLog(" parseFlatFile(): effective Date is :" + effectiveDate);

                                        if(effectiveDate>Integer.parseInt(getDateTime())){
                                                        mxLog.writeLog(" parseFlatFile(): Job message  is in the future Date ");
                                                        store.add(curLine);
                                                }
                                        else{
                                        	    System.out.println("ENtering if condition for TRANS_ID_JOB"); 
                                                vector = processMsg(curLine, jobFieldFrom, jobFieldTo);
                                                System.out.println("ENtering if condition for TRANS_ID_JOB-->"+vector);
                                                } 

                                }
                                 if (transId.equals(TRANS_ID_SNPCOSTC)) {
                                        vector = processMsg(curLine, costcFieldFrom,costcFieldTo);
                                        System.out.println("ENtering if condition for TRANS_ID_SNPCOSTC");
                                        System.out.println("ENtering if condition for TRANS_ID_SNPCOSTC-->"+vector);
                                } else {
                                	    System.out.println("ENtering else condition for TRANS_ID_SNPCOSTC");
                                        integrationLogger.debug("[NewPplsoftCronTask] Invalid transId: " + transId + ", cannot handle this record");
                                        mxLog.writeLog(" parseFlatFile(): Invalid transId: " + transId + ", cannot handle this record");
                                }
                                if (vector != null && vector.size() > 0)
                                {
                                        // Add to a collection
                                        col.add(vector);
                                        System.out.println("vector.size()->"+vector.size());
                                        System.out.println("COL-->"+col);
                                        System.out.println("VECTOR-->"+vector);
                                }
                        }

                        }
                }
                return col;
        }

        public String getDateTime()
        {
                DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
                Date date = new Date();
                return dateFormat.format(date);
        }

         private Vector processMsg(String msg, int[] startPos, int[] endPos) {

        Vector vec = new Vector();
        for (int i = 0; i < startPos.length; i++)
        {
                if (startPos[i] > msg.length())
                {
                	    System.out.println("StartPOs[i]: " + startPos[i]);
                        isProcErr = true;
                    String errMsg = NEWLINE + "Line:" + msg + NEWLINE;
                    errMsg += "Error Message: The field's start|end index is larger than message's total length: FieldFrom:["
                                        + startPos[i]   + "] FieldTo:[" + endPos[i] + "]" + NEWLINE;
                                errMessage.append(errMsg);
                        mxLog.writeLog("[" + getName() + "][ERROR] Invalid line:'" + msg+ "'");
                        break;
                }

                if (endPos[i] > msg.length())
                {
                	    System.out.println("endPos[i]: " + endPos[i]);
                        endPos[i] = msg.length();
                }

                String fieldValue = msg.substring(startPos[i], endPos[i]);
                vec.add(fieldValue.trim());
                System.out.println("Field value " + fieldValue);
                System.out.println("startPos " + startPos[i]);
                System.out.println("EndPOs " + endPos[i]);
                System.out.println("VEC--> " + vec);
                
        }
        
      //code to print out vector for debugging
        
        Iterator j=vec.iterator();
        
        while(j.hasNext())
        {
        	System.out.println("While processMsg(): Element in vector is: " + j.next());
        }
        
        return vec;
        
         }



 
//Creating the person and labor calendar and labor crft rate

        public void processPersonData(Collection personData)throws MXException,RemoteException
        {
        	try
        	{
        	mxLog.writeLog("|-----------------------------Peoplesoft file processing starts here-----------------------------|");	
        	Iterator parsedPersonData=personData.iterator();
        	
        	while(parsedPersonData.hasNext())
        	{
        		Vector getCurrentSetData=(Vector) parsedPersonData.next();
        		String f_headerInfo=(String) getCurrentSetData.elementAt(1);
        		String f_personID="";
        		String f_ic="";
        		String f_department="";
        		String f_title="";
        		//String apptTyC="";
        		String f_section="";
        		String f_name="";
        		String f_appt_ty_c="";
        		String f_glacct="";
        		String GLACCOUNT="";
        		String lob="";
        		String costcenter="";
        		String lobcostcenter="";
        		//String sectionHead="";
				//String engineer="";
				//String engManager="";
				//String sto="";
        		
        		if(f_headerInfo.equalsIgnoreCase("JOB"))
        		{
        			f_personID=(String) getCurrentSetData.elementAt(9);
        			f_ic=(String) getCurrentSetData.elementAt(5);
        			f_department=(String) getCurrentSetData.elementAt(7);
        			f_title=(String) getCurrentSetData.elementAt(40);
        			//apptTyC=(String) getCurrentSetData.elementAt(26);
        			f_section=(String) getCurrentSetData.elementAt(16);
        			f_name=(String) getCurrentSetData.elementAt(14);
        			f_appt_ty_c=(String) getCurrentSetData.elementAt(26);
        			
        			mxLog.writeLog("|-----------------------------Job Record-----------------------------|");
        			mxLog.writeLog("|*****personID: "+f_personID+" -> IC: "+f_ic+" -> department: "+f_department+" -> section: "+f_section+" -> appt_ty_c: "+f_appt_ty_c+" -> name: "+f_name+" -> Title: "+f_title);
        			
        			MboSetRemote personSet=MXServer.getMXServer().getMboSet("PERSON", getRunasUserInfo());
        			laborSectionMap(f_headerInfo,f_personID,f_ic,f_department,f_section,defaultgl);
        			
        		}
        		if(f_headerInfo.equalsIgnoreCase("SNPCOSTC"))
        		{
        			f_personID=(String) getCurrentSetData.elementAt(8);
        			f_ic=(String) getCurrentSetData.elementAt(5);
        			f_department=(String) getCurrentSetData.elementAt(6);
        			f_section=(String) getCurrentSetData.elementAt(10);
        			f_glacct=(String) getCurrentSetData.elementAt(11);
        			lob=f_glacct.substring(3,6);
        			costcenter=f_glacct.substring(f_glacct.length()-4);
        			String GLformat = defaultgl;
        			
        		    GLACCOUNT = GLformat.replaceFirst("\\?\\?\\?", lob).replaceFirst("\\?\\?\\?\\?", costcenter);
        			
        			mxLog.writeLog("|-----------------------------SNPCOSTC Record-----------------------------|");
        			mxLog.writeLog("|*****personID: "+f_personID+" -> IC: "+f_ic+" -> department: "+f_department+" -> section: "+f_section);
        			mxLog.writeLog("|*****GLaccount: "+f_glacct+" -> CostCenter: "+f_glacct.substring(f_glacct.length()-4)+" -> LOB: "+f_glacct.substring(3,6));
        			mxLog.writeLog("|*****Formatted GLaccount: "+GLACCOUNT);
        			
        			MboSetRemote personSet=MXServer.getMXServer().getMboSet("PERSON", getRunasUserInfo());
        			laborSectionMap(f_headerInfo,f_personID,f_ic,f_department,f_section,GLACCOUNT);
        			
        		}
        		
            	   MboSetRemote mxDepartmentSet=MXServer.getMXServer().getMboSet("MAXEXTLISTVAL", getRunasUserInfo());
            	   SqlFormat mxDepartmentSql=new SqlFormat("EXTSYSNAME='SMS' and IFACECONTROL='MXDEPARTMENTS' and value='"+f_department+"'");
            	   mxDepartmentSet.setWhere(mxDepartmentSql.format());
            	   mxDepartmentSet.reset();
            	   
            	   if(!mxDepartmentSet.isEmpty())
            	   {
            		mxLog.writeLog("|*****The department "+f_department+" is valid in integration control");
                            			
        			MboSetRemote laborSet=MXServer.getMXServer().getMboSet("LABOR", getRunasUserInfo());
        			
        			MboSetRemote personSet=MXServer.getMXServer().getMboSet("PERSON", getRunasUserInfo());
        			SqlFormat personSql=new SqlFormat("PERSONID=:1");
        			personSql.setObject(1, "PERSON", "PERSONID",f_personID);
        			personSet.setWhere(personSql.format());
        			personSet.reset();
        		
					//Updation of existing person details
					if(!personSet.isEmpty() && personSet!=null)
        			{
						mxLog.writeLog("|*****Updating the "+f_personID+" details");
						
        				String status=personSet.getMbo(0).getString("STATUS");
        				        				       				
        				sectionMap(f_headerInfo, f_personID, f_ic, f_department, f_section, f_title, f_appt_ty_c, f_name, personSet);
        				String appointType=personSet.getMbo(0).getString("appt_ty_c");      				   				
    			        if(status.equalsIgnoreCase("ACTIVE") && (appointType.equalsIgnoreCase("J") || appointType.equalsIgnoreCase("S")))
        				{
        			       	createLabor(laborSet,f_personID,f_section,f_department,appointType);	
        				}
        				/*else if(status.equalsIgnoreCase("ACTIVE") && !personSet.getMbo(0).getString("appt_ty_c").equalsIgnoreCase("J"))
        				{
        					mxLog.writeLog("|*****The "+f_personID+" is not JO officer");
        				}*/
        				calendarName=createCalendar(f_personID);
        			}
					else
        			{
						mxLog.writeLog("|*****The "+f_personID+" is not exists in people application");    					
						sectionMap(f_headerInfo, f_personID, f_ic, f_department, f_section, f_title, f_appt_ty_c, f_name, personSet);
						
						calendarName=createCalendar(f_personID);
        				
        				String appointmentType=personSet.getMbo(0).getString("appt_ty_c");
        				mxLog.writeLog("|*****appointmentType: "+appointmentType);
        				if (appointmentType.equalsIgnoreCase("J"))
    					{
        				
        				createLabor(laborSet,f_personID,f_section,f_department,appointmentType);
        				}        				
        			}
            	   } 
            	   else
            	   {
            		   mxLog.writeLog("|*****The department "+f_department+" is not valid  in integration control");
            	   }
           
        	} 
        	mxLog.writeLog("|-----------------------------Peoplesoft file processing ends-----------------------------|");
        	}
        	catch(Exception e)
        	{
        		e.printStackTrace();
        	}
        	
        }
        
        //Creation/updation of Labor section mapping based on section which received from peoplesoft file
        public void laborSectionMap(String headerInfo, String personID, String ic, String department, String section, String GLAccount) throws MXException,RemoteException
        {
        	mxLog.writeLog("||**********||Creation/updation of labor section map||**********||");
        	mxLog.writeLog("|*****headerInfo: "+headerInfo+" -> personID: "+personID+" -> IC: "+ic+" -> department: "+department+" -> section: "+section+" -> Glaccount: "+GLAccount);
        	MboSetRemote labSectionMapSet=MXServer.getMXServer().getMboSet("SECTIONMAP", getRunasUserInfo());
	        SqlFormat labSectionMapSql=new SqlFormat("SECTION=:1");
	        labSectionMapSql.setObject(1, "SECTIONMAP", "SECTION", section);
	        labSectionMapSet.setWhere(labSectionMapSql.format());
	        labSectionMapSet.reset();
	        
	        //String labSkill=labSectionMapSet.getMbo(0).getString("SKILL");
	        //String labContAcct=labSectionMapSet.getMbo(0).getString("CONTACCT");
	        
			if(labSectionMapSet.isEmpty())            				
			{
				System.out.println("Entering if else Cond if sectionMapSet not present and adding sectionmap");
				mxLog.writeLog("|*****"+section+" is not present in Labor section Map");
				MboRemote sectionMapMbo=labSectionMapSet.addAtEnd();
				sectionMapMbo.setValue("SECTION", section,2L);
				sectionMapMbo.setValue("SKILL", skill,2L);
				sectionMapMbo.setValue("CONTACCT", GLAccount,2L);
				labSectionMapSet.save();
			}
			else if(!labSectionMapSet.isEmpty() && headerInfo.equalsIgnoreCase("JOB"))        				
			{
				mxLog.writeLog("|*****JOB Updating details for existing "+section+" in Labor section Map");
				labSectionMapSet.getMbo(0).setValue("SKILL", skill,2L);
				labSectionMapSet.save();
			}
			else if(!labSectionMapSet.isEmpty() && !headerInfo.equalsIgnoreCase("JOB"))            				
			{
				mxLog.writeLog("|*****COSTCC Updating details for existing "+section+" in Labor section Map");
				labSectionMapSet.getMbo(0).setValue("SKILL", skill,2L);
				labSectionMapSet.getMbo(0).setValue("CONTACCT", GLAccount,2L);
				labSectionMapSet.save();
			}
			
        }

        //Get details from labor section map and set those details to person
        public void sectionMap(String headerInfo, String personID, String ic, String department, String section, String title, String appt_ty_c, String name, MboSetRemote personSet) throws MXException,RemoteException
        {
        	mxLog.writeLog("||**********||Fetching values from labor section map||**********||");
        	//mxLog.writeLog("|*****section Map values to be passed");
        	mxLog.writeLog("|*****headerInfo: "+headerInfo+" -> personID: "+personID+" -> IC: "+ic+" -> department: "+department+" -> section: "+section);
        	mxLog.writeLog("|*****Count of personset: "+personSet.count());
        	
        	
        	MboSetRemote sectionMapSet=MXServer.getMXServer().getMboSet("SECTIONMAP", getRunasUserInfo());
	        SqlFormat sectionMapSql=new SqlFormat("SECTION=:1");
	        sectionMapSql.setObject(1, "SECTIONMAP", "SECTION", section);
	        sectionMapSet.setWhere(sectionMapSql.format());
	        sectionMapSet.reset();
	        
	        
	        if(!sectionMapSet.isEmpty() && sectionMapSet!=null && personSet.count() > 0)
	        {
				mxLog.writeLog("|*****Section: "+section+" -> Sectionhead: "+sectionMapSet.getMbo(0).getString("SECTIONHEAD")+" -> Engineer: "+sectionMapSet.getMbo(0).getString("ENGINEER")+" -> EngManager: "+sectionMapSet.getMbo(0).getString("ENGINEERINGMANAGER")+" -> STO: "+sectionMapSet.getMbo(0).getString("STO"));
				String pplic=personSet.getMbo(0).getString("IC");
				String ppldept=personSet.getMbo(0).getString("DEPARTMENT");
	        	String pplsh=personSet.getMbo(0).getString("SECTIONHEAD");
	        	String pplengmanger=personSet.getMbo(0).getString("ENGMANAGER");
	        	String ppleng=personSet.getMbo(0).getString("ENGINEER");
	        	String pplsto=personSet.getMbo(0).getString("STO");
				if(pplic.isEmpty() || !pplic.equalsIgnoreCase(ic))
				{
					mxLog.writeLog("|*****updating IC#"+ic+" from peoplesoft application");
					personSet.getMbo(0).setValue("IC", ic);
					//personSet.save();
				}
				if(headerInfo.equalsIgnoreCase("JOB")) 
	        	{
					personSet.getMbo(0).setValue("APPT_TY_C",appt_ty_c);
					personSet.getMbo(0).setValue("DISPLAYNAME", name);
					personSet.getMbo(0).setValue("TITLE", title);
	        	}
				if((ppldept==null || ppldept=="") || (pplsh==null || pplsh=="") || (pplengmanger==null || pplengmanger=="") || (ppleng==null || ppleng=="")|| (pplsto==null || pplsto==""))
				{
		        	personSet.getMbo(0).setValue("SECTIONHEAD", sectionMapSet.getMbo(0).getString("SECTIONHEAD"));
		        	personSet.getMbo(0).setValue("ENGINEER", sectionMapSet.getMbo(0).getString("ENGINEER"));
		        	personSet.getMbo(0).setValue("ENGMANAGER", sectionMapSet.getMbo(0).getString("ENGINEERINGMANAGER"));
		        	personSet.getMbo(0).setValue("STO", sectionMapSet.getMbo(0).getString("STO"));
				}
				personSet.getMbo(0).setValue("DEPARTMENT", department);
								
	        	personSet.save();
	        }
        	
	        else if(!sectionMapSet.isEmpty() && sectionMapSet!=null && personSet.count() == 0)
	        {
	        	String sectionHead=sectionMapSet.getMbo(0).getString("SECTIONHEAD");
	        	String engineer=sectionMapSet.getMbo(0).getString("ENGINEER");
	        	String engManger=sectionMapSet.getMbo(0).getString("ENGINEERINGMANAGER");
	        	String sto=sectionMapSet.getMbo(0).getString("sto");
	        	
	        	MboRemote personMbo=personSet.addAtEnd();
				personMbo.setValue("PERSONID", personID);
				personMbo.setValue("IC", ic);
				personMbo.setValue("DEPARTMENT", department);
				personMbo.setValue("TITLE", title);
				personMbo.setValue("APPT_TY_C", appt_ty_c);
				personMbo.setValue("ENGINEER", engineer);
				personMbo.setValue("SECTIONHEAD", sectionHead);
				personMbo.setValue("ENGMANAGER", engManger);
				personMbo.setValue("STO", sto);
				personMbo.setValue("DISPLAYNAME", name);
	        	
	        	personSet.save();
	        	
	        	mxLog.writeLog("|*****"+personSet.getMbo(0).getString("PERSONID")+" record has been created successfully");
	        }
	        
        }
        
		// Creation/updation of labor based on person    
        private void createLabor(MboSetRemote laborSet,String personID,String section, String department, String apptType ) throws MXException,RemoteException
        {
        	try
        	{
        	mxLog.writeLog("||**********||Creation/updation of labor based on person||**********||");
        	SqlFormat laborSql=new SqlFormat("LABORCODE=:1 and status='ACTIVE'");
        	laborSql.setObject(1, "LABOR", "LABORCODE", personID);
        	laborSet.setWhere(laborSql.format());
        	laborSet.reset();
        
			if (!laborSet.isEmpty() && laborSet != null && (apptType.equalsIgnoreCase("J") || apptType.equalsIgnoreCase("S")))
        	{
				mxLog.writeLog("|*****Updating for existing labor");
				//String labStatus=laborSet.getMbo(0).getString("STATUS");
				laborSet.getMbo(0).setValue("SECTION", section);
        		laborSet.save();
        		if(apptType.equalsIgnoreCase("J"))
        		{
        			createLaborCraftRate(personID,section,department);
        		}        		
        	}
        	else if (laborSet.isEmpty() && !apptType.equalsIgnoreCase("S"))
        	{
        		mxLog.writeLog("|*****Creating new labor");
        		MboRemote laborMbo = laborSet.addAtEnd();
        		laborMbo.setValue("LABORCODE", personID,2L);
        		laborMbo.setValue("STATUS", "ACTIVE",MboConstants.NOACCESSCHECK);
        		laborMbo.setValue("ORGID", "PSAST",MboConstants.NOACCESSCHECK);
        		laborMbo.setValue("SECTION", section);
        		
        		calendarName=createCalendar(personID);
        		laborMbo.setValue("CALNUM",calendarName);
        		laborSet.save();
        		mxLog.writeLog("createLabor():  Labor Record created.");
        		System.out.println("Labor Record created.");
        		createLaborCraftRate(personID,section,department);
        				
            	}
			}
			
			catch(Exception e)
        	{
        		e.printStackTrace();
        		
        	}
        	
        }
 
//Creation/updation of the createLaborCraftRate based on labor information       
        public void createLaborCraftRate(String personID,String section,String department)throws MXException,RemoteException
        {	
        	try
        	{
        		mxLog.writeLog("||**********||Creation/updation of the createLaborCraftRate||**********||");
        		 System.out.println("Entering Create Laborcraft Information");	     		
        	        MboSetRemote sectionMapSet=MXServer.getMXServer().getMboSet("SECTIONMAP", getRunasUserInfo());
        	        SqlFormat sectionMapSql=new SqlFormat("SECTION=:1");
        	        sectionMapSql.setObject(1, "SECTIONMAP", "SECTION", section);
        	        sectionMapSet.setWhere(sectionMapSql.format());
        	        sectionMapSet.reset();
        	        if(!sectionMapSet.isEmpty() && sectionMapSet!=null)
        	        {
        	        	
        	        	controlAcct=sectionMapSet.getMbo(0).getString("CONTACCT");
        	        	skill=sectionMapSet.getMbo(0).getString("SKILL");
        	        	System.out.println("!sectionMapSet.isEmpty() controlAcct---> "+controlAcct);
        	        	System.out.println("!sectionMapSet.isEmpty() skill---> "+skill);
        	        
        	        /* 09-09-2020: BCT Modification Starts
        	         * Oracle to SQL Conversion
        	         */
        	        
        	         if(!controlAcct.equalsIgnoreCase("")&& controlAcct!=null)
        	        {
        	        	MboSetRemote laborSet=MXServer.getMXServer().getMboSet("LABOR", getRunasUserInfo());
        	         	SqlFormat laborSql=new SqlFormat("LABORCODE=:1");
        	         	laborSql.setObject(1, "LABOR", "LABORCODE", personID);
        	         	laborSet.setWhere(laborSql.format());
        	         	laborSet.reset();
        	        	
        	        	MboSetRemote laborCraftRateSet=laborSet.getMbo(0).getMboSet("LABORCRAFTRATE");
        	        	
        	        	
        	        	if(!laborCraftRateSet.isEmpty())
        	        	{
        	        		        	        		
        	        		if(laborCraftRateSet.count()>1)
        	        		{
        	        			mxLog.writeLog("|*****"+personID+" has more than 1 craft");
        	        			deleteCraft(personID,skill,laborCraftRateSet);
        	        		}
        	        		
        	        		settingCTdeptLabcraft(personID,section,department);
        	        		calendarName=createCalendar(personID);
        	        		
            	        	//laborCraftRateSet.save();  	
            	        }
        	        	else if(laborCraftRateSet.isEmpty())
        	        	{
        	        	MboRemote laborCraftRateMbo=laborCraftRateSet.addAtEnd();
        	     
        	        	laborCraftRateMbo.setValue("LABORCODE", personID,2L);
        	        	laborCraftRateMbo.setValue("CONTROLACCOUNT",controlAcct,MboConstants.NOVALIDATION_AND_NOACTION);
        	        	laborCraftRateMbo.setValue("CRAFT", skill,MboConstants.NOACCESSCHECK);
        	        	laborCraftRateMbo.setValue("DEFAULTCRAFT","1",2L);
        	        	laborCraftRateMbo.setValue("INHERIT","1",2L);  
        	        	laborCraftRateSet.save();
        	        	
        	        	settingCTdeptLabcraft(personID,section,department);
        
        	        }
            
        }
       
        else
        {
        	if(!sectionVec.contains(section))
        	{
        	sectionVec.add(section);
        	}
        	
        	mxLog.writeLog(sectionMappingMissing);
        	
        }
        	}
        	               
        	}
        	catch(Exception e)
        	{
        		e.printStackTrace();
        	}
        	finally
      	  {
      		MXServer.getMXServer().getDBManager().freeConnection(getRunasUserInfo().getConnectionKey());
      	  
      	  }
        	
        }
        
        public void settingCTdeptLabcraft(String personID,String section,String department)throws MXException,RemoteException
        {	
        	try
        	{
        		mxLog.writeLog("||**********||updation of the settingCTdeptLabcraft||**********||");
        			        	
        		MboSetRemote laborSet=MXServer.getMXServer().getMboSet("LABOR", getRunasUserInfo());
	         	SqlFormat laborSql=new SqlFormat("LABORCODE=:1");
	         	laborSql.setObject(1, "LABOR", "LABORCODE", personID);
	         	laborSet.setWhere(laborSql.format());
	         	laborSet.reset();
	        	
	        	MboSetRemote laborCraftRateSet=laborSet.getMbo(0).getMboSet("LABORCRAFTRATE");
	        	
        		MboSetRemote mxCTDepartmentSet=MXServer.getMXServer().getMboSet("MAXEXTLISTVAL", getRunasUserInfo());
         	    SqlFormat mxCTDepartmentSql=new SqlFormat("EXTSYSNAME='SMS' and IFACECONTROL='CTDEPARTMENTS' and value='"+department+"'");
         	    mxCTDepartmentSet.setWhere(mxCTDepartmentSql.format());
         	    mxCTDepartmentSet.reset();
         	   
         	   if(!mxCTDepartmentSet.isEmpty() && laborCraftRateSet.count()>0)
         	   {
         		 laborCraftRateSet.getMbo(0).setValue("CRAFT", ctdeptcraft,MboConstants.NOACCESSCHECK);
         		 laborCraftRateSet.getMbo(0).setValue("CONTROLACCOUNT", controlAcct,MboConstants.NOACCESSCHECK);
         		 laborCraftRateSet.save();
         	   }
         	   else if(mxCTDepartmentSet.isEmpty() && laborCraftRateSet.count()>0)
         	   {
         		   mxLog.writeLog("|*****The "+department+" is not valid in the list od CTDEPARTMENT in integration control");
         		   laborCraftRateSet.getMbo(0).setValue("LABORCODE", personID,2L);
         		   laborCraftRateSet.getMbo(0).setValue("CRAFT", skill,MboConstants.NOACCESSCHECK);
         		   laborCraftRateSet.getMbo(0).setValue("DEFAULTCRAFT","1",2L);
         		   laborCraftRateSet.getMbo(0).setValue("INHERIT","1",2L); 
         		   laborCraftRateSet.getMbo(0).setValue("CONTROLACCOUNT",controlAcct,MboConstants.NOVALIDATION_AND_NOACTION);
         		   laborCraftRateSet.save();
         	   }
         	  }
        	catch(Exception e)
        	{
        		e.printStackTrace();
        	}
        	finally
      	  {
      		MXServer.getMXServer().getDBManager().freeConnection(getRunasUserInfo().getConnectionKey());
      	  
      	  }
        }
        	
        
//Creating the calendar information for the labor       
        public String createCalendar(String personID) throws MXException,RemoteException
        {
        	try
        	{
        		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        		Date currentDate=MXServer.getMXServer().getDate();
        		MboSetRemote calendarMapSet=MXServer.getMXServer().getMboSet("CALENDAR", getRunasUserInfo());
             SqlFormat calendarSql=new SqlFormat("CALNUM=:1");
             calendarSql.setObject(1, "CALENDAR", "CALNUM", personID);
             calendarMapSet.setWhere(calendarSql.format());
             calendarMapSet.reset();
           
             if(!calendarMapSet.isEmpty() && calendarMapSet!=null)
             {
            	 calendarName=calendarMapSet.getMbo(0).getString("CALNUM");
            	 return calendarName;
             }
             else
             {
            	 MboRemote calendarMbo=calendarMapSet.addAtEnd();
            	 calendarMbo.setValue("CALNUM", personID);
            	 calendarMbo.setValue("STARTDATE",dateFormat.format(currentDate));
            	 calendarMbo.setValue("ENDDATE",dateFormat.format(currentDate));            	
            	 calendarMbo.setValue("ORGID","PSAST",MboConstants.NOACCESSCHECK);
            	 calendarMapSet.save();
            	 return personID;
             }
        	}
        	catch(Exception e)
        	{
        		e.printStackTrace();
        	}
        	return calendarName;
        }
//labor should not have more then 1 craft rate.   
        public void deleteCraft(String personID,String skill ,MboSetRemote laborCraftRateSet) throws MXException,RemoteException
        {
        	mxLog.writeLog("||**********||Deleting of the LaborCraftRate||**********||");
        	SqlFormat laborCraftSql=new SqlFormat("CRAFT IN ('"+skill+"') AND  LABORCODE='"+personID+"'");
        	laborCraftRateSet.setWhere(laborCraftSql.format());
        	laborCraftRateSet.reset();
        	if(!laborCraftRateSet.isEmpty() && laborCraftRateSet!=null)
        	{
        		laborCraftRateSet.deleteAll();
        		laborCraftRateSet.save();
        	}
        }
    
}