/**
 * @author	HCHA
 * Date		Jun 28, 2006
 * Comment	 
 */
package com.psa.custom.commocode;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.psa.custom.common.MxDatabase;
import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxZip;
import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.mic.MicUtil;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

/**
 * @author		HCHA
 * @class		CommoCronTask
 * @date		Jun 28, 2006
 * @function	
 */
public class CommoCronTask extends SimpleCronTask
{
	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMddHHmmss";
	private static final String FILE_DATE_FORMAT = "yyyyMMdd";
	private static final String SPACE = " ";
	private static final String DASH = "-";
	
    //Parameters 
    private String delimiter;				//Delimiter
    private String adminEmail;			//Adminstrator Email
    private String emailSubj;				//Alert Email Subject
    private String zipExec;				//Executable/Command for zip function
    private boolean enableLog;			//Enable Log
    private String logFilePath;			//Filename and Directory where log file will be placed
    
    private String outputDirectory;		//Path for Output File
    private String filename;				//Filename for Output File

    //For Cron Task
    private String qualifiedInstanceName;
    
    private static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
    private MxLog mxLog;
    private MxEmail email;
    
    private boolean initialized;
	
	public CommoCronTask() {
		
		super();
		
		initialized = false;  	
		qualifiedInstanceName = null;
	      	
	    //Init Parameters
		delimiter=null;
	    adminEmail=null;
	    emailSubj=null;
   		logFilePath=null;
   		zipExec=null;
	    enableLog=false;

	    outputDirectory=null;
	    filename=null;
		
	}
	
    /**
     * @author		HCHA
     * @function	refreshSettings
     * @date		Jun 28, 2006
     * @comment		Refresh Cron Task setting	
     */
     private void refreshSettings()
     {
         try {

        	delimiter = getParamAsString("SPLITTAG");
        	 
            //Paramater for zip
            zipExec = getParamAsString("ZIPEXEC");        
               
            //Email Parameters
            adminEmail = getParamAsString("ALERTEMAIL");
            email.setAdmin(adminEmail);
            emailSubj = getParamAsString("ALERTEMAILSUBJ");
                        
            //Output Path and File Name
            DateFormat fileDateTimeFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
            String todayDateTime=fileDateTimeFormat.format(new Date());
     	    outputDirectory=getParamAsString("OUTPUTDIRECTORY");
     	    filename=getParamAsString("FILENAME").replaceAll("yyyymmddhhmmss",todayDateTime);

             
             //Log
     	     DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_FORMAT);
             String todayDate=fileDateFormat.format(new Date());
             logFilePath = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd",todayDate); 
             enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y")==0);
               
             mxLog.setEnabled(enableLog);
             mxLog.setLogFilePath(logFilePath);
             mxLog.setLogTag(getName());
             mxLog.createLogFile();
                                       	
            
         }
         catch(Exception exception) {
             if(integrationLogger.isErrorEnabled())
                 integrationLogger.error(exception.getMessage(), exception);
         }


     }
    
 
     /**
      * @author		HCHA
      * @function	init
      * @date		Jun 28, 2006
      * @comment	[Standard Cron Task Function]Initialize cron task 
      */

	public void init() 
    	throws MXException
    {
    	
    	super.init();
    	
        mxLog = new MxLog();  
        email = new MxEmail(adminEmail);
        initialized = true;
         
    }
   
    /**
     * @author		HCHA
     * @function	start
     * @date		Jun 28, 2006
     * @comment		[Standard Cron Task Function] Start cron task  
     */

    public void start() {
    	
        try {
            refreshSettings();
            
            mxLog.writeLog(getName()+".start()");
            
            MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Start" );
            setSleepTime(0L);
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }


    /**
     * @author		HCHA
     * @function	stop
     * @date		Jun 28, 2006
     * @comment		[Standard Cron Task Function]Stop cron task  
     */

    public void stop() 
    {
    	
    	try{
            mxLog.writeLog(getName()+".stop()");
    		mxLog.closeLogFile();
    	}
    	catch(Exception exception){
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
    	}
    			
    	MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Stop" );
    }


    /**
     * @author		HCHA
     * @function	setCrontaskInstance
     * @date		Jun 28, 2006
     * @comment		[Standard Cron Task Function] Set cron task instance 
     */
    
    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {
		
    	
        try {
        	
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") + 
            	"." + crontaskinstanceremote.getString("instancename");
        }
        catch(Exception exception) {
            integrationLogger.error(exception.getMessage(), exception);
        }
    }

    /**
     * @author		HCHA
     * @function	isReqParamSet
     * @date		Jun 28, 2006
     * @comment		returns true if all required parameter is set
     */

    private boolean isReqParamSet()
    {
        if(adminEmail==null) return false;
        if(outputDirectory==null) return false;
        if(filename==null) return false;
        
    	return true; 
    }
   
    /**
     * @author		HCHA
     * @function	cronAction
     * @date		Jun 28, 2006
     * @comment		[Standard Cron Task Function]
     */
    

	public void cronAction() 
	{

        try {
        	
        	mxLog.writeLog(getName()+".cronAction():[Info]Start CronTask Action");
        	
            if(!initialized){
            	mxLog.writeLog(getName()+".cronAction():[Error]CronTask not initialized!");
                throw new Exception(getName()+".cronAction():[Error]CronTask not initialized!");
            }

        	// Refresh setting before perform cron action
            refreshSettings();
   
        	if (!isReqParamSet()) {
        		mxLog.writeLog(getName()+".cronAction(): Required parameters not set.");
        		throw new Exception("Required parameters not set.");        	
        	}

        	//Generate the output flat files
        	boolean isFileGenerated = processData();
        	
        	//Copy and Zip Flat Files to Output and Archive Directory 
        	if(isFileGenerated)
        		depositFile();
        	
        	mxLog.writeLog(getName()+".cronAction():[Info]End CronTask Action");
        	
        }
        catch(Exception e) {
        	
        	mxLog.writeLog("[ERROR] "+e.getMessage());
        	
            MicUtil.INTEGRATIONLOGGER.error("["+getName()+"] "+e.getMessage(), e);                   
            
            String emailContent = genEmail(e);
            email.send(emailSubj,emailContent );
          	mxLog.writeLog("Email Sent:\n"+emailContent); 
            
            stop();
        	
        }       
	}
	
    /**
     * @author		HCHA
     * @function	depositFile
     * @date		Jun 28, 2006
     * @comment		Copy and Zip Flat Files to Output and Archive Directory 
     */

	private void depositFile()
		throws Exception
	{
		mxLog.writeLog(getName()+".depositFile():[Info]Start depositing output file...");
		
		//Zip Flat Files
		String outputFilePath = outputDirectory + filename;
		String cmd = zipExec + SPACE + outputFilePath;
		mxLog.writeLog(getName()+".depositFile():[Info]Zip using cmd: " + cmd);
		int retcode= MxZip.zipFile(cmd);
		if (retcode != 0){
   			mxLog.writeLog(getName()+".depositFile():[Error]Unable to zip file - " + outputFilePath);
			throw new Exception(getName()+".depositFile(): Unable to zip file - " + outputFilePath);
		}
		
		mxLog.writeLog(getName()+".depositFile():[Info]Finish depositing output file");
	}
	

    /**
     * @author		HCHA
     * @function	genEmail
     * @date		Jun 28, 2006
     * @comment		Generate Email  
     */
	
	private String genEmail(Exception e){
		
        //Form Email Message
        String emailMsg = "Date: " + new Date()+"\n";
        emailMsg += "Error in CronTask: "+getName()+ "\n";
        emailMsg+="Error Message: "+ e.getMessage()+"\n";
        emailMsg+="Detail:\n";
        emailMsg+=e.toString()+"\n"; 
        StackTraceElement element[] = e.getStackTrace();
        for(int i=0; i< element.length; i++){
        	emailMsg+="\tat "+ element[i].toString()+"\n";	
        }
        
        return emailMsg;
		
	}
	
    /**
     * @author		HCHA
     * @function	writeFile
     * @date		Jun 28, 2006
     * @comment		Generate the output flat file
     * @return		true = file generated, false = no data present 		  
     */
	
	private boolean writeFile(Connection conn)
		throws SQLException, IOException
	{
		ResultSet rs=null;
		PreparedStatement pstmt=null;
		
		try{
			mxLog.writeLog(getName()+".writeFile():[Info]Start writing file...");        
			 
			String readSqlStmt = "SELECT "+
							 "IFACE.COMMODITY, "+
							 "IFACE.DESCRIPTION, " +
							 "IFACE.PARENT, "+
							 "IFACE.TRANSID, "+
							 "TRANS.ACTION "+
							 "FROM " + 
							 "MXCOMMODITIES_IFAC IFACE LEFT JOIN MXOUT_INTER_TRANS TRANS " +
							 "ON (IFACE.TRANSID = TRANS.TRANSID ) " + 
							 "ORDER BY IFACE.TRANSID";
			
			mxLog.writeLog(getName()+".writeFile():[Info]SQL Statement - " + readSqlStmt);
			pstmt = conn.prepareStatement(readSqlStmt);
			rs = pstmt.executeQuery();
			

			//Check if there is any record 
			if(!rs.next()){
				mxLog.writeLog(getName()+".writeFile():[Info]No new commodity code. No file is generated.");
				return false;
			}
			
			//Set up sql to delete line from Interface table MXCOMMODITIES_IFAC  
			String purgeIfaceSQL = "delete from MXCOMMODITIES_IFAC " +
							  "where TRANSID= ?";
			PreparedStatement purgeIfaceStmt = conn.prepareStatement(purgeIfaceSQL);
			
			//Set up sql to delete line from transcation Out Table MXOUT_INTER_TRANS TRANS
			String purgeTxnSQL = "delete from MXOUT_INTER_TRANS where TRANSID = ?";
			PreparedStatement purgeTxnStmt = conn.prepareStatement(purgeTxnSQL);
			
			File outFile = new File(outputDirectory+filename);
			FileWriter fWriter = new FileWriter(outFile);
			BufferedWriter bWriter =  new BufferedWriter(fWriter);
			
			Date curDate = new Date();
	        DateFormat dmyDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	        String curDateStr=dmyDateFormat.format(curDate);
				
			do {
				
				String commo = rs.getString("COMMODITY");
				String commogrp = rs.getString("PARENT");
				String desc = rs.getString("DESCRIPTION");
				if(desc==null){
					desc="";
				}
				String transid = rs.getString("TRANSID");
				String action = rs.getString("ACTION");
				
				String commoCode = null;
				if(commogrp==null){
					commoCode = commo + DASH;
				}
				else{
					commoCode = commogrp + DASH + commo;
				}
				
				String status = "";
				if(action.equalsIgnoreCase("Add")){
					status = "C";
				}
				else if(action.equalsIgnoreCase("Replace")){
					status = "A";
				}
				else if(action.equalsIgnoreCase("Delete")){
					status = "D";
				}
				
				String writeline= commoCode + delimiter + desc + delimiter + curDateStr + delimiter + status;
				
				//Write to file
				bWriter.write(writeline);
				bWriter.newLine();
				
				//Delete line from Interface table MXCOMMODITIES_IFAC  
				purgeIfaceStmt.clearParameters();
				purgeIfaceStmt.setString(1,transid); //Set TransID
				purgeIfaceStmt.executeUpdate();

				//Purge Transcation Out Table MXOUT_INTER_TRANS TRANS
				purgeTxnStmt.clearParameters();
				purgeTxnStmt.setString(1,transid); //Set TransID
				purgeTxnStmt.executeUpdate();
				
			}while(rs.next());
			
	        bWriter.close();
	        fWriter.close();
			
			purgeIfaceStmt.close();
			purgeTxnStmt.close();
			rs.close();
			pstmt.close();
			
			mxLog.writeLog(getName()+"writeFile():[Info]End writing file...");
		}
		catch(SQLException e){
			if(rs!=null) rs.close();
			if(pstmt!=null) pstmt.close();
			throw e;
		}
		
		return true;

	}
	
	
	
    /**
     * @author		HCHA
     * @function	processData
     * @date		Jun 28, 2006
     * @comment		Generate the flat file  
     * @return		true = file generated, false = no data present 
     */
	private boolean processData()
		throws Exception
	{
		MxDatabase db = null;
		Connection conn = null;
		boolean isFileGenerated = false;
		
	  	try {             
	  		
	  		mxLog.writeLog(getName()+".processData():[Info]Start processing ...");
	  		
	  		db = new MxDatabase(getRunasUserInfo());
			conn = db.getConn();
			
			isFileGenerated = writeFile(conn);
			
			//20061004 HCHA - Remove Close Connection (use freeConnection in provided by releaseResources())
			//conn.close();
			db.releaseResources();
			
			mxLog.writeLog(getName()+".processData():[Info]Finished processing ...");
	    		
	  	}
        catch(Exception e) { 
        	
        	//20061004 HCHA - Remove Close Connection (use freeConnection in provided by releaseResources())
			//if(conn!=null) 	conn.close();
			if(db!=null)	db.releaseResources();
			
			throw e;
        }
        
        return isFileGenerated;
	}
	
	
    /**
     * @author		HCHA
     * @function	getParameters
     * @date		Jun 28, 2006
     * @comment		[Standard Cron Task Function] Get the parameter from Cron Task. 
     */
	public CrontaskParamInfo[] getParameters() 
    	throws MXException, RemoteException 
    {
    	return params;
	}
	
	//CronTask Parameters
	protected static CrontaskParamInfo params[];
    static 
    {
    	//Set the number of the parameter.  
        params = null;
        params = new CrontaskParamInfo[8];
        
        //All the parameter configurable from Cron Task user interface 
        params[0] = new CrontaskParamInfo();
        params[0].setName("SPLITTAG");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[0].setDescription("Delimiter for flat file.");
        params[0].setDescription("CommonCron","DelimiterFlatFile");
        //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[0].setDefault("~");
 
        params[1] = new CrontaskParamInfo();
        params[1].setName("ALERTEMAIL");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[1].setDescription("Admin email address for notification of error.");
        params[1].setDescription("CommonCron","Adminemailaddress");
        //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[2] = new CrontaskParamInfo();
        params[2].setName("ALERTEMAILSUBJ");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[2].setDescription("Email Subject for the Alert Email.");
        params[2].setDescription("CommonCron","EmailSubject");
        //-- COMM-IT changed to make it compatible with Maximo 7 API

        params[3] = new CrontaskParamInfo();
        params[3].setName("ZIPEXEC");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[3].setDescription("Executable for ziping the flat file.");
        params[3].setDescription("CommonCron","ExecutableZiping");
        //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[3].setDefault("gzip -f -q");
        
        params[4] = new CrontaskParamInfo();
        params[4].setName("OUTPUTDIRECTORY");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[4].setDescription("Directory to place the output file.");
        params[4].setDescription("CommonCron","OutputDirectory");
        //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[5] = new CrontaskParamInfo();
        params[5].setName("FILENAME");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[5].setDescription("Output filename(Add 'yyyymmddhhmmss' to add date to filename)");
        params[5].setDescription("CommonCron","OutputFilename");
        //-- COMM-IT changed to make it compatible with Maximo 7 API
        
        params[6] = new CrontaskParamInfo();
        params[6].setName("ENABLELOG");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[6].setDescription("Enable log output('Y' or 'N').");
        params[6].setDescription("CommonCron","EnableLog");
        //-- COMM-IT changed to make it compatible with Maximo 7 API
        params[6].setDefault("Y");
                        
        params[7] = new CrontaskParamInfo();
        params[7].setName("LOGFILEPATH");
        //++ COMM-IT changed to make it compatible with Maximo 7 API
        //params[7].setDescription("Log Directory and Filename.");
        params[7].setDescription("CommonCron","LogDirectory");
        //-- COMM-IT changed to make it compatible with Maximo 7 API
        

        
    }

}

