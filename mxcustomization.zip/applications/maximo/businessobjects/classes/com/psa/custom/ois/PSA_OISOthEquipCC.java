/*
 * Modification history
 * 02-03-2006	HCA	NA			OIS Main Class for Other Equipment Computation for Container Count
 * 08-01-2007	AGD	SR-045	Catch lines with error
 * 									QC : base on start date/time instead of end date/time
 * 									several readings with the same start time but with different end times
 * 21-05-2007	AGD	DR-021	Change checks for asset field length = 6
 * 26-10-2007	AGD	DR-054	Update OISData constructor with new version from SR-110
 * 15-07-2014	WMJ	EMS-819 [Crontask]Handle 4 digit equipment in OIS crontasks
 */
package com.psa.custom.ois;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;

import com.psa.custom.common.EMSSite;
import com.psa.custom.common.MxSort;


import psdi.security.UserInfo;
import psdi.util.MXException;

public class PSA_OISOthEquipCC
{

	private static String delimiter = ",";
	private static final String outputfileext = ".out";
	private static final String sortedfileext = ".sort";
	
	private OISCheck equipIncl;
	
	private String boxMeterName;
	private String boxMeterNameM;
	
	private ArrayList finalDataArray;
	
	private UserInfo userInfo; //Maximo User Info 
	
	private String sortCmd;
	private String sortOpOpt;

   private  MxLog mxLog;


	public PSA_OISOthEquipCC(String equipInclFile, UserInfo userInfo, String boxMeterName, String boxMeterNameM, String sortCmd, String sortOpOpt,  MxLog mxLog) 
		throws Exception
	{
		
		this.mxLog = mxLog;
		
		finalDataArray = new ArrayList();
		
		this.userInfo = userInfo;
		this.boxMeterName = boxMeterName;
		this.boxMeterNameM = boxMeterNameM;
		this.sortCmd = sortCmd;
		this.sortOpOpt = sortOpOpt;
		
		//Load the equipment type list that is included
		equipIncl = new OISCheck(equipInclFile);
		
	}


	/**
	 * @function	Reads input flat file
	 */
	/*
	 * SR-45 AGD : catch lines with error
	 * Change return type to String in order to return the list of lines with error
	 * Returns null or the lines separated by comma
	 */
//	private void readDataFile(String inFileName, String outFileName, String EMSAssetIDCfgFile)
	private String readDataFile(String inFileName, String outFileName, String EMSAssetIDCfgFile)
		throws Exception
	{

		mxLog.writeLog(getClass().getName()+".readDataFile()");

		String inputText=null;
		int linenum=0;
		// SR-45 AGD : catch lines with error
		String errorLines = "";

		try{

			File inFile = new File(inFileName);
			if (!inFile.exists()){
				//mxLog.writeLog(getClass().getName()+".readDataFile(): Input file: '"+inFileName+"' not found!");
				throw new Exception(getClass().getName()+".readDataFile(): Input file: '"+inFileName+"' not found!");
			}

			FileReader fReader = new FileReader(inFile);
			BufferedReader bReader = new BufferedReader(fReader);

			File outFile = new File(outFileName);
			FileWriter fWriter = new FileWriter(outFile);
			BufferedWriter bWriter = new BufferedWriter(fWriter);

			EMSAssetIDConversion assetIDConv = new EMSAssetIDConversion(EMSAssetIDCfgFile);
			inputText = bReader.readLine();

			while(inputText!=null) {

				linenum++;
				String splitText[]=new String[7];
				
				try {
					
					splitText= inputText.split(",");
					String type=splitText[0];
					String assetID=assetIDConv.getRightAssetId(splitText[1].trim());
					String meterDate=splitText[2].trim();
					int contCount=Integer.parseInt(splitText[5].trim());
										
					System.out.println("Maximo Location: "+assetID);
					System.out.println("Container Count: "+contCount);
					
					
					if(type.equalsIgnoreCase("YC") && assetID.length()>0)
					{
						
						if(equipIncl.isInList(assetID.substring(1,3)))
						{
							//Write data to output file
				        	String writeline = assetID + delimiter + meterDate + delimiter + contCount + "\n";
				            bWriter.write(writeline);
						}
						//OISData data = new OISData(assetID, contCount, 0.0d, meterDate);
						//finalDataArray.add(data);
					}
					
					else if(assetID.length()>0 && type.equalsIgnoreCase("ME"))
					{
						if((equipIncl.isInList(assetID.substring(1,3)) || equipIncl.isInList(assetID.substring(0,2))))
						{
							int eqmtCount=Integer.parseInt(splitText[4].trim()); //PM count
							int eqofCount=Integer.parseInt(splitText[5].trim()); //AGV count
						
							if(assetID.contains("GV"))
							{
								String writeline = assetID + "," + meterDate + delimiter + eqofCount + "\n";
								bWriter.write(writeline);
								//OISData data = new OISData(assetID, eqofCount, 0.0d, meterDate);
								//finalDataArray.add(data);
							}
						
							else if(assetID.contains("PM"))
							{
								String writeline = assetID + "," + meterDate + delimiter + eqmtCount + "\n";
								bWriter.write(writeline);
								//OISData data = new OISData(assetID, eqmtCount, 0.0d, meterDate);
								//finalDataArray.add(data);
							}
						
							}
						}
				}
				catch (Exception e) {
					errorLines = errorLines + ", " + linenum;
					String errormsg = getClass().getName()+".readDataFile(): Error at line("+linenum+")of '"+inFileName+"' - "+inputText+"("+MxLog.genError(e)+")";
					mxLog.writeLog(errormsg);
				}
				inputText = bReader.readLine();
			}
			bWriter.flush();
			bWriter.close();
			fWriter.close();

			bReader.close();
			fReader.close();

		}
		catch(IOException e) {
			String errormsg;
			if(inputText!=null){
				errormsg = getClass().getName()+".readDataFile(): I/O Error at line("+linenum+")of '"+inFileName+"' - '"+inputText+"' ("+e+")";
			}
			else{
				errormsg = getClass().getName()+".readDataFile(): I/O Error reading text file '"+inFileName+"'"+" ("+e+")";
			}
			//mxLog.writeLog(errormsg);
			throw new Exception(errormsg);
		}
		catch(Exception e) {
			String errormsg;
			if(inputText!=null){
				errormsg = getClass().getName()+".readDataFile(): Error at line("+linenum+")of '"+inFileName+"' - '"+inputText+"' ("+e+")";
			}
			else{
				errormsg = getClass().getName()+".readDataFile(): Error reading text file '"+inFileName+"'"+" ("+e+")";
			}
			//mxLog.writeLog(errormsg);
			throw new Exception(errormsg);
		}

		// SR-45 AGD : catch lines with error
		return (errorLines.equals(""))? null : errorLines.substring(2);
	}


	/**
	 * @function	[For debug purpose only] 
	 * 				Write data array list to file
	 */
	public void writeFinalArrayToFile(String outFileName){
		writeArrayToFile(finalDataArray, outFileName);
	}


	/**
	 * @function	[For debug purpose only] 
	 * 				Write data array list to file
	 */
	private void writeArrayToFile(ArrayList arraylst, String outFileName){

		try{

			File outFile = new File(outFileName);
			FileWriter fWriter = new FileWriter(outFile);
			BufferedWriter bWriter = new BufferedWriter(fWriter);
			
			//Write Header
        	String writeHdr = new String();
        	writeHdr = "AssetID," ;
        	writeHdr += "ActLastReadingDT," ; 
        	writeHdr +=  "NumContainer," ;
        	writeHdr += "Duration"; 
            bWriter.write(writeHdr);

		
	        for (int j=0; j < arraylst.size(); j++) {
	        	
	        	OISData temp = (OISData) arraylst.get(j);
	        	
	        	String writeline = new String();
	        	writeline = "\n" + temp.getAssetID()+ "," ;
	        	writeline += temp.getActLastReadingDT() + "," ; 
	        	writeline +=  String.valueOf(temp.getNumContainer())+"," ;
	        	writeline += String.valueOf(temp.getDuration()); 
	        	
	            bWriter.write(writeline);
	        }
	
	        bWriter.close();
	        fWriter.close();
		}
		catch(IOException e) {
			mxLog.writeLog ( "OISOthEquipCC.writeArrayToFile(): Error writing text file : " + e); 
		}
		
		catch(Exception e) {
			mxLog.writeLog("OISOthEquipCC.writeArrayToFile(): Unexpected error writing text file : " + e);
		} 
		
	}
	

	/**
	 * @function	Process the input file and the send the result to Maximo
	 */
	/*
	 * SR-45 : catch lines with error
	 * Changed the return type to String[] to be able to return also the list of lines with error
	 */
	public String[] processFile(String filename,String extSys, String intIface, String intObject, String isdelta, String inspector, String EMSAssetIDCfgFile)
		throws MXException, RemoteException, InterruptedException, IOException, Exception
	{

		mxLog.writeLog(getClass().getName()+".processFile()");
		String outfilename =  filename + outputfileext;
		// SR-45 AGD : catch lines with error
		String[] returnMsg = { null, null };
		returnMsg[1] = readDataFile(filename,outfilename, EMSAssetIDCfgFile);

		calTotal(outfilename);

		OISJmsMessage msg = new OISJmsMessage(extSys,intIface);
		MxXmlLocMeter xmlGen = new MxXmlLocMeter(extSys, intIface, intObject, boxMeterName, isdelta, inspector);

		String locNotFound = new String();
		int nbLocNotFound = 0;
		OISData curData = null;
		try{
	        for (int j=0; j < finalDataArray.size(); j++) {
	
	        	curData = (OISData) finalDataArray.get(j);
	        	
				EMSSite site = new EMSSite(curData.getAssetID(),userInfo);
				
				if(site.getOrgID()!=null && site.getSiteID()!=null){
					
					String xml;

					//Send Container Count Meter Data (Read-only meter)
					xmlGen.setMetername(boxMeterName);
					xml = xmlGen.genXml(site.getOrgID(),site.getSiteID(),curData.getAssetID(),curData.getActLastReadingDT(),String.valueOf(curData.getNumContainer()));
					msg.sendMessage(xml.getBytes());
					System.out.println("XML-1: "+xml);
					//Send Container Count Meter Data (User modifiable meter)
					xmlGen.setMetername(boxMeterNameM);
					xml = xmlGen.genXml(site.getOrgID(),site.getSiteID(),curData.getAssetID(),curData.getActLastReadingDT(),String.valueOf(curData.getNumContainer()));
					msg.sendMessage(xml.getBytes());
					System.out.println("XML-2: "+xml);
				}
				else{
					nbLocNotFound++;
					locNotFound += curData.getAssetID()+ "\t" + curData.getActLastReadingDT()+ "\t" + String.valueOf(curData.getNumContainer()) + "\n";
				}
	
	        }
		}
		catch(Exception e)
		{
			String errormsg;
			errormsg = getClass().getName()+".processFile(): Unexpected Error "+"("+e+")"+
					   "\nCurrently Writing to Queue for:" +
					   "\n\tAssetID="+curData.getAssetID();
			//mxLog.writeLog(errormsg);
			throw new Exception(errormsg);
		}
        
		if(nbLocNotFound!=0){
			mxLog.writeLog(getClass().getName()+".processFile(): "+nbLocNotFound+" Locations not found in the database!");
			String title =
				"[OIS Other Equipment Container Count]\n"+
				"Date: "+ new Date()+"\n" +
				"List of locations not found in the database:\n"+
				"LocationID"+"\t"+"Last Reading"+"\t"+"Container Count\n";
			String locNotFoundErrMsg = title + locNotFound;

        	// SR-45 AGD : catch lines with error
        	returnMsg[0] = locNotFoundErrMsg;
			//return locNotFoundErrMsg;
		}

		//	 SR-45 AGD : catch lines with error
		return returnMsg;
		//return null;

	}


	private void calTotal(String filename)
		throws MXException, RemoteException, InterruptedException, Exception
	{
		mxLog.writeLog(getClass().getName()+".calTotal(): Start Calculation");

		//Sort file
		String sortfilename = filename + sortedfileext;
		if(MxSort.sort(sortCmd, filename, sortOpOpt , sortfilename)!=0)
		{
			//mxLog.writeLog(getClass().getName()+".calTotal(): Unable to sort file "+ filename);
			throw new Exception(getClass().getName()+".calTotal(): Unable to sort file "+ filename);
		}

		String inputText=null;
		int linenum=0;

		try
		{
			File sortedFile = new File(sortfilename);
			FileReader fReader = new FileReader(sortedFile);
			BufferedReader bReader = new BufferedReader(fReader);
			String splitText[]=new String[2]; //2 fields in the intermediate output file

			String curLocID = "";
			String lstActDT = "";
			int contCount = 0;

			inputText = bReader.readLine();

			while(inputText!=null)
			{
				linenum++;

				splitText= inputText.split(delimiter);
				String locID = splitText[0];
				String actDT = splitText[1];
				int contCnt = Integer.parseInt(splitText[2].trim());
				
				//Current Location ID to process is equal the Location ID just read
				if(curLocID.compareTo(locID)==0)
				{
					contCount=contCount+contCnt;
					lstActDT = actDT;
				}
				else
				{
					if(contCount!=0)
					{
//Begin modification DR-054
//						OISData data = new OISData(curLocID, contCount, 0, lstActDT);
						OISData data = new OISData(curLocID, contCount, 0.0d, lstActDT);
//End modification DR-054
						finalDataArray.add(data);
					}

					curLocID = locID;
					lstActDT = actDT;
					contCount = contCnt;
				}

				inputText = bReader.readLine();
			}

			//Write Last Data
			if(contCount!=0)
			{
//Begin modification DR-054
//				OISData data = new OISData(curLocID, contCount, 0, lstActDT);
				OISData data = new OISData(curLocID, contCount, 0.0d, lstActDT);
//End modification DR-054
				finalDataArray.add(data);
			}
		}
		catch(IOException e)
		{
			String errormsg;
			if(inputText!=null){
				errormsg = getClass().getName()+".calTotal(): I/O Error at line("+linenum+")of '"+sortfilename+"' - '"+inputText+"' ("+e+")";
			}
			else{
				errormsg = getClass().getName()+".calTotal(): I/O Error reading text file '"+sortfilename+"'"+"("+e+")";
			}
			//mxLog.writeLog(errormsg);
			throw new Exception(errormsg);
		}
		catch(Exception e)
		{
			String errormsg;
			if(inputText!=null){
				errormsg = getClass().getName()+".calTotal(): Error at line("+linenum+")of '"+sortfilename+"' - '"+inputText+"' ("+e+")";
			}
			else{
				errormsg = getClass().getName()+".calTotal(): Error reading text file '"+sortfilename+"'"+"("+e+")";
			}
			//mxLog.writeLog(errormsg);
			throw new Exception(errormsg);
		}

		mxLog.writeLog(getClass().getName()+".calTotal(): Calculation Done");
	}


	/*
	 * Clears Calculation Results stored in finalDataArray
	 */
	public void clearResult()
	{
		finalDataArray.clear();
	}
}


