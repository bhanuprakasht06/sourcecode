/*
 * Modification history
 * 26-06-2013	WMJ	EMS-605			Creation
 * 26-06-2013	WMJ	EMS-605			[WORKFLOW][REWOWF]Auto approve labour when routing recond workflow from RCNINCOMP -> RCNINTQC 
 *
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;
import psdi.app.labor.LabTransRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class AutoApprNonOTLaborCustom
implements ActionCustomClass
{

/*
* Constructor - does nothing
*/
public AutoApprNonOTLaborCustom()
{
}


/*
* Approve all unapproved non OT labor reports
*/
public void applyCustomAction(MboRemote woremote, Object aobj[])
	throws MXException, RemoteException
{
mxLogger.debug("AutoApprNonOTLaborCustom - Entering");

wo = woremote;

MboSetRemote labtransset = wo.getMboSet("NONOTLABTRANS");
LabTransRemote labtrans;
for (int i = 0; (labtrans = (LabTransRemote) labtransset.getMbo(i)) != null; i ++)
{
	if (!labtrans.getBoolean("genapprservreceipt") && !(labtrans.isNull("startdate")) && !(labtrans.isNull("starttime")) && !(labtrans.isNull("finishdate")) && !(labtrans.isNull("finishtime")))
		labtrans.approveLaborTransaction();
}
//labtransset.save();
//labtransset.close();

mxLogger.debug("AutoApprNonOTLaborCustom - Leaving");
}

private MboRemote			wo;
private static final MXLogger	mxLogger	= MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}

