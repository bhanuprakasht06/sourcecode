package com.psa.app.pr;

import java.rmi.RemoteException;

import psdi.app.pr.PRLineRemote;
import psdi.app.workorder.WORemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public class PRLineRequestbyCustom 
implements ActionCustomClass
{
public PRLineRequestbyCustom() 
{
}

public void applyCustomAction(MboRemote mboremote, Object aobj[])
throws MXException, RemoteException
{
	MboSetRemote prlineset = mboremote.getMboSet("PRLINE");
	int i = 0;
//	System.out.println("[PRLineRequestbyCustom]PRNUM: " + mboremote.getString("prnum"));
	/* Get the PRLines from the PR */ 
	for (PRLineRemote prline; (prline = (PRLineRemote) prlineset.getMbo(i)) != null; i++)
	{
//		System.out.println("[PRLineRequestbyCustom]PRLINENUM: " + prline.getString("prlinenum"));
		/* Get the workorder of the PRLine */
		MboSetRemote WOset = prline.getMboSet("WORKORDER");
		WORemote WO;
		if ((WO = (WORemote) WOset.getMbo(0)) != null)
		{
			/* Set the Prline RequestBy with the WO ApproveBy */
			
			prline.setValue("requestedby", WO.getString("prapprovedby"), 2L);
//			System.out.println("[PRLineRequestbyCustom]REQUESTEDBY: " + WO.getString("prapprovedby"));
		}
		WOset.close();
	}
	/* Save the PRLine record */
	try
	{
		prlineset.save();
	}
	finally
	{
		prlineset.close();
	}
}
}
