/*
 * Modification history
 * 08-11-2012	WMJ	NA	Creation
 * 08-11-2012	WMJ	EMS-526	[RFQ]System check to ensure that the RFQ CLOSEONDATE is the current date or in the future 
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.mbo.CrossOverDomain;
import psdi.mbo.Mbo;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class FldOpenDurationCustom extends MboValueAdapter

{

	public FldOpenDurationCustom(MboValue mbovalue)
        throws MXException, RemoteException
    {
		super(mbovalue);
    }

	public void action() throws MXException, RemoteException
    {
       
	}
	
	public void validate()
    	throws MXException, RemoteException
     {
		Mbo mbo = getMboValue().getMbo();
		
		if(!mbo.isNull("CLOSEONDATE"))//WMJ: allow NULL value for the field CLOSEONDATE as CLOSEONDATE will be set to NULL for reopened RFQs.
		{
			Calendar cal = Calendar.getInstance();//get current date time
			
			//clear off the time component from cal
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			
			Date curDate = cal.getTime();//get Date object from cal
				
			if((curDate.compareTo(mbo.getDate("CLOSEONDATE")))>0)//WMJ: returns a value greater than zero if curDate is before Close Date, 0 if both dates are the same
	        throw new MXApplicationException("rfq", "closeOnDateBeforeCurrentDate");
		}
		
     }
}


