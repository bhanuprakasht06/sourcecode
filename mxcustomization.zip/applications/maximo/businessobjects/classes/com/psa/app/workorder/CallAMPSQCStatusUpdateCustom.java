package com.psa.app.workorder;

import java.io.BufferedInputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class CallAMPSQCStatusUpdateCustom
		implements ActionCustomClass
{

	
	private static final MXLogger mxLogger = MXLoggerFactory.getLogger("maximo.application.WORKORDER");
	/*
	 * Constructor - does nothing
	 */
	public CallAMPSQCStatusUpdateCustom()
	{
	}


	/*
	 * Call AMPS QC Status API
	 */
	public void applyCustomAction(MboRemote woremote, Object aobj[])
			throws MXException, RemoteException
	{
		mxLogger.debug("CallAMPSQCStatusUpdateCustom - Entering");
		
		String statusUpdate = woremote.getString("psa_statusupd");
		String[] strArray = statusUpdate.split(",");
		
		@SuppressWarnings("deprecation")
		Properties configData = MXServer.getMXServer().getConfig();
		String query_url = configData.getProperty("psa.amps.qc.webapp");
		String x_api_key = configData.getProperty("psa.amps.qc.x_api_key");
		String AMPSQC_authorization = configData.getProperty("psa.amps.qc.authorization");
		String PrevStatus=null;
		boolean callAMPSQC =false;
		
		System.out.println("------Post_JSON_AMPSQC()------------------query_url-----------------"+query_url);
		System.out.println("------Post_JSON_AMPSQC()------------------x_api_key-----------------"+x_api_key);
		System.out.println("------Post_JSON_AMPSQC()------------------AMPSQC_authorization------"+AMPSQC_authorization);
		
		for (int i = 0; i < strArray.length; i++) 
		{
			System.out.println("String: "+strArray[i]);
			System.out.println("PrevStatus: "+PrevStatus);
			//WPLSCH,WPLSCH
			if (PrevStatus == null)
				callAMPSQC=true;
			else if (PrevStatus != null && !PrevStatus.equalsIgnoreCase(strArray[i]))
				callAMPSQC=true;
			else
				callAMPSQC=false;
			
			if (callAMPSQC)	
			{
				if((!query_url.isEmpty()) || (query_url!=null))
				{
					PrevStatus=strArray[i];
					SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyyMMddHHmmss");
					String jsondate = simpledateformat.format(new Date());
					String json = "{ \"wonum_m\" : \""+woremote.getString("WONUM")+"\", \"user_id_m\" : \""+woremote.getString("CHANGEBY")+"\", \"job_status_c\" : \""+strArray[i]+"\" , \"update_dt\" : \""+jsondate+"\" }";
					
					System.out.println("------Post_JSON_AMPSQC()------------------json format-----------------"+json);
					try 
					{
						URL url = new URL(query_url);
						HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		        
						conn.setConnectTimeout(5000);
						conn.setRequestProperty("x-api-key", x_api_key);
						conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
						conn.setRequestProperty("Authorization", AMPSQC_authorization);
						System.out.println("---------1---------");
						conn.setDoOutput(true);
						conn.setDoInput(true);
						conn.setRequestMethod("POST");
						System.out.println("---------2---------");
	
						OutputStream os = conn.getOutputStream();
						os.write(json.getBytes("UTF-8"));
						os.close(); 
						System.out.println("---------3---------");
	
						// read the response
						BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
						System.out.println("---------4---------");
						byte[] contents = new byte[1024];
						System.out.println("---------5---------");
						int bytesRead=0;
						String result=null;
						System.out.println("---------6---------");
						while((bytesRead = in.read(contents))!=-1)
						{
							System.out.println("---------7---------");
							result += new String(contents,0,bytesRead);
		        	
						}        
						System.out.println(result);
						in.close();
						conn.disconnect();
					} 
					catch (Exception e) 
					{
						System.out.println(e);
					}
				}
			}
			callAMPSQC=false;
		}
		woremote.setValueNull("PSA_STATUSUPD");
		mxLogger.debug("CallAMPSQCStatusUpdateCustom - Leaving");
	}

	
}
