package com.psa.app.jobplan;

import psdi.app.jobplan.JobPlanSetRemote;

public interface JobPlanSetCustomRemote extends JobPlanSetRemote 
{
		
}
