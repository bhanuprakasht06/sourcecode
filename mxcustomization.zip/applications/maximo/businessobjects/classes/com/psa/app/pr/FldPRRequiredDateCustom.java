/*
 * Modification history
 * 02-05-07	LS	SR-071	Populate the required date of the PRLINEs when the required date of PR is populated
 */

package com.psa.app.pr;

import java.rmi.RemoteException;

import psdi.app.pr.PRLineRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

public class FldPRRequiredDateCustom extends MboValueAdapter 
{
	public FldPRRequiredDateCustom(MboValue mbovalue) 
	{
		super(mbovalue);
	}

    public void action()
	    throws MXException, RemoteException
	{
	    super.action();
		Mbo mbo = getMboValue().getMbo();
		MboSetRemote prlineset = mbo.getMboSet("PRLINE");
		int i = 0;
//		System.out.println("[PRLineRequestbyCustom]PRNUM: " + mboremote.getString("prnum"));
		/* Get the PRLines from the PR */ 
		for (PRLineRemote prline; (prline = (PRLineRemote) prlineset.getMbo(i)) != null; i++)
		{
//			System.out.println("[PRLineRequestbyCustom]PRLINENUM: " + prline.getString("prlinenum"));
			/* Set the contract of the PRLine to null*/
			prline.setValue("reqdeliverydate", getMboValue().getDate(), 2L);
		}
	}
}
