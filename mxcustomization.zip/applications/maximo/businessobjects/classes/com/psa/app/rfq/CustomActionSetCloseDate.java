/*
 * Modification history
 * 20-07-2013  CR-2  Custom Action Class To Set Close Date in RFQ Work Flow 
 * 
   
*/


package com.psa.app.rfq;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;

import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;


public class CustomActionSetCloseDate implements ActionCustomClass
{
	
	static Calendar cc;
	static Date closedate = null;

	public CustomActionSetCloseDate()
	{
	}

	public void applyCustomAction(MboRemote rfqremote, Object aobj[])throws MXException, RemoteException
	{
		cc = Calendar.getInstance();
		System.out.println(" Date Is    "+cc.getTime());
		System.out.println("***I am Inside CustomActionSetCloseDate ***");
		double totlinecost = 0;
		boolean check = false;
		int day = cc.getTime().getDay();
		System.out.println("***Day Now Is "+day+"***");
		MboSetRemote rfqlineset = rfqremote.getMboSet("RFQLINE");
		MboRemote rfq;
		
			for(int i=0;((rfq = rfqlineset.getMbo(i))!=null);i++)
				{
				    System.out.println("***I am In RFQLINE MboSet ***");
					check = true;
					totlinecost = totlinecost + rfq.getDouble("WPITEMLIST.LINECOST");
				}
			if(check && totlinecost >= 1000)
				{
				    System.out.println("*** Tot Line Cost Greater Than 1K *** "+totlinecost);
				    System.out.println("***    Adding 5 Days ***");					
				    add5days (day);
				}
			if(check && totlinecost < 1000)
				{
					System.out.println("*** Tot Line Cost Less Than 1K *** "+totlinecost);				
					System.out.println("*** Adding 3 Days ***");
					add3days (day);
				}
		System.out.println("*** Setting Close Date "+closedate+" ***");	
		rfqremote.setValue("CLOSEONDATE", closedate, MboConstants.NOACCESSCHECK);
		rfqremote.getThisMboSet().save();
	}

	public static Date adddays (int days)
	{
		System.out.println("Inside adddays adding "+days+" days");
		cc.add(cc.DATE, days);
		return cc.getTime();
	}

	public static Date add3days (int day)
	{
		switch(day){

		case 1: closedate=adddays(3);System.out.println("In add3days Case 1"+closedate); break;
		case 2: closedate=adddays(3);System.out.println("In add3days Case 2"+closedate); break;
		case 3: closedate=adddays(5);System.out.println("In add3days Case 3"+closedate); break;
		case 4: closedate=adddays(5);System.out.println("In add3days Case 4"+closedate); break;
		case 5: closedate=adddays(5);System.out.println("In add3days Case 5"+closedate); break;
		case 6: closedate=adddays(4);System.out.println("In add3days Case 6"+closedate); break;
		case 7: closedate=adddays(3);System.out.println("In add3days Case 0"+closedate); break;
		default:;
		}
		return closedate;
	}

	public static Date add5days (int day)
	{
		switch(day){

		case 1: closedate=adddays(7);System.out.println(" In add5days Case 1"+closedate); break;
		case 2: closedate=adddays(7);System.out.println(" In add5days Case 2"+closedate); break;
		case 3: closedate=adddays(7);System.out.println(" In add5days Case 3"+closedate); break;
		case 4: closedate=adddays(7);System.out.println(" In add5days Case 4"+closedate); break;
		case 5: closedate=adddays(7);System.out.println(" In add5days Case 5"+closedate); break;
		case 6: closedate=adddays(6);System.out.println(" In add5days Case 6"+closedate); break;
		case 7: closedate=adddays(5);System.out.println(" In add5days Case 0"+closedate); break;
		default:;
		}
		return closedate;
	}

}
