package com.psa.app.workorder;

import psdi.mbo.MboRemote;

public interface WOSkillsetCustomRemote extends MboRemote 
{
}
