package com.psa.app.common;

import java.rmi.RemoteException;
import java.util.Date;
import psdi.common.action.ActionCustomClass;
import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.mbo.MboRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXSystemException;


public class CustCronMonitor
implements ActionCustomClass
{

	public CustCronMonitor()
	{
	}
		
	public void applyCustomAction(MboRemote cron, Object param[])
		throws MXException, RemoteException
	{
        try 
        {
            System.out.println("-----------CustCronMonitor--------CronAction()------");

            String pattern = cron.getString("SCHEDULE");
            Date lastrun = cron.getDate("LASTRUN");
            System.out.println("-----------CustCronMonitor--------format------"+pattern);
            
            String[] str = getIndividualString(pattern);
            int repeatValue = Integer.parseInt(str[0].substring(0, str[0].length() - 1));
            String timeUnit = str[0].substring(str[0].length() - 1);            
            System.out.println("-----------CustCronMonitor--------repeatValue------"+repeatValue);
            System.out.println("-----------CustCronMonitor--------timeUnit------"+timeUnit);
            
            com.ibm.icu.util.Calendar c = com.ibm.icu.util.Calendar.getInstance();
            c.setTime(lastrun);
            com.ibm.icu.util.Calendar nextdate = getNextCalendar(c, str, repeatValue, timeUnit);
            
            com.ibm.icu.util.Calendar currentdate = com.ibm.icu.util.Calendar.getInstance();
            System.out.println("-----------CustCronMonitor--------nextdate------"+nextdate);
            System.out.println("-----------CustCronMonitor--------currentdate------"+currentdate);
            
	        if(currentdate.after(nextdate))
	        {	        
	        	CommTemplateSetRemote commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
				commTemplateSet.setWhere("TEMPLATEID='CRON_DUE'");
				commTemplateSet.reset();
				CommTemplateRemote tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);	
				String toMail=tempRemote.getString("TOLIST");
				String fromMail=tempRemote.getString("SENDFROM");
				String ccTo=tempRemote.getString("CCLIST");
				String bccTo=tempRemote.getString("BCCLIST");
				String subject=tempRemote.getString("SUBJECT");
				String message=tempRemote.getString("MESSAGE");
				String replyTo=tempRemote.getString("REPLYTO");
				
				message =message.replace("#INSTANCE", cron.getString("INSTANCENAME"));
				message =message.replace("#LASTRUN", cron.getString("LASTRUN"));
				
				toMail=tempRemote.convertSendTo("COMMTMPLT_TO", tempRemote);
				ccTo=tempRemote.convertSendTo("COMMTMPLT_CC", tempRemote);
				bccTo=tempRemote.convertSendTo("COMMTMPLT_BCC", tempRemote);
				
				MXServer.sendEMail(toMail, ccTo, bccTo, fromMail, subject, message, replyTo, null, null);	        	 
	        }
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
	}

public static String[] getIndividualString(String pattern)
		throws MXException
{
	int ind = 0;
	String[] str = new String[10];
	int i = 0;
		  
	if ((pattern == null) || (pattern.trim().length() == 0)) 
	{
		return str;
	}
	ind = pattern.indexOf(',');
while (ind > 0)
{
	str[i] = pattern.substring(0, ind);
	pattern = pattern.substring(ind + 1);
	ind = pattern.indexOf(',');
	i += 1;
}
str[9] = pattern.substring(0);

if (i != 9)
{
	throw new MXSystemException("system", "invalidpattern");
}
	  
String timeUnit = str[0].substring(str[0].length() - 1);
if ((!timeUnit.equals("s")) && (!timeUnit.equals("m")) && (!timeUnit.equals("h")) && (!timeUnit.equals("d")) && (!timeUnit.equals("w")) && (!timeUnit.equals("M")) && (!timeUnit.equals("y")))
{
	throw new MXSystemException("system", "invalidpattern");
}

String repeatStr = str[0].substring(0, str[0].length() - 1);
if ((repeatStr == null) || (repeatStr.trim().length() == 0)) 
{
	throw new MXSystemException("system", "invalidpattern");
}
int repeatValue;
try
{
	repeatValue = Integer.parseInt(repeatStr);
}
catch (Exception e)
{
	throw new MXSystemException("system", "invalidpattern", e);
}
if (repeatValue == 0) 
{
	throw new MXSystemException("dateselector", "zerorepeat");
}
	  
if ((timeUnit.equals("h")) && (str[2].equals("*"))) 
{
	throw new MXSystemException("system", "invalidpattern");
}
	  
if (timeUnit.equals("d"))
{
	if ((str[1].equals("*")) || (str[2].equals("*")) || (str[3].equals("*"))) 
	{
		throw new MXSystemException("system", "invalidpattern");
	}
}
	  
if (!str[1].equals("*"))
{
	int second = new Integer(str[1]).intValue();
	if ((second < 0) || (second > 59)) 
	{
		throw new MXSystemException("system", "invalidpattern");
	}
}
if (!str[2].equals("*"))
{
	int minute = new Integer(str[2]).intValue();
	if ((minute < 0) || (minute > 59)) 
	{
		throw new MXSystemException("system", "invalidpattern");
	}
}
	  
if (!str[3].equals("*"))
{
	int hour = new Integer(str[3]).intValue();
	if ((hour < 0) || (hour > 23)) 
	{
		throw new MXSystemException("system", "invalidpattern");
	}
}
if (!str[4].equals("*"))
{
	int day = new Integer(str[4]).intValue();
	if ((day < 1) || (day > 31)) 
	{
		throw new MXSystemException("system", "invalidpattern");
	}
}
if (!str[5].equals("*"))
{
	int month = new Integer(str[5]).intValue();
	if ((month < 0) || (month > 11)) 
	{
		throw new MXSystemException("system", "invalidpattern");
	}
}
if (!str[7].equals("*"))
{
	int dow = new Integer(str[7]).intValue();
	if ((dow < 1) || (dow > 7)) 
	{
		throw new MXSystemException("system", "invalidpattern");
	}
}
if (!str[8].equals("*"))
{
	int flDow = new Integer(str[8]).intValue();
	if ((flDow < 0) || (flDow > 1)) 
	{
		throw new MXSystemException("system", "invalidpattern");
	}
}
	  
if (!str[9].equals("*"))
{
	int flDom = new Integer(str[9]).intValue();
	if ((flDom < 0) || (flDom > 1))
		throw new MXSystemException("system", "invalidpattern");
	}
	return str;
}


public static com.ibm.icu.util.Calendar getNextCalendar(com.ibm.icu.util.Calendar c, String[] str, int repeatValue, String timeUnit)
		 throws MXException
	   {
		 int dow = c.get(7);
		 int dom = 0;
		 
		 try
		 {
		   if (timeUnit.equals("s")) {
		 c.add(13, repeatValue);
	   } else if (timeUnit.equals("m")) {
		 c.add(12, repeatValue);
	   } else if (timeUnit.equals("h")) {
		 c.add(11, repeatValue);
	   } else if (timeUnit.equals("d")) {
		 c.add(5, repeatValue);
	   } else if (timeUnit.equals("w")) {
		 c.add(5, 7 * repeatValue);
	   } else if (timeUnit.equals("M"))
	   {
 
		 if ((str[8].equals("*")) && (str[9].equals("*")))
		 {
		   if (c.get(2) + repeatValue <= c.getActualMaximum(2))
		   {
			 c.add(2, repeatValue);
		   }
		   else
		   {
			 c.add(1, (c.get(2) + repeatValue) / (c.getActualMaximum(2) + 1));
			 if (c.getActualMaximum(2) != c.get(2))
			 {
			   c.set(2, (c.get(2) + repeatValue) % (c.getActualMaximum(2) + 1));
			 }
			 else {
			   c.set(2, 0);
			 }
		   }
		   if (!"*".equals(str[4]))
		   {
			 int domInt = new Integer(str[4]).intValue();
			 dom = c.getActualMaximum(5);
			 if (domInt > dom) {
			   c.set(5, dom);
			 } else {
			   c.set(5, domInt);
			 }
			 if (!"*".equals(str[3])) {
			   int hodInt = new Integer(str[3]).intValue();
			   c.set(11, hodInt);
			 }
		   }
		 }
		 else if (str[8].equals("0"))
		 {
		   if (c.get(2) + repeatValue <= c.getActualMaximum(2))
		   {
			 c.add(2, repeatValue);
		   }
		   else
		   {
			 c.add(1, (c.get(2) + repeatValue) / (c.getActualMaximum(2) + 1));
			 if (c.getActualMaximum(2) != c.get(2))
			 {
			   c.set(2, (c.get(2) + repeatValue) % (c.getActualMaximum(2) + 1));
			 }
			 else {
			   c.set(2, 0);
			 }
		   }
		   c.set(5, 1);
		   if (c.get(7) > dow) {
			 c.add(5, dow + 7 - c.get(7));
		   } else if (c.get(7) < dow) {
			 c.add(5, dow - c.get(7));
		   }
		 } else if (str[8].equals("1"))
		 {
		   if (c.get(2) + repeatValue <= c.getActualMaximum(2)) {
			 c.add(2, repeatValue);
		   }
		   else
		   {
			 c.add(1, (c.get(2) + repeatValue) / (c.getActualMaximum(2) + 1));
			 if (c.getActualMaximum(2) != c.get(2))
			 {
			   c.set(2, (c.get(2) + repeatValue) % (c.getActualMaximum(2) + 1));
			 }
			 else {
			   c.set(2, 0);
			 }
		   }
		   dom = c.getActualMaximum(5);
		   c.set(5, dom);
		   if (c.get(7) > dow) {
			 c.add(5, -(c.get(7) - dow));
		   } else if (c.get(7) < dow) {
			 c.add(5, -(c.get(7) + 7 - dow));
		   }
		 } else if (str[9].equals("0"))
		 {
		   if (c.get(2) + repeatValue <= c.getActualMaximum(2)) {
			 c.add(2, repeatValue);
		   }
		   else
		   {
			 c.add(1, (c.get(2) + repeatValue) / (c.getActualMaximum(2) + 1));
			 if (c.getActualMaximum(2) != c.get(2))
			 {
			   c.set(2, (c.get(2) + repeatValue) % (c.getActualMaximum(2) + 1));
			 }
			 else {
			   c.set(2, 0);
			 }
		   }
		   c.set(5, 1);
		 }
		 else if (str[9].equals("1"))
		 {
		   if (c.get(2) + repeatValue <= c.getActualMaximum(2)) {
			 c.add(2, repeatValue);
		   }
		   else
		   {
			 c.add(1, (c.get(2) + repeatValue) / (c.getActualMaximum(2) + 1));
			 if (c.getActualMaximum(2) != c.get(2))
			 {
			   c.set(2, (c.get(2) + repeatValue) % (c.getActualMaximum(2) + 1));
			 }
			 else {
			   c.set(2, 0);
			 }
		   }
		   dom = c.getActualMaximum(5);
		   c.set(5, dom);
		 }
	   }
	   else if (timeUnit.equals("y"))
	   {
		 if ((str[8].equals("*")) && (str[9].equals("*")))
		 {
		   c.add(1, repeatValue);
		   if (!"*".equals(str[4]))
		   {
			 int domInt = new Integer(str[4]).intValue();
			 dom = c.getActualMaximum(5);
			 if (domInt > dom) {
			   c.set(5, dom);
			 } else {
			   c.set(5, domInt);
			 }
		   }
		 }
		 else if (str[8].equals("0"))
		 {
		   c.set(2, 0);
		   c.set(5, 1);
		   c.add(1, repeatValue);
		   if (c.get(7) > dow) {
			 c.add(5, dow + 7 - c.get(7));
		   } else if (c.get(7) < dow) {
			 c.add(5, dow - c.get(7));
		   }
		 }
		 else if (str[8].equals("1"))
		 {
 
		   int DOM = c.get(5);
		   c.set(5, DOM - 1);
		   c.add(1, repeatValue);
		   if (c.getActualMaximum(5) >= DOM) {
			 c.set(5, DOM);
		   }
		   
		   c.set(2, c.getActualMaximum(2));
		   c.set(5, c.getActualMaximum(5));
		   if (c.get(7) > dow) {
			 c.add(5, -(c.get(7) - dow));
		   } else if (c.get(7) < dow) {
			 c.add(5, -(c.get(7) + 7 - dow));
		   }
		 }
		 else if (str[9].equals("0"))
		 {
		   c.add(1, repeatValue);
		   c.set(5, 1);
 
		 }
		 else if (str[9].equals("1"))
		 {
		   c.add(1, repeatValue);
		   dom = c.getActualMaximum(5);
		   c.set(5, dom);
		 }
		 
 
 
		 int hodInt = new Integer(str[3]).intValue();
		 c.set(11, hodInt);
	   }
	 }
	 catch (Exception e)
	 {
	   throw new MXApplicationException("dateselector", "nextcalerror", e);
	 }
	 return c;
   }
}