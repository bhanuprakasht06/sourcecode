package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.FldWpSerItemNum;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXException;


public class FldWpSerItemNumCustom extends FldWpSerItemNum
{

	public FldWpSerItemNumCustom(MboValue mbovalue)
			throws MXException
	{
		super(mbovalue);
	}


	public void action()
			throws MXException, RemoteException
	{
		super.action();

		MboValue mbovalue = getMboValue();
		MboRemote wpservice = mbovalue.getMbo();
		if (mbovalue.isNull())
		{
			// Cater for empty value
			wpservice.setValueNull("vendor", MboConstants.NOACCESSCHECK);
		}
		else
		{
			MboSetRemote contractlineset = wpservice.getMboSet("CONTRACTLINE");
      	if (contractlineset.count() == 0)
			{
				// Cater for cases when item with contract is entered, then overridden with another item
				// witout contract
				wpservice.setValueNull("vendor", MboConstants.NOACCESSCHECK);
			}
			else
			{
				MboRemote contractline = contractlineset.getMbo(0);
				wpservice.setValue("vendor", contractline.getMboSet("CONTRACT").getMbo(0).getString(
						"vendor"), MboConstants.NOACCESSCHECK);
				wpservice.setValue("unitcost", contractline.getDouble("unitcost"));
			}
			contractlineset.close();
		}
	}
}
