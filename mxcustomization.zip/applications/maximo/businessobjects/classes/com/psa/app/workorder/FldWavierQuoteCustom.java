package com.psa.app.workorder;

import java.rmi.RemoteException;

import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MAXTableDomain;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldWavierQuoteCustom extends MAXTableDomain
{
	public FldWavierQuoteCustom(MboValue mbovalue) 
	{
			super(mbovalue);
	}
	
    public void validate()
		throws MXException, RemoteException
	{
		boolean wavierquote = getMboValue("WAVIERQUOTE").getBoolean();
		
		try
		{
			if(wavierquote)
	    		getMboValue("WAVIERQUOTEREMARK").getMbo().setFieldFlag("WAVIERQUOTEREMARK", MboConstantsCustom.REQUIRED, true);
			else
	    		getMboValue("WAVIERQUOTEREMARK").getMbo().setFieldFlag("WAVIERQUOTEREMARK", MboConstantsCustom.REQUIRED, false);
		} catch(RemoteException remoteexception) 
		{
			
		}
		
	} 
}