/*
 * Modification history
 * 29-10-2007	LS	DR-55		Creation
 */
package com.psa.app.rfq;

import psdi.app.rfq.QuotationLineRemote;

public interface QuotationLineCustomRemote 
	extends QuotationLineRemote 
{
}
