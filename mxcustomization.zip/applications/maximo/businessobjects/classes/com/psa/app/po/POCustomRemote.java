package com.psa.app.po;

import java.rmi.RemoteException;

import psdi.app.po.PORemote;


public interface POCustomRemote
		extends PORemote
{

	public abstract void setLD(boolean bool)
			throws RemoteException;

	public abstract boolean getLD()
			throws RemoteException;

}
