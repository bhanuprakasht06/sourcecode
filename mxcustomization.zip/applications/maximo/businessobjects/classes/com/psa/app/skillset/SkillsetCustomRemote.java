package com.psa.app.skillset;

import psdi.mbo.MboRemote;

public interface SkillsetCustomRemote extends MboRemote 
{
}
