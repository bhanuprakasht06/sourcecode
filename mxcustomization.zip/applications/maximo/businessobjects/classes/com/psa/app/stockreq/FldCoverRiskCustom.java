/*
 * Modification history
 * 31-05-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

public class FldCoverRiskCustom extends MboValueAdapter
{

    public FldCoverRiskCustom(MboValue mbovalue)
        throws MXException, RemoteException
    {
        super(mbovalue);
    }

    public void action()
    	throws MXException, RemoteException
    {
    	MboRemote mboRemote = getMboValue().getMbo();
    	boolean coverrisk = mboRemote.getBoolean("coverrisk");
    	if (coverrisk)
    	{   		
    		mboRemote.setFieldFlag("REORDERUSGQTY", 8L, false);
    		mboRemote.setFieldFlag("REORDERUSGINT", 8L, false);
    	}
    	else
    	{
    		mboRemote.setFieldFlag("REORDERUSGQTY", 8L, true);
    		mboRemote.setFieldFlag("REORDERUSGINT", 8L, true);
    	}    	
    }
}