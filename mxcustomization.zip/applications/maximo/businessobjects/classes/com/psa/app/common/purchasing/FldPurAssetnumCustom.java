/**
 * @author	HCHA
 * Date		Jul 3, 2006
 * Comment	 
 */
package com.psa.app.common.purchasing;

import psdi.app.common.purchasing.FldPurAssetnum;
import psdi.app.item.ItemRemote;
import psdi.app.item.ItemSetRemote;
import psdi.mbo.GLFormat;
import psdi.mbo.Mbo;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;
import java.rmi.RemoteException;

/**
 * @author		HCHA
 * @class		FldPurAssetnumCustom
 * @date		Jul 3, 2006
 * @function	
 */
public class FldPurAssetnumCustom extends FldPurAssetnum 
{

	//20061004 HCHA - Add 1 Type Segment
	//private static final String LABSERV_DEBIT_GL = "???-????-?-??-???-????-????-004";
	
	/*BCT modifications starts.
	 * COA structure change from 24 Bit to 28 Bit
	
	private static final String LABSERV_DEBIT_GL = "???-????-1-??-???-????-????-004";
	private static final String MATERIAL_RC = "???-????-1-??-???-????-????-003";
	private static final String SERVICE_RC = "???-????-1-??-???-????-????-005";*/
	
    private static final String LABSERV_DEBIT_GL = "???-???????-???-????-???-????-????";
    private static final String MATERIAL_RC = "???-???????-???-????-???-????-????";
    private static final String SERVICE_RC = "???-???????-???-????-???-????-????";
   
	/*BCT modifications ends.
	 * COA structure change from 24 Bit to 28 Bit
	 */
	/**
	 * @param arg0
	 * @throws MXException
	 */
	public FldPurAssetnumCustom(MboValue arg0) throws MXException {
		super(arg0);
	}
	
	public void action()
	    throws MXException, RemoteException
	{
	    super.action();
	    
	    Mbo mbo = getMboValue().getMbo();
	    
	    //Check for if it is Labor Service 	   
	    if(!mbo.isNull("itemnum")){
	        //Get item mbo
		    ItemSetRemote itemSet =(ItemSetRemote) MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo());
		    	
		    SqlFormat sqlformatItemSet = new SqlFormat(mbo.getUserInfo(), "itemnum = :1 and itemsetid = :2");
		    sqlformatItemSet.setObject(1, "PRLINE", "ITEMNUM", mbo.getString("itemnum"));
		    sqlformatItemSet.setObject(2, "PRLINE", "ITEMSETID", mbo.getString("itemsetid"));
		    itemSet.setWhere(sqlformatItemSet.format());
		           
		    if(!itemSet.isEmpty())
		    {
		        ItemRemote item = (ItemRemote) itemSet.getMbo(0);
		        boolean isLabService = item.getBoolean("LABORSERVICE");
		        if(isLabService){
						
			        //Get current debit Glaccount
			        String curGLAccount = mbo.getString("gldebitacct");
					//System.out.println("[FldPurItemNumcustom.getGLDebitAcct]Current Debit GL Account:"+curGLAccount);
						
					if(curGLAccount!=null&&!curGLAccount.equals("")){
						GLFormat glformat = new GLFormat(LABSERV_DEBIT_GL, mbo.getString("orgid"));
						glformat.mergeString(curGLAccount);
						//System.out.println("[FldPurItemNumcustom.getGLDebitAcct]Merged GL Account:"+glformat.toDisplayString());
							
						mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
					}          		
		        }
		    }
	    }
	    else{
	    	//For Item Type = Service or Material => Merge GL Account with resource code

	    	String linetype = mbo.getString("LINETYPE");
	    	
	    	if(linetype.equalsIgnoreCase("MATERIAL")){
	    		//Get current debit Glaccount
		        String curGLAccount = mbo.getString("gldebitacct");
				//System.out.println("[FldPurRefWOCustom.action()]Current Debit GL Account:"+curGLAccount);
					
				if(curGLAccount!=null  && !curGLAccount.equals("")){
					GLFormat glformat = new GLFormat(MATERIAL_RC, mbo.getString("orgid"));
					glformat.mergeString(curGLAccount);
					//System.out.println("[FldPurRefWOCustom.action()]Merged GL Account:"+glformat.toDisplayString());
						
					mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
				}  	    		
	    	}
	    	else if(linetype.equalsIgnoreCase("SERVICE")){
	    		//Get current debit Glaccount
		        String curGLAccount = mbo.getString("gldebitacct");
				//System.out.println("[FldPurRefWOCustom.action()]Current Debit GL Account:"+curGLAccount);
					
				if(curGLAccount!=null  && !curGLAccount.equals("")){
					GLFormat glformat = new GLFormat(SERVICE_RC, mbo.getString("orgid"));
					glformat.mergeString(curGLAccount);
					//System.out.println("[FldPurRefWOCustom.action()]Merged GL Account:"+glformat.toDisplayString());
						
					mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
				} 
	    	}
	    }
	}

}

