package com.psa.app.pm;

import psdi.app.pm.PMSetRemote;

public interface PMCustomSetRemote extends PMSetRemote {
		
}
