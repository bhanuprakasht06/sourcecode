/*
 * Modification history
 * 15-10-2007	AGD	eRFQ		Creation
 */
package com.psa.app.common.purchasing;

import java.rmi.RemoteException;

import psdi.app.common.purchasing.FldPurLineCost;
import com.psa.app.rfq.QuotationAltCustomRemote;
import psdi.mbo.MboValue;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldPurLineCostCustom extends FldPurLineCost
{

	public FldPurLineCostCustom(MboValue linecostvalue)
			throws MXException
	{
		super(linecostvalue);
	}


	public void action()
			throws MXException, RemoteException
	{
		try
		{
			super.action();
		}
		catch (MXApplicationException mxe)
		{
			// Ignore errors "attribute doesn't exist" because super.linecost_class.action exits in the middle if the mbo is quotation
			if (getMboValue().getMbo() instanceof QuotationAltCustomRemote &&
					mxe.getErrorGroup().equalsIgnoreCase("system") && mxe.getErrorKey().equalsIgnoreCase("noattribute"))
				return;
			else
				throw mxe;
		}
	}
}
