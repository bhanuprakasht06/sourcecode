package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

public class FldWOInterruptDate extends MboValueAdapter {

	public FldWOInterruptDate(MboValue mbovalue) 
	{
		super(mbovalue);
	}

	public void validate()
	    throws MXException, RemoteException
	{
//		System.out.println("[WOInterruptCustom]validate : going in");
		WOInterruptCustom wointerruptcustom = (WOInterruptCustom)getMboValue().getMbo();
		if(getMboValue().isNull())
	    {
			wointerruptcustom.updateIntHrsNull();
//			System.out.println("[WOInterruptCustom]Fld: Update: null");
	    	return;
	    }
	    MboValue mbovalue = getMboValue("StartDate");
//	    System.out.println("[WOInterruptCustom]Fld: Start Date: " + mbovalue.getDate());
	    MboValue mbovalue1 = getMboValue("EndDate");
//	    System.out.println("[WOInterruptCustom]Fld: End Date: " + mbovalue1.getDate());

	    wointerruptcustom.checkIntDate(mbovalue.getDate(), mbovalue1.getDate());
	    
//	    System.out.println("[WOInterruptCustom]Fld: check pass");
	    if(mbovalue.isNull() || mbovalue1.isNull())
	        return;

	    wointerruptcustom.updateIntHrs();
	}
	
}
