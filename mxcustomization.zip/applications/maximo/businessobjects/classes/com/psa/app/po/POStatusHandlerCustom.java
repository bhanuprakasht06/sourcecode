/*
 * Modification history
 * 28-07-2011   WMJ     EMS-461  Creation on behalf of Tricia Teo for JIRA EMS-461
 *
 * 14-08-2013-- CR-1 -  Enhance PO Status Change to Set RFQ status - 'FINISHED' on PO Cancel.
 * 14-08-2013-- 4.2.8 - Enhance Maximo to allow the cancellation of Purchase Order (PO) when there are transactions done in the PO with net amount that is zero (0).
 * 14-08-2013-- 4.2.8 - WMJ change set printdate to old value 
 *
*/
package com.psa.app.po;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.Vector;

import psdi.app.common.RoundToScale;
import psdi.app.common.purchasing.PurchasingMbo;
import psdi.app.contract.ContractRemote;
import psdi.app.contract.purch.PurchViewRemote;
import psdi.app.contract.software.SFWViewRemote;
import psdi.app.currency.CurrencyServiceRemote;
import psdi.app.financial.FinancialServiceRemote;
import psdi.app.integration.IntegrationServiceRemote;
import psdi.app.inventory.InvReserveRemote;
import psdi.app.inventory.InvReserveSet;
import psdi.app.inventory.InventoryRemote;
import psdi.app.item.ItemOrgInfoRemote;
import psdi.app.mr.MRRemote;
import psdi.app.po.PO;
import psdi.app.po.POLine;
import psdi.app.po.POLineSetRemote;
import psdi.app.po.PORemote;
import psdi.app.po.POStatusHandler;
import psdi.app.pr.PR;
import psdi.app.pr.PRLineRemote;
import psdi.app.pr.PRRemote;
import psdi.app.rfq.RFQLineRemote;
import psdi.app.rfq.RFQLineSetRemote;
import psdi.app.rfq.RFQRemote;
import psdi.app.workorder.WORemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.mbo.StatefulMbo;
import psdi.mbo.StatefulMboRemote;
import psdi.security.UserInfo;
import psdi.server.AppService;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXApplicationYesNoCancelException;
import psdi.util.MXException;
import psdi.util.MXFormat;
import psdi.util.MXMath;
import psdi.util.Resolver;

public class POStatusHandlerCustom extends POStatusHandler
{
        private StatefulMbo parent = null;
        private String CANCEL;

  public POStatusHandlerCustom(StatefulMbo statefulMbo)
  {
    super(statefulMbo);
    this.parent = statefulMbo;
    CANCEL = "CAN";
  }

  /*public void approve(Date date)
    throws MXException, RemoteException
  {
    //System.out.println("---------------------------- Entering POStatusHandlerCustom.approve() function ----------------------------");


    String str1 = this.parent.getString("potype");
    String str2 = this.parent.getTranslator().toInternalString("POTYPE", str1);
    MboSetRemote localMboSetRemote = this.parent.getMboSet("POLINE");
    ((PO)this.parent).validatePO();
    if (!this.parent.getBoolean("buyahead"))
    {
      double d1 = ((PurchasingMbo)this.parent).getExchangeRate(date);
      this.parent.setValue("exchangerate", d1, 2L);
      this.parent.setValue("exchangedate", date, 2L);
    }
    double d1 = ((PurchasingMbo)this.parent).getExchangeRate2(date);
    if (d1 != 0.0D)
      this.parent.setValue("exchangerate2", d1, 2L);
    double d2 = this.parent.getDouble("totalcost");
    double d3 = this.parent.getDouble("totalcost") * this.parent.getDouble("exchangerate");
    CurrencyServiceRemote localCurrencyServiceRemote = (CurrencyServiceRemote)MXServer.getMXServer().lookup("CURRENCY");
    double d4 = this.parent.getDouble("preTaxTotal") * this.parent.getDouble("exchangerate");
    double d5;
    Object localObject1;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    if (str2.equals("REL"))
    {

        //System.out.println("---------------------------- Entering if PO-REL = 'REL' ----------------------------");

      d5 = 0.0D;
      localObject1 = (PurchViewRemote)this.parent.getMboSet("PURCHVIEW").getMbo(0);
      double d7 = 0.0D;
      if (((PurchViewRemote)localObject1).getString("currencycode").equalsIgnoreCase(this.parent.getString("currencycode")))
      {
        d5 = this.parent.getDouble("preTaxTotal");
        //d7 = ((PurchViewRemote)localObject1).getInvoiceVariance() + ((PurchViewRemote)localObject1).getAmountReceived() + ((PurchViewRemote)localObject1).getAmountOnOrder() + this.parent.getDouble("pretaxtotal");
      d7 = this.parent.getDouble("preTaxTotal");

      //System.out.println("Testing the amount of d7= " + d7);

      }
      else
      {
        //d7 = ((PurchViewRemote)localObject1).getInvoiceVariance() + ((PurchViewRemote)localObject1).getAmountReceived() + ((PurchViewRemote)localObject1).getAmountOnOrder() + this.parent.getDouble("pretaxtotal") * localCurrencyServiceRemote.getCurrencyExchangeRate(this.parent.getUserInfo(), this.parent.getString("currencycode"), ((PurchViewRemote)localObject1).getString("currencycode"), date, ((PurchViewRemote)localObject1).getString("orgid"));
        d7 = this.parent.getDouble("preTaxTotal") * localCurrencyServiceRemote.getCurrencyExchangeRate(this.parent.getUserInfo(), this.parent.getString("currencycode"), ((PurchViewRemote)localObject1).getString("currencycode"), date, ((PurchViewRemote)localObject1).getString("orgid"));

        //System.out.println("Testing the amount of d7= " + d7);

        d5 = this.parent.getDouble("preTaxTotal") * localCurrencyServiceRemote.getCurrencyExchangeRate(this.parent.getUserInfo(), this.parent.getString("currencycode"), ((PurchViewRemote)localObject1).getString("currencycode"), date, ((PurchViewRemote)localObject1).getString("orgid"));
      }
      if ((!((PurchViewRemote)localObject1).isNull("maxrelvol")) && (d5 > ((PurchViewRemote)localObject1).getDouble("maxrelvol")))
        throw new MXApplicationException("po", "exceedsMaxRelVol");
      if ((!((PurchViewRemote)localObject1).isNull("maxvol")) && (d7 > ((PurchViewRemote)localObject1).getDouble("maxvol")))
      {
        localObject2 = new Double(d7 - ((PurchViewRemote)localObject1).getDouble("maxvol"));
        if (((PurchViewRemote)localObject1).getBoolean("canexceedvolume"))
        {
          localObject3 = new String[] { ((PurchViewRemote)localObject1).getString("maxvol"), ((PurchViewRemote)localObject1).getString("currencycode"), ((PurchViewRemote)localObject1).getString("contractnum"), MXFormat.doubleToString(((Double)localObject2).doubleValue(), MXServer.getMXServer().getMaximoDD().getMboSetInfo("PURCHVIEW").getMboValueInfo("totalcost").getScale()), ((PurchViewRemote)localObject1).getString("currencycode") };
          localObject4 = this.parent.getUserInfo();
          if (((UserInfo)localObject4).isInteractive())
          {
            int k = MXApplicationYesNoCancelException.getUserInput("exceedsMaxVolWarning", MXServer.getMXServer(), (UserInfo)localObject4);
            switch (k)
            {
            case -1:
              throw new MXApplicationYesNoCancelException("exceedsMaxVolWarning", "contract", "exceedsMaxVol");
            case 2:
            }
          }
        }
        else
        {
          localObject3 = new String[] { ((PurchViewRemote)localObject1).getString("maxvol"), ((PurchViewRemote)localObject1).getString("currencycode"), MXFormat.doubleToString(((Double)localObject2).doubleValue(), MXServer.getMXServer().getMaximoDD().getMboSetInfo("PURCHVIEW").getMboValueInfo("totalcost").getScale()), ((PurchViewRemote)localObject1).getString("currencycode") };
          throw new MXApplicationException("po", "exceededMaxVol");
        }
      }
    }
    if (((PO)this.parent).checkLimitWhenApprove)
    {
      d5 = this.parent.getProfile().getTolerance("POLIMIT", this.parent.getString("orgid"));
      localObject1 = this.parent.getString("currencycode");
      if ((d5 != 0.0D) && (d3 > d5))
        throw new MXApplicationException("po", "approveamountexceeded");
    }
    int i = 0;
    double d6 = 0.0D;
    for (int j = 0; ; ++j)
    {
      POLine localPOLine = (POLine)localMboSetRemote.getMbo(j);
      if (localPOLine == null)
        break;
      localObject2 = new String[] { localPOLine.getString("polinenum") };
      if ((((localPOLine.getBoolean("issue")) || (localPOLine.isNull("itemnum")))) && (((localPOLine.getString("assetnum").equalsIgnoreCase("")) || (localPOLine.isNull("assetnum")))) && (((localPOLine.getString("wonum").equalsIgnoreCase("")) || (localPOLine.isNull("wonum")))) && (((localPOLine.getString("location").equalsIgnoreCase("")) || (localPOLine.isNull("location")))) && (((localPOLine.getString("gldebitacct").equalsIgnoreCase("")) || (localPOLine.isNull("gldebitacct")))))
        throw new MXApplicationException("po", "assetwolocglNull");
      if ((!localPOLine.getBoolean("issue")) && (localPOLine.getString("storeloc").equalsIgnoreCase("")))
        throw new MXApplicationException("po", "StoreLocIsNull");
      if (d1 != 0.0D)
        localPOLine.setValue("linecost2", localPOLine.getDouble("linecost") * d1, 2L);
      if (!localPOLine.getString("contractrefnum").equals(""))
      {
        localObject3 = new SqlFormat(this.parent, "contractnum=:1 and revisionnum=:2 and orgid=:3");
        ((SqlFormat)localObject3).setObject(1, "CONTRACT", "contractnum", localPOLine.getString("contractrefnum"));
        ((SqlFormat)localObject3).setObject(2, "CONTRACT", "revisionnum", localPOLine.getString("contractrefrev"));
        ((SqlFormat)localObject3).setObject(3, "CONTRACT", "orgid", localPOLine.getString("orgid"));
        localObject4 = this.parent.getMboSet("$releases", "CONTRACT", ((SqlFormat)localObject3).format()).getMbo(0);
        if ((localObject4 != null) && (!((ContractRemote)localObject4).getInternalStatus().equalsIgnoreCase("APPR")))
          throw new MXApplicationException("po", "agreementnotapproved");
      }
      if (i != 0)
      {
        localPOLine.setValue("proratecost", 0.0D, 2L);
      }
      else
      {
        d6 = localPOLine.getDouble("proratecost");
        if (d6 != 0.0D)
        {
          localPOLine.setValue("proratecost", 0.0D, 2L);
          i = 1;
        }
      }
      localObject3 = new String[] { localPOLine.getString("polinenum") };
      if (!localPOLine.getString("wonum").equalsIgnoreCase(""))
      {
        localObject4 = localPOLine.getMboSet("WORKORDER").getMbo(0);
        if ((localObject4 != null) && (!localPOLine.getBoolean("receiptscomplete")))
        {
          String str3 = ((WORemote)localObject4).getInternalStatus();
          if ((str3.equals("CAN")) || (str3.equals("CLOSE")) || (str3.equals("WAPPR")))
            throw new MXApplicationException("po", "invalidWO");
        }
      }
      localObject4 = localPOLine.getString("glcreditacct");
      String str3 = localPOLine.getString("gldebitacct");
      Object localObject5 = localPOLine.getString("orgid");
      FinancialServiceRemote localFinancialServiceRemote = (FinancialServiceRemote)((AppService)this.parent.getMboServer()).getMXServer().lookup("FINANCIAL");
      Object localObject7;
      MboRemote localMboRemote1;
      if (!((String)localObject4).equals(""))
      {
        Object localObject6 = null;
        if (this.parent.getBoolean("internal"))
        {
          localObject7 = new SqlFormat(this.parent.getUserInfo(), "siteid = :1");
          ((SqlFormat)localObject7).setObject(1, "SITE", "SITEID", this.parent.getString("storelocsiteid"));
          localMboRemote1 = this.parent.getMboSet("$sitegl", "SITE", ((SqlFormat)localObject7).format()).getMbo(0);
          if (localMboRemote1 != null)
          {
            localObject6 = localObject5;
            localObject5 = localMboRemote1.getString("orgid");
          }
        }
        if (!localFinancialServiceRemote.validateFullGLAccount(this.parent.getUserInfo(), (String)localObject4, (String)localObject5))
          throw new MXApplicationException("po", "glcreditnotfull");
        if (localObject6 != null)
          localObject5 = localObject6;
      }
      if (this.parent.getBoolean("internal"))
      {
        Object localObject6 = new SqlFormat(this.parent.getUserInfo(), "siteid = :1");
        ((SqlFormat)localObject6).setObject(1, "SITE", "SITEID", localPOLine.getString("tositeid"));
        localObject7 = this.parent.getMboSet("$siteg2", "SITE", ((SqlFormat)localObject6).format()).getMbo(0);
        if (localObject7 != null)
          localObject5 = ((MboRemote)localObject7).getString("orgid");
      }
      if ((!str3.equals("")) && (!localFinancialServiceRemote.validateFullGLAccount(this.parent.getUserInfo(), str3, (String)localObject5)))
        throw new MXApplicationException("po", "gldebitnotfull");
      Object localObject6 = localPOLine.getMboSet("POCOST");
      for (int l = 0; ; ++l)
      {
        localMboRemote1 = ((MboSetRemote)localObject6).getMbo(l);
        if (localMboRemote1 == null)
          break;
        if (localMboRemote1.toBeDeleted())
          continue;
        if ((localFinancialServiceRemote.glRequiredForTrans(localMboRemote1.getUserInfo(), (String)localObject5)) && (((localMboRemote1.isNull("gldebitacct")) || (localMboRemote1.isNull("glcreditacct")))))
          throw new MXApplicationException("financial", "GLRequiredForTrans");
        if ((localMboRemote1.getString("gldebitacct").equals("")) || (localFinancialServiceRemote.validateFullGLAccount(this.parent.getUserInfo(), localMboRemote1.getString("gldebitacct"), (String)localObject5)))
          continue;
        throw new MXApplicationException("po", "GLDebitMustBeFull");
      }
      if ((this.parent.getBoolean("internal")) && (!localPOLine.isServiceType()))
      {
        Object localObject8 = (IntegrationServiceRemote)((AppService)this.parent.getMboServer()).getMXServer().lookup("INTEGRATION");
        boolean bool1 = ((IntegrationServiceRemote)localObject8).useIntegrationRules(this.parent.getString("ownersysid"), localPOLine.getString("ITEM.ownersysid"), "PORES", this.parent.getUserInfo());
        if (!bool1)
        {
          Object localObject9 = this.parent.getString("storeloc");
          Object localObject10 = "";
          boolean bool2 = false;
          Object localObject11 = new SqlFormat(this.parent.getUserInfo(), "siteid=:1 and polineid=:2");
          ((SqlFormat)localObject11).setObject(1, "POLINE", "siteid", localPOLine.getString("tositeid"));
          ((SqlFormat)localObject11).setObject(2, "POLINE", "polineid", localPOLine.getString("polineid"));
          Object localObject12 = (InvReserveSet)this.parent.getMboSet("$invreserve", "INVRESERVE", ((SqlFormat)localObject11).format());
          if (((InvReserveSet)localObject12).isEmpty())
          {
            InvReserveRemote localInvReserveRemote = ((InvReserveSet)localObject12).addPOReservation(localPOLine, (String)localObject9, this.parent.getString("storeLocSiteID"), (String)localObject10, bool2);
                }
        }
      }
      localPOLine.generateWO();
      if (localPOLine.isNull("itemnum"))
        continue;
      Object localObject8 = localPOLine.getString("itemnum");
      String str4 = localPOLine.getString("itemsetid");
      Object localObject9 = new SqlFormat(this.parent.getUserInfo(), "itemnum = :1");
      ((SqlFormat)localObject9).setObject(1, "ITEM", "itemnum", (String)localObject8);
      Object localObject10 = this.parent.getMboSet("$itemtable", "item", ((SqlFormat)localObject9).format());
      MboRemote localMboRemote2 = ((MboSetRemote)localObject10).getMbo(0);
      if (localMboRemote2 == null)
      {
        Object localObject11 = localPOLine.getMRPassedIn();
        if (localObject11 != null)
          localMboRemote2 = (MboRemote)((MRRemote)localObject11).getItemReferenceHashtable().get((String)localObject8 + "&" + str4);
      }
      Object localObject11 = localMboRemote2.getString("ownersysid");
      Object localObject12 = (IntegrationServiceRemote)((AppService)this.parent.getMboServer()).getMXServer().lookup("INTEGRATION");
      boolean bool3 = ((IntegrationServiceRemote)localObject12).useIntegrationRules(this.parent.getString("ownersysid"), (String)localObject11, "POIVM", this.parent.getUserInfo());
      if (bool3)
        continue;
      localPOLine.updateInvVendor();
    }
    ((PORemote)this.parent).prorateServices();
    ((PORemote)this.parent).createInvoicesForSchedule();

        //System.out.println("---------------------------- Exiting POStatusHandlerCustom.approve() function ----------------------------");

  }*/
  
  
	public void approve(Date date)
		     throws MXException, RemoteException
		  	{
		  		MboRemote contract = this.parent.getMboSet("CONTRACTREF").getMbo(0);
				String maxContractType = "";
		     
				if (contract != null)
				{
					maxContractType = this.parent.getTranslator().toInternalString("CONTRACTTYPE", contract.getString("contracttype"));
				}
		     
		 
				MboSetRemote poLines = this.parent.getMboSet("POLINE");
				Vector<String> itemsPlanning = new Vector();
				Vector<String> items = new Vector();
		     
				if (!poLines.isEmpty())
				{
		 
					POLine poLine = null;
					int l = 0;
		       
					while ((poLine = (POLine)poLines.getMbo(l++)) != null)
					{
						MboSetRemote invSet = poLine.getMboSet("INVENTORY");
						InventoryRemote inv = null;
						if (!invSet.isEmpty())
						{
							inv = (InventoryRemote)invSet.getMbo(0);
							if (!this.parent.getBoolean("internal"))
							{
								if ((inv.isPendobs()) || (inv.isPlanning()))
								{
									if ((poLine.getDouble("receivedtotalcost") != 0.0D) || (poLine.getBoolean("receiptscomplete"))) 
									{
										continue;
									}
									items.addElement(inv.getString("itemnum") + " ");
								}
							}
							else if (inv.isPlanning())
							{
								itemsPlanning.addElement(inv.getString("itemnum") + " ");
								continue;
							}
						}
						if (this.parent.getBoolean("internal") == true)
						{
							SqlFormat sqlf = new SqlFormat(poLine, "itemnum=:1 and itemsetid=:2 and location=:3 and siteid=:4");
							sqlf.setObject(1, "INVENTORY", "itemnum", poLine.getString("itemnum"));
							sqlf.setObject(2, "INVENTORY", "itemsetid", poLine.getString("itemsetid"));
							sqlf.setObject(3, "INVENTORY", "location", this.parent.getString("storeloc"));
							sqlf.setObject(4, "INVENTORY", "siteid", poLine.getString("tositeid"));
							inv = null;
							inv = (InventoryRemote)poLine.getMboSet("$temp", "INVENTORY", sqlf.format()).getMbo(0);
							if (inv != null)
							{
								if (inv.isPlanning())
								{
									itemsPlanning.addElement(inv.getString("itemnum") + " ");
									continue;
								}
							}
						}
						if (poLine.getString("storeloc").equals(""))
						{
							MboSetRemote itemOrgSet = poLine.getMboSet("ITEMORGINFO");
							ItemOrgInfoRemote itemOrg = null;
							if (!itemOrgSet.isEmpty())
							{
								itemOrg = (ItemOrgInfoRemote)itemOrgSet.getMbo(0);
								if ((itemOrg.isPendobs()) || (itemOrg.isPlanning()))
								{
									items.addElement(itemOrg.getString("itemnum") + " ");
								}
							}
						}
					}
					if (!this.parent.getBoolean("internal"))
					{
						if (!items.isEmpty())
						{
							String[] params = { items.toString(), "PLANNING or PENDOBS" };
							throw new MXApplicationException("item", "InvalidStatusForPO", params);
						}
					}
					else if (!itemsPlanning.isEmpty())
					{
						String[] params = { itemsPlanning.toString(), "PLANNING" };
						throw new MXApplicationException("item", "InvalidStatusForPO", params);
					}
				}
				String poType = this.parent.getString("potype");
				String maxType = this.parent.getTranslator().toInternalString("POTYPE", poType);
				((PO)this.parent).validatePO();
				if (!this.parent.getBoolean("buyahead"))
				{
					double exchangeRate = ((PurchasingMbo)this.parent).getExchangeRate(date);
					this.parent.setValue("exchangerate", exchangeRate, 2L);
					this.parent.setValue("exchangedate", date, 2L);
				}
				double exchangeRate2 = ((PurchasingMbo)this.parent).getExchangeRate2(date);
				if (exchangeRate2 != 0.0D) 
				{
					this.parent.setValue("exchangerate2", exchangeRate2, 2L);
				}
				double totalCost = this.parent.getDouble("totalcost");
				double totalCostInBase = this.parent.getDouble("totalcost") * this.parent.getDouble("exchangerate");
				CurrencyServiceRemote currServ = (CurrencyServiceRemote)MXServer.getMXServer().lookup("CURRENCY");
				double preTaxTotal = this.parent.getDouble("preTaxTotal") * this.parent.getDouble("exchangerate");
				String currentInternalStatus = this.parent.getInternalStatus();
				if (maxType.equals("REL"))
				{
					double preTaxInContractCurrency = 0.0D;
					double totalReleaseCost = 0.0D;
					double currentPOReleaseCost = 0.0D;
					for (int k = 0;; k++)
					{
						POLine oneLine = (POLine)poLines.getMbo(k);
						if (oneLine == null)
							break;
						currentPOReleaseCost = MXMath.add(currentPOReleaseCost, oneLine.getDouble("receivedtotalcost"));
					}
		       
					if ((maxContractType.equalsIgnoreCase("SFWCONTRACT")) || (maxContractType.equalsIgnoreCase("ENTERPRISE")) || (maxContractType.equalsIgnoreCase("OEM")) || (maxContractType.equalsIgnoreCase("RETAIL")) || (maxContractType.equalsIgnoreCase("SELECT")) || (maxContractType.equalsIgnoreCase("SUBSCRIPTION")))
					{
						SFWViewRemote swViewRemote = (SFWViewRemote)this.parent.getMboSet("SFWVIEW").getMbo(0);
						if (swViewRemote.getString("currencycode").equalsIgnoreCase(this.parent.getString("currencycode")))
						{
							preTaxInContractCurrency = this.parent.getDouble("preTaxTotal");
						}
						else
						{
							preTaxInContractCurrency = this.parent.getDouble("preTaxTotal") * currServ.getCurrencyExchangeRate(this.parent.getUserInfo(), this.parent.getString("currencycode"), swViewRemote.getString("currencycode"), date, swViewRemote.getString("orgid"));
						}		 
			 
			 
						if ((!swViewRemote.isNull("maxrelvol")) && (preTaxInContractCurrency > swViewRemote.getDouble("maxrelvol")))
						{
							Double diffInCosts = new Double(preTaxInContractCurrency - swViewRemote.getDouble("maxrelvol"));
							String[] params = { swViewRemote.getString("maxrelvol"), MXFormat.doubleToString(diffInCosts.doubleValue(), MXServer.getMXServer().getMaximoDD().getMboSetInfo("SFWVIEW").getMboValueInfo("totalcost").getScale()) };
							throw new MXApplicationException("po", "exceedsMaxRelVol", params);
						}
					 
						if (!swViewRemote.isNull("maxvol"))
						{
							if (swViewRemote.getString("currencycode").equalsIgnoreCase(this.parent.getString("currencycode")))
							{
								//totalReleaseCost = swViewRemote.getInvoiceVariance() + swViewRemote.getAmountReceived() + swViewRemote.getAmountOnOrder() - currentPOReleaseCost + this.parent.getDouble("pretaxtotal");
								totalReleaseCost = this.parent.getDouble("preTaxTotal");
							}
							else
							{
								double exchangeRate = currServ.getCurrencyExchangeRate(this.parent.getUserInfo(), this.parent.getString("currencycode"), swViewRemote.getString("currencycode"), date, swViewRemote.getString("orgid"));
								//totalReleaseCost = swViewRemote.getInvoiceVariance() + swViewRemote.getAmountReceived() + swViewRemote.getAmountOnOrder() - currentPOReleaseCost * exchangeRate + this.parent.getDouble("pretaxtotal") * exchangeRate;
								totalReleaseCost = this.parent.getDouble("preTaxTotal") * exchangeRate;
							}
					   
							if (totalReleaseCost > swViewRemote.getDouble("maxvol"))
							{
								Double diffInCosts = new Double(totalReleaseCost - swViewRemote.getDouble("maxvol"));
								if (swViewRemote.getBoolean("canexceedvolume"))
								{
									String[] params = { swViewRemote.getString("maxvol"), swViewRemote.getString("currencycode"), swViewRemote.getString("contractnum"), MXFormat.doubleToString(diffInCosts.doubleValue(), MXServer.getMXServer().getMaximoDD().getMboSetInfo("PURCHVIEW").getMboValueInfo("totalcost").getScale()), swViewRemote.getString("currencycode") };
									UserInfo userInfo = this.parent.getUserInfo();
									if (userInfo.isInteractive())
									{
										int userInput = MXApplicationYesNoCancelException.getUserInput("exceedsMaxVolWarning", MXServer.getMXServer(), userInfo);
										switch (userInput)
										{ 
											case -1: 
											
												throw new MXApplicationYesNoCancelException("exceedsMaxVolWarning", "contract", "exceedsMaxVol", params);
										}
									}
								}
								else
								{
									String[] params2 = { swViewRemote.getString("maxvol"), swViewRemote.getString("currencycode"), MXFormat.doubleToString(diffInCosts.doubleValue(), MXServer.getMXServer().getMaximoDD().getMboSetInfo("PURCHVIEW").getMboValueInfo("totalcost").getScale()), swViewRemote.getString("currencycode") };
									throw new MXApplicationException("po", "exceededMaxVol", params2);
								}
							}
						}
					}
					else
					{
						PurchViewRemote purchViewRemote = (PurchViewRemote)this.parent.getMboSet("PURCHVIEW").getMbo(0);
						if (purchViewRemote.getString("currencycode").equalsIgnoreCase(this.parent.getString("currencycode")))
						{
							preTaxInContractCurrency = this.parent.getDouble("preTaxTotal");
						}
						else
						{
							preTaxInContractCurrency = this.parent.getDouble("preTaxTotal") * currServ.getCurrencyExchangeRate(this.parent.getUserInfo(), this.parent.getString("currencycode"), purchViewRemote.getString("currencycode"), date, purchViewRemote.getString("orgid"));
						}
						if ((!purchViewRemote.isNull("maxrelvol")) && (preTaxInContractCurrency > purchViewRemote.getDouble("maxrelvol")))
						{
		 
							Double diffInCosts = new Double(preTaxInContractCurrency - purchViewRemote.getDouble("maxrelvol"));
							String[] params = { purchViewRemote.getString("maxrelvol"), MXFormat.doubleToString(diffInCosts.doubleValue(), MXServer.getMXServer().getMaximoDD().getMboSetInfo("PURCHVIEW").getMboValueInfo("totalcost").getScale()) };
							throw new MXApplicationException("po", "exceedsMaxRelVol", params);
						}
						if (!purchViewRemote.isNull("maxvol"))
						{
							if (purchViewRemote.getString("currencycode").equalsIgnoreCase(this.parent.getString("currencycode")))
							{
								String lineOrLoaded = ((PO)this.parent).useLineOrLoadedCost();
								double calTotalCost = this.parent.getDouble("pretaxtotal");
								if (lineOrLoaded.equalsIgnoreCase("LOADEDCOST"))
								{
									calTotalCost = this.parent.getDouble("totalcost");
								}
								//totalReleaseCost = purchViewRemote.getInvoiceVariance() + purchViewRemote.getAmountReceived() + purchViewRemote.getAmountOnOrder() - currentPOReleaseCost + calTotalCost;
								totalReleaseCost = this.parent.getDouble("preTaxTotal");
								if ((currentInternalStatus.equalsIgnoreCase("PNDREV")) && (this.parent.getInt("revisionnum") > 0))
								{
									MboRemote poRemote = ((PO)this.parent).getApprRevision();
									MboSetRemote poLineSetRemote = poRemote.getMboSet("POLINE");
									double amountOnOrder = 0.0D;
									for (int j = 0;; j++)
									{
										MboRemote poLineRemote = poLineSetRemote.getMbo(j);
										if (poLineRemote == null)
											break;
										if (!poLineRemote.getBoolean("receiptscomplete"))
										{
											if (lineOrLoaded.equalsIgnoreCase("LOADEDCOST"))
											{
												amountOnOrder = MXMath.add(amountOnOrder, MXMath.subtract(poLineRemote.getDouble("loadedcost"), poLineRemote.getDouble("receivedtotalcost")));
											}
											else
											{
												amountOnOrder = MXMath.add(amountOnOrder, MXMath.subtract(poLineRemote.getDouble("linecost"), poLineRemote.getDouble("receivedtotalcost")));
											}
										}
									}
									poRemote.clear();
									poLineSetRemote.close();
									totalReleaseCost = MXMath.subtract(totalReleaseCost, amountOnOrder);
								}
							}
							else
							{
								double exchangeRate = currServ.getCurrencyExchangeRate(this.parent.getUserInfo(), this.parent.getString("currencycode"), purchViewRemote.getString("currencycode"), date, purchViewRemote.getString("orgid"));
								String lineOrLoaded = ((PO)this.parent).useLineOrLoadedCost();
						 
								double calTotalCost = this.parent.getDouble("pretaxtotal");
								if (lineOrLoaded.equalsIgnoreCase("LOADEDCOST"))
								{
									calTotalCost = this.parent.getDouble("totalcost");
								}
						 
								//totalReleaseCost = purchViewRemote.getInvoiceVariance() + purchViewRemote.getAmountReceived() + purchViewRemote.getAmountOnOrder() - currentPOReleaseCost * exchangeRate + calTotalCost * exchangeRate;
								totalReleaseCost = this.parent.getDouble("preTaxTotal") * exchangeRate;
								if ((currentInternalStatus.equalsIgnoreCase("PNDREV")) && (this.parent.getInt("revisionnum") > 0))
								{
									MboRemote poRemote = ((PO)this.parent).getApprRevision();
									MboSetRemote poLineSetRemote = poRemote.getMboSet("POLINE");
									double amountOnOrder = 0.0D;
									for (int j = 0;; j++)
									{
										MboRemote poLineRemote = poLineSetRemote.getMbo(j);
										if (poLineRemote == null)
											break;
										if (!poLineRemote.getBoolean("receiptscomplete"))
										{
											if (lineOrLoaded.equalsIgnoreCase("LOADEDCOST"))
											{
												amountOnOrder = MXMath.add(amountOnOrder, MXMath.multiply(MXMath.subtract(poLineRemote.getDouble("loadedcost"), poLineRemote.getDouble("receivedtotalcost")), exchangeRate));
											}
											else
											{
												amountOnOrder = MXMath.add(amountOnOrder, MXMath.multiply(MXMath.subtract(poLineRemote.getDouble("linecost"), poLineRemote.getDouble("receivedtotalcost")), exchangeRate));
											}
										}
									}
									poRemote.clear();
									poLineSetRemote.close();
									totalReleaseCost = MXMath.subtract(totalReleaseCost, amountOnOrder);
								}
							}
							totalReleaseCost = RoundToScale.round(this.parent.getMboValue("pretaxtotal"), totalReleaseCost);
							if (totalReleaseCost > purchViewRemote.getDouble("maxvol"))
							{
								Double diffInCosts = new Double(totalReleaseCost - purchViewRemote.getDouble("maxvol"));
								if (purchViewRemote.getBoolean("canexceedvolume"))
								{
									String[] params = { purchViewRemote.getString("maxvol"), purchViewRemote.getString("currencycode"), purchViewRemote.getString("contractnum"), MXFormat.doubleToString(diffInCosts.doubleValue(), MXServer.getMXServer().getMaximoDD().getMboSetInfo("PURCHVIEW").getMboValueInfo("totalcost").getScale()), purchViewRemote.getString("currencycode") };
									UserInfo userInfo = this.parent.getUserInfo();
									if (userInfo.isInteractive())
									{
										int userInput = MXApplicationYesNoCancelException.getUserInput("exceedsMaxVolWarning", MXServer.getMXServer(), userInfo);
										switch (userInput)
										{
											case -1: 
												throw new MXApplicationYesNoCancelException("exceedsMaxVolWarning", "contract", "exceedsMaxVol", params);
										}
							 
									}
								}
								else
								{
									String[] params2 = { purchViewRemote.getString("maxvol"), purchViewRemote.getString("currencycode"), MXFormat.doubleToString(diffInCosts.doubleValue(), MXServer.getMXServer().getMaximoDD().getMboSetInfo("PURCHVIEW").getMboValueInfo("totalcost").getScale()), purchViewRemote.getString("currencycode") };
									throw new MXApplicationException("po", "exceededMaxVol", params2);
								}
							}
						}
					}
				}
				if (((PO)this.parent).checkLimitWhenApprove)
				{
					double approvalLimit = this.parent.getProfile().getTolerance("POLIMIT", this.parent.getString("orgid"));
					String poCurrency = this.parent.getString("currencycode");
					if (approvalLimit != Double.MAX_VALUE)
					{
						if (totalCostInBase > approvalLimit)
						{
							throw new MXApplicationException("po", "approveamountexceeded");
						}
					}
				}
				
				if ((currentInternalStatus.equalsIgnoreCase("PNDREV")) && (this.parent.getInt("revisionnum") > 0))
				{
					deleteReservations();
				}
				
				boolean prorateCostNotZero = false;
				double prorateCost = 0.0D;
				InvReserveSet invReserveSet = (InvReserveSet)this.parent.getMboSet("INVRESERVE");
				for (int i = 0;; i++)
				{
					POLine oneLine = (POLine)poLines.getMbo(i);
					if (oneLine == null) {
						break;
					}
		       
					String[] params1 = { oneLine.getString("polinenum") };
					if ((oneLine.getBoolean("issue")) || (oneLine.isNull("itemnum")))
					{
						if (((oneLine.getString("assetnum").equalsIgnoreCase("")) || (oneLine.isNull("assetnum"))) && ((oneLine.getString("wonum").equalsIgnoreCase("")) || (oneLine.isNull("wonum"))) && ((oneLine.getString("location").equalsIgnoreCase("")) || (oneLine.isNull("location"))) && ((oneLine.getString("gldebitacct").equalsIgnoreCase("")) || (oneLine.isNull("gldebitacct"))))
						{
							throw new MXApplicationException("po", "assetwolocglNull", params1);
						}
					}
		       
					if (!oneLine.getBoolean("issue"))
					{
						if (oneLine.getString("storeloc").equalsIgnoreCase("")) {
							throw new MXApplicationException("po", "StoreLocIsNull", params1);
						}
					}
					if (exchangeRate2 != 0.0D) {
						oneLine.setValue("linecost2", oneLine.getDouble("linecost") * exchangeRate2, 2L);
					}
		       
					if (!this.parent.getBoolean("ignorecntrev"))
					{
						if (!oneLine.getString("contractrefnum").equals(""))
						{
							SqlFormat sqlf = null;
							if (!oneLine.isNull("contractrefid"))
							{
								sqlf = new SqlFormat(this.parent, "contractid=:1");
								sqlf.setLong(1, oneLine.getLong("contractrefid"));
							}
							else
							{
								sqlf = new SqlFormat(this.parent, "contractnum=:1 and revisionnum=:2 and orgid=:3");
								sqlf.setObject(1, "CONTRACT", "contractnum", oneLine.getString("contractrefnum"));
								sqlf.setObject(2, "CONTRACT", "revisionnum", oneLine.getString("contractrefrev"));
								sqlf.setObject(3, "CONTRACT", "orgid", oneLine.getString("orgid"));
							}
							MboRemote contractRemote = this.parent.getMboSet("$releases", "CONTRACT", sqlf.format()).getMbo(0);
							if (contractRemote != null)
							{
								if (!((ContractRemote)contractRemote).getInternalStatus().equalsIgnoreCase("APPR"))
								{
									String[] params = { oneLine.getString("contractrefnum"), oneLine.getString("contractrefrev"), oneLine.getString("polinenum") };
									throw new MXApplicationException("po", "agreementnotapproved", params);
								}
							}
						}
					}
		       
					if (prorateCostNotZero) {
						oneLine.setValue("proratecost", 0.0D, 2L);
					}
					else {
						prorateCost = oneLine.getDouble("proratecost");
						if (prorateCost != 0.0D)
						{
							oneLine.setValue("proratecost", 0.0D, 2L);
							prorateCostNotZero = true;
						}
					}
					String[] params = { oneLine.getString("polinenum") };
		       
					if (!oneLine.getString("refwo").equalsIgnoreCase(""))
					{
						SqlFormat sqf = new SqlFormat(this.parent.getUserInfo(), "wonum=:1 and siteid=:2");
						sqf.setObject(1, "WORKORDER", "wonum", oneLine.getString("refwo"));
						sqf.setObject(2, "POLINE", "siteid", oneLine.getString("siteid"));
						MboRemote woRemote = oneLine.getMboSet("$getWorkorder", "WORKORDER", sqf.format()).getMbo(0);
						if (woRemote != null)
						{
							if (!oneLine.getBoolean("receiptscomplete"))
							{
								String woStatus = ((WORemote)woRemote).getInternalStatus();
								if ((woStatus.equals("CAN")) || (woStatus.equals("CLOSE")) || (woStatus.equals("WAPPR"))) {
									throw new MXApplicationException("po", "invalidWO", params);
								}
							}
						}
					}
		       
					String glCredit = oneLine.getString("glcreditacct");
					String glDebit = oneLine.getString("gldebitacct");
					String orgID = oneLine.getString("orgid");
		       
					FinancialServiceRemote financialThingy = (FinancialServiceRemote)((AppService)this.parent.getMboServer()).getMXServer().lookup("FINANCIAL");
		       
					if (!glCredit.equals(""))
					{
						String tempOrgID = null;
						if (this.parent.getBoolean("internal"))
						{
							SqlFormat sqlf = new SqlFormat(this.parent.getUserInfo(), "siteid = :1");
							sqlf.setObject(1, "SITE", "SITEID", this.parent.getString("storelocsiteid"));
							MboRemote siteRemote = this.parent.getMboSet("$sitegl", "SITE", sqlf.format()).getMbo(0);
							if (siteRemote != null)
							{
								tempOrgID = orgID;
								orgID = siteRemote.getString("orgid");
							}
						}
						if (!financialThingy.validateFullGLAccount(this.parent.getUserInfo(), glCredit, orgID))
						{
							throw new MXApplicationException("po", "glcreditnotfull", params);
						}
						if (tempOrgID != null) {
							orgID = tempOrgID;
						}
					}
					if (this.parent.getBoolean("internal"))
					{
						SqlFormat sqlf = new SqlFormat(this.parent.getUserInfo(), "siteid = :1");
						sqlf.setObject(1, "SITE", "SITEID", oneLine.getString("tositeid"));
						MboRemote siteRemote = this.parent.getMboSet("$siteg2", "SITE", sqlf.format()).getMbo(0);
						if (siteRemote != null)
							orgID = siteRemote.getString("orgid");
					}
					if (!glDebit.equals(""))
					{
						if (!financialThingy.validateFullGLAccount(this.parent.getUserInfo(), glDebit, orgID))
						{
							throw new MXApplicationException("po", "gldebitnotfull", params);
						}
					}
		       
		 
					MboSetRemote poCostSetRemote = oneLine.getMboSet("POCOST");
		       
					if (!oneLine.getString("siteid").equalsIgnoreCase(oneLine.getString("tositeid")))
					{
						if ((!oneLine.getString("toorgid").equals("")) && (!oneLine.getString("toorgid").equalsIgnoreCase(oneLine.getString("orgid")))) {
							orgID = oneLine.getString("toorgid");
						}
						else {
							SqlFormat sqlWhere = new SqlFormat(oneLine, "siteid=:1");
							sqlWhere.setObject(1, "SITE", "SITEID", oneLine.getString("tositeid"));
							MboRemote siteMbo = oneLine.getMboSet("$getOrg", "SITE", sqlWhere.format()).getMbo(0);
							if (siteMbo != null)
								orgID = siteMbo.getString("orgid");
						}
					}
					for (int x = 0;; x++)
					{
						MboRemote poCostRemote = poCostSetRemote.getMbo(x);
		         
						if (poCostRemote == null)
							break;
						if (!poCostRemote.toBeDeleted())
						{
							if (financialThingy.glRequiredForTrans(poCostRemote.getUserInfo(), orgID))
							{
								if ((poCostRemote.isNull("gldebitacct")) || (poCostRemote.isNull("glcreditacct"))) {
									throw new MXApplicationException("financial", "GLRequiredForTrans");
								}
							}
							if (!poCostRemote.getString("gldebitacct").equals(""))
							{
								if (!financialThingy.validateFullGLAccount(this.parent.getUserInfo(), poCostRemote.getString("gldebitacct"), orgID))
								{
									throw new MXApplicationException("po", "GLDebitMustBeFull", params);
								}
							}
						}
					}
					InvReserveRemote newInvRes;
					if (this.parent.getBoolean("internal"))
					{
						if (!oneLine.isServiceType())
						{ 
							IntegrationServiceRemote intserv = (IntegrationServiceRemote)((AppService)this.parent.getMboServer()).getMXServer().lookup("INTEGRATION");
							boolean useIntegration = intserv.useIntegrationRules(this.parent.getString("ownersysid"), oneLine.getString("ITEM.ownersysid"), "PORES", this.parent.getUserInfo());
							if (!useIntegration)
							{
								String location = this.parent.getString("storeloc");
								String glaccount = "";
		             
								boolean directreq = false;
		             
								SqlFormat sqlf = new SqlFormat(this.parent.getUserInfo(), "siteid=:1 and polineid=:2");
								sqlf.setObject(1, "POLINE", "siteid", oneLine.getString("tositeid"));
								sqlf.setLong(2, oneLine.getLong("polineid"));
								InvReserveSet invReserveLineIdSet = (InvReserveSet)this.parent.getMboSet("$invreserve" + oneLine.getLong("polineid"), "INVRESERVE", sqlf.format());
		             
								if (invReserveLineIdSet.isEmpty())
								{
									glaccount = oneLine.getString("gldebitacct");
									newInvRes = invReserveSet.addPOReservation(oneLine, location, this.parent.getString("storeLocSiteID"), glaccount, directreq);
								}
							}
						}
					}
		       
					if (!oneLine.isNull("itemnum"))
					{ 
						String itemNum = oneLine.getString("itemnum");
						String itemSetID = oneLine.getString("itemsetid");
						SqlFormat sqlf = new SqlFormat(this.parent.getUserInfo(), "itemnum = :1");
						sqlf.setObject(1, "ITEM", "itemnum", itemNum);
						MboSetRemote itemSet = this.parent.getMboSet("$itemtable", "item", sqlf.format());
						MboRemote item = itemSet.getMbo(0);
						if (item == null)
						{
							MRRemote mr = oneLine.getMRPassedIn();
							if (mr != null) {
								item = (MboRemote)mr.getItemReferenceHashtable().get(itemNum + "&" + itemSetID);
							}
						}
						String ownersysid2 = item.getString("ownersysid");
						IntegrationServiceRemote intserv = (IntegrationServiceRemote)((AppService)this.parent.getMboServer()).getMXServer().lookup("INTEGRATION");
						boolean useIntegration = intserv.useIntegrationRules(this.parent.getString("ownersysid"), ownersysid2, "POIVM", this.parent.getUserInfo());
						if (!useIntegration)
						{
							oneLine.updateInvVendor();
						}
					}
				}
				((PORemote)this.parent).prorateServices();
		     
				((PORemote)this.parent).createInvoicesForSchedule();
		     
				if ((currentInternalStatus.equalsIgnoreCase("PNDREV")) && (this.parent.getInt("revisionnum") > 0))
				{
					MboRemote poRemote = ((PO)this.parent).getApprRevision();
					if (poRemote != null)
					{
		 				checkPndRevLines(poRemote, poLines);
		         
		 				((PO)this.parent).updatePndRevPO();
		         
		 				((StatefulMbo)poRemote).changeStatus(this.parent.getTranslator().toExternalDefaultValue("POSTATUS", "REVISE", this.parent), MXServer.getMXServer().getDate(), "");
		         
		 				if (isPOFromPR())
		 				{
		 					updatePRPRLine();
		 				}
		 				if (isPOFromRFQ())
		 				{
		 					updateRFQRFQLine();
		 				}
		 				updatePndRevLines(poRemote, poLines);
					}	
				}
		  	} 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  // Modification Starts For CR-1 & 4.2.8
  public void changeStatus(String currentStatus, String desiredStatus, Date date, String memo)
  throws MXException, RemoteException
{
          //System.out.println("*** I am Inside Overide change Status method ***");
          if(date.getTime() < parent.getDate("statusdate").getTime())
          throw new MXApplicationException("po", "statusdate");
      String desiredMaxStatus = parent.getTranslator().toInternalString("POSTATUS", desiredStatus);
      if(desiredMaxStatus.equals(CANCEL))
      {
          //System.out.println("*** I am Inside Desired Status = CANCEL ***");
          cancel();
          parent.setValue("status", desiredStatus, 2L);
          parent.setValue("statusdate", date, 2L);
          return;
      }
      else
      {
          //System.out.println("*** I am Inside else block calling Super Change Status ***");
          super.changeStatus(currentStatus, desiredStatus, date, memo);
      }

}

  private void cancel()throws MXException, RemoteException
{
  //System.out.println("*** I am Inside Overide cancel method ***");
//Modification For 4.2.8.
  if(this.parent.getDouble("RECEIVEDTOTALCOST") != 0)
  {
  ((PO)this.parent).hasReceipts();
  }
  deleteReservations();

  if (((PO)this.parent).getCancelFlag())
  {
    if (!MXServer.getBulletinBoard().isPosted("PO.CREATECHGORDER", this.parent.getUserInfo()))
    {
      resetPOVariablesOnPRLines();
      resetPOVariablesOnRFQLines();
    }

  }

  POLineSetRemote poLineSet = (POLineSetRemote)this.parent.getMboSet("POLINE");
  for (int i = 0; ; i++)
  {
    POLine poLine = (POLine)poLineSet.getMbo(i);
    if (poLine == null)
    {
      break;
    }

    poLine.cancelScheduleInvoice();
  }

  this.parent.setValue("historyflag", true, 2L);
  //System.out.println("*** I am Exiting Overide cancel method ***");
}

private void resetPOVariablesOnPRLines()
  throws MXException, RemoteException
{
        //System.out.println("*** I am Inside Overide resetPOVariablesOnPRLines method ***");
  String ponum = this.parent.getString("ponum");

  String siteId = this.parent.getString("siteid");

  SqlFormat sqf = new SqlFormat(this.parent.getUserInfo(), "prnum in (select prnum from prline where ponum = :1) and siteid =:2");

  sqf.setObject(1, "PRLINE", "ponum", ponum);

  sqf.setObject(2, "PRLINE", "siteid", siteId);
  MboSetRemote prSetRemote = this.parent.getMboSet("$getponum", "pr", sqf.format());
  prSetRemote.setOrderBy("prnum");

  for (int i = 0; ; i++)
  {
    PRRemote pr = (PRRemote)prSetRemote.getMbo(i);
    if (pr == null) {
      break;
    }
    MboSetRemote prLineSet = pr.getMboSet("PRLINE");

    for (int j = 0; ; j++)
    {
      MboRemote prLineRemote = prLineSet.getMbo(j);
      if (prLineRemote == null) {
        break;
      }
      if (prLineRemote.getString("ponum").equals(ponum)) {
        ((PRLineRemote)prLineRemote).setNullValuesToPOVariables();
      }
    }
    StatefulMboRemote sMboRemote = pr;
    if (pr.getInternalStatus().equals("COMP"))
    {
      String approveString = ((PR)pr).getTranslator().toExternalDefaultValue("PRSTATUS", "APPR", pr);
      String memo = Resolver.getResolver().getMessage("po", "AllowCloseToAppr").getMessage();
      MXServer.getBulletinBoard().post("pr.ALLOWCLOSETOAPPR");
      try
      {
        sMboRemote.changeStatus(approveString, MXServer.getMXServer().getDate(), memo, 2L);
      }
      finally
      {
        MXServer.getBulletinBoard().remove("pr.ALLOWCLOSETOAPPR");
      }
    }
  }
//System.out.println("*** I am Exiting Overide resetPOVariablesOnPRLines method ***");

}

private void resetPOVariablesOnRFQLines()
  throws MXException, RemoteException
{
        //System.out.println("*** I am Inside Overide resetPOVariablesOnRFQLines method ***");

  String ponum = this.parent.getString("ponum");

  SqlFormat sqf = new SqlFormat(this.parent.getUserInfo(), "ponum = :1");
  sqf.setObject(1, "RFQLINE", "ponum", ponum);
  MboSetRemote mboRFQLineSet = this.parent.getMboSet("$rfqline", "rfqline", sqf.format());
  mboRFQLineSet.setOrderBy("rfqnum");
  RFQLineSetRemote rfqLineSet = (RFQLineSetRemote)mboRFQLineSet;
  int recordCount = mboRFQLineSet.count();

  StringBuffer rfqNums = new StringBuffer("(");
  if (rfqLineSet.getMbo(0) == null)
    return;
  String prevRFQNum = "";
  for (int i = 0; ; i++)
  {
    MboRemote rfqLineRemote = rfqLineSet.getMbo(i);
    if (rfqLineRemote == null) {
      break;
    }
    String thisRFQNum = rfqLineRemote.getString("rfqnum");

    ((RFQLineRemote)rfqLineRemote).setNullValuesToPOVariables();

    if (!prevRFQNum.equals(thisRFQNum))
    {
      rfqNums.append("'");
      rfqNums.append(thisRFQNum);
      rfqNums.append("'");
      if (i != recordCount - 1)
        rfqNums.append(",");
    }
    prevRFQNum = thisRFQNum;
  }

  int length = rfqNums.length();
  if (length != 0)
  {
    if (rfqNums.charAt(length - 1) == ',') {
      rfqNums.deleteCharAt(length - 1);
    }
  }

  rfqNums.append(")");
  String inClause = rfqNums.toString();

  SqlFormat sqlf = new SqlFormat(this.parent.getUserInfo(), "rfqnum in " + inClause);
  MboSetRemote mboRFQSetRemote = this.parent.getMboSet("$rfq", "rfq", sqlf.format());
  for (int j = 0; ; j++)
  {
    RFQRemote rfq = (RFQRemote)mboRFQSetRemote.getMbo(j);
    if (rfq == null)
    {
      break;
    }
    StatefulMboRemote sMboRemote = rfq;

    if (rfq.getInternalStatus().equals("CLOSE"))
    {
// Modification For CR-1 Set RFQ to FINISHED on PO Cancel.
      String sentString = "FINISHED";
      String memo = Resolver.getResolver().getMessage("rfq", "AllowCloseToSent").getMessage();
      MXServer.getBulletinBoard().post("rfq.ALLOWCLOSETOSENT");
      try
      {
	    //start of WMJ change set printdate to old value
	    Date prtDate = sMboRemote.getDate("printdate");
	    //end of WMJ change set printdate to old value
	      
        sMboRemote.changeStatus(sentString, MXServer.getMXServer().getDate(), memo);
        
        //start of WMJ change set printdate to old value
	    sMboRemote.setValue("printdate", prtDate, 11L);
	    //end of WMJ change set printdate to old value
        
      }
      finally
      {
        MXServer.getBulletinBoard().remove("rfq.ALLOWCLOSETOSENT");
      }
    }
  }
        //System.out.println("*** I am Exiting Overide resetPOVariablesOnRFQLines method ***");
}
private void deleteReservations()
throws MXException, RemoteException
{
        //System.out.println("*** I am Inside Overide deleteReservations method ***");
if (this.parent.getBoolean("internal"))
{
  String ponum = this.parent.getString("ponum");
  InvReserveSet invReserveSet = (InvReserveSet)this.parent.getMboSet("$invreserve", "INVRESERVE", "");
  invReserveSet.deletePOReservations(ponum);
}
//System.out.println("*** I am Exiting Overide deleteReservations method ***");

}
//Modification Ends For CR-1 & 4.2.8
}

