/*
 * Modification history
 * xx-xx-2006	BTE	Creation
 * xx-xx-2007	AGD	SR-062
 * 25-07-2007	AGD	SR-103
 * 23-08-2007	AGD	SR-112
 */
package com.psa.app.common;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Properties;
//import hello.iconn.client.*;	// For UMS
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.Resolver;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class MxEmail
{
	// Variables
	private String				toMail	= null;
	private String				fromMail	= null;
	private MXServer			mxserver;
	private static String	UMSSMTP;
	private static boolean	DELTEMPFILE;
//	private static final String		UMSSENDER			= "EMS";
	private static final String		UMSCFGFILE			= "/opt/psa/rel/config/ums/cfg/ums.cfg";
	private static final String		UMSDEFAULTFOLDER	= "/opt/psa/data/rw/ums/temp/";
	private static final String		UMSDEFAULTFILE		= "EMS";
	private static final String		UMSDEFAULTEXT		= ".html";
	private static final MXLogger	mxLogger				= MXLoggerFactory.getLogger("maximo.mail");


	/*
	 * Author: BTE
	 * Date 23 FEB 2006
	 * Comment: Constructor
	 */
	public MxEmail()
	{
		try {
			mxserver = MXServer.getMXServer();
		}
		catch (RemoteException e) {
			mxLogger.error(e.getMessage(), e);
		}

		Properties properties = mxserver.getConfig();
		setFromMail(properties.getProperty("mxe.adminEmail", null));
	}


	/*
	 * Author: BTE
	 * Date 23 FEB 2006
	 * Comment: Constructor
	 */
	public MxEmail(String Admin)
	{
		try {
			mxserver = MXServer.getMXServer();
		}
		catch (RemoteException e) {
			mxLogger.error(e.getMessage(), e);
		}

		Properties properties = mxserver.getConfig();

		setAdmin(Admin);
		setFromMail(properties.getProperty("mxe.adminEmail", null));
	}


	/*
	 * Author: BTE
	 * Date 23 FEB 2006
	 * Comment: Set administrator
	 */
	public void setAdmin(String admin)
	{
		setToMail(admin);
	}


	/*
	 * Same as setAdmin but more understandable
	 * Author : AGD
	 */
	public void setToMail(String to)
	{
		toMail = to;
	}


	/*
	 * Author: BTE
	 * Date 23 FRB 2006
	 * Comment: Set from mail
	 */
	public void setFromMail(String from)
	{
		fromMail = from;
	}


	/* Author: BTE
	 * Date: 21 FEB 2006
	 * Comment: Send email
	 */
	public void send(String subject, String message)
	{
		send(subject, message, null, null);
/*		if ((administrator != null) && (fromMail != null))
		{
			try {
				MXServer.sendEMail(administrator, fromMail, subject, message);
			}
			catch (MessagingException e) {
				mxLogger.error(e.getMessage(), e);
			}
		}*/
	}


	/*
	 * Send an email with attachment
	 * Author : AGD
	 */
	public void send(String subject, String message, String attachment, String filename)
	{
		if ((toMail != null) && (fromMail != null))
		{
			try {
/*				try {
					mxLogger.debug("SMTP="+MXServer.getMXServer().getSystemProperties().getProperty("mail.smtp.host"));
				}
				catch (Exception e) { } */
				MXServer.sendEMail(toMail, fromMail, subject, message, attachment, filename);
			}
			catch (javax.mail.MessagingException e) {
				mxLogger.error(e.fillInStackTrace());
			}
		}
		else
			mxLogger.warn("MxEmail.send - Email not sent to: " + toMail + ", from: " + fromMail);
	}


	/*
	 * Send data via UMS using email submission
	 * Author : AGD
	 */
// Begin modification SR-103
//	public void sendViaUMS(String subject, String message, String contactno, int type, String filename)

	/*
	 * 29-10-2020 BCT: Removal of UMS starts here:
	 * 
	 */
	       
/*
	public void sendViaUMS(String subject, String message, String contactno, int type, String filename, String userid)
// End modification SR-103
			throws MXApplicationException
	{
		// Validate a few thing on the file passed in parameter
		if (filename == null)
			filename = UMSDEFAULTFOLDER + UMSDEFAULTFILE + UMSDEFAULTEXT;
		else
		{
			if (filename.indexOf("/") == -1)
				filename = UMSDEFAULTFOLDER + filename;
			if (filename.indexOf(".") == -1)
				filename = filename + UMSDEFAULTEXT;
		}

		// Read the UMS configuration file
		try
		{
			readUMSConfigFile();
		}
		catch (IOException ioe)
		{
			mxLogger.error("MxEmail.sendViaUMS - Problem reading the UMS configuration file. Exiting");
			String[] param = { UMSCFGFILE };
			throw new MXApplicationException("iface", "ioexception", param, ioe);
		}

		try
		{
			// Create the temp file attachment that UMS will send
			File file = new File(filename);
			FileWriter filewriter = new FileWriter(file);
			filewriter.write(message);
			filewriter.close();
			mxLogger.debug("MxEmail.sendViaUMS - File " + filename + " created");

			// Create the UMS message
			Message msg = new Message(subject, file);

			// Create the UMS recipient
			Contact contact = new Contact(type, contactno);
//	Begin modification SR-103
//			Recipient recipient = new Recipient(null, null, contact);
			Recipient recipient = new Recipient(userid, null, contact);
//	End modification SR-103

			// Create the UMS request
			MessageRequest msgrequest = new MessageRequest(
//	02-04-07 Requested by CTSD to avoid timeouts
//			UMSSENDER, subject, msg, MessageRequest.NORMAL_PRIORITY, 0, null, recipient);
//	19-04-07 Requested by CTSD to avoid blank cover page
//			UMSSENDER, subject, msg, MessageRequest.NORMAL_PRIORITY, 60, null, recipient);
			null, subject, msg, MessageRequest.NORMAL_PRIORITY, 60, null, recipient);

			// Send the message to UMS
			iConnProxy email = new iConnProxy(UMSSMTP, fromMail, toMail);
			if (email.sendRequest(msgrequest) == iConnProxy.ERROR)
			{
				mxLogger.error("MxEmail.sendViaUMS - Could not send message '" + subject + "' to UMS");
				throw new MXApplicationException("system", "unknownerror", email.getLastException());
			}
			// Delete the temp attachment file except in debug mode
			if (DELTEMPFILE)
				file.delete();

//	Begin modification SR-085
			// Create the control file containing the sending options (recipient, method, subject)
			File controlfile = new File(filename.substring(0, filename.indexOf(".")) + ".ctl");
			FileWriter controlfilewriter = new FileWriter(controlfile);
			controlfilewriter.write(subject + "|" + type + "|" + contactno + "\n");
			controlfilewriter.close();
			mxLogger.debug("MxEmail.sendViaUMS - Control file " + filename + " created");
// End modification SR-085
		}
		catch (IOException e)
		{
			mxLogger.error("MxEmail.sendViaUMS - I/O Exception");
			String[] param = { filename };
			throw new MXApplicationException("iface", "ioexception", param, e.fillInStackTrace());
		}

		mxLogger.debug("MxEmail.sendViaUMS - Message '" + subject + "' sent to '" + contactno + "' via UMS");
	}
*/

	/*
	 * Read the UMS configuration file (path hard-coded, no choice)
	 */
/*	private void readUMSConfigFile()
			throws IOException
	{
		BufferedReader reader = new BufferedReader(new FileReader(UMSCFGFILE));
		for(String line; (line = reader.readLine()) != null; )
		{
			StringTokenizer tok = new StringTokenizer(line.trim(), "=");
			String parameter	= tok.nextToken().trim();
			String value		= tok.nextToken().trim();
			if (parameter.equalsIgnoreCase("UMSSMTP"))
				UMSSMTP = value;
			else if (parameter.equalsIgnoreCase("DELTEMPFILE"))
				DELTEMPFILE = value.toLowerCase() == "true" ? true : false;
			// Ignore any other parameter
		}
	}
*/
	
	/*
	 * 29-10-2020 BCT: Removal of UMS ends here
	 * 
	 */

// Begin modification SR-112
	public void emailForActionError(String action, Object[] param)
	{
		setToMail(fromMail);
		String message = Resolver.getResolver().getMessage("action", "failedcustomaction").getMessage(param);
		send("Error while executing custom action " + action, message);
	}
// End modification SR-112

}
