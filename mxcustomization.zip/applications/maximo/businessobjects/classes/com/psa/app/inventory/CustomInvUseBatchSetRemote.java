package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public interface CustomInvUseBatchSetRemote extends MboSetRemote 
{
	public abstract void copyInvBatchLineSet(MboSetRemote paramMboSetRemote)
		    throws MXException, RemoteException;
	
	public abstract void copyInvBatchLineTransferSet(MboSetRemote paramMboSetRemote)
		    throws MXException, RemoteException;	
}
