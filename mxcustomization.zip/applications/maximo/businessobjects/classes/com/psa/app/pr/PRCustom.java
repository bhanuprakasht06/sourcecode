/*
 * Modification history
 * 03-10-2007	AGD	SR-116	Check vendor validity upon approval
 * 31-10-2007	AGD	eRFQ		Allow editing of Ship To Attn in APPR state
 */
package com.psa.app.pr;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.Iterator;

import com.psa.app.common.VendorCheckCustom;

import psdi.app.pr.PR;
import psdi.app.pr.PRRemote;
import psdi.app.pr.virtual.PRChangeStatusSet;
import psdi.mbo.MboConstants;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValueInfo;
import psdi.server.MXServer;
import psdi.util.MXException;

public class PRCustom extends PR
implements PRRemote
{

public PRCustom(MboSet prset)
	throws MXException, RemoteException
{
super(prset);
}


public void changeStatus(String status, Date statusdate, String memo, long modifier)
	throws MXException, RemoteException
{
if (getTranslator().toInternalString(getStatusListName(), status, this).equals("APPR"))
	VendorCheckCustom.checkValidity(this, "PR_VENDOR");
super.changeStatus(status, statusdate, memo, modifier);
}


//Begin modification eRFQ
public void setRelatedMboEditibility(String relationship, MboSetRemote mbosetremote)
	throws MXException, RemoteException
{
if (toBeAdded())
	return;
MboSetRemote mbosetremote1 = mbosetremote;
if (getBoolean("HistoryFlag") && !MXServer.getBulletinBoard().isPosted("PO.CREATECHGORDER", getUserInfo()))
{
	setFlag(7L, true);
	if (!(mbosetremote1 instanceof PRChangeStatusSet))
		mbosetremote1.setFlag(7L, true);
}
if (!getInternalStatus().equalsIgnoreCase("WAPPR"))
//Begin change of std MX method
	if (getInternalStatus().equalsIgnoreCase("APPR"))
	{
		// Get list of fields and set them all to read-only except shiptoattn
		Iterator attributelist = getMboSetInfo().getAttributes();
		while (attributelist.hasNext())
		{
			String attributename = ((MboValueInfo) attributelist.next()).getAttributeName();
			if (!attributename.equalsIgnoreCase("shiptoattn"))
				setFieldFlag(attributename, MboConstants.READONLY, true);
		}
	}
	else
//End change of std MX method
		setFlag(7L, true);
if (relationship.equals("PRSTATUS"))
	mbosetremote1.setFlag(7L, true);
if (relationship.equals("PRTERM") && (getInternalStatus().equalsIgnoreCase("APPR") || getInternalStatus().equalsIgnoreCase("INPRG")))
	mbosetremote1.setFlag(7L, true);
}
//End modification eRFQ

}

