package com.psa.app.inventory;

import psdi.app.inventory.InvUseLineSetRemote;

public interface CustomInvUseLineSetRemote extends InvUseLineSetRemote 
{
		
}
