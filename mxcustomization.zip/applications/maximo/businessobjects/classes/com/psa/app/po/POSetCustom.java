/*
 * Modification history
 * 17-04-2007	AGD	SR-068	Set vendor date at PO and PO line levels read-only when PO is approved
 */
package com.psa.app.po;

import java.rmi.RemoteException;


import psdi.app.po.POSet;
import psdi.app.po.POSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;

public class POSetCustom extends POSet
		implements POSetRemote
{

	public POSetCustom(MboServerInterface mboserverinterface)
			throws MXException, RemoteException
	{
		super(mboserverinterface);
	}


	protected Mbo getMboInstance(MboSet mboset)
			throws MXException, RemoteException
	{
		return new POCustom(mboset);
	}

}
