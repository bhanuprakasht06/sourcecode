package com.psa.app.inventory;

import psdi.app.inventory.InvUseSetRemote;

public interface CustomInvUseSetRemote extends InvUseSetRemote 
{
		
}
