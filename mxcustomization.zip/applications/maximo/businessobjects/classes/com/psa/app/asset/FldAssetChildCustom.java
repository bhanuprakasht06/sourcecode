/*
 * Created by BCT 
 * 
 * if newly entered Asset code is available in OFABACKUP,
 *  this class will populate the related data into respective attribute 
 * 
 * 
 */

package com.psa.app.asset;

import java.rmi.RemoteException;

import psdi.app.asset.FldAssetChild;
import psdi.mbo.Mbo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.util.MXException;
import psdi.mbo.MboConstants;


public class FldAssetChildCustom extends FldAssetChild {

	public FldAssetChildCustom(MboValue mbv) throws MXException {
		super(mbv);
		
	}
// populating the data from OFABACKUP to OFASSETNUM and GLAccount	
	public void action() throws MXException, RemoteException {
		
		Mbo getCurrentMbo=getMboValue().getMbo();
	
			String ofAssetNum=getCurrentMbo.getString("ASSETNUM");
			
			SqlFormat ofaSql=new SqlFormat("LOCATION=:1");
			ofaSql.setObject(1, "OFABACKUP", "LOCATION", ofAssetNum);
			MboSetRemote ofa_backMboSet=getCurrentMbo.getMboSet("$OFABACKUP","OFABACKUP",ofaSql.format());
			if(!ofa_backMboSet.isEmpty() && ofa_backMboSet!=null)
			{
				getCurrentMbo.setValue("OAASSETNUM",ofa_backMboSet.getMbo(0).getString("OAASSETNUM"));
				getCurrentMbo.setValue("INSTALLDATE",ofa_backMboSet.getMbo(0).getString("INSTALLDATE"));
				getCurrentMbo.setValue("DESCRIPTION",ofa_backMboSet.getMbo(0).getString("DESCRIPTION"));
				getCurrentMbo.setValue("GLACCOUNT",ofa_backMboSet.getMbo(0).getString("GLACCOUNT"),MboConstants.NOVALIDATION+MboConstants.NOACCESSCHECK);
				
			}
			
		
		super.action();
	}
	

}
