package com.psa.app.location;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;
import java.sql.ResultSet;


import psdi.common.action.ActionCustomClass;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import com.psa.custom.ois.MxLog;
import psdi.app.location.*;

public class LocationsSiteUpdateCustom
implements ActionCustomClass
{
public LocationsSiteUpdateCustom() {
}

public void applyCustomAction(MboRemote mboremote, Object aobj[])
throws MXException, RemoteException
{

System.out.println("Siteshift Custom Action Start");	
	
//Initialize the variables
logFilePath = null;
mxserver = MXServer.getMXServer();
mxLog = new MxLog();
    
//Set date format and get date to put into log file name
DateFormat fileDateFormat = new SimpleDateFormat("yyyyMMddHHmm");	// Ex: 201012071136
String runtime = fileDateFormat.format(mxserver.getDate());

logFilePath = "/opt/psa/data/maximo/log/siteshift/siteshift_yyyymmddhhmm.log";
logFilePath = logFilePath.replaceAll("yyyymmddhhmm", runtime);

//To create the log file
mxLog.setEnabled(true);
mxLog.setLogFilePath(logFilePath);
mxLog.setLogTag("SiteShift_Update");
try {
        mxLog.createLogFile();
}
catch (Exception e) {
        logger.error("Site Shift update" + " " + e.getMessage(), e);
}

//To start logging
mxLog.writeLog("Starting log for Siteshift Update");
mxLog.writeLog("List of affected locations:");
mxLog.writeLog("In the order: Location, Wrong Site, Correct Site");


DBShortcut dbshortcut;
dbshortcut = new DBShortcut();

//To get the list of affected locations and put into the log file
try{
dbshortcut.connect(mboremote.getUserInfo().getConnectionKey());
SqlFormat afflocsqlformat = new SqlFormat(mboremote.getUserInfo(), "SELECT distinct location, siteid, backupsiteid from locations where siteid<>backupsiteid");
ResultSet rs = dbshortcut.executeQuery(afflocsqlformat.format());
while (rs.next())
{
    mxLog.writeLog(rs.getString("location")+","+rs.getString("siteid")+","+rs.getString("backupsiteid"));    
}
rs.close();
}
catch (SQLException sqle)
                {
                        sqle.printStackTrace();
                        String[] param = { ""+sqle.getErrorCode() };
                        throw new MXApplicationException("system", "sql", param);
                }
                finally
                {
                 	dbshortcut.close();
                }
                



//To run the update statement to shift back all the sites
System.out.println("Running Update statement now");
mxLog.writeLog("Running update statement now");
SqlFormat locsqlformat = new SqlFormat(mboremote.getUserInfo(), "UPDATE LOCATIONS SET SITEID=BACKUPSITEID WHERE SITEID<>BACKUPSITEID");   


        //dbshortcut = new DBShortcut();
        try
        {
            dbshortcut.connect(mboremote.getUserInfo().getConnectionKey());
            dbshortcut.execute(1, locsqlformat);
            dbshortcut.commit();
            System.out.println("Commit Done");
        }
        catch(SQLException sqlexception)
        {
            System.out.println("sqlexception");
            sqlexception.printStackTrace();
            String as[] = {
                sqlexception.getMessage()
            };
            throw new MXApplicationException("locations", "UpdateSiteShiftError", as);
        }
        catch(RemoteException remoteexception)
        {
            System.out.println("remoteexception");
            remoteexception.printStackTrace();
            String as[] = {
                remoteexception.getMessage()
            };
            throw new MXApplicationException("locations", "UpdateSiteShiftError", as);
        }
        catch(MXException mxexception)
        {
            System.out.println("mxexception");
            mxexception.printStackTrace();
            String as[] = {
                mxexception.getMessage()
            };
            throw new MXApplicationException("locations", "UpdateSiteShiftError", as);
        }
        catch(Exception exception)
        {
            System.out.println("exception");
            exception.printStackTrace();
            String as[] = {
                exception.getMessage()
            };
            throw new MXApplicationException("locations", "UpdateSiteShiftError", as);
        }
        finally
        {
                dbshortcut.close();
        }

        mxLog.writeLog("Update statement done");

        //Closing the log after the update is done
        if (mxLog.isEnabled())
        {
                try
                {
                        mxLog.writeLog("Closing log");
                        mxLog.closeLogFile();
                }
                catch (Exception e)
                {
                        logger.error("Site Shift update" + " " + e.getMessage(), e);
                }
        }

        
        }

// Define variables
private MXLogger	logger;
private MxLog	mxLog;
private String	logFilePath;
private MXServer	mxserver;
       
}
