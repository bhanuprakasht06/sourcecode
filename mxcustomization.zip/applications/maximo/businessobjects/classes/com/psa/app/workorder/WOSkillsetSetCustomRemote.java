package com.psa.app.workorder;

import psdi.mbo.MboSetRemote;

public interface WOSkillsetSetCustomRemote extends MboSetRemote 
{
}
