/*
 * Modification history
 * 07-06-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class FldItemnumCustom extends MboValueAdapter
{

    public FldItemnumCustom(MboValue mbovalue)
        throws MXException, RemoteException
    {
        super(mbovalue);
    }

    public void action()
    	throws MXException, RemoteException
    {
    	MboRemote mboRemote = getMboValue().getMbo();
    	MboSetRemote ItemSetRemote = mboRemote.getMboSet("ITEM");
    	MboRemote ItemRemote = ItemSetRemote.getMbo(0);
    	if (ItemRemote != null)
    		throw new MXApplicationException("item", "itemExists");   	
    }
}