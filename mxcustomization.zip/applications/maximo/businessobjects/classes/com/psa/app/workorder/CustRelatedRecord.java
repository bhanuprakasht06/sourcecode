/*
 * Modification history
 
 * 29-07-2013--4.1.1-  Enhance Work Order Tracking Application to enable users to create follow up work orders across multiple sites.
 *   
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.ticket.RelatedRecord;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public class CustRelatedRecord extends RelatedRecord
    
{

    public CustRelatedRecord(MboSet ms)
        throws MXException, RemoteException
    {
        super(ms);
    }


    public void appValidate()
        throws MXException, RemoteException
    {
    	System.out.println("###Entering  Class CustRelatedRecord Method appvalidate()###");
        MboSetRemote relatedset = getMboSet("RELATEDRECORD");
        Mbo otherRelated;
        if(!getOwner().isBasedOn("RELATEDRECORD") && toBeAdded())
            if(relatedset.isEmpty())
            {

            	otherRelated = (Mbo)relatedset.add();

            } else
            {
                String site = getString("siteid");
                System.out.println("###IN Class CustRelatedRecord Method appvalidate Break Point 1 site here is ###"+site);
                if(site == null)
                    site = "";
                String relsite = getString("relatedrecsiteid");
                System.out.println("###IN Class CustRelatedRecord Method appvalidate Break Point 2 related Site here is###"+relsite);
                if(relsite == null)
                    relsite = "";
                int index = 0;
                boolean exist = false;
                for(MboRemote relRecordMbo = relatedset.getMbo(index); relRecordMbo != null; relRecordMbo = relatedset.getMbo(index))
                {
                    String othersite = relRecordMbo.getString("siteid");
                    String otherrelsite = relRecordMbo.getString("relatedrecsiteid");
                    if(othersite == null)
                        othersite = "";
                    if(otherrelsite == null)
                        otherrelsite = "";
                    if(site.equals(otherrelsite) && relsite.equals(othersite))
                    {
                    	System.out.println("###IN Class CustRelatedRecord Method appvalidate Setting Boolean Flag Exists value###");
                        exist = true;
                    }
                    index++;
                }

                
                if(!exist)
                {
                	System.out.println("###IN Class CustRelatedRecord Method appvalidate Break Point 3###");
                }
            }
        
    }


    protected void copyRelatedRecSiteOrg(MboRemote relatedRecordMbo)
        throws MXException, RemoteException
    {
        if(relatedRecordMbo != null)
        {
        	System.out.println("###IN Class CustRelatedRecord Method copyRelatedRecSiteOrg ()###");
            //setValue("relatedrecsiteid", relatedRecordMbo.getString("siteid"), 11L);
            //setValue("relatedrecorgid", relatedRecordMbo.getString("orgid"), 11L);
        } else
        {
            setValueNull("relatedrecsiteid", 11L);
            setValueNull("relatedrecorgid", 11L);
        }
    }


}

