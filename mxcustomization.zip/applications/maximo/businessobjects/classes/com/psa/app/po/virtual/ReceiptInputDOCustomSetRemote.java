package com.psa.app.po.virtual;

import psdi.mbo.NonPersistentMboSetRemote;

public interface ReceiptInputDOCustomSetRemote extends NonPersistentMboSetRemote
{

}
