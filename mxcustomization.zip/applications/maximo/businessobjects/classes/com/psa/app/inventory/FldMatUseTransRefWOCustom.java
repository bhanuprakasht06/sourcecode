/*
 * Modification history
 * 28-11-06	HCHA	Creation
 * 27-03-07	AGD	DR-006	GL account not set correctly for capital work WO when WO site <> store site
 * 10-04-07	AGD	SR-087	Get the WO GL A/c rather than the work type GL A/c for capital work (cater for capital work defined WO per WO)
 */
/**
 * @author	HCHA
 * Date		Nov 28, 2006
 * Comment	 
 */
package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.FldMatUseTransRefWO;
import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOSetRemote;
import psdi.app.workorder.WorkTypeRemote;
import psdi.app.workorder.WorkTypeSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;

/**
 * @author		HCHA
 * @class		FldMatUseTransRefWOCustom
 * @date		Nov 28, 2006
 * @function	
 */
public class FldMatUseTransRefWOCustom extends FldMatUseTransRefWO {

	/**
	 * @param arg0
	 * @throws MXException
	 * @throws RemoteException
	 */
	public FldMatUseTransRefWOCustom(MboValue arg0) throws MXException,
			RemoteException {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public void action()
	    throws MXException, RemoteException
	{
		    
		super.action();
		
	   	Mbo mbo = getMboValue().getMbo();
	   	
	    //Check for if Work Order is of Capital Work Type 
	   	boolean isCapWorkType = false;
	   	if(!mbo.isNull("wonum")){
	       	
	       	WOSetRemote woSet =(WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", mbo.getUserInfo());
	        SqlFormat sqlformat = new SqlFormat(mbo.getUserInfo(), "wonum = :1 and siteid = :2");
	        sqlformat.setObject(1, "WORKORDER", "WONUM", mbo.getString("wonum"));
//	Begin modification DR-006
//	        sqlformat.setObject(2, "WORKORDER", "SITEID", mbo.getString("siteid"));
           sqlformat.setObject(2, "WORKORDER", "SITEID", mbo.getString("tositeid"));
// End modification DR-006
	        woSet.setWhere(sqlformat.format());
	           
	        if(!woSet.isEmpty())
	        {
	        	WORemote wo = (WORemote) woSet.getMbo(0);
	   	    	String woWorkType = wo.getString("WORKTYPE");
	   	    	if(woWorkType != null){
	   	    		
	   	    		//Get Worktype mbo
	   	    		WorkTypeSetRemote worktypeSet =(WorkTypeSetRemote) MXServer.getMXServer().getMboSet("WORKTYPE", mbo.getUserInfo());
	   	    		
	   	            SqlFormat sqlformatWOType = new SqlFormat(mbo.getUserInfo(), "worktype = :1 and orgid = :2");
	   	            sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
	   	            sqlformatWOType.setObject(2, "WORKTYPE", "ORGID", mbo.getString("orgid"));
	   	            worktypeSet.setWhere(sqlformatWOType.format());
	   	            
	   	            if(!worktypeSet.isEmpty())
	   	            {
	   	            	WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
	   	            	isCapWorkType = worktype.getBoolean("capitalwork");
	   	            	if(isCapWorkType){
	   	            		//Capital Type Work Order
//	Begin modification SR-087
//	   	            		String wotypeGlAccount = worktype.getString("glaccount");
//	   	            		if(wotypeGlAccount != null){
		   	            		String wotypeGlAccount = wo.getString("glaccount");
	   	            			//Set WO GL Account into LabTrans Gl Debit Account
	   	            			mbo.setValue("gldebitacct", wotypeGlAccount, 2L);
	   	            			//return;
//	   	            		}	
//	End modification SR-087
	   	            	}
	   	            }
	   	    	}
	        }
	   	}
	}
}
