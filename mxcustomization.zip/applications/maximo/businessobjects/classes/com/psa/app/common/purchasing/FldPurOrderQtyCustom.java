package com.psa.app.common.purchasing;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboValue;
import psdi.app.common.purchasing.FldPurOrderQty;
import psdi.util.MXException;

/**
 * @author		LS
 * @class		FldPurOrderQtyCustom
 * @date		Mar 19, 2007
 * @function	Update Total Quotation Amount and Total Awarded Amount of RFQ Vendor
 */

public class FldPurOrderQtyCustom extends FldPurOrderQty 
{
	public FldPurOrderQtyCustom(MboValue arg0) 
		throws MXException,	RemoteException 
	{
		super(arg0);
	}

	public void action() throws MXException, RemoteException
    {
        Mbo mbo = getMboValue().getMbo();
        //Get RFQVendor Mbo
        MboRemote rfqvendorremote = mbo.getOwner();
//        System.out.println("[FldPurOrderQtyCustom]quotationlineremote: " + rfqvendorremote);
        if(rfqvendorremote == null)
            return;
        
        double totalquo = 0.0D;
        double prevqty = 0.0D;
        double curqty = 0.0D;
		double totalaward = 0.0D;
		
        //Get Total Quotation Amount
		totalquo = rfqvendorremote.getDouble("totalquotationamt");
//        System.out.println("[FldPurOrderQtyCustom]orig totalquo: " + totalquo);
        //Get Total Awarded Amount
		totalaward = rfqvendorremote.getDouble("totalawardamt");
//        System.out.println("[FldPurOrderQtyCustom]totalaward: " + totalaward);

        if(!getMboValue().getPreviousValue().isNull())
        {
        	//Get Previous Quantity
        	prevqty = getMboValue().getPreviousValue().asDouble();
//        	System.out.println("[FldPurOrderQtyCustom]prevqty: " + prevqty);
        	if(!(mbo.isNull("unitcost") || mbo.getDouble("unitcost") == 0.0D))
        	{
        		//Subtract line cost from total quotation amount
        		totalquo = totalquo - (prevqty * mbo.getDouble("unitcost"));
//        		System.out.println("[FldPurOrderQtyCustom]less prev totalquo(not null or 0): " + totalquo);
        		
                if(mbo.getMboValue("isawarded").getBoolean())
                {
                	//Subtract line cost from total awarded amount
                	totalaward = totalaward - (prevqty * mbo.getDouble("unitcost"));
                	rfqvendorremote.setValue("totalawardamt", totalaward);
//                	System.out.println("[FldPurOrderQtyCustom]set totalawardamt: " + totalaward);
                }
        	}
        }

        if(!getMboValue().isNull())
        {
        	//Get Current Quantity
        	curqty = getMboValue().getDouble();
//           	System.out.println("[FldPurOrderQtyCustom]curqty: " + curqty);
        }
        if(!mbo.isNull("unitcost"))
        {
        	//Add line cost to total quotation amount
        	totalquo = totalquo + (curqty * mbo.getDouble("unitcost"));
//        	System.out.println("[FldPurOrderQtyCustom]less prev totalquo(not null): " + totalquo);
        }

        if(mbo.getMboValue("isawarded").getBoolean())
        {
//        	Add line cost to total awarded amount
        	totalaward = totalaward + (curqty * mbo.getDouble("unitcost"));
        	rfqvendorremote.setValue("totalawardamt", totalaward);
//        	System.out.println("[FldPurOrderQtyCustom]set totalawardamt: " + totalaward);
        }

        rfqvendorremote.setValue("totalquotationamt", totalquo);
//        System.out.println("[FldPurOrderQtyCustom]set totalquotationamt: " + totalquo);
        super.action();
    }
}
