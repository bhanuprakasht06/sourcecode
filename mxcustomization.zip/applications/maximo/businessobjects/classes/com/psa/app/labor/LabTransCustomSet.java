/**
 * @author	HCHA
 * Date		Jun 22, 2006
 * Comment	 
 */
package com.psa.app.labor;

import java.rmi.RemoteException;
import psdi.mbo.*;
import psdi.util.MXException;
import psdi.util.MXApplicationException;
import psdi.app.labor.*;
import psdi.app.workorder.WORemote;


/**
 * @author		HCHA
 * @class		LabTransCustomSet
 * @date		Jun 22, 2006
 * @function	
 */
public class LabTransCustomSet extends LabTransSet 
implements LabTransSetRemote, MboSetListenable
{
	 WORemote woOwner;
/**
 * @param arg0
 * @throws MXException
 * @throws RemoteException
 */
public LabTransCustomSet(MboServerInterface arg0) 
	throws MXException, RemoteException 
{
	super(arg0);

}

protected Mbo getMboInstance(MboSet mboset)
    throws MXException, RemoteException
{
    return new LabTransCustom(mboset);
}

public void canAdd()
	throws MXException
{
	super.canAdd();
	try
	{
		
		if(woOwner != null)
		{
			if(woOwner.getString("STATUS").compareTo("WAPPR-OT")==0 || woOwner.getString("STATUS").compareTo("WFAPPR-COMP")==0) 
			{
				Object aobj[] = {
						woOwner.getString("STATUS")
				};
				throw new MXApplicationException("labor", "otaddnotallowed", aobj);
			}
		}
		
	}catch(RemoteException remoteexception)
    {
    }
}
}
