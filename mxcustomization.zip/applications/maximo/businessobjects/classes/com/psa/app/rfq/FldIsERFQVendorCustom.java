/*
 * Modification history
 * 28-03-13 WMJ Creation
 * 28-03-13 WMJ EMS-566 [RFQ]To show if a RFQ vendor is an eRFQ vendor in the RFQ Vendor Tab
 */
 
package com.psa.app.rfq;

import java.rmi.RemoteException;
import psdi.app.rfq.RFQ;
import psdi.app.rfq.RFQVendor;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class FldIsERFQVendorCustom extends MboValueAdapter
{
  public FldIsERFQVendorCustom(MboValue mbv)
    throws MXException
  {
    super(mbv);
  }

  public void initValue()
    throws MXException, RemoteException
  {
    super.initValue();
    
    MboValue isERFQVendor = getMboValue(); 
    
    MboSetRemote compLoginErfqSet = getMboValue().getMbo().getMboSet("COMPLOGINERFQ");
     
    if(compLoginErfqSet.isEmpty())
    {
	    isERFQVendor.setValue(false, 11L);
	}
	else
	{
		isERFQVendor.setValue(true, 11L);
	}
  }
  
}