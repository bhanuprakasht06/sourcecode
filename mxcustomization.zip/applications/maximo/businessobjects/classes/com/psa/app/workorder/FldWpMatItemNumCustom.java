/*
 * Modification history
 * 04-04-2007	AGD	SR-064	Set vendor and cost from BA
 * 05-10-2007	AGD	SR-117	Populate store based on user default store
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.psa.app.common.InventoryCommonCustom;

import psdi.app.workorder.FldWpMatItemNum;
import psdi.mbo.DBShortcut;
import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldWpMatItemNumCustom extends FldWpMatItemNum
{
	
	public FldWpMatItemNumCustom(MboValue mbovalue)
			throws MXException
	{
		super(mbovalue);
	}


	public void action()
			throws MXException, RemoteException
	{
		super.action();

		MboValue mbovalue = getMboValue();
		MboRemote wpmaterial = mbovalue.getMbo();
      if (mbovalue.isNull())
      {
      	// Cater for empty value
			wpmaterial.setValueNull("vendor", MboConstants.NOACCESSCHECK);
	//Modified for MIMS project: start
		 wpmaterial.setFieldFlag("CONDITIONCODE", 8L, false);
	//Modified for MIMS project : end

      }
      else
      {
	//Modified for MIMS project: start

   		String itemnum1=getMboValue().getString();
		MboRemote mboRemote = getMboValue().getMbo();
		SqlFormat sql = new SqlFormat(mboRemote.getUserInfo(), "itemnum = :1 and conditionenabled = :2");
		sql.setObject(1, "ITEM", "itemnum", itemnum1);
		sql.setObject(2, "ITEM", "conditionenabled", "1");
		MboSetRemote  itemConditionSet = ((Mbo)mboRemote).getMboSet("$ITEM", "ITEM", sql.format());
		if (!itemConditionSet.isEmpty())
		{
			 wpmaterial.setFieldFlag("CONDITIONCODE", 8L, true);
		}	

	//Modified for MIMS project : end
      	MboSetRemote contractlineset = wpmaterial.getMboSet("CONTRACTLINE");
      	if (contractlineset.count() == 0)
      	{
      		// Cater for cases when item with contract is entered, then overridden with another item witout contract
      		wpmaterial.setValueNull("vendor", MboConstants.NOACCESSCHECK);
      	}
      	else
      	{
      		MboRemote contractline = contractlineset.getMbo(0);
      		wpmaterial.setValue("vendor", contractline.getMboSet("CONTRACT").getMbo(0).getString("vendor"), MboConstants.NOACCESSCHECK);
      		wpmaterial.setValue("unitcost", contractline.getDouble("unitcost"));
      	}
   		contractlineset.close();

//Begin modification SR-117
   		setStore(mbovalue, wpmaterial);
//End modification SR-117
   		
   	// Begin Modification for Consignment by GPTM 
   		
   		
   		Mbo mbo=getMboValue().getMbo();
   		
   		String itemnum=getMboValue().getString();
   		String store= mbo.getString("LOCATION");
   		if(store !=null && store.endsWith("CONSIGN"))
   		{
   		boolean consign = store.endsWith("CONSIGN");
		
		double itemqty=mbo.getDouble("itemqty");
		
			int i = store.indexOf("CONSIGN");
			String main_store=store.substring(0, i)+ "STORE";
			MboSetRemote mboset=getMboValue().getMbo().getThisMboSet();
			double wo_qty=0D;
			
			if(!mboset.isEmpty())
			{
				MboRemote mboremote;
				for(int j=0;(mboremote=mboset.getMbo(j))!=null;j++)
				{
					if(mboremote.getString("location").equalsIgnoreCase(main_store) && 
							mboremote.getString("itemnum").equalsIgnoreCase(itemnum))
					{
					wo_qty=wo_qty+mboset.getMbo(j).getDouble("itemqty");
					System.out.println("FldWpMatItemNumCustom-------3 WO_qty ="+wo_qty);
					}
				}
			}
			
			 SqlFormat sqlformat = new SqlFormat(mbo.getUserInfo(), "location = :1 and itemnum=:2");
	            sqlformat.setObject(1, "wpmaterial", "location", main_store);
	            sqlformat.setObject(2, "wpmaterial", "itemnum", itemnum);
	            MboSetRemote mbosetremote = mbo.getMboSet("$invcurbal", "invbalances", sqlformat.format());
	            
	            if(!mbosetremote.isEmpty())
	            {
	            	double presentqty=0D;
	            	for(int k=0;k<=(mbosetremote.count()-1);k++)
	            	{
	            		presentqty=presentqty+mbosetremote.getMbo(k).getDouble("curbal");
	            	}
	            	
	            	 
	            	 if(itemqty <= (presentqty-wo_qty) || (((itemqty > 0) && ((presentqty-wo_qty)>0)) && (itemqty >(presentqty-wo_qty))))
	            	{
	            		Object params[] = { main_store, Double.toString(presentqty),itemnum };
	            		throw new MXApplicationException("custom", "consignmentstock",params);
	            	}
	            	 
	            }
		}
	
   	// Begin Modification for Consignment by GPTM 
   		
      }
    
	}


//Begin modification SR-117
	private void setStore(MboValue itemvalue, MboRemote wpmaterial)
			throws MXException, RemoteException
	{
		UserInfo userinfo = wpmaterial.getUserInfo();
		String defstoreroom = (wpmaterial.isNull("location")) ? getDefaultStore(userinfo) : wpmaterial.getString("location");
		MboRemote inventory = InventoryCommonCustom.getInventoryMbo(itemvalue.getString(), defstoreroom, wpmaterial.getString("storelocsite"), userinfo);

		// Don't populate the store if the corresponding inventory record doesn't exist
		if (inventory != null)
			wpmaterial.setValue("location", defstoreroom, MboConstants.NOACCESSCHECK);	// The field class on location will take care of all the checks
	}


	/*
	 * Get the default store of a user
	 */
	private String getDefaultStore(UserInfo userinfo)
			throws MXException, RemoteException
	{
		DBShortcut dbshortcut = new DBShortcut();
		String defstoreroom = null;
		try
		{
			dbshortcut.connect(userinfo.getConnectionKey());
			SqlFormat sqlformat = new SqlFormat(userinfo, "SELECT defstoreroom FROM maxuser WHERE userid=:1");
			sqlformat.setObject(1, "maxuser", "userid", userinfo.getLoginUserName());
			ResultSet rs = dbshortcut.executeQuery(sqlformat.format());
			if (rs.next())
				defstoreroom = rs.getString("defstoreroom");
			rs.close();
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			String[] param = { ""+sqle.getErrorCode() };
			throw new MXApplicationException("system", "sql", param);
		}
		finally
		{
			try
			{
				dbshortcut.close();
			}
			catch (Exception e)
			{
				// Do nothing
			}
		}
		return defstoreroom;
	}
//End modification SR-117

}
