/*
 * Modification history
 * 20-07-18		Comm-IT		 To create ass_id.dat mapping file in the path - /opt/psa/rel/config/mapping
 */

package com.psa.app.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;

import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;

public class Createc21MappingFileCustom 
	implements ActionCustomClass
{
	public Createc21MappingFileCustom() 
	{
	}

	public void applyCustomAction(MboRemote mboremote, Object aobj[])
		throws MXException, RemoteException
	{
		System.out.println("-----------Createc21MappingFileCustom--------applyCustomAction()------");
		
		MboSetRemote alndomainSet =MXServer.getMXServer().getMboSet("ALNDOMAIN", mboremote.getUserInfo());
		alndomainSet.setWhere("domainid='PSA_LOCMAPPING'");
		alndomainSet.reset();
		
		
		if(!alndomainSet.isEmpty() & alndomainSet!=null)
		{
			// The name of the file to open.
			String fileName = "/opt/psa/rel/config/mapping/ass_id.dat";
			System.out.println("-----------Createc21MappingFileCustom--------file read-----------"+fileName);
			try 
	        {
				
				// This will reference one line at a time
				String line = null;
				FileWriter fileWriter = new FileWriter(fileName);
            
				// wrap FileWriter in BufferedWriter.
				BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
				int i=0;
	           	for(MboRemote alndomainMbo=alndomainSet.moveFirst(); alndomainMbo!=null; alndomainMbo=alndomainSet.moveNext())
	        	{        		
	        		String valueDesc = alndomainMbo.getString("VALUE") + "," + alndomainMbo.getString("DESCRIPTION");
	        		System.out.println("-----------Createc21MappingFileCustom--------valueDesc-----"+i+"-------:"+valueDesc);
	        		if (i != 0)
	        			bufferedWriter.newLine();
		            bufferedWriter.write(valueDesc);
		            i++;
	        	} 
	           	bufferedWriter.newLine();
	            

	            bufferedWriter.close();
	            
	            // FileReader reads text files in the default encoding.
	            FileReader fileReader = new FileReader(fileName);
	            System.out.println("-----------Createc21MappingFileCustom--------fileReader-----------"+fileReader);
	            // wrap FileReader in BufferedReader.
	            BufferedReader bufferedReader = new BufferedReader(fileReader);
	            System.out.println("-----------Createc21MappingFileCustom--------bufferedReader-----------"+bufferedReader);
	            while((line = bufferedReader.readLine()) != null) 
	            {
	                System.out.println("-----------------------line------------------------:"+ line);
	            }   

	            // close files.
	            bufferedReader.close(); 
	            
	        }
	        catch(FileNotFoundException ex) 
	        {
	            System.out.println("Unable to open file '" + fileName + "'");   
	            ex.printStackTrace();
	        }
	        catch(IOException ex) 
	        {
	            System.out.println("Error reading file '" + fileName + "'");                  
	            ex.printStackTrace();
	        }	    
		}
	}
}
