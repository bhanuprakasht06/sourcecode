/*
 * Modification history
 * 03-Oct-2007		AGD	SR-116	Validate vendor and update lookup
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;

import com.psa.app.common.VendorCheckCustom;

import psdi.app.workorder.FldWpMatVendor;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXException;


public class FldWpMatVendorCustom extends FldWpMatVendor
{

	public FldWpMatVendorCustom(MboValue vendorvalue)
			throws MXException, RemoteException
	{
		super(vendorvalue);
	}


	public void validate()
			throws MXException, RemoteException
	{
		super.validate();
		VendorCheckCustom.checkValidity(getMboValue(), "COMPANY");
	}


	/*
	 * Lookup
	 */
	public MboSetRemote getList()
   		throws MXException, RemoteException
   {
   	return VendorCheckCustom.getValidVendorList(getMboValue().getMbo());
   }

}
