/*
 * Modification history
 
 * 29-07-2013--4.1.1-  Enhance Work Order Tracking Application to enable users to create follow up work orders across multiple sites.
 *   
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;
import psdi.mbo.*;
import psdi.util.*;
import psdi.app.ticket.*;


public class CustRelatedRecordSet extends RelatedRecordSet
    implements RelatedRecordSetRemote
{

    public CustRelatedRecordSet(MboServerInterface ms)
        throws MXException, RemoteException
    {
        super(ms);
    }

    protected Mbo getMboInstance(MboSet ms)
        throws MXException, RemoteException
    {
        return new CustRelatedRecord(ms);
    }
}