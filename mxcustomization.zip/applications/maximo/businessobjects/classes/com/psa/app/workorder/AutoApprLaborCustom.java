package com.psa.app.workorder;

import java.rmi.RemoteException;
import psdi.app.labor.LabTransRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class AutoApprLaborCustom
implements ActionCustomClass
{

/*
* Constructor - does nothing
*/
public AutoApprLaborCustom()
{
}


/*
* Approve all unapproved labor reports
*/
public void applyCustomAction(MboRemote woremote, Object aobj[])
	throws MXException, RemoteException
{
mxLogger.debug("AutoApprLaborCustom - Entering");

wo = woremote;

MboSetRemote labtransset = wo.getMboSet("LABTRANS");
LabTransRemote labtrans;
for (int i = 0; (labtrans = (LabTransRemote) labtransset.getMbo(i)) != null; i ++)
{
	if (!labtrans.getBoolean("genapprservreceipt"))
		labtrans.approveLaborTransaction();
}
//labtransset.save();
//labtransset.close();

mxLogger.debug("AutoApprLaborCustom - Leaving");
}

private MboRemote			wo;
private static final MXLogger	mxLogger	= MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}
