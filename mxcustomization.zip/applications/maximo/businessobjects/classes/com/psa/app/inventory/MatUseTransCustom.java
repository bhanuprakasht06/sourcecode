/*
 * Modification history
 * 22-06-07	HCHA	NA			Creation
 * 10-04-07	AGD	SR-087	Get the WO GL A/c rather than the work type GL A/c for capital work (cater for capital work defined WO per WO)
 * 27-04-07	AGD	SR-030	Disallow transactions at cost>0 for project with no more budget
 */
package com.psa.app.inventory;

import java.rmi.RemoteException;

import com.psa.app.common.FinancialTransaction;

import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.mbo.*;
import psdi.app.common.TransactionGLMerger;
import psdi.app.inventory.Inventory;
import psdi.app.inventory.MatUseTrans;
import psdi.app.inventory.MatUseTransRemote;
import psdi.app.workorder.*;


public class MatUseTransCustom extends MatUseTrans 
	implements MatUseTransRemote
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public MatUseTransCustom(MboSet arg0) 
		throws MXException, RemoteException 
	{
		super(arg0);
//	Begin modification SR-030
		myset = arg0;
//	End modification SR-030
	}
	
	
	


	protected void updateGlAccounts()
	    throws MXException, RemoteException
	{

    	//Get WO Mbo (if exist)
    	WORemote wo = null;
	    MboRemote mboremote = getOwner();
	    if(mboremote == null || !(mboremote instanceof WORemote) || !getString("wonum").equals(mboremote.getString("wonum"))){

	    	if(!isNull("wonum")){
	        	
	        	WOSetRemote woSet =(WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", getUserInfo());
	            SqlFormat sqlformat = new SqlFormat(getUserInfo(), "wonum = :1 and siteid = :2");
	            sqlformat.setObject(1, "WORKORDER", "WONUM", getString("wonum"));
	            sqlformat.setObject(2, "WORKORDER", "SITEID", getString("siteid"));
	            woSet.setWhere(sqlformat.format());
	            
	            if(!woSet.isEmpty())
	            {
	            	wo = (WORemote) woSet.getMbo(0);
	            }
	        }        
	    	
	    }        
	    else{
	        if(mboremote instanceof WORemote){
	        	wo = (WORemote) mboremote;
	        }   
	    }

	    if(wo != null){
	    	String woWorkType = wo.getString("WORKTYPE");
	    	if(woWorkType != null){
	    		
	    		//Get Worktype mbo
	    		WorkTypeSetRemote worktypeSet =(WorkTypeSetRemote) MXServer.getMXServer().getMboSet("WORKTYPE", getUserInfo());
	    		
	            SqlFormat sqlformat = new SqlFormat(getUserInfo(), "worktype = :1 and orgid = :2");
	            sqlformat.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
	            sqlformat.setObject(2, "LABTRANS", "ORGID", getString("orgid"));
	            worktypeSet.setWhere(sqlformat.format());
	            
	            if(!worktypeSet.isEmpty())
	            {
	            	WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
	            	if(worktype.getBoolean("capitalwork")){
	            		//Capital Type Work Order
//	Begin modification SR-087
//	            		String wotypeGlAccount = worktype.getString("glaccount");
//	            		if(wotypeGlAccount != null){
	            			//Set WO GL Account into LabTrans Gl Debit Account
	            			String wotypeGlAccount = wo.getString("glaccount");
	            			setValue("gldebitacct", wotypeGlAccount, 11L);
	            			return;
//	            		}
//	End modification SR-087
	            			
	            	}
	            	
	            }
	    	}
	    }
	    
	    //Use Original Function
	    //++ COMM-IT commented to make it compatible with Maximo 7
	    //super.updateGlAccounts();
	    //-- COMM-IT commented to make it compatible with Maximo 7
	  //++ COMM-IT Added to make it compatible with Maximo 7
	    TransactionGLMerger glm = new TransactionGLMerger(this);
        glm.setMRInfo(getString("mrnum"), getString("mrlinenum"));
        glm.setItem(getString("itemnum"));
        glm.setItemSetID(getString("itemsetid"));
        MboRemote owner = getOwner();
        if(owner == null || !(owner instanceof WORemote) || !getString("wonum").equals(owner.getString("wonum")))
            glm.setWonum(getString("wonum"));
        else
            glm.setWO(owner);
        glm.setAssetnum(getString("assetnum"));
        glm.setLocation(getString("location"));
        glm.setStoreLoc(getString("storeloc"));
        if(!isNull("gldebitacct"))
            setValue("gldebitacct", glm.mergedGL(getTopGL(glm), getString("gldebitacct")), 11L);
        else
            setValue("gldebitacct", glm.getMergedDebitGLAccount(), 11L);
      //-- COMM-IT Added to make it compatible with Maximo 7
	}
	
	
	//++ COMM-IT Added to make it compatible with Maximo 7	
	private String getTopGL(TransactionGLMerger glm)
    throws MXException, RemoteException
    {
	    String topGl = null;
	    if(!isNull("itemnum"))
	        if(isNull("storeloc"))
	            topGl = glm.getItemResourceAccount();
	        else
	            topGl = glm.getInventoryGLAccount();
	    return topGl;
    }
	//-- COMM-IT Added to make it compatible with Maximo 7

	/*
	private void updateInventory(Inventory inventory, InvBalances invbalances, InvCost invcost)
    	throws MXException, RemoteException
    {
	   
        if(inventory.toBeAdded())
        {
            inventory.updateInventoryIssueDetails(getDate("actualdate"), getDouble("quantity"));
        } else
        {
            MatUseTransSet matusetransset = (MatUseTransSet)getThisMboSet();
            matusetransset.addDeltaIssueYTD(inventory, getDouble("quantity"), this);
        }
        if(isReturn())
        {
            inventory.updateInventoryAverageCost(getDouble("quantity"), Math.abs(getDouble("linecost")), 1.0D, invcost);
            invcost.increaseAccumulativeReceiptQty(getDouble("quantity"));
        }
    }
    */


    private MboRemote getInvCostRecord(MboRemote mboremote)
	    throws MXException, RemoteException
	{
    	
	    MboSetRemote mbosetremote = mboremote.getMboSet("INVCOST");
	    int i = 0;
	    for(MboRemote mboremote1 = null; (mboremote1 = mbosetremote.getMbo(i)) != null;)
	    {
	        if(mboremote1.getString("itemnum").equals(getString("itemnum")) && mboremote1.getString("location").equals(getString("storeloc")) && mboremote1.getString("itemsetid").equals(getString("itemsetid")) && mboremote1.getString("conditioncode").equals(getString("conditioncode")) && mboremote1.getString("siteid").equals(getString("siteid")))
	            return mboremote1;
	        i++;
	    }
	
	    return null;
	}


    public void save()
	    throws MXException, RemoteException
	{

    	Inventory inventory = null;
    	InvCostCustom invcost = null;

    	if(isReturn())
    	{
    		inventory = (Inventory)getSharedInventory();
    		if(inventory != null){
    			invcost = (InvCostCustom)getInvCostRecord(inventory);
    			//Check if there is invcost record
    			//if there is no invcost record -> unit price will be used => no rounding err
    			if(invcost!=null){

    				double curBalanceTotal = inventory.getCurrentBalance(null,null,getString("conditioncode"))+ invcost.getAccumulativeReceiptQty();
    				double curAvgCost = invcost.getDouble("avgcost");
    		    	double curAvgCostRnd = Math.round(curAvgCost*100.0)/100.0;

		    		//Set the rounded AvgCost into InvCost
		    	    //=> will enable consistant rounding error for muiltiple line receipts
		    	    //=> if not, the unrounded avgcost will be used to calculate the 2nd receipt line
		    	    invcost.setValue("avgcost", curAvgCostRnd, 2L);

    		    	double quantity = getDouble("quantity");
    		    	double linecost = Math.abs(getDouble("linecost"));
    		    	double newBalTotal = curBalanceTotal + quantity;

    		    /*
    		    	System.out.println("[MatUseTransCustomSet.save]Bef AvgCost:"+curAvgCost);
    		    	System.out.println("[MatUseTransCustomSet.save]Bef CurBal:" + inventory.getCurrentBalance(null,null,getString("conditioncode")));
    		    	System.out.println("[MatUseTransCustomSet.save]Bef Accumulative Receipt Qty:" + invcost.getAccumulativeReceiptQty());
    		    	System.out.println("[MatUseTransCustomSet.save]Bef CurBalTotal:" + curBalanceTotal);
    		    	System.out.println("[MatUseTransCustomSet.save]Exchange Rate:"+getDouble("exchangerate"));
    		    	System.out.println("[MatUseTransCustomSet.save]Quantity:"+getDouble("quantity"));
    		    	System.out.println("[MatUseTransCustomSet.save]Unit Cost:"+getDouble("unitcost"));
    		    	System.out.println("[MatUseTransCustomSet.save]Line Cost:"+getDouble("linecost"));
    		    */
    		    	if((newBalTotal)>0.0D && linecost!=0.0D && quantity!=0.0D )
    		    	{

    		    		double newAvgCost = 0;

    		    		if(curBalanceTotal > 0.0D){
    		    			newAvgCost = (curAvgCostRnd * curBalanceTotal + linecost ) / (newBalTotal);
    		    		}
    		    		else{
    		    			newAvgCost = linecost/quantity;
    		    		}

    		    		double newAvgCostRnd = Math.round(newAvgCost*100.0)/100.0;

    		    		// Rounding Error = New Total Balance * (New Avg Cost Rounded - New Avg Cost Not Rounded)
    		    	    // +ve => rounding error increases the store value (with comparison to the actual store value)
    		    	    // -ve => rounding error decreases the store value (with comparison to the actual store value)
    		    	    double roundingErr = newBalTotal * (newAvgCostRnd - newAvgCost);
    		    	    
    		    	  /*  
        		    	System.out.println("[MatUseTransCustomSet.save]After AvgCost(Cal):"+ newAvgCostRnd + "("+newAvgCost+")");
        			    System.out.println("[MatRecTransCustomSet.updateInventory]Rounding Error:"+roundingErr);
        			  */

    		    	    setValue("oldavgcost",curAvgCost, 11L);
    		    	    setValue("newavgcost",newAvgCost, 11L);
    		    	    setValue("oldtotalbal",curBalanceTotal, 11L);
    		    	    setValue("roundingerr",roundingErr, 11L);
    		    	}
    			}
    		}    		
        }

// Begin modification SR-030
    	if (getDouble("linecost") > 0)
    	{
			FinancialTransaction financialtransaction = new FinancialTransaction(myset);
			financialtransaction.validateProject(this, "WORKORDER");
    	}
// End modification SR-030

    	super.save();

    	//For Debug Purpose
    /*
    	if(isReturn() && inventory != null && invcost!=null){
    	    double newDBAvgCost = invcost.getDouble("avgcost");
    	    //Round up to 2 decimal places
    	    System.out.println("[MatUseTransCustomSet.save]After AvgCost(DB):"+ newDBAvgCost);
			System.out.println("[MatUseTransCustomSet.save]After Accumulative Receipt Qty:" + invcost.getAccumulativeReceiptQty());
    	}
    */

	}


// Begin modification SR-030
    MboSet myset;
// End modification SR-030

}
