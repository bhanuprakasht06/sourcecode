package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.InvUseLine;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public class CustomInvUseLine extends InvUseLine 
	implements CustomInvUseLineRemote 
{
	public CustomInvUseLine (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void add() 
		throws MXException, RemoteException 
	{
		super.add();
	}
	
	public void save() 
		throws MXException, RemoteException 
	{
		super.save();
	}
	
	public void copyInvbatchLineSetForReturn(MboSetRemote invUseIssueBatch)
			throws RemoteException, MXException
	{
		CustomInvUseBatchSetRemote newInvUseLineSet = (CustomInvUseBatchSetRemote)getMboSet("INVUSEBATCH");
		newInvUseLineSet.copyInvBatchLineSet(invUseIssueBatch);
	}
	
	public void copyInvbatchLineSetForTransfer(MboSetRemote invUseTransferBatch)
			throws RemoteException, MXException
	{
		CustomInvUseBatchSetRemote newInvUseLineSet = (CustomInvUseBatchSetRemote)getMboSet("INVUSEBATCH");
		newInvUseLineSet.copyInvBatchLineTransferSet(invUseTransferBatch);
	}
}
