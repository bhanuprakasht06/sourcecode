package com.psa.app.pm;

import java.io.PrintStream;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import psdi.app.system.CrontaskParam;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.server.MXServer;
import psdi.util.MXException;

public class CustPMCronParamUpdate
  implements ActionCustomClass
{
  public void applyCustomAction(MboRemote localMbo, Object[] params)
    throws MXException, RemoteException
  {
    CrontaskParam param = (CrontaskParam)localMbo;
    
    String logFilePath = param.getString("value");
    String[] path = logFilePath.split("_");
    System.out.println("from CustPMCronParamUpdate log file name = " + logFilePath);
    String runtime = "";
    
    DateFormat fileDateFormat = new SimpleDateFormat("ddMMyyyy");
    runtime = fileDateFormat.format(MXServer.getMXServer().getDate());
    logFilePath = path[0] + "_" + runtime + ".log";
    param.setValue("value", logFilePath, 9L);
    System.out.println("from CustPMCronParamUpdate log file name after updation= " + logFilePath);
  }
}
