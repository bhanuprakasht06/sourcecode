/*
 * Modification history 
 * 
 * 11-Dec-02 YCH Creation
 * 
 * This class is Route the labour transactions to update the labour transaction end date/time if needed
 * 
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;

import psdi.app.labor.LabTransRemote;
import psdi.app.labor.LabTransSetRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class SetLaborFinishDateTimeCustom 
	implements ActionCustomClass
{
	/*
     * Constructor - does nothing
     */
	public SetLaborFinishDateTimeCustom()
	{
	}
	
	/*
     * Check all labour end date/time.
     * 
     * If user route again, check all labour end time.
     *   i.	If labour end date/time is blank, update with actual finish end datetime.
     *  ii.	If labour end date/time is not blank, do nothing.
     *
     */
	public void applyCustomAction(MboRemote mboremote, Object[] aobj)
			throws MXException, RemoteException {
		mxLogger.debug("SetLaborFinishDateTimeCustom - Entering");
//		System.out.println("SetLaborFinishDateTimeCustom - Entering");
		
		//Get Labour Transactions Mbo
//		mxLogger.debug("LABORCODE -> " + mboremote.getString("laborcode"));
//		System.out.println("LABORCODE -> " + mboremote.getString("laborcode"));
		mxLogger.debug("WONUM -> " + mboremote.getString("WONUM"));
//		System.out.println("WONUM -> " + mboremote.getString("WONUM"));
		mxLogger.debug("SITEID -> " + mboremote.getString("SITEID"));
//		System.out.println("SITEID -> " + mboremote.getString("SITEID"));
		
		wo = mboremote;
		
//		boolean doesactdateNull = false;
		
//		doesactdateNull = wo.isNull("actfinish");
//		mxLogger.debug("Actual WO FinishDate is blank -> " + doesactdateNull);
//		System.out.println("SITEID -> " + mboremote.getString("SITEID"));
//		if (!doesactdateNull) {
			// Extract the Work Order Actual Finish Date separately into two fields
//			Date actFinishdate = wo.getDate("actfinish");
			Date curdate = new Date();
			Calendar actCal = Calendar.getInstance();
			actCal.setTime(curdate);
			
			Calendar enddate = Calendar.getInstance();
			Calendar endtime = Calendar.getInstance();
			
			enddate.set(actCal.get(1), actCal.get(2), actCal.get(5),0,0,0);
			endtime.set(1970, 0, 1, actCal.get(11), actCal.get(12),0);
//			endtime.set(14, actCal.get(14));	
			
			mxLogger.debug("Current Date -> " + curdate);
//			System.out.println("Current Date -> " + curdate);
			mxLogger.debug("Actual WO FinishDate Extracted Date -> " + enddate.getTime());
//			System.out.println("Actual WO FinishDate Extracted Date -> " + enddate.getTime());
			mxLogger.debug("Actual WO FinishDate Extracted Time -> " + endtime.getTime());
//			System.out.println("Actual WO FinishDate Extracted Time -> " + endtime.getTime());
			// End Extract
						
			LabTransSetRemote labtransset = (LabTransSetRemote) MXServer.getMXServer().getMboSet("LABTRANS", mboremote.getUserInfo());
			// SQL need to be confirmed by your side to retrieve the labor records
			SqlFormat sqlformatLabor = new SqlFormat(mboremote.getUserInfo(), "PSA_OT_FLAG = :1 and REFWO = :2 and siteid = :3");
			sqlformatLabor.setObject(1, "LABTRANS", "PSA_OT_FLAG", "0");
			sqlformatLabor.setObject(2, "LABTRANS", "REFWO", wo.getString("WONUM"));
			sqlformatLabor.setObject(3, "LABTRANS", "SITEID", wo.getString("SITEID"));
			labtransset.setWhere(sqlformatLabor.format());
			
			LabTransRemote labtrans;
			for (int i = 0; (labtrans = (LabTransRemote) labtransset.getMbo(i)) != null; i ++)
			{
				if (labtrans.isNull("finishdate") && labtrans.isNull("finishtime"))
				{
					mxLogger.debug("SetLaborFinishDateTimeCustom - Labour FinishDate before = " + labtrans.getDate("finishdate"));
//					System.out.println("SetLaborFinishDateTimeCustom - Labour FinishDate before = " + labtrans.getDate("finishdate"));
					mxLogger.debug("SetLaborFinishDateTimeCustom - Labour FinishTime before = " + labtrans.getDate("finishtime"));
//					System.out.println("SetLaborFinishDateTimeCustom - Labour FinishTime before = " + labtrans.getDate("finishtime"));
					
					labtrans.setValue("finishdate", enddate.getTime());
					labtrans.setValue("finishtime", endtime.getTime());
					
					mxLogger.debug("SetLaborFinishDateTimeCustom - Labour FinishDate after = " + enddate.getTime());
//					System.out.println("SetLaborFinishDateTimeCustom - Labour FinishDate after = " + enddate.getTime());
					mxLogger.debug("SetLaborFinishDateTimeCustom - Labour FinishTime after = " + endtime.getTime());
//					System.out.println("SetLaborFinishDateTimeCustom - Labour FinishTime after = " + endtime.getTime());
				}			
			}
			
			labtransset.save();
            labtransset.close();
//		}	
		
		mxLogger.debug("SetLaborFinishDateTimeCustom - Leaving");
//        System.out.println("SetLaborFinishDateTimeCustom - Leaving");	
	}
	
	private MboRemote wo;
    private static final MXLogger mxLogger = MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}
