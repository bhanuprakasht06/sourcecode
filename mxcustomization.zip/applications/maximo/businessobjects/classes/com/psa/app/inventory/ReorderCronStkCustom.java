/*
 * Modification history
 * 26-07-07	LS	SR-100	Reorder logic : 1 stock PR can have several delivery locations per contract or vendor
 * 05-03-08 HAM SR-100  Reordering process should not generate PR line for the item that has EOQ = 0
 * 13-03-08 HAM SR-100  Reorder will be applied when current balance is less than or equal to Reorder point
 * 10-07-08 HAM DR-062	Increase the initial capacity of HashMap grouping from 128 to 5000 and set itemgroup = null to free hash memory
 * 21-06-22 KP  PKG-4:UR-AP-IM-017 Update the orderqty calculation From [orderqty = orderqty + invitem.getDouble("ORDERQTY")] to [orderqty = rop + eoq + reserveqty - curbal - (prqty + poqty)] 
 * 14-09-22 KP  PKG-4:UR-AP-IM-017 If the calculated orderqty based on new formula is <=0, the the orderqty on prline to be set to 1.
 * 06-09-22 SHARMEYA  UR-AP-IM-021 Added additional check to count for open PR's for the items to be reordered.
 * 10-02-23 SHARMEYA  Added WHERE Clause to Filter only APPR contract lines to be fetched for the item LINE:336 
 */

package com.psa.app.inventory;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import psdi.app.inventory.InventoryRemote;
import psdi.app.pr.PRLineSetRemote;
import psdi.app.pr.PRSetRemote;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import com.psa.custom.common.MboConstantsCustom;
import com.psa.custom.common.MxEmail;
import com.psa.custom.ois.MxLog;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.MaxVarServiceRemote;
import psdi.server.SimpleCronTask;
import psdi.txn.MXTransaction;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class ReorderCronStkCustom extends SimpleCronTask {

   /**
    * @comment	Reset class variables 
    * @author	LS
    * @function	ReorderCronStkCustom
    * @date		26 Jul 2007
    */
	public ReorderCronStkCustom() {
		logFilePath = null;
		userInfo = null;
		logger = MXLoggerFactory.getLogger("maximo.application.INVENTOR");
		emailSubj = null;
	}
	
	
	/**
	  * @comment	[Standard Cron Task Function]Initialize cron task 
	  * @author		LS
	  * @function	init
	  * @date		26 Jul 2007
	  */
	public void init()
			throws MXException
	{
		super.init();
		
		email = new MxEmail();
		mxLog = new MxLog();  
	}

	
	/**
	  * @comment	[Standard Cron Task Function] Start cron task  
	  * @author		LS
	  * @function	start
	  * @date		26 Jul 2007
	  */
	public void start()
	{
		try
		{
			logger.info(getName() + " Start");
			if (getSleepTime() < 10000)	// Run only if next scheduled time is in less than 10 sec
			{
				mxLog.writeLog("Starting crontask");
				setSleepTime(0L);
			}
			else
			{
				logger.info("SleepTime: " + getSleepTime());
				logger.info(getName() + " crontask not yet scheduled : stopping now");
			}
		}
		catch (Exception e)
		{
			logger.error(getName() + " " + e.getMessage(), e);
		}
	}


	/**
	 * @comment		[Standard Cron Task Function]Stop cron task
	 * @author		LS
	 * @function	stop
	 * @date		26 Jul 2007
	 */
	public void stop()
	{
		logger.info(getName() + " Stop");
		if (mxLog.isEnabled())
		{
			try
			{
				mxLog.writeLog("Stopping crontask");
				mxLog.closeLogFile();
			}
			catch (Exception e)
			{
					logger.error(getName() + " " + e.getMessage(), e);
			}
		}
	}
		
	

	/**
	  * @comment	[Standard Cron Task Function] Set cron task instance 
	  * @author		LS
	  * @function	setCrontaskInstance
	  * @date		26 Jul 2007
	  */
	public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
	{
		try
		{
			super.setCrontaskInstance(crontaskinstanceremote);
		}
		catch (Exception e)
		{
			logger.error(getName() + " " + e.getMessage(), e);
		}
	}


	/**
	  * @comment	[Standard Cron Task Function] Get the parameters from Cron Task.
	  * @author		LS
	  * @function	getParameters
	  * @date		26 Jul 2007
	  */
	public CrontaskParamInfo[] getParameters()
			throws MXException, RemoteException
	{
		return params;
	}

	
	/**
	  * @comment	[Standard Cron Task Function]Perform the crontask action
	  * @author		LS
	  * @function	cronAction
	  * @date		26 Jul 2007
	  */
	public void cronAction() 
	{
		try
		{
			logger.debug(getName() + " Start of CronTask action");
			readConfig();
			if (!processData())
			{
				// Email for error
				String message = "Some data have problems. See log file " + mxLog.getLogFilePath() + " for details";
				email.send(emailSubj, genEmail(message, ""));
				logger.info(getName() + " Email sent");
			}
			logger.debug(getName() + " End of CronTask action");
		}
		catch (Exception e)
		{
			String message = e.getMessage();
			String stack = getStackTrace(e);

			// Log error
			logger.error(getName() + " " + message, e);
			mxLog.writeLog("ERROR " + message + "\n" + stack);

			// Email for error
			email.send(emailSubj, genEmail(message, stack));
			logger.info(getName() + " Email sent");

			stop();
		}       
	}

	
	/**
	 * @comment		Execute the reorder
	 * @author		LS
	 * @function	processData
	 * @date		26 Jul 2007
	 */
	/**
	 * @return
	 * @throws Exception
	 */
	private boolean processData()
		throws Exception
	{
		boolean noproblem = true;
		
		/*
		 * Retrive all the Items to check
		 */
		

		mxLog.writeLog("Starting Of the cron startTime---> "+LocalDateTime.now());
		
		MboSetRemote itemList = mxserver.getMboSet("ITEM", userInfo);
		SqlFormat sqlformat = new SqlFormat("EXISTS(SELECT 1 FROM inventory WHERE CATEGORY = 'STK' AND itemnum=item.itemnum AND itemsetid=item.itemsetid AND orderqty > 0 and minlevel>=0 and item.commoditygroup!='delete')");
	//	SqlFormat sqlformat = new SqlFormat("ITEMNUM in ('0900801','0901251')");
		mxLog.writeLog("***ReorderCronStkCustom.processData > sqlformat ="+sqlformat.format());
		mxLog.writeLog("***ReorderCronStkCustom.processData getMboSet> sqlformat ="+sqlformat.format());
		itemList.setWhere(sqlformat.format());
		itemList.reset();
		MboRemote item = null;
		boolean reorder = false;
		int prcounter = 0;
		DBShortcut dbshortcut = new DBShortcut();

		if (!itemList.isEmpty())
		{
			ItemGroup itemgroup = new ItemGroup();
			
			mxLog.writeLog("-------------- Start ---------------");
			
			try
			{
				dbshortcut.connect(userInfo.getConnectionKey());
				
				for (int i = 0; (item = itemList.getMbo(i)) != null; i ++)
				{
				
					MboSetRemote iteminv = item.getMboSet("REORDER_INVENTORY");
					iteminv.setOrderBy("ITEMNUM");
					MboRemote inv = null;
					//mxLog.writeLog("ReorderCronStkCustom.iteminv count ***********************"+iteminv.count());
					for (int j = 0; (inv = iteminv.getMbo(j)) != null && !reorder; j ++)
					{
						String orgid = inv.getString("ORGID");
						String itemnum = inv.getString("ITEMNUM");
						String location = inv.getString("LOCATION");
						String siteid = inv.getString("SITEID");
						String itemsetid = inv.getString("ITEMSETID");
						int deliverytime = inv.getInt("DELIVERYTIME");
						
						//mxLog.writeLog("***ReorderCronStkCustom.iteminv ["+j+"]:orgid="+orgid+",itemnum="+itemnum+",location="+location+",siteid="+siteid+",itemsetid="+itemsetid+",deliverytime="+deliverytime+",orderqty="+inv.getDouble("ORDERQTY"));
						
						if(inv.getDouble("ORDERQTY") > 0.0)
						{
							
							double reserveqty = GetResvQty(orgid, itemnum, location, siteid, itemsetid, deliverytime, dbshortcut);
							
							double invbalqty = SumCurBal(itemnum, location, siteid, itemsetid, dbshortcut);
							
							double winspqty = HoldCurBal(itemnum, siteid, dbshortcut);
							
							double curbal = invbalqty + winspqty;
							
							double prqty = GetPRQty(itemnum, location, siteid, itemsetid, dbshortcut);
							
							double poqty = GetPOQty(itemnum, location, siteid, itemsetid, dbshortcut);
							
							double expqty = GetExpQty(itemnum, location, siteid, itemsetid, deliverytime, dbshortcut);
							
							//mxLog.writeLog("Item Num : "+itemnum+" Location : "+location+" Current Balance : " + ((curbal + prqty + poqty) - reserveqty - expqty) + "  ROP : " + inv.getDouble("MINLEVEL"));

							//Begin Modification SR-100
							//if(inv.getDouble("MINLEVEL") > (curbal + prqty + poqty - reserveqty - expqty))
							//mxLog.writeLog("***ReorderCronStkCustom.MINLEVEL="+inv.getDouble("MINLEVEL")+", (curbal + prqty + poqty - reserveqty - expqty)"+(curbal + prqty + poqty - reserveqty - expqty));
							if(inv.getDouble("MINLEVEL") >= (curbal + prqty + poqty - reserveqty - expqty))
							//End Modification SR-100
							{
								reorder = true;
								//mxLog.writeLog("Item Num : "+itemnum+" Location : "+location+" Current Balance : " + ((curbal + prqty + poqty) - reserveqty - expqty) + "  ROP : " + inv.getDouble("MINLEVEL"));
								//block to check for open PR's for the respective item, UR-AP-IM-021
								int openprcount = 0;
								SqlFormat sqlformat1 = new SqlFormat(userInfo, "SELECT count(*) AS OPENPRCOUNT FROM PR pr join prline prl on prl.prnum = pr.prnum AND prl.siteid = pr.siteid WHERE prl.storeloc = :2 AND prl.itemnum = :1 AND prl.siteid = :3 AND prl.itemsetid = :4 AND prl.prnum = pr.prnum AND prl.siteid = pr.siteid AND prl.issue = 0 AND prl.ponum IS NULL AND pr.status IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='PRSTATUS' AND VALUE IN ('WAPPR', 'WAPPR-RFQ','PRWCFM')) AND pr.historyflag=0");
								sqlformat1.setObject(1, "inventory", "itemnum", itemnum);
								sqlformat1.setObject(2, "inventory", "location", location);
								sqlformat1.setObject(3, "inventory", "siteid", siteid);
								sqlformat1.setObject(4, "inventory", "itemsetid", itemsetid);
								//mxLog.writeLog("OPEN PRCOUNT Query"+sqlformat1.format());
								ResultSet rs = dbshortcut.executeQuery(sqlformat1.format());
								if (rs.next())
								{
								 openprcount = rs.getInt("OPENPRCOUNT");
								}
								rs.close();
								if (openprcount>0)
								{
									reorder = false;
									//mxLog.writeLog("OPENPRCOUNT="+openprcount+"for the item" +itemnum);
								}
								//end of the block
							}						
						}
					}
					
					inv = null;
					//mxLog.writeLog("***ReorderCronStkCustom.reorder ="+reorder);
					if(reorder)
					{
						//mxLog.writeLog("Starting to reorder for item " + iteminv.getMbo(0).getString("ITEMNUM")+". Current Count: " + (i+1));
						for (int k = 0; (inv = iteminv.getMbo(k)) != null; k ++)
						{
							// Begin Modification SR 100
							if(inv.getDouble("ORDERQTY") > 0.0)
							// End Modification SR 100
							{
								String contractnum = null;
								String vendor = null;
								String itemnum =null;
								itemnum = inv.getString("ITEMNUM");
								//UR-AP-IM-021
								String location = inv.getString("LOCATION");
								String siteid = inv.getString("SITEID");
								String itemsetid = inv.getString("ITEMSETID");
								//
																						
								if(inv.getString("VENDOR") != null)
								vendor = inv.getString("VENDOR");
								logger.debug(getName() + " Searching for a contract for item " + itemnum);
								// Get the contract lines for this item
									
								HashMap contractvendor = new HashMap();
								//BCT
								// added where clause to filter only APPR contract lines
								sqlformat = new SqlFormat(userInfo, "SELECT c.contractnum, c.vendor FROM contract c, contractline cl WHERE cl.contractnum = c.contractnum AND cl.revisionnum = c.revisionnum AND cl.orgid = c.orgid AND c.status = 'APPR' AND c.startdate <= getDate() AND (c.enddate IS NULL OR c.enddate >= getDate()) AND cl.itemnum = :1 and cl.linestatus='APPR'");
								sqlformat.setObject(1, "item", "itemnum", itemnum);
								ResultSet rs = dbshortcut.executeQuery(sqlformat.format());
								while (rs.next())
								{
									contractvendor.put(rs.getString("vendor"), rs.getString("contractnum"));
								}
								rs.close();
			
								/*
								 * Choose the approved contract among those found as follows :
								 * 	if no BA, don't change anything
								 *		if the vendor of a BA is the WP vendor, take this one
								 *		otherwise, take the 1st BA found
								 */
								if (contractvendor.size() > 0)
								{
									if (contractvendor.containsKey(vendor))
										contractnum = (String) contractvendor.get(vendor);
									else
									{
										Iterator iterator = contractvendor.keySet().iterator();
										vendor = (String) iterator.next();
										contractnum = (String) contractvendor.get(vendor);
									}
								}
									
								logger.debug(getName() + " Adding to the reorder list: " + itemnum + "/" + inv.getString("location")
											+ "\t-->\t" + contractnum + "/" + vendor);
								mxLog.writeLog(getName() + " Adding to the reorder list: " + itemnum + "/" + inv.getString("location")
								+ "\t-->\t" + contractnum + "/" + vendor);
								
								//UR-AP-IM-021 to check open PR against Item's storeroom level
								int openprcount1 = 0;
								SqlFormat sqlformat2 = new SqlFormat(userInfo, "SELECT count(*) AS PRCOUNT FROM PR pr join prline prl on prl.prnum = pr.prnum AND prl.siteid = pr.siteid WHERE prl.storeloc = :2 AND prl.itemnum = :1 AND prl.siteid = :3 AND prl.itemsetid = :4 AND prl.prnum = pr.prnum AND prl.siteid = pr.siteid AND prl.issue = 0 AND prl.ponum IS NULL AND pr.status IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='PRSTATUS' AND VALUE IN ('WAPPR', 'WAPPR-RFQ','PRWCFM')) AND pr.historyflag=0");
								sqlformat2.setObject(1, "inventory", "itemnum", itemnum);
								sqlformat2.setObject(2, "inventory", "location", location);
								sqlformat2.setObject(3, "inventory", "siteid", siteid);
								sqlformat2.setObject(4, "inventory", "itemsetid", itemsetid);
								ResultSet rs2 = dbshortcut.executeQuery(sqlformat2.format());
								if (rs2.next())
								{
									openprcount1 = rs2.getInt("PRCOUNT");
								}
								rs2.close();//
								
								//openprcount1 == 0  for UR-AP-IM-021, and changes ends here
								//if(!inv.isNull("orderunit"))//
								if(!inv.isNull("orderunit") && openprcount1 == 0) 
								{
									mxLog.writeLog("Adding to the reorder list: " + itemnum + "\t --> Location : "+ inv.getString("location")+"\t --> \t" + contractnum + "/" + vendor);
									mxLog.writeLog("ReorderCronStkCustom.after addvalue1 ***********************");
									itemgroup.add(contractnum, vendor, inv);
									mxLog.writeLog("ReorderCronStkCustom.after addvalue ***********************");
								}
								else
									mxLog.writeLog(itemnum + "/" + inv.getString("location") +" is not added to the Reorder List due to Required Field Order Unit is Null or the item has open PR");
						//		    mxLog.writeLog(prqty+"-PRQTY"+poqty+ "-POQTY" + curbal+ "-CURBAL");
								
							}
						}	
					}											
					reorder = false;
					iteminv.close();
				}
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
				String[] param = { ""+sqle.getErrorCode() };
				throw new MXApplicationException("system", "sql", param);
			}
			finally
			{
				try
				{
					dbshortcut.close();
				}
				catch (Exception e)
				{
					// Do nothing
				}
			}
		
			mxLog.writeLog("--------------ReorderCronStkCustom Start Creating PRs---------------");
			
			/*
			 * Create 1 PR per group in itemgroup
			 */
			PRSetRemote prset = (PRSetRemote)mxserver.getMboSet("PR", userInfo);
			// Ensure that PR creation and WO update are part of the same DB transaction (either both succeed or both fail)
			boolean mustsave = false;
			Set groups = itemgroup.keySet();
			if(groups!=null && groups.size()>0) {
				mxLog.writeLog("ReorderCronStkCustom.groups size**************"+groups.size());
			}
			Iterator iterator = groups.iterator();
			int maxprlines = ((MaxVarServiceRemote)MXServer.getMXServer().lookup("MAXVARS")).getInt("MAXPRLINES", "PSAST");
			String prnum = null;
			try
			{
				dbshortcut.connect(userInfo.getConnectionKey()); 
				while (iterator.hasNext())
				{
					MXTransaction mxtransaction = prset.getMXTransaction();
					itemList.setMXTransaction(mxtransaction);
	
					String group = (String)iterator.next();
					//mxLog.writeLog("ReorderCronStkCustom.group**************"+group);
					try
					{
						ArrayList items = itemgroup.get(group);
						//mxLog.writeLog("ReorderCronStkCustom.items size**************"+items.size());
						//mxLog.writeLog("ReorderCronStkCustom.PR Size : "+items.size());
						if (items.size() > maxprlines)
						{
							MboRemote temp;
							ArrayList itemsbybatch = new ArrayList();
							ArrayList itemsbyitemnum = new ArrayList();
							String lastitemnum = "";
							for (int j = 0; j < items.size(); j ++)
							{
								temp = (MboRemote) items.get(j);

								if (!temp.getString("ITEMNUM").equals(lastitemnum) && j != 0)								
								{
									for(int k = 0; k < itemsbyitemnum.size(); k++)
									{
										itemsbybatch.add((MboRemote) itemsbyitemnum.get(k));	
									}
									itemsbyitemnum = new ArrayList();
								}
								
								lastitemnum = temp.getString("ITEMNUM");
	
								if (temp.getString("ITEMNUM").equals(lastitemnum) || j == 0) 
								{
									itemsbyitemnum.add(temp);
								}
	
								if (itemsbybatch.size() + itemsbyitemnum.size() >= maxprlines)
								{
									prnum = null;
									prnum = generatePR(prset.add(), group, itemsbybatch, itemList, dbshortcut);	// Pass the Item set so that we can add inside the PR & PR line
									prcounter ++;
									mustsave = true;
									itemsbybatch = new ArrayList();
								}
							}
							
							if (itemsbyitemnum.size() != 0)
							{
								for(int k = 0; k < itemsbyitemnum.size(); k++)
									itemsbybatch.add((MboRemote)itemsbyitemnum.get(k));
								prnum = null;
								prnum = generatePR(prset.add(), group, itemsbybatch, itemList, dbshortcut);	// Pass the Item set so that we can add inside the PR & PR line
								prcounter ++;
								mustsave = true;
							}
						}
						else
						{
							prnum = null;
							prnum = generatePR(prset.add(), group, items, itemList, dbshortcut);	// Pass the Item set so that we can add inside the PR & PR line
							prcounter ++;
							mustsave = true;
						}
						if (mustsave)
						{
							mxtransaction.commit();
							mxLog.writeLog("PR: " + prnum + " successfully created");
						}
					}
					catch (SQLException sqle)
					{
						sqle.printStackTrace();
						String[] param = { ""+sqle.getErrorCode() };
						throw new MXApplicationException("system", "sql", param);
					}
					catch (Exception e)
					{
						String message = "Error during reorder stk cron task";
						logger.warn(getName() + " " + message + ". See log file for details");
						//mxLog.writeLog("|--" + message + "\n" + e.getMessage() + "\n" + getStackTrace(e));
						noproblem = false;
					}
				}
			}	
			catch (Exception e)
			{
				// Do nothing		
			}
			finally
			{
				try
				{
					dbshortcut.close();
				}
				catch (Exception e)
				{
					// Do nothing
				}
			}
			//Begin Modification DR-062
			itemgroup = null;
			//End Modification DR-062
		}
		mxLog.writeLog("[ReorderCronStkCustom] Total : " + prcounter + " PR created");
		logger.info(getName() + " Total : " + prcounter + " PR created");
		mxLog.writeLog("Total : " + prcounter + " PR created");
		
		mxLog.writeLog("-------------- End ---------------");
		return noproblem;
	}


	/**
	  * @comment	Create the PR and call generatePRLine to create the lines
	  * @author		LS
	  * @function	generatePR
	  * @date		30 Jul 2007
	  */

	private String generatePR(MboRemote pr, String group, ArrayList iteminv, MboSetRemote itemsetforupdate, DBShortcut dbshortcut)
			throws Exception, SQLException
	{
		String contractnum = null;
		String vendor = null;
		String vendorAndTriggerVal = null;
		String message = "Creating PR " + pr.getString("prnum");
		//Thirumal changes starts for Tender Ref No 5.2.42
		if (group != null)
		{
			int index = group.indexOf("|");

			if (index > 0)
				contractnum = group.substring(0, index);
			
			vendorAndTriggerVal = group.substring(index+1);
			if(vendorAndTriggerVal!=null){
				int vendorIndex = vendorAndTriggerVal.indexOf("|");
				if (vendorIndex > 0){
					vendor = vendorAndTriggerVal.substring(0, vendorIndex);
				}else if(vendorIndex <= 0){
					vendor = vendorAndTriggerVal.substring(vendorIndex+1);
				}
			}
			message += " for contract="+contractnum+" vendor="+vendor;
		}
		
		/*if (group != null)
		{
			String[] groupValues = group.split(":");
			System.out.println("items size**************"+groupValues.length);
			if(groupValues!=null && groupValues.length>0) {
				contractnum = groupValues[0];
				System.out.println("contractnum**************"+contractnum);
				vendor = groupValues[1];
				System.out.println("vendor**************"+vendor);
			}
			message += " for contract="+contractnum+" vendor="+vendor;
		}*/
		//Thirumal Changes ends
		else
			message += " without contract nor vendor";
		
		//mxLog.writeLog("|--" + message);
		//System.out.println("ReorderCronStkCustom.vendor**************"+vendor);
		//System.out.println("ReorderCronStkCustom.contractnum**************"+contractnum);
		/*
		 * Populate values for the PR header
		 */
		// Default values
		pr.setValue("buyahead", false, NOACCESSCHECK);
		java.util.Date date = mxserver.getDate();
		pr.setValue("changedate", date, NOACCESSCHECK);

		// Data related to the cron task
		pr.setValue("changeby", userInfo.getPersonId(), MboConstants.NOACCESSCHECK);

		// Data related to the work plan - any planned line will do for our purpose since the data are common to all lines
		MboRemote inv = (MboRemote)iteminv.get(0);
		
//		prdesc = "ReorderCronStkCustom";
		DateFormat fileDateFormat = new SimpleDateFormat("d-MMM-yy HH:mm");	// Ex: 9-Feb-07 23:10
		String runtime = fileDateFormat.format(mxserver.getDate());
		prdesc = getParamAsString("prdescription").replaceFirst("yyyymmddhhmm", runtime);

		prdescLong = null;
		
		pr.setValue("description", prdesc);
		pr.setValue("description_longdescription", prdescLong);
			
		String siteid = inv.getString("siteid");
		pr.setValue("siteid", siteid, NOACCESSCHECK);
		String orgid = inv.getString("orgid");
		pr.setValue("orgid", orgid, NOACCESSCHECK);

		if (vendor != null)
			pr.setValue("vendor", vendor);

		logger.debug(getName() + " PR tab general data set");

		// Data related to the contract
		MboRemote contract = null;
		if (contractnum != null)
		{
			contract = getContractMbo(contractnum);
			pr.setValue("contractrefid", contract.getString("contractid"), NOACCESSCHECK);
			pr.setValue("contractrefnum", contractnum, NOACCESSCHECK);
			pr.setValue("contractrefrev", contract.getInt("revisionnum"), NOACCESSCHECK);
			pr.setValue("currencycode", contract.getString("currencycode"), NOACCESSCHECK);
		}
		
		logger.debug(getName() + " PR data related to the contract set");
		
		/*
		 * Data related to site
		 * This program assumes that at least the address codes are populated for all sites, except MED
		 */
		MboRemote site = getSiteMbo(siteid);
		
        
		//Start -- Modified to suite Maximo 7.6 framework - Comm-IT
		//if (site.isNull("shiptoaddresscode"))
	/*	if(billtoShiptoShippingMbo != null) 	//End -- Modified to suite Maximo 7.6 framework - Comm-IT
		{
			// Get the billto of the site pointed by the prefix
			// WARNING - hard-code the logic to get the site from the prefix
			String realsiteid = null;
			String store = null;
			
			store = inv.getString("LOCATION");

			int storeindex = store.indexOf("STORE");

			if (storeindex > 0)
				realsiteid = store.substring(0, storeindex);
			
			site = getSiteMbo(realsiteid);
		}*/
		

		
		//Get Shipto Address from Storeroom - Change in logic - NextGen Maximo
		 MboRemote storeroomMbo = inv.getMboSet("STOREROOM").getMbo(0);
		 
		 MboSetRemote billtoShiptoShippingMbo = site.getMboSet("BILLTOSHIPTO");
		 billtoShiptoShippingMbo.setWhere("ADDRESSCODE='"+storeroomMbo.getString("SHIPTOADDRESSCODE")+"'");
		 billtoShiptoShippingMbo.reset();
		 
		 MboSetRemote billtoShiptoBillingMbo = site.getMboSet("BILLTOSHIPTO");
		 billtoShiptoBillingMbo.setWhere("ADDRESSCODE='"+storeroomMbo.getString("BILLTOADDRESSCODE")+"'");
		 billtoShiptoBillingMbo.reset();
		 
		 
        if ((storeroomMbo != null)) 
        {
        	pr.setValue("billto", storeroomMbo.getString("BILLTOADDRESSCODE"), 11L);
         	pr.setValue("shipto", storeroomMbo.getString("SHIPTOADDRESSCODE"), 11L);
        }	
        
        if ((pr.getString("shiptoattn").equals("")) && (billtoShiptoShippingMbo.getMbo(0) != null)) 
        {
        	if (billtoShiptoShippingMbo.getMbo(0).getString("shiptocontact").equals(""))
        		pr.setValue("shiptoattn", userInfo.getPersonId());
        	else
        		pr.setValue("shiptoattn", billtoShiptoShippingMbo.getMbo(0).getString("shiptocontact"), 11L);
        }
        if ((pr.getString("billtoattn").equals("")) && (billtoShiptoBillingMbo.getMbo(0) != null)) 
        {
        	if (billtoShiptoBillingMbo.getMbo(0).getString("billtocontact").equals(""))
        		pr.setValue("billtoattn", userInfo.getPersonId());
        	else
        		pr.setValue("billtoattn", billtoShiptoBillingMbo.getMbo(0).getString("billtocontact"), 11L);
        }
        
		 //Start -- Modified to suite Maximo 7.6 - Comm-IT
        /*if(!site.isNull("billtoaddresscode"))
            pr.setValue("billto", site.getString("billtoaddresscode"));
        if(!site.isNull("shiptoaddresscode"))
            pr.setValue("shipto", site.getString("shiptoaddresscode"));
        if(site.isNull("billtolaborcode"))
            pr.setValue("billtoattn", userInfo.getPersonId());
        else
            pr.setValue("billtoattn", site.getString("billtolaborcode"));
        if(site.isNull("shiptolaborcode"))
            pr.setValue("shiptoattn", userInfo.getPersonId());
        else
            pr.setValue("shiptoattn", site.getString("shiptolaborcode"));*/
        //End -- Modified to suite Maximo 7.6 - Comm-IT
		
		logger.debug(getName() + " PR data related to shipt to... set");
		/*
		 * Populate the PR lines
		 */
		PRLineSetRemote prlineset = (PRLineSetRemote)pr.getMboSet("prline");
		Iterator iterator = iteminv.iterator();
		while (iterator.hasNext())
		{
			MboRemote invitem = (InventoryRemote)iterator.next();
			MboRemote prline = prlineset.add();
			generatePRLine(prline, pr, invitem, contract, dbshortcut);
		}

		inv = null;
		return pr.getString("prnum");
	}

	
	/**
    * @comment	Create a PR line
    * @author	LS
    * @function	generatePRLine
    * @date		30 Jul 2007
    */
	private void generatePRLine(MboRemote prline, MboRemote pr, MboRemote invitem, MboRemote contract, DBShortcut dbshortcut)
	throws Exception, SQLException
	{
		try
		{
			logger.debug(getName() + " ReorderCronStkCustom.Adding PR line for item=" + invitem.getString("itemnum"));
			mxLog.writeLog("ReorderCronStkCustom.Adding PR line for item : " + invitem.getString("itemnum") + "\t --> \t" + invitem.getString("LOCATION"));
			
			String linetype = "ITEM";
			
			// Set the long description
	//		if (!invitem.isNull("description_longdescription"))
	//			prline.setValue("description_longdescription", invitem.getString("description_longdescription"));
	
			// Set the order quantity from the WP
			double orderqty = 0;
			String orgid = invitem.getString("ORGID");
			String itemnum = invitem.getString("ITEMNUM");
			String location = invitem.getString("LOCATION");
			String siteid = invitem.getString("SITEID");
			String itemsetid = invitem.getString("ITEMSETID");
			int deliverytime = invitem.getInt("DELIVERYTIME");
			
			if(invitem.getDouble("ORDERQTY") > 0.0)
			{
				double reserveqty = GetResvQty(orgid, itemnum, location, siteid, itemsetid, deliverytime, dbshortcut);
				double invbalqty = SumCurBal(itemnum, location, siteid, itemsetid, dbshortcut);
				double winspqty = HoldCurBal(itemnum, siteid, dbshortcut);
				double curbal = invbalqty + winspqty;
				double prqty = GetPRQty(itemnum, location, siteid, itemsetid, dbshortcut);
				double poqty = GetPOQty(itemnum, location, siteid, itemsetid, dbshortcut);
				double expqty = GetExpQty(itemnum, location, siteid, itemsetid, deliverytime, dbshortcut);
	
				orderqty = invitem.getDouble("ORDERQTY");
			/*
			 * PKG-4: UR-AP-IM-017 - START
			 *
			 *
				//Begin Modification SR-100
				//while(invitem.getDouble("MINLEVEL") > ((curbal + prqty + poqty - reserveqty - expqty) + orderqty))
				while(invitem.getDouble("MINLEVEL") >= ((curbal + prqty + poqty - reserveqty - expqty) + orderqty))
				//End Modification SR-100
				{
					orderqty = orderqty + invitem.getDouble("ORDERQTY");
				}
				
			*/
				
				double rop = invitem.getDouble("MINLEVEL");
				double eoq = invitem.getDouble("ORDERQTY");
				orderqty = rop + eoq + reserveqty - curbal - (prqty + poqty);
				
				// <START> 14-09-22 KP  PKG-4:UR-AP-IM-017 If the calculated orderqty based on new formula is <=0, the the orderqty on prline to be set to 1.
				if (orderqty <=0)
				{
					orderqty=1;
				}
				//<END> 14-09-22 KP  PKG-4:UR-AP-IM-017 If the calculated orderqty based on new formula is <=0, the the orderqty on prline to be set to 1.
			
			/*
			 * PKG4: UR-AP-IM-017 - END
			 */
				
			}
			siteid = null;
			String store = null;
			
			store = invitem.getString("LOCATION");
			int storeindex = store.indexOf("STORE");
			if (storeindex > 0)
				siteid = store.substring(0, storeindex);
			
			MboRemote site = getSiteMbo(siteid);
			
			
			/*
			 * Data must be set in this order : linetype, itemnum, wonum
			 */
			prline.setValue("linetype", linetype, MboConstantsCustom.DBSET);
			
	//		 Set the itemnum, condition code and description (if no itemnum)
			if (invitem.isNull("itemnum"))
			{
				prline.setValue("description", invitem.getString("description"), MboConstantsCustom.DBSET);
			}
			else
			{
				prline.setValue("itemnum", invitem.getString("itemnum"));
	
				if (!invitem.isNull("conditioncode"))
					prline.setValue("conditioncode", invitem.getString("conditioncode"));
				else if (linetype.equalsIgnoreCase("ITEM"))
				{
					// set by default the condition code that's 100%
					MboRemote itemconditionfull = invitem.getMboSet("ITEMCONDITION_FULL").getMbo(0);
					if (itemconditionfull != null)
						prline.setValue("conditioncode", itemconditionfull.getString("conditioncode"));
				}
			}
			
			//Set the storeloc after the itemnum is set in PR to support enhancement UR-AP-PU-010
			prline.setValue("storeloc", store, NOACCESSCHECK);
			
			//logger.debug(getName() + " Batch 1/3 of PR line data set");
			prline.setValue("orderqty", orderqty, NOACCESSCHECK);
			
			if (!invitem.isNull("orderunit"))
				prline.setValue("orderunit", invitem.getString("orderunit"), NOACCESSCHECK);
			
			if (!pr.isNull("contractrefnum"))
			{
				prline.setValue("contractrefnum", pr.getString("contractrefnum"), MboConstantsCustom.DBSET);
				prline.setValue("contractrefrev", pr.getString("contractrefrev"), MboConstantsCustom.DBSET);
				MboRemote contractline = getContractLineMbo(pr.getString("contractrefnum"), pr.getString("contractrefrev"), invitem.getString("itemnum"));
				prline.setValue("unitcost", contractline.getDouble("unitcost"), MboConstantsCustom.DBSET);
			}
			else
			{
				prline.setValue("unitcost", invitem.getMboSet("INVCOST").getMbo(0).getDouble("avgcost"), MboConstantsCustom.DBSET);
			}
			
			//logger.debug(getName() + " Batch 2/3 of PR line data set");
			
			
			//Start -- Modified to suite Maximo 7.6 framework - Comm-IT
			//MboRemote billtoShiptoShippingMbo = site.getMboSet("SHIPTODEFAULT").getMbo(0);
			
			//Get Shipto Address from Storeroom - Change in logic - NextGen Maximo
			MboRemote storeroomMbo = invitem.getMboSet("STOREROOM").getMbo(0);
			
	        
			
	        //	Set the shipto of the PRLine
			//if (!site.isNull("shiptoaddresscode"))
			if(storeroomMbo != null) 	
				//prline.setValue("shipto", site.getString("shiptoaddresscode"));
				prline.setValue("shipto", storeroomMbo.getString("SHIPTOADDRESSCODE"), 11L);
			//End -- Modified to suite Maximo 7.6 framework - Comm-IT
			prline.setValue("conversion", 1, NOACCESSCHECK);
			
			// Default values
			prline.setValue("linecost2", 0, NOACCESSCHECK);
			prline.setValue("mktplcitem", 0, NOACCESSCHECK);
	
			//logger.debug(getName() + " Batch 3/3 of PR line data set");
			
		}
		catch(MXException mxexception)
		{
			mxexception.printStackTrace();
			throw mxexception;
		}
	
	}

	/**
	 * @comment		Initialize class variables
	 * @author		Ls
	 * @function	SumCurBal
	 * @date		21 Aug 2007
	 */
	private double SumCurBal(String itemnum, String location, String siteid, String itemsetid, DBShortcut dbshortcut)
			throws RemoteException, MXException, SQLException
		{
			MboRemote invbalMbo;
			double curbal = 0.0;
			//mxLog.writeLog("ITEMNUM used in SumCurBal Query---> "+itemnum);
			
	        LocalDateTime startTime = LocalDateTime.now();
			
			//mxLog.writeLog("Before Executing for SumCurBal Query startTime---> "+startTime);
			
			//SqlFormat sqlformat = new SqlFormat(userInfo, "SELECT sum(CURBAL) AS CURBAL FROM invbalances invb WHERE invb.itemnum = :1 AND invb.location = :2 AND invb.siteid = :3 AND invb.itemsetid = :4");
	        
			MXServer mxserver = MXServer.getMXServer();
	        MboSetRemote iteminvbalSet = mxserver.getMboSet("INVBALANCES", userInfo);
	        
	        SqlFormat sqlformat = new SqlFormat("itemnum = :1 AND location = :2 AND siteid = :3 AND itemsetid = :4");
	        sqlformat.setObject(1, "inventory", "itemnum", itemnum);
	        sqlformat.setObject(2, "inventory", "location", location);
	        sqlformat.setObject(3, "inventory", "siteid", siteid);
			sqlformat.setObject(4, "inventory", "itemsetid", itemsetid);
			iteminvbalSet.setWhere(sqlformat.format());
	        
			
			//mxLog.writeLog("***ReorderCronStkCustom.SumCurBal.sqlformat="+sqlformat.format());

			for (int e=0;(invbalMbo=iteminvbalSet.getMbo(e))!= null;e++)
			{
			curbal = curbal+invbalMbo.getDouble("CURBAL");
			}
			
			//mxLog.writeLog("After Executing for SumCurBal Query EndTime---> "+startTime);
			//mxLog.writeLog("Curbal from Sumcurbal Query--> "+curbal);
			iteminvbalSet.close();
			return curbal;		
		}
	/**
	 * @comment		Initialize class variables
	 * @author		Ls
	 * @function	HoldCurBal
	 * @date		21 Aug 2007
	 */
	private double HoldCurBal(String itemnum, String siteid, DBShortcut dbshortcut)
		throws RemoteException, MXException, SQLException
	{
		double winspqty = 0.0;
		MboRemote matrecMbo;
		
		//mxLog.writeLog("ITEMNUM used in HoldCurBal Query---> "+itemnum);
        LocalDateTime startTime = LocalDateTime.now();
		
		//mxLog.writeLog("Before Executing for HoldCurBal Query startTime---> "+startTime);
		//SqlFormat sqlformat = new SqlFormat(userInfo, "SELECT sum(mrt.QUANTITY - mrt.REJECTQTY) AS WINSPQTY FROM matrectrans mrt WHERE mrt.itemnum=:1 AND mrt.tostoreloc=(SELECT location FROM locations WHERE TYPE='HOLDING' AND siteid=:2) AND mrt.status='WINSP' AND mrt.siteid=:2");
		
		MXServer mxserver = MXServer.getMXServer();
        MboSetRemote matrecSet = mxserver.getMboSet("MATRECTRANS", userInfo);
        
        SqlFormat sqlformat = new SqlFormat("itemnum=:1 AND tostoreloc=(SELECT location FROM locations WHERE TYPE='HOLDING' AND siteid=:2) AND status='WINSP' AND siteid=:2");
        matrecSet.setWhere(sqlformat.format());
		sqlformat.setObject(1, "inventory", "itemnum", itemnum);
		sqlformat.setObject(2, "inventory", "siteid", siteid);
		matrecSet.setWhere(sqlformat.format());
		//mxLog.writeLog("***ReorderCronStkCustom.HoldCurBal.sqlformat="+sqlformat.format());

	for (int f=0;(matrecMbo=matrecSet.getMbo(f))!= null;f++)
	{
		double quantity=matrecMbo.getDouble("QUANTITY");
		double rejectqty=matrecMbo.getDouble("REJECTQTY");
		winspqty = winspqty+(quantity-rejectqty);
	}
	
	//mxLog.writeLog("After Executing for HoldCurBal Query EndTime---> "+startTime);
	//mxLog.writeLog("Curbal from HoldCurBal Query--> "+winspqty);
	matrecSet.close();
	return winspqty;		
}

	/**
	 * @comment		Initialize class variables
	 * @author		Ls
	 * @function	HoldCurBal
	 * @date		21 Aug 2007
	 */
	private double GetResvQty(String orgid, String itemnum, String location, String siteid, String itemsetid, int deliverytime, DBShortcut dbshortcut)
		throws RemoteException, MXException, SQLException
	{
		double resvqty = 0.0;
		MboRemote invresMbo;
		
		//mxLog.writeLog("ITEMNUM used in GetResvQty Query---> "+itemnum);
        LocalDateTime startTime = LocalDateTime.now();
		
		//mxLog.writeLog("Before Executing for GetResvQty Query startTime---> "+startTime);
		
		MXServer mxserver = MXServer.getMXServer();
        MboSetRemote invresSet = mxserver.getMboSet("INVRESERVE", userInfo);
        
        SqlFormat sqlformat = new SqlFormat("orgid = :1 AND storelocsiteid = :2 AND itemnum = :3 AND itemsetid = :4 AND location = :5 AND directreq = 0 AND requireddate <= getDate() + :6");

		//SqlFormat sqlformat = new SqlFormat(userInfo, "SELECT sum(RESERVEDQTY) AS RESERVEDQTY FROM invreserve invr WHERE invr.orgid = :1 AND invr.storelocsiteid = :2 AND invr.itemnum = :3 AND invr.itemsetid = :4 AND invr.location = :5 AND invr.directreq = 0 AND invr.requireddate <= getDate() + :6 ");
		
        sqlformat.setObject(1, "inventory", "orgid", orgid);
		sqlformat.setObject(2, "inventory", "siteid", siteid);
		sqlformat.setObject(3, "inventory", "itemnum", itemnum);
		sqlformat.setObject(4, "inventory", "itemsetid", itemsetid);
		sqlformat.setObject(5, "inventory", "location", location);
		sqlformat.setInt(6, deliverytime);
		invresSet.setWhere(sqlformat.format());
		//mxLog.writeLog("***ReorderCronStkCustom.GetResvQty.sqlformat="+sqlformat.format());
		
		for (int e=0;(invresMbo=invresSet.getMbo(e))!= null;e++)
		{
			resvqty = resvqty+invresMbo.getDouble("RESERVEDQTY");
		}
		
		//mxLog.writeLog("After Executing for GetResvQty Query EndTime---> "+startTime);
		//mxLog.writeLog("Curbal from GetResvQty Query--> "+resvqty);
		invresSet.close();
		return resvqty;
	}
		
		
	
	/**
	 * @comment		Initialize class variables
	 * @author		Ls
	 * @function	GetPRQty
	 * @date		27 Aug 2007
	 */
	private double GetPRQty(String itemnum, String location, String siteid, String itemsetid, DBShortcut dbshortcut)
		throws RemoteException, MXException, SQLException
	{
		double prqty = 0.0;
		MboRemote prqtyMbo;
		
		//mxLog.writeLog("ITEMNUM used in GetPRQty Query---> "+itemnum);
        LocalDateTime startTime = LocalDateTime.now();
		
		//mxLog.writeLog("Before Executing for GetPRQty Query startTime---> "+startTime);
		
		MXServer mxserver = MXServer.getMXServer();
        MboSetRemote prqtySet = mxserver.getMboSet("PRLINE", userInfo);
        
		//SqlFormat sqlformat = new SqlFormat(userInfo, "SELECT sum(prl.ORDERQTY) AS PRQTY FROM prline prl, pr WHERE prl.storeloc = :2 AND prl.itemnum = :1 AND prl.siteid = :3 AND prl.itemsetid = :4 AND prl.prnum = pr.prnum AND prl.siteid = pr.siteid AND prl.issue = 0 AND prl.ponum IS NULL AND pr.status IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='PRSTATUS' AND MAXVALUE IN ('WAPPR', 'APPR')) AND pr.historyflag=0");
		
        SqlFormat sqlformat = new SqlFormat("storeloc = :2 AND itemnum = :1 AND siteid = :3 AND itemsetid = :4   AND issue = 0 AND ponum IS NULL AND prnum in (select prnum from pr where  historyflag=0 AND status IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='PRSTATUS' AND MAXVALUE IN ('WAPPR', 'APPR'))) ");
		
		sqlformat.setObject(1, "inventory", "itemnum", itemnum);
		sqlformat.setObject(2, "inventory", "location", location);
		sqlformat.setObject(3, "inventory", "siteid", siteid);
		sqlformat.setObject(4, "inventory", "itemsetid", itemsetid);
		prqtySet.setWhere(sqlformat.format());
		//mxLog.writeLog("***ReorderCronStkCustom.GetPRQty.sqlformat="+sqlformat.format());
       

		for (int g=0;(prqtyMbo=prqtySet.getMbo(g))!= null;g++)
		{
			prqty = prqty+prqtyMbo.getDouble("ORDERQTY");
		}
		
		//mxLog.writeLog("After Executing for GetPRQty Query EndTime---> "+startTime);
		//mxLog.writeLog("Curbal from GetPRQty Query--> "+prqty);
		prqtySet.close();
		return prqty;
	}


	/**
	 * @comment		Initialize class variables
	 * @author		Ls
	 * @function	GetPOQty
	 * @date		27 Aug 2007
	 */
	private double GetPOQty(String itemnum, String location, String siteid, String itemsetid, DBShortcut dbshortcut)
		throws RemoteException, MXException, SQLException
	{
		double poqty = 0.0;
		MboRemote poqtyMbo;
		
		//mxLog.writeLog("ITEMNUM used in GetPOQty Query---> "+itemnum);
        LocalDateTime startTime = LocalDateTime.now();
		
		//mxLog.writeLog("Before Executing for GetPOQty Query startTime---> "+startTime);
		
		MXServer mxserver = MXServer.getMXServer();
        MboSetRemote poqtySet = mxserver.getMboSet("POLINE", userInfo);

		//PO Revision number included in the query - Maximo 7.6
		//SqlFormat sqlformat = new SqlFormat(userInfo, "SELECT sum(pol.ORDERQTY - isnull(pol.RECEIVEDQTY, 0)) AS POQTY FROM poline pol, po WHERE pol.storeloc = :2 AND pol.itemnum = :1 AND pol.itemsetid = :4 AND pol.siteid = :3 AND pol.ponum = po.ponum AND pol.revisionnum = po.revisionnum AND pol.siteid = po.siteid AND pol.RECEIPTSCOMPLETE = 0 AND pol.issue = 0 AND (pol.orderqty > pol.receivedqty OR pol.receivedqty IS NULL) AND po.status IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='POSTATUS' AND MAXVALUE IN ('WAPPR', 'APPR', 'INPRG')) AND po.potype IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='POTYPE' AND MAXVALUE IN ('STD', 'REL', 'CHG')) AND po.historyflag=0");
		
        SqlFormat sqlformat = new SqlFormat("storeloc = :2 AND itemnum = :1 AND itemsetid = :4 AND siteid = :3 AND RECEIPTSCOMPLETE = 0 AND issue = 0 AND (orderqty > receivedqty OR receivedqty IS NULL) AND ponum in ( select ponum from po where status IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='POSTATUS' AND MAXVALUE IN ('WAPPR', 'APPR', 'INPRG')) AND poline.revisionnum=po.revisionnum AND potype IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='POTYPE' AND MAXVALUE IN ('STD', 'REL', 'CHG')) AND historyflag=0)");
		
		sqlformat.setObject(1, "inventory", "itemnum", itemnum);
		sqlformat.setObject(2, "inventory", "location", location);
		sqlformat.setObject(3, "inventory", "siteid", siteid);
		sqlformat.setObject(4, "inventory", "itemsetid", itemsetid);
		poqtySet.setWhere(sqlformat.format());
		//mxLog.writeLog("***ReorderCronStkCustom.GetPOQty.sqlformat="+sqlformat.format());
       

		
		for (int h=0;(poqtyMbo=poqtySet.getMbo(h))!= null;h++)
		{
			double orderqty=poqtyMbo.getDouble("ORDERQTY");
			double recqty=poqtyMbo.getDouble("RECEIVEDQTY");
			
			double sumofqty=orderqty-recqty;
			
			poqty = poqty+(sumofqty);
		}
		
		//mxLog.writeLog("After Executing for GetPOQty Query EndTime---> "+startTime);
		//mxLog.writeLog("Curbal from GetPOQty Query--> "+poqty);
		poqtySet.close();
		return poqty;
	}

	/**
	 * @comment		Initialize class variables
	 * @author		Ls
	 * @function	GetPOQty
	 * @date		27 Aug 2007
	 */
	private double GetExpQty(String itemnum, String location, String siteid, String itemsetid, int deliverytime, DBShortcut dbshortcut)
		throws RemoteException, MXException, SQLException
	{
		double expqty = 0.0;
		MboRemote invlotMbo;
		//mxLog.writeLog("ITEMNUM used in GetExpQty Query---> "+itemnum);
        LocalDateTime startTime = LocalDateTime.now();
		
		//mxLog.writeLog("Before Executing for GetExpQty Query startTime---> "+startTime);
		
		MXServer mxserver = MXServer.getMXServer();
        MboSetRemote invlotSet = mxserver.getMboSet("INVBALANCES", userInfo);
        
        SqlFormat sqlformat = new SqlFormat("itemnum = :1 AND location = :2 AND siteid = :3 AND itemsetid = :4  AND itemnum in (select itemnum from invlot invlot where invlot.itemnum = :1 AND invlot.useby < getDate() + :5 AND invlot.location = :2 AND invlot.siteid=:4 AND invlot.itemsetid = :4)");

		//SqlFormat sqlformat = new SqlFormat(userInfo, "SELECT sum(invb.CURBAL) AS EXPQTY FROM invlot invl, invbalances invb WHERE invl.itemnum = :1 AND invl.location = :2 AND invl.siteid = :3 AND invl.itemsetid = :4 AND invl.useby < getDate() + :5 AND invb.itemnum = invl.itemnum AND invb.location = invl.location AND invb.lotnum = invl.lotnum AND invb.siteid=invl.siteid AND invb.itemsetid = invl.itemsetid");
		sqlformat.setObject(1, "inventory", "itemnum", itemnum);
		sqlformat.setObject(2, "inventory", "location", location);
		sqlformat.setObject(3, "inventory", "siteid", siteid);
		sqlformat.setObject(4, "inventory", "itemsetid", itemsetid);
		sqlformat.setInt(5, deliverytime);
		invlotSet.setWhere(sqlformat.format());
		
		//mxLog.writeLog("***ReorderCronStkCustom.GetExpQty.sqlformat="+sqlformat.format());
		
		
		for (int l=0;(invlotMbo=invlotSet.getMbo(l))!= null;l++)
		{
			expqty = expqty+invlotMbo.getDouble("CURBAL");
		}
		//mxLog.writeLog("After Executing for GetExpQty Query EndTime---> "+startTime);
		//mxLog.writeLog("Curbal from GetExpQty Query--> "+expqty);
		invlotSet.close();
		return expqty;
	}

	
	/**
	 * @comment		Initialize class variables
	 * @author		Ls
	 * @function	readConfig
	 * @date		26 Jul 2007
	 */
	private void readConfig()
		throws RemoteException, MXException
	{
		mxserver = MXServer.getMXServer();
		userInfo = getRunasUserInfo();

		// PR description
		DateFormat fileDateFormat = new SimpleDateFormat("d-MMM-yyyy HH:mm");	// Ex: 9-Feb-07 23:10
		String runtime = fileDateFormat.format(mxserver.getDate());

		// Log file
		logFilePath = getParamAsString("logfile");
		if (logFilePath != null)
		{
			logFilePath = logFilePath.trim();
			if (logFilePath.equals(""))
				logFilePath = null;
			else
			{
				fileDateFormat = new SimpleDateFormat("yyMMddHHmm");
				runtime = fileDateFormat.format(mxserver.getDate());
				logFilePath = logFilePath.replaceAll("yyyymmddhhmm", runtime);
				mxLog.setEnabled(true);
				mxLog.setLogFilePath(logFilePath);
				mxLog.setLogTag(getName());
				try {
					mxLog.createLogFile();
				}
				catch (Exception e) {
	             logger.error(getName() + " " + e.getMessage(), e);
				}
			}
		}

		// Email
		email.setToMail(getParamAsString("emailto"));
		Properties properties = mxserver.getConfig();
	    email.setFromMail(properties.getProperty("mxe.adminEmail", null));
		emailSubj = getParamAsString("alertemailsubj");
	}


	/**
	  * @comment	Generate email message from an error
	  * @author		LS
	  * @function	genEmail
	  * @date		26 Jul 2007
	  */
	private String genEmail(String error, String stack)
	{
		String emailMsg = "Date: " + new Date() + "\n"
				+ "Error Message: " + error + "\n"
				+ stack;
		return emailMsg;
	}


	/**
	  * @comment	Get the error stack trace into a String
	  * @author		LS
	  * @function	getStackTrace
	  * @date		26 Jul 2007
	 */
	private String getStackTrace(Exception e)
	{
		String stack = "";
		StackTraceElement element[] = e.getStackTrace();
		for (int i = 0; i < element.length; i++)
			stack += "\tat " + element[i].toString() + "\n";
		return stack;
	}


	/**
	  * @comment	Get the approved contract mbo from a contract number
	  * @author		LS
	  * @function	getContractMbo
	  * @date		30 Jul 2007
	  */
	private MboRemote getContractMbo(String contractnum)
		throws Exception
	{
		MboSetRemote contractset = mxserver.getMboSet("contract", userInfo);
		SqlFormat sqlformat = new SqlFormat("contractnum=:1 AND status='APPR'");
		sqlformat.setObject(1, "contract", "contractnum", contractnum);
		contractset.setWhere(sqlformat.format());
		return contractset.getMbo(0);
	}

	
	/**
	  * @comment	Get the contractline mbo from a contract number and itemnum
	  * @author		LS
	  * @function	getContractLineMbo
	  * @date		30 Jul 2007
	  */
	private MboRemote getContractLineMbo(String contractnum, String revisionnum, String itemnum)
		throws Exception
	{
		MboSetRemote contractlineset = mxserver.getMboSet("contractline", userInfo);
		SqlFormat sqlformat = new SqlFormat("contractnum=:1 AND revisionnum=:2 AND itemnum=:3");
		sqlformat.setObject(1, "contractline", "contractnum", contractnum);
		sqlformat.setObject(2, "contractline", "revisionnum", revisionnum);
		sqlformat.setObject(3, "contractline", "itemnum", itemnum);
		contractlineset.setWhere(sqlformat.format());
		return contractlineset.getMbo(0);
	}

	
   /**
    * @comment	Get the site mbo from site code
    * @author	LS
    * @function	getSiteMbo
    * @date		30 Jul 2007
    */
	private MboRemote getSiteMbo(String siteid)
		throws Exception
	{
		MboSetRemote siteset = mxserver.getMboSet("site", userInfo);
		SqlFormat sqlformat = new SqlFormat("siteid=:1");
		sqlformat.setObject(1, "site", "siteid", siteid);
		siteset.setWhere(sqlformat.format());
		return siteset.getMbo(0);
	}

	
   /**
	 * @comment	class used to manage groups of items that will be reordered together
	 * @author 	LS
	 * @date	26 Jul 2007
	 */
	private class ItemGroup
	{
		private HashMap grouping = null;
		// Initialize the HashMap
		ItemGroup()
		{
			//Begin Modification DR-062
			//grouping = new HashMap(128);
			//End Modification DR-062
			grouping = new HashMap(5000);
		}
   
		// Add a new ket / value to the group
		void add(String contract, String vendor, MboRemote mbo) throws RemoteException, MXException
		{
			//mxLog.writeLog("inside add***********************");
			/*
			 * Build key
			 * The key stays null when there's no vendor (ie also no contract)
			 * The key does not need to include the revision as only 1 contract revision is approved at any given time
			 */
			String triggerValue = mbo.getString("PSA_AUTOTRIGGERIND");

			String key = null;
			if (vendor != null)
				if (contract != null)
					key = contract + "|" + vendor + "|" + triggerValue;
				else
					key = "|" + vendor + "|" + triggerValue;
			
			// Add the value to the existing key if it exists, otherwise create it
			//mxLog.writeLog("key updated*********************"+key);
			ArrayList value = new ArrayList();
			// Get the existing item/desc values from the existing group if any
			if (grouping.containsKey(key))
				value = (ArrayList) grouping.get(key);
			value.add(mbo);
			grouping.put(key, value);	// replace the previous value if it existed
		}

		// Get all the keys
		Set keySet()
		{
			return grouping.keySet();
		}

		// Get the value of a key
		ArrayList get(String key)
		{
			return (ArrayList)grouping.get(key);
		}

		
	}

	
//	 CronTask Parameters
	protected static CrontaskParamInfo	params[];
		static
	{
		// Set the number of the parameter.
		params = null;
		
		params = new CrontaskParamInfo[4];

		// All the parameter configurable from Cron Task user interface
		params[0] = new CrontaskParamInfo();
		params[0].setName("emailto");
		//params[0].setDescription("Admin email address for notification of error.");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[0].setDescription("CommonCron","Adminemailaddress");
		//-- COMM-IT changed to make it compatible with Maximo 7 API

		params[1] = new CrontaskParamInfo();
		params[1].setName("alertemailsubj");
		//params[1].setDescription("Email Subject for the Alert Email.");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[1].setDescription("CommonCron","EmailSubject");
		//-- COMM-IT changed to make it compatible with Maximo 7 API

		params[2] = new CrontaskParamInfo();
		params[2].setName("logfile");
		//params[2].setDescription("Log Directory and Filename.");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[2].setDescription("CommonCron","LogDirectory");
		//-- COMM-IT changed to make it compatible with Maximo 7 API
		
		params[3] = new CrontaskParamInfo();
		params[3].setName("prdescription");
		//params[3].setDescription("Description of PR generated.");
		//++ COMM-IT changed to make it compatible with Maximo 7 API
		params[3].setDescription("CommonCron","DescriptionofPR");
		//-- COMM-IT changed to make it compatible with Maximo 7 API


	}

	
	// Email variables
	private MxEmail				email;
	private String				emailSubj;

	// Log variables
	private MXLogger			logger;
	private MxLog				mxLog;
	private String				logFilePath;

	// Other variables
	private String				prdesc;
	private String 				prdescLong; 
	private UserInfo			userInfo;
	private MXServer			mxserver;
	private static final long	NOACCESSCHECK	= MboConstants.NOACCESSCHECK;
}


/*
 * Modification history 26-07-07 LS SR-100 Reorder logic : 1 stock PR can have
 * several delivery locations per contract or vendor 05-03-08 HAM SR-100
 * Reordering process should not generate PR line for the item that has EOQ = 0
 * 13-03-08 HAM SR-100 Reorder will be applied when current balance is less than
 * or equal to Reorder point 10-07-08 HAM DR-062 Increase the initial capacity
 * of HashMap grouping from 128 to 5000 and set itemgroup = null to free hash
 * memory
 * 
 * 
 * package com.psa.app.inventory;
 * 
 * import java.rmi.RemoteException; import java.sql.ResultSet; import
 * java.sql.SQLException; import java.text.DateFormat; import
 * java.text.SimpleDateFormat; import java.util.ArrayList; import
 * java.util.Date; import java.util.HashMap; import java.util.Iterator; import
 * java.util.Properties; import java.util.Set; import java.util.StringTokenizer;
 * 
 * import psdi.app.inventory.InventoryRemote; import
 * psdi.app.pr.PRLineSetRemote; import psdi.app.pr.PRSetRemote; import
 * psdi.app.system.CrontaskInstanceRemote; import
 * psdi.app.system.CrontaskParamInfo; import
 * com.psa.custom.common.MboConstantsCustom; import
 * com.psa.custom.common.MxEmail; import com.psa.custom.ois.MxLog; import
 * psdi.mbo.DBShortcut; import psdi.mbo.MboConstants; import psdi.mbo.MboRemote;
 * import psdi.mbo.MboSet; import psdi.mbo.MboSetRemote; import
 * psdi.mbo.SqlFormat; import psdi.security.UserInfo; import
 * psdi.server.MXServer; import psdi.server.MaxVarServiceRemote; import
 * psdi.server.SimpleCronTask; import psdi.txn.MXTransaction; import
 * psdi.util.MXApplicationException; import psdi.util.MXException; import
 * psdi.util.logging.MXLogger; import psdi.util.logging.MXLoggerFactory;
 * 
 * public class ReorderCronStkCustom extends SimpleCronTask {
 * 
 *//**
	 * @comment Reset class variables
	 * @author LS
	 * @function ReorderCronStkCustom
	 * @date 26 Jul 2007
	 */
/*
 * public ReorderCronStkCustom() { logFilePath = null; userInfo = null; logger =
 * MXLoggerFactory.getLogger("maximo.application.INVENTOR"); emailSubj = null; }
 * 
 * 
 *//**
	 * @comment [Standard Cron Task Function]Initialize cron task
	 * @author LS
	 * @function init
	 * @date 26 Jul 2007
	 */
/*
 * public void init() throws MXException { super.init();
 * 
 * email = new MxEmail(); mxLog = new MxLog(); }
 * 
 * 
 *//**
	 * @comment [Standard Cron Task Function] Start cron task
	 * @author LS
	 * @function start
	 * @date 26 Jul 2007
	 */
/*
 * public void start() { try { logger.info(getName() + " Start"); if
 * (getSleepTime() < 10000) // Run only if next scheduled time is in less than
 * 10 sec { mxLog.writeLog("Starting crontask"); setSleepTime(0L); } else {
 * logger.info("SleepTime: " + getSleepTime()); logger.info(getName() +
 * " crontask not yet scheduled : stopping now"); } } catch (Exception e) {
 * logger.error(getName() + " " + e.getMessage(), e); } }
 * 
 * 
 *//**
	 * @comment [Standard Cron Task Function]Stop cron task
	 * @author LS
	 * @function stop
	 * @date 26 Jul 2007
	 */
/*
 * public void stop() { logger.info(getName() + " Stop"); if (mxLog.isEnabled())
 * { try { mxLog.writeLog("Stopping crontask"); mxLog.closeLogFile(); } catch
 * (Exception e) { logger.error(getName() + " " + e.getMessage(), e); } } }
 * 
 * 
 * 
 *//**
	 * @comment [Standard Cron Task Function] Set cron task instance
	 * @author LS
	 * @function setCrontaskInstance
	 * @date 26 Jul 2007
	 */
/*
 * public void setCrontaskInstance(CrontaskInstanceRemote
 * crontaskinstanceremote) { try {
 * super.setCrontaskInstance(crontaskinstanceremote); } catch (Exception e) {
 * logger.error(getName() + " " + e.getMessage(), e); } }
 * 
 * 
 *//**
	 * @comment [Standard Cron Task Function] Get the parameters from Cron Task.
	 * @author LS
	 * @function getParameters
	 * @date 26 Jul 2007
	 */
/*
 * public CrontaskParamInfo[] getParameters() throws MXException,
 * RemoteException { return params; }
 * 
 * 
 *//**
	 * @comment [Standard Cron Task Function]Perform the crontask action
	 * @author LS
	 * @function cronAction
	 * @date 26 Jul 2007
	 */
/*
 * public void cronAction() { try { logger.debug(getName() +
 * " Start of CronTask action"); readConfig(); if (!processData()) { // Email
 * for error String message = "Some data have problems. See log file " +
 * mxLog.getLogFilePath() + " for details"; email.send(emailSubj,
 * genEmail(message, "")); logger.info(getName() + " Email sent"); }
 * logger.debug(getName() + " End of CronTask action"); } catch (Exception e) {
 * String message = e.getMessage(); String stack = getStackTrace(e);
 * 
 * // Log error logger.error(getName() + " " + message, e);
 * mxLog.writeLog("ERROR " + message + "\n" + stack);
 * 
 * // Email for error email.send(emailSubj, genEmail(message, stack));
 * logger.info(getName() + " Email sent");
 * 
 * stop(); } }
 * 
 * 
 *//**
	 * @comment Execute the reorder
	 * @author LS
	 * @function processData
	 * @date 26 Jul 2007
	 */
/*
*//**
	 * @return
	 * @throws Exception
	 */
/*
 * private boolean processData() throws Exception { boolean noproblem = true;
 * 
 * 
 * Retrive all the Items to check
 * 
 * MboSetRemote itemList = mxserver.getMboSet("item", userInfo); SqlFormat
 * sqlformat = new
 * SqlFormat("EXISTS(SELECT 1 FROM inventory WHERE CATEGORY = 'STK' AND itemnum=item.itemnum AND itemsetid=item.itemsetid AND orderqty > 0) "
 * ); // SqlFormat sqlformat = new SqlFormat("ITEMNUM='TESTUR015'");
 * mxLog.writeLog("***ReorderCronStkCustom.processData > sqlformat ="
 * +sqlformat.format()); itemList.setWhere(sqlformat.format());
 * itemList.reset(); MboRemote item = null; boolean reorder = false; int
 * prcounter = 0; DBShortcut dbshortcut = new DBShortcut(); if
 * (!itemList.isEmpty()) { ItemGroup itemgroup = new ItemGroup();
 * 
 * mxLog.writeLog("-------------- Start ---------------");
 * 
 * try { dbshortcut.connect(userInfo.getConnectionKey());
 * 
 * for (int i = 0; (item = itemList.getMbo(i)) != null; i ++) { MboSetRemote
 * iteminv = item.getMboSet("REORDER_INVENTORY"); iteminv.setOrderBy("ITEMNUM");
 * MboRemote inv = null; System.out.
 * println("ReorderCronStkCustom.iteminv count ***********************"+iteminv.
 * count()); for (int j = 0; (inv = iteminv.getMbo(j)) != null && !reorder; j
 * ++) { String orgid = inv.getString("ORGID"); String itemnum =
 * inv.getString("ITEMNUM"); String location = inv.getString("LOCATION"); String
 * siteid = inv.getString("SITEID"); String itemsetid =
 * inv.getString("ITEMSETID"); int deliverytime = inv.getInt("DELIVERYTIME");
 * 
 * mxLog.writeLog("***ReorderCronStkCustom.iteminv ["+j+"]:orgid="+orgid+
 * ",itemnum="+itemnum+",location="+location+",siteid="+siteid+",itemsetid="+
 * itemsetid+",deliverytime="+deliverytime+",orderqty="+inv.getDouble("ORDERQTY"
 * ));
 * 
 * if(inv.getDouble("ORDERQTY") > 0.0) { double reserveqty = GetResvQty(orgid,
 * itemnum, location, siteid, itemsetid, deliverytime, dbshortcut); double
 * invbalqty = SumCurBal(itemnum, location, siteid, itemsetid, dbshortcut);
 * double winspqty = HoldCurBal(itemnum, siteid, dbshortcut); double curbal =
 * invbalqty + winspqty; double prqty = GetPRQty(itemnum, location, siteid,
 * itemsetid, dbshortcut); double poqty = GetPOQty(itemnum, location, siteid,
 * itemsetid, dbshortcut); double expqty = GetExpQty(itemnum, location, siteid,
 * itemsetid, deliverytime, dbshortcut);
 * //mxLog.writeLog("Item Num : "+itemnum+" Location : "
 * +location+" Current Balance : " + ((curbal + prqty + poqty) - reserveqty -
 * expqty) + "  ROP : " + inv.getDouble("MINLEVEL"));
 * 
 * //Begin Modification SR-100 //if(inv.getDouble("MINLEVEL") > (curbal + prqty
 * + poqty - reserveqty - expqty))
 * mxLog.writeLog("***ReorderCronStkCustom.MINLEVEL="+inv.getDouble(
 * "MINLEVEL")+", (curbal + prqty + poqty - reserveqty - expqty)"+(curbal +
 * prqty + poqty - reserveqty - expqty)); if(inv.getDouble("MINLEVEL") >=
 * (curbal + prqty + poqty - reserveqty - expqty)) //End Modification SR-100 {
 * reorder = true; } } }
 * 
 * inv = null; mxLog.writeLog("***ReorderCronStkCustom.reorder ="+reorder);
 * if(reorder) { mxLog.writeLog("Starting to reorder for item " +
 * iteminv.getMbo(0).getString("ITEMNUM")+". Current Count: " + (i+1)); for (int
 * k = 0; (inv = iteminv.getMbo(k)) != null; k ++) { // Begin Modification SR
 * 100 if(inv.getDouble("ORDERQTY") > 0.0) // End Modification SR 100 { String
 * contractnum = null; String vendor = null; String itemnum =null; itemnum =
 * inv.getString("ITEMNUM");
 * 
 * if(inv.getString("VENDOR") != null) vendor = inv.getString("VENDOR");
 * logger.debug(getName() + " Searching for a contract for item " + itemnum); //
 * Get the contract lines for this item
 * 
 * HashMap contractvendor = new HashMap(); //BCT sqlformat = new
 * SqlFormat(userInfo,
 * "SELECT c.contractnum, c.vendor FROM contract c, contractline cl WHERE cl.contractnum = c.contractnum AND cl.revisionnum = c.revisionnum AND cl.orgid = c.orgid AND c.status = 'APPR' AND c.startdate <= getDate() AND (c.enddate IS NULL OR c.enddate >= getDate()) AND cl.itemnum = :1"
 * ); sqlformat.setObject(1, "item", "itemnum", itemnum); ResultSet rs =
 * dbshortcut.executeQuery(sqlformat.format()); while (rs.next()) {
 * contractvendor.put(rs.getString("vendor"), rs.getString("contractnum")); }
 * rs.close();
 * 
 * 
 * Choose the approved contract among those found as follows : if no BA, don't
 * change anything if the vendor of a BA is the WP vendor, take this one
 * otherwise, take the 1st BA found
 * 
 * if (contractvendor.size() > 0) { if (contractvendor.containsKey(vendor))
 * contractnum = (String) contractvendor.get(vendor); else { Iterator iterator =
 * contractvendor.keySet().iterator(); vendor = (String) iterator.next();
 * contractnum = (String) contractvendor.get(vendor); } }
 * 
 * logger.debug(getName() + " Adding to the reorder list: " + itemnum + "/" +
 * inv.getString("location") + "\t-->\t" + contractnum + "/" + vendor);
 * mxLog.writeLog(getName() + " Adding to the reorder list: " + itemnum +
 * "/" + inv.getString("location") + "\t-->\t" + contractnum + "/" + vendor);
 * 
 * 
 * 
 * if(!inv.isNull("orderunit")) { mxLog.writeLog("Adding to the reorder list: "
 * + itemnum + "\t --> Location : "+ inv.getString("location")+"\t --> \t" +
 * contractnum + "/" + vendor); System.out.
 * println("ReorderCronStkCustom.after addvalue1 ***********************");
 * itemgroup.add(contractnum, vendor, inv); System.out.
 * println("ReorderCronStkCustom.after addvalue ***********************"); }
 * else mxLog.writeLog(itemnum + "/" + inv.getString("location")
 * +" is not added to the Reorder List due to Required Field Order Unit is Null"
 * );
 * 
 * } } } reorder = false; iteminv.close(); } } catch (SQLException sqle) {
 * sqle.printStackTrace(); String[] param = { ""+sqle.getErrorCode() }; throw
 * new MXApplicationException("system", "sql", param); } finally { try {
 * dbshortcut.close(); } catch (Exception e) { // Do nothing } }
 * 
 * mxLog.
 * writeLog("--------------ReorderCronStkCustom Start Creating PRs---------------"
 * );
 * 
 * 
 * Create 1 PR per group in itemgroup
 * 
 * PRSetRemote prset = (PRSetRemote)mxserver.getMboSet("PR", userInfo); //
 * Ensure that PR creation and WO update are part of the same DB transaction
 * (either both succeed or both fail) boolean mustsave = false; Set groups =
 * itemgroup.keySet(); if(groups!=null && groups.size()>0) {
 * mxLog.writeLog("ReorderCronStkCustom.groups size**************"+groups.
 * size()); } Iterator iterator = groups.iterator(); int maxprlines =
 * ((MaxVarServiceRemote)MXServer.getMXServer().lookup("MAXVARS")).getInt(
 * "MAXPRLINES", "PSAST"); String prnum = null; try {
 * dbshortcut.connect(userInfo.getConnectionKey()); while (iterator.hasNext()) {
 * MXTransaction mxtransaction = prset.getMXTransaction();
 * itemList.setMXTransaction(mxtransaction);
 * 
 * String group = (String)iterator.next();
 * mxLog.writeLog("ReorderCronStkCustom.group**************"+group); try {
 * ArrayList items = itemgroup.get(group);
 * mxLog.writeLog("ReorderCronStkCustom.items size**************"+items.size
 * ()); mxLog.writeLog("ReorderCronStkCustom.PR Size : "+items.size()); if
 * (items.size() > maxprlines) { MboRemote temp; ArrayList itemsbybatch = new
 * ArrayList(); ArrayList itemsbyitemnum = new ArrayList(); String lastitemnum =
 * ""; for (int j = 0; j < items.size(); j ++) { temp = (MboRemote)
 * items.get(j);
 * 
 * if (!temp.getString("ITEMNUM").equals(lastitemnum) && j != 0) { for(int k =
 * 0; k < itemsbyitemnum.size(); k++) { itemsbybatch.add((MboRemote)
 * itemsbyitemnum.get(k)); } itemsbyitemnum = new ArrayList(); }
 * 
 * lastitemnum = temp.getString("ITEMNUM");
 * 
 * if (temp.getString("ITEMNUM").equals(lastitemnum) || j == 0) {
 * itemsbyitemnum.add(temp); }
 * 
 * if (itemsbybatch.size() + itemsbyitemnum.size() >= maxprlines) { prnum =
 * null; prnum = generatePR(prset.add(), group, itemsbybatch, itemList,
 * dbshortcut); // Pass the Item set so that we can add inside the PR & PR line
 * prcounter ++; mustsave = true; itemsbybatch = new ArrayList(); } }
 * 
 * if (itemsbyitemnum.size() != 0) { for(int k = 0; k < itemsbyitemnum.size();
 * k++) itemsbybatch.add((MboRemote)itemsbyitemnum.get(k)); prnum = null; prnum
 * = generatePR(prset.add(), group, itemsbybatch, itemList, dbshortcut); // Pass
 * the Item set so that we can add inside the PR & PR line prcounter ++;
 * mustsave = true; } } else { prnum = null; prnum = generatePR(prset.add(),
 * group, items, itemList, dbshortcut); // Pass the Item set so that we can add
 * inside the PR & PR line prcounter ++; mustsave = true; } if (mustsave) {
 * mxtransaction.commit(); mxLog.writeLog("PR: " + prnum +
 * " successfully created"); } } catch (SQLException sqle) {
 * sqle.printStackTrace(); String[] param = { ""+sqle.getErrorCode() }; throw
 * new MXApplicationException("system", "sql", param); } catch (Exception e) {
 * String message = "Error during reorder stk cron task"; logger.warn(getName()
 * + " " + message + ". See log file for details"); mxLog.writeLog("|--" +
 * message + "\n" + e.getMessage() + "\n" + getStackTrace(e)); noproblem =
 * false; } } } catch (Exception e) { // Do nothing } finally { try {
 * dbshortcut.close(); } catch (Exception e) { // Do nothing } } //Begin
 * Modification DR-062 itemgroup = null; //End Modification DR-062 }
 * mxLog.writeLog("[ReorderCronStkCustom] Total : " + prcounter +
 * " PR created"); logger.info(getName() + " Total : " + prcounter +
 * " PR created"); mxLog.writeLog("Total : " + prcounter + " PR created");
 * 
 * mxLog.writeLog("-------------- End ---------------"); return noproblem; }
 * 
 * 
 *//**
	 * @comment Create the PR and call generatePRLine to create the lines
	 * @author LS
	 * @function generatePR
	 * @date 30 Jul 2007
	 */
/*
 * 
 * private String generatePR(MboRemote pr, String group, ArrayList iteminv,
 * MboSetRemote itemsetforupdate, DBShortcut dbshortcut) throws Exception,
 * SQLException { String contractnum = null; String vendor = null; String
 * vendorAndTriggerVal = null; String message = "Creating PR " +
 * pr.getString("prnum"); //Thirumal changes starts for Tender Ref No 5.2.42 if
 * (group != null) { int index = group.indexOf("|");
 * 
 * if (index > 0) contractnum = group.substring(0, index);
 * 
 * vendorAndTriggerVal = group.substring(index+1);
 * if(vendorAndTriggerVal!=null){ int vendorIndex =
 * vendorAndTriggerVal.indexOf("|"); if (vendorIndex > 0){ vendor =
 * vendorAndTriggerVal.substring(0, vendorIndex); }else if(vendorIndex <= 0){
 * vendor = vendorAndTriggerVal.substring(vendorIndex+1); } } message +=
 * " for contract="+contractnum+" vendor="+vendor; }
 * 
 * if (group != null) { String[] groupValues = group.split(":");
 * mxLog.writeLog("items size**************"+groupValues.length);
 * if(groupValues!=null && groupValues.length>0) { contractnum = groupValues[0];
 * mxLog.writeLog("contractnum**************"+contractnum); vendor =
 * groupValues[1]; mxLog.writeLog("vendor**************"+vendor); } message
 * += " for contract="+contractnum+" vendor="+vendor; } //Thirumal Changes ends
 * else message += " without contract nor vendor";
 * 
 * mxLog.writeLog("|--" + message);
 * mxLog.writeLog("ReorderCronStkCustom.vendor**************"+vendor);
 * mxLog.writeLog("ReorderCronStkCustom.contractnum**************"+
 * contractnum);
 * 
 * Populate values for the PR header
 * 
 * // Default values pr.setValue("buyahead", false, NOACCESSCHECK);
 * java.util.Date date = mxserver.getDate(); pr.setValue("changedate", date,
 * NOACCESSCHECK);
 * 
 * // Data related to the cron task pr.setValue("changeby",
 * userInfo.getPersonId(), MboConstants.NOACCESSCHECK);
 * 
 * // Data related to the work plan - any planned line will do for our purpose
 * since the data are common to all lines MboRemote inv =
 * (MboRemote)iteminv.get(0);
 * 
 * // prdesc = "ReorderCronStkCustom"; DateFormat fileDateFormat = new
 * SimpleDateFormat("d-MMM-yy HH:mm"); // Ex: 9-Feb-07 23:10 String runtime =
 * fileDateFormat.format(mxserver.getDate()); prdesc =
 * getParamAsString("prdescription").replaceFirst("yyyymmddhhmm", runtime);
 * 
 * prdescLong = null;
 * 
 * pr.setValue("description", prdesc);
 * pr.setValue("description_longdescription", prdescLong);
 * 
 * String siteid = inv.getString("siteid"); pr.setValue("siteid", siteid,
 * NOACCESSCHECK); String orgid = inv.getString("orgid"); pr.setValue("orgid",
 * orgid, NOACCESSCHECK);
 * 
 * if (vendor != null) pr.setValue("vendor", vendor);
 * 
 * logger.debug(getName() + " PR tab general data set");
 * 
 * // Data related to the contract MboRemote contract = null; if (contractnum !=
 * null) { contract = getContractMbo(contractnum); pr.setValue("contractrefid",
 * contract.getString("contractid"), NOACCESSCHECK);
 * pr.setValue("contractrefnum", contractnum, NOACCESSCHECK);
 * pr.setValue("contractrefrev", contract.getInt("revisionnum"), NOACCESSCHECK);
 * pr.setValue("currencycode", contract.getString("currencycode"),
 * NOACCESSCHECK); }
 * 
 * logger.debug(getName() + " PR data related to the contract set");
 * 
 * 
 * Data related to site This program assumes that at least the address codes are
 * populated for all sites, except MED
 * 
 * MboRemote site = getSiteMbo(siteid);
 * 
 * 
 * //Start -- Modified to suite Maximo 7.6 framework - Comm-IT //if
 * (site.isNull("shiptoaddresscode")) if(billtoShiptoShippingMbo != null) //End
 * -- Modified to suite Maximo 7.6 framework - Comm-IT { // Get the billto of
 * the site pointed by the prefix // WARNING - hard-code the logic to get the
 * site from the prefix String realsiteid = null; String store = null;
 * 
 * store = inv.getString("LOCATION");
 * 
 * int storeindex = store.indexOf("STORE");
 * 
 * if (storeindex > 0) realsiteid = store.substring(0, storeindex);
 * 
 * site = getSiteMbo(realsiteid); }
 * 
 * 
 * 
 * //Get Shipto Address from Storeroom - Change in logic - NextGen Maximo
 * MboRemote storeroomMbo = inv.getMboSet("STOREROOM").getMbo(0);
 * 
 * MboSetRemote billtoShiptoShippingMbo = site.getMboSet("BILLTOSHIPTO");
 * billtoShiptoShippingMbo.setWhere("ADDRESSCODE='"+storeroomMbo.getString(
 * "SHIPTOADDRESSCODE")+"'"); billtoShiptoShippingMbo.reset();
 * 
 * MboSetRemote billtoShiptoBillingMbo = site.getMboSet("BILLTOSHIPTO");
 * billtoShiptoBillingMbo.setWhere("ADDRESSCODE='"+storeroomMbo.getString(
 * "BILLTOADDRESSCODE")+"'"); billtoShiptoBillingMbo.reset();
 * 
 * 
 * if ((storeroomMbo != null)) { pr.setValue("billto",
 * storeroomMbo.getString("BILLTOADDRESSCODE"), 11L); pr.setValue("shipto",
 * storeroomMbo.getString("SHIPTOADDRESSCODE"), 11L); }
 * 
 * if ((pr.getString("shiptoattn").equals("")) &&
 * (billtoShiptoShippingMbo.getMbo(0) != null)) { if
 * (billtoShiptoShippingMbo.getMbo(0).getString("shiptocontact").equals(""))
 * pr.setValue("shiptoattn", userInfo.getPersonId()); else
 * pr.setValue("shiptoattn",
 * billtoShiptoShippingMbo.getMbo(0).getString("shiptocontact"), 11L); } if
 * ((pr.getString("billtoattn").equals("")) && (billtoShiptoBillingMbo.getMbo(0)
 * != null)) { if
 * (billtoShiptoBillingMbo.getMbo(0).getString("billtocontact").equals(""))
 * pr.setValue("billtoattn", userInfo.getPersonId()); else
 * pr.setValue("billtoattn",
 * billtoShiptoBillingMbo.getMbo(0).getString("billtocontact"), 11L); }
 * 
 * //Start -- Modified to suite Maximo 7.6 - Comm-IT
 * if(!site.isNull("billtoaddresscode")) pr.setValue("billto",
 * site.getString("billtoaddresscode")); if(!site.isNull("shiptoaddresscode"))
 * pr.setValue("shipto", site.getString("shiptoaddresscode"));
 * if(site.isNull("billtolaborcode")) pr.setValue("billtoattn",
 * userInfo.getPersonId()); else pr.setValue("billtoattn",
 * site.getString("billtolaborcode")); if(site.isNull("shiptolaborcode"))
 * pr.setValue("shiptoattn", userInfo.getPersonId()); else
 * pr.setValue("shiptoattn", site.getString("shiptolaborcode")); //End --
 * Modified to suite Maximo 7.6 - Comm-IT
 * 
 * logger.debug(getName() + " PR data related to shipt to... set");
 * 
 * Populate the PR lines
 * 
 * PRLineSetRemote prlineset = (PRLineSetRemote)pr.getMboSet("prline"); Iterator
 * iterator = iteminv.iterator(); while (iterator.hasNext()) { MboRemote invitem
 * = (InventoryRemote)iterator.next(); MboRemote prline = prlineset.add();
 * generatePRLine(prline, pr, invitem, contract, dbshortcut); }
 * 
 * inv = null; return pr.getString("prnum"); }
 * 
 * 
 *//**
	 * @comment Create a PR line
	 * @author LS
	 * @function generatePRLine
	 * @date 30 Jul 2007
	 */
/*
 * private void generatePRLine(MboRemote prline, MboRemote pr, MboRemote
 * invitem, MboRemote contract, DBShortcut dbshortcut) throws Exception,
 * SQLException { try { logger.debug(getName() +
 * " ReorderCronStkCustom.Adding PR line for item=" +
 * invitem.getString("itemnum"));
 * mxLog.writeLog("ReorderCronStkCustom.Adding PR line for item : " +
 * invitem.getString("itemnum") + "\t --> \t" + invitem.getString("LOCATION"));
 * 
 * String linetype = "ITEM";
 * 
 * // Set the long description // if
 * (!invitem.isNull("description_longdescription")) //
 * prline.setValue("description_longdescription",
 * invitem.getString("description_longdescription"));
 * 
 * // Set the order quantity from the WP double orderqty = 0; String orgid =
 * invitem.getString("ORGID"); String itemnum = invitem.getString("ITEMNUM");
 * String location = invitem.getString("LOCATION"); String siteid =
 * invitem.getString("SITEID"); String itemsetid =
 * invitem.getString("ITEMSETID"); int deliverytime =
 * invitem.getInt("DELIVERYTIME");
 * 
 * if(invitem.getDouble("ORDERQTY") > 0.0) { double reserveqty =
 * GetResvQty(orgid, itemnum, location, siteid, itemsetid, deliverytime,
 * dbshortcut); double invbalqty = SumCurBal(itemnum, location, siteid,
 * itemsetid, dbshortcut); double winspqty = HoldCurBal(itemnum, siteid,
 * dbshortcut); double curbal = invbalqty + winspqty; double prqty =
 * GetPRQty(itemnum, location, siteid, itemsetid, dbshortcut); double poqty =
 * GetPOQty(itemnum, location, siteid, itemsetid, dbshortcut); double expqty =
 * GetExpQty(itemnum, location, siteid, itemsetid, deliverytime, dbshortcut);
 * 
 * orderqty = invitem.getDouble("ORDERQTY"); //Begin Modification SR-100
 * //while(invitem.getDouble("MINLEVEL") > ((curbal + prqty + poqty - reserveqty
 * - expqty) + orderqty)) while(invitem.getDouble("MINLEVEL") >= ((curbal +
 * prqty + poqty - reserveqty - expqty) + orderqty)) //End Modification SR-100 {
 * orderqty = orderqty + invitem.getDouble("ORDERQTY"); } } siteid = null;
 * String store = null;
 * 
 * store = invitem.getString("LOCATION"); int storeindex =
 * store.indexOf("STORE"); if (storeindex > 0) siteid = store.substring(0,
 * storeindex);
 * 
 * MboRemote site = getSiteMbo(siteid);
 * 
 * 
 * 
 * Data must be set in this order : linetype, itemnum, wonum
 * 
 * prline.setValue("linetype", linetype, MboConstantsCustom.DBSET);
 * 
 * // Set the itemnum, condition code and description (if no itemnum) if
 * (invitem.isNull("itemnum")) { prline.setValue("description",
 * invitem.getString("description"), MboConstantsCustom.DBSET); } else {
 * prline.setValue("itemnum", invitem.getString("itemnum"));
 * 
 * if (!invitem.isNull("conditioncode")) prline.setValue("conditioncode",
 * invitem.getString("conditioncode")); else if
 * (linetype.equalsIgnoreCase("ITEM")) { // set by default the condition code
 * that's 100% MboRemote itemconditionfull =
 * invitem.getMboSet("ITEMCONDITION_FULL").getMbo(0); if (itemconditionfull !=
 * null) prline.setValue("conditioncode",
 * itemconditionfull.getString("conditioncode")); } }
 * 
 * //Set the storeloc after the itemnum is set in PR to support enhancement
 * UR-AP-PU-010 prline.setValue("storeloc", store, NOACCESSCHECK);
 * 
 * logger.debug(getName() + " Batch 1/3 of PR line data set");
 * prline.setValue("orderqty", orderqty, NOACCESSCHECK);
 * 
 * if (!invitem.isNull("orderunit")) prline.setValue("orderunit",
 * invitem.getString("orderunit"), NOACCESSCHECK);
 * 
 * if (!pr.isNull("contractrefnum")) { prline.setValue("contractrefnum",
 * pr.getString("contractrefnum"), MboConstantsCustom.DBSET);
 * prline.setValue("contractrefrev", pr.getString("contractrefrev"),
 * MboConstantsCustom.DBSET); MboRemote contractline =
 * getContractLineMbo(pr.getString("contractrefnum"),
 * pr.getString("contractrefrev"), invitem.getString("itemnum"));
 * prline.setValue("unitcost", contractline.getDouble("unitcost"),
 * MboConstantsCustom.DBSET); } else { prline.setValue("unitcost",
 * invitem.getMboSet("INVCOST").getMbo(0).getDouble("avgcost"),
 * MboConstantsCustom.DBSET); }
 * 
 * logger.debug(getName() + " Batch 2/3 of PR line data set");
 * 
 * 
 * //Start -- Modified to suite Maximo 7.6 framework - Comm-IT //MboRemote
 * billtoShiptoShippingMbo = site.getMboSet("SHIPTODEFAULT").getMbo(0);
 * 
 * //Get Shipto Address from Storeroom - Change in logic - NextGen Maximo
 * MboRemote storeroomMbo = invitem.getMboSet("STOREROOM").getMbo(0);
 * 
 * 
 * 
 * // Set the shipto of the PRLine //if (!site.isNull("shiptoaddresscode"))
 * if(storeroomMbo != null) //prline.setValue("shipto",
 * site.getString("shiptoaddresscode")); prline.setValue("shipto",
 * storeroomMbo.getString("SHIPTOADDRESSCODE"), 11L); //End -- Modified to suite
 * Maximo 7.6 framework - Comm-IT prline.setValue("conversion", 1,
 * NOACCESSCHECK);
 * 
 * // Default values prline.setValue("linecost2", 0, NOACCESSCHECK);
 * prline.setValue("mktplcitem", 0, NOACCESSCHECK);
 * 
 * logger.debug(getName() + " Batch 3/3 of PR line data set");
 * 
 * } catch(MXException mxexception) { mxexception.printStackTrace(); throw
 * mxexception; }
 * 
 * }
 * 
 *//**
	 * @comment Initialize class variables
	 * @author Ls
	 * @function SumCurBal
	 * @date 21 Aug 2007
	 */
/*
 * private double SumCurBal(String itemnum, String location, String siteid,
 * String itemsetid, DBShortcut dbshortcut) throws RemoteException, MXException,
 * SQLException { double curbal = 0.0; SqlFormat sqlformat = new
 * SqlFormat(userInfo,
 * "SELECT sum(CURBAL) AS CURBAL FROM invbalances invb WHERE invb.itemnum = :1 AND invb.location = :2 AND invb.siteid = :3 AND invb.itemsetid = :4"
 * ); sqlformat.setObject(1, "inventory", "itemnum", itemnum);
 * sqlformat.setObject(2, "inventory", "location", location);
 * sqlformat.setObject(3, "inventory", "siteid", siteid); sqlformat.setObject(4,
 * "inventory", "itemsetid", itemsetid);
 * mxLog.writeLog("***ReorderCronStkCustom.SumCurBal.sqlformat="+sqlformat.
 * format()); ResultSet rs = dbshortcut.executeQuery(sqlformat.format()); if
 * (rs.next()) { curbal = rs.getDouble("CURBAL"); } rs.close(); return curbal; }
 * 
 *//**
	 * @comment Initialize class variables
	 * @author Ls
	 * @function HoldCurBal
	 * @date 21 Aug 2007
	 */
/*
 * private double HoldCurBal(String itemnum, String siteid, DBShortcut
 * dbshortcut) throws RemoteException, MXException, SQLException { double
 * winspqty = 0.0; SqlFormat sqlformat = new SqlFormat(userInfo,
 * "SELECT sum(mrt.QUANTITY - mrt.REJECTQTY) AS WINSPQTY FROM matrectrans mrt WHERE mrt.itemnum=:1 AND mrt.tostoreloc=(SELECT location FROM locations WHERE TYPE='HOLDING' AND siteid=:2) AND mrt.status='WINSP' AND mrt.siteid=:2"
 * ); sqlformat.setObject(1, "inventory", "itemnum", itemnum);
 * sqlformat.setObject(2, "inventory", "siteid", siteid);
 * mxLog.writeLog("***ReorderCronStkCustom.HoldCurBal.sqlformat="+sqlformat.
 * format()); ResultSet rs = dbshortcut.executeQuery(sqlformat.format()); if
 * (rs.next()) { winspqty = rs.getDouble("WINSPQTY"); } rs.close(); return
 * winspqty; }
 * 
 *//**
	 * @comment Initialize class variables
	 * @author Ls
	 * @function HoldCurBal
	 * @date 21 Aug 2007
	 */
/*
 * private double GetResvQty(String orgid, String itemnum, String location,
 * String siteid, String itemsetid, int deliverytime, DBShortcut dbshortcut)
 * throws RemoteException, MXException, SQLException { double resvqty = 0.0;
 * SqlFormat sqlformat = new SqlFormat(userInfo,
 * "SELECT sum(RESERVEDQTY) AS RESERVEDQTY FROM invreserve invr WHERE invr.orgid = :1 AND invr.storelocsiteid = :2 AND invr.itemnum = :3 AND invr.itemsetid = :4 AND invr.location = :5 AND invr.directreq = 0 AND invr.requireddate <= getDate() + :6 "
 * ); sqlformat.setObject(1, "inventory", "orgid", orgid);
 * sqlformat.setObject(2, "inventory", "siteid", siteid); sqlformat.setObject(3,
 * "inventory", "itemnum", itemnum); sqlformat.setObject(4, "inventory",
 * "itemsetid", itemsetid); sqlformat.setObject(5, "inventory", "location",
 * location); sqlformat.setInt(6, deliverytime);
 * mxLog.writeLog("***ReorderCronStkCustom.GetResvQty.sqlformat="+sqlformat.
 * format()); ResultSet rs = dbshortcut.executeQuery(sqlformat.format()); if
 * (rs.next()) { resvqty = rs.getDouble("RESERVEDQTY"); } rs.close(); return
 * resvqty; }
 * 
 *//**
	 * @comment Initialize class variables
	 * @author Ls
	 * @function GetPRQty
	 * @date 27 Aug 2007
	 */
/*
 * private double GetPRQty(String itemnum, String location, String siteid,
 * String itemsetid, DBShortcut dbshortcut) throws RemoteException, MXException,
 * SQLException { double prqty = 0.0; SqlFormat sqlformat = new
 * SqlFormat(userInfo,
 * "SELECT sum(prl.ORDERQTY) AS PRQTY FROM prline prl, pr WHERE prl.storeloc = :2 AND prl.itemnum = :1 AND prl.siteid = :3 AND prl.itemsetid = :4 AND prl.prnum = pr.prnum AND prl.siteid = pr.siteid AND prl.issue = 0 AND prl.ponum IS NULL AND pr.status IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='PRSTATUS' AND MAXVALUE IN ('WAPPR', 'APPR')) AND pr.historyflag=0"
 * ); sqlformat.setObject(1, "inventory", "itemnum", itemnum);
 * sqlformat.setObject(2, "inventory", "location", location);
 * sqlformat.setObject(3, "inventory", "siteid", siteid); sqlformat.setObject(4,
 * "inventory", "itemsetid", itemsetid);
 * mxLog.writeLog("***ReorderCronStkCustom.GetPRQty.sqlformat="+sqlformat.
 * format()); ResultSet rs = dbshortcut.executeQuery(sqlformat.format()); if
 * (rs.next()) { prqty = rs.getDouble("PRQTY"); } rs.close(); return prqty; }
 * 
 *//**
	 * @comment Initialize class variables
	 * @author Ls
	 * @function GetPOQty
	 * @date 27 Aug 2007
	 */
/*
 * private double GetPOQty(String itemnum, String location, String siteid,
 * String itemsetid, DBShortcut dbshortcut) throws RemoteException, MXException,
 * SQLException { double poqty = 0.0; //PO Revision number included in the query
 * - Maximo 7.6 SqlFormat sqlformat = new SqlFormat(userInfo,
 * "SELECT sum(pol.ORDERQTY - isnull(pol.RECEIVEDQTY, 0)) AS POQTY FROM poline pol, po WHERE pol.storeloc = :2 AND pol.itemnum = :1 AND pol.itemsetid = :4 AND pol.siteid = :3 AND pol.ponum = po.ponum AND pol.revisionnum = po.revisionnum AND pol.siteid = po.siteid AND pol.RECEIPTSCOMPLETE = 0 AND pol.issue = 0 AND (pol.orderqty > pol.receivedqty OR pol.receivedqty IS NULL) AND po.status IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='POSTATUS' AND MAXVALUE IN ('WAPPR', 'APPR', 'INPRG')) AND po.potype IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID='POTYPE' AND MAXVALUE IN ('STD', 'REL', 'CHG')) AND po.historyflag=0"
 * ); sqlformat.setObject(1, "inventory", "itemnum", itemnum);
 * sqlformat.setObject(2, "inventory", "location", location);
 * sqlformat.setObject(3, "inventory", "siteid", siteid); sqlformat.setObject(4,
 * "inventory", "itemsetid", itemsetid);
 * mxLog.writeLog("***ReorderCronStkCustom.GetPOQty.sqlformat="+sqlformat.
 * format()); ResultSet rs = dbshortcut.executeQuery(sqlformat.format()); if
 * (rs.next()) { poqty = rs.getDouble("POQTY"); } rs.close(); return poqty; }
 * 
 *//**
	 * @comment Initialize class variables
	 * @author Ls
	 * @function GetPOQty
	 * @date 27 Aug 2007
	 */
/*
 * private double GetExpQty(String itemnum, String location, String siteid,
 * String itemsetid, int deliverytime, DBShortcut dbshortcut) throws
 * RemoteException, MXException, SQLException { double expqty = 0.0; SqlFormat
 * sqlformat = new SqlFormat(userInfo,
 * "SELECT sum(invb.CURBAL) AS EXPQTY FROM invlot invl, invbalances invb WHERE invl.itemnum = :1 AND invl.location = :2 AND invl.siteid = :3 AND invl.itemsetid = :4 AND invl.useby < getDate() + :5 AND invb.itemnum = invl.itemnum AND invb.location = invl.location AND invb.lotnum = invl.lotnum AND invb.siteid=invl.siteid AND invb.itemsetid = invl.itemsetid"
 * ); sqlformat.setObject(1, "inventory", "itemnum", itemnum);
 * sqlformat.setObject(2, "inventory", "location", location);
 * sqlformat.setObject(3, "inventory", "siteid", siteid); sqlformat.setObject(4,
 * "inventory", "itemsetid", itemsetid); sqlformat.setInt(5, deliverytime);
 * mxLog.writeLog("***ReorderCronStkCustom.GetExpQty.sqlformat="+sqlformat.
 * format()); ResultSet rs = dbshortcut.executeQuery(sqlformat.format()); if
 * (rs.next()) { expqty = rs.getDouble("EXPQTY"); } rs.close(); return expqty; }
 * 
 * 
 *//**
	 * @comment Initialize class variables
	 * @author Ls
	 * @function readConfig
	 * @date 26 Jul 2007
	 */
/*
 * private void readConfig() throws RemoteException, MXException { mxserver =
 * MXServer.getMXServer(); userInfo = getRunasUserInfo();
 * 
 * // PR description DateFormat fileDateFormat = new
 * SimpleDateFormat("d-MMM-yyyy HH:mm"); // Ex: 9-Feb-07 23:10 String runtime =
 * fileDateFormat.format(mxserver.getDate());
 * 
 * // Log file logFilePath = getParamAsString("logfile"); if (logFilePath !=
 * null) { logFilePath = logFilePath.trim(); if (logFilePath.equals(""))
 * logFilePath = null; else { fileDateFormat = new
 * SimpleDateFormat("yyMMddHHmm"); runtime =
 * fileDateFormat.format(mxserver.getDate()); logFilePath =
 * logFilePath.replaceAll("yyyymmddhhmm", runtime); mxLog.setEnabled(true);
 * mxLog.setLogFilePath(logFilePath); mxLog.setLogTag(getName()); try {
 * mxLog.createLogFile(); } catch (Exception e) { logger.error(getName() + " " +
 * e.getMessage(), e); } } }
 * 
 * // Email email.setToMail(getParamAsString("emailto")); Properties properties
 * = mxserver.getConfig();
 * email.setFromMail(properties.getProperty("mxe.adminEmail", null)); emailSubj
 * = getParamAsString("alertemailsubj"); }
 * 
 * 
 *//**
	 * @comment Generate email message from an error
	 * @author LS
	 * @function genEmail
	 * @date 26 Jul 2007
	 */
/*
 * private String genEmail(String error, String stack) { String emailMsg =
 * "Date: " + new Date() + "\n" + "Error Message: " + error + "\n" + stack;
 * return emailMsg; }
 * 
 * 
 *//**
	 * @comment Get the error stack trace into a String
	 * @author LS
	 * @function getStackTrace
	 * @date 26 Jul 2007
	 */
/*
 * private String getStackTrace(Exception e) { String stack = "";
 * StackTraceElement element[] = e.getStackTrace(); for (int i = 0; i <
 * element.length; i++) stack += "\tat " + element[i].toString() + "\n"; return
 * stack; }
 * 
 * 
 *//**
	 * @comment Get the approved contract mbo from a contract number
	 * @author LS
	 * @function getContractMbo
	 * @date 30 Jul 2007
	 */
/*
 * private MboRemote getContractMbo(String contractnum) throws Exception {
 * MboSetRemote contractset = mxserver.getMboSet("contract", userInfo);
 * SqlFormat sqlformat = new SqlFormat("contractnum=:1 AND status='APPR'");
 * sqlformat.setObject(1, "contract", "contractnum", contractnum);
 * contractset.setWhere(sqlformat.format()); return contractset.getMbo(0); }
 * 
 * 
 *//**
	 * @comment Get the contractline mbo from a contract number and itemnum
	 * @author LS
	 * @function getContractLineMbo
	 * @date 30 Jul 2007
	 */
/*
 * private MboRemote getContractLineMbo(String contractnum, String revisionnum,
 * String itemnum) throws Exception { MboSetRemote contractlineset =
 * mxserver.getMboSet("contractline", userInfo); SqlFormat sqlformat = new
 * SqlFormat("contractnum=:1 AND revisionnum=:2 AND itemnum=:3");
 * sqlformat.setObject(1, "contractline", "contractnum", contractnum);
 * sqlformat.setObject(2, "contractline", "revisionnum", revisionnum);
 * sqlformat.setObject(3, "contractline", "itemnum", itemnum);
 * contractlineset.setWhere(sqlformat.format()); return
 * contractlineset.getMbo(0); }
 * 
 * 
 *//**
	 * @comment Get the site mbo from site code
	 * @author LS
	 * @function getSiteMbo
	 * @date 30 Jul 2007
	 */
/*
 * private MboRemote getSiteMbo(String siteid) throws Exception { MboSetRemote
 * siteset = mxserver.getMboSet("site", userInfo); SqlFormat sqlformat = new
 * SqlFormat("siteid=:1"); sqlformat.setObject(1, "site", "siteid", siteid);
 * siteset.setWhere(sqlformat.format()); return siteset.getMbo(0); }
 * 
 * 
 *//**
	 * @comment class used to manage groups of items that will be reordered together
	 * @author LS
	 * @date 26 Jul 2007
	 *//*
		 * private class ItemGroup { private HashMap grouping = null; // Initialize the
		 * HashMap ItemGroup() { //Begin Modification DR-062 //grouping = new
		 * HashMap(128); //End Modification DR-062 grouping = new HashMap(5000); }
		 * 
		 * // Add a new ket / value to the group void add(String contract, String
		 * vendor, MboRemote mbo) throws RemoteException, MXException {
		 * mxLog.writeLog("inside add***********************");
		 * 
		 * Build key The key stays null when there's no vendor (ie also no contract) The
		 * key does not need to include the revision as only 1 contract revision is
		 * approved at any given time
		 * 
		 * String triggerValue = mbo.getString("PSA_AUTOTRIGGERIND");
		 * 
		 * String key = null; if (vendor != null) if (contract != null) key = contract +
		 * "|" + vendor + "|" + triggerValue; else key = "|" + vendor + "|" +
		 * triggerValue;
		 * 
		 * // Add the value to the existing key if it exists, otherwise create it
		 * mxLog.writeLog("key updated*********************"+key); ArrayList value =
		 * new ArrayList(); // Get the existing item/desc values from the existing group
		 * if any if (grouping.containsKey(key)) value = (ArrayList) grouping.get(key);
		 * value.add(mbo); grouping.put(key, value); // replace the previous value if it
		 * existed }
		 * 
		 * // Get all the keys Set keySet() { return grouping.keySet(); }
		 * 
		 * // Get the value of a key ArrayList get(String key) { return
		 * (ArrayList)grouping.get(key); }
		 * 
		 * 
		 * }
		 * 
		 * 
		 * // CronTask Parameters protected static CrontaskParamInfo params[]; static {
		 * // Set the number of the parameter. params = null;
		 * 
		 * params = new CrontaskParamInfo[4];
		 * 
		 * // All the parameter configurable from Cron Task user interface params[0] =
		 * new CrontaskParamInfo(); params[0].setName("emailto");
		 * //params[0].setDescription("Admin email address for notification of error.");
		 * //++ COMM-IT changed to make it compatible with Maximo 7 API
		 * params[0].setDescription("CommonCron","Adminemailaddress"); //-- COMM-IT
		 * changed to make it compatible with Maximo 7 API
		 * 
		 * params[1] = new CrontaskParamInfo(); params[1].setName("alertemailsubj");
		 * //params[1].setDescription("Email Subject for the Alert Email."); //++
		 * COMM-IT changed to make it compatible with Maximo 7 API
		 * params[1].setDescription("CommonCron","EmailSubject"); //-- COMM-IT changed
		 * to make it compatible with Maximo 7 API
		 * 
		 * params[2] = new CrontaskParamInfo(); params[2].setName("logfile");
		 * //params[2].setDescription("Log Directory and Filename."); //++ COMM-IT
		 * changed to make it compatible with Maximo 7 API
		 * params[2].setDescription("CommonCron","LogDirectory"); //-- COMM-IT changed
		 * to make it compatible with Maximo 7 API
		 * 
		 * params[3] = new CrontaskParamInfo(); params[3].setName("prdescription");
		 * //params[3].setDescription("Description of PR generated."); //++ COMM-IT
		 * changed to make it compatible with Maximo 7 API
		 * params[3].setDescription("CommonCron","DescriptionofPR"); //-- COMM-IT
		 * changed to make it compatible with Maximo 7 API
		 * 
		 * 
		 * }
		 * 
		 * 
		 * // Email variables private MxEmail email; private String emailSubj;
		 * 
		 * // Log variables private MXLogger logger; private MxLog mxLog; private String
		 * logFilePath;
		 * 
		 * // Other variables private String prdesc; private String prdescLong; private
		 * UserInfo userInfo; private MXServer mxserver; private static final long
		 * NOACCESSCHECK = MboConstants.NOACCESSCHECK; }
		 */