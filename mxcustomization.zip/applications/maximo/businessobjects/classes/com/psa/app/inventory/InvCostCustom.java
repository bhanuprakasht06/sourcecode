/**
 * @author	HCHA
 * Date		Oct 12, 2006
 * Comment	 
 */
package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.InvCost;
import psdi.app.inventory.InvCostRemote;
import psdi.mbo.MboSet;
import psdi.util.MXException;

/**
 * @author		HCHA
 * @class		InvCostCustom
 * @date		Oct 12, 2006
 * @function	
 */
public class InvCostCustom extends InvCost 
	implements InvCostRemote 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double accReceiptQty;
	
	/**
	 * @param arg0
	 * @throws MXException
	 * @throws RemoteException
	 */
	public InvCostCustom(MboSet arg0) 
		throws MXException, RemoteException 
	{
		super(arg0);
		accReceiptQty = 0.0D;
	}

    void increaseAccumulativeReceiptQty(final double d)
	    throws MXException, RemoteException
	{
	    //super.increaseAccumulativeReceiptQty(d);
    	accReceiptQty = accReceiptQty + d;
	}
    
	public double getAccumulativeReceiptQty()
	{
		return accReceiptQty;
	}
	
}
