/*
 * Modification history
 * 02-05-07	LS	SR-071	Blank the Vendor and Contract for the PR and its PRLINE
 */

package com.psa.app.pr;

import java.rmi.RemoteException;

import psdi.app.pr.PRLineRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public class BlankPRContractCustom 
implements ActionCustomClass
{
public BlankPRContractCustom() 
{
}

public void applyCustomAction(MboRemote mboremote, Object aobj[])
throws MXException, RemoteException
{
	if(mboremote == null)
		return;
	
	String billto = mboremote.getString("billto");
	String billtoattn = mboremote.getString("billtoattn");
	
	/* Set the contract and vendor of the PR to null*/
	mboremote.setValueNull("vendor", 2L);
	mboremote.setValueNull("contractrefnum", 2L);
	mboremote.setValueNull("contractrefrev", 2L);
	
	MboRemote localmboremote = mboremote;
	MboSetRemote prlineset = localmboremote.getMboSet("PRLINE");
	int i = 0;
//	System.out.println("[PRLineRequestbyCustom]PRNUM: " + mboremote.getString("prnum"));
	/* Get the PRLines from the PR */ 
	for (PRLineRemote prline; (prline = (PRLineRemote) prlineset.getMbo(i)) != null; i++)
	{
//		System.out.println("[PRLineRequestbyCustom]PRLINENUM: " + prline.getString("prlinenum"));
		/* Set the contract of the PRLine to null*/
		prline.setValueNull("contractrefnum", 2L);
		prline.setValueNull("contractrefrev", 2L);
	}
	
	mboremote.setValue("billto", billto, 2L);
	mboremote.setValue("billtoattn", billtoattn, 2L);
}
}
