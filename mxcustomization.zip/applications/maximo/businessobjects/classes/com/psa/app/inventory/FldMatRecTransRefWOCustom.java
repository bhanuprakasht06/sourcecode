package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.FldMatRecTransRefWO;
import psdi.mbo.Mbo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldMatRecTransRefWOCustom extends FldMatRecTransRefWO {

	public FldMatRecTransRefWOCustom(MboValue arg0) 
		throws MXException, RemoteException 
	{
		super(arg0);
	}

	public void action()
    	throws MXException, RemoteException
    {
		super.action();
		
		Mbo mbo = getMboValue().getMbo();
		double totalhrs = 0;
		
//		System.out.println("[FldMatRecTransRefWOCustom] mbo name: " + mbo.getName());
//	    System.out.println("[FldMatRecTransRefWOCustom] refwo: " + mbo.getString("REFWO"));
//	    System.out.println("[FldMatRecTransRefWOCustom] positeid: " + mbo.getString("POSITEID"));
//	    System.out.println("[FldMatRecTransRefWOCustom] ponum: " + mbo.getString("PONUM"));
//	    System.out.println("[FldMatRecTransRefWOCustom] polinenum: " + mbo.getString("POLINENUM"));
	    
	    MboSetRemote wointerruptset = mbo.getMboSet("LDWOINTERRUPT");
	    
//	    System.out.println("[FldMatRecTransRefWOCustom] wointerrupt count: " + wointerruptset.count());
//		System.out.println("[FldMatRecTransRefWOCustom] Totalhrs: " + totalhrs);
//		System.out.println("[FldMatRecTransRefWOCustom] Set Name: " + wointerruptset.getName());
//		System.out.println("[FldMatRecTransRefWOCustom] Where: " + wointerruptset.getWhere());

		totalhrs = wointerruptset.sum("INTERRUPTHRS")/24;
		
//		System.out.println("[FldMatRecTransRefWOCustom] Totalhrs: " + totalhrs);
//		System.out.println("[FldMatRecTransRefWOCustom] Exit");
		mbo.setValue("WOINTERRUPT",totalhrs, 11L);

    }
}
