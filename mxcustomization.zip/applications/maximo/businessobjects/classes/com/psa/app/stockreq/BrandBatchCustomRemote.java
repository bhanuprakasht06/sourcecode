/*
 * Modification history
 * 27-05-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.*;
import psdi.mbo.*;
import psdi.util.*;

public interface BrandBatchCustomRemote extends MboRemote 
{
	public abstract void init()
        throws MXException, RemoteException;

}
