/*
 * Modification history
 * 13-01-2014	WMJ	EMS-666	[LABTRANS]SRADHOCWF Exception when routing a monitored equipment to confirm completion
 */

package com.psa.app.labor;

import java.rmi.RemoteException;

import psdi.app.labor.virtual.FldLabTransStartTimeNP;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldLabTransStartTimeCustom extends FldLabTransStartTimeNP
{
        public FldLabTransStartTimeCustom(MboValue arg0)
        {
                super(arg0);
        }

        public void validate()
        throws MXException, RemoteException
    	{
	    	super.validate();

                if (!(getMboValue().isNull()))
                {
                        LabTransCustom labtrans = (LabTransCustom)getMboValue().getMbo();

                        //if (!(labtrans.isNull("startdate")))
                        //{
	                        if(!labtrans.isNull("PSA_OT_FLAG"))
	            			{
                                boolean otflag = labtrans.getBoolean("PSA_OT_FLAG");
                                //System.out.println("[DEBUG] OT FLAG from FldLabTransStartTimeCustom.validate() :-> " + otflag);

                                if (otflag)
                                {
                                        //System.out.println("[DEBUG] Proccess OT OverLap Validate Start");
                                        labtrans.checkOverlapForOTField(true);
                                        //System.out.println("[DEBUG] Proccess OT OverLap Validate End");
                                }
                                else if(!otflag)
                                {
	                                
                                	if(!(labtrans.isNull("startdate")) && !(labtrans.isNull("starttime")) && !(labtrans.isNull("finishdate")) && !(labtrans.isNull("finishtime")))
                                	{
                                        //labtrans.checkOverlapForField(true);
                                        labtrans.checkOverlap();
                                	}
                            	}
                        	}
                        //}
                }

                

    }
}
