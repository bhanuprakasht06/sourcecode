/*
 * Modification history
 * 17-10-2007	AGD	eRFQ	Creation
 * 19-01-2009	HMD	DR 66	Set Close Date to NULL with NO VALIDATION, NO ACCESSCHECK & NO ACTION;
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.common.action.ActionCustomClass;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;


public class ReopenRFQCustom
implements ActionCustomClass
{

public ReopenRFQCustom()
{
}


public void applyCustomAction(MboRemote rfq, Object param[])
	throws MXException, RemoteException
{
MboSetRemote quotationset = rfq.getMboSet("QUOTATIONLINEALL");
//Delete all the Quotations for this RFQ
quotationset.deleteAll(MboConstantsCustom.DBSET);

//Set the Deadline to current date + Opening Duration and set ReOpened RFQ Flag to true
/*
GregorianCalendar deadline = new GregorianCalendar();
deadline.setGregorianChange(MXServer.getMXServer().getDate());
deadline.add(Calendar.DATE, rfq.getInt("OPENDURATION"));

rfq.setValue("CLOSEONDATE",deadline.getTime(),MboConstantsCustom.DBSET);
*/
//Begin Modification DR 66
//rfq.setValueNull("CLOSEONDATE");
rfq.setValueNull("CLOSEONDATE",MboConstantsCustom.DBSET);
//End Modification DR 66
rfq.setValue("REOPENEDRFQ",true,MboConstantsCustom.DBSET);

//Set Total Quotation Amont and Awarded Amount of each Vendor to Null
MboSetRemote rfqvendorset = MXServer.getMXServer().getMboSet("RFQVENDOR", rfq.getUserInfo());
SqlFormat sql = new SqlFormat("rfqnum=:1 AND siteid=:2");
sql.setObject(1, "rfqvendor", "rfqnum", rfq.getString("rfqnum"));
sql.setObject(2, "rfqvendor", "siteid", rfq.getString("siteid"));
System.out.println("SQL Output"+sql);
rfqvendorset.setWhere(sql.format());
//rfqvendorset.reset();


int i=0;
for(MboRemote rfqvendor = null; (rfqvendor=rfqvendorset.getMbo(i)) != null;i++)
{
	
	rfqvendor.setValueNull("TOTALQUOTATIONAMT",MboConstantsCustom.DBSET);
	rfqvendor.setValueNull("TOTALAWARDAMT", MboConstantsCustom.DBSET);
	
}

quotationset.save();
//System.out.println("Inside Reopen RFQ Custom");
rfqvendorset.save();//EMS-579
//System.out.println("Inside Reopen RFQ Custom 1");
rfq.getThisMboSet().save();
rfqvendorset.close();//EMS-579


}
}
