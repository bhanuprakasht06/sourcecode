package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.inventory.InvBalancesRemote;
import psdi.app.inventory.InvBalancesSetRemote;
import psdi.app.inventory.InventoryRemote;
import psdi.app.inventory.InventorySetRemote;
import psdi.app.location.LocationRemote;
import psdi.app.location.LocationSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class RecondUtilCustom
{

	public RecondUtilCustom() 
	{
	}

	public String getTransitStoreLoc(String siteid)
	{
		return siteid.concat("TRANSIT");
	}
	
	public String getRecondStoreLoc(String storeloc)
	{
		return storeloc.substring(0, storeloc.indexOf("STORE")).concat("RECOND");
	}
	
	public String getNormalStoreLoc(String recondstoreloc)
	{
		return recondstoreloc.substring(0, recondstoreloc.indexOf("RECOND")).concat("STORE");
	}
	
	public String getScrapStoreLoc(String recondstoreloc)
	{
		return recondstoreloc.substring(0, recondstoreloc.indexOf("RECOND")).concat("SCRAP");
	}
	
	public double getCurBal(MboRemote mboremote, String itemnum, String itemsetid, String storeloc, String siteid , String binnum)
	throws MXException, RemoteException
	{
		InvBalancesSetRemote invbalancessetremote = (InvBalancesSetRemote) MXServer.getMXServer().getMboSet("INVBALANCES", mboremote.getUserInfo());
        SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "itemnum = :1 and itemsetid = :2 and location = :3 and siteid = :4 and binnum = :5 and conditioncode='RECOND'");
        sqlformat.setObject(1, "INVENTORY", "ITEMNUM", itemnum);
        sqlformat.setObject(2, "INVENTORY", "ITEMSETID", itemsetid);
        sqlformat.setObject(3, "INVENTORY", "LOCATION", storeloc);
        sqlformat.setObject(4, "INVENTORY", "SITEID", siteid);
        sqlformat.setObject(5, "INVENTORY", "BINNUM", binnum);
        invbalancessetremote.setWhere(sqlformat.format());
        System.out.println("*** RecondUtilCustom a sql:"+sqlformat.format());
        		
        InvBalancesRemote invbalancesremote;
        if((invbalancesremote = (InvBalancesRemote) invbalancessetremote.getMbo(0)) != null) 
        {
        	double curbal = invbalancesremote.getDouble("CURBAL");
        	System.out.println("*** RecondUtilCustom a curbal:"+curbal);
        	invbalancessetremote.close();
        	return curbal;
        }
        else
		{
			invbalancessetremote.close();
			Object obj[] = {
					storeloc
			};
			throw new MXApplicationException("workorder", "NoInv", obj);
		}
	}
	
	public String getBin(MboRemote mboremote, String itemnum, String itemsetid, String storeloc, String siteid)
	throws MXException, RemoteException
	{
		InvBalancesSetRemote invbalancessetremote = (InvBalancesSetRemote) MXServer.getMXServer().getMboSet("INVBALANCES", mboremote.getUserInfo());
        SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "itemnum = :1 and itemsetid = :2 and location = :3 and siteid = :4 and conditioncode='RECOND'");
        sqlformat.setObject(1, "INVENTORY", "ITEMNUM", itemnum);
        sqlformat.setObject(2, "INVENTORY", "ITEMSETID", itemsetid);
        sqlformat.setObject(3, "INVENTORY", "LOCATION", storeloc);
        sqlformat.setObject(4, "INVENTORY", "SITEID", siteid);
        invbalancessetremote.setWhere(sqlformat.format());
        
        InvBalancesRemote invbalancesremote;
        if((invbalancesremote = (InvBalancesRemote) invbalancessetremote.getMbo(0)) != null) 
        {
        	String binnum = invbalancesremote.getString("BINNUM");
        	invbalancessetremote.close();
        	return binnum;
        }
        else
		{
			invbalancessetremote.close();
			Object obj[] = {
					storeloc
			};
			throw new MXApplicationException("workorder", "NoInv", obj);
		}
	}
	
	public String getLot(MboRemote mboremote, String itemnum, String itemsetid, String storeloc, String siteid)
			throws MXException, RemoteException
			{
				InvBalancesSetRemote invbalancessetremote = (InvBalancesSetRemote) MXServer.getMXServer().getMboSet("INVBALANCES", mboremote.getUserInfo());
		        SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "itemnum = :1 and itemsetid = :2 and location = :3 and siteid = :4 and conditioncode='RECOND'");
		        sqlformat.setObject(1, "INVENTORY", "ITEMNUM", itemnum);
		        sqlformat.setObject(2, "INVENTORY", "ITEMSETID", itemsetid);
		        sqlformat.setObject(3, "INVENTORY", "LOCATION", storeloc);
		        sqlformat.setObject(4, "INVENTORY", "SITEID", siteid);
		        invbalancessetremote.setWhere(sqlformat.format());
		        
		        InvBalancesRemote invbalancesremote;
		        if((invbalancesremote = (InvBalancesRemote) invbalancessetremote.getMbo(0)) != null) 
		        {
		        	String lotnum = invbalancesremote.getString("LOTNUM");
		        	invbalancessetremote.close();
		        	return lotnum;
		        }
		        else
				{
					invbalancessetremote.close();
					Object obj[] = {
							storeloc
					};
					throw new MXApplicationException("workorder", "NoInv", obj);
				}
			}
	
	public double getTotalCurBal(MboRemote mboremote, String itemnum, String itemsetid, String storeloc, String siteid)
	throws MXException, RemoteException
	{
		InvBalancesSetRemote invbalancessetremote = (InvBalancesSetRemote) MXServer.getMXServer().getMboSet("INVBALANCES", mboremote.getUserInfo());
        SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "itemnum = :1 and itemsetid = :2 and location = :3 and siteid = :4");
        sqlformat.setObject(1, "INVENTORY", "ITEMNUM", itemnum);
        sqlformat.setObject(2, "INVENTORY", "ITEMSETID", itemsetid);
        sqlformat.setObject(3, "INVENTORY", "LOCATION", storeloc);
        sqlformat.setObject(4, "INVENTORY", "SITEID", siteid);
        invbalancessetremote.setWhere(sqlformat.format());
		
        int i=0;
        double totalcurbal=0;
        for(InvBalancesRemote invbalancesremote; (invbalancesremote = (InvBalancesRemote) invbalancessetremote.getMbo(i)) != null; i++) 
        {
        	totalcurbal = totalcurbal + invbalancesremote.getDouble("CURBAL");
        }
        invbalancessetremote.close();
		return totalcurbal;
	}
	
	public InventoryRemote getTransitInv(MboRemote mboremote, String itemnum, String itemsetid, String storeloc, String siteid)
	throws MXException, RemoteException
	{
		InventorySetRemote inventorysetremote = (InventorySetRemote) MXServer.getMXServer().getMboSet("INVENTORY", mboremote.getUserInfo());
        SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "itemnum = :1 and itemsetid = :2 and location = :3 and siteid = :4");
        sqlformat.setObject(1, "INVENTORY", "ITEMNUM", itemnum);
        sqlformat.setObject(2, "INVENTORY", "ITEMSETID", itemsetid);
        sqlformat.setObject(3, "INVENTORY", "LOCATION", storeloc);
        sqlformat.setObject(4, "INVENTORY", "SITEID", siteid);
        inventorysetremote.setWhere(sqlformat.format());
				
        InventoryRemote inventoryremote = (InventoryRemote) inventorysetremote.getMbo(0); 
		if(inventoryremote != null)
		{
			return inventoryremote;
		}else
		{
			inventorysetremote.close();
			Object obj[] = {
					storeloc
			};
			throw new MXApplicationException("workorder", "NoInv", obj);
		}
	}
	
	public String getGLAcct(MboRemote mboremote, String store, String siteid)
	throws MXException, RemoteException
	{
		LocationSetRemote locationsetremote = (LocationSetRemote) MXServer.getMXServer().getMboSet("LOCATIONS", mboremote.getUserInfo());
        SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "location = :1 and siteid = :2");
        sqlformat.setObject(1, "LOCATIONS", "LOCATION", store);
        sqlformat.setObject(2, "LOCATIONS", "SITEID", siteid);
        locationsetremote.setWhere(sqlformat.format());
        
        LocationRemote locationremote = (LocationRemote) locationsetremote.getMbo(0);
        if(locationremote != null)
		{
        	String GL = locationremote.getString("CONTROLACC");
        	locationsetremote.close();
        	return GL;
		}else
		{
			locationsetremote.close();
			Object obj[] = {
					store, siteid
			};
			throw new MXApplicationException("workorder", "NoStore", obj);
		}
	}
}
