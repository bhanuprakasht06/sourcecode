/*
 * Modification history
 * 15-10-2007	AGD	eRFQ		Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQLineRemote;
import psdi.util.MXException;


public interface RFQLineCustomRemote
		extends RFQLineRemote
{
	public abstract void copyRFQLinesToQuotationAlt(String vendor)
			throws MXException, RemoteException;

}
