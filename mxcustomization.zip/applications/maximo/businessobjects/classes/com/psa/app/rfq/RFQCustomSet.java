/*
 * Modification history
 * 28-09-07	LS		Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQSet;
import psdi.app.rfq.RFQSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;

public class RFQCustomSet extends RFQSet 
	implements RFQSetRemote
{
	public RFQCustomSet(MboServerInterface mboserverinterface)
		throws MXException, RemoteException
	{
		super(mboserverinterface);
	}

	protected Mbo getMboInstance(MboSet mboset)
		throws MXException, RemoteException
	{
		return new RFQCustom(mboset);
	}
}
