/*
 * Modification history
 * 05-10-2007	AGD	SR-117	Populate store based on user default store
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.WPMaterialSet;
import psdi.app.workorder.WPMaterialSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;

public class WPMaterialCustomSet extends WPMaterialSet
implements WPMaterialCustomSetRemote
{

public WPMaterialCustomSet(MboServerInterface mboserverinterface)
	throws MXException, RemoteException
{
super(mboserverinterface);
}


protected Mbo getMboInstance(MboSet wpmatset)
	throws MXException, RemoteException
{
return new WPMaterialCustom(wpmatset);
}

//recovering WO code starts here
public void copyLoanReserveSet(MboSetRemote invReserveSet, String wonum)
throws MXException, RemoteException
{
MboRemote invRes = null;
int index = 0;
while ((invRes = invReserveSet.getMbo(index)) != null)
{
	++index;
	if (!(invRes.isSelected()))
	{
		continue;
	}
	//double qtyForIssue = invRes.getDouble("RESERVEDQTY");
	//System.out.println("-VERSION 1-");
	MboRemote newMatUse = addMatUseFromInvReserve(invRes , wonum);	
}
	System.out.println("-WCS 002-");
	//invReserveSet.save();
}

public MboRemote addMatUseFromInvReserve(MboRemote invRes, String wonum)
throws MXException, RemoteException
{
	//System.out.println("-copying loanitems to wpmaterial -VERSION 1--");
MboRemote newMatUse = add();
try
{
MboSetRemote matLoanreturnset = MXServer.getMXServer().getMboSet("MATRECTRANS", getUserInfo());
SqlFormat sqlformat = new SqlFormat("itemnum=:1 AND tostoreloc=:2 AND fromstoreloc=:3 AND loanid=:4");
	//System.out.println("-WCS 4-");
sqlformat.setObject(1, "MATRECTRANS", "itemnum", invRes.getString("itemnum"));
sqlformat.setObject(2, "MATRECTRANS", "tostoreloc", invRes.getString("fromstoreloc"));
	//System.out.println("-WCS 5-");
sqlformat.setObject(3, "MATRECTRANS", "fromstoreloc", invRes.getString("tostoreloc"));
	System.out.println("-WCS 3-");
sqlformat.setObject(4, "MATRECTRANS", "loanid", invRes.getString("LOANID"));
matLoanreturnset.setWhere(sqlformat.format());
int k = 0;
MboRemote matLoanreturnMbo;
	System.out.println("-WCS 6-");
double loanReturnQty = 0.0D;
while ((matLoanreturnMbo = matLoanreturnset.getMbo(k)) != null)
{
	double loanReturnQty1 = matLoanreturnMbo.getDouble("quantity");
	loanReturnQty = loanReturnQty + loanReturnQty1;
	k++;
}
	double totloanqty = invRes.getDouble("quantity");
	double recoverqty = totloanqty - loanReturnQty;
if (recoverqty > 0.0)
	{
	//System.out.println("-itemnum-" + invRes.getString("itemnum") +"-CC-"+invRes.getString("conditioncode")+"-location-"+invRes.getString("fromstoreloc")+"-siteid-"+invRes.getString("fromsiteid"));
			newMatUse.setValueNull("STORELOCSITE", 2L);	
			newMatUse.setValue("itemnum", invRes.getString("itemnum"), 11L);
			newMatUse.setValue("description", invRes.getString("description"), 11L);
			newMatUse.setValue("orderunit", invRes.getString("receivedunit"), 11L);

			newMatUse.setValue("ITEMQTY", recoverqty, 2L);
			//newMatUse.setValue("linetype", "Item", 2L);
			newMatUse.setValue("LOCATION", invRes.getString("fromstoreloc"), 2L);
			newMatUse.setValue("conditioncode", invRes.getString("conditioncode"), 11L);
			newMatUse.setValue("STORELOCSITE", invRes.getString("fromsiteid"), 2L);	
			newMatUse.setValue("LOANID", invRes.getString("LOANID"), 2L);
			//invRes.setValue("REFWO", wonum , 11L);
	}

}
catch (MXException m)
{
	newMatUse.delete();
	newMatUse.getThisMboSet().remove();
	throw m;
}
catch (RemoteException r)
{
	newMatUse.delete();
	newMatUse.getThisMboSet().remove();
	throw r;
}
return newMatUse;
}
//Recovering WO code ends here

}
