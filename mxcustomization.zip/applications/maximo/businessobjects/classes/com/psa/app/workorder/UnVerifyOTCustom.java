package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.util.Date;

import psdi.app.labor.LabTransRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class UnVerifyOTCustom
                implements ActionCustomClass
{

        /*
         * Constructor - does nothing
         */
        public UnVerifyOTCustom()
        {
        }


        /*
         * Approve all unapproved labor reports
         */
        public void applyCustomAction(MboRemote woremote, Object aobj[])
                        throws MXException, RemoteException
        {
                mxLogger.debug("UnVerifyOTCustom - Entering");
                System.out.println("UnVerifyOTCustom - Entering: WO: " + woremote.getString("WONUM") + ": " + MXServer.getMXServer().getDate());

                wo = woremote;

                MboSetRemote labtransset = wo.getMboSet("VERIFIEDOT");
                LabTransRemote labtrans;
                for (int i = 0; (labtrans = (LabTransRemote) labtransset.getMbo(i)) != null; i ++)
                {
//       	                System.out.println("UnVerifyOTCustom - PSA_VERIFIED before=" + labtrans.getBoolean("PSA_VERIFIED"));

                        if (labtrans.getBoolean("PSA_VERIFIED") && labtrans.getBoolean("PSA_OT_FLAG"))
                        {
                                //labtrans.verifyOTTransaction();
                        	//labtrans.setValue("PSA_VERIFIED",0);
                        
                        	labtrans.setValue("PSA_VERIFIEDBY", wo.getUserInfo().getPersonId(), 11L);

                    		// Update the verify date of OT Transaction
                    		Date verifydate = MXServer.getMXServer().getDate();
                    		labtrans.setValue("PSA_VERIFIEDDATE", verifydate, 11L);
                    	
                    		// Update the verify flag of OT Transaction
                    		labtrans.setValue("PSA_VERIFIED",false, 11L);

//                        	System.out.println("UnVerifyOTCustom - PSA_VERIFIED after=" + labtrans.getBoolean("PSA_VERIFIED"));
                        }

                }
//                labtransset.save();
//                labtransset.close();

                mxLogger.debug("UnVerifyOTCustom - Leaving");
                System.out.println("UnVerifyOTCustom - Leaving: WO: " + woremote.getString("WONUM") + ": " + MXServer.getMXServer().getDate());
        }

        private MboRemote                       wo;
        private static final MXLogger   mxLogger        = MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}

