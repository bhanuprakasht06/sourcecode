/*
 * Modification history
 * 28-09-07	AGD	NA		Creation
 */
package com.psa.app.rfq;

import psdi.app.rfq.QuotationLineSetRemote;

public interface QuotationAltCustomSetRemote
		extends QuotationLineSetRemote
{

}
