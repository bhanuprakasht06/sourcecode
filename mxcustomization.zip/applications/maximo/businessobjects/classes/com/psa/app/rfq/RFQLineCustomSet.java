package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQLineSet;
import psdi.app.rfq.RFQLineSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class RFQLineCustomSet extends RFQLineSet
		implements RFQLineSetRemote
{

	public RFQLineCustomSet(MboServerInterface mboserverinterface)
			throws MXException, RemoteException
	{
		super(mboserverinterface);
	}


	protected Mbo getMboInstance(MboSet rfqlineset)
			throws MXException, RemoteException
	{
		return new RFQLineCustom(rfqlineset);
	}
}
