package com.psa.app.common.purchasing;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

public class FldWOInterruptCustom extends MboValueAdapter {

	public FldWOInterruptCustom(MboValue mbovalue) 
	{
		super(mbovalue);
	}
	
	//public void initValue()
	public void initValue()
		throws MXException, RemoteException
	{
	    super.initValue();
	    MboValue mbovalue = getMboValue();
	    double totalhrs = 0;
	    Mbo mbo = getMboValue().getMbo();
//	    System.out.println("[FldWOInterruptCustom] mbo name: " + mbo.getName());
//	    System.out.println("[FldWOInterruptCustom] refwo: " + mbo.getString("REFWO"));
//	    System.out.println("[FldWOInterruptCustom] positeid: " + mbo.getString("POSITEID"));
//	    System.out.println("[FldWOInterruptCustom] ponum: " + mbo.getString("PONUM"));
//	    System.out.println("[FldWOInterruptCustom] polinenum: " + mbo.getString("POLINENUM"));
	    
//	    MboSetRemote wointerruptset = MXServer.getMXServer().getMboSet("WOINTERRUPT", mbo.getUserInfo());
	    MboSetRemote wointerruptset = mbo.getMboSet("LDWOINTERRUPT");
//		SqlFormat sqlformat = new SqlFormat("wonum=:1 and siteid=:2 and INTERRUPTCODE='12'");
//		sqlformat.setObject(1, "wointerrupt", "wonum", mbo.getString("refwo"));
//		sqlformat.setObject(2, "wointerrupt", "siteid", mbo.getString("positeid"));
//		wointerruptset.setWhere(sqlformat.format());
	    
//	    System.out.println("[FldWOInterruptCustom] wointerrupt count: " + wointerruptset.count());
//		System.out.println("[FldWOInterruptCustom] Totalhrs: " + totalhrs);
//		System.out.println("[FldWOInterruptCustom] Set Name: " + wointerruptset.getName());
//		System.out.println("[FldWOInterruptCustom] Where: " + wointerruptset.getWhere());

		totalhrs = wointerruptset.sum("INTERRUPTHRS")/24;
		
//		System.out.println("[FldWOInterruptCustom] Totalhrs: " + totalhrs);
//		System.out.println("[FldWOInterruptCustom] Exit");
		mbovalue.setValue(totalhrs, 11L);
	}
}
