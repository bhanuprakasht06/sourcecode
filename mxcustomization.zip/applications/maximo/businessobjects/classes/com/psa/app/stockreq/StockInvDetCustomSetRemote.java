/*
 * Modification history
 * 27-05-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import psdi.mbo.*;

public interface StockInvDetCustomSetRemote extends MboSetRemote 
{
		
}
