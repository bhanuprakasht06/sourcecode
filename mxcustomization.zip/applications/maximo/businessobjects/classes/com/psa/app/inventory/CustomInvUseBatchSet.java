package com.psa.app.inventory;

import java.rmi.RemoteException;
import java.util.Vector;

import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.custapp.CustomMboSet;
import psdi.util.MXException;

public class CustomInvUseBatchSet extends CustomMboSet 
	implements CustomInvUseBatchSetRemote 
{
	public CustomInvUseBatchSet(MboServerInterface mboserverinterface)
			throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}

	protected Mbo getMboInstance(MboSet mboset) 
			throws MXException,	RemoteException 
	{
		return (new CustomInvUseBatch(mboset));
	}

	public void copyInvBatchLineSet(MboSetRemote invUseIssueBatch)
			throws MXException, RemoteException
	{
		@SuppressWarnings("rawtypes")
		Vector selected = invUseIssueBatch.getSelection();
		if (!selected.isEmpty()) 
		{
			int size = selected.size();
			for (int x = size - 1; x >= 0; x--) 
			{
				addInvBatchLineFromInvBatchIssue((MboRemote) selected.get(x));
			}
		}
	}
	
	public MboRemote addInvBatchLineFromInvBatchIssue(MboRemote invBatchIssue)
			throws MXException, RemoteException 
	{
		MboRemote newinvBatchIssue = addAtEnd();
		newinvBatchIssue.setValue("batchnum", invBatchIssue.getString("batchnum"), 11L);
		newinvBatchIssue.setValue("itemnum", invBatchIssue.getString("itemnum"), 11L);
		newinvBatchIssue.setValue("location", invBatchIssue.getString("location"), 11L);
		newinvBatchIssue.setValue("invusenum", getOwner().getString("invusenum"), 11L);
		newinvBatchIssue.setValue("binnum", invBatchIssue.getString("binnum"),2L);
		newinvBatchIssue.setValue("lotnum", invBatchIssue.getString("lotnum"),2L);
		newinvBatchIssue.setValue("conditioncode", invBatchIssue.getString("conditioncode"),2L);
		newinvBatchIssue.setValue("refwo", invBatchIssue.getString("refwo"),2L);
		newinvBatchIssue.setValue("usagetype", "RETURN",2L);
		newinvBatchIssue.setValue("quantity", invBatchIssue.getDouble("quantity"),2L);
		newinvBatchIssue.setValue("siteid", invBatchIssue.getString("siteid"), 2L);
		newinvBatchIssue.setValue("orgid", invBatchIssue.getString("orgid"), 2L);
		newinvBatchIssue.setValue("status", "ENTERED", 2L);
		newinvBatchIssue.setValue("changed", false, 2L);
		return newinvBatchIssue;
	}
	
	public void copyInvBatchLineTransferSet(MboSetRemote invUseTransferBatch)
			throws MXException, RemoteException
	{
		@SuppressWarnings("rawtypes")
		Vector selected = invUseTransferBatch.getSelection();
		if (!selected.isEmpty()) 
		{
			int size = selected.size();
			for (int x = size - 1; x >= 0; x--) 
			{
				addInvBatchLineForTransfer((MboRemote) selected.get(x));
			}
		}
	}

	public MboRemote addInvBatchLineForTransfer(MboRemote invBatchTransfer)
			throws MXException, RemoteException 
	{
		MboRemote newinvBatchIssue = addAtEnd();
		newinvBatchIssue.setValue("batchnum", invBatchTransfer.getString("batchnum"), 11L);
		newinvBatchIssue.setValue("itemnum", invBatchTransfer.getString("itemnum"), 11L);
		newinvBatchIssue.setValue("location", invBatchTransfer.getString("location"), 11L);
		newinvBatchIssue.setValue("tolocation", getOwner().getString("tostoreloc"), 11L);
		newinvBatchIssue.setValue("invusenum", getOwner().getString("invusenum"), 11L);
		newinvBatchIssue.setValue("binnum", invBatchTransfer.getString("binnum"),2L);
		newinvBatchIssue.setValue("tobin", getOwner().getString("tobin"),2L);
		newinvBatchIssue.setValue("lotnum", invBatchTransfer.getString("lotnum"),2L);
		newinvBatchIssue.setValue("tolot", getOwner().getString("tolot"),2L);
		newinvBatchIssue.setValue("conditioncode", invBatchTransfer.getString("conditioncode"),2L);
		newinvBatchIssue.setValue("usagetype", "TRANSFER",2L);
		newinvBatchIssue.setValue("quantity", getOwner().getDouble("quantity"),2L);
		newinvBatchIssue.setValue("siteid", getOwner().getString("siteid"), 2L);
		newinvBatchIssue.setValue("orgid", getOwner().getString("orgid"), 2L);
		newinvBatchIssue.setValue("status", "ENTERED", 2L);
		newinvBatchIssue.setValue("changed", false, 2L);
		return newinvBatchIssue;
	}

}
