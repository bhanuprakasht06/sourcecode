package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.custapp.CustomMboSet;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class WOSkillsetSetCustom extends CustomMboSet 
	implements WOSkillsetSetCustomRemote 
{
	public WOSkillsetSetCustom (MboServerInterface mboserverinterface) 
		throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}
	
	protected Mbo getMboInstance(MboSet mboset) 
		throws MXException, RemoteException
	{
		return (new WOSkillsetCustom(mboset));
	}
	
	public void canAdd()
			throws MXException
    {
	    super.canAdd();
	    try
	    {
	        MboRemote WORemote = getOwner();  	        
	        String WOStatus = WORemote.getString("STATUS");
	        if (WOStatus.equalsIgnoreCase("WPLSCH") || WOStatus.equalsIgnoreCase("WPLSCH-PRG")  || WOStatus.equalsIgnoreCase("WAPPR")  || WOStatus.equalsIgnoreCase("WSCH"));
	        else
	        	throw new MXApplicationException("jspmessages", "table_cannotadd");
	    }
	    catch(RemoteException t)
	    {
	        t.printStackTrace();
	    }
	}
}
