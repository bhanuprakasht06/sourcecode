/*
 * Created by BCT 
 * 
 * Returning the  Asset Mbo object
 * 
 * 
 */
package com.psa.app.asset;

import java.rmi.RemoteException;

import psdi.app.asset.AssetSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class AssetSetCustom extends AssetSet {

	public AssetSetCustom(MboServerInterface ms) throws MXException,
			RemoteException {
		super(ms);
		
	}

// Returning the AssetCustom Mbo	
	protected Mbo getMboInstance(MboSet ms) throws MXException, RemoteException {
		
		return new AssetCustom(ms);
	}

}
