/*
 * Modification history
 * 22-01-13 WMJ EMS-545 [LABTRANS]Escalation to highlight labour with more than 60 hours of OT in a calendar month 
 *
 *
 *
 */

package com.psa.app.labor;

import java.rmi.RemoteException;
import psdi.app.labor.LabTransRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

//Start of EMS-545
import java.util.Date;
//End of EMS-545

public abstract interface LabTransCustomRemote extends LabTransRemote
{
  public abstract void approveOTTransaction()
    throws MXException, RemoteException;

  public abstract void verifyOTTransaction(boolean paramBoolean)
    throws MXException, RemoteException;

  public abstract void unverifyOTTransaction()
    throws MXException, RemoteException;

  public abstract void copyLabTransToCurrentOT(MboSetRemote paramMboSetRemote)
    throws MXException, RemoteException;

  public abstract void setOTFlag(boolean paramBoolean)
    throws MXException, RemoteException;

  //Start of EMS-545    
  public abstract void checkDates()
    throws MXException, RemoteException;    

  public abstract Date validateDateTime(Date date, Date time)
    throws MXException, RemoteException;    
  //End of EMS-545	
    
}