/*
 * Modification history
 * 07-06-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.RemoteException;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

public class FldStoreLocCustom extends MboValueAdapter
{

    public FldStoreLocCustom(MboValue mbovalue)
        throws MXException, RemoteException
    {
        super(mbovalue);
    }

    public void action()
    	throws MXException, RemoteException
    {
    	MboRemote mboRemote = getMboValue().getMbo();
    	MboSetRemote StoreSetRemote = mboRemote.getMboSet("STOREROOM");
    	MboRemote StoreRemote = StoreSetRemote.getMbo(0);
    	mboRemote.setValue("siteid", StoreRemote.getString("siteid"), 2L);
    }
}