/*
 * Created by BCT 
 * 
 * This cron will get data from daily  balances table 
 * and captures items to be reconciled based on the days parameter 
 * inventory mismatches will be inserted in custom table INVCHECK
 * 1/14/2015-Date format of the log file name for the log  is changed as inventoryRecon.log.201501092359
 * 
 */
package com.psa.app.inventory;


import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.psa.custom.common.MxEmail;
import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class InvReconCronCustom extends SimpleCronTask {
	  
	
	private static CrontaskParamInfo params[];

	private int days;
	private double tolerance;
	private String adminEmail;
	private MxEmail email;
	private MxEmail invEentorymail;
	protected MxLog mxLog;
	protected String eMailsub;
	private String logDirectory;
	private String alertEmailSub;
	private String invAlertEmail;
	private String invAlertEmailSub;
	private boolean enableLog;
	private String itemNum ;
	private String itemNumLog ;
	private StringBuffer reconItem;
	private StringBuffer reconItemLog;
	private ResultSet itemReconSet;
	private String logFileName;
	protected static final MXLogger mxLogger = MXLoggerFactory.getLogger("maximo.integration");
	
	public InvReconCronCustom()
	{
		super();
		 days=0;
		 tolerance=0.000;
		 adminEmail = null;
		 eMailsub=null;
		 logDirectory=null;
		 alertEmailSub=null;
		 invAlertEmail=null;
		 invAlertEmailSub=null;
		 enableLog=false;
		 itemNum=null;
		 itemNumLog=null;
		 logFileName=null;
		
	}
	
	
 public CrontaskParamInfo[] getParameters() throws MXException, RemoteException
 {
		params = new CrontaskParamInfo[9];
		params[0] = new CrontaskParamInfo();
		params[0].setName("DAYS");
		params[0].setDescription("Days", "Time interval(in days) for Inventory reconciliation Check");
		params[0].setDefault("0");
		params[1] = new CrontaskParamInfo();
		params[1].setName("LOGFILEPATH");
		params[1].setDescription("Log", "Log File Path");
		params[2] = new CrontaskParamInfo();
		params[2].setName("ADMINEMAIL");
		params[2].setDescription("Email","Administrator Email");
		params[3] = new CrontaskParamInfo();
		params[3].setName("ALERTEMAILSUBJ");
		params[3].setDescription("EmailSub","Alert Email Subject");
		params[4] = new CrontaskParamInfo();
		params[4].setName("INVALERTEMAIL");
		params[4].setDescription("Inv_ReconEmail","Inventory Reconcilation Email Alert");
		params[5] = new CrontaskParamInfo();
		params[5].setName("INVALERTEMAILSUB");
		params[5].setDescription("Inv_ReconEmailSub","Inventory Reconcilation Email Subject");
		params[6] = new CrontaskParamInfo();
		params[6].setName("ENABLELOG");
		params[6].setDescription("Enable Log","Enable log output('Y' or 'N').");
		params[6].setDefault("Y");
		params[7] = new CrontaskParamInfo();
		params[7].setName("LOGFILENAME");
		params[7].setDescription("LOGFILENAME","Log File Name");
		params[8] = new CrontaskParamInfo();
		params[8].setName("TOLERANCEVALUE");
		params[8].setDescription("TOLERANCEVALUE","Tolerance Value for Cost mismatch (Only decimal values)");
		
		return params;
 }
	
 private void refreshSettings() {
        try {
        	adminEmail = getParamAsString("ADMINEMAIL");
            email.setAdmin(adminEmail);
            days=getParamAsInt("DAYS");
            logDirectory = getParamAsString("LOGFILEPATH");
            alertEmailSub = getParamAsString("ALERTEMAILSUBJ");
            invAlertEmail = getParamAsString("INVALERTEMAIL");
            invAlertEmailSub = getParamAsString("INVALERTEMAILSUB");
            enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
            tolerance=getParamAsDouble("TOLERANCEVALUE");
            Date currentDate=MXServer.getMXServer().getDate();
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
            String currentDateString = dateFormat.format(currentDate); 
            logFileName=getParamAsString("LOGFILENAME");
            logDirectory=logDirectory+logFileName+"."+currentDateString;
            mxLog.setEnabled(enableLog);
            mxLog.setLogFilePath(logDirectory);
            mxLog.setLogTag(getName());
            mxLog.createLogFile();
           
            
     }
     catch(Exception e)
     {
           
     }
 }
 
 private boolean isReqParamSet() {
     if (adminEmail.equalsIgnoreCase(""))
             return false;
     
     if (logDirectory.equalsIgnoreCase(""))
             return false;
     if (invAlertEmail.equalsIgnoreCase(""))
             return false;
     
     return true;
}
 public void init() throws MXException {
     super.init();

     email = new MxEmail(adminEmail);
     mxLog = new MxLog();
    
}
 private String genEmail(Exception e) {

     String emailMsg = "Date: " + new Date() + "\n";
     emailMsg += "Error in CronTask: " + getName() + "\n";
     emailMsg += "Error Message: " + e.getMessage() + "\n";
     emailMsg += "Detail:\n";
     emailMsg += e.toString() + "\n";
     StackTraceElement element[] = e.getStackTrace();
     for (int i = 0; i < element.length; i++) {
             emailMsg += "\tat " + element[i].toString() + "\n";
     }

     return emailMsg;
}	
	
	public void cronAction()
	{
		System.out.println();
		try{
			refreshSettings();
			
			if(isReqParamSet())
			{
			invReconCron();
			
			if(!invAlertEmail.equalsIgnoreCase(""))
			{
				if(!reconItem.toString().equalsIgnoreCase(""))
				{
				String emailTo[]=invAlertEmail.split(",");
				for(int i=0;i<=emailTo.length-1;i++)
				{
					invEentorymail=new MxEmail(emailTo[i].toString());
					invEentorymail.send(invAlertEmailSub, reconItem.toString());
					
				}
				}
			}
			}
			else
			{
				mxLogger.info("Required Parameters are not set.");
			}
			
		}
		catch(Exception e)
		{
			String emailContent = genEmail(e);
            email.send(alertEmailSub, emailContent);
		
		}
		
		
	}

	

	public void invReconCron() throws MXException,RemoteException, SQLException
	
	{	
		DBShortcut dbShortcut = new DBShortcut();
		try
		{
			dbShortcut.connect(getRunasUserInfo().getConnectionKey());
			mxLog.writeLog(" Starting Inventory reconcilation Cron: " +getName());
			days = getParamAsInt("DAYS");
			reconItem=new StringBuffer();
			reconItemLog=new StringBuffer();
		
			String invReconDiff =null;
			String invReconCostDiff =null;
			mxLog.writeLog(" Inventory Reconcilation No of days should not be zero: " +days);
			if(days>0)
			{
				//	int days1 =days + 1;
				mxLog.writeLog(" Executing the invcheck cron");
				String	deleteOldTransaction= "delete from INVCHECK";
				SqlFormat invRecoDeleteSql=new SqlFormat(deleteOldTransaction);
				dbShortcut.executeQuery(invRecoDeleteSql.format());
				dbShortcut.commit();
				mxLog.writeLog("Deleting all old data from the INVCHECK Table: Query-->"+deleteOldTransaction);
				
/*
 *     INVCHECK query written by BCT with Left outer join concept
*					T1 - INVBALANCES table as Master Table for Invcheck Query  
*					T2 - Second Point of receipts ( Receipts with inspections - with type TRANSFER ) 
*					T3 - Issues value ( Net receipts including issues and Issue returns ) 
*					T4 - Inventory Adjustments 
*					T5 - Opening balance and opening value  from Invdailybal backups 
*					T6 - Closing balance and Closing value  from Invdailybal backups 
*					T7 - Direct Receipts to store rooms and Receipt Returns from store room 
*					T8 - Transfer out from the specified inventory location 
*					T9 - Transfer in to the specified inventory location  
*			Note : invbackup should fall every  beginning of the day on 00:00 hrs which will in turn give the opening balance for the day
*			This invcheck query will check the transactions of past 'n' number of days excluding today 
*			Two strings (queries ) 		invReconDiff for for balance mismatch and invReconCostDiff for Cost mismatch 
*/
				//BCT
				MboSetRemote maxsequence = MXServer.getMXServer().getMboSet("MAXSEQUENCE",getRunasUserInfo());
				maxsequence.setWhere("TBNAME='INVCHECK'");				
				MboRemote invdailybalseq = maxsequence.getMbo(0); 
				int maxreserve = invdailybalseq.getInt("MAXRESERVED");
				maxreserve= maxreserve+1;
					
				
				
//				invReconDiff="INSERT INTO INVCHECK(ITEMNUM,LOCATION,SITEID,ORGID,BINNUM, LOTNUM, CONDITIONCODE,TRANSFEROUTQTY,TRANSFEROUTVALUE ,TRANSFERINQTY ,TRANSFERINVALUE ,RECEIPTSQTY,RECEIPTSVALUE,ISSUESQTY ,ISSUESVALUE, ADJUSTQTY , ADJUSTVALUE , OPENINGBAL ,CLOSINGBAL ,OPENINGVALUE,CLOSINGVALUE,FROMDATE,TODATE,INVCHECKID ,NETDIFFERENCE , MISMATCHTYPE ) ";
//				invReconDiff=invReconDiff+"(SELECT ITEMNUM ,LOCATION,SITEID,ORGID,BINNUM, LOTNUM, CONDITIONCODE, TOUT,TOUTVALUE,  TIN ,TINVALUE,RECEIPTSQTY,RECEIPTSVALUE,ISSQTY,ISSVALUE, AQTY,AVALUE, OBAL,CLOSEBAL, OVAL,CLOSEVAL,(TO_DATE(SYSDATE-"+days+" ,'DD-MM-YY') )  AS FROMDATE,(TO_DATE(SYSDATE ,'DD-MM-YY') -  (1 / 86400) ) AS TODATE,INVCHECKIDSEQ.NEXTVAL ,NETDIFFERENCE , MISMATCHTYPE  ";
//				invReconDiff=invReconDiff+"FROM  (   SELECT ITEMNUM ,LOCATION,SITEID,ORGID,BINNUM , LOTNUM ,CONDITIONCODE, tout,TOUTVALUE,  tin ,TINVALUE, (REC1QTY + REC2QTY ) AS RECEIPTSQTY, (REC1VALUE +REC2VALUE ) AS RECEIPTSVALUE ,ISSQTY,ISSVALUE, AQTY,AVALUE, OBAL,CLOSEBAL, OVAL,CLOSEVAL ,   "; 
//				invReconDiff=invReconDiff+"DECODE((REC1QTY+REC2QTY+ISSQTY+AQTY+TOUT+TIN+OBAL)-CLOSEBAL,0,'Y','N')RESULTBAL, ABS (REC1QTY+REC2QTY+ISSQTY+AQTY+TOUT+TIN+OBAL-CLOSEBAL ) AS NETDIFFERENCE , 'QUANTITY' AS MISMATCHTYPE       ";
//				invReconDiff=invReconDiff+"FROM (   SELECT  T1.ITEMNUM,T1.LOCATION,T1.SITEID,T1.ORGID , T1.BINNUM , T1.LOTNUM , T1.CONDITIONCODE , NVL(T2.R1QTY,0)REC1QTY , NVL(T2.R1VALUE,0)REC1VALUE ,  NVL(T7.R2QTY,0)REC2QTY , NVL(T7.R2VALUE,0)REC2VALUE ,  NVL(T3.IQTY,0)ISSQTY, NVL(T3.IVALUE,0)ISSVALUE,  ";
//				invReconDiff=invReconDiff+"nvl(T8.transout,0)tout,nvl(T9.transin,0)tin ,nvl(T8.TRANSOUTVALUE,0)TOUTVALUE,nvl(T9.TRANSINVALUE,0)TINVALUE ,NVL(T4.ADJQTY,0)AQTY , NVL(T4.ADJVALUE,0)AVALUE ,  NVL(T5.OPBAL,0)OBAL,NVL(T6.CLOSEBAL,0)CLOSEBAL ,   NVL(T5.OPVAL,0)OVAL,NVL(T6.CLOSEVAL,0)CLOSEVAL   ";
//				invReconDiff=invReconDiff+"FROM   (SELECT DISTINCT ITEMNUM,LOCATION,SITEID,ORGID , BINNUM , LOTNUM , CONDITIONCODE  FROM INVBALANCES WHERE LOCATION  LIKE '%STORE%' ) T1     ";
//				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,TOSTORELOC, TOBIN , TOLOT  , CONDITIONCODE,NVL(SUM(QUANTITY),0) AS R1QTY,  SUM (LINECOST) AS R1VALUE ,SITEID,ORGID FROM MATRECTRANS  WHERE TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY') AND ISSUETYPE='TRANSFER' AND FROMSTORELOC IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') GROUP BY ITEMNUM,TOSTORELOC,SITEID,ORGID,TOBIN, TOLOT ,CONDITIONCODE)T2   ";
//				invReconDiff=invReconDiff+"		 ON  T1.ITEMNUM = T2.ITEMNUM  AND T1.LOCATION = T2.TOSTORELOC  AND T1.SITEID= T2.SITEID  AND nvl (T1.CONDITIONCODE,'NOTVALID' ) =  nvl (T2.CONDITIONCODE,'NOTVALID')    AND nvl (T1.BINNUM ,'NOTVALID')=  nvl (T2.TOBIN ,'NOTVALID')      AND nvl (T1.LOTNUM ,'NOTVALID')= nvl(T2.TOLOT ,'NOTVALID')   ";	
//				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,STORELOC,BINNUM ,LOTNUM , CONDITIONCODE,NVL(SUM(QUANTITY),0) AS IQTY,NVL(SUM(-LINECOST),0) AS IVALUE ,SITEID,ORGID FROM MATUSETRANS  WHERE TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY') AND  STORELOC IS NOT NULL GROUP BY ITEMNUM,STORELOC,SITEID,ORGID,BINNUM,LOTNUM ,CONDITIONCODE)T3  ";
//				invReconDiff=invReconDiff+"		ON	  T1.ITEMNUM = T3.ITEMNUM AND T1.LOCATION = T3.STORELOC AND T1.SITEID= T3.SITEID AND  nvl(T1.CONDITIONCODE ,'NOTVALID')= nvl (T3.CONDITIONCODE ,'NOTVALID')    AND nvl (T1.BINNUM ,'NOTVALID') = nvl (T3.BINNUM ,'NOTVALID')      AND  nvl (T1.LOTNUM,'NOTVALID')=  nvl(T3.LOTNUM,'NOTVALID')  ";					
//				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,STORELOC,BINNUM , LOTNUM ,CONDITIONCODE ,NVL(SUM(QUANTITY),0) AS ADJQTY,NVL(SUM(LINECOST),0) AS ADJVALUE,SITEID,ORGID FROM INVTRANS  WHERE TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY') AND STORELOC IS NOT NULL AND TRANSTYPE  IN  ('CURBALADJ','RECBALADJ') GROUP BY ITEMNUM,STORELOC,SITEID,ORGID,BINNUM, LOTNUM ,CONDITIONCODE)T4  ";
//				invReconDiff=invReconDiff+"ON	 T1.ITEMNUM = T4.ITEMNUM AND T1.LOCATION = T4.STORELOC AND T1.SITEID= T4.SITEID  AND nvl(T1.CONDITIONCODE ,'NOTVALID') = nvl (T4.CONDITIONCODE,'NOTVALID')  AND nvl (T1.BINNUM ,'NOTVALID')= nvl (T4.BINNUM ,'NOTVALID')      AND nvl(T1.LOTNUM,'NOTVALID')= nvl(T4.LOTNUM,'NOTVALID')   ";
//				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,LOCATION, BINNUM , LOTNUM  ,  CONDITIONCODE ,NVL(SUM(CURBAL),0)AS OPBAL, NVL(SUM(CURBAL * AVGCOST ),0)AS OPVAL,  SITEID,ORGID FROM INVDAILYBAL  WHERE  TO_DATE(TDATE ,'DD-MM-YY')=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND LOCATION IS NOT NULL GROUP BY ITEMNUM,LOCATION,SITEID,ORGID, BINNUM , LOTNUM, CONDITIONCODE)T5  ";
//				invReconDiff=invReconDiff+"  	ON	 T1.ITEMNUM = T5.ITEMNUM AND T1.LOCATION = T5.LOCATION  AND T1.SITEID= T5.SITEID   AND nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T5.CONDITIONCODE,'NOTVALID')    AND nvl(T1.BINNUM,'NOTVALID')= nvl(T5.BINNUM,'NOTVALID')       AND nvl(T1.LOTNUM,'NOTVALID')= nvl(T5.LOTNUM,'NOTVALID')  ";
//				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,LOCATION, BINNUM , LOTNUM , CONDITIONCODE ,NVL(SUM(CURBAL),0)AS CLOSEBAL, NVL(SUM(CURBAL * AVGCOST ),0)AS CLOSEVAL, SITEID,ORGID FROM INVDAILYBAL  WHERE  TO_DATE(TDATE ,'DD-MM-YY')=TO_DATE(SYSDATE ,'DD-MM-YY') AND LOCATION IS NOT NULL GROUP BY ITEMNUM,LOCATION,SITEID,ORGID,BINNUM, LOTNUM ,CONDITIONCODE)T6 ";  
//				invReconDiff=invReconDiff+"		ON	 T1.ITEMNUM = T6.ITEMNUM  AND T1.LOCATION = T6.LOCATION  AND T1.SITEID= T6.SITEID  AND nvl(T1.CONDITIONCODE ,'NOTVALID')= nvl(T6.CONDITIONCODE,'NOTVALID')   AND nvl(T1.BINNUM,'NOTVALID')= nvl(T6.BINNUM,'NOTVALID')       AND nvl(T1.LOTNUM,'NOTVALID')= nvl(T6.LOTNUM,'NOTVALID')   ";
//				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,TOSTORELOC,TOBIN , TOLOT  ,CONDITIONCODE,NVL(sum(QUANTITY),0)R2QTY,SUM (LINECOST) AS R2VALUE,SITEID,ORGID FROM MATRECTRANS WHERE TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY') AND ISSUETYPE IN ('RECEIPT','RETURN') AND TOSTORELOC IS NOT NULL  AND TOSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') GROUP BY ITEMNUM,TOSTORELOC,SITEID,ORGID,TOBIN,TOLOT,CONDITIONCODE)T7   ";
//				invReconDiff=invReconDiff+"ON    T1.ITEMNUM = T7.ITEMNUM AND T1.LOCATION = T7.TOSTORELOC AND T1.SITEID= T7.SITEID AND nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T7.CONDITIONCODE,'NOTVALID') AND nvl(T1.BINNUM,'NOTVALID')= nvl(T7.TOBIN,'NOTVALID')      AND nvl(T1.LOTNUM,'NOTVALID')= nvl(T7.TOLOT,'NOTVALID')    ";   
//				invReconDiff=invReconDiff+" LEFT OUTER JOIN (select ITEMNUM,ORGID , fromsiteid ,fromstoreloc,frombin , fromlot ,FROMCONDITIONCODE , NVL(SUM(-QUANTITY),0)transout , ";
//				invReconDiff=invReconDiff+"SUM (-LINECOST) AS TRANSOUTVALUE from ";
//				invReconDiff=invReconDiff+"(SELECT itemnum , FROMCONDITIONCODE  ,  TOSTORELOC , FROMSTORELOC , FROMSITEID , siteid , Frombin ,tobin , Fromlot , tolot , ORGID , QUANTITY , LINECOST   FROM MATRECTRANS WHERE  ";
//				invReconDiff=invReconDiff+"ISSUETYPE ='TRANSFER' AND PONUM IS NULL AND FROMSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') AND ";
//				invReconDiff=invReconDiff+"TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY')  ";
//				invReconDiff=invReconDiff+") TRANSFEROUT WHERE   (  ((fromsiteid =siteid)  OR  (fromsiteid !=siteid) )    AND  (  ";
//				invReconDiff=invReconDiff+"( ((fromstoreloc =tostoreloc) OR (fromstoreloc !=tostoreloc) )  AND(( ( nvl(frombin,'NOTVALID')= nvl(tobin,'NOTVALID') OR nvl( frombin,'NOTVALID') != nvl(tobin ,'NOTVALID' )) and ( nvl (fromlot,'NOTVALID') = nvl(TOlot ,'NOTVALID') OR nvl(fromlot , 'NOTVALID') !=nvl(TOlot, 'NOTVALID') )))) ";
//				invReconDiff=invReconDiff+")  ) GROUP BY ITEMNUM, orgid , fromsiteid ,fromstoreloc, frombin , fromlot ,FROMCONDITIONCODE)T8 ";
//				invReconDiff=invReconDiff+"ON	 T1.ITEMNUM = T8.ITEMNUM  AND T1.LOCATION = T8.FROMSTORELOC AND T1.SITEID= T8.FROMSITEID AND nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T8.FROMCONDITIONCODE,'NOTVALID')  AND nvl(T1.BINNUM,'NOTVALID')= nvl(T8.FROMBIN,'NOTVALID')     AND nvl(T1.LOTNUM,'NOTVALID')= nvl(T8.FROMLOT,'NOTVALID')  ";    
//				invReconDiff=invReconDiff+" LEFT OUTER JOIN (select ITEMNUM,ORGID , siteid ,tostoreloc,tobin , tolot ,CONDITIONCODE , NVL(SUM(QUANTITY),0)transin, SUM (LINECOST) AS TRANSINVALUE  ";
//				invReconDiff=invReconDiff+"from   (SELECT itemnum ,  CONDITIONCODE  ,  TOSTORELOC , FROMSTORELOC , FROMSITEID , siteid , Frombin ,tobin , Fromlot ,tolot , ORGID , QUANTITY , LINECOST   FROM MATRECTRANS WHERE   ";
//				invReconDiff=invReconDiff+"ISSUETYPE ='TRANSFER' AND PONUM IS NULL AND FROMSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') AND  "; 
//				invReconDiff=invReconDiff+"TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY')  ) TRANSFERIN WHERE   ";
//				invReconDiff=invReconDiff+"(  ((fromsiteid =siteid)  OR  (fromsiteid !=siteid) )    AND  (  ";
//				invReconDiff=invReconDiff+"( ((fromstoreloc =tostoreloc) OR (fromstoreloc !=tostoreloc) )  AND((  ";
//				invReconDiff=invReconDiff+" ( nvl(frombin,'NOTVALID')= nvl(tobin,'NOTVALID') OR nvl(frombin,'NOTVALID') != nvl(tobin,'NOTVALID') ) and ( nvl(fromlot,'NOTVALID') = nvl(TOlot,'NOTVALID') OR nvl(fromlot,'NOTVALID')  != nvl (TOlot,'NOTVALID')))))  ";
//				invReconDiff=invReconDiff+")  ) GROUP BY ITEMNUM,orgid , siteid ,tostoreloc,tobin , tolot ,CONDITIONCODE)T9   ";
//				invReconDiff=invReconDiff+"ON    T1.ITEMNUM = T9.ITEMNUM  AND T1.LOCATION = T9.TOSTORELOC AND T1.SITEID= T9.SITEID AND   nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T9.CONDITIONCODE,'NOTVALID')       AND nvl(T1.BINNUM,'NOTVALID')= nvl(T9.TOBIN,'NOTVALID')      AND nvl(T1.LOTNUM,'NOTVALID')= nvl(T9.TOLOT,'NOTVALID')  ";
//				invReconDiff=invReconDiff+") WHERE LOCATION  LIKE '%STORE%' ) WHERE RESULTBAL ='N')	";
				
				
				//BCT
				invReconDiff="INSERT INTO INVCHECK(ITEMNUM,LOCATION,SITEID,ORGID,BINNUM, LOTNUM, CONDITIONCODE,TRANSFEROUTQTY,TRANSFEROUTVALUE ,TRANSFERINQTY ,TRANSFERINVALUE ,RECEIPTSQTY,RECEIPTSVALUE,ISSUESQTY ,ISSUESVALUE, ADJUSTQTY , ADJUSTVALUE , OPENINGBAL ,CLOSINGBAL ,OPENINGVALUE,CLOSINGVALUE,FROMDATE,TODATE,INVCHECKID ,NETDIFFERENCE , MISMATCHTYPE ) ";
				invReconDiff=invReconDiff+"(SELECT ITEMNUM ,LOCATION,SITEID,ORGID,BINNUM, LOTNUM, CONDITIONCODE, TOUT,TOUTVALUE,  TIN ,TINVALUE,RECEIPTSQTY,RECEIPTSVALUE,ISSQTY,ISSVALUE, AQTY,AVALUE, OBAL,CLOSEBAL, OVAL,CLOSEVAL,(CONVERT(DATETIME,getdate()-"+days+",5))  AS FROMDATE,(CONVERT(DATETIME,getdate() - (1/84000),5)) AS TODATE,"+maxreserve+",NETDIFFERENCE , MISMATCHTYPE  ";
				invReconDiff=invReconDiff+"FROM  (   SELECT ITEMNUM ,LOCATION,SITEID,ORGID,BINNUM , LOTNUM ,CONDITIONCODE, tout,TOUTVALUE,  tin ,TINVALUE, (REC1QTY + REC2QTY ) AS RECEIPTSQTY, (REC1VALUE +REC2VALUE ) AS RECEIPTSVALUE ,ISSQTY,ISSVALUE, AQTY,AVALUE, OBAL,CLOSEBAL, OVAL,CLOSEVAL ,   "; 
				invReconDiff=invReconDiff+"CASE 	WHEN (REC1QTY+REC2QTY+ISSQTY+AQTY+TOUT+TIN+OBAL)-CLOSEBAL = 0	 THEN 'Y' 	ELSE 'N' 	END AS RESULTBAL, ABS (REC1QTY+REC2QTY+ISSQTY+AQTY+TOUT+TIN+OBAL-CLOSEBAL ) AS NETDIFFERENCE , 'QUANTITY' AS MISMATCHTYPE       ";
				invReconDiff=invReconDiff+"FROM (   SELECT  T1.ITEMNUM,T1.LOCATION,T1.SITEID,T1.ORGID , T1.BINNUM , T1.LOTNUM , T1.CONDITIONCODE , ISNULL(T2.R1QTY,0)REC1QTY , ISNULL(T2.R1VALUE,0)REC1VALUE ,  ISNULL(T7.R2QTY,0)REC2QTY , ISNULL(T7.R2VALUE,0)REC2VALUE ,  ISNULL(T3.IQTY,0)ISSQTY, ISNULL(T3.IVALUE,0)ISSVALUE,  ";
				invReconDiff=invReconDiff+"ISNULL(T8.transout,0)tout,ISNULL(T9.transin,0)tin ,ISNULL(T8.TRANSOUTVALUE,0)TOUTVALUE,ISNULL(T9.TRANSINVALUE,0)TINVALUE ,ISNULL(T4.ADJQTY,0)AQTY , ISNULL(T4.ADJVALUE,0)AVALUE ,  ISNULL(T5.OPBAL,0)OBAL,ISNULL(T6.CLOSEBAL,0)CLOSEBAL ,   ISNULL(T5.OPVAL,0)OVAL,ISNULL(T6.CLOSEVAL,0)CLOSEVAL   ";
				invReconDiff=invReconDiff+"FROM   (SELECT DISTINCT ITEMNUM,LOCATION,SITEID,ORGID , BINNUM , LOTNUM , CONDITIONCODE  FROM INVBALANCES WHERE LOCATION  LIKE '%STORE%' ) T1     ";
				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,TOSTORELOC, TOBIN , TOLOT  , CONDITIONCODE,ISNULL(SUM(QUANTITY),0) AS R1QTY,  SUM (LINECOST) AS R1VALUE ,SITEID,ORGID FROM MATRECTRANS  WHERE CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5) AND ISSUETYPE='TRANSFER' AND FROMSTORELOC IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') GROUP BY ITEMNUM,TOSTORELOC,SITEID,ORGID,TOBIN, TOLOT ,CONDITIONCODE)T2   ";
				invReconDiff=invReconDiff+"		 ON  T1.ITEMNUM = T2.ITEMNUM  AND T1.LOCATION = T2.TOSTORELOC  AND T1.SITEID= T2.SITEID  AND ISNULL (T1.CONDITIONCODE,'NOTVALID' ) =  ISNULL (T2.CONDITIONCODE,'NOTVALID')    AND ISNULL (T1.BINNUM ,'NOTVALID')=  ISNULL (T2.TOBIN ,'NOTVALID')      AND ISNULL (T1.LOTNUM ,'NOTVALID')= ISNULL(T2.TOLOT ,'NOTVALID')   ";	
				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,STORELOC,BINNUM ,LOTNUM , CONDITIONCODE,ISNULL(SUM(QUANTITY),0) AS IQTY,ISNULL(SUM(-LINECOST),0) AS IVALUE ,SITEID,ORGID FROM MATUSETRANS  WHERE CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5) AND  STORELOC IS NOT NULL GROUP BY ITEMNUM,STORELOC,SITEID,ORGID,BINNUM,LOTNUM ,CONDITIONCODE)T3  ";
				invReconDiff=invReconDiff+"		ON	  T1.ITEMNUM = T3.ITEMNUM AND T1.LOCATION = T3.STORELOC AND T1.SITEID= T3.SITEID AND  ISNULL(T1.CONDITIONCODE ,'NOTVALID')= ISNULL (T3.CONDITIONCODE ,'NOTVALID')    AND ISNULL (T1.BINNUM ,'NOTVALID') = ISNULL (T3.BINNUM ,'NOTVALID')      AND  ISNULL (T1.LOTNUM,'NOTVALID')=  ISNULL(T3.LOTNUM,'NOTVALID')  ";					
				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,STORELOC,BINNUM , LOTNUM ,CONDITIONCODE ,ISNULL(SUM(QUANTITY),0) AS ADJQTY,ISNULL(SUM(LINECOST),0) AS ADJVALUE,SITEID,ORGID FROM INVTRANS  WHERE CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5) AND STORELOC IS NOT NULL AND TRANSTYPE  IN  ('CURBALADJ','RECBALADJ') GROUP BY ITEMNUM,STORELOC,SITEID,ORGID,BINNUM, LOTNUM ,CONDITIONCODE)T4  ";
				invReconDiff=invReconDiff+"ON	 T1.ITEMNUM = T4.ITEMNUM AND T1.LOCATION = T4.STORELOC AND T1.SITEID= T4.SITEID  AND ISNULL(T1.CONDITIONCODE ,'NOTVALID') = ISNULL (T4.CONDITIONCODE,'NOTVALID')  AND ISNULL (T1.BINNUM ,'NOTVALID')= ISNULL (T4.BINNUM ,'NOTVALID')      AND ISNULL(T1.LOTNUM,'NOTVALID')= ISNULL(T4.LOTNUM,'NOTVALID')   ";
				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,LOCATION, BINNUM , LOTNUM  ,  CONDITIONCODE ,ISNULL(SUM(CURBAL),0)AS OPBAL, ISNULL(SUM(CURBAL * AVGCOST ),0)AS OPVAL,  SITEID,ORGID FROM INVDAILYBAL  WHERE  CONVERT(DATETIME,TDATE,5)=CONVERT(DATETIME,getdate(),5)-"+days+" AND LOCATION IS NOT NULL GROUP BY ITEMNUM,LOCATION,SITEID,ORGID, BINNUM , LOTNUM, CONDITIONCODE)T5  ";
				invReconDiff=invReconDiff+"  	ON	 T1.ITEMNUM = T5.ITEMNUM AND T1.LOCATION = T5.LOCATION  AND T1.SITEID= T5.SITEID   AND ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T5.CONDITIONCODE,'NOTVALID')    AND ISNULL(T1.BINNUM,'NOTVALID')= ISNULL(T5.BINNUM,'NOTVALID')       AND ISNULL(T1.LOTNUM,'NOTVALID')= ISNULL(T5.LOTNUM,'NOTVALID')  ";
				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,LOCATION, BINNUM , LOTNUM , CONDITIONCODE ,ISNULL(SUM(CURBAL),0)AS CLOSEBAL, ISNULL(SUM(CURBAL * AVGCOST ),0)AS CLOSEVAL, SITEID,ORGID FROM INVDAILYBAL  WHERE  CONVERT(DATETIME,TDATE,5)=CONVERT(DATETIME,getdate(),5) AND LOCATION IS NOT NULL GROUP BY ITEMNUM,LOCATION,SITEID,ORGID,BINNUM, LOTNUM ,CONDITIONCODE)T6 ";  
				invReconDiff=invReconDiff+"		ON	 T1.ITEMNUM = T6.ITEMNUM  AND T1.LOCATION = T6.LOCATION  AND T1.SITEID= T6.SITEID  AND ISNULL(T1.CONDITIONCODE ,'NOTVALID')= ISNULL(T6.CONDITIONCODE,'NOTVALID')   AND ISNULL(T1.BINNUM,'NOTVALID')= ISNULL(T6.BINNUM,'NOTVALID')       AND ISNULL(T1.LOTNUM,'NOTVALID')= ISNULL(T6.LOTNUM,'NOTVALID')   ";
				invReconDiff=invReconDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,TOSTORELOC,TOBIN , TOLOT  ,CONDITIONCODE,ISNULL(sum(QUANTITY),0)R2QTY,SUM (LINECOST) AS R2VALUE,SITEID,ORGID FROM MATRECTRANS WHERE CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5) AND ISSUETYPE IN ('RECEIPT','RETURN') AND TOSTORELOC IS NOT NULL  AND TOSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') GROUP BY ITEMNUM,TOSTORELOC,SITEID,ORGID,TOBIN,TOLOT,CONDITIONCODE)T7   ";
				invReconDiff=invReconDiff+"ON    T1.ITEMNUM = T7.ITEMNUM AND T1.LOCATION = T7.TOSTORELOC AND T1.SITEID= T7.SITEID AND ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T7.CONDITIONCODE,'NOTVALID') AND ISNULL(T1.BINNUM,'NOTVALID')= ISNULL(T7.TOBIN,'NOTVALID')      AND ISNULL(T1.LOTNUM,'NOTVALID')= ISNULL(T7.TOLOT,'NOTVALID')    ";   
				invReconDiff=invReconDiff+" LEFT OUTER JOIN (select ITEMNUM,ORGID , fromsiteid ,fromstoreloc,frombin , fromlot ,FROMCONDITIONCODE , ISNULL(SUM(-QUANTITY),0)transout , ";
				invReconDiff=invReconDiff+"SUM (-LINECOST) AS TRANSOUTVALUE from ";
				invReconDiff=invReconDiff+"(SELECT itemnum , FROMCONDITIONCODE  ,  TOSTORELOC , FROMSTORELOC , FROMSITEID , siteid , Frombin ,tobin , Fromlot , tolot , ORGID , QUANTITY , LINECOST   FROM MATRECTRANS WHERE  ";
				invReconDiff=invReconDiff+"ISSUETYPE ='TRANSFER' AND PONUM IS NULL AND FROMSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') AND ";
				invReconDiff=invReconDiff+"CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5)  ";
				invReconDiff=invReconDiff+") TRANSFEROUT WHERE   (  ((fromsiteid =siteid)  OR  (fromsiteid !=siteid) )    AND  (  ";
				invReconDiff=invReconDiff+"( ((fromstoreloc =tostoreloc) OR (fromstoreloc !=tostoreloc) )  AND(( ( ISNULL(frombin,'NOTVALID')= ISNULL(tobin,'NOTVALID') OR ISNULL( frombin,'NOTVALID') != ISNULL(tobin ,'NOTVALID' )) and ( ISNULL (fromlot,'NOTVALID') = ISNULL(TOlot ,'NOTVALID') OR ISNULL(fromlot , 'NOTVALID') !=ISNULL(TOlot, 'NOTVALID') )))) ";
				invReconDiff=invReconDiff+")  ) GROUP BY ITEMNUM, orgid , fromsiteid ,fromstoreloc, frombin , fromlot ,FROMCONDITIONCODE)T8 ";
				invReconDiff=invReconDiff+"ON	 T1.ITEMNUM = T8.ITEMNUM  AND T1.LOCATION = T8.FROMSTORELOC AND T1.SITEID= T8.FROMSITEID AND ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T8.FROMCONDITIONCODE,'NOTVALID')  AND ISNULL(T1.BINNUM,'NOTVALID')= ISNULL(T8.FROMBIN,'NOTVALID')     AND ISNULL(T1.LOTNUM,'NOTVALID')= ISNULL(T8.FROMLOT,'NOTVALID')  ";    
				invReconDiff=invReconDiff+" LEFT OUTER JOIN (select ITEMNUM,ORGID , siteid ,tostoreloc,tobin , tolot ,CONDITIONCODE , ISNULL(SUM(QUANTITY),0)transin, SUM (LINECOST) AS TRANSINVALUE  ";
				invReconDiff=invReconDiff+"from   (SELECT itemnum ,  CONDITIONCODE  ,  TOSTORELOC , FROMSTORELOC , FROMSITEID , siteid , Frombin ,tobin , Fromlot ,tolot , ORGID , QUANTITY , LINECOST   FROM MATRECTRANS WHERE   ";
				invReconDiff=invReconDiff+"ISSUETYPE ='TRANSFER' AND PONUM IS NULL AND FROMSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') AND  "; 
				invReconDiff=invReconDiff+"CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5)) TRANSFERIN WHERE   ";
				invReconDiff=invReconDiff+"(  ((fromsiteid =siteid)  OR  (fromsiteid !=siteid) )    AND  (  ";
				invReconDiff=invReconDiff+"( ((fromstoreloc =tostoreloc) OR (fromstoreloc !=tostoreloc) )  AND((  ";
				invReconDiff=invReconDiff+" ( ISNULL(frombin,'NOTVALID')= ISNULL(tobin,'NOTVALID') OR ISNULL(frombin,'NOTVALID') != ISNULL(tobin,'NOTVALID') ) and ( ISNULL(fromlot,'NOTVALID') = ISNULL(TOlot,'NOTVALID') OR ISNULL(fromlot,'NOTVALID')  != ISNULL (TOlot,'NOTVALID')))))  ";
				invReconDiff=invReconDiff+")  ) GROUP BY ITEMNUM,orgid , siteid ,tostoreloc,tobin , tolot ,CONDITIONCODE)T9   ";
				invReconDiff=invReconDiff+"ON    T1.ITEMNUM = T9.ITEMNUM  AND T1.LOCATION = T9.TOSTORELOC AND T1.SITEID= T9.SITEID AND   ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T9.CONDITIONCODE,'NOTVALID')       AND ISNULL(T1.BINNUM,'NOTVALID')= ISNULL(T9.TOBIN,'NOTVALID')      AND ISNULL(T1.LOTNUM,'NOTVALID')= ISNULL(T9.TOLOT,'NOTVALID')  ";
				invReconDiff=invReconDiff+") WHERE LOCATION  LIKE '%STORE%' ) WHERE RESULTBAL ='N')	";		
				
				

//				invReconCostDiff="INSERT INTO INVCHECK(ITEMNUM,LOCATION,SITEID,ORGID,CONDITIONCODE,TRANSFEROUTQTY,TRANSFEROUTVALUE ,TRANSFERINQTY ,TRANSFERINVALUE ,RECEIPTSQTY,RECEIPTSVALUE,ISSUESQTY ,ISSUESVALUE, ADJUSTQTY , ADJUSTVALUE , OPENINGBAL ,CLOSINGBAL ,OPENINGVALUE,CLOSINGVALUE,FROMDATE,TODATE,INVCHECKID ,NETDIFFERENCE , MISMATCHTYPE) ";
//				invReconCostDiff=invReconCostDiff+"(SELECT ITEMNUM ,LOCATION,SITEID,ORGID, CONDITIONCODE, TOUT,TOUTVALUE,  TIN ,TINVALUE,RECEIPTSQTY,RECEIPTSVALUE,ISSQTY,ISSVALUE, AQTY,AVALUE, OBAL,CLOSEBAL, OVAL,CLOSEVAL, ( TO_DATE(SYSDATE-"+days+" ,'DD-MM-YY'))   AS FROMDATE,(TO_DATE(SYSDATE ,'DD-MM-YY') -  (1 / 86400) ) AS TODATE,INVCHECKIDSEQ.NEXTVAL , NETDIFFERENCE , MISMATCHTYPE ";
//				invReconCostDiff=invReconCostDiff+"FROM  (   SELECT ITEMNUM ,LOCATION,SITEID,ORGID,CONDITIONCODE, tout,TOUTVALUE,  tin ,TINVALUE, (REC1QTY + REC2QTY ) AS RECEIPTSQTY, (REC1VALUE +REC2VALUE ) AS RECEIPTSVALUE ,ISSQTY,ISSVALUE, AQTY,AVALUE, OBAL,CLOSEBAL, OVAL,CLOSEVAL ,   "; 
//				invReconCostDiff=invReconCostDiff+"DECODE((REC1VALUE +REC2VALUE +ISSVALUE+AVALUE+TOUTVALUE+TINVALUE+OVAL)-CLOSEVAL,0,'Y','N')RESULTVAL ,  ABS (REC1VALUE +REC2VALUE +ISSVALUE+AVALUE+TOUTVALUE+TINVALUE+OVAL-CLOSEVAL) AS NETDIFFERENCE , 'COST' AS MISMATCHTYPE      ";
//				invReconCostDiff=invReconCostDiff+"FROM (   SELECT  T1.ITEMNUM,T1.LOCATION,T1.SITEID,T1.ORGID , T1.CONDITIONCODE , NVL(T2.R1QTY,0)REC1QTY , NVL(T2.R1VALUE,0)REC1VALUE ,  NVL(T7.R2QTY,0)REC2QTY , NVL(T7.R2VALUE,0)REC2VALUE ,  NVL(T3.IQTY,0)ISSQTY, NVL(T3.IVALUE,0)ISSVALUE,  ";
//				invReconCostDiff=invReconCostDiff+"nvl(T8.transout,0)tout,nvl(T9.transin,0)tin ,nvl(T8.TRANSOUTVALUE,0)TOUTVALUE,nvl(T9.TRANSINVALUE,0)TINVALUE ,NVL(T4.ADJQTY,0)AQTY , NVL(T4.ADJVALUE,0)AVALUE ,  NVL(T5.OPBAL,0)OBAL,NVL(T6.CLOSEBAL,0)CLOSEBAL ,   NVL(T5.OPVAL,0)OVAL,NVL(T6.CLOSEVAL,0)CLOSEVAL   ";
//				invReconCostDiff=invReconCostDiff+"FROM  (SELECT DISTINCT ITEMNUM,LOCATION,SITEID,ORGID , CONDITIONCODE  FROM INVBALANCES  WHERE LOCATION LIKE '%STORE%') T1   ";
//				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,TOSTORELOC,  CONDITIONCODE,NVL(SUM(QUANTITY),0) AS R1QTY,  SUM (LINECOST) AS R1VALUE ,SITEID,ORGID FROM MATRECTRANS  WHERE TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY') AND ISSUETYPE='TRANSFER' AND FROMSTORELOC IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') GROUP BY ITEMNUM,TOSTORELOC,SITEID,ORGID,CONDITIONCODE)T2   ";
//				invReconCostDiff=invReconCostDiff+"ON     T1.ITEMNUM = T2.ITEMNUM  AND T1.LOCATION = T2.TOSTORELOC AND T1.SITEID= T2.SITEID AND nvl(T1.CONDITIONCODE,'NOTVALID') = nvl(T2.CONDITIONCODE,'NOTVALID')   ";
//				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,STORELOC,  CONDITIONCODE,NVL(SUM(QUANTITY),0) AS IQTY,NVL(SUM(-LINECOST),0) AS IVALUE ,SITEID,ORGID FROM MATUSETRANS  WHERE TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY') AND  STORELOC IS NOT NULL GROUP BY ITEMNUM,STORELOC,SITEID,ORGID,CONDITIONCODE)T3  ";
//				invReconCostDiff=invReconCostDiff+"ON	  T1.ITEMNUM = T3.ITEMNUM  AND T1.LOCATION = T3.STORELOC AND T1.SITEID= T3.SITEID AND nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T3.CONDITIONCODE,'NOTVALID')  ";
//				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,STORELOC, CONDITIONCODE ,NVL(SUM(QUANTITY),0) AS ADJQTY,NVL(SUM(LINECOST),0) AS ADJVALUE,SITEID,ORGID FROM INVTRANS  WHERE TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY') AND STORELOC IS NOT NULL AND TRANSTYPE  IN  ( 'AVGCSTADJ' , 'CURBALADJ','RECBALADJ') GROUP BY ITEMNUM,STORELOC,SITEID,ORGID ,CONDITIONCODE)T4 ";
//				invReconCostDiff=invReconCostDiff+"ON 	  T1.ITEMNUM = T4.ITEMNUM  AND T1.LOCATION = T4.STORELOC AND T1.SITEID= T4.SITEID  AND nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T4.CONDITIONCODE,'NOTVALID')    ";
//				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,LOCATION, CONDITIONCODE ,NVL(SUM(CURBAL),0)AS OPBAL, NVL(SUM(CURBAL * AVGCOST ),0)AS OPVAL,  SITEID,ORGID FROM INVDAILYBAL  WHERE  TO_DATE(TDATE ,'DD-MM-YY')=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND LOCATION IS NOT NULL GROUP BY ITEMNUM,LOCATION,SITEID,ORGID, CONDITIONCODE)T5  ";
//				invReconCostDiff=invReconCostDiff+"ON	  T1.ITEMNUM = T5.ITEMNUM  AND T1.LOCATION = T5.LOCATION AND T1.SITEID= T5.SITEID  AND nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T5.CONDITIONCODE,'NOTVALID')   ";
//				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,LOCATION,  CONDITIONCODE ,NVL(SUM(CURBAL),0)AS CLOSEBAL, NVL(SUM(CURBAL * AVGCOST ),0)AS CLOSEVAL, SITEID,ORGID FROM INVDAILYBAL  WHERE  TO_DATE(TDATE ,'DD-MM-YY')=TO_DATE(SYSDATE ,'DD-MM-YY') AND LOCATION IS NOT NULL GROUP BY ITEMNUM,LOCATION,SITEID,ORGID,CONDITIONCODE)T6 ";  
//				invReconCostDiff=invReconCostDiff+"ON	  T1.ITEMNUM = T6.ITEMNUM  AND T1.LOCATION = T6.LOCATION AND T1.SITEID= T6.SITEID AND nvl(T1.CONDITIONCODE,'NOTVALID') = nvl(T6.CONDITIONCODE,'NOTVALID')  ";
//				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,TOSTORELOC, CONDITIONCODE,NVL(sum(QUANTITY),0)R2QTY,SUM (LINECOST) AS R2VALUE,SITEID,ORGID FROM MATRECTRANS WHERE TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY') AND ISSUETYPE IN ('RECEIPT','RETURN') AND TOSTORELOC IS NOT NULL  AND TOSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') GROUP BY ITEMNUM,TOSTORELOC,SITEID,ORGID,CONDITIONCODE)T7   ";
//				invReconCostDiff=invReconCostDiff+"ON 	  T1.ITEMNUM = T7.ITEMNUM  AND T1.LOCATION = T7.TOSTORELOC AND T1.SITEID= T7.SITEID AND  nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T7.CONDITIONCODE,'NOTVALID')  ";   
//				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (select ITEMNUM,ORGID , fromsiteid ,fromstoreloc,FROMCONDITIONCODE , NVL(SUM(-QUANTITY),0)transout , SUM (-LINECOST) AS TRANSOUTVALUE from ";
//				invReconCostDiff=invReconCostDiff+"(SELECT itemnum , FROMCONDITIONCODE  ,  TOSTORELOC , FROMSTORELOC , FROMSITEID , siteid , ORGID , QUANTITY , LINECOST   FROM MATRECTRANS WHERE  ";
//				invReconCostDiff=invReconCostDiff+"ISSUETYPE ='TRANSFER' AND PONUM IS NULL AND FROMSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') AND ";
//				invReconCostDiff=invReconCostDiff+"TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY')  ";
//				invReconCostDiff=invReconCostDiff+") TRANSFEROUT WHERE   (  ((fromsiteid =siteid)  OR  (fromsiteid !=siteid) )    AND  (  ( (fromstoreloc =tostoreloc) OR (fromstoreloc !=tostoreloc)   )  ";
//				invReconCostDiff=invReconCostDiff+")  ) GROUP BY ITEMNUM, orgid , fromsiteid ,fromstoreloc,FROMCONDITIONCODE)T8 ";
//				invReconCostDiff=invReconCostDiff+"ON 	  T1.ITEMNUM = T8.ITEMNUM  AND T1.LOCATION = T8.FROMSTORELOC AND T1.SITEID= T8.FROMSITEID AND nvl(T1.CONDITIONCODE ,'NOTVALID')= nvl(T8.FROMCONDITIONCODE,'NOTVALID')    ";    
//				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (select ITEMNUM,ORGID , siteid ,tostoreloc,CONDITIONCODE , NVL(SUM(QUANTITY),0)transin, SUM (LINECOST) AS TRANSINVALUE  ";
//				invReconCostDiff=invReconCostDiff+"from   (SELECT itemnum , CONDITIONCODE  ,  TOSTORELOC , FROMSTORELOC , FROMSITEID , siteid , ORGID , QUANTITY , LINECOST   FROM MATRECTRANS WHERE   ";
//				invReconCostDiff=invReconCostDiff+"ISSUETYPE ='TRANSFER' AND PONUM IS NULL AND FROMSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') AND  "; 
//				invReconCostDiff=invReconCostDiff+"TO_DATE(TRANSDATE ,'DD-MM-YY')>=TO_DATE(SYSDATE ,'DD-MM-YY')-"+days+" AND TO_DATE(TRANSDATE ,'DD-MM-YY')<TO_DATE(SYSDATE ,'DD-MM-YY')  ";
//				invReconCostDiff=invReconCostDiff+") TRANSFERIN WHERE  ";
//				invReconCostDiff=invReconCostDiff+"(  ((fromsiteid =siteid)  OR  (fromsiteid !=siteid) )    AND  (   (fromstoreloc =tostoreloc) OR (fromstoreloc !=tostoreloc)     ";
//				invReconCostDiff=invReconCostDiff+")  ) GROUP BY ITEMNUM,orgid , siteid ,tostoreloc,CONDITIONCODE)T9   ";
//				invReconCostDiff=invReconCostDiff+"ON	  T1.ITEMNUM = T9.ITEMNUM  AND T1.LOCATION = T9.TOSTORELOC AND T1.SITEID= T9.SITEID AND   nvl(T1.CONDITIONCODE,'NOTVALID')= nvl(T9.CONDITIONCODE,'NOTVALID')   ";
//				invReconCostDiff=invReconCostDiff+") WHERE LOCATION  LIKE '%STORE%' ) WHERE RESULTVAL ='N')	";		
			
				maxreserve=maxreserve+1;
				invReconCostDiff="INSERT INTO INVCHECK(ITEMNUM,LOCATION,SITEID,ORGID,CONDITIONCODE,TRANSFEROUTQTY,TRANSFEROUTVALUE ,TRANSFERINQTY ,TRANSFERINVALUE ,RECEIPTSQTY,RECEIPTSVALUE,ISSUESQTY ,ISSUESVALUE, ADJUSTQTY , ADJUSTVALUE , OPENINGBAL ,CLOSINGBAL ,OPENINGVALUE,CLOSINGVALUE,FROMDATE,TODATE,INVCHECKID ,NETDIFFERENCE , MISMATCHTYPE) ";
				invReconCostDiff=invReconCostDiff+"(SELECT ITEMNUM ,LOCATION,SITEID,ORGID, CONDITIONCODE, TOUT,TOUTVALUE,  TIN ,TINVALUE,RECEIPTSQTY,RECEIPTSVALUE,ISSQTY,ISSVALUE, AQTY,AVALUE, OBAL,CLOSEBAL, OVAL,CLOSEVAL, (CONVERT(DATETIME,getdate()-"+days+",5))  AS FROMDATE,(CONVERT(DATETIME,getdate() -  (1 / 86400),5)) AS TODATE,"+maxreserve+" , NETDIFFERENCE , MISMATCHTYPE ";
				invReconCostDiff=invReconCostDiff+"FROM  (   SELECT ITEMNUM ,LOCATION,SITEID,ORGID,CONDITIONCODE, tout,TOUTVALUE,  tin ,TINVALUE, (REC1QTY + REC2QTY ) AS RECEIPTSQTY, (REC1VALUE +REC2VALUE ) AS RECEIPTSVALUE ,ISSQTY,ISSVALUE, AQTY,AVALUE, OBAL,CLOSEBAL, OVAL,CLOSEVAL ,   "; 
				invReconCostDiff=invReconCostDiff+"CASE 	WHEN (REC1VALUE +REC2VALUE +ISSVALUE+AVALUE+TOUTVALUE+TINVALUE+OVAL)-CLOSEVAL	 THEN 'Y' 	ELSE 'N' 	END AS RESULTVAL ,  ABS (REC1VALUE +REC2VALUE +ISSVALUE+AVALUE+TOUTVALUE+TINVALUE+OVAL-CLOSEVAL) AS NETDIFFERENCE , 'COST' AS MISMATCHTYPE      ";
				invReconCostDiff=invReconCostDiff+"FROM (   SELECT  T1.ITEMNUM,T1.LOCATION,T1.SITEID,T1.ORGID , T1.CONDITIONCODE , ISNULL(T2.R1QTY,0)REC1QTY , ISNULL(T2.R1VALUE,0)REC1VALUE ,  ISNULL(T7.R2QTY,0)REC2QTY , ISNULL(T7.R2VALUE,0)REC2VALUE ,  ISNULL(T3.IQTY,0)ISSQTY, ISNULL(T3.IVALUE,0)ISSVALUE,  ";
				invReconCostDiff=invReconCostDiff+"ISNULL(T8.transout,0)tout,ISNULL(T9.transin,0)tin ,ISNULL(T8.TRANSOUTVALUE,0)TOUTVALUE,ISNULL(T9.TRANSINVALUE,0)TINVALUE ,ISNULL(T4.ADJQTY,0)AQTY , ISNULL(T4.ADJVALUE,0)AVALUE ,  ISNULL(T5.OPBAL,0)OBAL,ISNULL(T6.CLOSEBAL,0)CLOSEBAL ,   ISNULL(T5.OPVAL,0)OVAL,ISNULL(T6.CLOSEVAL,0)CLOSEVAL   ";
				invReconCostDiff=invReconCostDiff+"FROM  (SELECT DISTINCT ITEMNUM,LOCATION,SITEID,ORGID , CONDITIONCODE  FROM INVBALANCES  WHERE LOCATION LIKE '%STORE%') T1   ";
				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,TOSTORELOC,  CONDITIONCODE,ISNULL(SUM(QUANTITY),0) AS R1QTY,  SUM (LINECOST) AS R1VALUE ,SITEID,ORGID FROM MATRECTRANS  WHERE CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5) AND ISSUETYPE='TRANSFER' AND FROMSTORELOC IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') GROUP BY ITEMNUM,TOSTORELOC,SITEID,ORGID,CONDITIONCODE)T2   ";
				invReconCostDiff=invReconCostDiff+"ON     T1.ITEMNUM = T2.ITEMNUM  AND T1.LOCATION = T2.TOSTORELOC AND T1.SITEID= T2.SITEID AND ISNULL(T1.CONDITIONCODE,'NOTVALID') = ISNULL(T2.CONDITIONCODE,'NOTVALID')   ";
				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,STORELOC,  CONDITIONCODE,ISNULL(SUM(QUANTITY),0) AS IQTY,ISNULL(SUM(-LINECOST),0) AS IVALUE ,SITEID,ORGID FROM MATUSETRANS  WHERE CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5) AND  STORELOC IS NOT NULL GROUP BY ITEMNUM,STORELOC,SITEID,ORGID,CONDITIONCODE)T3  ";
				invReconCostDiff=invReconCostDiff+"ON	  T1.ITEMNUM = T3.ITEMNUM  AND T1.LOCATION = T3.STORELOC AND T1.SITEID= T3.SITEID AND ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T3.CONDITIONCODE,'NOTVALID')  ";
				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,STORELOC, CONDITIONCODE ,ISNULL(SUM(QUANTITY),0) AS ADJQTY,ISNULL(SUM(LINECOST),0) AS ADJVALUE,SITEID,ORGID FROM INVTRANS  WHERE CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5) AND STORELOC IS NOT NULL AND TRANSTYPE  IN  ( 'AVGCSTADJ' , 'CURBALADJ','RECBALADJ') GROUP BY ITEMNUM,STORELOC,SITEID,ORGID ,CONDITIONCODE)T4 ";
				invReconCostDiff=invReconCostDiff+"ON 	  T1.ITEMNUM = T4.ITEMNUM  AND T1.LOCATION = T4.STORELOC AND T1.SITEID= T4.SITEID  AND ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T4.CONDITIONCODE,'NOTVALID')    ";
				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,LOCATION, CONDITIONCODE ,ISNULL(SUM(CURBAL),0)AS OPBAL, ISNULL(SUM(CURBAL * AVGCOST ),0)AS OPVAL,  SITEID,ORGID FROM INVDAILYBAL  WHERE  CONVERT(DATETIME,TDATE,5)=CONVERT(DATETIME,getdate(),5)-"+days+" AND LOCATION IS NOT NULL GROUP BY ITEMNUM,LOCATION,SITEID,ORGID, CONDITIONCODE)T5  ";
				invReconCostDiff=invReconCostDiff+"ON	  T1.ITEMNUM = T5.ITEMNUM  AND T1.LOCATION = T5.LOCATION AND T1.SITEID= T5.SITEID  AND ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T5.CONDITIONCODE,'NOTVALID')   ";
				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,LOCATION,  CONDITIONCODE ,ISNULL(SUM(CURBAL),0)AS CLOSEBAL, ISNULL(SUM(CURBAL * AVGCOST ),0)AS CLOSEVAL, SITEID,ORGID FROM INVDAILYBAL  WHERE  CONVERT(DATETIME,TDATE,5)=CONVERT(DATETIME,getdate(),5) AND LOCATION IS NOT NULL GROUP BY ITEMNUM,LOCATION,SITEID,ORGID,CONDITIONCODE)T6 ";  
				invReconCostDiff=invReconCostDiff+"ON	  T1.ITEMNUM = T6.ITEMNUM  AND T1.LOCATION = T6.LOCATION AND T1.SITEID= T6.SITEID AND ISNULL(T1.CONDITIONCODE,'NOTVALID') = ISNULL(T6.CONDITIONCODE,'NOTVALID')  ";
				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (SELECT ITEMNUM,TOSTORELOC, CONDITIONCODE,ISNULL(sum(QUANTITY),0)R2QTY,SUM (LINECOST) AS R2VALUE,SITEID,ORGID FROM MATRECTRANS WHERE CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5) AND ISSUETYPE IN ('RECEIPT','RETURN') AND TOSTORELOC IS NOT NULL  AND TOSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') GROUP BY ITEMNUM,TOSTORELOC,SITEID,ORGID,CONDITIONCODE)T7   ";
				invReconCostDiff=invReconCostDiff+"ON 	  T1.ITEMNUM = T7.ITEMNUM  AND T1.LOCATION = T7.TOSTORELOC AND T1.SITEID= T7.SITEID AND  ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T7.CONDITIONCODE,'NOTVALID')  ";   
				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (select ITEMNUM,ORGID , fromsiteid ,fromstoreloc,FROMCONDITIONCODE , ISNULL(SUM(-QUANTITY),0)transout , SUM (-LINECOST) AS TRANSOUTVALUE from ";
				invReconCostDiff=invReconCostDiff+"(SELECT itemnum , FROMCONDITIONCODE  ,  TOSTORELOC , FROMSTORELOC , FROMSITEID , siteid , ORGID , QUANTITY , LINECOST   FROM MATRECTRANS WHERE  ";
				invReconCostDiff=invReconCostDiff+"ISSUETYPE ='TRANSFER' AND PONUM IS NULL AND FROMSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') AND ";
				invReconCostDiff=invReconCostDiff+"CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5)  ";
				invReconCostDiff=invReconCostDiff+") TRANSFEROUT WHERE   (  ((fromsiteid =siteid)  OR  (fromsiteid !=siteid) )    AND  (  ( (fromstoreloc =tostoreloc) OR (fromstoreloc !=tostoreloc)   )  ";
				invReconCostDiff=invReconCostDiff+")  ) GROUP BY ITEMNUM, orgid , fromsiteid ,fromstoreloc,FROMCONDITIONCODE)T8 ";
				invReconCostDiff=invReconCostDiff+"ON 	  T1.ITEMNUM = T8.ITEMNUM  AND T1.LOCATION = T8.FROMSTORELOC AND T1.SITEID= T8.FROMSITEID AND ISNULL(T1.CONDITIONCODE ,'NOTVALID')= ISNULL(T8.FROMCONDITIONCODE,'NOTVALID')    ";    
				invReconCostDiff=invReconCostDiff+" LEFT OUTER JOIN (select ITEMNUM,ORGID , siteid ,tostoreloc,CONDITIONCODE , ISNULL(SUM(QUANTITY),0)transin, SUM (LINECOST) AS TRANSINVALUE  ";
				invReconCostDiff=invReconCostDiff+"from   (SELECT itemnum , CONDITIONCODE  ,  TOSTORELOC , FROMSTORELOC , FROMSITEID , siteid , ORGID , QUANTITY , LINECOST   FROM MATRECTRANS WHERE   ";
				invReconCostDiff=invReconCostDiff+"ISSUETYPE ='TRANSFER' AND PONUM IS NULL AND FROMSTORELOC NOT IN (SELECT DISTINCT LOCATION FROM LOCATIONS WHERE TYPE='HOLDING') AND  "; 
				invReconCostDiff=invReconCostDiff+"CONVERT(DATETIME,TRANSDATE,5)>=CONVERT(DATETIME,getdate(),5)-"+days+" AND CONVERT(DATETIME,TRANSDATE,5)<CONVERT(DATETIME,getdate(),5)  ";
				invReconCostDiff=invReconCostDiff+") TRANSFERIN WHERE  ";
				invReconCostDiff=invReconCostDiff+"(  ((fromsiteid =siteid)  OR  (fromsiteid !=siteid) )    AND  (   (fromstoreloc =tostoreloc) OR (fromstoreloc !=tostoreloc)     ";
				invReconCostDiff=invReconCostDiff+")  ) GROUP BY ITEMNUM,orgid , siteid ,tostoreloc,CONDITIONCODE)T9   ";
				invReconCostDiff=invReconCostDiff+"ON	  T1.ITEMNUM = T9.ITEMNUM  AND T1.LOCATION = T9.TOSTORELOC AND T1.SITEID= T9.SITEID AND   ISNULL(T1.CONDITIONCODE,'NOTVALID')= ISNULL(T9.CONDITIONCODE,'NOTVALID')   ";
				invReconCostDiff=invReconCostDiff+") WHERE LOCATION  LIKE '%STORE%' ) WHERE RESULTVAL ='N')	";
				
				SqlFormat invReconDiffSql=new SqlFormat(invReconDiff);
				dbShortcut.executeQuery(invReconDiffSql.format());
				dbShortcut.commit();
				
				SqlFormat invReconDiffCostSql=new SqlFormat(invReconCostDiff);
				dbShortcut.executeQuery(invReconDiffCostSql.format());
				dbShortcut.commit();
			
				mxLog.writeLog("Inventory Transaction Reconcilation Quantity-wise check query:  "+invReconDiff+"*** \n" );
				mxLog.writeLog("Inventory Transaction Reconcilation Cost-wise query:  "+invReconCostDiff  +"*** \n"   );
			
				itemReconSet=dbShortcut.executeQuery("Select ITEMNUM, SITEID, ORGID, CONDITIONCODE, ADJUSTQTY, ADJUSTVALUE, CLOSINGBAL, CLOSINGVALUE, to_char (FROMDATE , 'DD-MM-YYYY hh:mm:ss') AS FROMDATE, to_char (TODATE , 'DD-MM-YYYY hh:mm:ss') AS TODATE, ISSUESQTY, ISSUESVALUE, OPENINGBAL, OPENINGVALUE, RECEIPTSQTY, RECEIPTSVALUE, TRANSFERINQTY, TRANSFEROUTQTY, TRANSFERINVALUE, TRANSFEROUTVALUE, LOCATION, BINNUM, LOTNUM, NETDIFFERENCE,  CASE MISMATCHTYPE WHEN 'COST' THEN 'SGD'  ELSE 'Nos' END AS MISMATCHTYPE2 , MISMATCHTYPE   from INVCHECK WHERE CONDITIONCODE <> 'RECOND' AND MISMATCHTYPE ='QUANTITY' OR (MISMATCHTYPE ='COST' AND NETDIFFERENCE >"+tolerance+ ") ORDER BY MISMATCHTYPE DESC ");
				mxLog.writeLog("Inventory Reconcilation Cron Query execution completed:");
				// itemNum for E-mail alert , itemNumLog for Invcheck data to be written in  Log file 
					
				if(itemReconSet!=null)
				{
					while(itemReconSet.next())
					{
						String itemNumber=itemReconSet.getString("ITEMNUM");
						String mismatchType=itemReconSet.getString("MISMATCHTYPE");
						String mismatchType2=itemReconSet.getString("MISMATCHTYPE2");
						String siteid=itemReconSet.getString("SITEID");
						String conditionCode=itemReconSet.getString("CONDITIONCODE");
						String location=itemReconSet.getString("LOCATION");
						String binnum=itemReconSet.getString("BINNUM");
						String lotnum=itemReconSet.getString("LOTNUM");
						String difference=itemReconSet.getString("NETDIFFERENCE");
						String orgid=itemReconSet.getString("ORGID");
						String adjustQty=itemReconSet.getString("ADJUSTQTY");
						String adjustValue=itemReconSet.getString("ADJUSTVALUE");
						String closingBal=itemReconSet.getString("CLOSINGBAL");
						String closingVal=itemReconSet.getString("CLOSINGVALUE");
						String fromDate=itemReconSet.getString("FROMDATE");
						String toDate=itemReconSet.getString("TODATE");
						String issuesQty=itemReconSet.getString("ISSUESQTY");
						String issuesValue=itemReconSet.getString("ISSUESVALUE");
						String openingBal=itemReconSet.getString("OPENINGBAL");
						String openingVal=itemReconSet.getString("OPENINGVALUE");
						String receiptsQty=itemReconSet.getString("RECEIPTSQTY");
						String receiptsValue=itemReconSet.getString("RECEIPTSVALUE");
						String transferInQty=itemReconSet.getString("TRANSFERINQTY");
						String transferOutQty=itemReconSet.getString("TRANSFEROUTQTY");
						String transferInValue=itemReconSet.getString("TRANSFERINVALUE");
						String transferOutValue=itemReconSet.getString("TRANSFEROUTVALUE");
						
						itemNum="Item/Condition: "+itemNumber+"/"+conditionCode+" has a mismatch by "+difference+"-"+mismatchType2+" in Site: "+siteid+"  Location: "+location+"  Bin: "+binnum+"  Lot: "+lotnum+ " \n\r";
						
						itemNumLog =" ITEMNUM:"+itemNumber+" SITEID:"+siteid+" ORGID:"+orgid+" LOCATION:"+location+" CONDITIONCODE:"+conditionCode+" BINNUM:"+binnum+" LOTNUM:"+lotnum+ 
						" ADJUSTQTY:"+adjustQty+" ADJUSTVALUE:"+adjustValue+" CLOSINGBAL:"+closingBal+ " CLOSINGVALUE:"+closingVal+" FROMDATE:"+fromDate+" TODATE:"+toDate+
						" ISSUESQTY:"+issuesQty+ " ISSUESVALUE:"+issuesValue+ " OPENINGBAL:" +openingBal+ " OPENINGVALUE:"+openingVal+
						" RECEIPTSQTY:" +receiptsQty+ " RECEIPTSVALUE:" +receiptsValue+ " TRANSFERINQTY:"+transferInQty+ " TRANSFEROUTQTY:" +transferOutQty+
						" TRANSFERINVALUE:" +transferInValue+" TRANSFEROUTVALUE:"+transferOutValue+"  NETDIFFERENCE:"+difference+" MISMATCHTYPE:"+mismatchType+" **** \n \r   " ;
						
						reconItem.append(itemNum);
						
						reconItemLog.append(itemNumLog);														
					}
				}
				mxLog.writeLog("Invcheck Output : \n"+reconItemLog.toString()+ "\n" );			
			}				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			itemReconSet.close();
			MXServer.getMXServer().getDBManager().freeConnection(getRunasUserInfo().getConnectionKey());
			mxLog.writeLog("Inventory Inventory Reconciliation Cron Completed successfully");
			dbShortcut.close();
		  
		}
	}	
}
