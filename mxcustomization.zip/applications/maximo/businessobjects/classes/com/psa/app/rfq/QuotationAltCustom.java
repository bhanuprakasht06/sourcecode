/*
 * Modification history
 * 15-10-2007	AGD	eRFQ		Creation
 * 15-11-2012   LEWISS  EMS-533 [RFQ] RFQWF - New status BYPASS for buyers to handle exception RFQ scenario
 * 04-04-2013	WMJ		EMS-563	[RFQ]Allow deletion of quotes entered in BYPASS status so that a new RFQ is not required for wrong quotes entered 
 * 04-04-2013	WMJ		EMS-568	[RFQ]To default the unit cost and delivery date of quotation lines to zero so that ammendment by buyers are not required 
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;
import java.util.Iterator;

import psdi.app.rfq.RFQ;
import psdi.app.rfq.RFQVendor;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValueInfo;
import psdi.mbo.SqlFormat;
import psdi.app.rfq.QuotationLine;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class QuotationAltCustom extends QuotationLine
//QuotationLine
implements QuotationAltCustomRemote
{

public QuotationAltCustom(MboSet quotationlinealtset)
	throws MXException, RemoteException
{
super(quotationlinealtset);
}


public void add()
	throws MXException, RemoteException
{
	setValue("enterby", getUserInfo().getUserName(), MboConstantsCustom.DBSET);
	setValue("enterdate", MXServer.getMXServer().getDate(), MboConstantsCustom.DBSET);
	setValue("isawarded", false, MboConstantsCustom.DBSET);
	setValue("linetype", "!ITEM!", MboConstantsCustom.DBSET);
	setValue("selectedfordisplay", true, MboConstantsCustom.DBSET);
	setValue("eoq", 0.0D, MboConstantsCustom.DBSET);
	setValue("linecost", 0.0D, MboConstantsCustom.DBSET);
	setValue("alternate", true, MboConstantsCustom.DBSET);
}


public void save()
	throws MXException, RemoteException
{

        //Start of EMS-568 Shifted up on 03062015 by Raymond
        if((getInt("DELIVERYTIME")==0 || isNull("DELIVERYTIME")) && getDouble("UNITCOST")>0)
        {
                throw new MXApplicationException("rfq", "invaliddeliverytime");
        }
        //End of EMS-568

if (toBeDeleted())
{
	MboRemote rfqvendor = null;
	if (getOwner() instanceof RFQVendor)
		rfqvendor = getOwner();
	else
	{
		if((getMboValue("LINECOST").getMbo().getOwner().getOwner()) != null)
		{
			MboSetRemote rfqvendorset = getMboValue("linecost").getMbo().getOwner().getOwner().getMboSet("RFQVENDOR");
			for (int i = 0; (rfqvendor = rfqvendorset.getMbo(i)) != null; i++)
			{
				if (rfqvendor.getString("vendor").equals(getString("vendor")))
					break;
			}
		}
	}
	if(rfqvendor != null)
	{
		if (!rfqvendor.isNull("totalquotationamt"))
			rfqvendor.setValue("totalquotationamt", rfqvendor.getDouble("totalquotationamt") - getDouble("linecost"), MboConstantsCustom.NOACCESSCHECK);
	}
}

	//Start of EMS-568
        /**
        * Commented by Raymond and Shifted up on 03062015
	if((getInt("DELIVERYTIME")==0 || isNull("DELIVERYTIME")) && getDouble("UNITCOST")>0)
	{
		throw new MXApplicationException("rfq", "invaliddeliverytime");
	}*/
	//End of EMS-568

super.save();
}

public void init() throws MXException 
{
try
{
	if(getMboValue("rfqnum").getMbo().getOwner() != null)
	{
		super.init();
		MboRemote mboremote1 = null;
		
//		Get the RFQ remote
		if( ((getMboValue("rfqnum").getMbo()) != null) && ((getMboValue("rfqnum").getMbo().getName()).equalsIgnoreCase("RFQ")))
				mboremote1 = getMboValue("rfqnum").getMbo();
		
		else if( ((getMboValue("rfqnum").getMbo().getOwner()) != null) && ((getMboValue("rfqnum").getMbo().getOwner().getName()).equalsIgnoreCase("RFQ")))
				mboremote1 = getMboValue("rfqnum").getMbo().getOwner(); 
		
		else if( ((getMboValue("rfqnum").getMbo().getOwner().getOwner()) != null) && ((getMboValue("rfqnum").getMbo().getOwner().getOwner().getName()).equalsIgnoreCase("RFQ")))
				mboremote1 = getMboValue("rfqnum").getMbo().getOwner().getOwner(); //RFQ 
		
		else if( ((getMboValue("rfqnum").getMbo().getOwner().getOwner().getOwner()) != null) && ((getMboValue("rfqnum").getMbo().getOwner().getOwner().getOwner().getName()).equalsIgnoreCase("RFQ")))
				mboremote1 = getMboValue("rfqnum").getMbo().getOwner().getOwner().getOwner();
		
		
		String status=mboremote1.getString("STATUS");
		String currentuser = mboremote1.getUserName();
		int i=0;
	    boolean vendor = false;
	    //Check if the user belongs to Vendor group
	    MboSetRemote venodrgroupset = MXServer.getMXServer().getMboSet("GROUPUSER", getUserInfo());
		SqlFormat sql2 = new SqlFormat("GROUPNAME ='VENDORS'");
        venodrgroupset.setWhere(sql2.format());
         
	    for(MboRemote user = null; (user = venodrgroupset.getMbo(i)) != null; i++)
	    	if(user.getString("USERID").equalsIgnoreCase(currentuser))
	    		vendor =true;
	    
		//System.out.println("Alternate Quotations Init()--------------------RFQ : "+getString("rfqnum")+"-------------Status : "+status+"-----------Appn : ");
		
		//Begin change of std MX method
		if (!status.equalsIgnoreCase("SENT") && !status.equalsIgnoreCase("ESENT") && !status.equalsIgnoreCase("INPRG") && !status.equalsIgnoreCase("REOPEN"))
			//if(status.equalsIgnoreCase("WAWARD") || status.equalsIgnoreCase("REJECT-SH"))
			if(status.equalsIgnoreCase("WAWARD") || status.equalsIgnoreCase("REJECT-SH") || status.equalsIgnoreCase("REJECT-EM") || status.equalsIgnoreCase("EFINISHED"))
			{
				// Get list of fields and set them all to read-only except COMMENTS and isawarded
				//Iterator attributelist = mboremote.getThisMboSet().getMboSetInfo().getAttributes();
				Iterator attributelist = getMboSetInfo().getAttributes();
				while (attributelist.hasNext())
				{
					String attributename = ((MboValueInfo) attributelist.next()).getAttributeName();
					if (!attributename.equalsIgnoreCase("isawarded") && !attributename.equalsIgnoreCase("COMMENTS") && !attributename.equalsIgnoreCase("REJREASON"))
					{
						//mboremote.setFieldFlag(attributename, MboConstants.READONLY, false);
						setFieldFlag(attributename, MboConstantsCustom.READONLY, true);
					}
				}
				//mboremote.setFlag(7L, false); 
				setFlag(7L, false);
			}
			//else if(status.equalsIgnoreCase("WAPPR") || status.equalsIgnoreCase("REJECT-EM"))
			else if(status.equalsIgnoreCase("WAPPR") || status.equalsIgnoreCase("WAPPR-EM"))
			{
				// Get list of fields and set them all to read-only except COMMENTS and isawarded
				//Iterator attributelist = mboremote.getThisMboSet().getMboSetInfo().getAttributes();
				Iterator attributelist = getMboSetInfo().getAttributes();
				while (attributelist.hasNext())
				{
					String attributename = ((MboValueInfo) attributelist.next()).getAttributeName();
					if (!attributename.equalsIgnoreCase("COMMENTS") && !attributename.equalsIgnoreCase("REJREASON"))
					{
						//mboremote.setFieldFlag(attributename, MboConstants.READONLY, false);
						setFieldFlag(attributename, MboConstantsCustom.READONLY, true);
					}
				}
				//mboremote.setFlag(7L, false); 
				setFlag(7L, false);
			}
			//else if( status.equalsIgnoreCase("FINISHED") || status.equalsIgnoreCase("EFINISHED") || status.equalsIgnoreCase("REJECT-TO"))
			//else if( status.equalsIgnoreCase("AMEND"))
			//Start for EMS-533(added && !status.equalsIgnoreCase("BYPASS"))
			else if( status.equalsIgnoreCase("AMEND") || status.equalsIgnoreCase("BYPASS"))
			//End for EMS-533
			{
					if(vendor)
						setFlag(7L, true);
					else
						setFlag(7L, false);
			}	
			else
		//End change of std MX method
				//mboremote.setFlag(7L, true);
				setFlag(7L, true);
		/*
		//Set Remark field is compulsory for eRFQ Vendor appn
		if (status.equalsIgnoreCase("SENT") || status.equalsIgnoreCase("ESENT") || status.equalsIgnoreCase("AMEND"))
		{
			Iterator attributelist = getMboSetInfo().getAttributes();
			while (attributelist.hasNext())
			{
				String attributename = ((MboValueInfo) attributelist.next()).getAttributeName();
				if (attributename.equalsIgnoreCase("MEMO"))
				{
					setFieldFlag(attributename, MboConstantsCustom.REQUIRED, true);
				}
			}
		}*/
	}
}
catch(RemoteException remoteexception) { }
}

public void canDelete()
throws MXException, RemoteException
{
super.canDelete();

MboRemote mboremote = getMboSet("RFQ").getMbo(0);
RFQ rfq = (RFQ)mboremote;
//Start of EMS-563
//if(!rfq.getString("status").equalsIgnoreCase("SENT") && !rfq.getString("status").equalsIgnoreCase("AMEND"))
if(!rfq.getString("status").equalsIgnoreCase("SENT") && !rfq.getString("status").equalsIgnoreCase("AMEND") && !rfq.getString("status").equalsIgnoreCase("BYPASS"))
//End of EMS-563
	throw new MXApplicationException("rfq", "deleteOnlyIfTenderOpen");
else if(rfq.getString("status").equalsIgnoreCase("AMEND"))
{			
	//Check if the user belongs to Vendor group
	String currentuser = getUserName();	    			
	MboSetRemote venodrgroupset = MXServer.getMXServer().getMboSet("GROUPUSER", getUserInfo());
	SqlFormat sql2 = new SqlFormat("GROUPNAME ='VENDORS'");
	venodrgroupset.setWhere(sql2.format());
	boolean vendor = false;
	int i=0;
	
	for(MboRemote user = null; (user = venodrgroupset.getMbo(i)) != null; i++)
		if(user.getString("USERID").equalsIgnoreCase(currentuser))
			vendor =true;
	
	if(vendor)
		throw new MXApplicationException("rfq", "deleteOnlyIfTenderOpen");
	else
		return;
  }		    
  else
      return;
}      

}

