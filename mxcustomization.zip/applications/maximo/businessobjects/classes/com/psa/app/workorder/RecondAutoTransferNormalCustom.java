package com.psa.app.workorder;

import java.rmi.RemoteException;
//import java.sql.SQLException;



import psdi.app.inventory.MatRecTransRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboConstants;
//import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
//import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class RecondAutoTransferNormalCustom
  implements ActionCustomClass
{
	public void applyCustomAction(MboRemote mboremote, Object[] aobj)
			throws MXException, RemoteException
	{
		RecondUtilCustom recondUtil = new RecondUtilCustom();
		MboSetRemote matrectransSetRemote = mboremote.getMboSet("MATRECTRANS_RECONDITEM");
		if(!matrectransSetRemote.isEmpty()){
		MatRecTransRemote matrectransRemote = (MatRecTransRemote)matrectransSetRemote.getMbo(0);
		if (matrectransRemote != null)
		{
			
				
	    	//SqlFormat mrtsqlformat = new SqlFormat(mboremote.getUserInfo(), "INSERT INTO MATRECTRANS (ITEMNUM, TOSTORELOC, TRANSDATE, ACTUALDATE, QUANTITY, RECEIVEDUNIT, ISSUETYPE, UNITCOST, ACTUALCOST, REJECTQTY, CONVERSION, ENTERBY, OUTSIDE, ISSUE, TOTALCURBAL, OLDAVGCOST, TOBIN, GLDEBITACCT, GLCREDITACCT, LINECOST, CURRENCYCODE, EXCHANGERATE, CURRENCYUNITCOST, CURRENCYLINECOST, DESCRIPTION, FROMSTORELOC, FROMBIN, LOADEDCOST, TAX1, TAX2, TAX3, TAX4, TAX5, PRORATED, STATUS, CURBAL, EXCHANGERATE2, LINECOST2, MATRECTRANSID, SENDERSYSID, ORGID, SITEID, COSTINFO, REFWO, ENTEREDASTASK, FROMSITEID, LINETYPE, ITEMSETID, CONDITIONCODE, FROMCONDITIONCODE, CONDRATE, LANGCODE, INSPECTEDQTY, HASLD, NEWAVGCOST, OLDTOTALBAL, ROUNDINGERR, ISPDA, SAMESLIP) VALUES ('" + matrectransremote.getString("ITEMNUM") + "', '" + recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")) + "', SYSDATE, SYSDATE, " + mboremote.getDouble("RECONDQTY") + "-NVL(" + mboremote.getDouble("SCRAPQTY") + ", 0), '" + recondutil.getTransitInv(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")).getString("ISSUEUNIT") + "', 'TRANSFER', 0, 0, 0, " + matrectransremote.getDouble("CONVERSION") + ", '" + mboremote.getUserInfo().getUserName() + "', " + matrectransremote.getDouble("OUTSIDE") + ", 0, " + recondutil.getTotalCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + ", 0, '" + recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + "', '" + recondutil.getGLAcct(mboremote, recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + "', '" + recondutil.getGLAcct(mboremote, matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")) + "', 0, '" + matrectransremote.getString("CURRENCYCODE") + "', " + matrectransremote.getDouble("EXCHANGERATE") + ", 0, 0, '" + matrectransremote.getString("DESCRIPTION") + "', '" + matrectransremote.getString("TOSTORELOC") + "', '" + recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")) + "', 0, 0, 0, 0, 0, 0, 0, 'COMP', " + recondutil.getCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"), recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"))) + ", " + matrectransremote.getDouble("EXCHANGERATE") + ", 0, MATRECTRANSSEQ.NEXTVAL, '" + matrectransremote.getString("SENDERSYSID") + "', '" + matrectransremote.getString("ORGID") + "', '" + matrectransremote.getString("SITEID") + "', 1, '" + mboremote.getString("WONUM") + "', " + matrectransremote.getDouble("ENTEREDASTASK") + ", '" + matrectransremote.getString("SITEID") + "', '" + matrectransremote.getString("LINETYPE") + "', '" + matrectransremote.getString("ITEMSETID") + "', 'RECOND', 'RECOND', 1, '" + matrectransremote.getString("LANGCODE") + "', 0, 0, 0, " + recondutil.getCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"), recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"))) + ", 0, 0, 0)");
	    	//++ Comm-IT -- Added Lot number to the queries
			//--Commented by Comm-IT in Maximo 7.6 - SqlFormat mrtsqlformat = new SqlFormat(mboremote.getUserInfo(), "INSERT INTO MATRECTRANS (ITEMNUM, TOSTORELOC, TRANSDATE, ACTUALDATE, QUANTITY, RECEIVEDUNIT, ISSUETYPE, UNITCOST, ACTUALCOST, REJECTQTY, CONVERSION, ENTERBY, OUTSIDE, ISSUE, TOTALCURBAL, OLDAVGCOST, TOBIN, GLDEBITACCT, GLCREDITACCT, LINECOST, CURRENCYCODE, EXCHANGERATE, CURRENCYUNITCOST, CURRENCYLINECOST, DESCRIPTION, FROMSTORELOC, FROMBIN, LOADEDCOST, TAX1, TAX2, TAX3, TAX4, TAX5, PRORATED, STATUS, CURBAL, EXCHANGERATE2, LINECOST2, MATRECTRANSID, SENDERSYSID, ORGID, SITEID, COSTINFO, REFWO, ENTEREDASTASK, FROMSITEID, LINETYPE, ITEMSETID, CONDITIONCODE, FROMCONDITIONCODE, CONDRATE, LANGCODE, INSPECTEDQTY, HASLD, NEWAVGCOST, OLDTOTALBAL, ROUNDINGERR, ISPDA, SAMESLIP, RECONCILIATION, CONSIGNMENT) VALUES ('" + matrectransremote.getString("ITEMNUM") + "', '" + recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")) + "', SYSDATE, SYSDATE, " + mboremote.getDouble("RECONDQTY") + "-NVL(" + mboremote.getDouble("SCRAPQTY") + ", 0), '" + recondutil.getTransitInv(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")).getString("ISSUEUNIT") + "', 'TRANSFER', 0, 0, 0, " + matrectransremote.getDouble("CONVERSION") + ", '" + mboremote.getUserInfo().getUserName() + "', " + matrectransremote.getDouble("OUTSIDE") + ", 0, " + recondutil.getTotalCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + ", 0, '" + recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + "', '" + recondutil.getGLAcct(mboremote, recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + "', '" + recondutil.getGLAcct(mboremote, matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")) + "', 0, '" + matrectransremote.getString("CURRENCYCODE") + "', " + matrectransremote.getDouble("EXCHANGERATE") + ", 0, 0, '" + matrectransremote.getString("DESCRIPTION") + "', '" + matrectransremote.getString("TOSTORELOC") + "', '" + recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")) + "', 0, 0, 0, 0, 0, 0, 0, 'COMP', " + recondutil.getCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"), recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"))) + ", " + matrectransremote.getDouble("EXCHANGERATE") + ", 0, MATRECTRANSSEQ.NEXTVAL, '" + matrectransremote.getString("SENDERSYSID") + "', '" + matrectransremote.getString("ORGID") + "', '" + matrectransremote.getString("SITEID") + "', 1, '" + mboremote.getString("WONUM") + "', " + matrectransremote.getDouble("ENTEREDASTASK") + ", '" + matrectransremote.getString("SITEID") + "', '" + matrectransremote.getString("LINETYPE") + "', '" + matrectransremote.getString("ITEMSETID") + "', 'RECOND', 'RECOND', 1, '" + matrectransremote.getString("LANGCODE") + "', 0, 0, 0, " + recondutil.getCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"), recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"))) + ", 0, 0, 0, 0, 0)");
	      
	    	//SqlFormat mrtsqlformat = new SqlFormat(mboremote.getUserInfo(), "INSERT INTO MATRECTRANS (ITEMNUM, TOSTORELOC, TRANSDATE, ACTUALDATE, QUANTITY, RECEIVEDUNIT, ISSUETYPE, UNITCOST, ACTUALCOST, REJECTQTY, CONVERSION, ENTERBY, OUTSIDE, ISSUE, TOTALCURBAL, OLDAVGCOST, TOBIN, TOLOT, GLDEBITACCT, GLCREDITACCT, LINECOST, CURRENCYCODE, EXCHANGERATE, CURRENCYUNITCOST, CURRENCYLINECOST, DESCRIPTION, FROMSTORELOC, FROMBIN, FROMLOT, LOADEDCOST, TAX1, TAX2, TAX3, TAX4, TAX5, PRORATED, STATUS, CURBAL, EXCHANGERATE2, LINECOST2, MATRECTRANSID, SENDERSYSID, ORGID, SITEID, COSTINFO, REFWO, ENTEREDASTASK, FROMSITEID, LINETYPE, ITEMSETID, CONDITIONCODE, FROMCONDITIONCODE, CONDRATE, LANGCODE, INSPECTEDQTY, HASLD, NEWAVGCOST, OLDTOTALBAL, ROUNDINGERR, ISPDA, SAMESLIP, RECONCILIATION, CONSIGNMENT) VALUES ('" + matrectransremote.getString("ITEMNUM") + "', '" + recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")) + "', SYSDATE, SYSDATE, " + mboremote.getDouble("RECONDQTY") + "-NVL(" + mboremote.getDouble("SCRAPQTY") + ", 0), '" + recondutil.getTransitInv(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")).getString("ISSUEUNIT") + "', 'TRANSFER', 0, 0, 0, " + matrectransremote.getDouble("CONVERSION") + ", '" + mboremote.getUserInfo().getUserName() + "', " + matrectransremote.getDouble("OUTSIDE") + ", 0, " + recondutil.getTotalCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + ", 0, '" + recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + "', '" + recondutil.getLot(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + "', '" + recondutil.getGLAcct(mboremote, recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + "', '" + recondutil.getGLAcct(mboremote, matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")) + "', 0, '" + matrectransremote.getString("CURRENCYCODE") + "', " + matrectransremote.getDouble("EXCHANGERATE") + ", 0, 0, '" + matrectransremote.getString("DESCRIPTION") + "', '" + matrectransremote.getString("TOSTORELOC") + "', '" + recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")) + "', '" + recondutil.getLot(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")) + "', 0, 0, 0, 0, 0, 0, 0, 'COMP', " + recondutil.getCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"), recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"))) + ", " + matrectransremote.getDouble("EXCHANGERATE") + ", 0, MATRECTRANSSEQ.NEXTVAL, '" + matrectransremote.getString("SENDERSYSID") + "', '" + matrectransremote.getString("ORGID") + "', '" + matrectransremote.getString("SITEID") + "', 1, '" + mboremote.getString("WONUM") + "', " + matrectransremote.getDouble("ENTEREDASTASK") + ", '" + matrectransremote.getString("SITEID") + "', '" + matrectransremote.getString("LINETYPE") + "', '" + matrectransremote.getString("ITEMSETID") + "', 'RECOND', 'RECOND', 1, '" + matrectransremote.getString("LANGCODE") + "', 0, 0, 0, " + recondutil.getCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"), recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"))) + ", 0, 0, 0, 0, 0)");
			//#BCTACT1
			// 28-April-2021 : Modified by BCT to remove insert and convert it into mbo.add()
			//SqlFormat mrtsqlformat = new SqlFormat(mboremote.getUserInfo(), "INSERT INTO MATRECTRANS (ITEMNUM, TOSTORELOC, TRANSDATE, ACTUALDATE, QUANTITY, RECEIVEDUNIT, ISSUETYPE, UNITCOST, ACTUALCOST, REJECTQTY, CONVERSION, ENTERBY, OUTSIDE, ISSUE, TOTALCURBAL, OLDAVGCOST, TOBIN, TOLOT, GLDEBITACCT, GLCREDITACCT, LINECOST, CURRENCYCODE, EXCHANGERATE, CURRENCYUNITCOST, CURRENCYLINECOST, DESCRIPTION, FROMSTORELOC, FROMBIN, FROMLOT, LOADEDCOST, TAX1, TAX2, TAX3, TAX4, TAX5, PRORATED, STATUS, CURBAL, EXCHANGERATE2, LINECOST2, MATRECTRANSID, SENDERSYSID, ORGID, SITEID, COSTINFO, REFWO, ENTEREDASTASK, FROMSITEID, LINETYPE, ITEMSETID, CONDITIONCODE, FROMCONDITIONCODE, CONDRATE, LANGCODE, INSPECTEDQTY, HASLD, NEWAVGCOST, OLDTOTALBAL, ROUNDINGERR, ISPDA, SAMESLIP, RECONCILIATION, CONSIGNMENT) VALUES ('" + matrectransRemote.getString("ITEMNUM") + "', '" + recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")) + "', getDate(), getDate(), " + mboremote.getDouble("RECONDQTY") + "-ISNULL(" + mboremote.getDouble("SCRAPQTY") + ", 0), '" + recondUtil.getTransitInv(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")).getString("ISSUEUNIT") + "', 'TRANSFER', 0, 0, 0, " + matrectransRemote.getDouble("CONVERSION") + ", '" + mboremote.getUserInfo().getUserName() + "', " + matrectransRemote.getDouble("OUTSIDE") + ", 0, " + recondUtil.getTotalCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")) + ", 0, '" + recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")) + "', '" + recondUtil.getLot(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")) + "', '" + recondUtil.getGLAcct(mboremote, recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")) + "', '" + recondUtil.getGLAcct(mboremote, matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")) + "', 0, '" + matrectransRemote.getString("CURRENCYCODE") + "', " + matrectransRemote.getDouble("EXCHANGERATE") + ", 0, 0, '" + matrectransRemote.getString("DESCRIPTION") + "', '" + matrectransRemote.getString("TOSTORELOC") + "', '" + recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")) + "', '" + recondUtil.getLot(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")) + "', 0, 0, 0, 0, 0, 0, 0, 'COMP', " + recondUtil.getCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"), recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"))) + ", " + matrectransRemote.getDouble("EXCHANGERATE") + ", 0,(select max(matrectransid)+1 from matrectrans), '" + matrectransRemote.getString("SENDERSYSID") + "', '" + matrectransRemote.getString("ORGID") + "', '" + matrectransRemote.getString("SITEID") + "', 1, '" + mboremote.getString("WONUM") + "', " + matrectransRemote.getDouble("ENTEREDASTASK") + ", '" + matrectransRemote.getString("SITEID") + "', '" + matrectransRemote.getString("LINETYPE") + "', '" + matrectransRemote.getString("ITEMSETID") + "', 'RECOND', 'RECOND', 1, '" + matrectransRemote.getString("LANGCODE") + "', 0, 0, 0, " + recondUtil.getCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"), recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"))) + ", 0, 0, 0, 0, 0)");
			Double scrapQty=mboremote.getDouble("SCRAPQTY");
			
			MboSetRemote inventoryAddMboSet=MXServer.getMXServer().getMboSet("INVENTORY",mboremote.getUserInfo());
			inventoryAddMboSet.setWhere("ITEMNUM='"+matrectransRemote.getString("ITEMNUM")+"' and LOCATION='"+matrectransRemote.getString("TOSTORELOC")+"' and SITEID='"+mboremote.getString("SITEID")+"'");
			inventoryAddMboSet.reset();
			if(!inventoryAddMboSet.isEmpty())
			{
				MboSetRemote matrectransset = inventoryAddMboSet.getMbo(0).getMboSet("MATRECTRANS");
				MboRemote matrectransadd =null;
				matrectransadd = matrectransset.addAtEnd(MboConstants.NOVALIDATION|MboConstants.NOACCESSCHECK);
				Integer zeroVal = 0;
				Integer oneVal = 1;
				boolean trueVal = true;
				boolean falseVal = false;
				String issueType="TRANSFER";
				String recondCondition="RECOND";
				
				matrectransadd.setValue("ITEMNUM", matrectransRemote.getString("ITEMNUM"),MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				System.out.println("*** RecondAutoTransferNormalCustom AA matrectrans.TOSTORELOC="+recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")));
				matrectransadd.setValue("TOSTORELOC", recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")),  MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TRANSDATE",  MXServer.getMXServer().getDate(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ACTUALDATE", MXServer.getMXServer().getDate(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				if(scrapQty.equals(null)){
					scrapQty = 0.0;	
				}
				matrectransadd.setValue("QUANTITY", mboremote.getDouble("RECONDQTY")-scrapQty, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("RECEIVEDUNIT",  recondUtil.getTransitInv(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")).getString("ISSUEUNIT"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ISSUETYPE",issueType, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("UNITCOST",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ACTUALCOST",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("REJECTQTY",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("CONVERSION",matrectransRemote.getDouble("CONVERSION"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ENTERBY",mboremote.getUserInfo().getUserName(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("OUTSIDE",matrectransRemote.getDouble("OUTSIDE"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ISSUE",falseVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TOTALCURBAL",recondUtil.getTotalCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("OLDAVGCOST",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TOBIN",recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TOLOT",recondUtil.getLot(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("GLDEBITACCT",recondUtil.getGLAcct(mboremote, recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("GLCREDITACCT",recondUtil.getGLAcct(mboremote, matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("LINECOST",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("CURRENCYCODE",matrectransRemote.getString("CURRENCYCODE"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("EXCHANGERATE", matrectransRemote.getDouble("EXCHANGERATE"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("CURRENCYUNITCOST",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("CURRENCYLINECOST",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("DESCRIPTION", matrectransRemote.getString("DESCRIPTION"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("FROMSTORELOC",matrectransRemote.getString("TOSTORELOC"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("FROMBIN",recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				//matrectransadd.setValue("FROMSTORELOC",matrectransRemote.getString("TOSTORELOC"));
				matrectransadd.setValue("FROMLOT",recondUtil.getLot(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("LOADEDCOST",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TAX1",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TAX2",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TAX3",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TAX4",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("TAX5",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("PRORATED",falseVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("STATUS","COMP", MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("CURBAL",recondUtil.getCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"), recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"))), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("EXCHANGERATE2",matrectransRemote.getDouble("EXCHANGERATE"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("LINECOST2",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("SENDERSYSID",matrectransRemote.getString("SENDERSYSID"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ORGID",matrectransRemote.getString("ORGID"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("SITEID",matrectransRemote.getString("SITEID"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("COSTINFO",trueVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("REFWO",mboremote.getString("WONUM"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ENTEREDASTASK",matrectransRemote.getDouble("ENTEREDASTASK"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("FROMSITEID", matrectransRemote.getString("SITEID"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("LINETYPE",matrectransRemote.getString("LINETYPE"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ITEMSETID",matrectransRemote.getString("ITEMSETID"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("CONDITIONCODE",recondCondition, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("FROMCONDITIONCODE",recondCondition, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("CONDRATE", oneVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("LANGCODE",matrectransRemote.getString("LANGCODE"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("INSPECTEDQTY",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("HASLD",falseVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("NEWAVGCOST",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("OLDTOTALBAL", recondUtil.getCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"), recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"))), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ROUNDINGERR",zeroVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("ISPDA",falseVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("SAMESLIP",falseVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("RECONCILIATION",falseVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransadd.setValue("CONSIGNMENT",falseVal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
				matrectransset.save();
			}
			//-- Comm-IT -- Added Lot number to the queries
	    	//SqlFormat invbrecondsqlformat = new SqlFormat(mboremote.getUserInfo(), "UPDATE INVBALANCES SET CURBAL=" + recondutil.getCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID"), recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID"))) + "-" + mboremote.getDouble("RECONDQTY") + "+NVL(" + mboremote.getDouble("SCRAPQTY") + ",0) WHERE ITEMNUM='" + matrectransremote.getString("ITEMNUM") + "' AND ITEMSETID='" + matrectransremote.getString("ITEMSETID") + "' AND LOCATION='" + matrectransremote.getString("TOSTORELOC") + "' AND SITEID='" + matrectransremote.getString("SITEID") + "' AND BINNUM ='" + recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), matrectransremote.getString("TOSTORELOC"), matrectransremote.getString("SITEID")) + "' AND CONDITIONCODE='RECOND' AND ROWNUM=1");
			//SqlFormat invbrecondsqlformat = new SqlFormat(mboremote.getUserInfo(), "UPDATE INVBALANCES SET CURBAL=" + recondUtil.getCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID"), recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID"))) + "-" + mboremote.getDouble("RECONDQTY") + "+ISNULL(" + mboremote.getDouble("SCRAPQTY") + ",0) WHERE ITEMNUM='" + matrectransRemote.getString("ITEMNUM") + "' AND ITEMSETID='" + matrectransRemote.getString("ITEMSETID") + "' AND LOCATION='" + matrectransRemote.getString("TOSTORELOC") + "' AND SITEID='" + matrectransRemote.getString("SITEID") + "' AND BINNUM ='" + recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")) + "' AND CONDITIONCODE='RECOND'");
			/* Sere temp test org
			MboSetRemote invBalanceSet= mboremote.getMboSet("$INVBALANCES","INVBALANCES", "ITEMNUM='" + matrectransRemote.getString("ITEMNUM") + "' AND ITEMSETID='" + matrectransRemote.getString("ITEMSETID") + "' AND LOCATION='" + matrectransRemote.getString("TOSTORELOC") + "' AND SITEID='" + matrectransRemote.getString("SITEID") + "' AND BINNUM ='" + recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")) + "' AND CONDITIONCODE='RECOND'");
			System.out.println("*** RecondAutoTransferNormalCustom a: "+"ITEMNUM='" + matrectransRemote.getString("ITEMNUM") + "' AND ITEMSETID='" + matrectransRemote.getString("ITEMSETID") + "' AND LOCATION='" + matrectransRemote.getString("TOSTORELOC") + "' AND SITEID='" + matrectransRemote.getString("SITEID") + "' AND BINNUM ='" + recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")) + "' AND CONDITIONCODE='RECOND'");
			MboRemote invBalance=null;
			if(invBalanceSet.count()>0 && !invBalanceSet.isEmpty()) {
				for(int i=0;(invBalance=invBalanceSet.getMbo(i))!=null;i++) {
					System.out.println("*** RecondAutoTransferNormalCustom aa: recondUtil.getCurBal: itemnum="+matrectransRemote.getString("ITEMNUM")+",ITEMSETID="+matrectransRemote.getString("ITEMSETID")+",TOSTORELOC="+matrectransRemote.getString("TOSTORELOC")+",SITEID="+matrectransRemote.getString("SITEID")+", BIN="+recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")));
					double currentBalanceUtility = recondUtil.getCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID"), recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), matrectransRemote.getString("TOSTORELOC"), matrectransRemote.getString("SITEID")));
					double recondQuantity = mboremote.getDouble("RECONDQTY");
					if(scrapQty.equals(null)){
						scrapQty = 0.0;	
					}
					double curbal = currentBalanceUtility-recondQuantity+scrapQty;
					System.out.println("*** RecondAutoTransferNormalCustom b: curbal:"+curbal+",currentBalanceUtility:"+currentBalanceUtility+",recondQuantity:"+recondQuantity+",scrapQty:"+scrapQty);
					invBalance.setFieldFlag("CURBAL",MboConstants.READONLY,false);
					invBalance.setValue("CURBAL", curbal,MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
					invBalance.setFieldFlag("CURBAL",MboConstants.READONLY,true);
					System.out.println("*** RecondAutoTransferNormalCustom c: getcurbal:"+invBalance.getString("CURBAL"));
				}
				invBalanceSet.save();
			}
			*/
	    	//SqlFormat invbnormalsqlformat = new SqlFormat(mboremote.getUserInfo(), "UPDATE INVBALANCES SET CURBAL=" + recondutil.getCurBal(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"), recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID"))) + "+" + mboremote.getDouble("RECONDQTY") + "- NVL(" + mboremote.getDouble("SCRAPQTY") + ", 0) WHERE ITEMNUM='" + matrectransremote.getString("ITEMNUM") + "' AND ITEMSETID='" + matrectransremote.getString("ITEMSETID") + "' AND LOCATION='" + recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")) + "' AND SITEID='" + matrectransremote.getString("SITEID") + "' AND BINNUM='" + recondutil.getBin(mboremote, matrectransremote.getString("ITEMNUM"), matrectransremote.getString("ITEMSETID"), recondutil.getNormalStoreLoc(matrectransremote.getString("TOSTORELOC")), matrectransremote.getString("SITEID")) + "' AND CONDITIONCODE='RECOND' AND ROWNUM=1");
	    	//SqlFormat invbnormalsqlformat = new SqlFormat(mboremote.getUserInfo(), "UPDATE INVBALANCES SET CURBAL=" + recondUtil.getCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"), recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"))) + "+" + mboremote.getDouble("RECONDQTY") + "- ISNULL(" + mboremote.getDouble("SCRAPQTY") + ", 0) WHERE ITEMNUM='" + matrectransRemote.getString("ITEMNUM") + "' AND ITEMSETID='" + matrectransRemote.getString("ITEMSETID") + "' AND LOCATION='" + recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")) + "' AND SITEID='" + matrectransRemote.getString("SITEID") + "' AND BINNUM='" + recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")) + "' AND CONDITIONCODE='RECOND'");
	    	
			//*Comment: Do not needed anymore. Seem auto set
	    	System.out.println("*** RecondAutoTransferNormalCustom a1: "+"ITEMNUM='" + matrectransRemote.getString("ITEMNUM") + "' AND ITEMSETID='" + matrectransRemote.getString("ITEMSETID") + "' AND LOCATION='" + recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")) + "' AND SITEID='" + matrectransRemote.getString("SITEID") + "' AND BINNUM='" + recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")) + "' AND CONDITIONCODE='RECOND'");
	    	/*
	    	MboSetRemote invBalanceNormalSet= mboremote.getMboSet("$INVBALANCESNORMAL","INVBALANCES", "ITEMNUM='" + matrectransRemote.getString("ITEMNUM") + "' AND ITEMSETID='" + matrectransRemote.getString("ITEMSETID") + "' AND LOCATION='" + recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")) + "' AND SITEID='" + matrectransRemote.getString("SITEID") + "' AND BINNUM='" + recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")) + "' AND CONDITIONCODE='RECOND'");
	    	MboRemote invBalanceNormal=null;
			if(invBalanceNormalSet.count()>0 && !invBalanceNormalSet.isEmpty()) {
				for(int i=0;(invBalanceNormal=invBalanceNormalSet.getMbo(i))!=null;i++) {
					double currentBalanceUtility = recondUtil.getCurBal(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID"), recondUtil.getBin(mboremote, matrectransRemote.getString("ITEMNUM"), matrectransRemote.getString("ITEMSETID"), recondUtil.getNormalStoreLoc(matrectransRemote.getString("TOSTORELOC")), matrectransRemote.getString("SITEID")));
					double recondQuantity = mboremote.getDouble("RECONDQTY");
					if(scrapQty.equals(null)){
						scrapQty = 0.0;	
					}
					double curbal = currentBalanceUtility-recondQuantity+scrapQty;
					System.out.println("*** RecondAutoTransferNormalCustom b1: curbal:"+curbal+",currentBalanceUtility:"+currentBalanceUtility+",recondQuantity:"+recondQuantity+",scrapQty:"+scrapQty);
					//invBalanceNormal.setFieldFlag("CURBAL",MboConstants.READONLY,false);
					//invBalanceNormal.setValue("CURBAL", curbal,MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
					//invBalanceNormal.setFieldFlag("CURBAL",MboConstants.READONLY,true);
					System.out.println("*** RecondAutoTransferNormalCustom c1: getcurbal:"+invBalanceNormal.getString("CURBAL"));

				}
				//invBalanceNormalSet.save();
			}
			*/
	    	
	    	/*invbnormalsqlformat.format();
	      
	    
	    	DBShortcut dbshortcut = new DBShortcut();
	    	try
	    	{
				dbshortcut.connect(mboremote.getUserInfo().getConnectionKey());
				//dbshortcut.execute(1, mrtsqlformat);
				dbshortcut.execute(1, invbrecondsqlformat);
				dbshortcut.execute(1, invbnormalsqlformat);
				dbshortcut.commit();
	    	}
	    	catch (SQLException sqlexception)
	    	{
	    		sqlexception.printStackTrace();
	    		String[] as = { 
	    				sqlexception.getMessage() };
	
	    		throw new MXApplicationException("workorder", "AutoReturnError", as);
	    	}
	    	finally
	    	{
	    		dbshortcut.close();
	    	}*/
		}
		else
		{
			matrectransSetRemote.close();
			throw new MXApplicationException("workorder", "NoTransfer");
		}
		}
	}
}