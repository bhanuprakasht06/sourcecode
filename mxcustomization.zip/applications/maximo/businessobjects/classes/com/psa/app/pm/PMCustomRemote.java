package com.psa.app.pm;

import java.rmi.RemoteException;

import psdi.app.pm.PMRemote;
import psdi.util.MXException;

public interface  PMCustomRemote extends PMRemote {
	public abstract void init()
        throws MXException, RemoteException;


}
