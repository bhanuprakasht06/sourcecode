package com.psa.app.jobplan;

import psdi.mbo.MboSetRemote;

public interface JPSkillsetSetCustomRemote extends MboSetRemote 
{
		
}
