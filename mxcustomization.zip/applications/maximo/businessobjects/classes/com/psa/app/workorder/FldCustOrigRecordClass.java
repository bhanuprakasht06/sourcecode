/*
 * Modification history
 
 * 29-07-2013--4.1.1-  Enhance Work Order Tracking Application to enable users to create follow up work orders across multiple sites.
 *   
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.FldWOOrigRecordClass;
import psdi.mbo.Mbo;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldCustOrigRecordClass extends FldWOOrigRecordClass	
{

	public FldCustOrigRecordClass(MboValue mbv) throws MXException 
	{
		super(mbv);
	}
	 public void action()
     throws MXException, RemoteException
 {
		 System.out.println("###IN Class FldCustOrigRecordCLASS Method Action ()###");
		 Mbo wo = getMboValue().getMbo();
		 	if(getMboValue().isNull())
		 			wo.setValueNull("ORIGRECORDID", 2L);
		 System.out.println("###Exit Class FldCustOrigRecordCLASS Method Action ()###");
 }
	
}
