/*
 * Modification history
 * 10-04-07	LS	DR-015	Allow editing of WOInterrupt during edit WO history
 * 18-09-07	LS	DR-047	Fix to allow adding of interruption hrs to child WO  
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.util.Date;

import psdi.app.workorder.WORemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class WOInterruptCustom extends Mbo 
implements WOInterruptCustomRemote
{
public WOInterruptCustom(MboSet mboset) 
throws MXException, RemoteException 
{
	super(mboset);
}

public void init()
    throws MXException
{
	super.init();
	try
	{
		WORemote mboremote = (WORemote)getOwner();
		if(mboremote.getBoolean("historyflag") && !mboremote.isWOInEditHist())
		{
//			System.out.println("[WOInterruptCustom]historyflag: " + mboremote.getBoolean("historyflag"));
//			System.out.println("[WOInterruptCustom]isWOInEditHist: " + !mboremote.isWOInEditHist());
			setFlag(7L, true);
		}
		else
		{
//			System.out.println("[WOInterruptCustom]historyflag: " + mboremote.getBoolean("historyflag"));
//			System.out.println("[WOInterruptCustom]isWOInEditHist: " + !mboremote.isWOInEditHist());
			setFlag(7L, false);
		}
	}
	catch (RemoteException remoteexception) { }
}

public void add()
	throws MXException, RemoteException
{	
	MboRemote mboremote = getOwner();
/* Start of Modification - DR 47 */
//	MboRemote mboremote1 = ((WO)getOwner()).getTop().getMbo(0);
//	String w = "";
//	String s = "";
//
//	if(mboremote1 == null)
//	{
//		w = mboremote.getString("wonum");
//		s = mboremote.getString("siteid");
//	}
//	else
//	{
//		w = mboremote1.getString("wonum");
//		s = mboremote1.getString("siteid");
//	}
//
//	setValue("wonum", w, 2L);
//	setValue("siteid", s, 2L);
	setValue("wonum", mboremote.getString("wonum"), 2L);
	setValue("siteid", mboremote.getString("siteid"), 2L);
/* End of Modification - DR 47 */
}

public void delete(long l)
	throws MXException, RemoteException
{
	super.delete(l);
}

public double getDatesDiff()
    throws MXException, RemoteException
{
    double d = 0.0D;
    
    Date date = getMboValue("EndDate").getDate();
//    System.out.println("[WOInterruptCustom]WOIC: End date: " + date);
    Date date1 = getMboValue("StartDate").getDate();
//    System.out.println("[WOInterruptCustom]WOIC: Start date: " + date1);
    
	d = (double)(date.getTime() - date1.getTime()) / 3600000D;
//    System.out.println("[WOInterruptCustom]WOIC: d value: " + d);
    return d;
}

public void updateIntHrs()
	throws MXException, RemoteException
{
	double d = getDatesDiff();
//	System.out.println("[WOInterruptCustom]WOIC: d value: " + d);
	setValue("interrupthrs", d, 2L);
//	System.out.println("[WOInterruptCustom]WOIC: Set Value: d");
}

public void updateIntHrsNull()
	throws MXException, RemoteException
{
	setValue("interrupthrs", "", 2L);
//	System.out.println("[WOInterruptCustom]WOIC: Set value: null");
}

public void checkIntDate(Date intstart, Date intend)
	throws MXException, RemoteException
{
	MboRemote mboremote = getOwner();
	Date actstart = mboremote.getDate("ACTSTART");
	Date actfinish = mboremote.getDate("ACTFINISH");

//	System.out.println("[WOInterruptCustom]WOIC: intstart: " + intstart);
//	System.out.println("[WOInterruptCustom]WOIC: intend: " + intend);
//	System.out.println("[WOInterruptCustom]WOIC: actstart: " + actstart);
//	System.out.println("[WOInterruptCustom]WOIC: actfinish: " + actfinish);
	
	if(actstart == null)
	{
//		System.out.println("[WOInterruptCustom]WOIC: actstart: null");
		throw new MXApplicationException("workorder", "NoActStart");
	}
	if(intstart != null)
	{
		if(intend != null && intstart.after(intend))
		{
//			System.out.println("[WOInterruptCustom]WOIC: intstart > intend");
			throw new MXApplicationException("workorder", "StartAfterFinish");
		}
		if(actstart.after(intstart))
		{
//			System.out.println("[WOInterruptCustom]WOIC: actstart > intstart");
			throw new MXApplicationException("workorder", "IntStartBeforeActStart");
		}
		if(actfinish != null && actfinish.before(intstart))
		{
//			System.out.println("[WOInterruptCustom]WOIC: actfinish < intstart");
			throw new MXApplicationException("workorder", "IntStartAfterActFinish");
		}
		if(actfinish != null && intend != null && actfinish.before(intend))
		{
//			System.out.println("[WOInterruptCustom]WOIC: actfinish < intend");
			throw new MXApplicationException("workorder", "IntEndAfterActFinish");
		}
	}
	else
	{
		if(actstart.after(intend))
		{
//			System.out.println("[WOInterruptCustom]WOIC: actfinish < intend");
			throw new MXApplicationException("workorder", "IntEndBeforeActStart");
		}
		if(actfinish != null && actfinish.before(intend))
		{
//			System.out.println("[WOInterruptCustom]WOIC: actfinish < intend");
			throw new MXApplicationException("workorder", "IntEndAfterActFinish");
		}
	}
}
}
