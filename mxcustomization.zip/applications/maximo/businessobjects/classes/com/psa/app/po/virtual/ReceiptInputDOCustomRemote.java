package com.psa.app.po.virtual;

import psdi.mbo.NonPersistentMboRemote;

public interface ReceiptInputDOCustomRemote
		extends NonPersistentMboRemote
{

}
