package com.psa.app.labor;

import java.rmi.RemoteException;

import psdi.app.labor.FldServRecTransRefWO;
import psdi.mbo.Mbo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldServRecTransRefWOCustom extends FldServRecTransRefWO {

	public FldServRecTransRefWOCustom(MboValue arg0) 
		throws MXException,RemoteException 
	{
		super(arg0);
	}
	
	public void action()
		throws MXException, RemoteException
	{
		super.action();
		
		Mbo mbo = getMboValue().getMbo();
		double totalhrs = 0;
		
//		System.out.println("[FldServRecTransRefWOCustom] mbo name: " + mbo.getName());
//	    System.out.println("[FldServRecTransRefWOCustom] refwo: " + mbo.getString("REFWO"));
//	    System.out.println("[FldServRecTransRefWOCustom] positeid: " + mbo.getString("POSITEID"));
//	    System.out.println("[FldServRecTransRefWOCustom] ponum: " + mbo.getString("PONUM"));
//	    System.out.println("[FldServRecTransRefWOCustom] polinenum: " + mbo.getString("POLINENUM"));
	    
	    MboSetRemote wointerruptset = mbo.getMboSet("LDWOINTERRUPT");
	    
//	    System.out.println("[FldServRecTransRefWOCustom] wointerrupt count: " + wointerruptset.count());
//		System.out.println("[FldServRecTransRefWOCustom] Totalhrs: " + totalhrs);
//		System.out.println("[FldServRecTransRefWOCustom] Set Name: " + wointerruptset.getName());
//		System.out.println("[FldServRecTransRefWOCustom] Where: " + wointerruptset.getWhere());
	
		totalhrs = wointerruptset.sum("INTERRUPTHRS")/24;
		
//		System.out.println("[FldServRecTransRefWOCustom] Totalhrs: " + totalhrs);
//		System.out.println("[FldServRecTransRefWOCustom] Exit");
		mbo.setValue("WOINTERRUPT",totalhrs, 11L);
	
	}
}
