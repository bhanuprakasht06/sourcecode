package com.psa.app.location;

import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import com.psa.custom.common.MxEmail;
import com.psa.custom.ois.MxLog;

import psdi.app.location.LocMeterReadingRemote;
import psdi.app.location.LocMeterReadingSetRemote;
import psdi.app.location.LocationMeterRemote;
import psdi.app.location.LocationMeterSetRemote;
import psdi.app.location.LocationRemote;
import psdi.app.location.LocationSetRemote;
import psdi.app.meter.DeployedMeterRemote;
import psdi.app.meter.DeployedMeterSetRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboConstants;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class LocationRenameCronCust extends SimpleCronTask 
{
	private MxEmail email;
	private String emailSubj;
	private MXLogger logger;
	private MxLog mxLog;
	private String logFilePath;
	private UserInfo userInfo;
	private MXServer mxserver;
	String[] arrParams = new String[8]; 
	private SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	
	public LocationRenameCronCust()
	{
		logFilePath = null;
		userInfo = null;
		logger = MXLoggerFactory.getLogger("maximo.application.USER");
	    emailSubj = null;
	}
	
	public void init()throws MXException
	{
		super.init();
		email = new MxEmail();
		mxLog = new MxLog();
	}
	
	public void start()
	{
		try
		{
			super.start();
			logger.info((new StringBuilder(String.valueOf(getName()))).append(" Start").toString());
			logger.info((new StringBuilder(String.valueOf(getName()))).append(" Starting Crontask").toString());
			cacheResources();
			setSleepTime(0L);
		}
		catch(Exception e)
		{
			logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
		}
	}
	
	public CrontaskParamInfo[] getParameters() throws MXException,RemoteException
	{
		CrontaskParamInfo parameters[] = new CrontaskParamInfo[8];
		parameters[0] = new CrontaskParamInfo();
		parameters[0].setName("oldlocation");
		parameters[0].setDescription("LocationRenameCron", "oldlocation");
		parameters[1] = new CrontaskParamInfo();
		parameters[1].setName("newlocation");
		parameters[1].setDescription("LocationRenameCron", "newlocation");	    
		parameters[2] = new CrontaskParamInfo();
		parameters[2].setName("oldsite");
		parameters[2].setDescription("LocationRenameCron", "oldsite");
		parameters[3] = new CrontaskParamInfo();
		parameters[3].setName("newsite");
		parameters[3].setDescription("LocationRenameCron", "newsite");
		parameters[4] = new CrontaskParamInfo();
		parameters[4].setName("effectivedate");
		parameters[4].setDescription("LocationRenameCron", "effectivedate");	    
		parameters[5] = new CrontaskParamInfo();
		parameters[5].setName("logfile");
		parameters[5].setDescription("CommonCron", "LogDirectory");
		parameters[6] = new CrontaskParamInfo();
		parameters[6].setName("emailto");
		parameters[6].setDescription("CommonCron", "Adminemailaddress");
		parameters[7] = new CrontaskParamInfo();
		parameters[7].setName("alertemailsubj");
		parameters[7].setDescription("CommonCron", "EmailSubject");	    
		return parameters;
	}
	
	public void cacheResources() 
	{
		try
		{ 
			arrParams[0] = getParamAsString("oldlocation");
			//System.out.println("Old Location : "+arrParams[0]);
			logger.info("Old Location : "+arrParams[0]);
			arrParams[1] = getParamAsString("newlocation");
			//System.out.println("New Location : "+arrParams[1]);
			logger.info("New Location : "+arrParams[1]);
			arrParams[2] = getParamAsString("oldsite");
			System.out.println("Old Site : "+arrParams[2]);
			logger.info("Old Site : "+arrParams[2]);
			arrParams[3] = getParamAsString("newsite");
			//System.out.println("New Site : "+arrParams[3]);
			logger.info("New Site : "+arrParams[3]);
			arrParams[4] = getParamAsString("effectivedate");
			//System.out.println("Effective Date : "+arrParams[4]);
			logger.info("Effective Date : "+arrParams[4]);
			arrParams[5] = getParamAsString("logfile");
			//System.out.println("Log File Path : "+arrParams[5]);
			logger.info("Log File Path : "+arrParams[5]);
			arrParams[6] = getParamAsString("emailto");
			//System.out.println("Email To: "+arrParams[6]);
			logger.info("Email To: "+arrParams[6]);
			arrParams[7] = getParamAsString("alertemailsubj");
			//System.out.println("Email Subject : "+arrParams[7]);
			logger.info("Email Subject : "+arrParams[7]);
		}

		catch(Exception e)
		{
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
			logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
		}

	}
	

	
	public void cronAction()
	{
		try
			{
				
				if(parameterCheck(arrParams))
					{
					 if(readConfig())
					 {
						 mxLog.writeLog("Parameters Values");
						 mxLog.writeLog("Old Location : "+arrParams[0]);
						 mxLog.writeLog("New Location : "+arrParams[1]);
						 mxLog.writeLog("Old Site : "+arrParams[2]);
						 mxLog.writeLog("New Site : "+arrParams[3]);
						 mxLog.writeLog("Effective Date : "+arrParams[4]);
						 mxLog.writeLog("Log File Path : "+arrParams[5]);
						 mxLog.writeLog("Email To: "+arrParams[6]);
						 mxLog.writeLog("Email Subject : "+arrParams[7]);
						 if(!arrParams[0].equalsIgnoreCase(arrParams[1]) && !arrParams[1].toUpperCase().contains("OLD_"))
						    {
						    	//System.out.println("Old Location And New Location are not same, Entered Scenario : 1 , Checking For Site");
						    	logger.info("Old Location And New Location are not same, Entered Scenario : 1 , Checking For Site");
						    	mxLog.writeLog("Old Location And New Location are not same, Entered Scenario : 1 , Checking For Site");
						    	if(arrParams[2].equalsIgnoreCase(arrParams[3]))
							    	
							    	{
							    		//System.out.println("Old Site And New Site are same, In Scenario : 1 , Checking For Effective Date");
							    		logger.info("Old Site And New Site are same, In Scenario : 1 , Checking For Effective Date");
							    		mxLog.writeLog("Old Site And New Site are same, In Scenario : 1 , Checking For Effective Date");
							    		
							    		if(dateFormat1.parse(arrParams[4]).after(mxserver.getDate()))
							    		{
							    			//System.out.println(" In Scenario : 1 , Effective Date is after Current Date");
							    			//System.out.println("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Only Meters Will Be Copied with Updated Last Reading Details");
							    			logger.info(" In Scenario : 1 , Effective Date is after Current Date");
							    			logger.info("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Only Meters Will Be Copied with Updated Last Reading Details");
							    			mxLog.writeLog(" In Scenario : 1 , Effective Date is after Current Date");
							    			mxLog.writeLog("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Only Meters Will Be Copied with Updated Last Reading Details");
							    			
							    			if(locationRename())
						    				{
							    			//System.out.println("Scenario 1 ,Location Renamed Successfully");
									    	logger.info("Scenario 1 ,Location Renamed Successfully");
									    	mxLog.writeLog("Scenario 1 ,Location Renamed Successfully");
									    		
								    			if(updatePMforS1())
								    			{
								    				//System.out.println("Scenario 1 ,PM Data Updated Successfully");
										    		logger.info("Scenario 1 ,PM Data Updated Successfully");
										    		mxLog.writeLog("Scenario 1 ,PM Data Updated Successfully");
										    		
								    			}
								    			else
								    			{
								    				throw new Exception("Scenario 1 , Error While Updating PM Data , Check Logs");
								    			}
								    		}
							    			
							    			else
							    				{
							    					throw new Exception("Scenario 1 , Error While Renaming Location , Check Logs");
							    				}
							    		}
							    		
							    		if(dateFormat1.parse(arrParams[4]).before(mxserver.getDate()))
							    		{
							    			//System.out.println(" In Scenario : 1 , Effective Date is before Current Date");
							    			//System.out.println("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Meters Will Be Copied along with Meter Readings after Effective Date");
							    			logger.info(" In Scenario : 1 , Effective Date is before Current Date");
							    			logger.info("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Meters Will Be Copied along with Meter Readings after Effective Date");
							    			mxLog.writeLog(" In Scenario : 1 , Effective Date is before Current Date");
							    			mxLog.writeLog("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Meters Will Be Copied along with Meter Readings after Effective Date");
							    			
							    			if(locRenamewithEffectiveDate())
						    				{
							    			//System.out.println("Scenario 1.1 ,Location Renamed Successfully");
									    	logger.info("Scenario 1.1 ,Location Renamed Successfully");
									    	mxLog.writeLog("Scenario 1.1 ,Location Renamed Successfully");
									    	
								    			if(updatePMforS1())
								    			{
								    				//System.out.println("Scenario 1.1 , PM Data Updated Successfully");
										    		logger.info("Scenario 1.1 , PM Data Updated Successfully");
										    		mxLog.writeLog("Scenario 1.1 , PM Data Updated Successfully");
										    		
								    			}
								    			else
								    			{
								    				throw new Exception("Scenario 1.1 , Error While Updating PM Data , Check Logs");
								    			}
								    		}
							    			
							    			else
						    				{
						    					throw new Exception("Scenario 1.1 , Error While Renaming Location , Check Logs");
						    				}
							    		}
							    	}
							    else
							    	{
							    		//System.out.println("Old Site And New Site are not same, Old and New Site are not same , Exiting Scenario : 1 , Check Parameter values ");
							    		logger.info("Old Site And New Site are not same, Old and New Site are not same , Exiting Scenario : 1 , Check Parameter values ");
							    		mxLog.writeLog("Old Site And New Site are not same, Old and New Site are not same , Exiting Scenario : 1 , Check Parameter values ");
								    	
							    	}
						    }
	
						 else if(arrParams[0].equalsIgnoreCase(arrParams[1]))
						    {
							 	//System.out.println("Old Location And New Location are same, Entered Scenario : 2 , Checking For Site");
							 	logger.info("Old Location And New Location are same, Entered Scenario : 2 , Checking For Site");
							 	mxLog.writeLog("Old Location And New Location are same, Entered Scenario : 2 , Checking For Site");
							    
							 	if(!arrParams[2].equalsIgnoreCase(arrParams[3]))
							    	
							    	{
							    		//System.out.println("Old Site And New Site are not same, In Scenario : 2 , Meters will be copied to new location ");
							    		logger.info("Old Site And New Site are not same, In Scenario : 2 , Meters will be copied to new location ");
							    		mxLog.writeLog("Old Site And New Site are not same, In Scenario : 2 , Meters will be copied to new location ");
							    		
							    		if(locationRenameWithSite())
					    				{
							    		//System.out.println("Scenario 2 ,Location Renamed Successfully");
									    logger.info("Scenario 2 ,Location Renamed Successfully");
									    mxLog.writeLog("Scenario 2 ,Location Renamed Successfully");
									    	
									    	if(updatePMforS2())
							    			{
							    				//System.out.println("Scenario 2 ,PM Data Updated Successfully");
									    		logger.info("Scenario 2 ,PM Data Updated Successfully");
									    		mxLog.writeLog("Scenario 2 ,PM Data Updated Successfully");
									    		
							    			}
							    			else
							    			{
							    				throw new Exception("Scenario 2 , Error While Updating PM Data , Check Logs");
							    			}
							    		}
							    		else
					    				{
					    					throw new Exception("Scenario 2 , Error While Renaming Location , Check Logs");
					    				}
							    	}
							    else
							    	{
							    		//System.out.println("Old Site And New Site are same,Exiting Scenario : 2 , Meters will be copied to new location ");
							    		logger.info("Old Site And New Site are same,Exiting Scenario : 2 , Meters will be copied to new location ");
							    		mxLog.writeLog("Old Site And New Site are same,Exiting Scenario : 2 , Meters will be copied to new location ");
							    		
							    	}
						    }
					    
						 else if(("OLD_"+arrParams[0]).equalsIgnoreCase(arrParams[1]) && arrParams[1].toUpperCase().contains("OLD_"))
						    {
						    	//System.out.println("New Location id with Prefix OLD_ Entering Scenarion 3, Check For Sites");
						    	logger.info("New Location id with Prefix OLD_ Entering Scenarion 3, Check For Sites");
						    	mxLog.writeLog("New Location id with Prefix OLD_ Entering Scenarion 3, Check For Sites");
							    
						    	if(arrParams[2].equalsIgnoreCase(arrParams[3]))
							    	
							    	{
							    		//System.out.println("New Location id with Prefix OLD_ , Old and New Site are same In Scenarion 3");
							    		logger.info("New Location id with Prefix OLD_ , Old and New Site are same In Scenarion 3");
							    		mxLog.writeLog("New Location id with Prefix OLD_ , Old and New Site are same In Scenarion 3");
							    		
							    		if(dateFormat1.parse(arrParams[4]).after(mxserver.getDate()))
							    		{
							    			//System.out.println(" In Scenario : 3 , Effective Date is after Current Date");
							    			//System.out.println("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , All Meter Readings Will Be Copied to New Location and Old Location Meters will be Reset");
							    			logger.info(" In Scenario : 3 , Effective Date is after Current Date");
							    			logger.info("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , All Meter Readings Will Be Copied to New Location and Old Location Meters will be Reset");
							    			mxLog.writeLog(" In Scenario : 3 , Effective Date is after Current Date");
							    			mxLog.writeLog("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , All Meter Readings Will Be Copied to New Location and Old Location Meters will be Reset");
							    			
							    			if(locationPhysicalChange())
							    			{
							    			//System.out.println("Scenario 3 ,Location Renamed Successfully");
										    logger.info("Scenario 3 ,Location Renamed Successfully");
										    mxLog.writeLog("Scenario 3 ,Location Renamed Successfully");
										    	
								    			if(updatePMforS3())
								    			{
								    				//System.out.println("Scenario 3 , PM Data Updated Successfully");
										    		logger.info("Scenario 3 , PM Data Updated Successfully");
										    		mxLog.writeLog("Scenario 3 , PM Data Updated Successfully");
										    		
								    			}
								    			else
								    			{
								    				throw new Exception("Scenario 3 , Error While Updating PM Data , Check Logs");
								    			}
							    			}
							    			else
							    			{
							    				throw new Exception("Scenario 3 , Error While Renaming Location , Check Logs");
							    				
							    			}
							    		}
							    		
							    		if(dateFormat1.parse(arrParams[4]).before(mxserver.getDate()))
							    		{
							    			//System.out.println(" In Scenario : 3 , Effective Date is before Current Date");
							    			//System.out.println("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Meter Readings before effective date will Be Copied to New Location and Old Location Meters will be Reset with readings after effective date");
							    			logger.info(" In Scenario : 3 , Effective Date is before Current Date");
							    			logger.info("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Meter Readings before effective date will Be Copied to New Location and Old Location Meters will be Reset with readings after effective date");
							    			mxLog.writeLog(" In Scenario : 3 , Effective Date is before Current Date");
							    			mxLog.writeLog("Old Location : "+arrParams[0]+" will be Renamed to New Location : "+arrParams[1]+" , Meter Readings before effective date will Be Copied to New Location and Old Location Meters will be Reset with readings after effective date");
							    			
							    			if(locationPhysicalChangeWithDate())
							    			{
							    			//System.out.println("Scenario 3.1 ,Location Renamed Successfully");
										    logger.info("Scenario 3.1 ,Location Renamed Successfully");
										    mxLog.writeLog("Scenario 3.1 ,Location Renamed Successfully");
										    	
								    			if(updatePMforS3())
								    			{
								    				//System.out.println("Scenario 3.1 ,PM Data Updated Successfully");
										    		logger.info("Scenario 3.1 ,PM Data Updated Successfully");
										    		mxLog.writeLog("Scenario 3.1 ,PM Data Updated Successfully");
										    		
								    			}
								    			else
								    			{
								    				throw new Exception("Scenario 3.1 , Error While Updating PM Data , Check Logs");
								    			}
							    			}
							    			
							    			else
							    			{
							    				throw new Exception("Scenario 3.1 , Error While Renaming Location , Check Logs");
							    				
							    			}
							    		}
							    	}
						    }
						 
						 else
						 	{
							 throw new Exception("Parameter Values Given For Location Rename Related Fields Don't Evaluate to any Scenario, Please Check Values");	
						 	}    
						}
					 else
						{
							throw new Exception("Error While Configuring Logging and Email, Check Logs For Error");
						}
					}
				else
				{
					throw new Exception("Some Parameter Values are left blank , please fill values.");
				}
			}
		
		catch(Exception e)
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				if(mxLog.isEnabled())
				{
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				}
				//System.out.println("Email Genration : "+genEmail(message, stack));
				logger.info("Email Genration : "+genEmail(message, stack));
				email.send(emailSubj, genEmail(message, stack));
				logger.info((new StringBuilder(String.valueOf(getName()))).append(" Email sent").toString());
				stop();
			}
	}

	
	public boolean parameterCheck(String []arrParams)
	{
		boolean bFlag = true;
		for (int iParamCount = 0; iParamCount < arrParams.length; iParamCount++)	// Iteration on Parameter values
		{
			if (arrParams[iParamCount] == null || arrParams[iParamCount].equalsIgnoreCase("") || arrParams[iParamCount] == "") // Check for null parameter values
			{ 
				bFlag = false;
			} 
		}

		return bFlag;
	}
	
	public boolean locationPhysicalChange() 
	{
		boolean flag1 = true;
		//System.out.println("Match Found With Scenarion 3, Effective Date is After Current System Date , Cron Will Rename Location and Reset Meter Reading.");
		logger.info("Match Found With Scenarion 3, Effective Date is After Current System Date , Cron Will Rename Location and Reset Meter Reading.");
		mxLog.writeLog("Match Found With Scenarion 3, Effective Date is After Current System Date , Cron Will Rename Location and Reset Meter Reading.");
		String s = "Scenario 3 , After Effective Date ";
		try 
			{
				LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
				//System.out.println(s+"Count For All Locations "+locationSet.count());
				logger.info(s+"Count For All Locations "+locationSet.count());
				mxLog.writeLog(s+"Count For All Locations "+locationSet.count());
				locationSet.setWhere("LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"'");
				locationSet.reset();
				//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				
				LocationRemote loc = (LocationRemote) locationSet.getMbo(0);
				if(loc != null)
					{
						//System.out.println(s+" Old Location Match Found , Count Is "+locationSet.count());
						//System.out.println(s+" Old Location Is "+loc.getString("location"));
						logger.info(s+" Old Location Match Found , Count Is "+locationSet.count());
						logger.info(s+" Old Location Is "+loc.getString("location"));
						mxLog.writeLog(s+" Old Location Match Found , Count Is "+locationSet.count());
						mxLog.writeLog(s+" Old Location Is "+loc.getString("location"));
						
						locationSet.setWhere("LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"'");
						locationSet.reset();
						//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						//System.out.println("Count For New Location"+locationSet.count());
						logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						logger.info("Count For New Location"+locationSet.count());
						mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						mxLog.writeLog("Count For New Location"+locationSet.count());
						
						LocationRemote newloc = (LocationRemote) locationSet.getMbo(0);
						if(newloc != null)
							{
								//System.out.println(s+" New Location Match Found , Count Is "+locationSet.count());
								//System.out.println(s+" New Location Is "+newloc.getString("location"));
								//System.out.println(s+" Checking Meter Readings For New Location");
								logger.info(s+" New Location Match Found , Count Is "+locationSet.count());
								logger.info(s+" New Location Is "+newloc.getString("location"));
								logger.info(s+" Checking Meter Readings For New Location");
								mxLog.writeLog(s+" New Location Match Found , Count Is "+locationSet.count());
								mxLog.writeLog(s+" New Location Is "+newloc.getString("location"));
								mxLog.writeLog(s+" Checking Meter Readings For New Location");
								
								LocMeterReadingSetRemote locMeterReadingSet=(LocMeterReadingSetRemote)newloc.getMboSet("LOCMETERREADINGS");
								if(locMeterReadingSet.count() == 0)
									{
										//System.out.println(s+" No Meter Readings For New Location, Location Rename Will Continue");
										logger.info(s+" No Meter Readings For New Location, Location Rename Will Continue");
										mxLog.writeLog(s+" No Meter Readings For New Location, Location Rename Will Continue");
										
										LocationMeterSetRemote locmeterset = (LocationMeterSetRemote)loc.getMboSet("LOCATIONMETER");
										LocationMeterSetRemote newlocmeterset = (LocationMeterSetRemote)newloc.getMboSet("LOCATIONMETER");	
										//System.out.println(s+" Meter Count For Old Location "+locmeterset.count());
										//System.out.println(s+" Meter Count For New Location "+newlocmeterset.count());
										logger.info(s+" Meter Count For Old Location "+locmeterset.count());
										logger.info(s+" Meter Count For New Location "+newlocmeterset.count());
										mxLog.writeLog(s+" Meter Count For Old Location "+locmeterset.count());
										mxLog.writeLog(s+" Meter Count For New Location "+newlocmeterset.count());
										
										if(locmeterset.count()!=0)
											{
												//System.out.println(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												logger.info(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												mxLog.writeLog(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												
												LocationMeterRemote locmeter;
												LocationMeterRemote newlocmeter;
												if(newlocmeterset.count() == 0)
												{
													//System.out.println(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													logger.info(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													mxLog.writeLog(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
														{
															//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															
															
															newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
															//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															
															if(!setMeterValuesPhysical(newlocmeter, locmeter))
															{
																throw new Exception(s+"Error Adding Meters , Check The Logs");
															}
														}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													//System.out.println("Updating Old Location Meter Reading To New Location Meter Readings");
													logger.info("Updating Old Location Meter Reading To New Location Meter Readings");
													mxLog.writeLog("Updating Old Location Meter Reading To New Location Meter Readings");
													if(!updateMeterReadings())
													{
														throw new Exception(s+"Error Updating Meter Readings");
													}
													if(!updatelastreading())
													{
														throw new Exception(s+"Error While Updating Lase Meter Readings For New Location");
													}
													if(!resetMeters())
													{
														throw new Exception(s+"Error while Meter Reset for Old Location");
													}
													//System.out.println(s+" Location Renamed Succecfully");
													logger.info(s+" Location Renamed Succecfully");
													mxLog.writeLog(s+" Location Renamed Succecfully");
													
												}
												
												else if(newlocmeterset.count() != 0)
												{
													//System.out.println(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													//System.out.println(s+" Count For Meters In New Location "+newlocmeterset.count());
													logger.info(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													logger.info(s+" Count For Meters In New Location "+newlocmeterset.count());
													mxLog.writeLog(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													mxLog.writeLog(s+" Count For Meters In New Location "+newlocmeterset.count());
													
													LocationMeterRemote newlocmeter1 ;
													LocationMeterRemote[] keys = new LocationMeterRemote[newlocmeterset.count()] ;	
													for (int m=0; ((newlocmeter1 = (LocationMeterRemote) newlocmeterset.getMbo(m))!= null);m++)
													{
														//System.out.println(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														logger.info(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														mxLog.writeLog(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														
														keys[m] = newlocmeter1;									
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters ");
													logger.info(s+" Matching Old Location Meters With New Location Meters ");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														logger.info(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														mxLog.writeLog(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														
														for (LocationMeterRemote str : keys) 
														{
															if (str.getString("METERNAME").toUpperCase().equalsIgnoreCase(locmeter.getString("METERNAME").toUpperCase())) 
															{
																//System.out.println("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																//System.out.println("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																logger.info("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																logger.info("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																str.delete();
															} 					            
														}
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													logger.info(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													
													newlocmeterset.save();	
													//System.out.println(s+" Meters Saved");
													logger.info(s+" Meters Saved");
													mxLog.writeLog(s+" Meters Saved");
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														
														newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
														//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														
														if(!setMeterValues(newlocmeter, locmeter))
														{
															throw new Exception(s+"Error Adding Meters , Check The Logs");
														}
														
													}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													//System.out.println("Updating Old Location Meter Reading To New Location Meter Readings");
													logger.info("Updating Old Location Meter Reading To New Location Meter Readings");
													mxLog.writeLog("Updating Old Location Meter Reading To New Location Meter Readings");
													if(!updateMeterReadings())
													{
														throw new Exception(s+"Error Updating Meter Readings");
													}
													if(!updatelastreading())
													{
														throw new Exception(s+"Error While Updating Lase Meter Readings For New Location");
													}
													if(!resetMeters())
													{
														throw new Exception(s+"Error while Meter Reset for Old Location");
													}
													//System.out.println(s+" Location Renamed Succecfully");
													logger.info(s+" Location Renamed Succecfully");
													mxLog.writeLog(s+" Location Renamed Succecfully");
													
												}	
											}	
										else
										{
											//System.out.println("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											logger.info("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											mxLog.writeLog("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											
											flag1 = false;
										}	
											}
								else
								{
									//System.out.println("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									logger.info("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									mxLog.writeLog("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									flag1 = false;
								}	
									
							}
								
								
						else
						{
							//System.out.println(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							logger.info(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							mxLog.writeLog(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							
							flag1 = false;
						}
								
					}	
				else
				{	
					//System.out.println(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					logger.info(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					mxLog.writeLog(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					
					flag1 = false;
				}
				
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				flag1 = false;
			}
		return flag1;
	}
	
	public boolean locationPhysicalChangeWithDate() 
	{
		boolean flag1 = true;
		//System.out.println("Match Found With Scenarion 3.1, Effective Date is Before Current System Date , Cron Will Rename Location and Reset Meter Reading.");
		logger.info("Match Found With Scenarion 3.1, Effective Date is Before Current System Date , Cron Will Rename Location and Reset Meter Reading.");
		mxLog.writeLog("Match Found With Scenarion 3.1, Effective Date is Before Current System Date , Cron Will Rename Location and Reset Meter Reading.");
		String s = "Scenario 3.1 , Before Effective Date ";
		try 
			{
				LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
				//System.out.println(s+"Count For All Locations "+locationSet.count());
				logger.info(s+"Count For All Locations "+locationSet.count());
				mxLog.writeLog(s+"Count For All Locations "+locationSet.count());
				locationSet.setWhere("LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"'");
				locationSet.reset();
				//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				
				LocationRemote loc = (LocationRemote) locationSet.getMbo(0);
				if(loc != null)
					{
						//System.out.println(s+" Old Location Match Found , Count Is "+locationSet.count());
						//System.out.println(s+" Old Location Is "+loc.getString("location"));
						logger.info(s+" Old Location Match Found , Count Is "+locationSet.count());
						logger.info(s+" Old Location Is "+loc.getString("location"));
						mxLog.writeLog(s+" Old Location Match Found , Count Is "+locationSet.count());
						mxLog.writeLog(s+" Old Location Is "+loc.getString("location"));
						
						locationSet.setWhere("LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"'");
						locationSet.reset();
						//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						//System.out.println("Count For New Location"+locationSet.count());
						logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						logger.info("Count For New Location"+locationSet.count());
						mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						mxLog.writeLog("Count For New Location"+locationSet.count());
						
						LocationRemote newloc = (LocationRemote) locationSet.getMbo(0);
						if(newloc != null)
							{
								//System.out.println(s+" New Location Match Found , Count Is "+locationSet.count());
								//System.out.println(s+" New Location Is "+newloc.getString("location"));
								//System.out.println(s+" Checking Meter Readings For New Location");
								logger.info(s+" New Location Match Found , Count Is "+locationSet.count());
								logger.info(s+" New Location Is "+newloc.getString("location"));
								logger.info(s+" Checking Meter Readings For New Location");
								mxLog.writeLog(s+" New Location Match Found , Count Is "+locationSet.count());
								mxLog.writeLog(s+" New Location Is "+newloc.getString("location"));
								mxLog.writeLog(s+" Checking Meter Readings For New Location");
								
								LocMeterReadingSetRemote locMeterReadingSet=(LocMeterReadingSetRemote)newloc.getMboSet("LOCMETERREADINGS");
								if(locMeterReadingSet.count() == 0)
									{
										//System.out.println(s+" No Meter Readings For New Location, Location Rename Will Continue");
										logger.info(s+" No Meter Readings For New Location, Location Rename Will Continue");
										mxLog.writeLog(s+" No Meter Readings For New Location, Location Rename Will Continue");
										
										LocationMeterSetRemote locmeterset = (LocationMeterSetRemote)loc.getMboSet("LOCATIONMETER");
										LocationMeterSetRemote newlocmeterset = (LocationMeterSetRemote)newloc.getMboSet("LOCATIONMETER");	
										//System.out.println(s+" Meter Count For Old Location "+locmeterset.count());
										//System.out.println(s+" Meter Count For New Location "+newlocmeterset.count());
										logger.info(s+" Meter Count For Old Location "+locmeterset.count());
										logger.info(s+" Meter Count For New Location "+newlocmeterset.count());
										mxLog.writeLog(s+" Meter Count For Old Location "+locmeterset.count());
										mxLog.writeLog(s+" Meter Count For New Location "+newlocmeterset.count());
										
										if(locmeterset.count()!=0)
											{
												//System.out.println(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												logger.info(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												mxLog.writeLog(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												
												LocationMeterRemote locmeter;
												LocationMeterRemote newlocmeter;
												if(newlocmeterset.count() == 0)
												{
													//System.out.println(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													logger.info(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													mxLog.writeLog(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
														{
															//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															
															
															newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
															//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															
															if(!setMeterValuesPhysical(newlocmeter, locmeter))
															{
																throw new Exception(s+"Error Adding Meters , Check The Logs");
															}
														}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													//System.out.println("Updating Old Location Meter Reading To New Location Meter Readings");
													logger.info("Updating Old Location Meter Reading To New Location Meter Readings");
													mxLog.writeLog("Updating Old Location Meter Reading To New Location Meter Readings");
													if(!updateMeterReadings())
													{
														throw new Exception(s+"Error Updating Meter Readings");
													}
													if(!updatelastreading())
													{
														throw new Exception(s+"Error While Updating Lase Meter Readings For New Location");
													}
													if(!resetMeters())
													{
														throw new Exception(s+"Error while Meter Reset For Old Location");
													}
													if(!resetMetersWithEff())
													{
														throw new Exception(s+"Error while Meter Reading Reset with Effective Date For Old Location");
													}
													//System.out.println(s+" Location Renamed Succecfully");
													logger.info(s+" Location Renamed Succecfully");
													mxLog.writeLog(s+" Location Renamed Succecfully");
													
												}
												
												else if(newlocmeterset.count() != 0)
												{
													//System.out.println(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													//System.out.println(s+" Count For Meters In New Location "+newlocmeterset.count());
													logger.info(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													logger.info(s+" Count For Meters In New Location "+newlocmeterset.count());
													mxLog.writeLog(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													mxLog.writeLog(s+" Count For Meters In New Location "+newlocmeterset.count());
													
													LocationMeterRemote newlocmeter1 ;
													LocationMeterRemote[] keys = new LocationMeterRemote[newlocmeterset.count()] ;	
													for (int m=0; ((newlocmeter1 = (LocationMeterRemote) newlocmeterset.getMbo(m))!= null);m++)
													{
														//System.out.println(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														logger.info(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														mxLog.writeLog(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														
														keys[m] = newlocmeter1;									
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters ");
													logger.info(s+" Matching Old Location Meters With New Location Meters ");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														logger.info(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														mxLog.writeLog(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														
														for (LocationMeterRemote str : keys) 
														{
															if (str.getString("METERNAME").toUpperCase().equalsIgnoreCase(locmeter.getString("METERNAME").toUpperCase())) 
															{
																//System.out.println("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																//System.out.println("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																logger.info("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																logger.info("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																str.delete();
															} 					            
														}
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													logger.info(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													
													newlocmeterset.save();	
													//System.out.println(s+" Meters Saved");
													logger.info(s+" Meters Saved");
													mxLog.writeLog(s+" Meters Saved");
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														
														newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
														//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														
														if(!setMeterValues(newlocmeter, locmeter))
														{
															throw new Exception(s+"Error Adding Meters , Check The Logs");
														}
														
													}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													//System.out.println("Updating Old Location Meter Reading To New Location Meter Readings");
													logger.info("Updating Old Location Meter Reading To New Location Meter Readings");
													mxLog.writeLog("Updating Old Location Meter Reading To New Location Meter Readings");
													if(!updateMeterReadings())
													{
														throw new Exception(s+"Error Updating Meter Readings");
													}
													if(!updatelastreading())
													{
														throw new Exception(s+"Error While Updating Lase Meter Readings For New Location");
													}
													if(!resetMeters())
													{
														throw new Exception(s+"Error while Meter Reset For Old Location");
													}
													if(!resetMetersWithEff())
													{
														throw new Exception(s+"Error while Meter Reading Reset with Effective Date For Old Location");
													}
													//System.out.println(s+" Location Renamed Succecfully");
													logger.info(s+" Location Renamed Succecfully");
													mxLog.writeLog(s+" Location Renamed Succecfully");
													
												}	
											}	
										else
										{
											//System.out.println("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											logger.info("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											mxLog.writeLog("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											
											flag1 = false;
										}	
											}
								else
								{
									//System.out.println("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									logger.info("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									mxLog.writeLog("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									flag1 = false;
								}	
									
							}
								
								
						else
						{
							//System.out.println(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							logger.info(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							mxLog.writeLog(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							
							flag1 = false;
						}
								
					}	
				else
				{	
					//System.out.println(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					logger.info(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					mxLog.writeLog(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					
					flag1 = false;
				}
				
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag1 = false;
			}
		return flag1;
	}

	public boolean locationRenameWithSite() 
	{
		boolean flag1 = true;
		//System.out.println("Match Found With Scenarion 2, Site is Different , Cron Will Rename Location and Update Last Reading.");
		logger.info("Match Found With Scenarion 2, Site is Different , Cron Will Rename Location and Update Last Reading.");
		mxLog.writeLog("Match Found With Scenarion 2, Site is Different , Cron Will Rename Location and Update Last Reading.");
		String s = "Scenario 2 , Site is Different ";
		try 
			{
				LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
				//System.out.println(s+"Count For All Locations "+locationSet.count());
				logger.info(s+"Count For All Locations "+locationSet.count());
				mxLog.writeLog(s+"Count For All Locations "+locationSet.count());
				locationSet.setWhere("LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"'");
				locationSet.reset();
				//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				
				LocationRemote loc = (LocationRemote) locationSet.getMbo(0);
				if(loc != null)
					{
						//System.out.println(s+" Old Location Match Found , Count Is "+locationSet.count());
						//System.out.println(s+" Old Location Is "+loc.getString("location"));
						logger.info(s+" Old Location Match Found , Count Is "+locationSet.count());
						logger.info(s+" Old Location Is "+loc.getString("location"));
						mxLog.writeLog(s+" Old Location Match Found , Count Is "+locationSet.count());
						mxLog.writeLog(s+" Old Location Is "+loc.getString("location"));
						
						locationSet.setWhere("LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"'");
						locationSet.reset();
						//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						//System.out.println("Count For New Location"+locationSet.count());
						logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						logger.info("Count For New Location"+locationSet.count());
						mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						mxLog.writeLog("Count For New Location"+locationSet.count());
						
						LocationRemote newloc = (LocationRemote) locationSet.getMbo(0);
						if(newloc != null)
							{
								//System.out.println(s+" New Location Match Found , Count Is "+locationSet.count());
								//System.out.println(s+" New Location Is "+newloc.getString("location"));
								//System.out.println(s+" Checking Meter Readings For New Location");
								logger.info(s+" New Location Match Found , Count Is "+locationSet.count());
								logger.info(s+" New Location Is "+newloc.getString("location"));
								logger.info(s+" Checking Meter Readings For New Location");
								mxLog.writeLog(s+" New Location Match Found , Count Is "+locationSet.count());
								mxLog.writeLog(s+" New Location Is "+newloc.getString("location"));
								mxLog.writeLog(s+" Checking Meter Readings For New Location");
								
								LocMeterReadingSetRemote locMeterReadingSet=(LocMeterReadingSetRemote)newloc.getMboSet("LOCMETERREADINGS");
								if(locMeterReadingSet.count() == 0)
									{
										//System.out.println(s+" No Meter Readings For New Location, Location Rename Will Continue");
										logger.info(s+" No Meter Readings For New Location, Location Rename Will Continue");
										mxLog.writeLog(s+" No Meter Readings For New Location, Location Rename Will Continue");
										
										LocationMeterSetRemote locmeterset = (LocationMeterSetRemote)loc.getMboSet("LOCATIONMETER");
										LocationMeterSetRemote newlocmeterset = (LocationMeterSetRemote)newloc.getMboSet("LOCATIONMETER");	
										//System.out.println(s+" Meter Count For Old Location "+locmeterset.count());
										//System.out.println(s+" Meter Count For New Location "+newlocmeterset.count());
										logger.info(s+" Meter Count For Old Location "+locmeterset.count());
										logger.info(s+" Meter Count For New Location "+newlocmeterset.count());
										mxLog.writeLog(s+" Meter Count For Old Location "+locmeterset.count());
										mxLog.writeLog(s+" Meter Count For New Location "+newlocmeterset.count());
										
										if(locmeterset.count()!=0)
											{
												//System.out.println(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												logger.info(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												mxLog.writeLog(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												
												LocationMeterRemote locmeter;
												LocationMeterRemote newlocmeter;
												if(newlocmeterset.count() == 0)
												{
													//System.out.println(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													logger.info(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													mxLog.writeLog(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
														{
														//	System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															
															
															newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
															//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															
															if(!setMeterValues(newlocmeter, locmeter))
															{
																throw new Exception(s+"Error Adding Meters , Check The Logs");
															}
														}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													
													if(!setDelta(locMeterReadingSet))
													{
														throw new Exception(s+"Error Setting Delta For Meters");
													}
													//System.out.println(s+" Delta Updated for New Added Meters");
													logger.info(s+" Delta Updated for New Added Meters");
													mxLog.writeLog(s+" Delta Updated for New Added Meters");
													
												}
												
												else if(newlocmeterset.count() != 0)
												{
													//System.out.println(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													//System.out.println(s+" Count For Meters In New Location "+newlocmeterset.count());
													logger.info(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													logger.info(s+" Count For Meters In New Location "+newlocmeterset.count());
													mxLog.writeLog(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													mxLog.writeLog(s+" Count For Meters In New Location "+newlocmeterset.count());
													
													LocationMeterRemote newlocmeter1 ;
													LocationMeterRemote[] keys = new LocationMeterRemote[newlocmeterset.count()] ;	
													for (int m=0; ((newlocmeter1 = (LocationMeterRemote) newlocmeterset.getMbo(m))!= null);m++)
													{
														//System.out.println(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														logger.info(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														mxLog.writeLog(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														
														keys[m] = newlocmeter1;									
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters ");
													logger.info(s+" Matching Old Location Meters With New Location Meters ");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														logger.info(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														mxLog.writeLog(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														
														for (LocationMeterRemote str : keys) 
														{
															if (str.getString("METERNAME").toUpperCase().equalsIgnoreCase(locmeter.getString("METERNAME").toUpperCase())) 
															{
																//System.out.println("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																//System.out.println("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																logger.info("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																logger.info("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																str.delete();
															} 					            
														}
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													logger.info(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													
													newlocmeterset.save();	
													//System.out.println(s+" Meters Saved");
													logger.info(s+" Meters Saved");
													mxLog.writeLog(s+" Meters Saved");
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														
														newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
														//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														
														if(!setMeterValues(newlocmeter, locmeter))
														{
															throw new Exception(s+"Error Adding Meters , Check The Logs");
														}
														
													}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													
													if(!setDelta(locMeterReadingSet))
													{
														throw new Exception(s+"Error Setting Delta For Meters");
													}
													//System.out.println(s+" Delta Updated for New Added Meters");
													logger.info(s+" Delta Updated for New Added Meters");
													mxLog.writeLog(s+" Delta Updated for New Added Meters");
													
												}	
											}	
										else
										{
											//System.out.println("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											logger.info("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											mxLog.writeLog("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											
											flag1 = false;
										}	
											}
								else
								{
									//System.out.println("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									logger.info("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									mxLog.writeLog("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									flag1 = false;
								}	
									
							}
								
								
						else
						{
							//System.out.println(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							logger.info(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							mxLog.writeLog(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							
							flag1 = false;
						}
								
					}	
				else
				{	
					//System.out.println(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					logger.info(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					mxLog.writeLog(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					
					flag1 = false;
				}
				
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag1 = false;
			}
		return flag1;
	}
	
	public boolean locRenamewithEffectiveDate() 
	{
		boolean flag1 = true;
		//System.out.println("Match Found With Scenarion 1.1, Effective Date is Before Current System Date , Cron Will Rename Location and Update Last Reading.");
		logger.info("Match Found With Scenarion 1.1, Effective Date is Before Current System Date , Cron Will Rename Location and Update Last Reading.");
		mxLog.writeLog("Match Found With Scenarion 1.1, Effective Date is Before Current System Date , Cron Will Rename Location and Update Last Reading.");
		String s = "Scenario 1.1 , Before Effective Date ";
		try 
			{
				LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
				//System.out.println(s+"Count For All Locations "+locationSet.count());
				logger.info(s+"Count For All Locations "+locationSet.count());
				mxLog.writeLog(s+"Count For All Locations "+locationSet.count());
				locationSet.setWhere("LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"'");
				locationSet.reset();
				//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				
				LocationRemote loc = (LocationRemote) locationSet.getMbo(0);
				if(loc != null)
					{
						//System.out.println(s+" Old Location Match Found , Count Is "+locationSet.count());
						//System.out.println(s+" Old Location Is "+loc.getString("location"));
						logger.info(s+" Old Location Match Found , Count Is "+locationSet.count());
						logger.info(s+" Old Location Is "+loc.getString("location"));
						mxLog.writeLog(s+" Old Location Match Found , Count Is "+locationSet.count());
						mxLog.writeLog(s+" Old Location Is "+loc.getString("location"));
						
						locationSet.setWhere("LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"'");
						locationSet.reset();
						//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						//System.out.println("Count For New Location"+locationSet.count());
						logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						logger.info("Count For New Location"+locationSet.count());
						mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						mxLog.writeLog("Count For New Location"+locationSet.count());
						
						LocationRemote newloc = (LocationRemote) locationSet.getMbo(0);
						if(newloc != null)
							{
								//System.out.println(s+" New Location Match Found , Count Is "+locationSet.count());
								//System.out.println(s+" New Location Is "+newloc.getString("location"));
								//System.out.println(s+" Checking Meter Readings For New Location");
								logger.info(s+" New Location Match Found , Count Is "+locationSet.count());
								logger.info(s+" New Location Is "+newloc.getString("location"));
								logger.info(s+" Checking Meter Readings For New Location");
								mxLog.writeLog(s+" New Location Match Found , Count Is "+locationSet.count());
								mxLog.writeLog(s+" New Location Is "+newloc.getString("location"));
								mxLog.writeLog(s+" Checking Meter Readings For New Location");
								
								LocMeterReadingSetRemote locMeterReadingSet=(LocMeterReadingSetRemote)newloc.getMboSet("LOCMETERREADINGS");
								if(locMeterReadingSet.count() == 0)
									{
										//System.out.println(s+" No Meter Readings For New Location, Location Rename Will Continue");
										logger.info(s+" No Meter Readings For New Location, Location Rename Will Continue");
										mxLog.writeLog(s+" No Meter Readings For New Location, Location Rename Will Continue");
										
										LocationMeterSetRemote locmeterset = (LocationMeterSetRemote)loc.getMboSet("LOCATIONMETER");
										LocationMeterSetRemote newlocmeterset = (LocationMeterSetRemote)newloc.getMboSet("LOCATIONMETER");	
										//System.out.println(s+" Meter Count For Old Location "+locmeterset.count());
										//System.out.println(s+" Meter Count For New Location "+newlocmeterset.count());
										logger.info(s+" Meter Count For Old Location "+locmeterset.count());
										logger.info(s+" Meter Count For New Location "+newlocmeterset.count());
										mxLog.writeLog(s+" Meter Count For Old Location "+locmeterset.count());
										mxLog.writeLog(s+" Meter Count For New Location "+newlocmeterset.count());
										
										if(locmeterset.count()!=0)
											{
												//System.out.println(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												logger.info(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												mxLog.writeLog(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												
												LocationMeterRemote locmeter;
												LocationMeterRemote newlocmeter;
												if(newlocmeterset.count() == 0)
												{
													//System.out.println(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													logger.info(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													mxLog.writeLog(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
														{
															//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															
															
															newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
															//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															
															if(!setMeterValuesWithEffectiveDate(newlocmeter, locmeter))
															{
																throw new Exception(s+"Error Adding Meters , Check The Logs");
															}
														}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													
													if(!setDelta(locMeterReadingSet))
													{
														throw new Exception(s+"Error Setting Delta For Meters");
													}
													//System.out.println(s+" Delta Updated for New Added Meters");
													logger.info(s+" Delta Updated for New Added Meters");
													mxLog.writeLog(s+" Delta Updated for New Added Meters");
													//System.out.println(s+" Adding Meter Readings For New Location Meters After Effective Date");
													logger.info(s+" Adding Meter Readings For New Location Meters After Effective Date");
													mxLog.writeLog(s+" Adding Meter Readings For New Location Meters After Effective Date");
													if(!addMeterReadings(locmeterset,newloc, loc))
													{
														throw new Exception(s+"Error Copying Meter Reading To New Location, Check Logs");
													}
													else
													{
														if(updatemeterfileds(locmeterset,newloc,loc))
														{

															if(!deleteMeterReadings())
															{
																throw new Exception(s+"Error Deleting Meter Reading From Old Location, Check Logs");
															}
															else
															{
																if(!updatelastreadingoldloc())
																{
																	throw new Exception(s+"Error While updating last reading for Old Location, Check Logs");
																}
															}
														}
														
														else
														{
															throw new Exception(s+"Error While updating fields for new Locations, Check Logs");
														}
														
													}
													//System.out.println(s+" Meter Readings Copied From Old Location to New Location , After Effective Date");
													logger.info(s+" Meter Readings Copied From Old Location to New Location , After Effective Date");
													mxLog.writeLog(s+" Meter Readings Copied From Old Location to New Location , After Effective Date");
												}
												
												else if(newlocmeterset.count() != 0)
												{
													//System.out.println(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													//System.out.println(s+" Count For Meters In New Location "+newlocmeterset.count());
													logger.info(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													logger.info(s+" Count For Meters In New Location "+newlocmeterset.count());
													mxLog.writeLog(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													mxLog.writeLog(s+" Count For Meters In New Location "+newlocmeterset.count());
													
													LocationMeterRemote newlocmeter1 ;
													LocationMeterRemote[] keys = new LocationMeterRemote[newlocmeterset.count()] ;	
													for (int m=0; ((newlocmeter1 = (LocationMeterRemote) newlocmeterset.getMbo(m))!= null);m++)
													{
														//System.out.println(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														logger.info(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														mxLog.writeLog(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														
														keys[m] = newlocmeter1;									
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters ");
													logger.info(s+" Matching Old Location Meters With New Location Meters ");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														logger.info(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														mxLog.writeLog(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														
														for (LocationMeterRemote str : keys) 
														{
															if (str.getString("METERNAME").toUpperCase().equalsIgnoreCase(locmeter.getString("METERNAME").toUpperCase())) 
															{
																//System.out.println("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																//System.out.println("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																logger.info("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																logger.info("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																str.delete();
															} 					            
														}
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													logger.info(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													
													newlocmeterset.save();	
													//System.out.println(s+" Meters Saved");
													logger.info(s+" Meters Saved");
													mxLog.writeLog(s+" Meters Saved");
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														
														newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
														//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														
														if(!setMeterValuesWithEffectiveDate(newlocmeter, locmeter))
														{
															throw new Exception(s+"Error Adding Meters , Check The Logs");
														}
														
													}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													
													if(!setDelta(locMeterReadingSet))
													{
														throw new Exception(s+"Error Setting Delta For Meters");
													}
													//System.out.println(s+" Delta Updated for New Added Meters");
													logger.info(s+" Delta Updated for New Added Meters");
													mxLog.writeLog(s+" Delta Updated for New Added Meters");
													//System.out.println(s+" Adding Meter Readings For New Location Meters After Effective Date");
													logger.info(s+" Adding Meter Readings For New Location Meters After Effective Date");
													mxLog.writeLog(s+" Adding Meter Readings For New Location Meters After Effective Date");
													if(!addMeterReadings(locmeterset,newloc, loc))
													{
														throw new Exception(s+"Error Copying Meter Reading To New Location, Check Logs");
													}
													else
													{
														if(updatemeterfileds(locmeterset,newloc,loc))
														{

															if(!deleteMeterReadings())
															{
																throw new Exception(s+"Error Deleting Meter Reading From Old Location, Check Logs");
															}
															else
															{
																if(!updatelastreadingoldloc())
																{
																	throw new Exception(s+"Error While updating last reading for Old Location, Check Logs");
																}
															}
														}
														
														else
														{
															throw new Exception(s+"Error While updating fields for new Locations, Check Logs");
														}
														
													}
													//System.out.println(s+" Meter Readings Copied From Old Location to New Location , After Effective Date");
													logger.info(s+" Meter Readings Copied From Old Location to New Location , After Effective Date");
													mxLog.writeLog(s+" Meter Readings Copied From Old Location to New Location , After Effective Date");
												
													
												}	
											}	
										else
										{
											//System.out.println("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											logger.info("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											mxLog.writeLog("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											
											flag1 = false;
										}	
											}
								else
								{
									//System.out.println("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									logger.info("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									mxLog.writeLog("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									flag1 = false;
								}	
									
							}
								
								
						else
						{
							//System.out.println(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							logger.info(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							mxLog.writeLog(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							
							flag1 = false;
						}
								
					}	
				else
				{	
					//System.out.println(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					logger.info(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					mxLog.writeLog(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					
					flag1 = false;
				}

			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				flag1 = false;
			}
		return flag1;
	}
	
	public boolean locationRename() 
	{
		boolean flag1 = true;
		//System.out.println("Match Found With Scenarion 1, Effective Date is After Current System Date , Cron Will Rename Location and Update Last Reading.");
		logger.info("Match Found With Scenarion 1, Effective Date is After Current System Date , Cron Will Rename Location and Update Last Reading.");
		mxLog.writeLog("Match Found With Scenarion 1, Effective Date is After Current System Date , Cron Will Rename Location and Update Last Reading.");
		String s = "Scenario 1 , After Effective Date ";
		try 
			{
				LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
				//System.out.println(s+"Count For All Locations "+locationSet.count());
				logger.info(s+"Count For All Locations "+locationSet.count());
				mxLog.writeLog(s+"Count For All Locations "+locationSet.count());
				locationSet.setWhere("LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"'");
				locationSet.reset();
				//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"' "+locationSet.count());
				
				LocationRemote loc = (LocationRemote) locationSet.getMbo(0);
				if(loc != null)
					{
						//System.out.println(s+" Old Location Match Found , Count Is "+locationSet.count());
						//System.out.println(s+" Old Location Is "+loc.getString("location"));
						logger.info(s+" Old Location Match Found , Count Is "+locationSet.count());
						logger.info(s+" Old Location Is "+loc.getString("location"));
						mxLog.writeLog(s+" Old Location Match Found , Count Is "+locationSet.count());
						mxLog.writeLog(s+" Old Location Is "+loc.getString("location"));
						
						locationSet.setWhere("LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"'");
						locationSet.reset();
						//System.out.println(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						//System.out.println("Count For New Location"+locationSet.count());
						logger.info(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						logger.info("Count For New Location"+locationSet.count());
						mxLog.writeLog(s+"Count For Locations After Location and Site Set Where : "+"LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"' "+locationSet.count());
						mxLog.writeLog("Count For New Location"+locationSet.count());
						
						LocationRemote newloc = (LocationRemote) locationSet.getMbo(0);
						if(newloc != null)
							{
								//System.out.println(s+" New Location Match Found , Count Is "+locationSet.count());
								//System.out.println(s+" New Location Is "+newloc.getString("location"));
								//System.out.println(s+" Checking Meter Readings For New Location");
								logger.info(s+" New Location Match Found , Count Is "+locationSet.count());
								logger.info(s+" New Location Is "+newloc.getString("location"));
								logger.info(s+" Checking Meter Readings For New Location");
								mxLog.writeLog(s+" New Location Match Found , Count Is "+locationSet.count());
								mxLog.writeLog(s+" New Location Is "+newloc.getString("location"));
								mxLog.writeLog(s+" Checking Meter Readings For New Location");
								
								LocMeterReadingSetRemote locMeterReadingSet=(LocMeterReadingSetRemote)newloc.getMboSet("LOCMETERREADINGS");
								if(locMeterReadingSet.count() == 0)
									{
										//System.out.println(s+" No Meter Readings For New Location, Location Rename Will Continue");
										logger.info(s+" No Meter Readings For New Location, Location Rename Will Continue");
										mxLog.writeLog(s+" No Meter Readings For New Location, Location Rename Will Continue");
										
										LocationMeterSetRemote locmeterset = (LocationMeterSetRemote)loc.getMboSet("LOCATIONMETER");
										LocationMeterSetRemote newlocmeterset = (LocationMeterSetRemote)newloc.getMboSet("LOCATIONMETER");	
										//System.out.println(s+" Meter Count For Old Location "+locmeterset.count());
										//System.out.println(s+" Meter Count For New Location "+newlocmeterset.count());
										logger.info(s+" Meter Count For Old Location "+locmeterset.count());
										logger.info(s+" Meter Count For New Location "+newlocmeterset.count());
										mxLog.writeLog(s+" Meter Count For Old Location "+locmeterset.count());
										mxLog.writeLog(s+" Meter Count For New Location "+newlocmeterset.count());
										
										if(locmeterset.count()!=0)
											{
												//System.out.println(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												logger.info(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												mxLog.writeLog(s+" Meter Exits For Old Location, These Meters will Be Copied To New Location ");
												
												LocationMeterRemote locmeter;
												LocationMeterRemote newlocmeter;
												if(newlocmeterset.count() == 0)
												{
													//System.out.println(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													logger.info(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													mxLog.writeLog(s+" No Meter Exits For New Location, Copying Old Location Meters to New Location ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
														{
															//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
															
															
															newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
															//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
															
															if(!setMeterValues(newlocmeter, locmeter))
															{
																throw new Exception(s+"Error Adding Meters , Check The Logs");
															}
														}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													
													if(!setDelta(locMeterReadingSet))
													{
														throw new Exception(s+"Error Setting Delta For Meters");
													}
													//System.out.println(s+" Delta Updated for New Added Meters");
													logger.info(s+" Delta Updated for New Added Meters");
													mxLog.writeLog(s+" Delta Updated for New Added Meters");
													
												}
												
												else if(newlocmeterset.count() != 0)
												{
													//System.out.println(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													//System.out.println(s+" Count For Meters In New Location "+newlocmeterset.count());
													logger.info(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													logger.info(s+" Count For Meters In New Location "+newlocmeterset.count());
													mxLog.writeLog(s+" Meter Exits For New Location, Meters Matching with Old Location Meters will be deleted and Recopied to New Location ");
													mxLog.writeLog(s+" Count For Meters In New Location "+newlocmeterset.count());
													
													LocationMeterRemote newlocmeter1 ;
													LocationMeterRemote[] keys = new LocationMeterRemote[newlocmeterset.count()] ;	
													for (int m=0; ((newlocmeter1 = (LocationMeterRemote) newlocmeterset.getMbo(m))!= null);m++)
													{
														//System.out.println(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														logger.info(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														mxLog.writeLog(s+" Meter "+m+" In New Location "+newlocmeter1.getString("METERNAME"));
														
														keys[m] = newlocmeter1;									
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters ");
													logger.info(s+" Matching Old Location Meters With New Location Meters ");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters ");
													
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														logger.info(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														mxLog.writeLog(s+"Old Location Meter : "+locmeter.getString("METERNAME"));	
														
														for (LocationMeterRemote str : keys) 
														{
															if (str.getString("METERNAME").toUpperCase().equalsIgnoreCase(locmeter.getString("METERNAME").toUpperCase())) 
															{
																//System.out.println("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																//System.out.println("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																logger.info("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																logger.info("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Old Location Meter "+locmeter.getString("METERNAME")+" Already Exists In New Location "+newloc.getString("LOCATION"));
																mxLog.writeLog("Deleting Meter " + str.getString("METERNAME")+" From New Location "+newloc.getString("LOCATION"));
																str.delete();
															} 					            
														}
													}
													//System.out.println(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													logger.info(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													mxLog.writeLog(s+" Matching Old Location Meters With New Location Meters Deleted, Saving Meters");
													
													newlocmeterset.save();	
													//System.out.println(s+" Meters Saved");
													logger.info(s+" Meters Saved");
													mxLog.writeLog(s+" Meters Saved");
													for (int k=0; ((locmeter = (LocationMeterRemote) locmeterset.getMbo(k))!= null);k++)
													{
														//System.out.println(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														logger.info(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														mxLog.writeLog(s+"Copying "+locmeter.getString("METERNAME")+" From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
														
														newlocmeter = (LocationMeterRemote) newlocmeterset.addAtEnd();
														//System.out.println(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														logger.info(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														mxLog.writeLog(s+"Meter : "+locmeter.getString("METERNAME")+" Copied To New Location");
														
														if(!setMeterValues(newlocmeter, locmeter))
														{
															throw new Exception(s+"Error Adding Meters , Check The Logs");
														}
														
													}
													//System.out.println(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													//System.out.println(s+" Saving New Added Meters");
													logger.info(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													logger.info(s+" Saving New Added Meters");
													mxLog.writeLog(s+"Meters Added From Old Location "+loc.getString("LOCATION")+ " to New Location "+newloc.getString("LOCATION"));
													mxLog.writeLog(s+" Saving New Added Meters");
													
													newlocmeterset.save();
													//System.out.println(s+" New Added Meters Saved Succecfully");
													logger.info(s+" New Added Meters Saved Succecfully");
													mxLog.writeLog(s+" New Added Meters Saved Succecfully");
													
													if(!setDelta(locMeterReadingSet))
													{
														throw new Exception(s+"Error Setting Delta For Meters");
													}
													//System.out.println(s+" Delta Updated for New Added Meters");
													logger.info(s+" Delta Updated for New Added Meters");
													mxLog.writeLog(s+" Delta Updated for New Added Meters");
													
												}	
											}	
										else
										{
											//System.out.println("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											logger.info("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											mxLog.writeLog("Old Location don't has any associated meter "+loc.getString("LOCATION")+" No. Of Meters : "+locmeterset.count());
											
											flag1 = false;
										}	
											}
								else
								{
									//System.out.println("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									logger.info("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									mxLog.writeLog("Meter Readings Already Exists For New Location "+newloc.getString("LOCATION"));
									flag1 = false;
								}	
									
							}
								
								
						else
						{
							//System.out.println(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							logger.info(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							mxLog.writeLog(" New Location : "+arrParams[1]+" Does Not Exists On Site : "+arrParams[3] );
							
							flag1 = false;
						}
								
					}	
				else
				{	
					//System.out.println(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					logger.info(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					mxLog.writeLog(" Old Location : "+arrParams[0]+" Does Not Exists On Site : "+arrParams[2] );					
					
					flag1 = false;
				}
				
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag1 = false;
			}
		return flag1;
	}
	
	public boolean setMeterValues(LocationMeterRemote l1,LocationMeterRemote l2) 
	{
		boolean flag = false;
		try {
				//System.out.println(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				logger.info(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				mxLog.writeLog(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				
				l1.setValue("METERNAME", l2.getString("METERNAME"));
				l1.setValue("MEASUREUNITID", l2.getString("MEASUREUNITID"));
				l1.setValue("ACTIVE", l2.getString("ACTIVE"));
				l1.setValue("AVGCALCMETHOD", l2.getString("AVGCALCMETHOD"));
				l1.setValue("SLIDINGWINDOWSIZE", l2.getString("SLIDINGWINDOWSIZE"));
				l1.setValue("ROLLOVER", l2.getString("ROLLOVER"));
				l1.setValue("READINGTYPE", l2.getString("READINGTYPE"));
				//System.out.println(" Fields Copied For Meter : "+l2.getString("METERNAME")+" To New Location");
				//System.out.println(" Updating Last Reading For Meter : "+l2.getString("METERNAME")+" To New Location");
				logger.info(" Fields Copied For Meter : "+l2.getString("METERNAME")+" To New Location");
				logger.info(" Updating Last Reading For Meter : "+l2.getString("METERNAME")+" To New Location");
				mxLog.writeLog(" Fields Copied For Meter : "+l2.getString("METERNAME")+" To New Location");
				mxLog.writeLog(" Updating Last Reading For Meter : "+l2.getString("METERNAME")+" To New Location");
				
				LocMeterReadingRemote oldLocMeterReadingBeforeDate=(LocMeterReadingRemote)l2.getPreviousMeterReading(mxserver.getDate());
				if(oldLocMeterReadingBeforeDate != null)
				{
				//System.out.println("\nLast Reading: "+oldLocMeterReadingBeforeDate.getString("READING")+" Last Reading Date: "+oldLocMeterReadingBeforeDate.getString("READINGDATE"));
				logger.info("\nLast Reading: "+oldLocMeterReadingBeforeDate.getString("READING")+" Last Reading Date: "+oldLocMeterReadingBeforeDate.getString("READINGDATE"));
				mxLog.writeLog("\nLast Reading: "+oldLocMeterReadingBeforeDate.getString("READING")+" Last Reading Date: "+oldLocMeterReadingBeforeDate.getString("READINGDATE"));
				
				l1.setValue("LASTREADING", oldLocMeterReadingBeforeDate.getString("READING"));
				l1.setValue("LASTREADINGDATE", oldLocMeterReadingBeforeDate.getString("READINGDATE"));
				l1.setValue("LASTREADINGINSPCTR", oldLocMeterReadingBeforeDate.getString("INSPECTOR"));	
				l1.setValue("REMARKS", oldLocMeterReadingBeforeDate.getString("REASON"));
				}
				else
				{
					//System.out.println("Last Reading Does Not Exist For Meter "+l2.getString("METERNAME"));	
					logger.info("Last Reading Does Not Exist For Meter "+l2.getString("METERNAME"));	
					mxLog.writeLog("Last Reading Does Not Exist For Meter "+l2.getString("METERNAME"));	
					
				}
				l1.setValue("SINCELASTREPAIR", l2.getDouble("SINCELASTREPAIR"),MboConstants.NOACCESSCHECK);
				l1.setValue("SINCELASTOVERHAUL", l2.getDouble("SINCELASTOVERHAUL"),MboConstants.NOACCESSCHECK);
				l1.setValue("SINCELASTINSPECT", l2.getDouble("SINCELASTINSPECT"),MboConstants.NOACCESSCHECK);
				l1.setValue("SINCEINSTALL", l2.getDouble("SINCEINSTALL"),MboConstants.NOACCESSCHECK);
			
			flag = true;
			} 
		catch (Exception e) 
			{
				
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag = false;
			}
		
		return flag;
	}
	
	public  boolean setMeterValuesWithEffectiveDate(LocationMeterRemote l1,LocationMeterRemote l2) 
	{

		boolean flag = false;
		try {
				//System.out.println(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				logger.info(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				mxLog.writeLog(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				
				l1.setValue("METERNAME", l2.getString("METERNAME"));
				l1.setValue("MEASUREUNITID", l2.getString("MEASUREUNITID"));
				l1.setValue("ACTIVE", l2.getString("ACTIVE"));
				l1.setValue("AVGCALCMETHOD", l2.getString("AVGCALCMETHOD"));
				l1.setValue("SLIDINGWINDOWSIZE", l2.getString("SLIDINGWINDOWSIZE"));
				l1.setValue("ROLLOVER", l2.getString("ROLLOVER"));
				l1.setValue("READINGTYPE", l2.getString("READINGTYPE"));
				//System.out.println(" Fields Copied For Meter : "+l2.getString("METERNAME")+" To New Location");
				//System.out.println(" Updating Last Reading For Meter : "+l2.getString("METERNAME")+" To New Location");
				logger.info(" Fields Copied For Meter : "+l2.getString("METERNAME")+" To New Location");
				logger.info(" Updating Last Reading For Meter : "+l2.getString("METERNAME")+" To New Location");
				mxLog.writeLog(" Fields Copied For Meter : "+l2.getString("METERNAME")+" To New Location");
				mxLog.writeLog(" Updating Last Reading For Meter : "+l2.getString("METERNAME")+" To New Location");
				
				LocMeterReadingRemote oldLocMeterReadingBeforeDate=(LocMeterReadingRemote)l2.getPreviousMeterReading(dateFormat1.parse(arrParams[4]));
				if(oldLocMeterReadingBeforeDate != null)
				{
				//System.out.println("\nLast Reading: "+oldLocMeterReadingBeforeDate.getString("READING")+" Last Reading Date: "+oldLocMeterReadingBeforeDate.getString("READINGDATE"));
				logger.info("\nLast Reading: "+oldLocMeterReadingBeforeDate.getString("READING")+" Last Reading Date: "+oldLocMeterReadingBeforeDate.getString("READINGDATE"));
				mxLog.writeLog("\nLast Reading: "+oldLocMeterReadingBeforeDate.getString("READING")+" Last Reading Date: "+oldLocMeterReadingBeforeDate.getString("READINGDATE"));
				
				l1.setValue("LASTREADING", oldLocMeterReadingBeforeDate.getString("READING"));
				l1.setValue("LASTREADINGDATE", oldLocMeterReadingBeforeDate.getString("READINGDATE"));
				l1.setValue("LASTREADINGINSPCTR", oldLocMeterReadingBeforeDate.getString("INSPECTOR"));	
				l1.setValue("REMARKS", oldLocMeterReadingBeforeDate.getString("REASON"));
				}
				else
				{
					//System.out.println("Last Reading Does Not Exist For Meter "+l2.getString("METERNAME"));	
					logger.info("Last Reading Does Not Exist For Meter "+l2.getString("METERNAME"));	
					mxLog.writeLog("Last Reading Does Not Exist For Meter "+l2.getString("METERNAME"));	
					
				}
			
			
			flag = true;
			} 
		catch (Exception e) 
			{
				
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag = false;
			}
		
		return flag;
	}

	public boolean setMeterValuesPhysical(LocationMeterRemote l1,LocationMeterRemote l2) 
	{
		boolean flag = false;
		try {
				//System.out.println(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				logger.info(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				mxLog.writeLog(" Copying Fields For Meter : "+l2.getString("METERNAME")+" To New Location");
				
				l1.setValue("METERNAME", l2.getString("METERNAME"));
				l1.setValue("MEASUREUNITID", l2.getString("MEASUREUNITID"));
				l1.setValue("ACTIVE", l2.getString("ACTIVE"));
				l1.setValue("AVGCALCMETHOD", l2.getString("AVGCALCMETHOD"));
				l1.setValue("SLIDINGWINDOWSIZE", l2.getString("SLIDINGWINDOWSIZE"));
				l1.setValue("ROLLOVER", l2.getString("ROLLOVER"));
				l1.setValue("READINGTYPE", l2.getString("READINGTYPE"));
				l1.setValue("SINCELASTREPAIR", l2.getDouble("SINCELASTREPAIR"),MboConstants.NOACCESSCHECK);
				l1.setValue("SINCELASTOVERHAUL", l2.getDouble("SINCELASTOVERHAUL"),MboConstants.NOACCESSCHECK);
				l1.setValue("SINCELASTINSPECT", l2.getDouble("SINCELASTINSPECT"),MboConstants.NOACCESSCHECK);
				l1.setValue("SINCEINSTALL", l2.getDouble("SINCEINSTALL"),MboConstants.NOACCESSCHECK);
			
				//System.out.println(" Fields Copied For Meter : "+l2.getString("METERNAME")+" To New Location");
				
			flag = true;
			} 
		catch (Exception e) 
			{
				
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag = false;
			}
		
		return flag;
	}
	
	public boolean addMeterReadings(LocationMeterSetRemote ls1,LocationRemote l1,LocationRemote l2)
	{
		boolean flag = false;
		try
			{
				LocationMeterRemote locmeterr;
				LocationMeterRemote newlocmeterr;
				for (int k=0; ((locmeterr = (LocationMeterRemote) ls1.getMbo(k))!= null);k++)
				{
					//System.out.println("\n Adding Meter Reading After Effective date");
					logger.info("\n Adding Meter Reading After Effective date");
					mxLog.writeLog("\n Adding Meter Reading After Effective date");
					//System.out.println("Meter "+k+" In Old Location "+l2.getString("LOCATION")+ " is "+locmeterr.getString("METERNAME"));
					logger.info("Meter "+k+" In Old Location "+l2.getString("LOCATION")+ " is "+locmeterr.getString("METERNAME"));
					mxLog.writeLog("Meter "+k+" In Old Location "+l2.getString("LOCATION")+ " is "+locmeterr.getString("METERNAME"));
					LocMeterReadingSetRemote oldLocMeterReadingSet=(LocMeterReadingSetRemote)locmeterr.getMboSet("LOCMETERREADING");
					oldLocMeterReadingSet.setWhere("readingdate >= to_date('"+arrParams[4]+"','yyyy-mm-dd HH24:MI:SS')");
					oldLocMeterReadingSet.reset();
					oldLocMeterReadingSet.setOrderBy("READINGDATE");
					//System.out.println("Total No. Of Meter Reading In Old Location "+l2.getString("LOCATION")+" For Meter "+locmeterr.getString("METERNAME")+" are : "+oldLocMeterReadingSet.count());
					logger.info("Total No. Of Meter Reading In Old Location "+l2.getString("LOCATION")+" For Meter "+locmeterr.getString("METERNAME")+" are : "+oldLocMeterReadingSet.count());
					mxLog.writeLog("Total No. Of Meter Reading In Old Location "+l2.getString("LOCATION")+" For Meter "+locmeterr.getString("METERNAME")+" are : "+oldLocMeterReadingSet.count());
					LocationMeterSetRemote newLocMeterSet= (LocationMeterSetRemote)l1.getMboSet("LOCATIONMETER");
					newLocMeterSet.setWhere("METERNAME='"+locmeterr.getString("METERNAME")+"'");
					newLocMeterSet.reset();
					for(int reading=0;oldLocMeterReadingSet.getMbo(reading)!=null;reading++)
					{
						newlocmeterr = (LocationMeterRemote) newLocMeterSet.getMbo(0);
						//System.out.println("\nNew Location Meter Is : "+newlocmeterr.getString("METERNAME"));
						logger.info("\nNew Location Meter Is : "+newlocmeterr.getString("METERNAME"));
						mxLog.writeLog("\nNew Location Meter Is : "+newlocmeterr.getString("METERNAME"));
						LocMeterReadingRemote oldLocMeterReading=(LocMeterReadingRemote)oldLocMeterReadingSet.getMbo(reading);
						//System.out.println("\nReading: "+oldLocMeterReading.getString("READING")+" Reading Date: "+oldLocMeterReading.getString("READINGDATE"));
						logger.info("\nReading: "+oldLocMeterReading.getString("READING")+" Reading Date: "+oldLocMeterReading.getString("READINGDATE"));
						mxLog.writeLog("\nReading: "+oldLocMeterReading.getString("READING")+" Reading Date: "+oldLocMeterReading.getString("READINGDATE"));
						
						String type=oldLocMeterReading.getString("READINGTYPE");
						
						if(type.equalsIgnoreCase("DELTA"))
						{
							newlocmeterr.setValue("ISDELTA", "Y",MboConstants.NOACCESSCHECK);
							newlocmeterr.setValue("NEWREADING", oldLocMeterReading.getString("DELTA"),MboConstants.NOACCESSCHECK);
						}
						else  if(type.equalsIgnoreCase("ACTUAL"))
						{
							newlocmeterr.setValue("ISDELTA", "N",MboConstants.NOACCESSCHECK);
							newlocmeterr.setValue("NEWREADING", oldLocMeterReading.getString("READING"),MboConstants.NOACCESSCHECK);
						}
						newlocmeterr.setValue("NEWREADINGDATE", oldLocMeterReading.getString("READINGDATE"),MboConstants.NOACCESSCHECK);
						newlocmeterr.setValue("INSPECTOR", oldLocMeterReading.getString("INSPECTOR"),MboConstants.NOACCESSCHECK);
						newlocmeterr.setValue("REMARKS", oldLocMeterReading.getString("REASON"),MboConstants.NOACCESSCHECK);
						newLocMeterSet.save();
						newLocMeterSet.reset();
					}
					//System.out.println("All Meter Readings after Effective Date Copied From Old Location to New Location for Meter "+locmeterr.getString("METERNAME"));
					logger.info("All Meter Readings after Effective Date Copied From Old Location to New Location for Meter "+locmeterr.getString("METERNAME"));
					mxLog.writeLog("All Meter Readings after Effective Date Copied From Old Location to New Location for Meter "+locmeterr.getString("METERNAME"));
					
				}
			flag = true;
			}
		
		catch (Exception e)
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag = false;
			}
		return flag;
	}
	
	public boolean setDelta(LocMeterReadingSetRemote ls) 
	{
		boolean flag0 = false;
		try {
				//System.out.println("Meters Added , Now Updating Delta For Newly Added Meters");
				logger.info("Meters Added , Now Updating Delta For Newly Added Meters");
				mxLog.writeLog("Meters Added , Now Updating Delta For Newly Added Meters");
				
				ls.reset();
				//System.out.println("Total No Of Meter Reading Entered For New Meters "+ls.count());
				logger.info("Total No Of Meter Reading Entered For New Meters "+ls.count());
				mxLog.writeLog("Total No Of Meter Reading Entered For New Meters "+ls.count());
				
				LocMeterReadingRemote locMeterReading;
				for (int k=0; ((locMeterReading = (LocMeterReadingRemote) ls.getMbo(k))!= null);k++)
					{
						//System.out.println("Updating Delta For Meter "+locMeterReading.getString("METERNAME"));
						//System.out.println("Updating Delta For Meter "+locMeterReading.getString("METERNAME"));
						mxLog.writeLog("Updating Delta For Meter "+locMeterReading.getString("METERNAME"));
						
						
						if(locMeterReading.getString("READINGTYPE").equalsIgnoreCase("DELTA"))
						{
						//System.out.println("Reading Type Is Delta , Delta will be set to 0");
						logger.info("Reading Type Is Delta , Delta will be set to 0");
						mxLog.writeLog("Reading Type Is Delta , Delta will be set to 0");
						locMeterReading.setValue("DELTA", 0,MboConstants.NOACCESSCHECK);
						}
						if(locMeterReading.getString("READINGTYPE").equalsIgnoreCase("ACTUAL"))
						{
						//System.out.println("Reading Type Is Actual , Delta will be set to NULL");
						logger.info("Reading Type Is Actual , Delta will be set to NULL");
						mxLog.writeLog("Reading Type Is Actual , Delta will be set to NULL");
						locMeterReading.setValueNull("DELTA",MboConstants.NOACCESSCHECK);
						}
					}
					
				ls.save();
				flag0 = true;
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag0 = false;
			}
	return flag0;	
	}
	
	public boolean updateMeterReadings() 
	{
		boolean flag0 = false;
		try {
				//update locmeterreading set location = 'OLD_BTT083' where location = 'BTT083' and siteid = 'BT'
				//and readingdate  < to_date('2012-05-14 11:59:00','yyyy-mm-dd HH24:MI:SS')
				//System.out.println("Updating Locations");
				logger.info("Updating Locations");
				mxLog.writeLog("Updating Locations");
				DBShortcut dbshortcut = new DBShortcut();
				dbshortcut.connect(userInfo.getConnectionKey());
				String Query = "update locmeterreading set location = '"+arrParams[1]+"' where location = '"+arrParams[0]+"' and siteid = '"+arrParams[2]+"' and readingdate < to_date('"+arrParams[4]+"','yyyy-mm-dd HH24:MI:SS')";
				//System.out.println("Query Is "+Query);
				SqlFormat sqlformat = new SqlFormat(userInfo, Query);
				dbshortcut.execute(sqlformat);
				//System.out.println("Location Meter Reading Updated , Now Running DB Commit.");
				logger.info("Location Meter Reading Updated , Now Running DB Commit.");
				mxLog.writeLog("Location Meter Reading Updated , Now Running DB Commit.");
				dbshortcut.commit();
				//System.out.println("Location Meter Reading Updated , Now Closing DB Connection.");
				logger.info("Location Meter Reading Updated , Now Closing DB Connection.");
				mxLog.writeLog("Location Meter Reading Updated , Now Closing DB Connection.");
				dbshortcut.close();
				//System.out.println("DB Connection Closed.");
				logger.info("DB Connection Closed.");
				mxLog.writeLog("DB Connection Closed.");
				flag0 = true;
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag0 = false;
			}
	return flag0;	
	}
	
	public boolean resetMeters()
	{
		boolean flag0 = true;
		try 
		{
			//System.out.println("Old Location Meter Reset...");
			logger.info("Old Location Meter Reset...");
			mxLog.writeLog("Old Location Meter Reset...");
			LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
			locationSet.setWhere("LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"'");
			locationSet.reset();
			//System.out.println("Count For Old Location "+locationSet.count());
			logger.info("Count For Old Location "+locationSet.count());
			mxLog.writeLog("Count For Old Location "+locationSet.count());
			LocationRemote oldloc = (LocationRemote) locationSet.getMbo(0);
			if(oldloc != null)
				{
					//System.out.println("Old Location "+oldloc.getString("location"));
					logger.info("Old Location "+oldloc.getString("location"));
					mxLog.writeLog("Old Location "+oldloc.getString("location"));
					DeployedMeterSetRemote oldlocmeterset = (DeployedMeterSetRemote)oldloc.getMboSet("LOCATIONMETER");	
					//System.out.println("Count Of Meter in Old Location "+oldlocmeterset.count());
					DeployedMeterRemote oldlocmeter;
					if(oldlocmeterset.count() != 0)
							{
							for (int k=0; ((oldlocmeter =  (DeployedMeterRemote) oldlocmeterset.getMbo(k))!= null);k++)
								{
									//System.out.println("Resetting "+oldlocmeter.getString("METERNAME"));
									logger.info("Resetting "+oldlocmeter.getString("METERNAME"));
									mxLog.writeLog("Resetting "+oldlocmeter.getString("METERNAME"));
									oldlocmeter.setValue("SINCELASTREPAIRNEW", 0);
									oldlocmeter.setValue("SINCELASTOVERHAULNEW", 0);
									oldlocmeter.setValue("SINCELASTINSPECTNEW", 0);
									oldlocmeter.setValue("SINCEINSTALLNEW", 0);
									oldlocmeter.setValue("AVERAGENEW", 0);
									oldlocmeter.setValueNull("LASTREADING",MboConstants.NOACCESSCHECK);
									oldlocmeter.setValueNull("LASTREADINGDATE",MboConstants.NOACCESSCHECK);
									oldlocmeter.setValueNull("LASTREADINGINSPCTR",MboConstants.NOACCESSCHECK);
									oldlocmeter.setValue("LIFETODATE",0,MboConstants.NOACCESSCHECK);
									oldlocmeter.resetMeter();

								}
							oldlocmeterset.save();
						}
					else
						{
						//System.out.println("Old Location Meter Count Null");
						logger.info("Old Location Meter Count Null");
						mxLog.writeLog("Old Location Meter Count Null");
						
						flag0 = false;
						}
					}
				else
					{
					//System.out.println("Old Location Null");
					logger.info("Old Location Null");
					mxLog.writeLog("Old Location Null");
					flag0 = false;
					}
						
		}
		catch(Exception e)
		{
			String message = e.getMessage();
			String stack = getStackTrace(e);
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
			logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
			mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
			
			flag0 = false;
		}
		return flag0;
	}
	
	public boolean updatelastreading()
	{
		boolean flag0 = true;
		try 
		{
			//System.out.println("In Updating Last Meter Reading For New Location");
			logger.info("In Updating Last Meter Reading For New Location");
			mxLog.writeLog("In Updating Last Meter Reading For New Location");
			LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
			locationSet.setWhere("LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"'");
			locationSet.reset();
			//System.out.println("Count For New Location in Locations "+locationSet.count());
			logger.info("Count For New Location in Locations "+locationSet.count());
			mxLog.writeLog("Count For New Location in Locations "+locationSet.count());
			LocationRemote newloc = (LocationRemote) locationSet.getMbo(0);
			if(newloc != null)
				{
					//System.out.println(newloc.getString("location"));
					LocationMeterSetRemote newlocmeterset = (LocationMeterSetRemote)newloc.getMboSet("LOCATIONMETER");	
					//System.out.println("Count Of Meter in New Location "+newlocmeterset.count());
					LocationMeterRemote newlocmeter;
					if(newlocmeterset.count() != 0)
						{
							for (int k=0; ((newlocmeter = (LocationMeterRemote) newlocmeterset.getMbo(k))!= null);k++)
								{
									LocMeterReadingRemote oldLocMeterReadingBeforeDate=(LocMeterReadingRemote)newlocmeter.getPreviousMeterReading(mxserver.getDate());
									if(oldLocMeterReadingBeforeDate != null)
									{
									//System.out.println("\nLast Reading: "+oldLocMeterReadingBeforeDate.getString("READING")+" Last Reading Date: "+oldLocMeterReadingBeforeDate.getString("READINGDATE"));
									newlocmeter.setValue("LASTREADING", oldLocMeterReadingBeforeDate.getString("READING"),MboConstants.NOACCESSCHECK);
									newlocmeter.setValue("LASTREADINGDATE", oldLocMeterReadingBeforeDate.getString("READINGDATE"),MboConstants.NOACCESSCHECK);
									newlocmeter.setValue("LASTREADINGINSPCTR", oldLocMeterReadingBeforeDate.getString("INSPECTOR"),MboConstants.NOACCESSCHECK);	
									newlocmeter.setValue("REMARKS", oldLocMeterReadingBeforeDate.getString("REASON"),MboConstants.NOACCESSCHECK);
									}
									else
									{
										//System.out.println("In New location Last Reading Does Not Exist For Meter "+newlocmeter.getString("METERNAME"));	
										logger.info("In New location Last Reading Does Not Exist "+newlocmeter.getString("METERNAME"));	
										mxLog.writeLog("In New location Last Reading Does Not Exist "+newlocmeter.getString("METERNAME"));	
										
									}
									
									}
							newlocmeterset.save();
						}
					else
						{
							//System.out.println("New Location Meter Count Null");
							logger.info("New Location Meter Count Null");
							mxLog.writeLog("New Location Meter Count Null");
						
							flag0 = false;
						}
					}
			else
				{
					//System.out.println("New Location Null");
					logger.info("New Location Null");
					mxLog.writeLog("New Location Null");
					flag0 = false;
				}		
		}
		catch(Exception e)
		{
			String message = e.getMessage();
			String stack = getStackTrace(e);
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
			logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
			mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
			
			flag0 = false;
		}
	return flag0;	
		
	}
	
	public boolean resetMetersWithEff()
	{
		boolean flag0 = true;
		try 
		{
			//System.out.println("Old Location Meter Reset With Effective Date...");
			logger.info("Old Location Meter Reset  With Effective Date...");
			mxLog.writeLog("Old Location Meter Reset  With Effective Date...");
			LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
			locationSet.setWhere("LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"'");
			locationSet.reset();
			//System.out.println("Count For Old Location "+locationSet.count());
			logger.info("Count For Old Location "+locationSet.count());
			mxLog.writeLog("Count For Old Location "+locationSet.count());
			LocationRemote oldloc = (LocationRemote) locationSet.getMbo(0);
			if(oldloc != null)
				{
					//System.out.println("Old Location "+oldloc.getString("location"));
					logger.info("Old Location "+oldloc.getString("location"));
					mxLog.writeLog("Old Location "+oldloc.getString("location"));
					DeployedMeterSetRemote oldlocmeterset = (DeployedMeterSetRemote)oldloc.getMboSet("LOCATIONMETER");	
					//System.out.println("Count Of Meter in Old Location "+oldlocmeterset.count());
					logger.info("Count Of Meter in Old Location "+oldlocmeterset.count());
					mxLog.writeLog("Count Of Meter in Old Location "+oldlocmeterset.count());
					DeployedMeterRemote oldlocmeter;
					if(oldlocmeterset.count() != 0)
							{
							for (int k=0; ((oldlocmeter =  (DeployedMeterRemote) oldlocmeterset.getMbo(k))!= null);k++)
							{
									LocMeterReadingSetRemote oldLocMeterReadingSet=(LocMeterReadingSetRemote)oldlocmeter.getMboSet("LOCMETERREADING");
									oldLocMeterReadingSet.setOrderBy("READINGDATE");
									//System.out.println("No Of Reading In Meter "+oldlocmeter.getString("METERNAME")+" !! "+oldLocMeterReadingSet.count());
									logger.info("No Of Reading In Meter "+oldlocmeter.getString("METERNAME")+" !! "+oldLocMeterReadingSet.count());
									mxLog.writeLog("No Of Reading In Meter "+oldlocmeter.getString("METERNAME")+" !! "+oldLocMeterReadingSet.count());
									LocMeterReadingRemote locmeterread;
									if(oldLocMeterReadingSet.count() != 0)
									{
										Double prev = getpreviousreading(oldlocmeter.getString("METERNAME"));
										Double reading;
									for (int l=0; ((locmeterread =  (LocMeterReadingRemote) oldLocMeterReadingSet.getMbo(l))!= null);l++)
									{
										
										
										if(prev != null && prev != -420.421)
										{
											//System.out.println("Previous Reading : "+prev);
											//System.out.println("Current Reading : "+locmeterread.getDouble("READING"));
											if(l == 0)
											{
												if(locmeterread.getString("READINGTYPE").equalsIgnoreCase("DELTA"))
													{
													reading = locmeterread.getDouble("READING") - prev ;
													locmeterread.setValue("READING", reading, MboConstants.NOACCESSCHECK);
													locmeterread.setValue("DELTA", reading,MboConstants.NOACCESSCHECK);
													}
												if(locmeterread.getString("READINGTYPE").equalsIgnoreCase("ACTUAL"))
													{
													reading = locmeterread.getDouble("READING") - prev ;
													locmeterread.setValue("READING", reading, MboConstants.NOACCESSCHECK);
													if(locmeterread.getString("DELTA") == null)
														{
														locmeterread.setValueNull("DELTA",MboConstants.NOACCESSCHECK);
														}
													else
														{
														locmeterread.setValue("DELTA", reading,MboConstants.NOACCESSCHECK);
														}
													}
										
											}
											else
											{
												reading = locmeterread.getDouble("READING") - prev ;
												locmeterread.setValue("READING", reading, MboConstants.NOACCESSCHECK);
						
											}
										}
										else if(prev == null)
										{
										//System.out.println("No Previous Reading For Meter "+oldlocmeter.getString("METERNAME"));
										logger.info("No Previous ReadingFor Meter "+oldlocmeter.getString("METERNAME"));
										mxLog.writeLog("No Previous Reading For Meter "+oldlocmeter.getString("METERNAME"));
										}
										else if(prev == -420.421)
										{
										//System.out.println("Exception During Get Previous Reading For Meter "+oldlocmeter.getString("METERNAME"));
										logger.info("Exception During Get Previous Reading For Meter "+oldlocmeter.getString("METERNAME"));
										mxLog.writeLog("Exception During Get Previous Reading For Meter "+oldlocmeter.getString("METERNAME"));
										}
								
									}
								oldLocMeterReadingSet.save();
								oldLocMeterReadingSet.reset();
									}
								else
									{
									//System.out.println("No Meter Reading For Meter "+oldlocmeter.getString("METERNAME"));
									logger.info("No Meter Reading For Meter "+oldlocmeter.getString("METERNAME"));
									mxLog.writeLog("No Meter Reading For Meter "+oldlocmeter.getString("METERNAME"));
									}
							
							}
							
						}
					else
						{
						//System.out.println("Old Location Meter Count Null");
						logger.info("Old Location Meter Count Null");
						mxLog.writeLog("Old Location Meter Count Null");
						
						flag0 = false;
						}
					}
			else
			{
			//System.out.println("Old Location Null");
			logger.info("Old Location Null");
			mxLog.writeLog("Old Location Null");
			flag0 = false;
			}
				
		}
		catch(Exception e)
		{
			String message = e.getMessage();
			String stack = getStackTrace(e);
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
			logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
			mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
			flag0 = false;
		}
	
		return flag0;
	}

	public Double getpreviousreading(String metername)
	{
		
		//System.out.println("In Old Location Meter Reset With Effective Date Get Previous Reading...");
		logger.info("Old Location Meter Reset  With Effective Date Get Previous Reading...");
		mxLog.writeLog("Old Location Meter Reset  With Effective Date Get Previous Reading...");
		LocationSetRemote locationSet;
		Double previous = null;
		try {
			locationSet = (LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
			locationSet.setWhere("LOCATION = '"+arrParams[1]+"' and SITEID = '"+arrParams[3]+"'");
			locationSet.reset();
			//System.out.println("Get previous Reading, Count For New Location "+locationSet.count());
			logger.info("Get previous Reading, Count For New Location "+locationSet.count());
			mxLog.writeLog("Get previous Reading, Count For New Location "+locationSet.count());
			LocationRemote newloc = (LocationRemote) locationSet.getMbo(0);
			if(newloc != null)
				{
					//System.out.println("Get previous Reading, New location "+newloc.getString("location"));
					logger.info("Get previous Reading, New location "+newloc.getString("location"));
					mxLog.writeLog("Get previous Reading, New location "+newloc.getString("location"));
					DeployedMeterSetRemote newlocmeterset = (DeployedMeterSetRemote)newloc.getMboSet("LOCATIONMETER");	
					newlocmeterset.setWhere("METERNAME ='"+metername+"'");
					newlocmeterset.reset();
					//System.out.println("Get previous Reading,Count Of Meter in New Location After Metername setwhere"+newlocmeterset.count());
					logger.info("Get previous Reading, Count Of Meter in New Location After Metername setwhere"+newlocmeterset.count());
					mxLog.writeLog("Get previous Reading, Count Of Meter in New Location After Metername setwhere"+newlocmeterset.count());
					DeployedMeterRemote oldlocmeter = null;
					if(newlocmeterset.count() == 1)
						{
							//System.out.println("Get previous Reading, Count For Meter "+metername+" is 1 in New Location");
							logger.info("Get previous Reading, Count For Meter "+metername+" is 1 in New Location");
							mxLog.writeLog("Get previous Reading, Count For Meter "+metername+" is 1 in New Location");
							oldlocmeter = (DeployedMeterRemote) newlocmeterset.getMbo(0);
							if(oldlocmeter != null)
							{
								//System.out.println("Get previous Reading, Meter "+metername+" is not null in New Location");
								logger.info("Get previous Reading, Meter "+metername+" is not null in New Location");
								mxLog.writeLog("Get previous Reading, Meter "+metername+" is not null in New Location");
								previous = oldlocmeter.getPreviousMeterReading(mxserver.getDate()).getDouble("READING");
								//System.out.println("Get previous Reading, Meter "+metername+" in New Location , previous reading is "+previous);
								logger.info("Get previous Reading, Meter "+metername+" in New Location , previous reading is "+previous);
								mxLog.writeLog("Get previous Reading, Meter "+metername+" in New Location , previous reading is "+previous);
							}
							else
							{
								//System.out.println("Get previous Reading, Meter "+metername+" is null in New Location");
								logger.info("Get previous Reading, Meter "+metername+" is null in New Location");
								mxLog.writeLog("Get previous Reading, Meter "+metername+" is null in New Location");
							}
							
						}
					else
						{
							//System.out.println("Get previous Reading, Count For Meter "+metername+" not 1 in New Location");
							logger.info("Get previous Reading, Count For Meter "+metername+" not 1 in New Location");
							mxLog.writeLog("Get previous Reading, Count For Meter "+metername+" not 1 in New Location");
						}
						
				}
			else
				{
				//System.out.println("Get previous Reading, New Location Null");
				logger.info("Get previous Reading, New Location Null");
				mxLog.writeLog("Get previous Reading, New Location Null");
				}
			
			} 
			catch (Exception e)
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				previous = -420.421;
			}
			
			return previous;
		
	}
	
	public boolean deleteMeterReadings() 
	{
		boolean flag0 = false;
		try {
				//System.out.println("Deleting Meter Readings");
				logger.info("Deleting Meter Readings");
				mxLog.writeLog("Deleting Meter Readings");
				DBShortcut dbshortcut = new DBShortcut();
				dbshortcut.connect(userInfo.getConnectionKey());
				String Query = "delete from locmeterreading where location = '"+arrParams[0]+"' and siteid = '"+arrParams[2]+"' and readingdate > to_date('"+arrParams[4]+"','yyyy-mm-dd HH24:MI:SS')";
				//System.out.println("Query Is "+Query);
				SqlFormat sqlformat = new SqlFormat(userInfo, Query);
				dbshortcut.execute(sqlformat);
				//System.out.println("Location Meter Reading Deleted , Now Running DB Commit.");
				logger.info("Location Meter Reading Deleted , Now Running DB Commit.");
				mxLog.writeLog("Location Meter Reading Deleted , Now Running DB Commit.");
				dbshortcut.commit();
				//System.out.println("Location Meter Reading Deleted , Now Closing DB Connection.");
				logger.info("Location Meter Reading Deleted , Now Closing DB Connection.");
				mxLog.writeLog("Location Meter Reading Deleted , Now Closing DB Connection.");
				dbshortcut.close();
				//System.out.println("DB Connection Closed.");
				logger.info("DB Connection Closed.");
				mxLog.writeLog("DB Connection Closed.");
				flag0 = true;
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag0 = false;
			}
	return flag0;	
	}
	
	public boolean updatelastreadingoldloc()
	{
		boolean flag0 = true;
		try 
		{
			//System.out.println("In Updating Last Meter Reading For Old Location");
			logger.info("In Updating Last Meter Reading For Old Location");
			mxLog.writeLog("In Updating Last Meter Reading For Old Location");
			LocationSetRemote locationSet=(LocationSetRemote)mxserver.getMboSet("LOCATIONS",userInfo);
			locationSet.setWhere("LOCATION = '"+arrParams[0]+"' and SITEID = '"+arrParams[2]+"'");
			locationSet.reset();
			//System.out.println("Count For Old Location in Locations "+locationSet.count());
			logger.info("Count For Old Location in Locations "+locationSet.count());
			mxLog.writeLog("Count For Old Location in Locations "+locationSet.count());
			LocationRemote oldloc = (LocationRemote) locationSet.getMbo(0);
			if(oldloc != null)
				{
					//System.out.println(oldloc.getString("location"));
					LocationMeterSetRemote oldlocmeterset = (LocationMeterSetRemote)oldloc.getMboSet("LOCATIONMETER");	
					//System.out.println("Count Of Meter in Old Location "+oldlocmeterset.count());
					LocationMeterRemote oldlocmeter;
					if(oldlocmeterset.count() != 0)
						{
							for (int k=0; ((oldlocmeter = (LocationMeterRemote) oldlocmeterset.getMbo(k))!= null);k++)
								{
									LocMeterReadingRemote oldLocMeterReadingBeforeDate=(LocMeterReadingRemote)oldlocmeter.getPreviousMeterReading(mxserver.getDate());
									if(oldLocMeterReadingBeforeDate != null)
									{
									//System.out.println("\nLast Reading: "+oldLocMeterReadingBeforeDate.getString("READING")+" Last Reading Date: "+oldLocMeterReadingBeforeDate.getString("READINGDATE"));
									oldlocmeter.setValue("LASTREADING", oldLocMeterReadingBeforeDate.getString("READING"),MboConstants.NOACCESSCHECK);
									oldlocmeter.setValue("LASTREADINGDATE", oldLocMeterReadingBeforeDate.getString("READINGDATE"),MboConstants.NOACCESSCHECK);
									oldlocmeter.setValue("LASTREADINGINSPCTR", oldLocMeterReadingBeforeDate.getString("INSPECTOR"),MboConstants.NOACCESSCHECK);	
									oldlocmeter.setValue("REMARKS", oldLocMeterReadingBeforeDate.getString("REASON"),MboConstants.NOACCESSCHECK);
									}
									else
									{
										//System.out.println("In Old location Last Reading Does Not Exist For Meter "+oldlocmeter.getString("METERNAME"));	
										logger.info("In Old location Last Reading Does Not Exist "+oldlocmeter.getString("METERNAME"));	
										mxLog.writeLog("In Old location Last Reading Does Not Exist "+oldlocmeter.getString("METERNAME"));	
										
									}
									
									}
							oldlocmeterset.save();
						}
					else
						{
							//System.out.println("Old Location Meter Count Null");
							logger.info("Old Location Meter Count Null");
							mxLog.writeLog("Old Location Meter Count Null");
						
							flag0 = false;
						}
					}
			else
				{
					//System.out.println("Old Location Null");
					logger.info("Old Location Null");
					mxLog.writeLog("Old Location Null");
					flag0 = false;
				}		
		}
		catch(Exception e)
		{
			String message = e.getMessage();
			String stack = getStackTrace(e);
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
			logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
			//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
			mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
			
			flag0 = false;
		}
	return flag0;	
		
	}
	
	public boolean updatePMforS1()
	{
		boolean flag0 = false;
		try {
				//System.out.println("Updating PM Data");
				logger.info("Updating PM Data");
				mxLog.writeLog("Updating PM Data");
				DBShortcut dbshortcut = new DBShortcut();
				dbshortcut.connect(userInfo.getConnectionKey());
				String pmupdate = "UPDATE pm SET pmnum=REPLACE(pmnum,'"+arrParams[0]+"','"+arrParams[1]+"'), location='"+arrParams[1]+"' WHERE pmnum like '"+arrParams[0]+"%' and location = '"+arrParams[0]+"' and siteid = '"+arrParams[2]+"'";
				String pmmeterupdate = "UPDATE pmmeter SET pmnum=REPLACE(pmnum,'"+arrParams[0]+"','"+arrParams[1]+"'), location='"+arrParams[1]+"' WHERE pmnum like '"+arrParams[0]+"%' and location = '"+arrParams[0]+"' and siteid = '"+arrParams[2]+"'";
				String pmancestor = "UPDATE pmancestor SET pmnum=REPLACE(pmnum,'"+arrParams[0]+"','"+arrParams[1]+"'), ancestor=REPLACE(ancestor,'"+arrParams[0]+"','"+arrParams[1]+"') WHERE pmnum LIKE '"+arrParams[0]+"%' and siteid = '"+arrParams[2]+"'";
				String pmsequence = "UPDATE pmsequence SET pmnum=REPLACE(pmnum,'"+arrParams[0]+"','"+arrParams[1]+"') WHERE pmnum LIKE '"+arrParams[0]+"%' and siteid = '"+arrParams[2]+"'";
				
				SqlFormat sqlformat = new SqlFormat(userInfo, pmupdate);
				//System.out.println("Updating PM  Query Is : "+pmupdate);
				logger.info("Updating PM  Query Is : "+pmupdate);
				mxLog.writeLog("Updating PM  Query Is : "+pmupdate);
				dbshortcut.execute(sqlformat);
				//System.out.println("PM Update Successfull");
				logger.info("PM Update Successfull");
				mxLog.writeLog("PM Update Successfull");
				
				SqlFormat sqlformat1 = new SqlFormat(userInfo, pmmeterupdate);
				//System.out.println("Updating PMMETER  Query Is : "+pmmeterupdate);
				logger.info("Updating PMMETER  Query Is : "+pmmeterupdate);
				mxLog.writeLog("Updating PMMETER  Query Is : "+pmmeterupdate);
				dbshortcut.execute(sqlformat1);
				//System.out.println("PMMETER Update Successfull");
				logger.info("PMMETER Update Successfull");
				mxLog.writeLog("PMMETER Update Successfull");
				
				SqlFormat sqlformat2 = new SqlFormat(userInfo, pmancestor);
				//System.out.println("Updating PMANCESTOR  Query Is : "+pmancestor);
				logger.info("Updating PMANCESTOR  Query Is : "+pmancestor);
				mxLog.writeLog("Updating PMANCESTOR  Query Is : "+pmancestor);
				dbshortcut.execute(sqlformat2);
				//System.out.println("PMANCESTOR Update Successfull");
				logger.info("PMANCESTOR Update Successfull");
				mxLog.writeLog("PMANCESTOR Update Successfull");
				
				SqlFormat sqlformat3 = new SqlFormat(userInfo, pmsequence);
				//System.out.println("Updating PMSEQUENCE  Query Is : "+pmsequence);
				logger.info("Updating PMSEQUENCE  Query Is : "+pmsequence);
				mxLog.writeLog("Updating PMSEQUENCE  Query Is : "+pmsequence);
				dbshortcut.execute(sqlformat3);
				//System.out.println("PMSEQUENCE Update Successfull");
				logger.info("PMSEQUENCE Update Successfull");
				mxLog.writeLog("PMSEQUENCE Update Successfull");
				
				//System.out.println("PM Data Updated , Now Running DBCOMMIT");
				logger.info("PM Data Updated , Now Running DBCOMMIT");
				mxLog.writeLog("PM Data Updated , Now Running DBCOMMIT");
				dbshortcut.commit();
				//System.out.println("Closing Database Connection");
				logger.info("Closing Database Connection");
				mxLog.writeLog("Closing Database Connection");
				dbshortcut.close();
				//System.out.println("DB Connection Closed.");
				logger.info("DB Connection Closed.");
				mxLog.writeLog("DB Connection Closed.");
				flag0 = true;
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag0 = false;
			}
	return flag0;	
	}
	
	public boolean updatePMforS2()
	{
		boolean flag0 = false;
		try {
				//System.out.println("Updating PM Data");
				logger.info("Updating PM Data");
				mxLog.writeLog("Updating PM Data");
				DBShortcut dbshortcut = new DBShortcut();
				dbshortcut.connect(userInfo.getConnectionKey());
				String pmupdate = "UPDATE pm SET siteid = '"+arrParams[3]+"' WHERE pmnum like '"+arrParams[0]+"%' and location = '"+arrParams[0]+"' and siteid = '"+arrParams[2]+"'";
				String pmmeterupdate = "UPDATE pmmeter SET siteid = '"+arrParams[3]+"' WHERE pmnum like '"+arrParams[0]+"%' and location = '"+arrParams[0]+"' and siteid = '"+arrParams[2]+"'";
				String pmancestor = "UPDATE pmancestor SET siteid = '"+arrParams[3]+"' WHERE pmnum like '"+arrParams[0]+"%' and siteid = '"+arrParams[2]+"'";
				String pmsequence = "UPDATE pmsequence SET siteid = '"+arrParams[3]+"' WHERE pmnum like '"+arrParams[0]+"%' and siteid = '"+arrParams[2]+"'";
				
				SqlFormat sqlformat = new SqlFormat(userInfo, pmupdate);
				//System.out.println("Updating PM  Query Is : "+pmupdate);
				logger.info("Updating PM  Query Is : "+pmupdate);
				mxLog.writeLog("Updating PM  Query Is : "+pmupdate);
				dbshortcut.execute(sqlformat);
				//System.out.println("PM Update Successfull");
				logger.info("PM Update Successfull");
				mxLog.writeLog("PM Update Successfull");
				
				SqlFormat sqlformat1 = new SqlFormat(userInfo, pmmeterupdate);
				//System.out.println("Updating PMMETER  Query Is : "+pmmeterupdate);
				logger.info("Updating PMMETER  Query Is : "+pmmeterupdate);
				mxLog.writeLog("Updating PMMETER  Query Is : "+pmmeterupdate);
				dbshortcut.execute(sqlformat1);
				//System.out.println("PMMETER Update Successfull");
				logger.info("PMMETER Update Successfull");
				mxLog.writeLog("PMMETER Update Successfull");
				
				SqlFormat sqlformat2 = new SqlFormat(userInfo, pmancestor);
				//System.out.println("Updating PMANCESTOR  Query Is : "+pmancestor);
				logger.info("Updating PMANCESTOR  Query Is : "+pmancestor);
				mxLog.writeLog("Updating PMANCESTOR  Query Is : "+pmancestor);
				dbshortcut.execute(sqlformat2);
				//System.out.println("PMANCESTOR Update Successfull");
				logger.info("PMANCESTOR Update Successfull");
				mxLog.writeLog("PMANCESTOR Update Successfull");
				
				SqlFormat sqlformat3 = new SqlFormat(userInfo, pmsequence);
				//System.out.println("Updating PMSEQUENCE  Query Is : "+pmsequence);
				logger.info("Updating PMSEQUENCE  Query Is : "+pmsequence);
				mxLog.writeLog("Updating PMSEQUENCE  Query Is : "+pmsequence);
				dbshortcut.execute(sqlformat3);
				//System.out.println("PMSEQUENCE Update Successfull");
				logger.info("PMSEQUENCE Update Successfull");
				mxLog.writeLog("PMSEQUENCE Update Successfull");
				
				//System.out.println("PM Data Updated , Now Running DBCOMMIT");
				logger.info("PM Data Updated , Now Running DBCOMMIT");
				mxLog.writeLog("PM Data Updated , Now Running DBCOMMIT");
				dbshortcut.commit();
				//System.out.println("Closing Database Connection");
				logger.info("Closing Database Connection");
				mxLog.writeLog("Closing Database Connection");
				dbshortcut.close();
				//System.out.println("DB Connection Closed.");
				logger.info("DB Connection Closed.");
				mxLog.writeLog("DB Connection Closed.");
				flag0 = true;
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag0 = false;
			}
	return flag0;	
	}
		
	public boolean updatePMforS3()
	{
		boolean flag0 = false;
		try {
				//System.out.println("Updating PM Data");
				logger.info("Updating PM Data");
				mxLog.writeLog("Updating PM Data");
				DBShortcut dbshortcut = new DBShortcut();
				dbshortcut.connect(userInfo.getConnectionKey());
				String pmupdate = "UPDATE pm SET pmnum=REPLACE(pmnum,'"+arrParams[0]+"','"+arrParams[1]+"'), location='"+arrParams[1]+"' WHERE pmnum like '"+arrParams[0]+"%' and location = '"+arrParams[0]+"' and siteid = '"+arrParams[2]+"'";
				String pmmeterupdate = "UPDATE pmmeter SET pmnum=REPLACE(pmnum,'"+arrParams[0]+"','"+arrParams[1]+"'), location='"+arrParams[1]+"' WHERE pmnum like '"+arrParams[0]+"%' and location = '"+arrParams[0]+"' and siteid = '"+arrParams[2]+"'";
				String pmancestor = "UPDATE pmancestor SET pmnum=REPLACE(pmnum,'"+arrParams[0]+"','"+arrParams[1]+"'), ancestor=REPLACE(ancestor,'"+arrParams[0]+"','"+arrParams[2]+"') WHERE pmnum LIKE '"+arrParams[0]+"%' and siteid = '"+arrParams[2]+"'";
				String pmsequence = "UPDATE pmsequence SET pmnum=REPLACE(pmnum,'"+arrParams[0]+"','"+arrParams[1]+"') WHERE pmnum LIKE '"+arrParams[0]+"%' and siteid = '"+arrParams[2]+"'";
				
				SqlFormat sqlformat = new SqlFormat(userInfo, pmupdate);
				//System.out.println("Updating PM  Query Is : "+pmupdate);
				logger.info("Updating PM  Query Is : "+pmupdate);
				mxLog.writeLog("Updating PM  Query Is : "+pmupdate);
				dbshortcut.execute(sqlformat);
				//System.out.println("PM Update Successfull");
				logger.info("PM Update Successfull");
				mxLog.writeLog("PM Update Successfull");
				
				SqlFormat sqlformat1 = new SqlFormat(userInfo, pmmeterupdate);
				//System.out.println("Updating PMMETER  Query Is : "+pmmeterupdate);
				logger.info("Updating PMMETER  Query Is : "+pmmeterupdate);
				mxLog.writeLog("Updating PMMETER  Query Is : "+pmmeterupdate);
				dbshortcut.execute(sqlformat1);
				//System.out.println("PMMETER Update Successfull");
				logger.info("PMMETER Update Successfull");
				mxLog.writeLog("PMMETER Update Successfull");
				
				SqlFormat sqlformat2 = new SqlFormat(userInfo, pmancestor);
				//System.out.println("Updating PMANCESTOR  Query Is : "+pmancestor);
				logger.info("Updating PMANCESTOR  Query Is : "+pmancestor);
				mxLog.writeLog("Updating PMANCESTOR  Query Is : "+pmancestor);
				dbshortcut.execute(sqlformat2);
				//System.out.println("PMANCESTOR Update Successfull");
				logger.info("PMANCESTOR Update Successfull");
				mxLog.writeLog("PMANCESTOR Update Successfull");
				
				SqlFormat sqlformat3 = new SqlFormat(userInfo, pmsequence);
				//System.out.println("Updating PMSEQUENCE  Query Is : "+pmsequence);
				logger.info("Updating PMSEQUENCE  Query Is : "+pmsequence);
				mxLog.writeLog("Updating PMSEQUENCE  Query Is : "+pmsequence);
				dbshortcut.execute(sqlformat3);
				//System.out.println("PMSEQUENCE Update Successfull");
				logger.info("PMSEQUENCE Update Successfull");
				mxLog.writeLog("PMSEQUENCE Update Successfull");
				
				//System.out.println("PM Data Updated , Now Running DBCOMMIT");
				logger.info("PM Data Updated , Now Running DBCOMMIT");
				mxLog.writeLog("PM Data Updated , Now Running DBCOMMIT");
				dbshortcut.commit();
				//System.out.println("Closing Database Connection");
				logger.info("Closing Database Connection");
				mxLog.writeLog("Closing Database Connection");
				dbshortcut.close();
				//System.out.println("DB Connection Closed.");
				logger.info("DB Connection Closed.");
				mxLog.writeLog("DB Connection Closed.");
				flag0 = true;
			} 
		catch (Exception e) 
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag0 = false;
			}
	return flag0;	
	}
	
	
	public boolean updatemeterfileds(LocationMeterSetRemote ls1,LocationRemote l1,LocationRemote l2)
	{
		boolean flag = false;
		try
			{
				LocationMeterRemote locmeterr;
				LocationMeterRemote newlocmeterr;
				for (int k=0; ((locmeterr = (LocationMeterRemote) ls1.getMbo(k))!= null);k++)
				{
					//System.out.println("\n Updating SinceLastRepair and other dependent fields");
					logger.info("\n Updating SinceLastRepair and other dependent fields");
					mxLog.writeLog("\n Updating SinceLastRepair and other dependent fields");
					//System.out.println("Meter "+k+" In Old Location "+l2.getString("LOCATION")+ " is "+locmeterr.getString("METERNAME"));
					logger.info("Meter "+k+" In Old Location "+l2.getString("LOCATION")+ " is "+locmeterr.getString("METERNAME"));
					mxLog.writeLog("Meter "+k+" In Old Location "+l2.getString("LOCATION")+ " is "+locmeterr.getString("METERNAME"));
					LocationMeterSetRemote newLocMeterSet= (LocationMeterSetRemote)l1.getMboSet("LOCATIONMETER");
					newLocMeterSet.setWhere("METERNAME='"+locmeterr.getString("METERNAME")+"'");
					newLocMeterSet.reset();
					newlocmeterr = (LocationMeterRemote) newLocMeterSet.getMbo(0);
					newlocmeterr.setValue("SINCELASTREPAIR", locmeterr.getDouble("SINCELASTREPAIR"),MboConstants.NOACCESSCHECK);
					newlocmeterr.setValue("SINCELASTOVERHAUL", locmeterr.getDouble("SINCELASTOVERHAUL"),MboConstants.NOACCESSCHECK);
					newlocmeterr.setValue("SINCELASTINSPECT", locmeterr.getDouble("SINCELASTINSPECT"),MboConstants.NOACCESSCHECK);
					newlocmeterr.setValue("SINCEINSTALL", locmeterr.getDouble("SINCEINSTALL"),MboConstants.NOACCESSCHECK);
					newLocMeterSet.save();
					newLocMeterSet.reset();
					//System.out.println("Desired Fields Updated for "+locmeterr.getString("METERNAME"));
					logger.info("Desired Fields Updated for "+locmeterr.getString("METERNAME"));
					mxLog.writeLog("Desired Fields Updated for  "+locmeterr.getString("METERNAME"));
					
				}
			flag = true;
			}
		
		catch (Exception e)
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
				//System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
				mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
				
				flag = false;
			}
		return flag;
	}
	
	
	public boolean readConfig()
	{
		boolean flag = true;
			try
			{
			mxserver = MXServer.getMXServer();
			userInfo = getRunasUserInfo();
			DateFormat fileDateFormat = new SimpleDateFormat("d-MMM-yy HH:mm");
			String runtime = fileDateFormat.format(mxserver.getDate());
			logFilePath = arrParams[5];
			//System.out.println("Log File Name : "+logFilePath);
			logger.info("Log File Name : "+logFilePath);
			if(logFilePath != null)
			{
				logFilePath = logFilePath.trim();
				if(logFilePath.equals(""))
				{
					
					logFilePath = null;
				} else
				{
					
					fileDateFormat = new SimpleDateFormat("yyMMddHHmm");
					runtime = fileDateFormat.format(mxserver.getDate());
					logFilePath = logFilePath.replaceAll("yyyymmddhhmm", runtime);
					mxLog.setEnabled(true);
					mxLog.setLogFilePath(logFilePath);
					mxLog.setLogTag(String.valueOf(getName()));
					mxLog.createLogFile();
					
				}
			}
			email.setToMail(arrParams[6]);
			Properties properties = mxserver.getConfig();
			email.setFromMail(properties.getProperty("mxe.adminEmail", null));
			emailSubj = arrParams[7];
			}
			catch(Exception e)
			{
				String message = e.getMessage();
				String stack = getStackTrace(e);
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
				logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
				mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
				flag =  false;		
			}
		return flag;
	}

	public String genEmail(String error, String stack)
	{
		String emailMsg = (new StringBuilder("Date: ")).append(new Date()).append("\n").append("Error Message: ").append(error).append("\n").append(stack).toString();
		
		//System.out.println("Email Msg  Is : "+emailMsg);
		logger.info("Email Msg Is : "+emailMsg);
		if(mxLog.isEnabled()) 
		{
		mxLog.writeLog("Email Msg Is : "+emailMsg);
		} 
		return emailMsg;
	}   

	public String getStackTrace(Exception e)
	{
		String stack = "";
		StackTraceElement element[] = e.getStackTrace();
		for(int i = 0; i < element.length; i++)
			stack = (new StringBuilder(String.valueOf(stack))).append("\tat ").append(element[i].toString()).append("\n").toString();

			//System.out.println("Stack Trace Is : "+stack);
			logger.info("Stack Trace Is : "+stack);
			mxLog.writeLog("Stack Trace Is : "+stack);
			return stack;
	}
}
