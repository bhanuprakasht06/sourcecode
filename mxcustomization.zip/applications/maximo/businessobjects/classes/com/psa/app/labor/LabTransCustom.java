/*
 * Modification history
 * 22-06-07     HCHA    NA                      Creation
 * 10-04-07     AGD     SR-087  Get the WO GL A/c rather than the work type GL A/c for capital work (cater for capital work defined WO per WO)
 * 12-04-07     AGD     SR-080  Check for labor report overlap
 * 18-04-07     AGD     SR-030  Disallow transactions at cost>0 for project with no more budget
 * 28-02-14 WMJ EMS-767 [LABTRANS]Overlapping OT records can be saved
 * 28-02-14 WMJ EMS-666 [LABTRANS]SRADHOCWF Exception when routing a monitored equipment to confirm completion
 * 09-04-14 WMJ EMS-800 [WORKTYPE]New field to specify if labour transactions posted under a worktype should be checked for overlap
 * 09-04-14 WMJ EMS-801 [LABOR]New field to specify if labour transactions under a labour needs to be checked for overlap
 * 09-04-14 WMJ EMS-802 [LABTRANS]To skip save validations when OT/labour records are to be deleted when saving
 * 25-09-15 DES EMS-958 Recon status for some transactions cannot be updated due to LD Import and Labor Overlap prompts
 * 16-03-16 WMJ EMS-1033	[Labtrans]Labour rate not set to zero even though worktype/cost centre combination will suppress charging
 */
package com.psa.app.labor;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Vector;

import com.psa.app.common.FinancialTransaction;

import psdi.app.labor.LabTrans;
import psdi.app.labor.LabTransRemote;
import psdi.app.labor.LabTransSetRemote;
import com.psa.app.labor.LabTransCustomRemote;
import psdi.app.labor.virtual.LabTransEnterBy;
import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOSetRemote;
import psdi.app.workorder.WorkTypeRemote;
import psdi.app.workorder.WorkTypeSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationYesNoCancelException;
import psdi.util.MXException;
import psdi.util.MXApplicationException;

//start of EMS-1033	
import psdi.security.UserInfo;
import psdi.mbo.GLFormat;
import psdi.app.financial.GLComponentsRemote;
import psdi.app.financial.GLComponentsSetRemote;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
//end of EMS-1033 	

public class LabTransCustom extends LabTrans
implements LabTransCustomRemote
{

public LabTransCustom(MboSet mboset) throws MXException, RemoteException
{
        super(mboset);
//Begin modification SR-030
        myset = mboset;
//End modification SR-030

//Begin modification SR-080
        doesstartoverlap = false;
        doesfinishoverlap = false;
//End modification SR-080

//Begin add OT Flag for overlap
        doesotstartoverlap = false;
        doesotfinishoverlap = false;
//End add OT Flag for overlap
}

/*
 * Process the specific logic for OT record.
 * If Transaction is OT Record and already has been verified,
 * need to set the corresponding columns to be read-only.
 *
 * If Transaction is OT Record and does not have been verified,
 * need to remove the read-only status of corresponding columns.
 *
 *
 * @Date: 31 Oct 2011
 * @throws MXException
 */
public void init() throws MXException
{
        super.init();
        boolean isNew = false;
        try
        {
//              System.out.println("LabTransCustom.init() Start: " + MXServer.getMXServer().getDate());

                isNew = isNull("PSA_OT_FLAG");
                // Add New Log...
//                System.out.println("Is new OT Record (isNew) ->: " + isNew);
                if (!isNew)
                {
                        boolean otflag = false;
                        boolean verifyflag = false;

                        otflag = getBoolean("PSA_OT_FLAG");
                        verifyflag = getBoolean("PSA_VERIFIED");

//                System.out.println("OT Flag in init() :" + otflag);
//                System.out.println("Verify Flag in init() :" + verifyflag);
                        String as[] = {"startdate", "starttime", "finishdate", "finishtime", "psa_remarks"};
                        if (otflag)
                        {
                                if (verifyflag)
                                {
                                        setFieldFlag(as, 7L, true);
                                }
                                else
                                {
                                        setFieldFlag(as, 7L, false);
                                }
                        }
                }

//            System.out.println("LabTransCustom.init() End: " + MXServer.getMXServer().getDate());
        } catch (RemoteException e)
        {
                e.printStackTrace();
        }
}

protected void setGLDebitAcct()
throws MXException, RemoteException
{

//Get WO Mbo (if exist)
WORemote wo = null;
MboRemote mboremote = getOwner();
    if(mboremote == null || (mboremote instanceof LabTransEnterBy))
    {
        if(!isNull("wonum")){

                WOSetRemote woSet =(WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", getUserInfo());
            SqlFormat sqlformat = new SqlFormat(getUserInfo(), "wonum = :1 and siteid = :2");
            sqlformat.setObject(1, "WORKORDER", "WONUM", getString("wonum"));
            sqlformat.setObject(2, "WORKORDER", "SITEID", getString("siteid"));
            woSet.setWhere(sqlformat.format());

            if(!woSet.isEmpty())
            {
                wo = (WORemote) woSet.getMbo(0);
            }
        }
    }
    else
    {
        if(mboremote instanceof WORemote){
                wo = (WORemote) mboremote;
        }
    }

    if(wo != null){
        String woWorkType = wo.getString("WORKTYPE");
        if(woWorkType != null){

                //Get Worktype mbo
                WorkTypeSetRemote worktypeSet =(WorkTypeSetRemote) MXServer.getMXServer().getMboSet("WORKTYPE", getUserInfo());

            SqlFormat sqlformat = new SqlFormat(getUserInfo(), "worktype = :1 and orgid = :2");
            sqlformat.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
            sqlformat.setObject(2, "LABTRANS", "ORGID", getString("orgid"));
            worktypeSet.setWhere(sqlformat.format());
//For 2.5.4 validation
            /*if(!worktypeSet.isEmpty())
            {
                WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
                if(worktype.getBoolean("capitalwork")){
                        //Capital Type Work Order
//Begin modification SR-087
//                      String wotypeGlAccount = worktype.getString("glaccount");
//                      if(wotypeGlAccount != null){
                                String wotypeGlAccount = wo.getString("glaccount");
                                //Set WO GL Account into LabTrans Gl Debit Account
                                setValue("gldebitacct", wotypeGlAccount, 2L);
                                return;
//                      }
//End modification SR-087
                }
            }*/ //for 2.5.4
        }
    }

    //Use Original Function
    super.setGLDebitAcct();
}




/*
 * Check for overlap after a user has input a start/end date/time for OT information
 * Returns true if the field creates an overlap and that the user chooses to cancel his entry, returns false otherwise
 *
 * 1. Check OT claim is allowed for the labor records that are within 90 days
 * 2. Check OT claim is against for OT records for overlapping
 */
public int checkOverlapForOTField(boolean isOTStartField)
                throws MXException, RemoteException
{
        int needtoclearfield = 0;

//        System.out.println("checkOverlapForOTField() start: " + MXServer.getMXServer().getDate());
        /*
         * If the other date/time makes the current report overlap, no need to check again the current field
         * as the report will definitely overlap again and the check would prompt the user again needlessly
         * if ((isOTStartField && doesotfinishoverlap) || (!isOTStartField && doesotstartoverlap))
         *       return needtoclearfield;
         */

//        System.out.println("checkOverlapForOTField() isOTStartField :->" + isOTStartField);
//        System.out.println("checkOverlapForOTField() doesotstartoverlap :->" + doesotstartoverlap);
//        System.out.println("checkOverlapForOTField() doesotfinishoverlap :->" + doesotfinishoverlap);
        if ((isOTStartField && doesotfinishoverlap) || (!isOTStartField && doesotstartoverlap))
                return needtoclearfield;
//        System.out.println("checkOverlapForOTField() startdate..." + getDate("startdate"));
//        System.out.println("checkOverlapForOTField() starttime..." + getDate("starttime"));
//        System.out.println("checkOverlapForOTField() finishdate..." + getDate("finishdate"));
//        System.out.println("checkOverlapForOTField() finishtime..." + getDate("finishtime"));

//        Date rptotstarttime = getDate("starttime");
//        Date rptotfinishtime = getDate("finishtime");

        Date myotstart = validateDateTime(getDate("startdate"), getDate("starttime"));
        Date myotfinish = validateDateTime(getDate("finishdate"), getDate("finishtime"));
        Date otdatechecked = (isOTStartField)? myotstart : myotfinish;

//        System.out.println("checkOverlapForOTField() myotstart..." + myotstart);
//        System.out.println("checkOverlapForOTField() myotfinish..." + myotfinish);

                //1. Check OT reported start date is within 90 days
        if(isOTStartField)
                {
//                      System.out.println("Entering Check for OT reported start date if it is within 90 days: " + MXServer.getMXServer().getDate());
                        Calendar curdate = null;//current date to subtract 90 days
            Calendar startdate = null;//start date of reported OT

            curdate = Calendar.getInstance();
            startdate = Calendar.getInstance();

                curdate.add(Calendar.DATE,-90);
                startdate.setTime(otdatechecked);

            if(startdate.before(curdate))       //getTime() is in milliseconds, not applicable for Timezone timings
            {
                //OT is only allowed for records that are within 90 days
				//Validation appplied using script
				needtoclearfield=3;
				return needtoclearfield;
				//throw new MXApplicationException("labor", "otrptover90days");
				//Validation appplied using script
            }
//                              System.out.println("Leaving Check for OT reported start date if it is within 90 days: " + MXServer.getMXServer().getDate());
        }

        //. Check to see if the start/finish time are populated. if yes proceed with check. if not skip check first.
        if ( (isOTStartField && isNull("starttime")) || (!isOTStartField && isNull("finishtime")) )
        {
                return needtoclearfield;
        }
        
        /*
         * BCT Modification starts: 
         * Action: Oracle to SQL conversion
         */

        //2.Check OT claim is allowed for the labor records that are within 90 days
        //Get LabTrans mbo
        LabTransSetRemote laborTransSet = (LabTransSetRemote) MXServer.getMXServer().getMboSet("LABTRANS", getUserInfo());
        //SQL need to be confirmed by your side to retrieve the labor records within 90 days or labour starting after 90 days but ends within 90 days
        //SqlFormat sqlformatLab = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and REFWO = :3 and ( ((TRUNC(sysdate) - TRUNC(STARTDATE)) <= 90) or ( (TRUNC(sysdate) - TRUNC(STARTDATE))>90 and ((TRUNC(sysdate) - TRUNC(FINISHDATE)) <= 90) ) ) ");
        
        //Oracle to SQL conversion:
        SqlFormat sqlformatLab = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and REFWO = :3 and ( (( datediff ( dd,cast(startdate as date) ,cast(getdate() as date) ) ) <= 90) or ( (datediff ( dd,cast(startdate as date) ,cast(getdate() as date) ))>90 and ((datediff ( dd,cast(finishdate as date) ,cast(getdate() as date) )) <= 90) ) ) ");

        getMboLogger().debug("laborcode :" + getString("laborcode")     );
//        System.out.println("laborcode :" + getString("laborcode"));
        getMboLogger().debug("REFWO :" + getString("REFWO")     );
//        System.out.println("REFWO :" + getString("REFWO"));
        sqlformatLab.setObject(1, "LABTRANS", "LABORCODE", getString("laborcode"));
        sqlformatLab.setObject(2, "LABTRANS", "PSA_OT_FLAG", "0");
        sqlformatLab.setObject(3, "LABTRANS", "REFWO", getString("REFWO"));
        laborTransSet.setWhere(sqlformatLab.format());
//        System.out.println("Labor SQL: " + sqlformatLab.format() + ": " + MXServer.getMXServer().getDate());

        boolean doesotallowed = false;
        MboRemote laborreport;
        for (int i = 0; (laborreport = laborTransSet.getMbo(i)) != null; i++)//loop to check OT against existing labtrans, return doesotallowed = true if check date/s entered are ok
        {
//                System.out.println("Can get the LABTransactions...");
                // Don't consider weird cases where the date is null but the time is filled in
                //if time is null, take labtrans time to be null too
                Date laborstart = (laborreport.isNull("startdate")) ? null :
                                validateDateTime(laborreport.getDate("startdate"), laborreport.getDate("starttime"));
                Date laborfinish = (laborreport.isNull("finishdate")) ? null :
                                validateDateTime(laborreport.getDate("finishdate"), laborreport.getDate("finishtime"));
/*
                Date laborstart;
                Date laborfinish;

                if(isOTStartField && rptotstarttime == null)
                {
                    laborstart = (laborreport.isNull("startdate")) ? null :validateDateTime(laborreport.getDate("startdate"), rptotstarttime);
                }
                else
                {
                        laborstart = (laborreport.isNull("startdate")) ? null :
                                validateDateTime(laborreport.getDate("startdate"), laborreport.getDate("starttime"));
                }

                if(!isOTStartField && rptotfinishtime == null)
                {
                        laborfinish = (laborreport.isNull("finishdate")) ? null :
                                validateDateTime(laborreport.getDate("finishdate"), rptotfinishtime);
                }
                else
                {
                        laborfinish = (laborreport.isNull("finishdate")) ? null :
                                validateDateTime(laborreport.getDate("finishdate"), laborreport.getDate("finishtime"));
                }
*/

//                System.out.println("checkOverlapForOTField() laborstart..." + laborstart);
//                System.out.println("checkOverlapForOTField() laborfinish..." + laborfinish);
                /*
                 * Possible cases to check whether OT claim is successful between labor start and finish date
                 * a) OT start(myotstart) and OT finish(myotfinish) are not null and are between the labtrans start(laborstart) and labtrans finish(laborfinish)
                 * b) myotstart is equal to or later than laborstart but before laborfinish and myotfinish is null
                 * c) myotfinish is equal to or before laborfinish but before laborstart and myotstart is null
                 */

                if (laborstart != null && laborfinish != null)
                {
                    //case a
                    if ( myotstart != null && myotfinish != null && (myotstart.equals(laborstart) || myotstart.after(laborstart)) && (myotfinish.equals(laborfinish) || myotfinish.before(laborfinish)) )
                        doesotallowed = true;

                    //case b
                    if ( myotstart != null && myotfinish == null && (myotstart.equals(laborstart) || myotstart.after(laborstart)) )
                                doesotallowed = true;

                    //case c
                    if ( myotstart == null && myotfinish != null && (myotfinish.equals(laborfinish) || myotfinish.before(laborfinish)) )
                                doesotallowed = true;
                }


                if (doesotallowed)
                break;
        }
//        System.out.println("checkOverlapForOTField() doesotallowed..." + doesotallowed);

        //if OT is not part of any reported labtrans, throw an exception
        if(!doesotallowed)
        {          
			//Validation appplied using script
			needtoclearfield=2;
			return needtoclearfield;
			//throw new MXApplicationException("labor", "otnotlabsubset");
			//Validation appplied using script
        }


        //3. Check if OT overlaps with any other OT
        // if OT Claim is allowed between labor records within 90 days, need to check claimed OT is whether the overlapping records or not
        if(doesotallowed)
        {
                //Get OT LabTrans mbo
//              System.out.println("LABTRANSID :" + getString("LABTRANSID"));

            LabTransSetRemote otTransSet = (LabTransSetRemote) MXServer.getMXServer().getMboSet("LABTRANS", getUserInfo());
            //SQL need to be confirmed by your side to retrieve the OT records within 90 days
            //SqlFormat sqlformatOT = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and labtransid <> :3 and (TRUNC(sysdate) - TRUNC(STARTDATE)) <= 90 ");
            
            //Oracle to SQL conversion:
            SqlFormat sqlformatOT = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and labtransid <> :3 and (datediff ( dd,cast(startdate as date) ,cast(getdate() as date)) ) <= 90 ");
            
            //SqlFormat sqlformatOT = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and (TRUNC(sysdate) - TRUNC(STARTDATE)) <= 90 ");
            sqlformatOT.setObject(1, "LABTRANS", "LABORCODE", getString("laborcode"));
            sqlformatOT.setObject(2, "LABTRANS", "PSA_OT_FLAG", "1");
            sqlformatOT.setObject(3, "LABTRANS", "LABTRANSID", getString("LABTRANSID"));
            otTransSet.setWhere(sqlformatOT.format());
//            System.out.println("OT SQL: " + sqlformatOT.format() + ": " + MXServer.getMXServer().getDate());

            boolean doesotverlap = false;
            MboRemote otreport;
            for (int i = 0; (otreport = otTransSet.getMbo(i)) != null; i++)
            {

                    // Don't consider weird cases where the date is null but the time is filled in
                    Date otstart = (otreport.isNull("startdate")) ? null :
                                    validateDateTime(otreport.getDate("startdate"), otreport.getDate("starttime"));
                    Date otfinish = (otreport.isNull("finishdate")) ? null :
                                    validateDateTime(otreport.getDate("finishdate"), otreport.getDate("finishtime"));
/*

                                Date otstart;
                                Date otfinish;

                if(isOTStartField && rptotstarttime == null)
                {
                    otstart = (otreport.isNull("startdate")) ? null :
                                    validateDateTime(otreport.getDate("startdate"), rptotstarttime);
                }
                else
                {
                        otstart = (otreport.isNull("startdate")) ? null :
                                    validateDateTime(otreport.getDate("startdate"), otreport.getDate("starttime"));
                }

                if(!isOTStartField && rptotfinishtime == null)
                {
                        otfinish = (otreport.isNull("finishdate")) ? null :
                                    validateDateTime(otreport.getDate("finishdate"), rptotfinishtime);
                }
                else
                {
                        otfinish = (otreport.isNull("finishdate")) ? null :
                                    validateDateTime(otreport.getDate("finishdate"), otreport.getDate("finishtime"));
                }
*/

//                    System.out.println("checkOverlapForOTField() otstart..." + otstart);
//                    System.out.println("checkOverlapForOTField() otfinish..." + otfinish);
                    /*
                     * Cases of error to test :
                     * a) Entered OT start(myotstart) is after otstartdate checked(otstart) and myotstart is before otfinishdate checked(otfinish)
                     * b) Entered OT finish(myotfinish) is before otfinishdate checked(otfinish) and myotfinish is after otstartdate checked(otstart)
                     * c) myotstart is equal to otstart (otfinish can be null)
                     * d) myotfinish is equal to otfinish (otstart can be null)
                     */


                    if (otstart != null && otfinish != null)
                    {
                        //case a
                        if( myotstart != null && myotfinish != null && myotstart.after(otstart) && myotstart.before(otfinish))
                        {
                                doesotverlap = true;                                                                                 
                            }
                            //case b
                            if( myotstart != null && myotfinish != null && myotfinish.after(otstart) && myotfinish.before(otfinish))
                        {
                                doesotverlap = true;                                                                                 
                            }

                        }

                        if (otstart != null)
                        {
                            //case c
                            if( myotstart != null && myotstart.equals(otstart))
                        {
                                doesotverlap = true;                                                                                 
                            }
                    }

                    if (otfinish != null)
                        {
                            //case d
                            if( myotfinish != null && myotfinish.equals(otfinish))
                        {
                                doesotverlap = true;                                                                                 
                            }
                    }

                    if (doesotverlap)
                            break;
            }

//            System.out.println("checkOverlapForOTField() doesotverlap..." + doesotverlap);
            if (doesotverlap)
            {
                    //Exist Overlap OT from system
                    if (isOTStartField)
                            doesotstartoverlap = true;
                    else
                            doesotfinishoverlap = true;
                    //throw new MXApplicationException("labor", "otoverlap");
					//Validation appplied using script
					needtoclearfield=1;
					return needtoclearfield;
            }
            else
            {
                    // Reset the overlap flags if required
                    if (isOTStartField)
                            if (doesotstartoverlap)
                                    doesotstartoverlap = false;
                    else
                            if (doesotfinishoverlap)
                                    doesotfinishoverlap = false;
            }
        }
/*                else
        {
                //OT is only allowed for records that are within 90 days
                throw new MXApplicationException("labor", "otagainstlabor");
        }
*/
//        System.out.println("checkOverlapForOTField() end: " + MXServer.getMXServer().getDate());
        return needtoclearfield;
}

//Begin modification SR-080
/*
 * Check for overlap after a user has input a start/end date/time
 * Returns true if the field creates an overlap and that the user chooses to cancel his entry, returns false otherwise
 */
public boolean checkOverlapForField(boolean isStartField)
                throws MXException, RemoteException
{
        boolean needtoclearfield = false;

        /*
         * If the other date/time makes the current report overlap, no need to check again the current field
         * as the report will definitly overlap again and the check would prompt the user again needlessly
         */
        if ((isStartField && doesfinishoverlap) || (!isStartField && doesstartoverlap))
                return needtoclearfield;

        Date mystart = validateDateTime(getDate("startdate"), getDate("starttime"));
        Date myfinish = validateDateTime(getDate("finishdate"), getDate("finishtime"));
        Date datechecked = (isStartField)? mystart : myfinish;

        // Need to be update, since the laborreportset will be included OT transactions in future
        MboSetRemote laborreportset = getMboSet("OTHERLABORREPORTS");
        MboRemote laborreport;
        boolean doesoverlap = false;
        for (int i = 0; (laborreport = laborreportset.getMbo(i)) != null; i++)
        {
                // Don't consider weird cases where the date is null but the time is filled in
                Date start = (laborreport.isNull("startdate"))? null :
                                validateDateTime(laborreport.getDate("startdate"), laborreport.getDate("starttime"));
                Date finish = (laborreport.isNull("finishdate"))? null :
                                validateDateTime(laborreport.getDate("finishdate"), laborreport.getDate("finishtime"));

                /*
                 * Cases of error to test :
                 * a) the date checked is after the WO start and the WO finish is empty
                 * b) mystart is equal to WO start and the WO finish is empty
                 * c) the date checked is in between the WO start and finish
                 * d) mystart is equal to WO start
                 * e) myfinish is equal to WO finish
                 * f) mystart and myfinish surround the WO start and finish
                 * The other possible error cases are not tested as they correspond to an overlap that's already known
                 */
                if (start != null)
                {
                        if (finish == null)
                        {
                                if (    datechecked.after(start) ||                                                                     //      case a
                                                (mystart != null && mystart.equals(start)) )                            // case b
                                        doesoverlap = true;
                        }
                        else
                        {
                                if (datechecked.after(start) && datechecked.before(finish))     // case c
                                        doesoverlap = true;
                                if (mystart != null)
                                        if (    mystart.equals(start) ||                                                                        // case d
                                                        (mystart.before(start) && myfinish != null &&
                                                                        myfinish.after(finish)) )                                                       // case f
                                                doesoverlap = true;
                                else if (myfinish != null && myfinish.equals(finish))           // case e
                                        doesoverlap = true;
                        }
                }
                if (doesoverlap)
                        break;
        }

        if (doesoverlap)
        {
                int userInput = MXApplicationYesNoCancelException.getUserInput(
                                "laborOverlap", MXServer.getMXServer(), getUserInfo());
                switch (userInput)
                {
                case MXApplicationYesNoCancelException.NULL:
                        String param[] = { laborreport.getString("refwo") };
                        throw new MXApplicationYesNoCancelException("laborOverlap", "labor", "overlap", param);

                case MXApplicationYesNoCancelException.OK:
                        if (isStartField)
                                doesstartoverlap = true;
                        else
                                doesfinishoverlap = true;
                        break;

//              case MXApplicationYesNoCancelException.CANCEL:
//                      needtoclearfield = true;
//                      break;
                }
        }
        else
        {
                // Reset the overlap flags if required
                if (isStartField)
                        if (doesstartoverlap)
                                doesstartoverlap = false;
                else
                        if (doesfinishoverlap)
                                doesfinishoverlap = false;
        }
        return needtoclearfield;
}
//End modification SR-080


//Begin modification SR-030
public void save()
                throws MXException, RemoteException
{
        if (getDouble("linecost") > 0)
        {
                FinancialTransaction financialtransaction = new FinancialTransaction(myset);
                financialtransaction.validateProject(this, "WORKORDER");
        }

        boolean otflag = getBoolean("PSA_OT_FLAG");

//start of EMS-802        
	if (!toBeDeleted())
	{        
        if (otflag && (isNull("startdate") || isNull("starttime") || isNull("finishdate") || isNull("finishtime")))
        {
            throw new MXApplicationException("labor", "otdatetimeempty");
        }
/*              if(!getBoolean("PSA_OT_FLAG"))
        {
                checkOverlapForOTField(true);
                }
*/
        //start of EMS-767
        /*if(!isNull("PSA_OT_FLAG"))//ensure that PSA_OT_FLAG is not null
        {
            if (otflag)//call checkOTOverlap() before super.save()
            {
                    if(checkOTOverlap())
                        throw new MXApplicationException("labor", "otoverlap");
            }
            //start of EMS-666
            else
            {
                    if(!(isNull("startdate")) && !(isNull("starttime")) && !(isNull("finishdate")) && !(isNull("finishtime")))//call checkOverlap() only if all 4 date time fields are not null
                    {
                        checkOverlap();
                    }
            }
            //end of EMS-666
        }*/
        //end of EMS-767

	}    
//end of EMS-802
//start of 2.5.5 validation 
	//start of EMS-1033
	/*
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date date = new Date();
	System.out.println("start of EMS-1033 : " + dateFormat.format(date));
	*/
	
	//Get WO Mbo (if exist)
//	WORemote wo1 = null;
//	MboRemote mboremote = getOwner();
//	    if(mboremote == null || (mboremote instanceof LabTransEnterBy))
//	    {
//	        if(!isNull("wonum"))
//	        {
//                WOSetRemote wo1Set =(WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", getUserInfo());
//	            SqlFormat sqlformat = new SqlFormat(getUserInfo(), "wonum = :1 and siteid = :2");
//	            sqlformat.setObject(1, "WORKORDER", "WONUM", getString("wonum"));
//	            sqlformat.setObject(2, "WORKORDER", "SITEID", getString("siteid"));
//	            wo1Set.setWhere(sqlformat.format());
//	
//	            if(!wo1Set.isEmpty())
//	            {
//	                wo1 = (WORemote) wo1Set.getMbo(0);
//	            }
//	        }
//	    }
//	    else
//	    {
//	        if(mboremote instanceof WORemote){
//	                wo1 = (WORemote) mboremote;
//	        }
//	    }
//	
//
//	    if(wo1 != null){
//	        String wo1WorkType = wo1.getString("WORKTYPE");
//	        if(wo1WorkType != null)
//	        {
//	
//	//Get Worktype mbo
//				WorkTypeSetRemote worktypeSet = (WorkTypeSetRemote) MXServer.getMXServer().getMboSet("WORKTYPE", getUserInfo());
//
//				SqlFormat sqlformatWOType = new SqlFormat(getUserInfo(),"worktype = :1 and orgid = :2");
//				sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", wo1WorkType);
//				sqlformatWOType.setObject(2, "LABTRANS", "ORGID", getString("orgid"));
//				worktypeSet.setWhere(sqlformatWOType.format());
//
//				if (!worktypeSet.isEmpty())
//				{
//					WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
//					boolean noLabCost = worktype.getBoolean("nolabcost");
//					if (noLabCost)
//		            {
//                		//to get the cost centre of the GL debit account of labtrans
//                		String finalGLAccount = getString("GLDEBITACCT");
//                		if(!(finalGLAccount.equals(null) || finalGLAccount.equals("")) )
//                		{
//                        	MXServer mxserver = MXServer.getMXServer();
//                        	MboSetRemote glconfigureset = mxserver.getMboSet("GLCONFIGURE", getUserInfo());
//                        	String gldelimiter = glconfigureset.getMbo(0).getString("delimiter");
//                        	String[] glaccountseg = finalGLAccount.split(gldelimiter);
//
//                        	//to get the labcost_i  flag of the cost centre of the GL debit account of labtrans
//                        	GLComponentsSetRemote glcompSet = (GLComponentsSetRemote)MXServer.getMXServer().getMboSet("GLCOMPONENTS", getUserInfo());
//
//                            SqlFormat sqlformatGLComp = new SqlFormat(getUserInfo(), "COMPVALUE= :1 and orgid= :2 and GLORDER=5 ");
//                            sqlformatGLComp.setObject(1, "GLCOMPONENTS", "COMPVALUE", glaccountseg[5]);
//                            sqlformatGLComp.setObject(2, "LABTRANS", "ORGID", getString("orgid"));
//                            glcompSet.setWhere(sqlformatGLComp.format());
//
//                            GLComponentsRemote GLComp = (GLComponentsRemote)glcompSet.getMbo(0);
//                            boolean CCLabCost = GLComp.getBoolean("LABCOST_I");
//
//                            //set payrate to be zero  if LABCOST_I flag is 0
//                        	if(!CCLabCost)
//                        	{
//                            	setValue("payrate", 0, 2);
//							}
//                        }
//                	}
//                	else
//						setValue("payrate", getPayRate(), 2L);
//					}
//			}
//		}
//End of 2.5.5 validation					
			//Date date2 = new Date();
			//System.out.println("end of EMS-1033 : " + dateFormat.format(date2));
	//end of EMS-1033

                super.save();
}
//End modification SR-030

public void setPayRate() throws MXException, RemoteException{
		WORemote wo1 = null;
	MboRemote mboremote = getOwner();
	    if(mboremote == null || (mboremote instanceof LabTransEnterBy))
	    {
	        if(!isNull("wonum"))
	        {
                WOSetRemote wo1Set =(WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", getUserInfo());
	            SqlFormat sqlformat = new SqlFormat(getUserInfo(), "wonum = :1 and siteid = :2");
	            sqlformat.setObject(1, "WORKORDER", "WONUM", getString("wonum"));
	            sqlformat.setObject(2, "WORKORDER", "SITEID", getString("siteid"));
	            wo1Set.setWhere(sqlformat.format());
	
	            if(!wo1Set.isEmpty())
	            {
	                wo1 = (WORemote) wo1Set.getMbo(0);
	            }
	        }
	    }
	    else
	    {
	        if(mboremote instanceof WORemote){
	                wo1 = (WORemote) mboremote;
	        }
	    }
		    if(wo1 != null){
	        String wo1WorkType = wo1.getString("WORKTYPE");
	        if(wo1WorkType != null)
	        {
	
	// Get Worktype mbo
				WorkTypeSetRemote worktypeSet = (WorkTypeSetRemote) MXServer.getMXServer().getMboSet("WORKTYPE", getUserInfo());

				SqlFormat sqlformatWOType = new SqlFormat(getUserInfo(),"worktype = :1 and orgid = :2");
				sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", wo1WorkType);
				sqlformatWOType.setObject(2, "LABTRANS", "ORGID", getString("orgid"));
				worktypeSet.setWhere(sqlformatWOType.format());

				if (!worktypeSet.isEmpty())
				{
					WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
					boolean noLabCost = worktype.getBoolean("nolabcost");
					String wtCraft = worktype.getString("PSA_WTCATEGORY");
					Properties configData = MXServer.getMXServer().getConfig();
					String prop = configData.getProperty("com.psa.worktype.category");
					String[] propValueList = prop.split(",");

					if (noLabCost)
		            {
                		//to get the cost centre of the GL debit account of labtrans
                		String finalGLAccount = getString("GLDEBITACCT");
                		if(!(finalGLAccount.equals(null) || finalGLAccount.equals("")) )
                		{
                        	MXServer mxserver = MXServer.getMXServer();
                        	MboSetRemote glconfigureset = mxserver.getMboSet("GLCONFIGURE", getUserInfo());
                        	String gldelimiter = glconfigureset.getMbo(0).getString("delimiter");
                        	String[] glaccountseg = finalGLAccount.split(gldelimiter);

                        	//to get the labcost_i  flag of the cost centre of the GL debit account of labtrans
                        	GLComponentsSetRemote glcompSet = (GLComponentsSetRemote)MXServer.getMXServer().getMboSet("GLCOMPONENTS", getUserInfo());
                        	
                        	//BCT modified the GL Structural Change
                        	
                            //SqlFormat sqlformatGLComp = new SqlFormat(getUserInfo(), "COMPVALUE= :1 and orgid= :2 and GLORDER=5 ");
                        	SqlFormat sqlformatGLComp = new SqlFormat(getUserInfo(), "COMPVALUE= :1 and orgid= :2 and GLORDER=3 ");
                            
                        	sqlformatGLComp.setObject(1, "GLCOMPONENTS", "COMPVALUE", glaccountseg[3]);
                            sqlformatGLComp.setObject(2, "LABTRANS", "ORGID", getString("orgid"));
                            glcompSet.setWhere(sqlformatGLComp.format());

                            GLComponentsRemote GLComp = (GLComponentsRemote)glcompSet.getMbo(0);
                            boolean CCLabCost = GLComp.getBoolean("LABCOST_I");

                            //set payrate to be zero  if LABCOST_I flag is 0
                        	//BCT Commented as it was requested to remove from PSA
                            if(!CCLabCost)
                        	{
                            	setValue("payrate", 0, 2);
							}
                        }
                	}
                	else {
                		for(int i=0;i<propValueList.length;i++) {
                			if(wtCraft=="" || wtCraft==null || wtCraft.equalsIgnoreCase(propValueList[i])) {
                    			setValue("payrate", getPayRate(), 2L);
                    			break;
                    		}		
                		}	
                		
                	}
						
					}
			}
		}
}
//End of 2.5.5 Validation
//start of EMS-767
/*
 * Function purely to check for OT overlap, used by save().
 * Returns true if there is OT overlap and false if otherwise
 *
 */
public boolean checkOTOverlap()
                throws MXException, RemoteException
{
            Date myotstart = validateDateTime(getDate("startdate"), getDate("starttime"));
                Date myotfinish = validateDateTime(getDate("finishdate"), getDate("finishtime"));

            //Get OT LabTrans mbo in the last 90 days
            LabTransSetRemote otTransSet = (LabTransSetRemote) MXServer.getMXServer().getMboSet("LABTRANS", getUserInfo());
            //SqlFormat sqlformatOT = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and labtransid <> :3 and (TRUNC(sysdate) - TRUNC(STARTDATE)) <= 90 ");
            
            //Oracle To SQL Conversion:
            SqlFormat sqlformatOT = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and labtransid <> :3 and (datediff ( dd,cast(startdate as date) ,cast(getdate() as date))) <= 90 ");
            
            sqlformatOT.setObject(1, "LABTRANS", "LABORCODE", getString("laborcode"));
            sqlformatOT.setObject(2, "LABTRANS", "PSA_OT_FLAG", "1");
            sqlformatOT.setObject(3, "LABTRANS", "LABTRANSID", getString("LABTRANSID"));
            otTransSet.setWhere(sqlformatOT.format());

            boolean doesotverlap = false;
            MboRemote otreport;
            for (int i = 0; (otreport = otTransSet.getMbo(i)) != null; i++)
            {

                    // Don't consider weird cases where the date is null but the time is filled in
                    Date otstart = (otreport.isNull("startdate")) ? null :
                                    validateDateTime(otreport.getDate("startdate"), otreport.getDate("starttime"));
                    Date otfinish = (otreport.isNull("finishdate")) ? null :
                                    validateDateTime(otreport.getDate("finishdate"), otreport.getDate("finishtime"));

                    /*
                     * Cases of error to test :
                     * a) Entered OT start(myotstart) is after otstartdate checked(otstart) and myotstart is before otfinishdate checked(otfinish)
                     * b) Entered OT finish(myotfinish) is before otfinishdate checked(otfinish) and myotfinish is after otstartdate checked(otstart)
                     * c) myotstart is equal to otstart (otfinish can be null)
                     * d) myotfinish is equal to otfinish (otstart can be null)
                     */


                    if (otstart != null && otfinish != null)
                    {
                        //case a
                        if( myotstart != null && myotfinish != null && myotstart.after(otstart) && myotstart.before(otfinish))
                        {
                                doesotverlap = true;                                                                                 
                            }
                            //case b
                            if( myotstart != null && myotfinish != null && myotfinish.after(otstart) && myotfinish.before(otfinish))
                        {
                                doesotverlap = true;                                                                                 
                            }

                        }

                        if (otstart != null)
                        {
                            //case c
                            if( myotstart != null && myotstart.equals(otstart))
                        {
                                doesotverlap = true;                                                                                 
                            }
                    }

                    if (otfinish != null)
                        {
                            //case d
                            if( myotfinish != null && myotfinish.equals(otfinish))
                        {
                                doesotverlap = true;                                                                                 
                            }
                    }

                    if (doesotverlap)
                            break;
            }

            if (doesotverlap)
            {
                    return true;
            }
            else
            {
                     return false;
            }

}
//end of EMS-767

//start of EMS-958
/*
 * Function for checking if Current User is in the specified group, used by save().
 * Returns true if Current User is in the specified group, false if otherwise
 *
 */
public boolean isCurrUserInGrp(String grp)
                throws MXException, RemoteException
{
	
	boolean currUserIsInGrp = false;
	
	MboSetRemote groupset = MXServer.getMXServer().getMboSet("GROUPUSER", getUserInfo());
	SqlFormat sql2 = new SqlFormat("GROUPNAME ='"+grp+"'");
	groupset.setWhere(sql2.format());
	String currentuser = getUserName();

	int i=0;

	//Check if the user belongs to target group
	for(MboRemote user = null; (user = groupset.getMbo(i)) != null; i++) {
		if(user.getString("USERID").equalsIgnoreCase(currentuser)) currUserIsInGrp =true;
	}
	
	return currUserIsInGrp;

}
//end of EMS-958

//start of EMS-666
/*
 * Function purely to check for normal labour overlap, used by save().
 * Throw an MXException if there is normal labour overlap and breaks out of loop if otherwise
 *
 */
public void checkOverlap()
                throws MXException, RemoteException
{
            Date mystart = validateDateTime(getDate("startdate"), getDate("starttime"));
            Date myfinish = validateDateTime(getDate("finishdate"), getDate("finishtime"));

            //Start of EMS-800/EMS-801/EMS-802
            //Need new condition to check list of labtrans against
            MboSetRemote otherTransSet = getMboSet("CHKLABOVERLAP");
                      
            /*
            LabTransSetRemote otherTransSet = (LabTransSetRemote) MXServer.getMXServer().getMboSet("LABTRANS", getUserInfo());
            SqlFormat sqlformatOTH = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and labtransid <> :3 and regularhrs > 0 and (startdate > sysdate-30) ");
            sqlformatOTH.setObject(1, "LABTRANS", "LABORCODE", getString("laborcode"));
            sqlformatOTH.setObject(2, "LABTRANS", "PSA_OT_FLAG", "0");
            sqlformatOTH.setObject(3, "LABTRANS", "LABTRANSID", getString("LABTRANSID"));
            otherTransSet.setWhere(sqlformatOTH.format());
            */
            
            //End of EMS-800/EMS-801/EMS-802

                // Need to be update, since the laborreportset will be included OT transactions in future
                MboRemote laborreport;
                boolean doesoverlap = false;
                for (int i = 0; (laborreport = otherTransSet.getMbo(i)) != null; i++)
                {
                        // Don't consider weird cases where the date is null but the time is filled in
                        Date start = (laborreport.isNull("startdate"))? null :
                                        validateDateTime(laborreport.getDate("startdate"), laborreport.getDate("starttime"));
                        Date finish = (laborreport.isNull("finishdate"))? null :
                                        validateDateTime(laborreport.getDate("finishdate"), laborreport.getDate("finishtime"));

                    /*
                     * Cases of error to test :
                     * a) Entered OT start(myotstart) is after otstartdate checked(otstart) and myotstart is before otfinishdate checked(otfinish)
                     * b) Entered OT finish(myotfinish) is before otfinishdate checked(otfinish) and myotfinish is after otstartdate checked(otstart)
                     * c) myotstart is equal to otstart (otfinish can be null)
                     * d) myotfinish is equal to otfinish (otstart can be null)
                     */


                    if (start != null && finish != null)
                    {
                        //case a
                        if( mystart != null && myfinish != null && mystart.after(start) && mystart.before(finish))
                        {
                                doesoverlap = true;                                                                                  
                            }
                            //case b
                            if( mystart != null && myfinish != null && myfinish.after(start) && myfinish.before(finish))
                        {
                                doesoverlap = true;                                                                                  
                            }

                        }

                        if (start != null)
                        {
                            //case c
                            if( mystart != null && mystart.equals(start))
                        {
                                doesoverlap = true;                                                                                  
                            }
                    }

                    if (finish != null)
                        {
                            //case d
                            if( myfinish != null && myfinish.equals(finish))
                        {
                                doesoverlap = true;                                                                                  
                            }
                    }

                    if (doesoverlap)
                            break;
                }

                //Start of EMS-800/EMS-801/EMS-802
                
                if( doesoverlap && !isCurrUserInGrp("MAXADMIN") ) // EMS-958: Add criteria to skip Labor Overlap check for users in MAXADMIN group, Desmond
                {
                    int userInput = MXApplicationYesNoCancelException.getUserInput(
                                "laborOverlap", MXServer.getMXServer(), getUserInfo());
                	switch (userInput)
                	{
                        case MXApplicationYesNoCancelException.NULL:
                                String param[] = { laborreport.getString("refwo") };
                                throw new MXApplicationYesNoCancelException("laborOverlap", "labor", "overlap", param);

                        case MXApplicationYesNoCancelException.OK:
                                break;
                	}
                }
                
                //End of EMS-800/EMS-801/EMS-802
}
//end of EMS-666


//Begin modification SR-030
private MboSet myset;
//End modification SR-030
//Begin modification SR-080
private boolean doesstartoverlap;
private boolean doesfinishoverlap;
//End modification SR-080

//Begin Add flag to validate the OT Records overlap
private boolean doesotstartoverlap;
private boolean doesotfinishoverlap;
//End Add flag to validate the OT Records overlap
/*
 * Author: YCH
 *
 * When User to verify OT Transaction
 *
 * 1. Need to do the validation(Overlapping and so on) for the OT Record firstly.
 * 2. Update the verify info into current OT Transaction.
 *
 * @Date: 31 Oct 2011
 *
 */
public void verifyOTTransaction(boolean otrep) throws MXException, RemoteException
{
//        System.out.println("verifyOTTransaction() start: " + MXServer.getMXServer().getDate());
        if(getBoolean("PSA_VERIFIED"))
                throw new MXApplicationException("labor", "alreadyverify");

        boolean otflag = getBoolean("PSA_OT_FLAG");

//        System.out.println("OT Flag is: " + otflag);

        if (otflag)
        {
            //run through checks for OT overlap & OT >90 days  & OT subset of labour
        //    checkOverlapForOTField(true);

            boolean haslabor = false;
            //check for approved labor
            if(otrep)
            {
                if (!isNull("STARTDATE") && !isNull("STARTTIME") && !isNull("FINISHDATE") && !isNull("FINISHTIME"))
                {
                        LabTransSetRemote apprLabor = (LabTransSetRemote) MXServer.getMXServer().getMboSet("LABTRANS", getUserInfo());
                        
                        //Oracle To SQL conversion:
                        
                        //SqlFormat sqlformatOT = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and GENAPPRSERVRECEIPT = :3 and TRUNC(FINISHDATE)>= TRUNC(:4) ");
                        SqlFormat sqlformatOT = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and GENAPPRSERVRECEIPT = :3 and cast(FINISHDATE as date)>= cast(:4 as date) ");
                        
                        //SqlFormat sqlformatOT = new SqlFormat(getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and (TRUNC(sysdate) - TRUNC(STARTDATE)) <= 90 ");
                        sqlformatOT.setObject(1, "LABTRANS", "LABORCODE", getString("laborcode"));
                        sqlformatOT.setObject(2, "LABTRANS", "PSA_OT_FLAG", "0");
                        sqlformatOT.setObject(3, "LABTRANS", "GENAPPRSERVRECEIPT", "1");
                        sqlformatOT.setObject(4, "LABTRANS", "STARTDATE", getString("STARTDATE"));
                        apprLabor.setWhere(sqlformatOT.format());

//                      System.out.println("Appr Labor Query: " + sqlformatOT.format());

//                              if(apprLabor.count()==0)
//                              {
//                                      throw new MXApplicationException("labor", "NoApprLabor");
//                                  }

                        MboRemote labtrans;
                        for (int i = 0; (labtrans = apprLabor.getMbo(i)) != null; i++)
                        {
                                if((labtrans.getDate("STARTDATE").equals(getDate("STARTDATE")) || labtrans.getDate("STARTDATE").before(getDate("STARTDATE"))) &&  (labtrans.getDate("FINISHDATE").equals(getDate("FINISHDATE")) || labtrans.getDate("FINISHDATE").after(getDate("FINISHDATE"))))
                                {
//                                      System.out.println("STARTDATE < OT Startdate && FINISHDATE > OT Finishdate");
                                        if((labtrans.getDate("STARTTIME").equals(getDate("STARTTIME")) || labtrans.getDate("STARTTIME").before(getDate("STARTTIME"))) &&  (labtrans.getDate("FINISHTIME").equals(getDate("FINISHTIME")) || labtrans.getDate("FINISHTIME").after(getDate("FINISHTIME"))))
                                        {
//                                              System.out.println("STARTTIME < OT Starttime && FINISHTIME > OT Finishtime");
                                                haslabor = true;
                                        }
                                }
                        }
                }

            // Update the verify Person ID of OT Transaction
//            System.out.println("User ID getUserInfo().getPersonId(): " + getUserInfo().getPersonId());
//            System.out.println("User ID getString('laborcode'): " + getString("laborcode"));
            }

            if(haslabor == true || otrep == false)
            {
                setValue("PSA_VERIFIEDBY", getUserInfo().getPersonId(), 11L);

                // Update the verify date of OT Transaction
                Date verifydate = MXServer.getMXServer().getDate();
                setValue("PSA_VERIFIEDDATE", verifydate, 11L);

                // Update the verify flag of OT Transaction
                setValue("PSA_VERIFIED", true, 11L);
            }else
            {
                throw new MXApplicationException("labor", "NoApprLabor");
            }
        }
//        System.out.println("verifyOTTransaction() End: " + MXServer.getMXServer().getDate());
}

/*
 * Author: YCH
 *
 * When User to verify OT Transaction
 *
 * 1. Need to do the validation(Overlapping and so on) for the OT Record firstly.
 * 2. Update the verify info into current OT Transaction.
 *
 * @Date: 31 Oct 2011
 *
 */
public void approveOTTransaction() throws MXException, RemoteException
{
//        System.out.println("approveOTTransaction() start: " + MXServer.getMXServer().getDate());

//        System.out.println("VERIFY Flag : " + getBoolean("PSA_VERIFIED"));
        if(getBoolean("genapprservreceipt"))
                throw new MXApplicationException("labor", "otalreadyappr");


        if(!getBoolean("PSA_VERIFIED"))
                throw new MXApplicationException("labor", "otnotverify");


        if(getBoolean("PSA_VERIFIED") && !getBoolean("genapprservreceipt"))
        {
            //checkOverlapForOTField(true);

            // Update the approve OT Transaction
//            System.out.println("User ID getUserInfo().getPersonId(): " + getUserInfo().getPersonId());
//            System.out.println("User ID getString('laborcode'): " + getString("laborcode"));

            setValue("PSA_APPROVEDBY", getUserInfo().getPersonId(), 11L);
            setValue("genapprservreceipt", true, 11L);
            setValue("paymenttransdate", MXServer.getMXServer().getDate(), 11L);
        }

//        System.out.println("approveOTTransaction() end: " + MXServer.getMXServer().getDate());
}

/*
 * Author: YCH
 *
 * When User to do Copy from Labor Action
 *
 * 1. Get Current OT Transactions
 * 2. Retrieve Selected Labor Transactions
 * 3. Copy Labor Transactions into OT Transactions
 *
 * @Date: 31 Oct 2011
 *
 */
public void copyLabTransToCurrentOT(MboSetRemote mbosetremote)
        throws MXException, RemoteException
{
        MboSetRemote mbosetremote1 = getMboSet("OTLABOR");
        Vector vector = mbosetremote.getSelection();
        if (vector.size() == 0)
                throw new MXApplicationException("labor", "selectAtLeastOne");

        for (int i = 0; i < vector.size(); i++)
        {
                MboRemote mboremote;
                if ((mboremote = (MboRemote) vector.elementAt(i)) != null)
                {
                        MboRemote mboremote1 = mbosetremote1.addAtEnd();
                        Date date1 = MXServer.getMXServer().getDate();
                        Date date = MXServer.getMXServer().getDate(getClientLocale(), getClientTimeZone());
                        mboremote1.setValue("laborcode", mboremote.getString("laborcode"), 11L);
                        mboremote1.setValue("startdate", mboremote.getString("startdate"), 11L);
                        mboremote1.setValue("enterdate", date1, 11L);
                        mboremote1.setValue("enterby", getUserInfo().getUserName(), 11L);
                        mboremote1.setValue("transdate", date, 11L);
                        mboremote1.setValue("transtype", getTranslator().toExternalDefaultValue("lttype", "WORK", this), 11L);
                        mboremote1.setValue("GenApprServReceipt", false, 11L);
                        mboremote1.setValue("PSA_OT_FLAG", true, 11L);
                }
        }
}

/*
 * Author: LS
 *
 * To unverify OT Transaction
 *
 * @Date: 18 Jan 2012
 *
 */
public void unverifyOTTransaction() throws MXException, RemoteException
{
//        System.out.println("unverifyOTTransaction() start: " + MXServer.getMXServer().getDate());

        if(!getBoolean("PSA_VERIFIED"))
                throw new MXApplicationException("labor", "alreadynotverify");

        if(getBoolean("genapprservreceipt"))
                throw new MXApplicationException("labor", "otalreadyappr");


        boolean otflag = getBoolean("PSA_OT_FLAG");

//        System.out.println("OT Flag is: " + otflag);

        if (otflag)
        {
                // Update the verify Person ID of OT Transaction
//              System.out.println("User ID getUserInfo().getPersonId(): " + getUserInfo().getPersonId());
//              System.out.println("User ID getString('laborcode'): " + getString("laborcode"));

                setValue("PSA_VERIFIEDBY", getUserInfo().getPersonId(), 11L);

                // Update the verify date of OT Transaction
                Date verifydate = MXServer.getMXServer().getDate();
                setValue("PSA_VERIFIEDDATE", verifydate, 11L);

                // Update the verify flag of OT Transaction
                setValue("PSA_VERIFIED", false, 11L);
        }

//        System.out.println("unverifyOTTransaction() End: " + MXServer.getMXServer().getDate());
}

/*
 *
 * Call the super class's method to initialize the add record
 * Set OT Flag as default false value
 * Set OT Verify Flag as default false value
 *
 * Date: 11 Nov 2011
 */
public void add() throws MXException, RemoteException {
        getMboLogger().debug("LabTransCustom.add() start...");
        super.add();
        setValue("PSA_OT_FLAG", false, 11L);
        setValue("PSA_VERIFIED", false, 11L);
        getMboLogger().debug("LabTransCustom.add() end...");
}

public void setOTFlag(boolean flag) throws MXException, RemoteException {
        getMboLogger().debug("setOTFlag start...");
        setValue("PSA_OT_FLAG", flag, 11L);
        getMboLogger().debug("OT Flag :" + getBoolean("PSA_OT_FLAG"));
        getMboLogger().debug("setOTFlag end...");
}
}

