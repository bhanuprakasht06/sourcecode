/*
 * Modification history
 * 07-06-2007	LES	SR-091	Copy WPITEM.DONUM to the popup
 * 30-10-2007	AGD	DR-053	Need to by-pass the validation when setting packingslipnum
 */
package com.psa.app.po.virtual;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldDescriptionCustom extends MboValueAdapter
{

	public FldDescriptionCustom()
	{
		super();
	}


	public FldDescriptionCustom(MboValue mbovalue)
	{
		super(mbovalue);
	}


	public void validate()
			throws MXException, RemoteException
	{
		Mbo mbo = getMboValue().getMbo();

		MboSetRemote polineset = mbo.getMboSet("POLINE");
		MboRemote poline = polineset.getMbo(0);

		if (poline.getString("STORELOC") == null || poline.getString("STORELOC").equals(""))
		{
			MboSetRemote wpitemset = poline.getMboSet("WPITEM_RECEIPT");
			MboRemote wpitem = wpitemset.getMbo(0);
			if (wpitem == null)
			{
				Object param[] = { mbo.getString("Description") };
				throw new MXApplicationException("po", "nonstocknotvalid", param);
			}
//Begin modification DR-053
			// mbo.setValue("PACKINGSLIPNUM", wpitem.getString("DONUM"));
			mbo.setValue("packingslipnum", wpitem.getString("donum"), MboConstants.NOVALIDATION);
//End modification DR-053
		}
	}
}
