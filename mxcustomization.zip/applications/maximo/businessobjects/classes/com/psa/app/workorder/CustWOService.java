package com.psa.app.workorder;

import java.io.PrintStream;
import java.rmi.RemoteException;
import java.util.Date;
import javax.jws.WebMethod;
import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOService;
import psdi.iface.webservices.action.SigOption;
import psdi.iface.webservices.action.WSMboKey;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;

public class CustWOService
 extends WOService
  implements CustWOServiceRemote
{
	public CustWOService()
		throws RemoteException
	{
		
	}
  
	public CustWOService(MXServer mxServer)
		throws RemoteException
	{
		super(mxServer);
	}
  
	@WebMethod
	@SigOption("STATUS")
	public synchronized void custchangeStatus(@WSMboKey("WORKORDER") WORemote wo, String status, Date date, String memo)
			throws MXException, RemoteException
	{
		System.out.println("from custchangeStatus wo = " + wo.getString("wonum"));
		System.out.println("from custchangeStatus status = " + status);
		System.out.println("from custchangeStatus date = " + date);
		System.out.println("from custchangeStatus memo = " + memo);
		if (status.equalsIgnoreCase("A")) 
		{
			MboSetRemote chkNSSet = wo.getMboSet("$WPITEM","WPITEM","wonum='" + wo.getString("wonum") + "' and ((linetype in('STDSERVICE','MATERIAL','SERVICE')) or (itemnum in (select itemnum from itemorginfo where category='NS')))");    	
			if (chkNSSet.isEmpty())
				wo.changeStatus("APPROPS", date, memo);
			else
				wo.changeStatus("WAPPR", date, memo);
		}    
		else if (status.equalsIgnoreCase("I")) 
		{
			wo.changeStatus("WPLSCH", date, memo);
		}
		else if (status.equalsIgnoreCase("U")) 
		{
			wo.changeStatus("WPLSCH", date, memo);
		}
		else if (status.equalsIgnoreCase("P")) 
		{
			wo.changeStatus("WPLSCH", date, memo);
		}
		else if (status.equalsIgnoreCase("C")) 
		{
			MboSetRemote chkNSSet = wo.getMboSet("$WPITEM","WPITEM","wonum='" + wo.getString("wonum") + "' and ((linetype in('STDSERVICE','MATERIAL','SERVICE')) or (itemnum in (select itemnum from itemorginfo where category='NS')))");    	
			if (chkNSSet.isEmpty())
				wo.changeStatus("APPRWOPS", date, memo);
			else
				wo.changeStatus("WAPPR", date, memo);
		}
		else if (status.equalsIgnoreCase("M")) 
		{
			wo.changeStatus("INPRG", date, memo);
		}
		else if (status.equalsIgnoreCase("D")) 
		{
			wo.changeStatus("COMP", date, memo);
		}
		else if (status.equalsIgnoreCase("APPRWOPS")) 
		{
			MboSetRemote chkNSSet = wo.getMboSet("$WPITEM","WPITEM","wonum='" + wo.getString("wonum") + "' and ((linetype in('STDSERVICE','MATERIAL','SERVICE')) or (itemnum in (select itemnum from itemorginfo where category='NS')))");    	
			if (chkNSSet.isEmpty())
				wo.changeStatus("APPRWOPS", date, memo);
			else
				wo.changeStatus("WAPPR", date, memo);
		}
		else if (status.equalsIgnoreCase("APPROPS")) 
		{
			MboSetRemote chkNSSet = wo.getMboSet("$WPITEM","WPITEM","wonum='" + wo.getString("wonum") + "' and ((linetype in('STDSERVICE','MATERIAL','SERVICE')) or (itemnum in (select itemnum from itemorginfo where category='NS')))");    	
			if (chkNSSet.isEmpty())
				wo.changeStatus("APPROPS", date, memo);
			else
				wo.changeStatus("WAPPR", date, memo);
		}    
		else 
		{ 
			wo.changeStatus(status, date, memo);
		}
	}
}