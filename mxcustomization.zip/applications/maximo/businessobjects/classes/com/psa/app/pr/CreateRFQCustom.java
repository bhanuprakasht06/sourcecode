/*
 * Modiifcation History
 * 20-03-08	HMD			Creation
 * 24-04-08	HMD			Retrieving the attachments details from the related WO into RFQ
 * 12-03-09	HMD	DR-070	Set the Long Description from PR Line to RFQ Line
 */
package com.psa.app.pr;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.psa.app.rfq.RFQCustomRemote;

import psdi.app.pr.PRRemote;
import psdi.common.action.ActionCustomClass;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;

public class CreateRFQCustom 
implements ActionCustomClass
{
public CreateRFQCustom() 
{
}

public void applyCustomAction(MboRemote mboremote, Object aobj[])
	throws MXException, RemoteException
{
	//mboremote is pointing processing PR details.
	try
	{
		PRRemote prremote = (PRRemote) mboremote;
		if (prremote.getInternalStatus().equalsIgnoreCase("APPR"))
		{
			MboSetRemote rfqsetremote = MXServer.getMXServer().getMboSet("RFQ", mboremote.getUserInfo());
			MboRemote rfqremote = rfqsetremote.add();
			rfqremote.setValue("SITEID", mboremote.getString("SITEID"), MboConstantsCustom.FORCESET);
			rfqremote.setValue("DESCRIPTION", mboremote.getString("DESCRIPTION"));
			rfqremote.setValue("SHIPTO", mboremote.getString("SHIPTO"));
			rfqremote.setValue("SHIPTOATTN", mboremote.getString("SHIPTOATTN"));
			rfqremote.setValue("REQUIREDDATE", mboremote.getDate("REQUIREDDATE"));
//			Set the Deadline to current date + Opening Duration 
			GregorianCalendar deadline = new GregorianCalendar();
			deadline.setGregorianChange(MXServer.getMXServer().getDate());
			deadline.add(Calendar.DATE, rfqremote.getInt("OPENDURATION"));
			
			rfqremote.setValue("CLOSEONDATE", deadline.getTime(),MboConstantsCustom.DBSET);
			
			//Set Purchase Agent only if the WO DP Buyer is populated
			MboSetRemote prlinesetremote = mboremote.getMboSet("PRLINE");
			MboRemote prline = prlinesetremote.getMbo(0);
			MboSetRemote woset = prline.getMboSet("WORKORDER");
			MboRemote wo = woset.getMbo(0);
			if(!wo.isNull("DPBUYER"))
			{
				rfqremote.setValue("PURCHASEAGENT", wo.getString("DPBUYER"));
				//rfqremote.setValue("PURCHASEAGENT", mboremote.getString("SHIPTOATTN"));
			}
			rfqremote.setValue("PRIORITY", mboremote.getInt("PRIORITY"));
			rfqremote.setValue("REQUESTEDBY", mboremote.getString("REQUESTEDBY"));
			rfqremote.setValue("DESCRIPTION_LONGDESCRIPTION", mboremote.getString("DESCRIPTION_LONGDESCRIPTION"));
			
			int rfqid = rfqremote.getInt("RFQID");
			MboSetRemote rfqvendorsetremote = rfqremote.getMboSet("RFQVENDOR");
			
			if (!mboremote.isNull("bkpvendor"))
			{
				MboRemote rfqvendorremote = rfqvendorsetremote.add(MboConstantsCustom.NOACCESSCHECK);
				rfqvendorremote.setValue("VENDOR", mboremote.getString("BKPVENDOR"),MboConstantsCustom.NOACCESSCHECK);
			}
			
			MboRemote prlineremote;
			MboSetRemote rfqlinesetremote = rfqremote.getMboSet("RFQLINE");
			int j = 0;
			String refwo = null;
			for(int i = 0; (prlineremote = prlinesetremote.getMbo(i)) != null; i ++)
			{
				refwo = prlineremote.getString("refwo");
				if (prlineremote.getString("RFQNUM").equalsIgnoreCase("") && prlineremote.getString("RFQLINENUM").equalsIgnoreCase(""))
				{
					MboRemote rfqlineremote = rfqlinesetremote.add();
					rfqlineremote.setValue("SITEID", rfqremote.getString("SITEID"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("RFQNUM", rfqremote.getString("RFQNUM"));
					rfqlineremote.setValue("LINETYPE", prlineremote.getString("LINETYPE"));
					if(rfqlineremote.getString("LINETYPE").equalsIgnoreCase("ITEM") || rfqlineremote.getString("LINETYPE").equalsIgnoreCase("STDSERVICE"))
						rfqlineremote.setValue("ITEMNUM", prlineremote.getString("ITEMNUM"));
					else
						rfqlineremote.setValue("DESCRIPTION", prlineremote.getString("DESCRIPTION"));
					//Begin modification DR-070	
					rfqlineremote.setValue("DESCRIPTION_LONGDESCRIPTION", prlineremote.getString("DESCRIPTION_LONGDESCRIPTION"));
					//End modification DR-070	
					rfqlineremote.setValue("CONDITIONCODE", prlineremote.getString("CONDITIONCODE"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("REMARK", prlineremote.getString("REMARK"));
					rfqlineremote.setValue("MANUFACTURER", prlineremote.getString("MANUFACTURER"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("MODELNUM", prlineremote.getString("MODELNUM"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("CATEGORY", prlineremote.getString("CATEGORY"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("COMMODITYGROUP", prlineremote.getString("COMMODITYGROUP"));
					rfqlineremote.setValue("COMMODITY", prlineremote.getString("COMMODITY"));
					rfqlineremote.setValue("RECEIPTREQD", prlineremote.getBoolean("RECEIPTREQD"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("INSPECTIONREQUIRED", prlineremote.getBoolean("INSPECTIONREQUIRED"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("ISSUE", prlineremote.getBoolean("ISSUE"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("CHARGESTORE", prlineremote.getBoolean("CHARGESTORE"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("CONVERTTOCONTRACT", prlineremote.getBoolean("CONVERTTOCONTRACT"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("ORDERQTY", prlineremote.getDouble("ORDERQTY"),MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("ORDERUNIT", prlineremote.getString("ORDERUNIT"));
					rfqlineremote.setValue("CONVERSION", prlineremote.getDouble("CONVERSION"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("STORELOC", prlineremote.getString("STORELOC"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("REFWO", prlineremote.getString("REFWO"), MboConstantsCustom.FORCESET);
					rfqlineremote.setValue("GLDEBITACCT", prlineremote.getString("GLDEBITACCT"), MboConstantsCustom.DBSET);
					rfqlineremote.setValue("MRNUM", prlineremote.getString("MRNUM"));
					rfqlineremote.setValue("MRLINENUM", prlineremote.getString("MRLINENUM"));
					rfqlineremote.setValue("REQDELIVERYDATE", prlineremote.getDate("REQDELIVERYDATE"));
					
					prlineremote.setValue("RFQNUM", rfqlineremote.getString("RFQNUM"), MboConstantsCustom.FORCESET);
					prlineremote.setValue("RFQLINENUM", rfqlineremote.getString("RFQLINENUM"), MboConstantsCustom.FORCESET);
					prlinesetremote.save();
					j++;
				}
			}

	
//			Begin modification 
			//Getting the details from doclinks table with wonum which was obtained from PRLine
			MboSetRemote woSet = MXServer.getMXServer().getMboSet("WORKORDER", mboremote.getUserInfo());
			SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "wonum = :1 and siteid = :2");
			sqlformat.setObject(1, "WORKORDER", "WONUM", refwo);
			sqlformat.setObject(2, "WORKORDER", "SITEID", mboremote.getString("siteid"));
			woSet.setWhere(sqlformat.format());
			MboSetRemote doclinkset = woSet.getMbo(0).getMboSet("DOCLINKS");
			//addAttachments(doclinkset,rfqid);
			
			//Getting the details from WPMATERIAL for the processing WO
			MboSetRemote wpmaterialset = woSet.getMbo(0).getMboSet("WPMATERIAL");
			MboRemote wpmaterial = wpmaterialset.getMbo(0); 
//			End modification 
						

			if (j != 0)
			{
				rfqsetremote.save();
				rfqlinesetremote.save();
				addAttachments(doclinkset,rfqid);
//				Antoine
				//Copy from eRFQ only if this PR has an originating eRFQ
				if(!wpmaterial.isNull("ORIGINATINGERFQ"))
					((RFQCustomRemote)rfqremote).copyFromeRFQ();
//				Antoine
			}
			prlinesetremote.close();
			rfqlinesetremote.close();
			rfqvendorsetremote.close();
			rfqsetremote.close();
/*				
//			Display the new RFQ Num in the Appn screen
			Object param[] = {rfqremote.getString("RFQNUM") }; 				
			//MXServer.getMXServer().addWarning(new MXApplicationException("rfq", "newrfqnum"), param);
			MboSet temp = (MboSet)rfqsetremote;
			temp.addWarning(new MXApplicationException("rfq", "newrfqnum", param));*/
		}
	}
	catch (MXException e) 
	{
		e.printStackTrace();
		throw e;
	}
}
//Begin modification 
public void addAttachments(MboSetRemote doclinkset, int rfqid)
throws MXException, RemoteException
{
	try
	{
		MboRemote temp;
		String ownertable="RFQ";
		//Inserting record into doclinks with rfqid as ownerid and RFQ as ownertable
		for(int i=0;(temp=doclinkset.getMbo(i)) != null; i++)
		{
			MboRemote docremote;
			docremote = doclinkset.add();
			docremote.setValue("OWNERID", rfqid);
			docremote.setValue("OWNERTABLE", ownertable);
			docremote.setValue("REFERENCE", temp.getString("REFERENCE"));
			docremote.setValue("DOCTYPE", temp.getString("DOCTYPE"));
			docremote.setValue("DOCVERSION", temp.getString("DOCVERSION"));
			docremote.setValue("PRINTTHRULINK", temp.getInt("PRINTTHRULINK"));
			docremote.setValue("COPYLINKTOWO", temp.getInt("COPYLINKTOWO"));
			docremote.setValue("DOCINFOID", temp.getInt("DOCINFOID"));
			docremote.setValue("DOCUMENT", temp.getString("DOCUMENT"));
/*				System.out.println("-----------------------------------");
			System.out.println("OWNERID: "+ rfqid);
			System.out.println("OWNERTABLE: "+ ownertable);
			System.out.println("REFERENCE: "+ temp.getString("REFERENCE"));
			System.out.println("DOCTYPE: "+ temp.getString("DOCTYPE"));
			System.out.println("DOCVERSION: "+ temp.getString("DOCVERSION"));
			System.out.println("PRINTTHRULINK: "+ temp.getString("PRINTTHRULINK"));
			System.out.println("COPYLINKTOWO: "+ temp.getString("COPYLINKTOWO"));
			System.out.println("DOCINFOID: "+ temp.getString("DOCINFOID"));
			System.out.println("DOCUMENT: "+ temp.getString("DOCUMENT"));
			System.out.println("-----------------------------------");
*/				doclinkset.save();
		}
		doclinkset.close();
	}
	catch (MXException e) 
	{
		e.printStackTrace();
		throw e;
	}
}
//End modification 
}
