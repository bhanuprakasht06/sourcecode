/*
 * Modification history
 * 21-12-15 WMJ EMS-1012 [GL]New field to indicate if labour should be charged for a cost centre
 */
package com.psa.app.labor;

import java.rmi.RemoteException;
import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOSetRemote;
import psdi.app.workorder.WorkTypeRemote;
import psdi.app.workorder.WorkTypeSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.app.labor.FldLabTransLaborcode;

import psdi.app.labor.LabTrans;
//start of EMS-1012
import psdi.mbo.MboSetRemote;
import psdi.security.UserInfo;
import psdi.mbo.GLFormat;
import psdi.app.financial.GLComponentsRemote;
import psdi.app.financial.GLComponentsSetRemote;
//end of EMS-1012

public class FldLabTransLaborcodeCustom extends FldLabTransLaborcode
{
  public FldLabTransLaborcodeCustom(MboValue arg0)
    throws MXException, RemoteException
  {
    super(arg0);
  }

  public void action()
    throws MXException, RemoteException
  {
    super.action();

    LabTrans labtrans = (LabTrans)getMboValue().getMbo();

    if (!(labtrans.isNull("refwo")))
    {
      WOSetRemote woSet = (WOSetRemote)MXServer.getMXServer().getMboSet("WORKORDER", labtrans.getUserInfo());
      SqlFormat sqlformat = new SqlFormat(labtrans.getUserInfo(), "wonum = :1 and siteid = :2");
      sqlformat.setObject(1, "WORKORDER", "WONUM", labtrans.getString("refwo"));
      sqlformat.setObject(2, "WORKORDER", "SITEID", labtrans.getString("siteid"));
      woSet.setWhere(sqlformat.format());

      if (!(woSet.isEmpty()))
      {
        WORemote wo = (WORemote)woSet.getMbo(0);
        String woWorkType = wo.getString("WORKTYPE");
        if (woWorkType != null)
        {

          WorkTypeSetRemote worktypeSet = (WorkTypeSetRemote)MXServer.getMXServer().getMboSet("WORKTYPE", labtrans.getUserInfo());

          SqlFormat sqlformatWOType = new SqlFormat(labtrans.getUserInfo(), "worktype = :1 and orgid = :2");
          sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
          sqlformatWOType.setObject(2, "LABTRANS", "ORGID", labtrans.getString("orgid"));
          worktypeSet.setWhere(sqlformatWOType.format());

          if (!(worktypeSet.isEmpty()))
          {
            WorkTypeRemote worktype = (WorkTypeRemote)worktypeSet.getMbo(0);
            boolean noLabCost = worktype.getBoolean("nolabcost");
            if (noLabCost)
            //start of EMS-1012
            {
            	//to get the cost centre of the GL debit account of labtrans 
            	String finalGLAccount = labtrans.getString("GLDEBITACCT");
            	if(!(finalGLAccount.equals(null) || finalGLAccount.equals("")) ){
	            	MXServer mxserver = MXServer.getMXServer();
                	MboSetRemote glconfigureset = mxserver.getMboSet("GLCONFIGURE", labtrans.getUserInfo());
                	String gldelimiter = glconfigureset.getMbo(0).getString("delimiter");
                	String[] glaccountseg = finalGLAccount.split(gldelimiter);
                	
                	//to get the labcost_i  flag of the cost centre of the GL debit account of labtrans 
                	GLComponentsSetRemote glcompSet = (GLComponentsSetRemote)MXServer.getMXServer().getMboSet("GLCOMPONENTS", labtrans.getUserInfo());

			        SqlFormat sqlformatGLComp = new SqlFormat(labtrans.getUserInfo(), "COMPVALUE= :1 and orgid= :2 and GLORDER=3 ");
			        sqlformatGLComp.setObject(1, "GLCOMPONENTS", "COMPVALUE", glaccountseg[3]);
			        sqlformatGLComp.setObject(2, "LABTRANS", "ORGID", labtrans.getString("orgid"));
			        glcompSet.setWhere(sqlformatGLComp.format());
			        
			        GLComponentsRemote GLComp = (GLComponentsRemote)glcompSet.getMbo(0);
			        boolean CCLabCost = GLComp.getBoolean("LABCOST_I");
			        
			        // set payrate to be zero  if LABCOST_I flag is 0
                	if(!CCLabCost)
                	{
            //end of EMS-1012
              			labtrans.setValue("payrate", 0, 2);
              	
            //start of EMS-1012
          			}
         		}
     		}
         	//end of EMS-1012
          }
        }
      }
    }
  }
}
