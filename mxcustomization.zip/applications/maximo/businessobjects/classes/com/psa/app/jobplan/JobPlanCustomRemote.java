package com.psa.app.jobplan;

import psdi.app.jobplan.JobPlanRemote;

public interface JobPlanCustomRemote extends JobPlanRemote 
{
}
