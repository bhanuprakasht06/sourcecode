/*
 * Modification history
 * 15-10-2007	AGD	eRFQ		Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQLine;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class RFQLineCustom extends RFQLine
implements RFQLineCustomRemote
{

public RFQLineCustom(MboSet rfqlineset)
	throws MXException, RemoteException
{
super(rfqlineset);
}

public void init()
throws MXException
{
super.init();
String as[] = {
        "orderqty"
};
setFieldFlag(as, 7L, true);
return;
}

/*
* Copy the selected lines as alternate quotations
*/
public void copyRFQLinesToQuotationAlt(String vendor)
	throws MXException, RemoteException
{
	// Check required fields
	if (!isNull("storeloc"))
	{
		if (isNull("quotationorderunit"))
		{
			String as[] = { getMboValue("quotationorderunit").getColumnTitle(),
					getString("rfqlinenum") };
			throw new MXApplicationException("rfq", "enterQuotationInfoRequiredForStoreLoc", as);
		}
		if (isNull("conversion"))
		{
			String as1[] = { getMboValue("conversion").getColumnTitle(), getString("rfqlinenum") };
			throw new MXApplicationException("rfq", "enterQuotationInfoRequiredForStoreLoc", as1);
		}
	}
	// Add the alternate quotation and populate the fields
	MboSetRemote altquotationset = getMboSet("QUOTATIONALT");
	MboRemote altquotation = altquotationset.add(2L);
	if (!isNull("storeloc") && !isNull("itemnum"))
	{
		SqlFormat sqlformat = new SqlFormat(this, "itemnum=:1 and itemsetid=:2 and location=:3 and siteid=:4 and vendor=:5");
		sqlformat.setObject(1, "inventory", "itemnum", getString("itemnum"));
		sqlformat.setObject(2, "inventory", "itemsetid", getString("itemsetid"));
		sqlformat.setObject(3, "inventory", "location", getString("storeLoc"));
		sqlformat.setObject(4, "inventory", "siteid", getString("siteid"));
		sqlformat.setObject(5, "inventory", "vendor", vendor);
		MboRemote inventory = getMboSet("$inventory", "INVENTORY", sqlformat.format()).getMbo(0);
		if (inventory != null)
			altquotation.setValue("catalogcode", inventory.getString("catalogcode"), MboConstantsCustom.DBSET);
	}
	altquotation.setValue("rfqnum", getString("rfqnum"), MboConstantsCustom.DBSET);
	altquotation.setValue("rfqlinenum", getString("rfqlinenum"), MboConstantsCustom.DBSET);
	altquotation.setValue("vendor", vendor, MboConstantsCustom.DBSET);
	altquotation.setValue("tax1", 0.0D, MboConstantsCustom.DBSET);
	altquotation.setValue("tax2", 0.0D, MboConstantsCustom.DBSET);
	altquotation.setValue("tax3", 0.0D, MboConstantsCustom.DBSET);
	altquotation.setValue("tax4", 0.0D, MboConstantsCustom.DBSET);
	altquotation.setValue("tax5", 0.0D, MboConstantsCustom.DBSET);
	altquotation.setValue("itemnum", getString("itemnum"), MboConstants.NOACCESSCHECK);
	altquotation.setValue("itemsetid", getString("itemsetid"), MboConstants.NOACCESSCHECK);
	altquotation.setValue("description", getString("description"), MboConstantsCustom.DBSET);
	altquotation.setValue("description_longdescription", getString("description_longdescription"), MboConstantsCustom.DBSET);
	altquotation.setValue("linetype", getString("linetype"), MboConstantsCustom.DBSET);
	altquotation.setValue("manufacturer", getString("manufacturer"), MboConstantsCustom.DBSET);
	altquotation.setValue("modelnum", getString("modelnum"), MboConstantsCustom.DBSET);
	altquotation.setValue("orderqty", getString("orderqty"), MboConstantsCustom.DBSET);
	altquotation.setValue("orderunit", getString("quotationorderunit"), MboConstantsCustom.DBSET);
	altquotation.setValue("commodity", getString("commodity"), MboConstantsCustom.DBSET);
	altquotation.setValue("commoditygroup", getString("commoditygroup"), MboConstantsCustom.DBSET);
	altquotation.setValue("conditioncode", getString("conditioncode"), MboConstantsCustom.DBSET);
	altquotation.setValue("memo", getString("remark"), MboConstantsCustom.DBSET);
	altquotation.setValue("memo_longdescription", getString("remark_longdescription"), MboConstantsCustom.DBSET);
	if (altquotation.getString("tax1code") == "")
	{
		SqlFormat sqlformat = new SqlFormat(this, "company = :1");
		sqlformat.setObject(1, "COMPANIES", "company", vendor);
		MboRemote company = getMboSet("$companies", "companies", sqlformat.format()).getMbo(0);
		if (company != null)
		{
			altquotation.setValue("glcreditacct", company.getString("rbniacc"), MboConstantsCustom.DBSET);
			altquotation.setValue("tax1code", company.getString("tax1code"), MboConstants.NOACCESSCHECK);
			altquotation.setValue("tax2code", company.getString("tax2code"), MboConstants.NOACCESSCHECK);
			altquotation.setValue("tax3code", company.getString("tax3code"), MboConstants.NOACCESSCHECK);
			altquotation.setValue("tax4code", company.getString("tax4code"), MboConstants.NOACCESSCHECK);
			altquotation.setValue("tax5code", company.getString("tax5code"), MboConstants.NOACCESSCHECK);
		}
	}
}

}
