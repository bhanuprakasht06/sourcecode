// Decompiled by DJ v3.0.0.63 Copyright 2002 Atanas Neshkov  Date: 8/16/2009 11:04:13 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CustomMboSetRemote.java package

package com.psa.app.packaging;

import psdi.mbo.MboSetRemote;

public interface PackageSetRemote
    extends MboSetRemote
{
}