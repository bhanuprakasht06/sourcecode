/*
 * Created by BCT 
 * 
 * Returning the  Location Mbo object
 * 
 * 
 */
package com.psa.app.location;

import java.rmi.RemoteException;

import psdi.app.location.LocationSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;

public class LocationSetCustom extends LocationSet {

	public LocationSetCustom(MboServerInterface ms) throws MXException,
			RemoteException {
		super(ms);
		
	}
//Returning the LocationCustom Mbo
	protected Mbo getMboInstance(MboSet ms) throws MXException, RemoteException {
		
		return new LocationCustom(ms);
	}

}
