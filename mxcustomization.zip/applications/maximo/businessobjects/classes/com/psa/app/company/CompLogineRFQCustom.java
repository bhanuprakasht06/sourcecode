/*
 * Modification history
 * 28-09-07	AGD	NA		Creation
 */
package com.psa.app.company;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class CompLogineRFQCustom extends Mbo
implements CompLogineRFQCustomRemote
{

public CompLogineRFQCustom(MboSet comploginset)
	throws RemoteException
{
super(comploginset);
}


public void add()
	throws MXException, RemoteException
{
MboRemote company = getOwner();
setValue("orgid", company.getString("orgid"), MboConstants.NOACCESSCHECK);
setValue("company", company.getString("company"), MboConstants.NOACCESSCHECK);
}
}
