/*
 * Modification history
 * 10-04-07	LS	DR-015	Allow editing of WOInterrupt during edit WO history
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.WORemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXAccessException;
import psdi.util.MXException;

public class WOInterruptCustomSet extends MboSet
implements WOInterruptCustomSetRemote
{

public WOInterruptCustomSet(MboServerInterface mboserverinterface) 
throws MXException, RemoteException 
{
	super(mboserverinterface);
}

public void init()
    throws MXException, RemoteException
{
	super.init();
}

protected Mbo getMboInstance(MboSet mboset) 
	throws MXException,	RemoteException 
{
	return new WOInterruptCustom(mboset);
}

public void canAdd()
    throws MXException
{
    try
    {
		WORemote mboremote = (WORemote)getOwner();
    	if(mboremote.getBoolean("historyflag") && !mboremote.isWOInEditHist())
        {
//    		System.out.println("[WOInterruptCustomSet]mboremote owner: " + mboremote.getName());
    		throw new MXAccessException("workorder", "NoAddInterrupt");
        }
		if(mboremote.getDate("ACTSTART") == null)
		{
			throw new MXAccessException("workorder", "NoActStart");
		}
    }
    catch(RemoteException remoteexception)
    {
        throw new MXAccessException("workorder", "NoAdd", remoteexception);
    }
}

}
