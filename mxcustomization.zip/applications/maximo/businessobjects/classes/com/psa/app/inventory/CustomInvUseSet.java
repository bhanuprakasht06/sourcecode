package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.InvUseSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class  CustomInvUseSet extends InvUseSet 
	implements CustomInvUseSetRemote 
{
	public CustomInvUseSet (MboServerInterface mboserverinterface) 
		throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}
	
	protected Mbo getMboInstance(MboSet mboset) 
		throws MXException, RemoteException
	{
		return (new CustomInvUse(mboset));
	}
}
