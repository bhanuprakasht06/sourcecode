/*
 * Modification history
 * 29-10-2007	LS	DR-55		Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;

public class QuotationLineCustomSet extends psdi.app.rfq.QuotationLineSet 
	implements  QuotationLineCustomSetRemote
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QuotationLineCustomSet(MboServerInterface mboserverinterface) 
		throws MXException,	RemoteException 
	{
		super(mboserverinterface);
	}

	protected Mbo getMboInstance(MboSet mboset)
		throws MXException, RemoteException
	{
		return new QuotationLineCustom(mboset);
	}

}
