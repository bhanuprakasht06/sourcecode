/*
 * Modification history
 * 12-04-07	AGD	SR-080	Check for labor report overlap
 * 13-01-2014	WMJ	EMS-666	[LABTRANS]SRADHOCWF Exception when routing a monitored equipment to confirm completion
 */
package com.psa.app.labor;

import java.rmi.RemoteException;

import psdi.app.labor.virtual.FldLabTransStartDateNP;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldLabTransStartDateCustom extends FldLabTransStartDateNP
{

	public FldLabTransStartDateCustom(MboValue arg0)
	{
		super(arg0);
	}


	public void validate()
			throws MXException, RemoteException
	{		
		super.validate();
		
		if (!getMboValue().isNull())
		{
			LabTransCustom labtrans = (LabTransCustom) getMboValue().getMbo();
			//labtrans.checkOverlapForField(true);
			/*if (labtrans.checkOverlapForField(true))
			{
	         getMboValue().setValueNull();
	         labtrans.setValue("linecost", 0, MboConstants.NOACCESSCHECK);
	         labtrans.setValue("linecost2", 0, MboConstants.NOACCESSCHECK);
	         	String param[] = { getMboValue().getColumnTitle() };
				throw new MXApplicationException("system", "fieldvalidationerror", param);
			}*/
			
			//if (!(labtrans.isNull("startdate")))
            //{
	            if(!labtrans.isNull("PSA_OT_FLAG"))
	            {
                    boolean otflag = labtrans.getBoolean("PSA_OT_FLAG");
                    //System.out.println("[DEBUG] OT FLAG from FldLabTransFinishTimeCustom.validate() :-> " + otflag);
                    if (otflag)
                    {
                            //System.out.println("[DEBUG] Proccess OT OverLap Validate Start");
                            labtrans.checkOverlapForOTField(true);
                            //System.out.println("[DEBUG] Proccess OT OverLap Validate End");
                    }
                    else if(!otflag)
                    {
	                    
                    	if(!(labtrans.isNull("startdate")) && !(labtrans.isNull("starttime")) && !(labtrans.isNull("finishdate")) && !(labtrans.isNull("finishtime")))
                    	{
                            //labtrans.checkOverlapForField(true);
                            labtrans.checkOverlap();
                    	}
                	}
            	}
            //}
			
		}
	}

}
