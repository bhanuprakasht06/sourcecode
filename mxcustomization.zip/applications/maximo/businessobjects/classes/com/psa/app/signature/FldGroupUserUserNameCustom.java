package com.psa.app.signature;

import psdi.mbo.MboValue;
import psdi.mbo.Translate;
import psdi.util.MXException;

public class FldGroupUserUserNameCustom extends psdi.app.signature.FldGroupUserUserName
{
	public FldGroupUserUserNameCustom(MboValue mbv)
    	throws MXException
    {
		super(mbv);

	    String[] intStatuses = { "ACTIVE", "BLOCKED" };

	    String extStatuses = getTranslator().toExternalList("MAXUSERSTATUS", intStatuses);
	    setRelationship("MAXUSER", "userid = :userid and status in (" + extStatuses + ")");
	    setListCriteria("status in (" + extStatuses + ")");
    }
}
