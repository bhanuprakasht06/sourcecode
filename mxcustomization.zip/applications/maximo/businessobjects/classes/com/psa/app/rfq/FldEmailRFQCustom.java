/*
 * Modification history
 * 30-06-08	HAM	Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.mbo.CrossOverDomain;
import psdi.mbo.Mbo;
import psdi.mbo.MboValue;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldEmailRFQCustom extends CrossOverDomain

{

	public FldEmailRFQCustom(MboValue mbovalue)
        throws MXException, RemoteException
    {
		super(mbovalue);
    }

	public void action() throws MXException, RemoteException
    {
       
	}
	
	public void validate()
    	throws MXException, RemoteException
     {
		Mbo mbo = getMboValue().getMbo();
		if(mbo.getBoolean("emailrfq"))
		{
			Object param[] = {"E-mail"}; 	
			if (mbo.isNull("email"))
		             throw new MXApplicationException("system", "null",param);
		}	
     }
}

