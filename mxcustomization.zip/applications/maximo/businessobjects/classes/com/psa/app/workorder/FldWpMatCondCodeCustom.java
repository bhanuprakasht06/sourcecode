/*
 * Modification history
 * 05-10-2007	AGD	SR-117	Populate store based on user default store
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.FldWpMatCondCode;
import psdi.mbo.*;
import psdi.util.MXException;


public class FldWpMatCondCodeCustom extends FldWpMatCondCode
{

	public FldWpMatCondCodeCustom(MboValue conditioncodevalue)
			throws MXException
	{
		super(conditioncodevalue);
	}

		public void action()
			throws MXException, RemoteException
	{
		super.action();
		MboValue mbovalue = getMboValue();
		Mbo mbo=getMboValue().getMbo();
   		String itemnum= mbo.getString("ITEMNUM");

		if (mbovalue.isNull() && itemnum != null && itemnum.length() > 2)
		{
			MboRemote mboRemote = getMboValue().getMbo();
			SqlFormat sql = new SqlFormat(mboRemote.getUserInfo(), "itemnum = :1 and conditionenabled = :2");
			sql.setObject(1, "ITEM", "itemnum", itemnum);
			sql.setObject(2, "ITEM", "conditionenabled", "1");
			MboSetRemote  itemConditionSet = ((Mbo)mboRemote).getMboSet("$ITEM", "ITEM", sql.format());
			if (!itemConditionSet.isEmpty())
			{
				mboRemote.setFieldFlag("CONDITIONCODE", 8L, true);
			}
			else
			{
				mboRemote.setFieldFlag("CONDITIONCODE", 8L, false);
			}
		}

	}


	public void validate()
			throws MXException, RemoteException
	{
		super.validate();

		MboValue conditioncodevalue = getMboValue();
		((WPMaterialCustom) conditioncodevalue.getMbo()).checkQty(conditioncodevalue);
	}

}
