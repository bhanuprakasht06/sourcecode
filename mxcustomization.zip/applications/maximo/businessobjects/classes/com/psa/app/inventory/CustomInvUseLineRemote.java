package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.InvUseLineRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public interface CustomInvUseLineRemote extends InvUseLineRemote 
{
	public abstract void copyInvbatchLineSetForReturn(MboSetRemote paramMboSetRemote)
		    throws RemoteException, MXException;
	
	public abstract void copyInvbatchLineSetForTransfer(MboSetRemote paramMboSetRemote)
		    throws RemoteException, MXException;

}
