/*
 * Modification history
 * 28-09-07	AGD	NA		Creation
 */
package com.psa.app.company;

import java.rmi.RemoteException;

import psdi.app.company.Company;
import psdi.app.company.CompanyRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class CompanyCustom extends Company
implements CompanyRemote
{

public CompanyCustom(MboSet companyset)
	throws MXException, RemoteException
{
super(companyset);
}


public void delete(long modifier)
	throws MXException, RemoteException
{
getMboSet("COMPLOGINERFQ").deleteAll(MboConstants.NOACCESSCHECK);
super.delete(modifier);
}
}
