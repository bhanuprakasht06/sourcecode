/*
 * Modification history
 * 02-08-2007	AGD	SR-092	Send email if LD (per save transaction)
 * 16-08-2007	AGD	SR-098	Prevent duplicated packing slips
 * 25-10-2007	AGD	DR-053	Problem saving service receipt with same DO as material receipt, which can be normal
 */
package com.psa.app.common.receipt;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Properties;

import psdi.app.common.receipt.ReceiptMbo;
import psdi.app.inventory.MatRecTransRemote;
import com.psa.app.po.POCustomRemote;
import com.psa.custom.common.ConfigFile;
import com.psa.custom.common.MxEmail;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXApplicationYesNoCancelException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class ReceiptMboCustom extends ReceiptMbo
implements ReceiptMboCustomRemote
{

public ReceiptMboCustom(MboSet thismboset)
	throws MXException, RemoteException
{
super(thismboset);
mboset = thismboset;
}


/*
* Send an email to the PO buyer
* except if the email has already been sent by another receipt within the same transaction
*/
public void emailForLD(MboRemote receipt)
	throws MXException, RemoteException
{
// Ensure that there's only 1 email for 1 click on the Save button
POCustomRemote po = (POCustomRemote) receipt.getOwner();
if (po.getLD())
	return;
po.setLD(true);

// Initializing the configuration file
String paramList[] = { "LDEMAILSUBJECT", "LDEMAILBODY" };
ConfigFile config = new ConfigFile(CFGFILE, paramList);
try
{
	config.readFile();
}
catch (IOException e)
{
	mxLogger.warn("ReceiptMboCustom.emailForLD - Problem reading the configuration file. No email sent despite LD !");
	String[] param = { CFGFILE };
	throw new MXApplicationException("iface", "ioexception", param, e);
}

// Sending the email for LD
mxLogger.debug("ReceiptMboCustom.emailForLD - Sending an email");
MxEmail email = new MxEmail();
Properties properties = MXServer.getMXServer().getConfig();
email.setFromMail(properties.getProperty("mxe.adminEmail", null));
email.setToMail(po.getString("purchaseagentemail.emailaddress"));
email.send(replaceEmailData(config.get("LDEMAILSUBJECT"), po, receipt),
		replaceEmailData(config.get("LDEMAILBODY"), po, receipt));
}


/*
* Replace keywords in the text parameter with actual values
*/
private String replaceEmailData(String text, MboRemote po, MboRemote receipt)
	throws MXException, RemoteException
{
text = text.replaceAll("ponum", po.getString("ponum"));
text = text.replaceAll("vendorname", po.getString("vendor.name"));
text = text.replaceAll("ld", receipt.getString("remark"));
text = text.replaceAll("contractdesc", po.getString("contractref.description"));
if (receipt instanceof MatRecTransRemote)
	// Get store from PO line to avoid to retrieve the holding store in case of inspection
	text = text.replaceAll("storecode", receipt.getString("poline.storeloc"));
else
	text = text.replaceAll("storecode", "N/A");
text = text.replaceAll("storeuser", receipt.getString("enterby"));
text = text.replaceAll("transdate", receipt.getString("transdate"));
text = text.replaceAll("itemnum", receipt.getString("itemnum"));
text = text.replaceAll("itemdesc", receipt.getString("description"));
text = text.replaceAll("packingslip", receipt.getString("packingslipnum"));
text = text.replaceAll("poqty", receipt.getString("poline.orderqty"));
return text;
}


//Begin modification SR-098
/*
* Calls checkDuplicatePackingSlip(String packingslipentered, String vendor, UserInfo userinfo)
*/
//Begin modification DR-053
//public void checkDuplicatePackingSlip(MboValue packingslipmbovalue, String vendor)
public void checkDuplicatePackingSlip(MboValue packingslipmbovalue, String vendor, String ponum)
//End modification DR-053
	throws MXException, RemoteException
{
checkDuplicatePackingSlip(packingslipmbovalue.getString(), vendor, ponum, packingslipmbovalue.getMbo().getUserInfo());
}


/*
* Throws an error if the packing slip entered already exists in a previous material or service receipt
*/
//Begin modification DR-053
//public void checkDuplicatePackingSlip(String packingslipentered, String vendor, UserInfo userinfo)
private void checkDuplicatePackingSlip(String packingslipentered, String vendor, String ponum, UserInfo userinfo)
//End modification DR-053
	throws MXException, RemoteException
{
if (packingslipentered.equals("") || packingslipentered == null)
	return;

MXServer mxserver = MXServer.getMXServer();
boolean isconflict = false;

// Get conflicting existing material receipts
//Begin modification DR-053 - move most of the below code into private methods and change the logic there
MboSetRemote previousreceipts = mxserver.getMboSet("MATRECTRANS", userinfo);
/*		SqlFormat sql = new SqlFormat(genPackingSlipQuery("matrectrans"));
sql.setObject(1, "matrectrans", "packingslipnum", packingslipentered);
sql.setObject(2, "po", "vendor", vendor);*/
//previousreceipts.setWhere(sql.format());
previousreceipts.setWhere(genPackingSlipQuery("matrectrans", packingslipentered, vendor));
//if (!previousreceipts.isEmpty())
//	isconflict = true;
isconflict = isConflict(previousreceipts, ponum);
if (!isconflict)
//else
{
	// Check conflicting existing service receipts
	previousreceipts = mxserver.getMboSet("SERVRECTRANS", userinfo);
/*			sql = new SqlFormat(genPackingSlipQuery("servrectrans"));
	sql.setObject(1, "servrectrans", "packingslipnum", packingslipentered);
	sql.setObject(2, "po", "vendor", vendor);*/
//	previousservreceipts.setWhere(sql.format());
	previousreceipts.setWhere(genPackingSlipQuery("servrectrans", packingslipentered, vendor));
//	if (!previousreceipts.isEmpty())
//		isconflict = true;
	isconflict  = isConflict(previousreceipts, ponum);
}
previousreceipts.close();
//End modification DR-053

if (isconflict)
	throw new MXApplicationException("po", "packingslipalreadyused");
}


//Begin modification DR-053 - Perform the SqlFormat in the method and add required additional parameters
//private String genPackingSlipQuery(String table)
private String genPackingSlipQuery(String table, String packingslipentered, String vendor)
	throws RemoteException, MXException
{
String query = "packingslipnum=:1" 
		+ " AND (SELECT vendor FROM po WHERE ponum=" + table + ".ponum AND siteid=" + table + ".siteid)=:2";
SqlFormat sql = new SqlFormat(query);
sql.setObject(1, table, "packingslipnum", packingslipentered);
sql.setObject(2, "po", "vendor", vendor);
return sql.format();
}
//End modification DR-053
//End modification SR-098


//Begin modification DR-053
/*
* Check for conflict as follows :
* - if ponum is null, there's a conflict
* - otherwise, check all the receipts :
* 	* if at least 1 of the receipts is for a PO that's different from ponum, there's a conflict 
* 	* otherwise, show a warning as this case may be normal (duplicate DO for same PO)
*/
private boolean isConflict(MboSetRemote receipts, String ponum)
	throws RemoteException, MXException
{
if (receipts.isEmpty())
	return false;

// This means the caller is WP --> conflict for sure
if (ponum == null)
	return true;

int i = 0;
for (MboRemote receipt; (receipt = receipts.getMbo(i)) != null; i ++)
{
	if (!receipt.getString("ponum").equals(ponum))	// Found another PO with the same DO --> conflict for sure
		return true;
}

// We found duplicate DO but for the same PO --> need to ask the user whether it's normal
return promptUserForDuplicatePackingSlip();
}


/*
* Ask user if the duplicate DO detected is normal or not
*/
private boolean promptUserForDuplicatePackingSlip()
	throws MXException, RemoteException
{
boolean isconflict = false;
//Check the receiving is done by maximo - 0 or pda - 1 Start
//int i = mboset.count()-1;
/*for (int i=0;i<mboset.count();i++)
{
	System.out.println("testing on pop upA "+ i+" "+mboset.getMbo(i).getString("MATRECTRANSID")+" "+mboset.getMbo(i).getBoolean("ISPDA"));
	System.out.println("testing on pop upB "+ i+" "+mboset.getMbo(i).getString("MATRECTRANSID")+" "+mboset.getMbo(i).isNew());
	
	if(mboset.getMbo().isNew() && mboset.getMbo().getBoolean("ISPDA"))
	{
		return isconflict;
	}
}*/
/*if(mboset.getMbo() instanceof MatRecTransRemote)
{
	if(mboset.getMbo().getBoolean("SAMESLIP"))
	{
		return isconflict;
	}
}*/
if(mboset.getMbo() instanceof MatRecTransRemote)
{
	if(mboset.getMbo().getBoolean("ISPDA"))
	{
		return isconflict;
	}
}
//System.out.println("testing on pop upC "+ getBoolean("ISPDA"));
//End
int userInput = MXApplicationYesNoCancelException.getUserInput("normalDuplicateDO", MXServer.getMXServer(), getUserInfo());

switch (userInput) {
case MXApplicationYesNoCancelException.NULL:
	throw new MXApplicationYesNoCancelException("normalDuplicateDO", "po", "normalduplicatedo");

case MXApplicationYesNoCancelException.YES:
	isconflict = true;
	break;

case MXApplicationYesNoCancelException.NO:
	isconflict = false;
	break;
}
return isconflict;
}
//End modification DR-053
private MboSet mboset;
private static final String CFGFILE = "/opt/psa/rel/config/email/cfg/ldpo.cfg";
private static final MXLogger	mxLogger	= MXLoggerFactory.getLogger("maximo.application.INVENTOR");
}
