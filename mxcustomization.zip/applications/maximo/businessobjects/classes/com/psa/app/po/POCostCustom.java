/*
 * Modified by Comm-IT 
 *  
 * 
 * 
 */
package com.psa.app.po;
 
import java.rmi.RemoteException;

import psdi.app.po.PO;
import psdi.app.po.POCost;
import psdi.app.po.POCostRemote;
import psdi.app.po.POLine;
import psdi.app.po.POLineRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.security.UserInfo;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXMath;

public class POCostCustom extends POCost
  implements POCostRemote
{

	public POCostCustom(MboSet mboset)
			throws MXException, RemoteException
	{
		super(mboset);
	}
	
	
	public void save() throws MXException, RemoteException 
	{   
		MboRemote owner = getOwner();
		double pocost_linecost = getDouble("LINECOST");
		double pocost_percentage = getDouble("percentage"); 
		double pocost_loadedcost = getDouble("loadedcost"); 
		double poline_linecost = owner.getDouble("LINECOST");

		if (owner.getOwner() instanceof PO)
		{
			setValue("linecost",owner.getDouble("linecost"), 2L);
		}
	    super.save();
	}	
}