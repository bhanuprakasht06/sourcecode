/*
 * Created by BCT 
 * 
 * while creating the Asset, Asset code is available in OFAABCKUP,
 *  it will remove the data from OFAABCKUP.
 * 
 * 
 */
package com.psa.app.asset;

import java.rmi.RemoteException;

import psdi.app.asset.Asset;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;

public class AssetCustom extends Asset {

	public AssetCustom(MboSet ms) throws MXException, RemoteException {
		super(ms);
	
	}
// Record will be removed from OFABACKUP Table while save the record
public void save() throws MXException, RemoteException {
		
		super.save();
	
		MboSetRemote ofa_backMboSet=MXServer.getMXServer().getMboSet("OFABACKUP",getUserInfo());
		SqlFormat deleteOfa=new SqlFormat("LOCATION='"+getString("ASSETNUM")+"'");
		ofa_backMboSet.setWhere(deleteOfa.format());
		ofa_backMboSet.reset();
		if(!ofa_backMboSet.isEmpty() && ofa_backMboSet!=null)
		{
			ofa_backMboSet.deleteAll();
			ofa_backMboSet.save();
		}
	}
	

}
