/*
 * Modification history
 * 27-06-2007	AGD	DR-034	Copy packing slip from WO based on PR line, not on line description
 * 14-11-2007	AGD	DR-053	Prevent duplicate check on packing slip and thereby avoid repeated warnings
 */
package com.psa.app.labor;

import java.rmi.RemoteException;

import psdi.app.labor.FldServRecTransWonum;
import psdi.app.labor.ServRecTrans;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboValue;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldServRecTransWonumCustom extends FldServRecTransWonum
{

	public FldServRecTransWonumCustom(MboValue mbovalue)
			throws MXException, RemoteException
	{
		super(mbovalue);
	}


	public void action()
			throws MXException, RemoteException
	{
		ServRecTrans servrectrans = (ServRecTrans) getMboValue().getMbo();
		if (!servrectrans.getString("wonum").equals(""))
		{
			MboRemote wpitem = servrectrans.getMboSet("POLINE").getMbo(0).getMboSet("WPITEM_RECEIPT").getMbo(0);
			if(wpitem == null)
			{
				Object param[] = { servrectrans.getString("Description") };
				throw new MXApplicationException("po", "nonstocknotvalid", param);
			}
//Begin modification DR-053
//			servrectrans.setValue("packingslipnum", wpitem.getString("donum"));
			servrectrans.setValue("packingslipnum", wpitem.getString("donum"), MboConstants.NOVALIDATION);
//End modification DR-053
		}
		super.action();
	}

}
