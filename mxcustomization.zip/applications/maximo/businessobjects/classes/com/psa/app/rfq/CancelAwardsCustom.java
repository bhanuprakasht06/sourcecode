/*
 * Modification history
 * 17-10-2007	AGD	eRFQ	Creation
 * 29-01-2009	HMD	DR 67	Set Isawarded to False with NO VALIDATION 
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.common.action.ActionCustomClass;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;


public class CancelAwardsCustom
implements ActionCustomClass
{

public CancelAwardsCustom()
{
}


public void applyCustomAction(MboRemote rfq, Object param[])
	throws MXException, RemoteException
{
// Clear the quotations data (note that Maximo clears the RFQ lines data at this time)
MboSetRemote quotes = rfq.getMboSet("quotationlineall");
clearQuotes(quotes);
quotes.close();
}


/*
* Clear the Award checkbox for all the quotation lines of the set passed in parameter
*/
private void clearQuotes(MboSetRemote quotations)
	throws MXException, RemoteException
{
int i = 0;
for (MboRemote quote = null; (quote = quotations.getMbo(i)) != null; i++)
{
	//Begin Modification DR 67
	if (quote.getBoolean("isawarded"))
		//quote.setValue("isawarded", false, MboConstantsCustom.DBSET);
		quote.setValue("isawarded", false, MboConstantsCustom.NOVALIDATION);
	//End Modification DR 67
}
}

}
