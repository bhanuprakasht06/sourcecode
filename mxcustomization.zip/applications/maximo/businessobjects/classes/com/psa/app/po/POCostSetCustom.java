/*
 * Modified by Comm-IT 
 *  
 * 
 * 
 */
package com.psa.app.po;
 
import java.rmi.RemoteException;


import psdi.app.po.POCostSet;
import psdi.app.po.POCostSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;

public class POCostSetCustom extends POCostSet
		implements POCostSetRemote
{

	public POCostSetCustom(MboServerInterface mboserverinterface)
			throws MXException, RemoteException
	{
		super(mboserverinterface);
	}


	protected Mbo getMboInstance(MboSet mboset)
			throws MXException, RemoteException
	{
		return new POCostCustom(mboset);
	}

}
