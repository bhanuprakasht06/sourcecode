/*
 * Modification history
 * 15-10-2007	LES	eRFQ		Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;


public interface RFQCustomRemote
		extends RFQRemote
{
	public abstract void joinVendor()
			throws MXException, RemoteException;

	public abstract void copyeRFQtoWO(MboSetRemote woset)
			throws MXException, RemoteException;
	
	public abstract void copyeRFQtoNewWO(MboSetRemote woset)
			throws MXException, RemoteException;

	public abstract MboSetRemote getWOForRFQ()
			throws MXException, RemoteException;

	public abstract MboSetRemote getRFQForCopy()
			throws MXException, RemoteException;

	public void copyFromRFQ(MboSetRemote refquoteset, String rfqlinenum)
	throws MXException, RemoteException;

	public abstract void copyFromeRFQ()
			throws MXException, RemoteException;
	
	public void setRelatedMboEditibility(String relationship, MboSetRemote mbosetremote)
			throws MXException, RemoteException;

	/*
		 * Copy the quotation data from a set of quotations
		 */
		public void copyDetailsFromRFQ(MboSetRemote refquoteset)
				throws MXException, RemoteException
		;
}
