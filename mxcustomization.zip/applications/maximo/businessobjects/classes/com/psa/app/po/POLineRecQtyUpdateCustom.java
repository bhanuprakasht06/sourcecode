package com.psa.app.po;

import java.rmi.RemoteException;

import psdi.app.po.POLine;
import psdi.app.po.POLineRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboSet;
import psdi.util.MXException;

import psdi.common.action.ActionCustomClass;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.security.UserInfo;
import psdi.server.MXServer;

public class POLineRecQtyUpdateCustom
implements ActionCustomClass
{
public POLineRecQtyUpdateCustom() {
}

public void applyCustomAction(MboRemote mboremote, Object aobj[])
throws MXException, RemoteException
{

	System.out.println("POLineRecQtyUpdateCustom Start");	

	//get the mboset of MATRECTRANS to do a sum of qty receipted:
	MboSetRemote matrectransset = mboremote.getMboSet("MATRECTRANSRECRET");

	int i = 0;//counter
	double recqty = 0;//variable to store total quantity received/returned

	//get actual total quantity received/returned from matrectrans	
	for (MboRemote matrec = null; (matrec = matrectransset.getMbo(i)) != null; i ++)
	{
		recqty = recqty + matrec.getDouble("quantity");
		
	}
	
	//set value for received qty in POLINE
	mboremote.setValue("RECEIVEDQTY",recqty,11L);
	

}
}

/*

--new action to set RECEIVEDQTY=0 when it is negative
--new custom action
--new relationship
--new escalation 
with the following escalation point or condition?:
and poline.RECEIVEDQTY>0
and poline.RECEIPTSCOMPLETE=0

--for new relationship
select * from matrectrans mat, poline where mat.ponum = poline.ponum and mat.polinenum = poline.polinenum 
and belongsto is null and mat.positeid = poline.siteid and 
(
--get all returns
(ISSUETYPE='RETURN') or 
--get all receipts for non inspection
(ISSUETYPE='RECEIPT' and INSPECTIONREQUIRED=0) or 
--get all transfers for inspection
(ISSUETYPE='TRANSFER' and INSPECTIONREQUIRED=1) 
)
;



--for sqlplus testing
select poline.ponum,to_char(poline.polinenum), poline.RECEIVEDQTY, sum(mat.quantity)
from matrectrans mat, poline where mat.ponum = poline.ponum and mat.polinenum = poline.polinenum 
and belongsto is null and mat.positeid = poline.siteid and 
(
--get all returns
(ISSUETYPE='RETURN') or 
--get all receipts for non inspection
(ISSUETYPE='RECEIPT' and INSPECTIONREQUIRED=0) or 
--get all transfers for inspection
(ISSUETYPE='TRANSFER' and INSPECTIONREQUIRED=1) 
)
and poline.RECEIVEDQTY>0
and poline.RECEIPTSCOMPLETE=0
and tostoreloc like '%STORE'
group by poline.ponum,to_char(poline.polinenum), poline.RECEIVEDQTY
having poline.RECEIVEDQTY<>sum(mat.quantity)
;


--for benson

select a.po "PO", a.pol "PO Line", a.itm "Item", a.store "Store",a.RECEIPTSCOMPLETE as "Receipt Complete?", a.polqty "PO Line Received Qty", a.reptqty "Actual Received Qty" from 
(
select l.ponum as po ,to_char(l.polinenum) as pol, l.itemnum as itm, l.STORELOC as store,l.RECEIPTSCOMPLETE,
RECEIVEDQTY as polqty, sum(quantity) as reptqty from 
poline l, matrectrans mat where 
tostoreloc like '%STORE' and 
mat.ponum=l.ponum 
and mat.polinenum=l.polinenum  and mat.ponum is not null
and l.RECEIPTSCOMPLETE=0
and RECEIVEDQTY>0
--and l.enterdate>'01-Jan-2015'
group by l.ponum,to_char(l.polinenum), l.itemnum,l.STORELOC,l.RECEIPTSCOMPLETE,RECEIVEDQTY
order by l.STORELOC,l.itemnum,l.ponum
) a 
where a.polqty<>a.reptqty
order by a.store 
;



*/