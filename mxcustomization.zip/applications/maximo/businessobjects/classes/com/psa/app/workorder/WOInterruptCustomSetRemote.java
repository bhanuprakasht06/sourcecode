package com.psa.app.workorder;

import psdi.mbo.MboSetRemote;

public interface WOInterruptCustomSetRemote 
	extends MboSetRemote 
{
}
