package com.psa.app.workorder;

import java.rmi.RemoteException;

import com.psa.app.labor.LabTransCustomRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class VerifyOTCustom
                implements ActionCustomClass
{

        /*
         * Constructor - does nothing
         */
        public VerifyOTCustom()
        {
        }


        /*
         * Approve all unapproved labor reports
         */
        public void applyCustomAction(MboRemote woremote, Object aobj[])
                        throws MXException, RemoteException
        {
                mxLogger.debug("VerifyOTCustom - Entering");
                System.out.println("VerifyOTCustom - Entering: WO: " + woremote.getString("WONUM") + ": " + MXServer.getMXServer().getDate());

                wo = woremote;

                MboSetRemote labtransset = wo.getMboSet("LABTRANS");
                LabTransCustomRemote labtrans;
                for (int i = 0; (labtrans = (LabTransCustomRemote) labtransset.getMbo(i)) != null; i ++)
                {

                    if (!labtrans.getBoolean("genapprservreceipt") && !labtrans.getBoolean("PSA_OT_FLAG"))
                        labtrans.approveLaborTransaction();

//	                System.out.println("VerifyOTCustom - PSA_VERIFIED before=" + labtrans.getBoolean("PSA_VERIFIED"));
                    if (!labtrans.getBoolean("PSA_VERIFIED") && labtrans.getBoolean("PSA_OT_FLAG"))
                    {        
//	                    System.out.println("VerifyOTCustom before calling LabTransCustomRemote");
                    	labtrans.verifyOTTransaction(false);
                    	//labtrans.setValue("PSA_VERIFIED",1);
                        //labtrans.setValue("PSA_VERIFIED", true, 11L);
                        //labtrans.setValue("PSA_VERIFIEDBY", getUserInfo().getPersonId(), 11L);
                        //labtrans.setValue("PSA_VERIFIEDBY", getUserInfo().getUserName(), MboConstantsCustom.DBSET);
			            //labtrans.setValue("PSA_VERIFIEDDATE", MXServer.getMXServer().getDate(), 11L);
                    }
						
//                  System.out.println("VerifyOTCustom - PSA_VERIFIED after=" + labtrans.getBoolean("PSA_VERIFIED"));
                }
//                labtransset.save();
                labtransset.close();

                mxLogger.debug("VerifyOTCustom - Leaving");
                System.out.println("VerifyOTCustom - Leaving: WO: " + woremote.getString("WONUM") + ": " + MXServer.getMXServer().getDate());

        }

        private MboRemote                       wo;
        private static final MXLogger   mxLogger        = MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}

