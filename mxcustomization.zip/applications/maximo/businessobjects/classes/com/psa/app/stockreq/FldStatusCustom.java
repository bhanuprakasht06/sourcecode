/*
 * Modification history
 * 13-06-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.RemoteException;
import java.util.Date;

import psdi.mbo.MboRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.server.MXServer;
import psdi.util.MXException;

public class FldStatusCustom extends MboValueAdapter
{

    public FldStatusCustom(MboValue mbovalue)
        throws MXException, RemoteException
    {
        super(mbovalue);
    }

    public void action()
    	throws MXException, RemoteException
    {
    	MboRemote mboRemote = getMboValue().getMbo();
    	String status = mboRemote.getString("status");
    	Date currentDate = MXServer.getMXServer().getDate();
    	if (status.equalsIgnoreCase("WIMSCFM"))
    	{
    		mboRemote.setValue("APPROVERNAME", mboRemote.getUserName(), 2L);    
    		mboRemote.setValue("APPROVEDDATE", currentDate, 2L);    		
    	}
    	if (status.equalsIgnoreCase("CLOSED"))
    	{   		
    		mboRemote.setValue("HISTORYFLAG", true, 11L);    		
    	}    	  	
    }
}