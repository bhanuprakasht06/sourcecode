package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.WORemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.custapp.CustomMbo;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class WOSkillsetCustom extends CustomMbo 
	implements WOSkillsetCustomRemote 
{
	public WOSkillsetCustom (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void init() 
			throws MXException 
	{
		super.init();
		MboRemote WORemote = getOwner();         
		try 
		{
			if ((WORemote == null) || (!(WORemote instanceof WORemote))) 
				return;
			
			String staff_readonly[] = {"MIN_STAFF_N","MAX_STAFF_N","EXACT_STAFF_N"};
			
			if (isNew())
			{
				setFieldFlag("SKILLSET_C", MboConstants.READONLY, false);
				setFieldFlag("SKILLSET_C", MboConstants.REQUIRED, true);
				setFieldFlag(staff_readonly, MboConstants.READONLY, true);
			}
			else
				setFieldFlag("SKILLSET_C", MboConstants.READONLY, true);
			
			
			if (toBeAdded())
				return;
			
			if (getBoolean("MIN_SKILLSET_REQUIRED_I_BLN"))
			{
				setFieldFlag("MIN_STAFF_N", MboConstants.READONLY, false);
				setFieldFlag("MIN_STAFF_N", MboConstants.REQUIRED, true);
				setFieldFlag("ALL_STAFF_I_BLN", MboConstants.READONLY, true);
			}
			else
			{
				setFieldFlag("MIN_STAFF_N", MboConstants.READONLY, true);
				setFieldFlag("MIN_STAFF_N", MboConstants.REQUIRED, false);
				setFieldFlag("ALL_STAFF_I_BLN", MboConstants.READONLY, false);
			}
			
			if (getBoolean("MAX_SKILLSET_REQUIRED_I_BLN"))
			{
				setFieldFlag("MAX_STAFF_N", MboConstants.READONLY, false);
				setFieldFlag("MAX_STAFF_N", MboConstants.REQUIRED, true);
				setFieldFlag("ALL_STAFF_I_BLN", MboConstants.READONLY, true);
			}
			else
			{
				setFieldFlag("MAX_STAFF_N", MboConstants.READONLY, true);
				setFieldFlag("MAX_STAFF_N", MboConstants.REQUIRED, false);
				setFieldFlag("ALL_STAFF_I_BLN", MboConstants.READONLY, false);
			}
			
			if (getBoolean("EXACT_SKILLSET_REQUIRED_I_BLN"))
			{
				setFieldFlag("EXACT_STAFF_N", MboConstants.READONLY, false);
				setFieldFlag("EXACT_STAFF_N", MboConstants.REQUIRED, true);
				setFieldFlag("ALL_STAFF_I_BLN", MboConstants.READONLY, true);
			}
			else
			{
				setFieldFlag("EXACT_STAFF_N", MboConstants.READONLY, true);
				setFieldFlag("EXACT_STAFF_N", MboConstants.REQUIRED, false);
				setFieldFlag("ALL_STAFF_I_BLN", MboConstants.READONLY, false);
			}
			
			String allstaff_readonly[] = {"MIN_SKILLSET_REQUIRED_I_BLN","MIN_STAFF_N","MAX_SKILLSET_REQUIRED_I_BLN","MAX_STAFF_N","EXACT_SKILLSET_REQUIRED_I_BLN","EXACT_STAFF_N"};
			if (getBoolean("ALL_STAFF_I_BLN"))
				setFieldFlag(allstaff_readonly, MboConstants.READONLY, true);
			String WOStatus = WORemote.getString("STATUS");
			String allreadonly[] = {"SKILLSET_C","SKILLTYPE_C","ALL_STAFF_I_BLN","MIN_SKILLSET_REQUIRED_I_BLN","MIN_STAFF_N","MAX_SKILLSET_REQUIRED_I_BLN","MAX_STAFF_N","EXACT_SKILLSET_REQUIRED_I_BLN","EXACT_STAFF_N"};
			
			if (WOStatus.equalsIgnoreCase("WPLSCH") || WOStatus.equalsIgnoreCase("WPLSCH-PRG")  || WOStatus.equalsIgnoreCase("WAPPR")  || WOStatus.equalsIgnoreCase("WSCH"));
			//if (getTranslator().toInternalString("WOSTATUS", getString("STATUS")).equals("WAPPR") || getTranslator().toInternalString("WOSTATUS", getString("STATUS")).equals("WSCH"));
			else
				setFieldFlag(allreadonly, MboConstants.READONLY, true);
			
		} 
		catch (RemoteException e) 
		{
			e.printStackTrace();
		}	
	}

	public void add() 
		throws MXException, RemoteException 
	{
		super.add();
		setValue("all_staff_i_bln", false, 11L);
		setValue("exact_skillset_required_i_bln", false, 11L);
		setValue("min_skillset_required_i_bln", false, 11L);
		setValue("max_skillset_required_i_bln", false, 11L);
	}
	
	public void save() 
		throws MXException, RemoteException 
	{
		super.save();
	}
	
	
	public void canDelete()
	    throws MXException, RemoteException
	{
		MboRemote WORemote = getOwner();
		String WOStatus = WORemote.getString("STATUS");
		if (WOStatus.equalsIgnoreCase("WPLSCH") || WOStatus.equalsIgnoreCase("WPLSCH-PRG")  || WOStatus.equalsIgnoreCase("WAPPR")  || WOStatus.equalsIgnoreCase("WSCH"));
        else
        	throw new MXApplicationException("jspmessages", "table_cannotdelete");
	}
}
