/**
 * @author	HCHA
 * Date		Jun 14, 2006
 * Comment	 
 */
package com.psa.app.labor;

import java.rmi.RemoteException;
import psdi.util.MXException;
import psdi.mbo.*;
import psdi.app.labor.*;

/**
 * @author		HCHA
 * @class		LaborCraftRateCustomSet
 * @date		Jun 14, 2006
 * @function	
 */
public class LaborCraftRateCustomSet extends LaborCraftRateSet 
	implements LaborCraftRateSetRemote
{
    public LaborCraftRateCustomSet(MboServerInterface mboserverinterface)
    throws MXException, RemoteException
    {
    	super(mboserverinterface);
    }
    
    protected Mbo getMboInstance(MboSet mboset)
    	throws MXException, RemoteException
    {
    	return new LaborCraftRateCustom(mboset);
    }
    
}
