package com.psa.app.user;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import com.psa.custom.common.MxEmail;
import com.psa.custom.ois.MxLog;

public class UserRoleMappingCronCustom extends SimpleCronTask

{
	private MxEmail email;
	private String emailSubj;
	private MXLogger logger;
	private MxLog mxLog;
	private String logFilePath;
	private UserInfo userInfo;
	private MXServer mxserver;
	String[] arrParams = new String[3]; 
	private MboSetRemote mapset ;
	private String[] keys ;
	private Integer key;
	private String role;
	private String personadded;
	private List<String> comparelist;
	private String [] groupspresent;
	private MboSetRemote groupuserset;
	private String username;
	boolean all;
	private MboSetRemote personset; 
	private MboSetRemote persongroupset; 
	private MboSetRemote persongroupteamset;
	private Hashtable<Integer, String> mapwithsection = new Hashtable<Integer,String>();
	private HashMap<Integer, String>  mapwithsectionval = new HashMap(mapwithsection);
	private Hashtable<Integer, String> mapwithoutsection = new Hashtable<Integer,String>();
	private HashMap<Integer, String>  mapwithoutsectionval = new HashMap(mapwithoutsection);


	public UserRoleMappingCronCustom()
	{
		logFilePath = null;
		userInfo = null;
		logger = MXLoggerFactory.getLogger("maximo.application.USER");
	    emailSubj = null;
}

public void init()throws MXException
{
	super.init();
	email = new MxEmail();
	mxLog = new MxLog();

}

public void start()
{
	try
	{
		super.start();
		logger.info((new StringBuilder(String.valueOf(getName()))).append(" Start").toString());
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" Start").toString());
			cacheResources();
			setSleepTime(0L);
		
	}
	catch(Exception e)
	{
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
	}
}

/*public void stop()
{
	logger.info((new StringBuilder(String.valueOf(getName()))).append(" Stop").toString());
	if(//mxLog.isEnabled())
		try
	{
			//mxLog.writeLog("Stopping crontask");
			//mxLog.closeLogFile();
	}
	catch(Exception e)
	{
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
	}
}*/

public CrontaskParamInfo[] getParameters() throws MXException,RemoteException
{
	CrontaskParamInfo parameters[] = new CrontaskParamInfo[3];
	parameters[0] = new CrontaskParamInfo();
	parameters[0].setName("emailto");
	parameters[0].setDescription("CommonCron", "Adminemailaddress");
	parameters[1] = new CrontaskParamInfo();
	parameters[1].setName("alertemailsubj");
	parameters[1].setDescription("CommonCron", "EmailSubject");	    
	parameters[2] = new CrontaskParamInfo();
	parameters[2].setName("logfile");
	parameters[2].setDescription("CommonCron", "LogDirectory");
	return parameters;
}

public void cacheResources() 
{
	try
	{ 
		arrParams[0] = getParamAsString("emailto");
		arrParams[1] = getParamAsString("alertemailsubj");
		arrParams[2] = getParamAsString("logfile");
	}

	catch(Exception e)
	{
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
		
	}

}
@Override
public void cronAction() 
{
	try
	{
		logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Start of CronTask action").toString());
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" Start of CronTask action").toString());
		//mxLog.writeLog("Started Cron Action "+String.valueOf(getName()));
		System.out.println("Parameter Check :"+parameterCheck(arrParams));
		if(parameterCheck(arrParams))
		{
		if(readConfig())
			{
				if(processData())
				{
					if(all)
					{
						System.out.println("Data Processed Successfully, Check Logs For Trace");
						logger.info("Data Processed Successfully, Check Logs For Trace");
						mxLog.writeLog("Data Processed Successfully, Check Logs For Trace");
					}
					else
					{
						throw new Exception("Error While Processing Data, Some Data may not be updated, Check Logs For Error");
					}
				
				}
				else
				{
					throw new Exception("Error While Processing Data, Check Logs For Error");	
				}
				
			}
		else
		{
			throw new Exception("Error While Configuring Logging and Email, Check Logs For Error");
		}
		}
		else
		{
			throw new Exception("Some Parameter Values are left blank , please fill values.");
		}
		logger.debug((new StringBuilder(String.valueOf(getName()))).append(" End of CronTask action").toString());
		mxLog.writeLog("End Of Cron Task Action");

	}
	catch(Exception e)
	{
		String message = e.getMessage();
		String stack = getStackTrace(e);
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
		if(mxLog.isEnabled())
		{
		mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
		}
		System.out.println("Email Genration : "+genEmail(message, stack));
		logger.info("Email Genration : "+genEmail(message, stack));
		email.send(emailSubj, genEmail(message, stack));
		logger.info((new StringBuilder(String.valueOf(getName()))).append(" Email sent").toString());
		//stop();
	}

}

public boolean processData() throws Exception
	{
	all = true;
	boolean flag = true;	
	try
			{
				if(loadmapping())
					{
					
					System.out.println("Inside If(loadmapping) ");
					logger.info("Inside If(loadmapping) ");
					mxLog.writeLog("Inside If(loadmapping) ");
					boolean groupuserloaded ;
					MboSetRemote urmset = MXServer.getMXServer().getMboSet("MAXUSER", MXServer.getMXServer().getSystemUserInfo());
					persongroupset = MXServer.getMXServer().getMboSet("PERSONGROUP", MXServer.getMXServer().getSystemUserInfo());
					urmset.setWhere("PNUSRROLE is not null" );
					MboRemote urm = urmset.moveFirst();
					for (int k=0; ((urm = urmset.getMbo(k))!= null);k++)
					{
						username = urm.getString("USERID");
						System.out.println("Inside User For Loop "+username);
						logger.info("Inside User For Loop "+username);
						mxLog.writeLog("Inside User For Loop "+username);
						personset = urm.getMboSet("PERSON");
						setvaluenull();				
						groupuserloaded = loadgroupuser(urm);
						System.out.println("Value Of "+groupuserloaded);
						logger.info("Value Of "+groupuserloaded);
						mxLog.writeLog("Value Of "+groupuserloaded);
						role = urm.getString("PNUSRROLE").replaceAll("Engineering - ", "").replaceAll("Engineering � ", "");
						System.out.println("Value Of Role is "+role+" For User "+username);
						logger.info("Value Of Role is "+role+" For User "+username);
						mxLog.writeLog("Value Of Role is "+role+" For User "+username);
						
						if(role.toUpperCase().contains("SECTION"))
						{
							System.out.println("Inside Role With Section");
							logger.info("Inside Role With Section");
							mxLog.writeLog("Inside Role With Section");
							boolean flag3 = false;
							Iterator<Integer> mapwithsectionvaliter = mapwithsectionval.keySet().iterator();
							while(mapwithsectionvaliter.hasNext())
							{
								
								key = mapwithsectionvaliter.next();
								keys = mapwithsectionval.get(key).split("\\,");
								if(checkmapping(1))
								{
									flag3 = true;
									System.out.println("Inside If Check Mapping With Section");
									logger.info("Inside If Check Mapping With Section");
									mxLog.writeLog("Inside If Check Mapping With Section");
									/*System.out.println(username+" Has Section Mapping Found With USER_ROLE_MAPID "+mapset.getMbo().getString("USER_ROLE_MAPID"));
									logger.info(username+" Has Section Mapping Found With USER_ROLE_MAPID "+mapset.getMbo().getString("USER_ROLE_MAPID"));
									*/
									
									if(groupuserloaded) 
									{
										System.out.println("Inside If Group User Loaded "+groupuserloaded);
										logger.info("Inside If Group User Loaded "+groupuserloaded);
										mxLog.writeLog("Inside If Group User Loaded "+groupuserloaded);
										
										if(addsecuritygroups())
										{
											logger.info(" Following Security Groups : "+comparelist+" Added to User : "+username);
											System.out.println(" Following Security Groups : "+comparelist+" Added to User : "+username);
											mxLog.writeLog(" Following Security Groups : "+comparelist+" Added to User : "+username);
										}
										else
										{
											logger.info("Error Adding Security Groups To User : "+username+" Check Logs.");		 
											System.out.println("Error Adding Security Groups To User : "+username+" Check Logs.");		 
											mxLog.writeLog("Error Adding Security Groups To User : "+username+" Check Logs.");		 
											all = false;
										}
									}
				
									else
									{
										logger.info("Error Loading Security Group User's for "+username+" Check log file");                					  
										System.out.println("Error Loading Security Group User's for "+username+" Check log file");                					  
										mxLog.writeLog("Error Loading Security Group User's for "+username+" Check log file");                					  
										all = false;
									}
				
									if(personset.count() == 1)
									{	
										System.out.println("Inside Person Count is 1 ");
										logger.info("Inside Person Count is 1 ");
										mxLog.writeLog("Inside Person Count is 1 ");
										String person = personset.getMbo(0).getString("PERSONID");;
										if(addpersongroups())
										{
											if(personadded != null && personadded != "")	
											{
												logger.info("Person "+person+" Added to Person Groups "+personadded);		 	  
												System.out.println("Person "+person+" Added to Person Groups "+personadded);		 	  
												mxLog.writeLog("Person "+person+" Added to Person Groups "+personadded);		 	  
											}
											else
											{
												logger.info("Person "+person+" Already Exists In Desired Person Group "+mapset.getMbo().getString("PERSON_GROUP"));
												System.out.println("Person "+person+" Already Exists In Desired Person Group "+mapset.getMbo().getString("PERSON_GROUP"));
												mxLog.writeLog("Person "+person+" Already Exists In Desired Person Group "+mapset.getMbo().getString("PERSON_GROUP"));
												all = false;
											}
										}
										else
										{
											logger.info("Error Adding Person "+person+" to Person Groups "+mapset.getMbo().getString("PERSON_GROUP")+" Check Log File For Detail");		 	  	  
											System.out.println("Error Adding Person "+person+" to Person Groups "+mapset.getMbo().getString("PERSON_GROUP")+" Check Log File For Detail");		 	  	  
											mxLog.writeLog("Error Adding Person "+person+" to Person Groups "+mapset.getMbo().getString("PERSON_GROUP")+" Check Log File For Detail");		 	  	  
											
											all = false;
										}
										if(updateperson())
										{
											logger.info("Person Data For Person : "+person+" Update Successfully");		 	  	  
											System.out.println("Person Data For Person : "+person+" Update Successfully");		 	  	  
											mxLog.writeLog("Person Data For Person : "+person+" Update Successfully");		 	  	  
											
										}
										else
										{
											System.out.println("Error Updating Person Data for Person : "+person+" ,Check logs ");
											logger.info("Error Updating Person Data for Person : "+person+" ,Check logs ");
											mxLog.writeLog("Error Updating Person Data for Person : "+person+" ,Check logs ");
											
											all = false;
										}
									}
				
								}
								
							}
							if(!flag3)
							{
								logger.info("No Matching Role Found For "+username);
								System.out.println("No Matching Role Found For "+username);
								mxLog.writeLog("No Matching Role Found For "+username);
								
								all = false;
							}
						}
				
						else
						{
							Iterator<Integer> mapwithoutsectionvaliter = mapwithoutsectionval.keySet().iterator();
							boolean flag3 = false;
							while(mapwithoutsectionvaliter.hasNext())
							{
				
								key = mapwithoutsectionvaliter.next();
								keys = mapwithoutsectionval.get(key).split("\\,");
								if(checkmapping(0))
								{
									flag3 = true;
									System.out.println("Inside If Check Mapping Without Section");
									logger.info("Inside If Check Mapping Without Section");
									mxLog.writeLog("Inside If Check Mapping Without Section");
									
									if(groupuserloaded) 
									{
										System.out.println("Inside If Group User Loaded "+groupuserloaded);
										logger.info("Inside If Group User Loaded "+groupuserloaded);
										mxLog.writeLog("Inside If Group User Loaded "+groupuserloaded);
										
										if(addsecuritygroups())
										{
											logger.info(" Following Security Groups : "+comparelist+" Added to User : "+username);
											System.out.println(" Following Security Groups : "+comparelist+" Added to User : "+username);
											mxLog.writeLog(" Following Security Groups : "+comparelist+" Added to User : "+username);
										}
										else
										{
											logger.info("Error Adding Security Groups To User : "+username+" Check Logs.");		 
											System.out.println("Error Adding Security Groups To User : "+username+" Check Logs.");		 
											mxLog.writeLog("Error Adding Security Groups To User : "+username+" Check Logs.");		 
											all = false;
										}
									}
				
									else
									{
										logger.info("Error Loading Security Group User's for "+username+" Check log file");                					  
										System.out.println("Error Loading Security Group User's for "+username+" Check log file");                					  
										mxLog.writeLog("Error Loading Security Group User's for "+username+" Check log file");                					  
										
										all = false;
									}
				
									if(personset.count() == 1)
									{	
										System.out.println("Inside Person Count is 1 ");
										logger.info("Inside Person Count is 1 ");
										mxLog.writeLog("Inside Person Count is 1 ");
										
										String person = personset.getMbo(0).getString("PERSONID");;
										if(addpersongroups() )
										{
											if(personadded != null && personadded != "")	
											{
												logger.info("Person "+person+" Added to Person Groups "+personadded);		 	  
												System.out.println("Person "+person+" Added to Person Groups "+personadded);		 	  
												mxLog.writeLog("Person "+person+" Added to Person Groups "+personadded);		 	  
												
											}
											else
											{
												logger.info("Person "+person+" Already Exists In Desired Person Group "+mapset.getMbo().getString("PERSON_GROUP"));
												System.out.println("Person "+person+" Already Exists In Desired Person Group "+mapset.getMbo().getString("PERSON_GROUP"));
												mxLog.writeLog("Person "+person+" Already Exists In Desired Person Group "+mapset.getMbo().getString("PERSON_GROUP"));
												
												all = false;
											}
										}
										else
										{
											logger.info("Error Adding Person "+person+" to Person Groups "+mapset.getMbo().getString("PERSON_GROUP")+" Check Log File For Detail");		 	  	  
											mxLog.writeLog("Error Adding Person "+person+" to Person Groups "+mapset.getMbo().getString("PERSON_GROUP")+" Check Log File For Detail");		 	  	  
											System.out.println("Error Adding Person "+person+" to Person Groups "+mapset.getMbo().getString("PERSON_GROUP")+" Check Log File For Detail");		 	  	  
											
											all = false;
										}
										
										if(updateperson())
										{
											logger.info("Person Data For Person : "+person+" Update Successfully");		 	  	  
											System.out.println("Person Data For Person : "+person+" Update Successfully");		 	  	  
											mxLog.writeLog("Person Data For Person : "+person+" Update Successfully");		 	  	  
											
										}
										else
										{
											System.out.println("Error Updating Person Data for Person : "+person+" ,Check logs ");
											logger.info("Error Updating Person Data for Person : "+person+" ,Check logs ");
											mxLog.writeLog("Error Updating Person Data for Person : "+person+" ,Check logs ");
											
											all = false;
										}
				
									}
				
								}
								
							}
							if(!flag3)
							{
								logger.info("No Matching Role Found For "+username);
								System.out.println("No Matching Role Found For "+username);
								mxLog.writeLog("No Matching Role Found For "+username);
							}
				
						}
					}
				
					}
				
				else
					{
						throw new Exception("Error While Loading User Role Mapping , Check Log File For Error Stack Trace");
					}
		}
	catch (Exception e)
		{
		String message = e.getMessage();
		String stack = getStackTrace(e);
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
		mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
		flag = false;
		}
	return flag;
}

public boolean addpersongroups()  
{
	boolean flag;
	try
	{
		mapset.reset();
		mapset.setWhere("USER_ROLE_MAPID = "+Integer.parseInt(keys[0]) );
		mapset.moveFirst();
		System.out.println(username+" Without Section Mapping Found With USER_ROLE_MAPID "+mapset.getMbo().getString("USER_ROLE_MAPID"));
		mxLog.writeLog(username+" Without Section Mapping Found With USER_ROLE_MAPID "+mapset.getMbo().getString("USER_ROLE_MAPID"));
		logger.info(username+" Without Section Mapping Found With USER_ROLE_MAPID "+mapset.getMbo().getString("USER_ROLE_MAPID"));
		String[] pgroups ;
		String where = "";
		MboRemote persongroup;
		if(mapset.getMbo().getString("PERSON_GROUP") != null && !mapset.getMbo().isNull("PERSON_GROUP"))
		{
			System.out.println("PERSON GP Field Is Not null");
			logger.info("PERSON GP Field Is Not null");
			mxLog.writeLog("PERSON GP Field Is Not null");
			where = mapset.getMbo().getString("PERSON_GROUP").replace(",", "','");
			System.out.println("Where Clause '"+where+"'");
			logger.info("Where Clause '"+where+"'");
			mxLog.writeLog("Where Clause '"+where+"'");
			persongroupset.setWhere("PERSONGROUP in ('"+where+"')");
			persongroupset.reset();
			MboRemote m1 = null ;
			boolean flag1 = false;
			for (int k=0; ((persongroup = persongroupset.getMbo(k))!= null);k++)
			{
				persongroupteamset = persongroup.getMboSet("ALLPERSONGROUPTEAM");
				persongroupteamset.setOrderBy("RESPPARTYGROUPSEQ");
				int xx = persongroupteamset.count();
				if(xx > 0)
				{
					m1 = persongroupteamset.getMbo(persongroupteamset.count()-1);
				}
				
				persongroupteamset.setWhere("RESPPARTYGROUP = '"+personset.getMbo(0).getString("PERSONID")+"'");
				persongroupteamset.reset();
				if(persongroupteamset.count() == 0)
				{
					flag1 = true;
					System.out.println("Current Person Do Not Exist, Add Person "+personset.getMbo(0).getString("PERSONID")+" in GP "+persongroup);
					logger.info("Current Person Do Not Exist, Add Person "+personset.getMbo(0).getString("PERSONID")+" in GP "+persongroup);
					mxLog.writeLog("Current Person Do Not Exist, Add Person "+personset.getMbo(0).getString("PERSONID")+" in GP "+persongroup);
					
					if(xx == 0)
					{
						personadded = personadded+","+persongroup.getString("PERSONGROUP");
						if(addperson(1,persongroup.getString("PERSONGROUP")))
						{
							System.out.println("Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							logger.info("Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							mxLog.writeLog("Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							
						}
						else
						{
							System.out.println("Error Adding Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							logger.info("Error Adding Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							mxLog.writeLog("Error Adding Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							
						}

					}
					else if(xx > 0)
					{ 
						personadded = personadded+","+persongroup.getString("PERSONGROUP");
						if(addperson(m1.getInt("RESPPARTYGROUPSEQ")+1,persongroup.getString("PERSONGROUP")))
						{
							System.out.println("Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							logger.info("Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							mxLog.writeLog("Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							
						}
						else
						{
							System.out.println("Error Adding Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							logger.info("Error Adding Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							mxLog.writeLog("Error Adding Person : "+personset.getMbo(0).getString("PERSONID")+" added to Person Group : "+persongroup.getString("PERSONGROUP"));
							
						}

					}
				}
				else
				{
					System.out.println(" Person : "+personset.getMbo(0).getString("PERSONID")+" Already Exists In Person Group : "+persongroup.getString("PERSONGROUP"));
					logger.info(" Person : "+personset.getMbo(0).getString("PERSONID")+" Already Exists In Person Group : "+persongroup.getString("PERSONGROUP"));
					mxLog.writeLog(" Person : "+personset.getMbo(0).getString("PERSONID")+" Already Exists In Person Group : "+persongroup.getString("PERSONGROUP"));
					
				}
			}
			if(flag1)
			{
			System.out.println("Saving Person Group Set");
			logger.info("Saving Person Group Set");
			mxLog.writeLog("Saving Person Group Set");
			persongroupset.save();	 
			}
		}
		else
		{
			logger.info("NO PERSON_GROUPS define in User Role Mapping Application against User Role Map For User : "+username);
			System.out.println("NO PERSON_GROUPS define in User Role Mapping Application against User Role Map For User : "+username);
			mxLog.writeLog("NO PERSON_GROUPS define in User Role Mapping Application against User Role Map For User : "+username);
			
		}
		flag = true;
	}

	catch (Exception e) 
	{
		String message = (new StringBuilder("Problem Adding Person Groups For Person : "+username)).toString();
		String stack = getStackTrace(e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		mxLog.writeLog((new StringBuilder("|--")).append(message).append("\n").append(e.getMessage()).append("\n").append(stack).append(". See log file for details").toString());			
		flag =  false;
	}

	return flag;
}

public boolean addperson(int i,String p) 
{
	boolean flag = true;
	String person = null;
	try
	{
		person = personset.getMbo(0).getString("PERSONID");	
		System.out.println("Inside Add Person , Adding Person "+person+" To GP :"+p+" at Seq "+i);
		logger.info("Inside Add Person , Adding Person "+person+" To GP :"+p+" at Seq "+i);
		mxLog.writeLog("Inside Add Person , Adding Person "+person+" To GP :"+p+" at Seq "+i);
		
		MboRemote m = persongroupteamset.addAtEnd();
		m.setValue("PERSONGROUP", p);
		m.setValue("RESPPARTYGROUP", person);
		m.setValue("CRONADDED", "Y");
		m.setValue("RESPPARTYGROUPSEQ",i);
		
	}
	catch(Exception e)
	{
		String message = (new StringBuilder("Problem Adding Person "+person+" to Person Group "+p)).toString();
		String stack = getStackTrace(e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(stack).append(". See log file for details").toString());
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		mxLog.writeLog((new StringBuilder("|--")).append(message).append("\n").append(e.getMessage()).append("\n").append(stack).append(". See log file for details").toString());			
		flag = false;
	}

return flag;
}

public boolean updateperson() 
{
	boolean flag = true;
	String person = null;
	try
	{
		MboRemote m = personset.getMbo(0);
		person = m.getString("PERSONID");
		MboRemote m1 = mapset.getMbo();
		System.out.println("Inside Add Person , Updating Person "+person);
		logger.info("Inside Add Person , Updating Person "+person);
		mxLog.writeLog("Inside Add Person , Updating Person "+person);
		m.setValue("STO", m1.getString("STO"));
		m.setValue("ENGINEER", m1.getString("ENG"));
		m.setValue("SECTIONHEAD", m1.getString("SH"));
		m.setValue("ENGMANAGER",m1.getString("EM"));
		personset.save();
	}
	catch(Exception e)
	{
		String message = (new StringBuilder("Problem Updating Person "+person)).toString();
		String stack = getStackTrace(e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		mxLog.writeLog((new StringBuilder("|--")).append(message).append("\n").append(e.getMessage()).append("\n").append(stack).append(". See log file for details").toString());			
		flag = false;
	}

return flag;
}

public boolean addsecuritygroups() 
{
	boolean flag;
	try {

		mapset.reset();
		mapset.setWhere("USER_ROLE_MAPID = "+Integer.parseInt(keys[0]) );
		mapset.moveFirst();
		System.out.println(username+" Without Section Mapping Found With USER_ROLE_MAPID "+mapset.getMbo().getString("USER_ROLE_MAPID"));
		logger.info(username+" Without Section Mapping Found With USER_ROLE_MAPID "+mapset.getMbo().getString("USER_ROLE_MAPID"));
		System.out.println(" Count In USER ROLE MAP "+mapset.count());
		System.out.println("Security Groups For This Mapping Are"+mapset.getMbo().getString("SECURITY_GROUPS"));
		logger.info(" Count In USER ROLE MAP "+mapset.count());
		logger.info("Security Groups For This Mapping Are"+mapset.getMbo().getString("SECURITY_GROUPS"));		
		String[] groups ;
		if(mapset.getMbo().getString("SECURITY_GROUPS") != null && !mapset.getMbo().isNull("SECURITY_GROUPS"))
		{
			groups = mapset.getMbo().getString("SECURITY_GROUPS").split("\\,");
			String alreadyadded = "";
			comparelist = new ArrayList(Arrays.asList(groups));
			System.out.println("Security Groups to be added " + comparelist);
			logger.info("Security Groups to be added " + comparelist);
			for (String s : groupspresent) 
			{
				if (comparelist.contains(s)) 
				{
					
					comparelist.remove(s);
					alreadyadded = alreadyadded+","+s;
				} 					            
			}
			boolean flag1 = false;
			if(comparelist.size() != 0)
			{
			flag1 = true;
			for (int i=0;i<comparelist.size();i++) 
			{
				System.out.println("Adding Group "+comparelist.get(i));
				logger.info("Adding Group "+comparelist.get(i));
				MboRemote m = groupuserset.addAtEnd();
				m.setValue("GROUPNAME", comparelist.get(i));
				m.setValue("CRONADDED", "Y");
			}
			}
			else if(alreadyadded != null && alreadyadded != "")
			{
				System.out.println("Following Security Groups"+alreadyadded+"Already Exists for User : "+username);
				logger.info("Following Security Groups"+alreadyadded+"Already Exists for User : "+username);	
			}
			if(flag1)
			{
			System.out.println("Saving GROUPUSER Set");
			logger.info("Saving GROUPUSER Set");			
			groupuserset.save();
			}
		}
		flag = true;
	}


	catch (Exception e) 
	{
		String message = (new StringBuilder("Problem Adding Security Groups For User : "+username)+" , Security Groups To Be Added Are :"+comparelist).toString();
		String stack = getStackTrace(e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		mxLog.writeLog((new StringBuilder("|--")).append(message).append("\n").append(e.getMessage()).append("\n").append(stack).append(". See log file for details").toString());			
		flag =  false;
	}
	return flag;
}

public  boolean checkmapping(int x) throws RemoteException, MXException, SQLException 
{
	boolean match = false;
	if(x==1)
	{
		//logger.info(username+" Role Has Section Checking Mapping ");
		
		match = role.contains(keys[1]) && role.contains(keys[2]) && role.contains(keys[3]); 
		if(match)
		{
		logger.info("ID Match For User "+username+" Is "+keys[0]);
		}
		//logger.info(username+" Value of match "+match );
	}
	if(x==0)
	{
		//logger.info(username+" Role Do not Has Section Checking Mapping ");
		
		match = role.contains(keys[1]) && role.contains(keys[2]);
		if(match)
		{
			logger.info("ID Match For User "+username+" Is "+keys[0]);
		}
		
		//logger.info(username+" Value of match "+match );
	}
	return match;	
}

public boolean loadgroupuser(MboRemote urm) 
{
	boolean flag;
	try {
		System.out.println("Inside loadgroupuser");
		logger.info("Inside loadgroupuser");
		groupuserset = urm.getMboSet("GROUPUSER");
		MboRemote groupuser = groupuserset.moveFirst();
		logger.info("Total Count For Security Groups For User : "+username+" is "+groupuserset.count());
		groupspresent = new String [groupuserset.count()];
		while(groupuser != null)
		{
			groupspresent[groupuserset.getCurrentPosition()] = groupuser.getString("GROUPNAME"); 
			groupuser = groupuserset.moveNext();
		}
		flag = true;
	}

	catch (Exception e) 
	{
		String message = (new StringBuilder("Problem Loading Security Groups For User : "+username)).toString();
		String stack = getStackTrace(e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		mxLog.writeLog((new StringBuilder("|--")).append(message).append("\n").append(e.getMessage()).append("\n").append(stack).append(". See log file for details").toString());			
		flag =  false;
	}
	System.out.println("Exit loadgroupuser");
	logger.info("Exit loadgroupuser");
	return flag;

}

public void setvaluenull() 
{
	System.out.println("Inside Set Value Null");
	logger.info("Inside Set Value Null");
	mxLog.writeLog("Inside Set Value Null");
	keys = null;
	key = null;
	role = null;
	comparelist = null;
	groupspresent = null;
	groupuserset = null;
	groupuserset = null;
	personadded = "";
	System.out.println("Exit Set Value Null");
	logger.info("Exit Set Value Null");
	mxLog.writeLog("Exit Set Value Null");
}

public boolean loadmapping() 
{
	boolean flag = true;
	try 
	{
		System.out.println("Inside loadmapping");
		logger.info("Inside loadmapping");
		mxLog.writeLog("Inside loadmapping");
		mapset = MXServer.getMXServer().getMboSet("USER_ROLE_MAP", MXServer.getMXServer().getSystemUserInfo());
		logger.info("Total No. Of Records In User Role Mapping : "+mapset.count());
		System.out.println("Total No. Of Records In User Role Mapping : "+mapset.count());
		mxLog.writeLog("Total No. Of Records In User Role Mapping : "+mapset.count());
		
		MboRemote map = mapset.moveFirst();
		int i = 0;
		int j = 0;
		while(map != null)
		{
			if(map.isNull("SECTION") || map.getString("SECTION") == null)
			{
				mapwithoutsectionval.put(i,map.getInt("USER_ROLE_MAPID")+","+ map.getString("ROLE")+","+map.getString("SITE").replaceAll("Engineering", "").trim());
				i++;
			}
			else
			{
				mapwithsectionval.put(j, map.getInt("USER_ROLE_MAPID")+","+map.getString("ROLE")+","+map.getString("SITE").replaceAll("Engineering", "").trim()+","+map.getString("SECTION").replaceAll("Engineering", "").replaceAll("Section", "").trim());
				j++;
			}
			map = mapset.moveNext();
		}
		logger.info("Total No. Of Records In User Role Mapping With Section : "+mapwithsectionval.size());
		logger.info("Total No. Of Records In User Role Mapping Without Section : "+mapwithoutsectionval.size());
		System.out.println("Total No. Of Records In User Role Mapping With Section : "+mapwithsectionval.size());
		System.out.println("Total No. Of Records In User Role Mapping Without Section : "+mapwithoutsectionval.size());
		mxLog.writeLog("Total No. Of Records In User Role Mapping With Section : "+mapwithsectionval.size());
		mxLog.writeLog("Total No. Of Records In User Role Mapping Without Section : "+mapwithoutsectionval.size());
	} 
	catch (Exception e) 
	{
		String message = (new StringBuilder("Problem Loading User Roles From User Role Mapping")).toString();
		String stack = getStackTrace(e);
		System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
		mxLog.writeLog((new StringBuilder("|--")).append(message).append("\n").append(e.getMessage()).append("\n").append(stack).append(". See log file for details").toString());
		flag =  false;
	}
	System.out.println("Exit loadmapping");
	logger.info("Exit loadmapping");
	mxLog.writeLog("Exit loadmapping");
	return flag;		
}

public boolean readConfig()
{
	boolean flag = true;
		try
		{
		mxserver = MXServer.getMXServer();
		userInfo = getRunasUserInfo();
		DateFormat fileDateFormat = new SimpleDateFormat("d-MMM-yy HH:mm");
		String runtime = fileDateFormat.format(mxserver.getDate());
		logFilePath = arrParams[2];
		System.out.println("Log File Name : "+logFilePath);
		logger.info("Log File Name : "+logFilePath);
		if(logFilePath != null)
		{
			logFilePath = logFilePath.trim();
			if(logFilePath.equals(""))
			{
				
				logFilePath = null;
			} else
			{
				
				fileDateFormat = new SimpleDateFormat("yyMMddHHmm");
				runtime = fileDateFormat.format(mxserver.getDate());
				logFilePath = logFilePath.replaceAll("yyyymmddhhmm", runtime);
				mxLog.setEnabled(true);
				mxLog.setLogFilePath(logFilePath);
				mxLog.setLogTag(String.valueOf(getName()));
				mxLog.createLogFile();
				
			}
		}
		email.setToMail(arrParams[0]);
		Properties properties = mxserver.getConfig();
		email.setFromMail(properties.getProperty("mxe.adminEmail", null));
		emailSubj = arrParams[1];
		}
		catch(Exception e)
		{
			String message = e.getMessage();
			String stack = getStackTrace(e);
			logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
			logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
			mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
			flag =  false;	
		}
	return flag;
}


public boolean parameterCheck(String []arrParams)
{
	boolean bFlag = true;
	for (int iParamCount = 0; iParamCount < arrParams.length; iParamCount++)	// Iteration on Parameter values
	{
		System.out.println("Parameter is "+iParamCount+ " Value Is @@@@"+arrParams[iParamCount]+"@@@");
		if (arrParams[iParamCount] == null || arrParams[iParamCount].trim().equalsIgnoreCase("") || arrParams[iParamCount].trim() == "") // Check for null parameter values
		{ 
			bFlag = false;
		} 
	}

	return bFlag;
}

public String genEmail(String error, String stack)
{
	String emailMsg = (new StringBuilder("Date: ")).append(new Date()).append("\n").append("Error Message: ").append(error).append("\n").append(stack).toString();
	
	System.out.println("Email Msg  Is : "+emailMsg);
	logger.info("Email Msg Is : "+emailMsg);
	mxLog.writeLog("Email Msg Is : "+emailMsg);
	return emailMsg;
}

public String getStackTrace(Exception e)
{
	String stack = "";
	StackTraceElement element[] = e.getStackTrace();
	for(int i = 0; i < element.length; i++)
		stack = (new StringBuilder(String.valueOf(stack))).append("\tat ").append(element[i].toString()).append("\n").toString();

		//System.out.println("Stack Trace Is : "+stack);
		//logger.info("Stack Trace Is : "+stack);
		//mxLog.writeLog("Stack Trace Is : "+stack);
		return stack;
}
}
