package com.psa.app.po.virtual;

import java.rmi.RemoteException;

import psdi.mbo.MboSet;
import psdi.mbo.NonPersistentMbo;
import psdi.util.MXException;


public class ReceiptInputDOCustom extends NonPersistentMbo
		implements ReceiptInputDOCustomRemote
{

	public ReceiptInputDOCustom(MboSet mboset)
			throws MXException, RemoteException
	{
		super(mboset);
	}


	public void init()
			throws MXException
	{
	}

}
