/**
 * @author	HCHA
 * Date		Oct 12, 2006
 * Comment	 
 */
package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.InvCostSet;
import psdi.app.inventory.InvCostSetRemote;
import psdi.mbo.*;
import psdi.util.MXException;

/**
 * @author		HCHA
 * @class		InvCostCustomSet
 * @date		Oct 12, 2006
 * @function	
 */
public class InvCostCustomSet extends InvCostSet 
	implements InvCostSetRemote 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param arg0
	 * @throws MXException
	 * @throws RemoteException
	 */
	public InvCostCustomSet(MboServerInterface arg0) throws MXException,
			RemoteException {
		super(arg0);
	}
	
    protected Mbo getMboInstance(MboSet mboset)
	    throws MXException, RemoteException
	{
	    return new InvCostCustom(mboset);
	}

}
