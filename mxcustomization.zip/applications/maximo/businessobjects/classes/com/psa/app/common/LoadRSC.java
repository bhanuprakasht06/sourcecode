package com.psa.app.common;


import java.rmi.RemoteException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Properties;
import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import java.io.*;
import java.lang.*;
import java.util.StringTokenizer;
import java.util.regex.*;
import java.util.*;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.mic.MicUtil;
import psdi.server.MXServerRemote;
import psdi.server.SimpleCronTask;
import psdi.util.*;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.iface.load.LoadCronTask;
import psdi.iface.load.RecoveryService;


public class LoadRSC extends SimpleCronTask
{

	public LoadRSC()
	{
		strSrcFolder = null;
        delimiter = null;
		userInfo = null;
		mxserver = null;

	}

	   public void init()
    {
    }

    public void start()
    {
        try
        {
            cacheResources();
           
            setSleepTime(0L);
        }
        catch(Exception e)
        {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(e.getMessage(), e);
        }
    }

    private void cacheResources()
    {
        try
        {
		    mxserver = MXServer.getMXServer();
			java.util.Properties configData = mxserver.getConfig();
			userInfo = getRunasUserInfo();
            strSrcFolder = getParamAsString("SOURCEDIRECTORY");
            delimiter = getParamAsString("DELIMITER");
            if(delimiter != null && delimiter.trim().length() == 0)
                delimiter = ",";
        }
        catch(Exception e)
        {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(e.getMessage(), e);
        }
    }
	public void cronAction()
	    {
	    File dir = new File(strSrcFolder);
        File lstFiles[] = dir.listFiles();
       
            
        List tmpList = Arrays.asList(lstFiles);
        List importList = new ArrayList();
        Iterator itr1 = tmpList.iterator();
        do
        {
            if(!itr1.hasNext())
                break;
            File tFile = (File)itr1.next();
            if(!tFile.isDirectory())
                importList.add(tFile);
        } while(true);
        
        Iterator itr2 = importList.iterator();

        File importFile = (File)itr2.next();
        recoveryService = new RecoveryService(importFile);
        FileInputStream fiStream = null;
		try {
			fiStream = new FileInputStream(importFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                boolean recoveryExists = false;
				try {
					recoveryExists = recoveryService.startRecovery();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                if(recoveryExists)
                {
                    String recLine = null;
					try {
						recLine = recoveryService.readRecoveryUnit();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					System.out.println("****recovery****"+recLine);
					System.out.println("****rec****"+recLine);
				}
        try {
			recoveryService.endRecovery();
			fiStream.close();
			
			System.out.println("****closed rsc****");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }

		   public CrontaskParamInfo[] getParameters()
        throws MXException, RemoteException
    {
        CrontaskParamInfo params[] = new CrontaskParamInfo[2];
        params[0] = new CrontaskParamInfo();
        params[0].setName("DELIMITER");
        params[0].setDefault(MicUtil.getMeaTextDelimiter());
        params[1] = new CrontaskParamInfo();
        params[1].setName("SOURCEDIRECTORY");
		return params;

    }

    private String strSrcFolder;
    private String delimiter;
	private UserInfo userInfo;
	private MXServer mxserver;
	 private RecoveryService recoveryService;
	 private static CrontaskParamInfo params[];
	    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	
}