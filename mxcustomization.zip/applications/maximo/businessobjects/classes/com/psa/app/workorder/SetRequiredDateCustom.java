/*
 * Modification history
 * 10-10-2007	AGD	SR-118	Set the required date of planned items / services to 5 days in the future
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;


public class SetRequiredDateCustom
implements ActionCustomClass
{

public SetRequiredDateCustom()
{
}


public void applyCustomAction(MboRemote woremote, Object param[])
	throws MXException, RemoteException
{
MboSetRemote wpset = woremote.getMboSet("WPITEM");
GregorianCalendar requiredate = new GregorianCalendar();
GregorianCalendar now = new GregorianCalendar();
GregorianCalendar later = new GregorianCalendar();
later.add(Calendar.DATE, days);
int i = 0;
for (MboRemote wp = null; (wp = wpset.getMbo(i)) != null; i ++)
{
	requiredate.setTime(wp.getDate("requiredate"));
	if (requiredate.before(now))
		wp.setValue("requiredate", later.getTime(), MboConstants.READONLY);
}
wpset.close();
}

private static final int days = 5;
}
