/**
01-Jan-2021: BCT modifications for SQL change and Equipment restructure change (Site replacements)
 * 
 */
package com.psa.app.labor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import javax.mail.MessagingException;

import psdi.security.ConnectionKey;

import psdi.app.system.CrontaskParamInfo;
import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.iface.app.interror.MaxIntErrorMsg;
import psdi.iface.app.interror.MaxIntErrorMsgRemote;
import psdi.iface.app.interror.MaxIntErrorMsgSet;
import psdi.iface.app.interror.MaxIntErrorRemote;
import psdi.iface.app.interror.MaxIntErrorSetRemote;
import psdi.iface.jms.MessageUtil;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

/**
 * Custom Cron Task for sending email alerts to ED users for unapproved labour
 * 
 * @author 
 * @param
 * @since 27 Sep 2019
 *
 */
public class UnapprovedLaborAlertCron extends SimpleCronTask {
	
	// Logging
	protected static final MXLogger cronLogger = MXLoggerFactory.getLogger("maximo.crontask.UnapprovedLaborAlertCron");
	private static final String LOG_IDF = " [UnapprovedLaborAlertCron]: ";
	
	// Date Formats
	private static final String DATE_TIME_FORMAT = "dd.MM.yyyy";
	private static final String LOG_DATE_TIME_FORMAT = "yyyyMMdd";
	
	// Static IDs
	
	// Private Attributes

	private String sendFrom;
	private String adminEmail;
	private String adminEmailSub;

	private String commTmpl;
	private String commTmplFinal;
	private int finalReminderDate;
	private String excludeSite;
		
	/**
	 * Constructor for UnapprovedLaborAlertCron
	 */
	public UnapprovedLaborAlertCron() {
		
		super();
		sendFrom = null;
		adminEmail = null;
        adminEmailSub = null;
        commTmpl = null;
        commTmplFinal = null;
        finalReminderDate = 30;
        excludeSite = "XXX";
//      emailSubj = null;
//    	emailBody = null;
    	
	} // End UnapprovedLaborAlertCron()
	
	/**
	 * Override Method for standard Maximo CronTask method for retrieving Cron Task parameters
	 * 
	 * @return params - Array of Cron Task Parameter objects
	 */
	public CrontaskParamInfo[] getParameters() throws MXException, RemoteException {
		
		CrontaskParamInfo[] params = new CrontaskParamInfo[7];

		params[0] = new CrontaskParamInfo();
        params[0].setName("SENDFROM");
        params[0].setDescription("SENDFROM", "Email Address used for sending out emails");
        params[0].setDefault("emsteam_req@psa.com.sg");
        
		params[1] = new CrontaskParamInfo();
        params[1].setName("ADMINEMAIL");
        params[1].setDescription("ADMINEMAIL", "Email Address of system support team");
        params[1].setDefault("emsteam_req@psa.com.sg");
        
		params[2] = new CrontaskParamInfo();
        params[2].setName("ADMINEMAILSUB");
        params[2].setDescription("ADMINEMAILSUB", "Email Subject for Admin Alert Email");
        params[2].setDefault("[PROD] Outstanding Workorder Labour Records for Approval");
               
		params[3] = new CrontaskParamInfo();
        params[3].setName("COMMTEMPLATE");
        params[3].setDescription("COMMTEMPLATE", "Comms�Template�for�sending�email�to�users");
        params[3].setDefault("UNAPPROVEDLABOUR");
               
        params[4] = new CrontaskParamInfo();
        params[4].setName("COMMTEMPLATEFINAL");
        params[4].setDescription("COMMTEMPLATEFINAL", "Comms�Template�for�sending�email�to�users");
        params[4].setDefault("ULABOURFINAL");
        
		params[5] = new CrontaskParamInfo();
        params[5].setName("FINALCUTOFFDATE");
        params[5].setDescription("FINALCUTOFFDATE", "Final Reminder email after this day of month");
        params[5].setDefault("5");
        
      //BCT: Site's are replaced with Location Departments (PSA_DEPARTMENT)
        
        params[6] = new CrontaskParamInfo();
        params[6].setName("EXCLUDESITE");
        params[6].setDescription("EXCLUDESITE", "Site to exclude for email reminder, with quotes. Set XXX if no site is to be excluded");
       // params[6].setDefault("'ECD','BMD','TID','EMED'");       
        params[6].setDefault("'DSD','BMD','TID','ENID'");
		return params;
		
	} // End getParameters()
	
	/**
	 * Reload Cron Task Parameters
	 * 
	 * @throws RemoteException
	 * @throws MXException
	 */
	private void refreshSettings() throws RemoteException, MXException 	{
		
		final String MTD_IDF = "refreshSettings(): ";
		
		try
		{
			
			cronLogger.debug(LOG_IDF + MTD_IDF + " Refreshing Settings ... ");
			
			DateFormat fileDateFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
			String todayDate=fileDateFormat.format(new Date());
			
			sendFrom=getParamAsString("SENDFROM");
			adminEmail=getParamAsString("ADMINEMAIL");
			adminEmailSub=getParamAsString("ADMINEMAILSUB");
	        
	        commTmpl = getParamAsString("COMMTEMPLATE");
	        commTmplFinal = getParamAsString("COMMTEMPLATEFINAL");
	        finalReminderDate = getParamAsInt("FINALCUTOFFDATE");
	        excludeSite = getParamAsString("EXCLUDESITE");
			cronLogger.debug(LOG_IDF + MTD_IDF + "Refresh Settings Completed.");
			
		} catch(Exception e) {
			
			cronLogger.error(LOG_IDF + MTD_IDF + "ERROR: "+e.getMessage());
			e.printStackTrace();
			
		}

	} // End refreshSettings()
	
	/**
	 * Check if all required parameters are set
	 * 
	 * @return FALSE if any parameter not set, TRUE otherwise
	 */
	private boolean isReqParamSet() {
		
		final String MTD_IDF = "isReqParamSet(): ";
		
		if (sendFrom.equalsIgnoreCase("")) return false;
		if (adminEmail.equalsIgnoreCase("")) return false;
		if (adminEmailSub.equalsIgnoreCase("")) return false;
		
		if (commTmpl.equalsIgnoreCase("")) return false;

		cronLogger.debug(LOG_IDF + MTD_IDF + "ALL Required Parameters loaded as below, ");
		
		cronLogger.debug(LOG_IDF + MTD_IDF + "Send Email Using: " + sendFrom);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Admin Email Addr: " + adminEmail);
		cronLogger.debug(LOG_IDF + MTD_IDF + "Admin Email Subject: " + adminEmailSub);
		
		cronLogger.debug(LOG_IDF + MTD_IDF + "Comm Template: " + commTmpl);
		
		// All above have values
		return true;
		
	} // End isReqParamSet()
	
	/**
	 * Send email to Users with specified report as attachment
	 * 
	 * @param toList
	 * @param ccList
	 * @param bccList
	 * @param subj
	 * @param msg
	 */
	private void emailUsers(String toList, String ccList, String bccList, String replyTo, String subj, String msg) {
		
		final String MTD_IDF = "emailUsers(): ";
		
		try {
			
			cronLogger.debug(LOG_IDF + MTD_IDF +"toList: " + toList);
			cronLogger.debug(LOG_IDF + MTD_IDF +"ccList: " + ccList);
			cronLogger.debug(LOG_IDF + MTD_IDF +"bccList: " + bccList);
			cronLogger.debug(LOG_IDF + MTD_IDF +"replyTo: " + replyTo);
			cronLogger.debug(LOG_IDF + MTD_IDF +"subj: " + subj);
			cronLogger.debug(LOG_IDF + MTD_IDF +"msg: " + msg);
								
				cronLogger.debug(LOG_IDF +"Sending email ...");
				
				MXServer.sendEMail(toList, ccList, bccList, sendFrom, subj, msg, replyTo, null, null); 
				
				cronLogger.debug(LOG_IDF + MTD_IDF +"After sending email");
				
						
		} catch (MessagingException e) {
			
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MessagingException: " + e.getMessage());
			
		}
		
	} // End emailUsers(toList, ccList, subj, msg)
	
	/**
	 * Process list of all unapproved labor records across all WO
	 * 
	 * @param 
	 * @throws MessagingException
	 */
	
	public void cronAction() {
		
		cronLogger.info(LOG_IDF + "Processing extractUnapprovedLabor... ");
		
		MXServer mxServer = null;
		ConnectionKey conKey = null;
		Statement stmt1 = null;
		Connection conn = null;
		ResultSet mainResultSet = null;
		ResultSet SHResultSet = null;
		HashMap<String, String> unApprovedWOLaborMap = null;
		
		//SqlFormat laborSql = null;
		//DBShortcut dbShortcut = new DBShortcut();
		
		String laborQuery = null;
		String laborQuerySH = null;
		
		List<String> sectHeadList = null;
		List<String> engManList = null;
		
		try {
			refreshSettings(); 
			
			mxServer = MXServer.getMXServer();
			conKey = mxServer.getSystemUserInfo().getConnectionKey();
			conn = mxServer.getDBManager().getConnection(conKey);
			unApprovedWOLaborMap = new HashMap<String, String>();
			
			stmt1 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);	
			
			//dbShortcut.connect(getRunasUserInfo().getConnectionKey());
			
			laborQuery = "SELECT DISTINCT LT.REFWO, LT.LOCATION, LT.SITEID, LC.SECTHEAD, LC.ENGMANAGER, COUNT(LT.REFWO) as NUMWO " + 
				"FROM LABTRANS LT, LOCATIONS LC " + 
				"where LT.LOCATION = LC.LOCATION " + 
				"and LT.SITEID = LC.SITEID and " + 
				"OA_EXPENDTYPE not in ('CWIPP','ROD') and " + 
				"WORKER_Q is null and " + 
				"STARTDATE >= (select DATEADD(d, 1, EOMONTH(getdate(),-2))) and " + 
				"STARTDATE < (select DATEADD(d, 1, EOMONTH(getdate(),-1))) " + 
				"and GENAPPRSERVRECEIPT <> 1 " + 
				"and PSA_OT_FLAG = 0 " + 
				"and LC.PSA_DEPARTMENT not in (:exSite) " + 
				"group by LT.REFWO, LT.LOCATION, LT.SITEID, LC.SECTHEAD, LC.ENGMANAGER " + 
				"order by LC.SECTHEAD, LT.LOCATION";
				
			laborQuerySH = "SELECT DISTINCT LT.REFWO, LT.LOCATION, LT.SITEID, LC.SECTHEAD, LC.ENGMANAGER, COUNT(LT.REFWO) as NUMWO " + 
				"FROM LABTRANS LT, LOCATIONS LC " + 
				"where LT.LOCATION = LC.LOCATION " + 
				"and LT.SITEID = LC.SITEID and " + 
				"OA_EXPENDTYPE not in ('CWIPP','ROD') and " + 
				"WORKER_Q is null and " + 
				"STARTDATE >= (select DATEADD(d, 1, EOMONTH(getdate(),-2))) and " + 
				"STARTDATE < (select DATEADD(d, 1, EOMONTH(getdate(),-1))) " + 
				"and GENAPPRSERVRECEIPT <> 1 " + 
				"and PSA_OT_FLAG = 0 " + 
				"and LC.PSA_DEPARTMENT not in (:exSite) " + 
				"and LC.SECTHEAD = ':id' " + 
				"group by LT.REFWO, LT.LOCATION, LT.SITEID, LC.SECTHEAD, LC.ENGMANAGER " + 
				"order by LC.SECTHEAD, LT.LOCATION";
			
			laborQuery = laborQuery.replaceFirst(":exSite", excludeSite);
			laborQuerySH = laborQuerySH.replaceFirst(":exSite", excludeSite);
			
			//laborSql=new SqlFormat(laborQuery);
			//mainResultSet = dbShortcut.executeQuery(laborSql.format());
			mainResultSet = stmt1.executeQuery(laborQuery);
			sectHeadList = new ArrayList<String>();
			engManList = new ArrayList<String>();
			String sectHead = "";
			String engMan = "";
			//String refWO = "";
			//String location = "";
			//String siteID = "";
			//String numWO = "";
			int size= 0;  
			if (mainResultSet!= null) {
				mainResultSet.beforeFirst();  
				mainResultSet.last();  
				size = mainResultSet.getRow();  
				//set cursor back to first row
				mainResultSet.first();
			}
			cronLogger.info("mainResultSet size: " + size);
			if (mainResultSet!= null) { 
				for (int i=0; i< size; i++) {
					sectHead = mainResultSet.getString("SECTHEAD");
					engMan = mainResultSet.getString("ENGMANAGER");
					if (!sectHeadList.contains(sectHead)) {
						sectHeadList.add(sectHead);
						engManList.add(engMan);
					}
					/*if (!engManList.contains(engMan)) {
						engManList.add(engMan);
					}*/
					mainResultSet.next();
				}
				//set cursor back to first row
				mainResultSet.beforeFirst();  
			}
			
			//Test print
			for (int i=0; i<sectHeadList.size(); i++) {
				cronLogger.info("Sect Head: " + sectHeadList.get(i));
			}
			for (int i=0; i<engManList.size(); i++) {
				cronLogger.info("Eng Man: " + engManList.get(i));
			}
			
			//Check if cron task is triggered after the final cut off date.
			SimpleDateFormat dtf = new SimpleDateFormat("dd");
			Date date = new Date();
			String todayDate = dtf.format(date);
			
			int today = Integer.parseInt(todayDate);
			//If cron task is triggered after final cut off(i.e. Final Reminder)
			if (today > finalReminderDate) {
				//If there are any unapproved WO labour record
				if (size > 0) {
				unApprovedWOLaborMap = printDataInSet(unApprovedWOLaborMap, mainResultSet);
				prepareSendEmailFinalReminder(unApprovedWOLaborMap);
				unApprovedWOLaborMap.clear();
				}
			} else {
				//for every distinct SectHead, run a second query to list all the WOs belonging to the SectHead
				int finalSize = sectHeadList.size();
				cronLogger.info("sectHeadList size: " + finalSize);
				String laborQuerySHtemp = "";
				for (int i=0; i<finalSize; i++) {
				
					laborQuerySHtemp = laborQuerySH.replaceFirst(":id", sectHeadList.get(i));
				
					SHResultSet = stmt1.executeQuery(laborQuerySHtemp);
					unApprovedWOLaborMap = printDataInSet(unApprovedWOLaborMap, SHResultSet);
				
					/*
					if (sectHeadList.get(i).equals(mainResultSet.getString("SECTHEAD"))) {
					//Print the list of all WO under that sect head under a method
					printDataInSet(unApprovedWOLaborMap, mainResultSet,sectHeadList.get(i),engManList.get(i));
					}*/
					prepareSendEmail(unApprovedWOLaborMap, sectHeadList.get(i),engManList.get(i));
					unApprovedWOLaborMap.clear();
				}
			}
		}
		catch (Exception e) 
		{
			if (cronLogger.isErrorEnabled()) 
			{
				cronLogger.error("Cron action failed");
				cronLogger.error(e);
			}
		} 
		finally 
		{
			try 
			{
				cronLogger.info("Closing connection...");
				System.out.println("Closing connection...");
				mainResultSet.close();
				mainResultSet = null;
				SHResultSet.close();
				SHResultSet = null;
				//priorityResultSet.close();
				stmt1.close();
				//stmt2.close();
				conn.close();
				
				//laborSql = null;
				laborQuery = null;
				laborQuerySH = null;
				
				unApprovedWOLaborMap = null;
				
				//dbShortcut.close();
				//dbShortcut = null;
			} 
			catch (SQLException e) 
			{
				if (cronLogger.isErrorEnabled()) 
				{
					cronLogger.error("Cron action failed");
					cronLogger.error(e);
				}
			}
		}
	}
	
	private HashMap<String, String> printDataInSet(HashMap<String, String> map, ResultSet ResultSet) {
		
		String refWO = "";
		String location = "";
		String siteID = "";
		String numWO = "";
		try {
			while (ResultSet.next()) {
				refWO = ResultSet.getString("REFWO");
				location = ResultSet.getString("LOCATION");
				siteID = ResultSet.getString("SITEID");
				numWO = ResultSet.getString("NUMWO");
				cronLogger.info("---Details: " + refWO + " " + location + " " + siteID + " " + numWO);
				System.out.println("---Details: " + refWO + " " + location + " " + siteID + " " + numWO);
				map.put(refWO,"WO: "+ refWO+", Location: "+location + ", Unapproved Labour: " + numWO);
				//ResultSet.next();
			}
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			cronLogger.error(LOG_IDF +"SQLException: " + e.getMessage());
			e.printStackTrace();
		}
		return map;
	}
		
	/**
	 * Prepare to send email
	 * 
	 * @param
	 * @throws MessagingException
	 */
	private void prepareSendEmail(HashMap<String, String> map, String SectHeadPersonGroup, String EngManPersonGroup) {
		
		final String MTD_IDF = "prepareSendEmail(): ";
		
		cronLogger.info(LOG_IDF + MTD_IDF +"Processing Unapproved Labour Report ... ");
		
		String emailBodyMsg;
		
		String id = null;

		String subj = "";
		String body = "";
		String toList = "";
		String ccList = "";
		String bccList = "";
		String emailSubj = "";
		String emailBody = "";
		String replyTo = "";
		CommTemplateRemote tempRemote= null;
		CommTemplateSetRemote commTemplateSet= null;
		
		DBShortcut dbShortcut = new DBShortcut();

		SqlFormat sectHeadSql = null;
		SqlFormat engManSql = null;
		
		String query = "";
		
		String recipientSectHeadQuery = "select distinct EMAILADDRESS, PERSONID from EMAIL where PERSONID in (select RESPPARTYGROUP from PERSONGROUPTEAM where PERSONGROUP = ':id')";
		String recipientEngManQuery = "select distinct EMAILADDRESS, PERSONID from EMAIL where PERSONID in (select RESPPARTYGROUP from PERSONGROUPTEAM where PERSONGROUP = ':id')";

		ResultSet SectHeadRSet=null;
		ResultSet EngManRSet=null;
				
		try {
			
			dbShortcut.connect(getRunasUserInfo().getConnectionKey());

	    	// Get relevant comm template 
	    	commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
			commTemplateSet.setWhere("TEMPLATEID='"+commTmpl+"'");
			commTemplateSet.reset();
			tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);
			
			cronLogger.info(LOG_IDF + MTD_IDF +"Using CommTemplate for emails to users: " + commTmpl);
			
			bccList=tempRemote.getString("BCCLIST");
			emailSubj=tempRemote.getString("SUBJECT");
			emailBody=tempRemote.getString("MESSAGE");
			replyTo=tempRemote.getString("REPLYTO");
			
			// ---- Prepare to send emails to SectHead & EngMan ---- //
			
			toList = ""; 
			ccList = "";
			emailBodyMsg = ""; // Re-use variable for printing output in Email body
			
			// Loop through results of to List Query from DB if there are any
			query = recipientSectHeadQuery.replaceFirst(":id", SectHeadPersonGroup);
			sectHeadSql=new SqlFormat(query);
			cronLogger.debug(LOG_IDF + "Run SQL: " + query);
			SectHeadRSet = dbShortcut.executeQuery(sectHeadSql.format());
			
			if(SectHeadRSet != null) {
				while(SectHeadRSet.next()) {
					// Skip if already in list to avoid duplicates
					if ( toList.contains(SectHeadRSet.getString(1)) ) {
						cronLogger.debug(LOG_IDF  +"Skipping email:"+id+" ["+SectHeadRSet.getString(1)+"], already in list..");
					} else {
						cronLogger.debug(LOG_IDF  +"Adding email:"+id+" ["+SectHeadRSet.getString(1)+":"+SectHeadRSet.getString(2)+"]");
						toList += SectHeadRSet.getString(1) + ",";
					}
				}
				cronLogger.info(LOG_IDF +"Current To List for unApproved Labour: [" + toList + "]" );
				
			} else {
				cronLogger.warn(LOG_IDF +"WARNING: No Person Ids list!!!" );
			}
			
			// Loop through results of Cc List Query from DB if there are any
			query = recipientEngManQuery.replaceFirst(":id", EngManPersonGroup);
			engManSql=new SqlFormat(query);
			cronLogger.debug(LOG_IDF + "Run SQL: " + query);
			EngManRSet = dbShortcut.executeQuery(engManSql.format());
			if(EngManRSet != null) {
				while(EngManRSet.next()) {
					// Skip if already in list to avoid duplicates
					if ( ccList.contains(EngManRSet.getString(1)) ) {
						cronLogger.debug(LOG_IDF  +"Skipping email:"+id+" ["+EngManRSet.getString(1)+"], already in list..");
					} else {
						cronLogger.debug(LOG_IDF  +"Adding email:"+id+" ["+EngManRSet.getString(1)+":"+EngManRSet.getString(2)+"]");
						ccList += EngManRSet.getString(1) + ",";
					}
				}
				cronLogger.info(LOG_IDF +"Current CC List for unApproved Labour: [" + ccList + "]" );
				
			} else {
				cronLogger.warn(LOG_IDF +"WARNING: No Person Ids list!!!" );
			}
			
			//Check if cron task is triggered after the final cut off date.
			SimpleDateFormat dtf = new SimpleDateFormat("dd");
			Date date = new Date();
			String todayDate = dtf.format(date);
			
			int today = Integer.parseInt(todayDate);
			//Set Final Reminder header to email subject.
			//Update email content
			if (today == finalReminderDate) {
				emailSubj = emailSubj + " - FINAL REMINDER";
				emailBody = emailBody.replaceAll("the 5th of the month", "today");
			}
			
			// -------------------------------------- Prep and send email -------------------------------------- //
			
			//String newLine = System.getProperty("line.separator");//This will retrieve line separator dependent on OS.
			
			emailBodyMsg = "";
			for (Object name: map.keySet()) {
				String key = name.toString();
				String value = map.get(name).toString();
				emailBodyMsg += value + "<br>";
				//System.out.println(key + " " + value);
			}
			
			cronLogger.info("emailBodyMsg: "+emailBodyMsg);
			
			subj = emailSubj;
			body = emailBody.replaceAll("#UNAPPROVEDLABOR", emailBodyMsg);
			
			emailUsers(toList, ccList, bccList, replyTo, subj, body);
			
		} catch (IOException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"IOException: " + e.getMessage());
		} catch (MXApplicationException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MXApplicationException: " + e.getMessage());
		} catch (SQLException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"SQLException: " + e.getMessage());
		} catch (MXException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MXException: " + e.getMessage());
		} finally {
			
			try {
				SectHeadRSet.close();
				SectHeadRSet = null;
				EngManRSet.close();
				EngManRSet = null;
				
				sectHeadSql = null;
				engManSql = null;
				
				recipientSectHeadQuery = null;
				recipientEngManQuery = null;
				
				query = null;
				
				dbShortcut.close();
				dbShortcut = null;
				
				//currentLine = null;
				
				id = null;

				subj = null;
				body = null;
				toList = null;
				ccList = null;
				bccList = null;
				emailSubj = null;
				emailBody = null;
				replyTo = null;
				tempRemote= null;
				commTemplateSet= null;
				
			}  catch (Exception e) {
				e.printStackTrace();
				cronLogger.error(LOG_IDF + MTD_IDF +"Exception: " + e.getMessage());
			}
		}
		cronLogger.info(LOG_IDF + MTD_IDF +"Unapproved Labour Report Email completed.");
		
	} // End prepareSendEmail()
	/**
	 * Prepare to send final reminder email
	 * 
	 * @param
	 * @throws MessagingException
	 */
	private void prepareSendEmailFinalReminder(HashMap<String, String> map) {
		
		final String MTD_IDF = "prepareSendEmailFinalReminder(): ";
		
		cronLogger.info(LOG_IDF + MTD_IDF +"Processing Unapproved Labour Report ... ");
		
		String emailBodyMsg;

		String subj = "";
		String body = "";
		String toList = "";
		String ccList = "";
		String bccList = "";
		String emailSubj = "";
		String emailBody = "";
		String replyTo = "";
		CommTemplateRemote tempRemote= null;
		CommTemplateSetRemote commTemplateSet= null;
		
		try {
			
	    	// Get relevant comm template 
	    	commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
			commTemplateSet.setWhere("TEMPLATEID='"+commTmplFinal+"'");
			commTemplateSet.reset();
			tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);
			
			cronLogger.info(LOG_IDF + MTD_IDF +"Using CommTemplate for emails to users: " + commTmplFinal);
			
			toList = tempRemote.getString("TOLIST"); 
			ccList = tempRemote.getString("CCLIST");
			bccList=tempRemote.getString("BCCLIST");
			emailSubj=tempRemote.getString("SUBJECT");
			emailBody=tempRemote.getString("MESSAGE");
			replyTo=tempRemote.getString("REPLYTO");
			
			// ---- Prepare to send emails to SectHead & EngMan ---- //
			
			emailBodyMsg = ""; // Re-use variable for printing output in Email body
			
			//Check if cron task is triggered after the final cut off date.
			SimpleDateFormat dtf = new SimpleDateFormat("dd");
			Date date = new Date();
			String todayDate = dtf.format(date);
			
			// -------------------------------------- Prep and send email -------------------------------------- //
			
			//String newLine = System.getProperty("line.separator");//This will retrieve line separator dependent on OS.
			
			emailBodyMsg = "";
			for (Object name: map.keySet()) {
				String key = name.toString();
				String value = map.get(name).toString();
				emailBodyMsg += value + "<br>";
				//System.out.println(key + " " + value);
			}
			
			cronLogger.info("emailBodyMsg: "+emailBodyMsg);
			
			subj = emailSubj;
			body = emailBody.replaceAll("#UNAPPROVEDLABOR", emailBodyMsg);
			
			emailUsers(toList, ccList, bccList, replyTo, subj, body);
			
		} catch (IOException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"IOException: " + e.getMessage());
		} catch (MXApplicationException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MXApplicationException: " + e.getMessage());
		} catch (MXException e) {
			e.printStackTrace();
			cronLogger.error(LOG_IDF + MTD_IDF +"MXException: " + e.getMessage());
		} finally {
			
			try {

				subj = null;
				body = null;
				toList = null;
				ccList = null;
				bccList = null;
				emailSubj = null;
				emailBody = null;
				replyTo = null;
				tempRemote= null;
				commTemplateSet= null;
				
			}  catch (Exception e) {
				e.printStackTrace();
				cronLogger.error(LOG_IDF + MTD_IDF +"Exception: " + e.getMessage());
			}
		}
		cronLogger.info(LOG_IDF + MTD_IDF +"Unapproved Labour Report Email completed.");
		
	} // End prepareSendEmailFinalReminder()
	
} // End Class UnapprovedLaborAlertCron
