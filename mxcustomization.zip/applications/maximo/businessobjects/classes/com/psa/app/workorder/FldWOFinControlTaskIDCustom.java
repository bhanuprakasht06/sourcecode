/*
 * Modification history
 * 27-04-07 LS	SR-030 	Make Task ID of WO Org level
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import psdi.app.financial.FinControlRemote;
import psdi.mbo.MAXTableDomain;
import psdi.mbo.MboConstants;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class FldWOFinControlTaskIDCustom extends MAXTableDomain 
{

    public FldWOFinControlTaskIDCustom(MboValue mbovalue)
    {
        super(mbovalue);
        setRelationship("FINCNTRL", "taskid = :fctaskid");
        String as[] = {
            "fctaskid"
        };
        String as1[] = {
            "taskid"
        };
        setLookupKeyMapInOrder(as, as1);
    }

    public void initValue()
	    throws MXException, RemoteException
	{
	    super.initValue();
	    if(!getMboValue("fincntrlid").isNull())
	    {
	        MboSetRemote mbosetremote = getMboValue().getMbo().getMboSet("FINCNTRL");
	        if(!mbosetremote.isEmpty())
	        {
	            FinControlRemote fincontrolremote = (FinControlRemote)mbosetremote.getMbo(0);
	            getMboValue().setValue(fincontrolremote.getString("taskid"), 11L);
	        }
	    }
	}

    public void validate()
	    throws MXException, RemoteException
	{
	    if(getMboValue().isNull())
	        return;
	    if(getMboValue("fcprojectid").isNull())
	        throw new MXApplicationException("workorder", "FCProjectNeededForFCTask");

		MboSetRemote projectset = getMboValue().getMbo().getMboSet("$fincontrolTask_VALIDATE", "FINCNTRL", getValidTasksQuery());
		projectset.setWhere("taskid='" + getMboValue().getString() + "'");
		projectset.reset();
		if(projectset.isEmpty())
		{
			Object param[] = { getMboValue().getString() };
			throw new MXApplicationException("workorder", "InValidFCTask", param);
		}else
		{
			return;
		}
	}

    public void action()
	    throws MXException, RemoteException
	{
    	String projectid = getMboValue("fcprojectid").getString();
	    String orgid = getMboValue("orgid").getString();
	    if(getMboValue().isNull())
	    {
	        getMboValue("fincntrlid").setValueNull(11L);
	        SqlFormat sqlformat = new SqlFormat(getMboValue().getMbo(), "projectid = :1 and taskid is null and orgid = :2");
	        sqlformat.setObject(1, "FINCNTRL", "projectid", projectid);
	        sqlformat.setObject(2, "FINCNTRL", "orgid", orgid);
	        MboSetRemote mbosetremote = getMboValue().getMbo().getMboSet("$fcproject", "FINCNTRL", sqlformat.format());
	        if(!mbosetremote.isEmpty())
	            getMboValue("fincntrlid").setValue(mbosetremote.getMbo(0).getString("fincntrlid"), 11L);
	        return;
	    }
	    String task = getTranslator().toExternalList("FCTYPE", "TASK", getMboValue().getMbo());
	    String taskid = getMboValue().getString();
	    SqlFormat sqlformat1 = new SqlFormat(getMboValue().getMbo(), "projectid = :1 and taskid = :2 and fctype in (" + task + ") and orgid = :3");
	    sqlformat1.setObject(1, "FINCNTRL", "projectid", projectid);
	    sqlformat1.setObject(2, "FINCNTRL", "taskid", taskid);
	    sqlformat1.setObject(3, "FINCNTRL", "orgid", orgid);
	    MboSetRemote mbosetremote1 = getMboValue().getMbo().getMboSet("$fctask", "FINCNTRL", sqlformat1.format());
	    if(!mbosetremote1.isEmpty())
	        getMboValue("fincntrlid").setValue(mbosetremote1.getMbo(0).getString("fincntrlid"), MboConstants.NOVALIDATION);
	}

    public boolean hasList()
    {
        return true;
    }

    public MboSetRemote getList()
	    throws MXException, RemoteException
	{
		setListCriteria(getValidTasksQuery());
		MboSetRemote taskset = super.getList();
		return taskset;
	}

    
	private String getValidTasksQuery()
		throws MXException, RemoteException
	{
		Date today = MXServer.getMXServer().getDate();
		GregorianCalendar gregoriancalendar = new GregorianCalendar();
		gregoriancalendar.setTime(today);
		gregoriancalendar.add(Calendar.DAY_OF_MONTH, 1);
		Date tomorrow = gregoriancalendar.getTime();
		
		String taskstatus = getTranslator().toExternalList("FCSTATUS", "APPR", getMboValue().getMbo());
		String tasktype = getTranslator().toExternalList("FCTYPE", "TASK", getMboValue().getMbo());
		SqlFormat sqlformat = new SqlFormat(getMboValue().getMbo(),
				"projectid = :1 and fcstatus IN (" + taskstatus + ") AND fctype IN (" + tasktype + ") "
				+ "AND ((enddate>=:2) OR enddate IS NULL) AND ((startdate<=:3) OR startdate IS NULL) "
				+ "AND ischargeable = :YES AND orgid=:4");
		sqlformat.setObject(1, "FINCNTRL", "projectid", getMboValue().getMbo().getString("fcprojectid"));
		sqlformat.setDate(2, today);
		sqlformat.setDate(3, tomorrow);
		sqlformat.setObject(4, "FINCNTRL", "orgid", getMboValue("orgid").getString());
		return sqlformat.format();
	}

}
