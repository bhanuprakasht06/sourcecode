package com.psa.app.appurl;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.custapp.CustomMboSet;
import psdi.util.MXException;

public class AppUrlSetCustom extends CustomMboSet {

	public AppUrlSetCustom(MboServerInterface ms) throws RemoteException {
		super(ms);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected Mbo getMboInstance(MboSet ms) throws MXException, RemoteException {
		// TODO Auto-generated method stub
		return new AppUrl(ms);
	}

	
}
