package com.psa.app.workorder;


import psdi.mbo.*;
import java.util.*;
import psdi.util.*;
import java.rmi.*;
import psdi.app.workorder.*;


public interface WPMaterialCustomSetRemote extends psdi.app.workorder.WPMaterialSetRemote
{
	
	public abstract void copyLoanReserveSet(MboSetRemote paramMboSetRemote, String wonum)
    	throws MXException, RemoteException;	
	
}