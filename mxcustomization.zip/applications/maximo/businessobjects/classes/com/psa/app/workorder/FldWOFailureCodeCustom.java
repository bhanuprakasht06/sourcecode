/*Requirement Reference 4.1.4 Primary Part & secondary Part code editable on Edit History Mode*/


package com.psa.app.workorder;
import java.rmi.RemoteException;
import psdi.app.workorder.FailureReportSet;
import psdi.app.workorder.FldWOFailureCode;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldWOFailureCodeCustom extends FldWOFailureCode{

	public FldWOFailureCodeCustom(MboValue mbv) throws RemoteException 
	
	{
		super(mbv);
	}
	
	public void action()
	  	throws MXException, RemoteException
	 {
	    MboValue problemCode = getMboValue("problemcode");
	    System.out.println("### Entering FldWOFailiurCodeCustom Action () Method ");
		boolean dosave = (!(problemCode.getMbo().toBeAdded())) && (!(problemCode.getInitialValue().isNull()));
		FailureReportSet frSet = (FailureReportSet)getMboValue().getMbo().getMboSet("FAILUREREPORT");

		frSet.reflectFailureClass();
		System.out.println("###FldWOFailiurCodeCustom Break Point 1 ");
		problemCode.setValueNull(11L);

			if(!problemCode.getMbo().getString("STATUS").equalsIgnoreCase("CLOSE"))
			{
				System.out.println("###FldWOFailiurCodeCustom Status of WO is CLOSE");
				problemCode.setFlag(7L, getMboValue().isNull());
			}
			if (problemCode.getMbo().getString("STATUS").equalsIgnoreCase("CLOSE"))
			{
				dosave=false;
			}
	    	if (!(dosave))
	    
			{
				System.out.println("###FldWOFailiurCodeCustom Overriding DOSAVE Flag");
				return;
			}
	    frSet.save();
		System.out.println("### EXITING FldWOFailiurCodeCustom Action()");

	}

}

