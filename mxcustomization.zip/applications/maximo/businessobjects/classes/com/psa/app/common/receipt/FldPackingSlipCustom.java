/*
 * Modification history
 * 16-08-2007	AGD	SR-098	Prevent duplicated packing slips
 * 25-10-2007	AGD	DR-053	Problem saving service receipt with same DO as material receipt, which can be normal
 */
package com.psa.app.common.receipt;

import java.rmi.RemoteException;

import com.psa.app.common.receipt.ReceiptMboCustom;

import psdi.app.inventory.MatRecTransRemote;
import psdi.app.labor.ServRecTransRemote;
//import psdi.app.po.POCustomRemote;
import psdi.app.po.PORemote;
import psdi.app.po.virtual.ReceiptInputRemote;
import psdi.app.workorder.WPMaterialRemote;
import psdi.app.workorder.WPServiceRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldPackingSlipCustom extends MboValueAdapter
{

	public FldPackingSlipCustom()
	{
		super();
	}


	public FldPackingSlipCustom(MboValue mbovalue)
	{
		super(mbovalue);
	}


	public void validate()
			throws MXException, RemoteException
	{
		MboValue packingslipmbovalue = getMboValue();
		if (packingslipmbovalue.isNull() || packingslipmbovalue == null)
			return;

		// Get the vendor and the PO. The method to get it depends on who is the caller
		Mbo mbo = packingslipmbovalue.getMbo();
		String vendor = "";
//Begin modification DR-053
		String ponum = null;
		if (mbo instanceof MatRecTransRemote || mbo instanceof ServRecTransRemote || mbo instanceof ReceiptInputRemote)
		{
			vendor = mbo.getString("po.vendor");
			ponum = mbo.getString("ponum");
		}
//End modification DR-053
		else if (mbo instanceof WPMaterialRemote || mbo instanceof WPServiceRemote)
		{
			if (mbo.isNull("vendor"))
			{
				packingslipmbovalue.setValueNull();
				throw new MXApplicationException("workorder", "DOWithoutVendor");
			}
			vendor = mbo.getString("vendor");
		}
		else		// from ReceiptInputDOCustomRemote
		{
			MboRemote po = mbo.getOwner();
			if (po instanceof PORemote)
//Begin modification DR-053
			{
				vendor = po.getString("vendor");
				ponum = po.getString("ponum");
			}
//End modification DR-053
		}
		if (vendor == "" || vendor == null)
			return;
		
		//Comment: Remove check KIV issue 21  BCT# 03-Aug-2021
		//** Run the check
		//ReceiptMboCustom receipt = new ReceiptMboCustom((MboSet) mbo.getThisMboSet());
		//**Begin modification DR-053
		//receipt.checkDuplicatePackingSlip(packingslipmbovalue, vendor, ponum);
		//**End modification DR-053
		
	}

}
