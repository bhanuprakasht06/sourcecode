/*
 * Modification history
 * 28-09-07	AGD	NA		Creation
 */
package com.psa.app.company;

import java.rmi.RemoteException;


import psdi.app.company.CompanySet;
import psdi.app.company.CompanySetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class CompanyCustomSet extends CompanySet
		implements CompanySetRemote
{

	public CompanyCustomSet(MboServerInterface mboserverinterface)
			throws MXException, RemoteException
	{
		super(mboserverinterface);
	}


	protected Mbo getMboInstance(MboSet companyset)
			throws MXException, RemoteException
	{
		return new CompanyCustom(companyset);
	}
}
