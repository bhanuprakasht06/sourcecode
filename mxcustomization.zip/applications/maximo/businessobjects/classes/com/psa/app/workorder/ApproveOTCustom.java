package com.psa.app.workorder;

import java.rmi.RemoteException;

import com.psa.app.labor.LabTransCustomRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class ApproveOTCustom
                implements ActionCustomClass
{

        /*
         * Constructor - does nothing
         */
        public ApproveOTCustom()
        {
        }


        /*
         * Approve all unapproved labor reports
         */
        public void applyCustomAction(MboRemote woremote, Object aobj[])
                        throws MXException, RemoteException
        {
                mxLogger.debug("ApproveOTCustom - Entering");
                System.out.println("ApproveOTCustom - Entering: WO: " + woremote.getString("WONUM") + ": " + MXServer.getMXServer().getDate());
                
                wo = woremote;

                MboSetRemote labtransset = wo.getMboSet("LABTRANS");
                LabTransCustomRemote labtrans;
                for (int i = 0; (labtrans = (LabTransCustomRemote) labtransset.getMbo(i)) != null; i ++)
                {
                	if (!labtrans.getBoolean("genapprservreceipt") && labtrans.getBoolean("PSA_VERIFIED") && labtrans.getBoolean("PSA_OT_FLAG"))
                		labtrans.approveOTTransaction();
                                //labtrans.approveLaborTransaction();
                }
                
                //woremote.getThisMboSet().save();
                
                //labtransset.save();
                labtransset.close();

                mxLogger.debug("ApproveOTCustom - Leaving");
                System.out.println("ApproveOTCustom - Leaving: WO: " + woremote.getString("WONUM") + ": " + MXServer.getMXServer().getDate());
        }

        private MboRemote                       wo;
        private static final MXLogger   mxLogger        = MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}


