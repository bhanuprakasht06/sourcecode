package com.psa.app.workorder;

import java.rmi.RemoteException;
//import java.sql.SQLException;





import psdi.app.inventory.InventoryRemote;
import psdi.app.inventory.MatUseTransRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.mbo.StatefulMboRemote;
//import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.mbo.MboConstants;


public class RecondAutoReturnCustom implements ActionCustomClass {
	private double psa_invbcurrbal;

	public void applyCustomAction(MboRemote mboremote, Object[] aobj)
			throws MXException, RemoteException {
		RecondUtilCustom recondUtil = new RecondUtilCustom();
		MboSetRemote matusetransSetRemote = mboremote
				.getMboSet("ORIGRECONDITEMRETURN");
		if (!matusetransSetRemote.isEmpty()) {
			MatUseTransRemote matusetransRemote = (MatUseTransRemote) matusetransSetRemote
					.getMbo(0);

			if (matusetransRemote != null) {
				String psa_itemNum = matusetransRemote.getString("ITEMNUM");
				String psa_itemSet = matusetransRemote.getString("ITEMSETID");
				String psa_toSiteID = matusetransRemote.getString("TOSITEID");
				String psa_storeLoc = matusetransRemote.getString("STORELOC");
				double psa_recondQty = mboremote.getDouble("RECONDQTY");
				String psa_siteID = matusetransRemote.getString("SITEID");
				double psa_conversion = matusetransRemote
						.getDouble("CONVERSION");
				String psa_ponum = matusetransRemote.getString("PONUM");
				//double psa_hasld = matusetransRemote.getDouble("HASLD");
				String psa_assetNum = matusetransRemote.getString("ASSETNUM");
				String psa_memo=matusetransRemote.getString("MEMO");
				Double psa_outside=matusetransRemote.getDouble("OUTSIDE");
				String psa_packingslipnum=matusetransRemote.getString("PACKINGSLIPNUM");
				String psa_polinenum=matusetransRemote.getString("POLINENUM");
				Double psa_rollup=matusetransRemote.getDouble("ROLLUP");
				String psa_gldebitacc = matusetransRemote.getString("GLDEBITACCT");
				String psa_currencycode=matusetransRemote.getString("CURRENCYCODE");
				String psa_rotassetnum=matusetransRemote.getString("ROTASSETNUM");
				String psa_location=matusetransRemote.getString("LOCATION");
				String psa_desc=matusetransRemote.getString("DESCRIPTION");
				Double psa_exchangerate=matusetransRemote.getDouble("EXCHANGERATE");
				Double psa_sparepartadded=matusetransRemote.getDouble("SPAREPARTADDED");
				String psa_mrnum=matusetransRemote.getString("MRNUM");
				String psa_mrlinenum=matusetransRemote.getString("MRLINENUM");
				String psa_sendersysid=matusetransRemote.getString("SENDERSYSID");
				String psa_fincntrlid=matusetransRemote.getString("FINCNTRLID");
				String psa_orgid=matusetransRemote.getString("ORGID");
				String psa_refwo=matusetransRemote.getString("REFWO");
				Double psa_enteredastask=matusetransRemote.getDouble("ENTEREDASTASK");
				String psa_linetype=matusetransRemote.getString("LINETYPE");
				String psa_commoditygrp=matusetransRemote.getString("COMMODITYGROUP");
				String psa_commodity=matusetransRemote.getString("COMMODITY");
				
				// String psa_toSiteIDtransit = psa_toSiteID.concat("TRANSIT");
				// String psa_transitStoreLoc
				// =recondutil.getTransitStoreLoc(psa_toSiteID);
				String psa_transitStoreLoc = (psa_storeLoc.replace("STORE", ""))
						.concat("TRANSIT");
				String psa_recondStoreLoc = (psa_storeLoc.replace("STORE", ""))
						.concat("RECOND");

				String psa_recondBinNum = recondUtil.getBin(mboremote,
						psa_itemNum, psa_itemSet, psa_recondStoreLoc,
						psa_siteID);
				String psa_toSiteIDBinNum = recondUtil.getBin(mboremote,
						psa_itemNum, psa_itemSet, psa_transitStoreLoc,
						psa_toSiteID);

				double psa_currBal = recondUtil.getCurBal(mboremote,
						psa_itemNum, psa_itemSet, psa_transitStoreLoc,
						psa_toSiteID, psa_toSiteIDBinNum);
				double psa_recondBinCurrBal = recondUtil.getCurBal(mboremote,
						psa_itemNum, psa_itemSet, psa_recondStoreLoc,
						psa_siteID, psa_recondBinNum);

				String psa_lot = recondUtil.getLot(mboremote, psa_itemNum,
						psa_itemSet, psa_transitStoreLoc, psa_toSiteID);

				String psa_transitGLAcc = recondUtil.getGLAcct(mboremote,
						psa_transitStoreLoc, psa_toSiteID);
				String psa_recondGLAcc = recondUtil.getGLAcct(mboremote,
						psa_recondStoreLoc, psa_siteID);

				InventoryRemote transitInvRemote = recondUtil.getTransitInv(
						mboremote, psa_itemNum, psa_itemSet,
						psa_transitStoreLoc, psa_toSiteID);
				String psa_issueUnit = transitInvRemote.getString("ISSUEUNIT");
				double psa_issuetypeinv = transitInvRemote
						.getDouble("ISSUEYTD");

				double psa_recondTotalCurrBal = recondUtil.getTotalCurBal(
						mboremote, psa_itemNum, psa_itemSet,
						psa_recondStoreLoc, psa_siteID);

				String psa_recondLot = recondUtil.getLot(mboremote,
						psa_itemNum, psa_itemSet, psa_recondStoreLoc,
						psa_siteID);

				// BCT
				MboRemote wpitemRemote = mboremote.getMboSet(
						"$WPITEM",
						"WPITEM",
						"WONUM='" + mboremote.getString("ORIGRECORDID")
								+ "' and itemnum ='"
								+ mboremote.getString("RECONDITEM")
								+ "' and location='" + psa_storeLoc + "'")
						.getMbo(0);
				int psa_wpItemId = wpitemRemote.getInt("WPITEMID");
				try 
				{
					//Comment: add to matusetrans
					
					MboSetRemote woAddMboSet=MXServer.getMXServer().getMboSet("WORKORDER",mboremote.getUserInfo());
					woAddMboSet.setWhere("WONUM='"+mboremote.getString("origrecordid")+"' and SITEID='"+mboremote.getString("SITEID")+"'");
					woAddMboSet.reset();
					if(!woAddMboSet.isEmpty())
					{
						String internalstatus= ((StatefulMboRemote) woAddMboSet.getMbo(0)).getInternalStatus();
						System.out.println("***RecondAutoReturnCustom.internalstatus="+internalstatus+", wonum="+woAddMboSet.getMbo(0).getString("WONUM")+", status="+woAddMboSet.getMbo(0).getString("STATUS"));
						//Comment: to overcome the WO is not a valid approved work order. The workorder must have status of Approved.
						if (internalstatus.equalsIgnoreCase("CLOSE"))
						{
							woAddMboSet.setWhere("STATUS IN ('DRAWSTORE') and SITEID='"+mboremote.getString("SITEID")+"'");
							woAddMboSet.reset();
							
						}
						MboSetRemote matusetranAddMboSet=woAddMboSet.getMbo(0).getMboSet("ORIGRECONDITEMRETURN");
					
						MboRemote matusetranaddremote = matusetranAddMboSet.addAtEnd(MboConstants.NOVALIDATION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ITEMNUM",psa_itemNum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("STORELOC",psa_transitStoreLoc, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("TRANSDATE",MXServer.getMXServer().getDate(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ACTUALDATE",MXServer.getMXServer().getDate(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("QUANTITY",psa_recondQty, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("CURBAL",psa_currBal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("PONUM",psa_ponum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("CONVERSION",psa_conversion, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ASSETNUM",psa_assetNum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ENTERBY",mboremote.getUserInfo().getUserName(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("MEMO",psa_memo, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("OUTSIDE",psa_outside, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("PACKINGSLIPNUM",psa_packingslipnum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("POLINENUM",psa_polinenum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ROLLUP",psa_rollup, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("BINNUM",psa_toSiteIDBinNum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("LOTNUM",psa_lot, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ISSUETYPE","RETURN", MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("GLDEBITACCT",psa_gldebitacc, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("GLCREDITACCT",psa_transitGLAcc, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("CURRENCYCODE",psa_currencycode, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ROTASSETNUM",psa_rotassetnum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("LOCATION",psa_location, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("DESCRIPTION",psa_desc, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("EXCHANGERATE",psa_exchangerate, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("SPAREPARTADDED",psa_sparepartadded, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("QTYREQUESTED",psa_recondQty, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("MRNUM",psa_mrnum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("MRLINENUM",psa_mrlinenum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("SENDERSYSID",psa_sendersysid, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("FINCNTRLID",psa_fincntrlid, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ORGID",psa_orgid, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("SITEID",psa_toSiteID, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("REFWO",psa_refwo, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ENTEREDASTASK",psa_enteredastask, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("LINETYPE",psa_linetype, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("ITEMSETID",psa_itemSet, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("CONDITIONCODE","RECOND", MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("CONDRATE",1, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("COMMODITYGROUP",psa_commoditygrp, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("COMMODITY",psa_commoditygrp, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("TOSITEID",psa_toSiteID, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranaddremote.setValue("WPITEMID",psa_wpItemId, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matusetranAddMboSet.save();
					}
					  

					/*
						SqlFormat mutsqlformat = new SqlFormat(
						mboremote.getUserInfo(),
						"INSERT INTO MATUSETRANS (ITEMNUM, STORELOC, TRANSDATE, ACTUALDATE, QUANTITY, CURBAL, PHYSCNT, UNITCOST, ACTUALCOST, PONUM, CONVERSION, ASSETNUM, ENTERBY, MEMO, OUTSIDE, PACKINGSLIPNUM, POLINENUM, ROLLUP, BINNUM, LOTNUM, ISSUETYPE, GLDEBITACCT, GLCREDITACCT, LINECOST, CURRENCYCODE, CURRENCYUNITCOST, ROTASSETNUM, CURRENCYLINECOST, LOCATION, DESCRIPTION, EXCHANGERATE, SPAREPARTADDED, QTYREQUESTED, MRNUM, MRLINENUM, MATUSETRANSID, SENDERSYSID, FINCNTRLID, ORGID, SITEID, REFWO, ENTEREDASTASK, LINETYPE, ITEMSETID, CONDITIONCODE, CONDRATE, COMMODITYGROUP, COMMODITY, TOSITEID, LANGCODE, HASLD, REVIEWED, ISPDA, RECONCILIATION, CONSIGNMENT, WPITEMID) VALUES "
								+ "('"
								+ psa_itemNum
								+ "', '"
								+ psa_transitStoreLoc
								+ "', getDate(), getDate(), "
								+ psa_recondQty
								+ ", "
								+ psa_currBal
								+ ", 0, 0, 0, '"
								+ psa_ponum
								+ "', "
								+ psa_conversion
								+ ", '"
								+ psa_assetNum
								+ "', '"
								+ mboremote.getUserInfo().getUserName()
								+ "', '"
								+ matusetransRemote.getString("MEMO")
								+ "', "
								+ matusetransRemote.getDouble("OUTSIDE")
								+ ", '"
								+ matusetransRemote.getString("PACKINGSLIPNUM")
								+ "', '"
								+ matusetransRemote.getString("POLINENUM")
								+ "', "
								+ matusetransRemote.getDouble("ROLLUP")
								+ ", '"
								+ psa_toSiteIDBinNum
								+ "', '"
								+ psa_lot
								+ "', 'RETURN', '"
								+ matusetransRemote.getString("GLDEBITACCT")
								+ "', '"
								+ psa_transitGLAcc
								+ "', 0, '"
								+ matusetransRemote.getString("CURRENCYCODE")
								+ "', 0, '"
								+ matusetransRemote.getString("ROTASSETNUM")
								+ "', 0, '"
								+ matusetransRemote.getString("LOCATION")
								+ "', '"
								+ matusetransRemote.getString("DESCRIPTION")
								+ "', "
								+ matusetransRemote.getDouble("EXCHANGERATE")
								+ ", "
								+ matusetransRemote.getDouble("SPAREPARTADDED")
								+ ", "
								+ psa_recondQty
								+ ", '"
								+ matusetransRemote.getString("MRNUM")
								+ "', '"
								+ matusetransRemote.getString("MRLINENUM")
								+ "', (select max(matusetransid)+1 from MATUSETRANS), '"
								+ matusetransRemote.getString("SENDERSYSID")
								+ "', '"
								+ matusetransRemote.getString("FINCNTRLID")
								+ "', '"
								+ matusetransRemote.getString("ORGID")
								+ "', '"
								+ psa_toSiteID
								+ "', '"
								+ matusetransRemote.getString("REFWO")
								+ "', "
								+ matusetransRemote.getDouble("ENTEREDASTASK")
								+ ", '"
								+ matusetransRemote.getString("LINETYPE")
								+ "', '"
								+ psa_itemSet
								+ "', 'RECOND', 1, '"
								+ matusetransRemote.getString("COMMODITYGROUP")
								+ "', '"
								+ matusetransRemote.getString("COMMODITY")
								+ "', '"
								+ psa_toSiteID
								+ "', '"
								+ matusetransRemote.getString("LANGCODE")
								+ "', "
								+ psa_hasld
								+ ",0,0,0,0,'"
								+ psa_wpItemId + "')");
					 */
					MboSetRemote inventoryAddMboSet=MXServer.getMXServer().getMboSet("INVENTORY",mboremote.getUserInfo());
					inventoryAddMboSet.setWhere("ITEMNUM='"+psa_itemNum+"' and LOCATION='"+psa_transitStoreLoc+"' and SITEID='"+mboremote.getString("SITEID")+"'");
					inventoryAddMboSet.reset();
					if(!inventoryAddMboSet.isEmpty())
					{
						MboSetRemote matrectransSetRemote = inventoryAddMboSet.getMbo(0).getMboSet("MATRECTRANS");
						MboRemote matrectranaddremote = matrectransSetRemote.addAtEnd(MboConstants.NOVALIDATION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ITEMNUM",psa_itemNum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("TOSTORELOC",psa_recondStoreLoc,  MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("TRANSDATE",MXServer.getMXServer().getDate(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ACTUALDATE",MXServer.getMXServer().getDate(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("QUANTITY",psa_recondQty, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("RECEIVEDUNIT",psa_issueUnit, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ISSUETYPE","TRANSFER", MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("UNITCOST",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ACTUALCOST",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("PONUM",psa_ponum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("REJECTQTY",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("CONVERSION",psa_conversion, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ENTERBY",mboremote.getUserInfo().getUserName(), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("OUTSIDE",psa_outside, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("POLINENUM",psa_polinenum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ISSUE",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("TOTALCURBAL",psa_recondTotalCurrBal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("OLDAVGCOST",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("TOBIN",psa_recondBinNum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("TOLOT",psa_recondLot, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("GLDEBITACCT",psa_recondGLAcc, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("GLCREDITACCT",psa_transitGLAcc, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("LINECOST",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("CURRENCYCODE",psa_currencycode, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("EXCHANGERATE",psa_exchangerate, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("CURRENCYUNITCOST",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("CURRENCYLINECOST",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("DESCRIPTION",psa_desc, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("FROMSTORELOC",psa_transitStoreLoc, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("FROMBIN",psa_toSiteIDBinNum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("FROMLOT",psa_lot, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("STATUS","COMP", MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("CURBAL",psa_recondBinCurrBal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("EXCHANGERATE2",psa_exchangerate, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("LINECOST2",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("MRNUM",psa_mrnum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("MRLINENUM",psa_mrlinenum, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("SENDERSYSID",psa_sendersysid, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("FINCNTRLID",psa_fincntrlid, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ORGID",psa_orgid, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("SITEID",psa_siteID, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("COSTINFO",1, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("REFWO",mboremote.getString("WONUM"), MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ENTEREDASTASK",psa_enteredastask, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("FROMSITEID",psa_toSiteID, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("LINETYPE",psa_linetype, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("ITEMSETID",psa_itemSet, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("CONDITIONCODE","RECOND", MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("FROMCONDITIONCODE","RECOND", MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("CONDRATE",1, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("INSPECTEDQTY",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("NEWAVGCOST",0, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						matrectranaddremote.setValue("OLDTOTALBAL",psa_recondBinCurrBal, MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
						System.out.println("***RecondAutoReturnCustom.psa_toSiteIDBinNum="+psa_toSiteIDBinNum+",matrectranaddremote.FROMBIN="+matrectranaddremote.getString("FROMBIN"));
						matrectransSetRemote.save();
					}
					psa_invbcurrbal = psa_recondBinCurrBal + psa_recondQty;
					
					MboSetRemote invBalSetRemote= mboremote.getMboSet("$INVBALANCES","INVBALANCES", "ITEMNUM='" + psa_itemNum + "' AND ITEMSETID='"+ psa_itemSet + "' AND LOCATION='"+ psa_recondStoreLoc + "' AND SITEID='"+ psa_siteID + "' AND BINNUM='"+ psa_recondBinNum+ "' AND CONDITIONCODE='RECOND'");
					System.out.println("*** RecondAutoReturnCustom a: "+"ITEMNUM='" + psa_itemNum + "' AND ITEMSETID='"+ psa_itemSet + "' AND LOCATION='"+ psa_recondStoreLoc + "' AND SITEID='"+ psa_siteID + "' AND BINNUM='"+ psa_recondBinNum+ "' AND CONDITIONCODE='RECOND'");
					System.out.println("*** RecondAutoReturnCustom b1: "+"psa_invbcurrbal='" + psa_invbcurrbal+",psa_recondBinCurrBal="+psa_recondBinCurrBal+",psa_recondQty="+psa_recondQty);
					MboRemote invBalremote=null;
					if(!invBalSetRemote.isEmpty() && invBalSetRemote.count()>0 ) {
						for(int i=0;(invBalremote=invBalSetRemote.getMbo(i))!=null;i++) {
							System.out.println("*** RecondAutoReturnCustom b2: "+"invBalremote.getcurrbal='" + invBalremote.getString("CURBAL"));

							invBalremote.setFieldFlag("CURBAL",MboConstants.READONLY,false);
							invBalremote.setValue("CURBAL", psa_invbcurrbal,MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
							invBalremote.setFieldFlag("CURBAL",MboConstants.READONLY,true);
							System.out.println("*** RecondAutoReturnCustom c: getCurBal:"+invBalremote.getString("CURBAL")); 
						}
						invBalSetRemote.save();
					}
					
					MboSetRemote inventorySetRemote= mboremote.getMboSet("$INVENTORY","INVENTORY", "ITEMNUM='" + psa_itemNum + "' AND ITEMSETID='"+ psa_itemSet + "' AND LOCATION='"+ psa_transitStoreLoc + "' AND SITEID='"+ psa_toSiteID+ "'");
					MboRemote inventoryremote=null;
					if(!inventorySetRemote.isEmpty() && inventorySetRemote.count()>0 ) {
						for(int i=0;(inventoryremote=inventorySetRemote.getMbo(i))!=null;i++) {
							inventoryremote.setFieldFlag("ISSUEYTD",MboConstants.READONLY,false);
							inventoryremote.setValue("ISSUEYTD", psa_issuetypeinv - psa_recondQty,MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
							inventoryremote.setValue("LASTISSUEDATE", MXServer.getMXServer().getDate(),MboConstants.NOVALIDATION_AND_NOACTION|MboConstants.NOACCESSCHECK);
							inventoryremote.setFieldFlag("ISSUEYTD",MboConstants.READONLY,true);
						}
						inventorySetRemote.save();
					}
					

					
					/*
					SqlFormat mrtsqlformat = new SqlFormat(
						mboremote.getUserInfo(),
						"INSERT INTO MATRECTRANS (ITEMNUM, TOSTORELOC, TRANSDATE, ACTUALDATE, QUANTITY, RECEIVEDUNIT, ISSUETYPE, UNITCOST, ACTUALCOST, PONUM, REJECTQTY, CONVERSION, ENTERBY, OUTSIDE, POLINENUM, ISSUE, TOTALCURBAL, OLDAVGCOST, TOBIN, TOLOT, GLDEBITACCT, GLCREDITACCT, LINECOST, CURRENCYCODE, EXCHANGERATE, CURRENCYUNITCOST, CURRENCYLINECOST, DESCRIPTION, FROMSTORELOC, FROMBIN, FROMLOT, LOADEDCOST, TAX1, TAX2, TAX3, TAX4, TAX5, PRORATED, STATUS, CURBAL, EXCHANGERATE2, LINECOST2, MRNUM, MRLINENUM,  MATRECTRANSID, SENDERSYSID, FINCNTRLID, ORGID, SITEID, COSTINFO, REFWO, ENTEREDASTASK, FROMSITEID, LINETYPE, ITEMSETID, CONDITIONCODE, FROMCONDITIONCODE, CONDRATE, LANGCODE, INSPECTEDQTY, HASLD, NEWAVGCOST, OLDTOTALBAL, ROUNDINGERR, ISPDA, SAMESLIP, RECONCILIATION, CONSIGNMENT) VALUES ('"
								+ psa_itemNum
								+ "', '"
								+ psa_recondStoreLoc
								+ "', getDate(), getDate(), "
								+ psa_recondQty
								+ ", '"
								+ psa_issueUnit
								+ "', 'TRANSFER', 0, 0, '"
								+ psa_ponum
								+ "', 0, "
								+ psa_conversion
								+ ", '"
								+ mboremote.getUserInfo().getUserName()
								+ "', "
								+ matusetransRemote.getDouble("OUTSIDE")
								+ ", '"
								+ matusetransRemote.getString("POLINENUM")
								+ "', 0, "
								+ psa_recondTotalCurrBal
								+ ", 0, '"
								+ psa_recondBinNum
								+ "', '"
								+ psa_recondLot
								+ "', '"
								+ psa_recondGLAcc
								+ "', '"
								+ psa_transitGLAcc
								+ "', 0, '"
								+ matusetransRemote.getString("CURRENCYCODE")
								+ "', "
								+ matusetransRemote.getDouble("EXCHANGERATE")
								+ ", 0, 0, '"
								+ matusetransRemote.getString("DESCRIPTION")
								+ "', '"
								+ psa_transitStoreLoc
								+ "', '"
								+ psa_toSiteIDBinNum
								+ "', '"
								+ psa_lot
								+ "', 0, 0, 0, 0, 0, 0, 0, 'COMP', "
								+ psa_recondBinCurrBal
								+ ", "
								+ matusetransRemote.getDouble("EXCHANGERATE")
								+ ", 0, '"
								+ matusetransRemote.getString("MRNUM")
								+ "', '"
								+ matusetransRemote.getString("MRLINENUM")
								+ "', (select max(matrectransid)+1 from MATRECTRANS), '"
								+ matusetransRemote.getString("SENDERSYSID")
								+ "', '"
								+ matusetransRemote.getString("FINCNTRLID")
								+ "', '"
								+ matusetransRemote.getString("ORGID")
								+ "', '"
								+ psa_siteID
								+ "', 1, '"
								+ mboremote.getString("WONUM")
								+ "', "
								+ matusetransRemote.getDouble("ENTEREDASTASK")
								+ ", '"
								+ psa_toSiteID
								+ "', '"
								+ matusetransRemote.getString("LINETYPE")
								+ "', '"
								+ psa_itemSet
								+ "', 'RECOND', 'RECOND', 1, '"
								+ matusetransRemote.getString("LANGCODE")
								+ "', 0, 0, 0, "
								+ psa_recondBinCurrBal
								+ ", 0, 0, 0, 0, 0)");
								
					psa_invbcurrbal = psa_recondBinCurrBal + psa_recondQty;
					
					SqlFormat invbsqlformat = new SqlFormat(
						mboremote.getUserInfo(),
						"UPDATE INVBALANCES SET CURBAL=" + psa_invbcurrbal
							    + " WHERE ITEMNUM='"
								+ psa_itemNum + "' AND ITEMSETID='"
								+ psa_itemSet + "' AND LOCATION='"
								+ psa_recondStoreLoc + "' AND SITEID='"
								+ psa_siteID + "' AND BINNUM='"
								+ psa_recondBinNum
								+ "' AND CONDITIONCODE='RECOND'");
					SqlFormat invsqlformat = new SqlFormat(mboremote.getUserInfo(),
						"UPDATE INVENTORY SET ISSUEYTD=" + psa_issuetypeinv
								+ "-" + psa_recondQty
								+ ", LASTISSUEDATE=getdate() WHERE ITEMNUM='"
								+ psa_itemNum + "' AND ITEMSETID='"
								+ psa_itemSet + "' AND LOCATION='"
								+ psa_transitStoreLoc + "' AND SITEID='"
								+ psa_toSiteID + "'");
					*/

				// --  Added Lot number to the queries
				/*	
				System.out.println("*** Reconauto mutsqlformat:"+mutsqlformat);
				System.out.println("*** Reconauto mrtsqlformat:"+mrtsqlformat);
				System.out.println("*** Reconauto invbsqlformat:"+invbsqlformat);
				System.out.println("*** Reconauto invsqlformat:"+invsqlformat);
				DBShortcut dbshortcut = new DBShortcut();
				try {
					dbshortcut.connect(mboremote.getUserInfo()
							.getConnectionKey());
					dbshortcut.execute(1, mutsqlformat);
					dbshortcut.execute(1, mrtsqlformat);
					dbshortcut.execute(1, invbsqlformat);
					dbshortcut.execute(1, invsqlformat);
					dbshortcut.commit();
				} catch (SQLException sqlexception) {
					System.out.println("sqlexception -->");
					sqlexception.printStackTrace();
					String[] as = { sqlexception.getMessage() };

					throw new MXApplicationException("workorder",
							"AutoReturnError", as);
				*/	
				} catch (RemoteException remoteexception) {
					System.out.println("remoteexception");
					remoteexception.printStackTrace();
					String[] as = { remoteexception.getMessage() };

					throw new MXApplicationException("workorder",
							"AutoReturnError", as);
				} catch (MXException mxexception) {
					System.out.println("mxexception");
					mxexception.printStackTrace();
					String[] as = { mxexception.getMessage() };

					throw new MXApplicationException("workorder",
							"AutoReturnError", as);
				} catch (Exception exception) {
					System.out.println("exception");
					exception.printStackTrace();
					String[] as = { exception.getMessage() };

					throw new MXApplicationException("workorder",
							"AutoReturnError", as);
				} finally {
					//dbshortcut.close();
				}
			} else {
				matusetransSetRemote.close();
				Object[] obj = { mboremote.getString("RECONDITEM") };

				throw new MXApplicationException("workorder", "NoIssue", obj);
			}
		}
	}
}
