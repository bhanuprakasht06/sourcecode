/*
 * Modification history
 * 23-06-06	HCHA	NA			Creation
 * 10-04-07	AGD	SR-087	Get the WO GL A/c rather than the work type GL A/c for capital work (cater for capital work defined WO per WO)
 * 02-05-07	LS	SR-071	Default conditioncode to 'NEW' for Linetype 'ITEM'
 */
/**
 * @author	HCHA
 * Date		Jun 23, 2006
 * Comment	 
 */
package com.psa.app.common.purchasing;

import java.rmi.RemoteException;

import psdi.app.common.purchasing.FldPurItemNum;
import psdi.app.item.ItemRemote;
import psdi.app.item.ItemSetRemote;
import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOSetRemote;
import psdi.app.workorder.WorkTypeRemote;
import psdi.app.workorder.WorkTypeSetRemote;
import psdi.mbo.*;
import psdi.server.MXServer;
import psdi.util.MXException;

/**
 * @author		HCHA
 * @class		FldPurItemNumCustom
 * @date		Jun 23, 2006
 * @function	
 */
public class FldPurItemNumCustom extends FldPurItemNum 
{

	//20061004 HCHA - Add 1 Type Segment
	//private static final String LABSERV_DEBIT_GL = "???-????-?-??-???-????-????-004";
	
	/*BCT modifications starts.
	 * COA structure change from 24 Bit to 28 Bit
	private static final String LABSERV_DEBIT_GL = "???-????-1-??-???-????-????-004";*/
	
	 private static final String LABSERV_DEBIT_GL = "???-???????-???-????-???-????-????";
	   
		/*BCT modifications ends.
		 * COA structure change from 24 Bit to 28 Bit
		 */
	/**
	 * @param arg0
	 * @throws MXException
	 * @throws RemoteException
	 */
	public FldPurItemNumCustom(MboValue arg0) 
		throws MXException,RemoteException 
	{
		super(arg0);
	}
	
//	 Begin modification SR-071
	public void action()
		throws MXException, RemoteException
	{
		super.action();
		Mbo mbo = getMboValue().getMbo();
		if(mbo.getString("linetype").equals("ITEM"))
		{
			if(getMboValue().isNull())
				mbo.setValueNull("conditioncode", 2L);
			else
			{
				MboRemote mboremote = mbo.getMboSet("ITEM").getMbo(0).getMboSet("ITEMCONDITION_FULL").getMbo(0);
				if(mboremote != null)
				{
					mbo.setValue("conditioncode", mboremote.getString("conditioncode"), 2L);
				}
			}
		}
	}
//	 End modification SR-071
	
    public void getGLDebitAcct()
    	throws MXException, RemoteException
	{
    	
    	//System.out.println("[FldPurItemNumcustom.getGLDebitAcct] Entering...");
    	Mbo mbo = getMboValue().getMbo();
    	
     	//Check for if Work Order is of Capital Work Type 
    	boolean isCapWorkType = false;
    	if(!mbo.isNull("wonum")){
        	
        	WOSetRemote woSet =(WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", mbo.getUserInfo());
            SqlFormat sqlformat = new SqlFormat(mbo.getUserInfo(), "wonum = :1 and siteid = :2");
            sqlformat.setObject(1, "WORKORDER", "WONUM", mbo.getString("wonum"));
            sqlformat.setObject(2, "WORKORDER", "SITEID", mbo.getString("siteid"));
            woSet.setWhere(sqlformat.format());
            
            if(!woSet.isEmpty())
            {
            	WORemote wo = (WORemote) woSet.getMbo(0);
    	    	String woWorkType = wo.getString("WORKTYPE");
    	    	if(woWorkType != null){
    	    		
    	    		//Get Worktype mbo
    	    		WorkTypeSetRemote worktypeSet =(WorkTypeSetRemote) MXServer.getMXServer().getMboSet("WORKTYPE", mbo.getUserInfo());
    	    		
    	            SqlFormat sqlformatWOType = new SqlFormat(mbo.getUserInfo(), "worktype = :1 and orgid = :2");
    	            sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
    	            sqlformatWOType.setObject(2, "LABTRANS", "ORGID", mbo.getString("orgid"));
    	            worktypeSet.setWhere(sqlformatWOType.format());
    	            
    	            if(!worktypeSet.isEmpty())
    	            {
    	            	WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
    	            	isCapWorkType = worktype.getBoolean("capitalwork");
    	            	if(isCapWorkType){
    	            		//Capital Type Work Order
// Begin modification SR-087
//    	            	String wotypeGlAccount = worktype.getString("glaccount");
//   	            		if(wotypeGlAccount != null){
    	            		String wotypeGlAccount = wo.getString("glaccount");
 	            			//Set WO GL Account into LabTrans Gl Debit Account
 	            			mbo.setValue("gldebitacct", wotypeGlAccount, 2L);
 	            			//System.out.println("[FldPurItemNumcustom.getGLDebitAcct] Capital Account..GL Debit Accout ="+wotypeGlAccount);
 	            			return;
//             			}
// End modification SR-087
    	            			
    	            	}
    	            	
    	            }
	            }
	        }
    	}
    	
    	//System.out.println("[FldPurItemNumcustom.getGLDebitAcct] Running super.getGLDebitAcct()...");
    	super.getGLDebitAcct();
    	
	    //Check for if it is Labor Service 	   
	    if(!mbo.isNull("itemnum")){
	        //Get item mbo
		    	ItemSetRemote itemSet =(ItemSetRemote) MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo());
		    	
		    SqlFormat sqlformatItemSet = new SqlFormat(mbo.getUserInfo(), "itemnum = :1 and itemsetid = :2");
		    sqlformatItemSet.setObject(1, "PRLINE", "ITEMNUM", mbo.getString("itemnum"));
		    sqlformatItemSet.setObject(2, "PRLINE", "ITEMSETID", mbo.getString("itemsetid"));
		    itemSet.setWhere(sqlformatItemSet.format());
		           
		    if(!itemSet.isEmpty())
		    {
		        ItemRemote item = (ItemRemote) itemSet.getMbo(0);
		        boolean isLabService = item.getBoolean("LABORSERVICE");
		        if(isLabService){
						
			        //Get current debit Glaccount
			        String curGLAccount = mbo.getString("gldebitacct");
					//System.out.println("[FldPurItemNumcustom.getGLDebitAcct]Current Debit GL Account:"+curGLAccount);
						
					if(curGLAccount!=null&&!curGLAccount.equals("")){
						GLFormat glformat = new GLFormat(LABSERV_DEBIT_GL, mbo.getString("orgid"));
						glformat.mergeString(curGLAccount);
						//System.out.println("[FldPurItemNumcustom.getGLDebitAcct]Merged GL Account:"+glformat.toDisplayString());
							
						mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
					}          		
		        }
		    }
	    }
	}
}
