/*
 * Modification history
 * 10-09-2007	AGD	SR-098	Copy DO # from popup to main screen
 */
package com.psa.app.po.virtual;

import java.rmi.RemoteException;


import psdi.app.po.virtual.ReceiptInputSet;
import psdi.app.po.virtual.ReceiptInputSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class ReceiptInputCustomSet extends ReceiptInputSet
		implements ReceiptInputSetRemote
{

	public ReceiptInputCustomSet(MboServerInterface serverinterface)
			throws MXException, RemoteException
	{
		super(serverinterface);
	}


	protected Mbo getMboInstance(MboSet receiptinputset)
			throws MXException, RemoteException
	{
		return new ReceiptInputCustom(receiptinputset);
	}

}
