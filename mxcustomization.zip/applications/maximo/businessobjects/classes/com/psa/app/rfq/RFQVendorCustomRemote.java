/*
 * Modification history
 * 15-10-2007	AGD	eRFQ		Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQVendorRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;


public interface RFQVendorCustomRemote
		extends RFQVendorRemote
{
	public abstract MboSetRemote getRFQLinesForQuotationAlt()
			throws MXException, RemoteException;


	public void copyRFQToQuotationAlt(MboSetRemote rfqlineset)
			throws MXException, RemoteException;
	
	 public abstract void checkSentCompStatus(String s)
	 		throws MXException, RemoteException;
	 
	 public abstract void checkSentStatus()
     		throws MXException, RemoteException;
}
