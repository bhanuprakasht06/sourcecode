/*
 * Modification history
 * 16-04-2007	AGD	SR-068	Set vendor date at PO and PO line levels read-only when PO is approved
 */
package com.psa.app.po;

import java.rmi.RemoteException;

import psdi.app.po.POLine;
import psdi.app.po.POLineRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboSet;
import psdi.util.MXException;

public class POLineCustom extends POLine
		implements POLineRemote
{

	public POLineCustom(MboSet mboset)
			throws MXException, RemoteException
	{
		super(mboset);
	}


   protected void setApprEditibilityFlags(boolean isreceiptcomplete, boolean setflag)
			throws MXException, RemoteException
	{
   	super.setApprEditibilityFlags(isreceiptcomplete, setflag);
		String fields[] = { "vendeliverydate" };
		setFieldFlag(fields, MboConstants.READONLY, setflag);
	}

}
