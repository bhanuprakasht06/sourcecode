/*
 * Modification history
 * 08-11-2012   WMJ     EMS-525 [RFQ]System check to ensure that at least one of the fields(FAXRFQ, FAXBRIEFRFQ, EMAILRFQ) is selected
 * 15-11-2012   LEWISS  EMS-533 [RFQ] RFQWF - New status BYPASS for buyers to handle exception RFQ scenario
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQ;
import psdi.app.rfq.RFQVendor;
import psdi.app.rfq.RFQVendorSet; //EMS-579

import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class RFQVendorCustom extends RFQVendor
implements RFQVendorCustomRemote
{

public RFQVendorCustom(MboSet rfqvendorset)
        throws MXException, RemoteException
{	
super(rfqvendorset);
}

public void init()
        throws MXException
{
super.init();

try
{
                MboRemote mboremote1 = null;

                MboSetRemote rfqremoteset = getMboSet("RFQ");
                if(rfqremoteset.count()==0)
                {
//      Get the RFQ remote
                if( ((getMboValue("rfqnum").getMbo()) != null) && ((getMboValue("rfqnum").getMbo().getName()).equalsIgnoreCase("RFQ")))
                        mboremote1 = getMboValue("rfqnum").getMbo();

                else if( ((getMboValue("rfqnum").getMbo().getOwner()) != null) && ((getMboValue("rfqnum").getMbo().getOwner().getName()).equalsIgnoreCase("RFQ")))
                        mboremote1 = getMboValue("rfqnum").getMbo().getOwner();

                else if( ((getMboValue("rfqnum").getMbo().getOwner().getOwner()) != null) && ((getMboValue("rfqnum").getMbo().getOwner().getOwner().getName()).equalsIgnoreCase("RFQ")))
                        mboremote1 = getMboValue("rfqnum").getMbo().getOwner().getOwner(); //RFQ

                else if( ((getMboValue("rfqnum").getMbo().getOwner().getOwner().getOwner()) != null) && ((getMboValue("rfqnum").getMbo().getOwner().getOwner().getOwner().getName()).equalsIgnoreCase("RFQ")))
                        mboremote1 = getMboValue("rfqnum").getMbo().getOwner().getOwner().getOwner();
                }
                else
                mboremote1 = rfqremoteset.getMbo(0);

        String status=mboremote1.getString("STATUS");

        if (!status.equalsIgnoreCase("SENT") && !status.equalsIgnoreCase("ESENT") && !status.equalsIgnoreCase("AMEND") && !status.equalsIgnoreCase("INPRG") && !status.equalsIgnoreCase("REOPEN"))
                setFieldFlag("HOLDSUBMIT", MboConstantsCustom.READONLY, true);
}
catch(RemoteException remoteexception) { }
}


/*
* Override Maximo standard code so as to only display data relevant to main quotations
*/
public MboSetRemote getRFQLinesForQuotation()
        throws MXException, RemoteException
{
SqlFormat sqlformat = new SqlFormat(this, "siteid=:siteid AND rfqnum=:rfqnum AND rfqlinenum NOT IN (SELECT rfqlinenum FROM quotationline WHERE siteid=:siteid AND rfqnum=:rfqnum AND vendor=:vendor AND alternate=0)");
MboSetRemote rfqlineset = getMboSet("$getrfqline", "rfqline", sqlformat.format());
rfqlineset.setOrderBy("rfqnum, rfqlinenum");
rfqlineset.reset();
int i = 0;
for (MboRemote rfqline; (rfqline = rfqlineset.getMbo(i)) != null; i++)
{
        if (!rfqline.isNull("storeloc"))
        {
                rfqline.setFieldFlag("quotationorderunit", MboConstants.REQUIRED, true);
                rfqline.setFieldFlag("conversion", MboConstants.REQUIRED, true);
        }
        rfqline.setValue("quotationorderunit", rfqline.getString("orderunit"), MboConstants.NOACCESSCHECK);
}
return rfqlineset;
}


/*
* Get the list of all RFQ lines, whether already selected or not : a supplier can enter many alternate quotes
*/
public MboSetRemote getRFQLinesForQuotationAlt()
        throws MXException, RemoteException
{
MboSetRemote rfqlineset = getOwner().getMboSet("rfqline");
rfqlineset.setOrderBy("rfqnum, rfqlinenum");
rfqlineset.reset();
int i = 0;
for (MboRemote rfqline; (rfqline = rfqlineset.getMbo(i)) != null; i++)
{
        if (!rfqline.isNull("storeloc"))
        {
                rfqline.setFieldFlag("quotationorderunit", MboConstants.REQUIRED, true);
                rfqline.setFieldFlag("conversion", MboConstants.REQUIRED, true);
        }
        rfqline.setValue("quotationorderunit", rfqline.getString("orderunit"), MboConstants.NOACCESSCHECK);
}
return rfqlineset;

}


/*
* Copy the selected lines as alternate quotations
*/
        public void copyRFQToQuotationAlt(MboSetRemote rfqlineset)
                throws MXException, RemoteException
        {
                if (rfqlineset.isEmpty())
                        return;
                String vendor = getString("vendor");
                int i = 0;
                for (MboRemote rfqline = null; (rfqline = rfqlineset.getMbo(i)) != null; i ++)
                {
                        if (rfqline.isSelected())
                                ((RFQLineCustomRemote) rfqline).copyRFQLinesToQuotationAlt(vendor);
                }
        }


/*
* Check to enter quotations by vendor only when status = 'SENT' or 'ESENT'
*/

public void checkSentCompStatus(String s)
throws MXException, RemoteException
{
 MboSetRemote venodrgroupset = MXServer.getMXServer().getMboSet("GROUPUSER", getUserInfo());
 SqlFormat sql2 = new SqlFormat("GROUPNAME ='VENDORS'");
 venodrgroupset.setWhere(sql2.format());
 RFQ rfq = (RFQ)getOwner();
 String status=rfq.getString("STATUS");
 String currentuser = getUserName();
 int i=0;
 boolean vendor = false;

 //Check if the user belongs to Vendor group
 for(MboRemote user = null; (user = venodrgroupset.getMbo(i)) != null; i++)
         if(user.getString("USERID").equalsIgnoreCase(currentuser))
                 vendor =true;
 //if(!status.equalsIgnoreCase("SENT") && !status.equalsIgnoreCase("ESENT") && !status.equalsIgnoreCase("FINISHED") &&!status.equalsIgnoreCase("EFINISHED") && !status.equalsIgnoreCase("REJECT-TO"))
 if(!status.equalsIgnoreCase("SENT") && !status.equalsIgnoreCase("ESENT") && !status.equalsIgnoreCase("AMEND") && !status.equalsIgnoreCase("BYPASS"))
 {
     //Object aobj[] = {
     //    "'SENT','ESENT','EFINISHED','FINISHED','REJECT-TO'"
     //};
     //throw new MXApplicationException("rfq", "cannotSelectQuotaion", aobj);
         throw new MXApplicationException("rfq", "addOnlyIfTenderOpen");
 }
 else
 {
         //if ((status.equalsIgnoreCase("FINISHED") || status.equalsIgnoreCase("EFINISHED") || status.equalsIgnoreCase("REJECT-TO")) && vendor)
         if ((status.equalsIgnoreCase("AMEND")) && vendor)
         {
         //Object aobj[] = {
         //              "'SENT','ESENT'"
         //};
         //throw new MXApplicationException("rfq", "cannotSelectQuotaion", aobj);
                 throw new MXApplicationException("rfq", "addOnlyIfTenderOpen");
         }
         else
                 return;
 }
}

public void checkSentStatus()
throws MXException, RemoteException
{

 MboSetRemote venodrgroupset = MXServer.getMXServer().getMboSet("GROUPUSER", getUserInfo());
 SqlFormat sql2 = new SqlFormat("GROUPNAME ='VENDORS'");
 venodrgroupset.setWhere(sql2.format());

 RFQ rfq = (RFQ)getOwner();
 String status=rfq.getString("STATUS");
 String currentuser = getUserName();
 int i=0;
 boolean vendor = false;
 //Check if the user belongs to Vendor group
 for(MboRemote user = null; (user = venodrgroupset.getMbo(i)) != null; i++)
         if(user.getString("USERID").equalsIgnoreCase(currentuser))
                 vendor =true;

 //if(!status.equalsIgnoreCase("SENT") && !status.equalsIgnoreCase("ESENT") && !status.equalsIgnoreCase("FINISHED") &&!status.equalsIgnoreCase("EFINISHED") && !status.equalsIgnoreCase("REJECT-TO"))
 //if(!status.equalsIgnoreCase("SENT") && !status.equalsIgnoreCase("ESENT") && !status.equalsIgnoreCase("AMEND"))
  //Start for EMS-533(added && !status.equalsIgnoreCase("BYPASS"))
 if(!status.equalsIgnoreCase("SENT") && !status.equalsIgnoreCase("ESENT") && !status.equalsIgnoreCase("AMEND") && !status.equalsIgnoreCase("BYPASS"))
 //End for EMS-533
 {
     //Object aobj[] = {
     //    "'SENT','ESENT','EFINISHED','FINISHED','REJECT-TO'"
     //};
     //throw new MXApplicationException("rfq", "cannotSelectQuotaion", aobj);
         throw new MXApplicationException("rfq", "addOnlyIfTenderOpen");
 }
 else
 {
         //if ((status.equalsIgnoreCase("FINISHED") || status.equalsIgnoreCase("EFINISHED") || status.equalsIgnoreCase("REJECT-TO")) && vendor)
         if ((status.equalsIgnoreCase("AMEND")) && vendor)
         {
         //Object aobj[] = {
         //              "'SENT','ESENT'"
         //};
         //throw new MXApplicationException("rfq", "cannotSelectQuotaion", aobj);
                 throw new MXApplicationException("rfq", "addOnlyIfTenderOpen");
         }
         else
                 return;
 }
}


//EMS-525
public void save() throws MXException, RemoteException
{	
  MboSetRemote mboSet = getThisMboSet();
  RFQVendor rfqvendor = null;
  
  if (getOwner() != null)
  { 
      MboRemote rfq = getOwner();
      String status=rfq.getString("STATUS");        

      if((status.equalsIgnoreCase("INPRG")) || (status.equalsIgnoreCase("REOPEN")))  
      {
          for (int i = 0; (rfqvendor = (RFQVendor) mboSet.getMbo(i)) != null; i++)
          {
              if(!rfqvendor.getBoolean("FAXRFQ") && !rfqvendor.getBoolean("FAXBRIEFRFQ") && !rfqvendor.getBoolean("EMAILRFQ") && !toBeDeleted())
                      throw new MXApplicationException("rfq", "noSendOptionSelected");
          }
                  super.save();
      }

  }
  else{
      System.out.println("RFQ is Null");
      super.save(); 
  }
    	 
}
//end of EMS-525

//EMS-525

}

