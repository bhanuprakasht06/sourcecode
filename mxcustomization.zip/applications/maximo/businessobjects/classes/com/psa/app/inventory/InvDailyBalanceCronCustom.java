/*
 * Created by BCT 
 * 
 * Taking the daily balance data from Inv balances 
 * and storing to daily back up table.
 * 
 * 
 */
package com.psa.app.inventory;

import psdi.server.SimpleCronTask;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;


import com.psa.custom.common.MxEmail;
import com.psa.custom.ois.MxLog;
import psdi.app.system.CrontaskParamInfo;
import psdi.iface.webservices.MBOSchemaGenerator;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.ConnectionKey;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class InvDailyBalanceCronCustom extends SimpleCronTask {

	private static CrontaskParamInfo params[];

	private int days;
	private String adminEmail;
	//private MxEmail email;
	
	protected MxLog mxLog;
	protected String eMailsub;
	private String logDirectory;
	private String alertEmailSub;
	private String invAlertEmail;

	private boolean enableLog;

	private String logFileName;
	protected static final MXLogger mxLogger = MXLoggerFactory.getLogger("maximo.integration");
	
	public InvDailyBalanceCronCustom()
	{
		super();
		 days=0;
		 adminEmail = null;
		 eMailsub=null;
		 logDirectory=null;
		 alertEmailSub=null;
		 enableLog=false;
		 logFileName=null;
		
	}
	
	
 public CrontaskParamInfo[] getParameters() throws MXException, RemoteException
 {
		params = new CrontaskParamInfo[6];
		params[0] = new CrontaskParamInfo();
		params[0].setName("LOGFILEPATH");
		params[0].setDescription("Log", "Log File Path");
		params[1] = new CrontaskParamInfo();
		params[1].setName("ADMINEMAIL");
		params[1].setDescription("Email","Administrator Email");
		params[2] = new CrontaskParamInfo();
		params[2].setName("ALERTEMAILSUBJ");
		params[2].setDescription("EmailSub","Alert Email Subject");		
		params[3] = new CrontaskParamInfo();
		params[3].setName("ENABLELOG");
		params[3].setDescription("Enable Log","Enable log output('Y' or 'N').");
		params[3].setDefault("Y");
		params[4] = new CrontaskParamInfo();
		params[4].setName("DAYS");
		params[4].setDescription("No.Of Days","No.of Days to keep the Inventory Backup");
		params[4].setDefault("0");
		params[5] = new CrontaskParamInfo();
		params[5].setName("LOGFILENAME");
		params[5].setDescription("LOGFILENAME","Log File Name");
		
		
		return params;
 }
	
 private void refreshSettings() {
        try {
        	adminEmail = getParamAsString("ADMINEMAIL");
          //  email.setAdmin(adminEmail);
            logDirectory = getParamAsString("LOGFILEPATH");
            alertEmailSub = getParamAsString("ALERTEMAILSUBJ");
            enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
            mxLog.setEnabled(enableLog);
            logFileName=getParamAsString("LOGFILENAME");
            logDirectory=logDirectory+logFileName;
            mxLog.setLogFilePath(logDirectory);
            mxLog.setLogTag(getName());
            mxLog.createLogFile();
           
            
     }
     catch(Exception e)
     {
           
     }
 }
 public void init() throws MXException {
     super.init();

    // email = new MxEmail(adminEmail);
     mxLog = new MxLog();
    
}
 private String genEmail(Exception e) {

     String emailMsg = "Date: " + new Date() + "\n";
     emailMsg += "Error in CronTask: " + getName() + "\n";
     emailMsg += "Error Message: " + e.getMessage() + "\n";
     emailMsg += "Detail:\n";
     emailMsg += e.toString() + "\n";
     StackTraceElement element[] = e.getStackTrace();
     for (int i = 0; i < element.length; i++) {
             emailMsg += "\tat " + element[i].toString() + "\n";
     }

     return emailMsg;
}	
	
 private boolean isReqParamSet() {
     if (adminEmail.equalsIgnoreCase(""))
             return false;
     if (logDirectory.equalsIgnoreCase(""))
             return false;
         return true;
}

	public void cronAction()
	{
		
		try{
			refreshSettings();
			if(isReqParamSet())
			{
				invDailyBalCron();
			}
			else
			{
				mxLogger.info("Required Parameters are not set.");
			}
			
		
		}
		catch(Exception e)
		{
			String emailContent =  genEmail(e);
			mxLog.writeLog(emailContent);
         //   email.send(alertEmailSub, emailContent);
		
		}
		
		
	}
/*
 * 17-SEP-2020: BCT Modification Starts
 * Action #BCTACT1: Oracle to SQL conversion
 *  
 */
	

	public void invDailyBalCron() throws MXException,RemoteException
	
	{	mxLog.writeLog(" Starting Daily INvbalance Cron: "+getName());
		
		DBShortcut dbShortcut = new DBShortcut();
		dbShortcut.connect(getRunasUserInfo().getConnectionKey());
	
		String dailyBalance="";
		String deleteoldrecords="";
		String deletetodaysrecords="";
		
		//#BCTACT1: For Next Val
		String insertDailyBal;
		long maxreserve=0;
					
					try {
				
				days = getParamAsInt("DAYS");
				MboSetRemote balanceSet = MXServer.getMXServer().getMboSet("INVDAILYBAL",getRunasUserInfo());
				
				 
				//balanceSet.setWhere("TO_DATE(TDATE ,'DD-MM-YY')=TO_DATE(SYSDATE,'DD-MM-YY')");
				balanceSet.setWhere("cast(TDATE as date)=cast(GETDATE() as date)");
				balanceSet.reset(); 
				if(balanceSet.count()>0)
				{
					//#BCTACT1
					//deletetodaysrecords="DELETE INVDAILYBAL WHERE TO_DATE(TDATE ,'DD-MM-YY')=TO_DATE(SYSDATE,'DD-MM-YY')";
					deletetodaysrecords="DELETE INVDAILYBAL where cast(TDATE as date)=cast(GETDATE() as date)";					
					SqlFormat delRecSql=new SqlFormat(deletetodaysrecords);	
					dbShortcut.execute(delRecSql);	
					dbShortcut.commit();
							
				}
				
				if(days>0)
				{
				//#BCTACT1
				//deleteoldrecords ="DELETE  INVDAILYBAL WHERE TO_DATE(TDATE,'DD-MM-YY')<=SYSDATE-'"+days+"'";
				deleteoldrecords ="DELETE  INVDAILYBAL WHERE format(CONVERT(DATETIME,TDATE),'dd-MM-yy')<=getdate()-'"+days+"'";					
				SqlFormat delOldRecSql=new SqlFormat(deleteoldrecords);					
				dbShortcut.execute(delOldRecSql);
				dbShortcut.commit();
				}
				mxLog.writeLog(" Taking the Daily Inventory Balances from Invbalances Table");
				
				
				/*
				 *     INVDAILY query written by BCT with LEFT OUTER JOIN   between invbalance and invcost table   
				 */
				
				//#BCTACT1
				
				/*dailyBalance ="INSERT INTO INVDAILYBAL (ITEMNUM,LOCATION,BINNUM, LOTNUM, CONDITIONCODE,CURBAL,TDATE,ORGID,SITEID,ITEMSETID , AVGCOST,INVDAILYBALID)";
				 dailyBalance =dailyBalance+" SELECT   itemnum, LOCATION  , Binnum, lotnum , conditioncode , bal, SYSDATE ,orgid , SITEID ,ITEMSETID ,  AVGcost ,INVDAILYBALIDSEQ.NEXTVAL from ( ";
				 dailyBalance =dailyBalance+" SELECT   INV.itemnum, INV.LOCATION  ,INV.BINNUM, INV.LOTNUM , INV.conditioncode , sum (nvl (INV.curbal, 0) )bal ,INV.orgid ,  INV.SITEID ,INV.ITEMSETID ,  nvl (INVC.AVGCOST , 0) AVGcost  ";
				 dailyBalance =dailyBalance+" FROM (select itemnum, LOCATION  , BINNUM , LOTNUM , CONDITIONCODE , curbal ,SITEID ,ITEMSETID , ORGID  from  INVBALANCES  WHERE LOCATION LIKE '%STORE%' ) INV  ";
				 dailyBalance =dailyBalance+" LEFT OUTER JOIN   ( select  itemnum, LOCATION  , CONDITIONCODE , AVGCOST ,SITEID ,ITEMSETID , ORGID  from  INVCOST  WHERE LOCATION LIKE '%STORE%'   ) INVC  ";
				 dailyBalance =dailyBalance+" ON   INV.ITEMNUM =INVC.ITEMNUM  AND INV.LOCATION = INVC.LOCATION  AND  INV.SITEID =INVC.siteid  AND  INV.ORGID = INVC.ORGID  AND nvl(INV.conditioncode,'NOTVALID') = nvl(INVC.CONDITIONCODE ,'NOTVALID')  ";
				 dailyBalance =dailyBalance+" WHERE  INV.LOCATION LIKE '%STORE%'   group by INV.itemnum, INV.LOCATION, INV.BINNUM, INV.LOTNUM, INV.conditioncode, INV.orgid, INV.SITEID, INV.ITEMSETID, nvl (INVC.AVGCOST , 0)  ) "; 
				
				 
				#BCTACT1
				Oracle to SQL Conversion:
				
				*/
				 //dailyBalance ="INSERT INTO INVDAILYBAL (ITEMNUM,LOCATION,BINNUM, LOTNUM, CONDITIONCODE,CURBAL,TDATE,ORGID,SITEID,ITEMSETID , AVGCOST,INVDAILYBALID)";
				 
				 /*dailyBalance =" SELECT   itemnum, LOCATION  , Binnum, lotnum , conditioncode , bal, GETDATE() TDATE ,orgid , SITEID ,ITEMSETID ,  AVGcost  from ( ";
				 dailyBalance =dailyBalance+" SELECT   INV.itemnum, INV.LOCATION  ,INV.BINNUM, INV.LOTNUM , INV.conditioncode , sum (ISNULL (INV.curbal, 0) ) BAL ,INV.orgid ,  INV.SITEID ,INV.ITEMSETID ,  ISNULL (INVC.AVGCOST , 0) AVGcost  ";
				 dailyBalance =dailyBalance+" FROM (select itemnum, LOCATION  , BINNUM , LOTNUM , CONDITIONCODE , curbal ,SITEID ,ITEMSETID , ORGID  from  INVBALANCES  WHERE LOCATION LIKE '%STORE%'  AND ITEMNUM='0100059' ) INV  ";
				 dailyBalance =dailyBalance+" LEFT OUTER JOIN   ( select  itemnum, LOCATION  , CONDITIONCODE , AVGCOST ,SITEID ,ITEMSETID , ORGID  from  INVCOST  WHERE LOCATION LIKE '%STORE%'   ) INVC  ";
				 dailyBalance =dailyBalance+" ON   INV.ITEMNUM =INVC.ITEMNUM  AND INV.LOCATION = INVC.LOCATION  AND  INV.SITEID =INVC.siteid  AND  INV.ORGID = INVC.ORGID  AND ISNULL(INV.conditioncode,'NOTVALID') = ISNULL(INVC.CONDITIONCODE ,'NOTVALID')  ";
				 dailyBalance =dailyBalance+" WHERE  INV.LOCATION LIKE '%STORE%'   group by INV.itemnum, INV.LOCATION, INV.BINNUM, INV.LOTNUM, INV.conditioncode, INV.orgid, INV.SITEID, INV.ITEMSETID, ISNULL (INVC.AVGCOST , 0)) PSA "; */

				 dailyBalance =" SELECT INV.itemnum, INV.LOCATION  ,INV.BINNUM, INV.LOTNUM , INV.conditioncode , sum (ISNULL (INV.curbal, 0) ) BAL , ";
				 dailyBalance =dailyBalance+" GETDATE() TDATE,INV.orgid , INV.SITEID ,INV.ITEMSETID ,  ISNULL (INVC.AVGCOST , 0) AVGcost  ";
				 dailyBalance =dailyBalance+" FROM INVBALANCES INV  ";
				 dailyBalance =dailyBalance+" LEFT OUTER JOIN INVCOST  INVC ";
				 dailyBalance =dailyBalance+" ON   INV.ITEMNUM =INVC.ITEMNUM  AND INV.LOCATION = INVC.LOCATION  ";
				 dailyBalance =dailyBalance+" AND  INV.SITEID =INVC.siteid  AND  INV.ORGID = INVC.ORGID  ";
				 dailyBalance =dailyBalance+" AND ISNULL(INV.conditioncode,'NOTVALID') = ISNULL(INVC.CONDITIONCODE ,'NOTVALID') ";
				 dailyBalance =dailyBalance+" WHERE  INV.LOCATION LIKE '%STORE%' ";
				 dailyBalance =dailyBalance+" group by INV.itemnum, INV.LOCATION, INV.BINNUM, INV.LOTNUM, INV.conditioncode, INV.orgid, INV.SITEID, INV.ITEMSETID, ISNULL (INVC.AVGCOST , 0) ";
				 
				 
				  MXServer mxServer = MXServer.getMXServer();
				  ConnectionKey conKey = mxServer.getSystemUserInfo().getConnectionKey();
				  Connection con = mxServer.getDBManager().getConnection(conKey);
				  
				  Statement stmt = con.createStatement();
				  ResultSet invbalResult = stmt.executeQuery(dailyBalance);	
				  

				 DBShortcut dbShortcut_idb = new DBShortcut();
				 dbShortcut_idb.connect(getRunasUserInfo().getConnectionKey());
				 MboSetRemote invDailyBalSet=MXServer.getMXServer().getMboSet("INVDAILYBAL", getRunasUserInfo());
					//System.out.println(invDailyBalSet."Test");
					   
					while(invbalResult.next())
					{		
						insertDailyBal=null;
						invDailyBalSet.addAtEnd(MboConstants.NOVALIDATION|MboConstants.NOACCESSCHECK);
						invDailyBalSet.setValue("ITEMNUM", invbalResult.getString("ITEMNUM"));
						invDailyBalSet.setValue("LOCATION", invbalResult.getString("LOCATION"));
						invDailyBalSet.setValue("BINNUM", invbalResult.getString("BINNUM"));
						invDailyBalSet.setValue("LOTNUM", invbalResult.getString("LOTNUM"));
						invDailyBalSet.setValue("CONDITIONCODE", invbalResult.getString("CONDITIONCODE"));
						invDailyBalSet.setValue("CURBAL", invbalResult.getDouble("BAL"));
						invDailyBalSet.setValue("TDATE", invbalResult.getDate("TDATE"));
						invDailyBalSet.setValue("ORGID", invbalResult.getString("ORGID"));
						invDailyBalSet.setValue("SITEID", invbalResult.getString("SITEID"));
						invDailyBalSet.setValue("ITEMSETID", invbalResult.getString("ITEMSETID"));
						invDailyBalSet.setValue("AVGCOST", invbalResult.getDouble("AVGCOST"));
						//insertDailyBal ="INSERT INTO INVDAILYBAL (ITEMNUM,LOCATION,BINNUM, LOTNUM, CONDITIONCODE,CURBAL,TDATE,ORGID,SITEID,ITEMSETID ,AVGCOST,INVDAILYBALID) ";
						//insertDailyBal= insertDailyBal+" values ('"+invbalResult.getString("ITEMNUM")+"','"+invbalResult.getString("LOCATION")+"','"+invbalResult.getString("BINNUM")+"','"+invbalResult.getString("LOTNUM")+"','"+invbalResult.getString("CONDITIONCODE")+"','"+invbalResult.getDouble("BAL")+"','"+invbalResult.getDate("TDATE")+"','"+invbalResult.getString("ORGID")+"','"+invbalResult.getString("SITEID")+"','"+invbalResult.getString("ITEMSETID")+"','"+invbalResult.getDouble("AVGCOST")+"',(select max(INVDAILYBALID)+1 from INVDAILYBAL))";			
						//SqlFormat dailybalSql=new SqlFormat(insertDailyBal);
						//System.out.println("<============X======= INVDAILY BAL CRONTASK DEBUG ===================> \n" + insertDailyBal + "\n\n\n\n");
						 
						//dbShortcut_idb.execute(dailybalSql);
						// dbShortcut_idb.commit();
						
						
					}
					//System.out.println(" ");
					//dbShortcut_idb.commit();
					 invDailyBalSet.save();
					invbalResult.close();
					stmt.close();
					//dbShortcut_idb.close();
					

				/*	  ResultSet rs = dbShortcut.executeQuery("select max(INVDAILYBALID)+1 from INVDAILYBAL"); 
//					  System.out.println("111");
					  //dbShortcut.commit();
					//  while(rs.next())
						//  maxreserve = rs.getLong(1); 
					  
					MboSetRemote maxsequence = MXServer.getMXServer().getMboSet("MAXSEQUENCE",getRunasUserInfo());
					maxsequence.setWhere("TBNAME='INVDAILYBAL'");				
					MboRemote invdailybalseq = maxsequence.getMbo(0); 
					if(maxreserve>maxsequence.getMbo(0).getLong("MAXRESERVED"))
					{
						invdailybalseq.setValue("MAXRESERVED", maxreserve);
						maxsequence.save();
					}
					
					rs.close();*/
				 	
				
	} catch (Exception e) {
		
		String emailContent = genEmail(e);
		mxLog.writeLog(emailContent);
		e.printStackTrace();
		
	
	}
	finally
	  {
		MXServer.getMXServer().getDBManager().freeConnection(getRunasUserInfo().getConnectionKey());
		mxLog.writeLog(" Exit Inventory DailyBackup Cron :");
		dbShortcut.close();
	  
	  }
/*
  * 17-SEP-2020: BCT Modification Starts
  * Action #BCTACT1: Oracle to SQL conversion
  */
	}

}
