/*
 * Modification history
 * 27-05-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.*;

import psdi.mbo.*;
import psdi.util.*;
import psdi.mbo.custapp.*;


public class BrandBatchCustom extends CustomMbo 
	implements BrandBatchCustomRemote 
{
	public void init()
	throws MXException
{
    super.init();    
}
	
	public BrandBatchCustom (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void add() 
		throws MXException, RemoteException 
	{
		super.add();
		MboRemote owner = getOwner();
		setValue("ITEMNUM", owner.getString("ITEMNUM"), 2L);
		setValue("FUNCTIONTYPE", owner.getString("FUNCTIONTYPE"), 2L);
	}	
		
	public void save() 
		throws MXException, RemoteException 
	{
		super.save();
	}
	
}
