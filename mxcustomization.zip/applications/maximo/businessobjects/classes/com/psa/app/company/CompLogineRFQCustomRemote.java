/*
 * Modification history
 * 28-09-07	AGD	NA		Creation
 */
package com.psa.app.company;

import psdi.mbo.MboRemote;

public interface CompLogineRFQCustomRemote
		extends MboRemote
{

}
