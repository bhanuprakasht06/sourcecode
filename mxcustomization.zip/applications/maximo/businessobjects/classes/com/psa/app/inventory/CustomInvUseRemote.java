package com.psa.app.inventory;

import psdi.app.inventory.InvUseRemote;


public interface CustomInvUseRemote extends InvUseRemote 
{
}
