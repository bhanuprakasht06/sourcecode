/*
 * Modification history
 * 10-09-2007	AGD	SR-098	Copy DO # from popup to main screen
 * 26-10-2007	AGD	DR-053	Prevent duplicate check on packing slip and thereby avoid repeated warnings
 * 01-03-18		Comm-IT		Batch Tracking
 */
package com.psa.app.po.virtual;

import java.rmi.RemoteException;

import psdi.app.po.virtual.ReceiptInput;
import psdi.app.po.virtual.ReceiptInputRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;


public class ReceiptInputCustom extends ReceiptInput
implements ReceiptInputRemote
{

	public ReceiptInputCustom(MboSet receiptinputset)
		throws MXException, RemoteException
	{
		super(receiptinputset);
	}


	public MboRemote createReceipt(MboSetRemote receiptset)
		throws MXException, RemoteException
	{
		//Begin modification DR-053 - Empty the packing slip before Maximo copies it and set it again ourselves to by-pass validation
		String packingslip = null;
		if (!isNull("packingslipnum"))
		{
			packingslip = getString("packingslipnum");
			setValueNull("packingslipnum", MboConstants.NOVALIDATION);
		}
		MboRemote receipt = super.createReceipt(receiptset);
		//if (receipt instanceof ServRecTransRemote && !isNull("packingslipnum"))
		//	receipt.setValue("packingslipnum", getString("packingslipnum"), MboConstants.NOACCESSCHECK);
		if (packingslip != null)
			receipt.setValue("packingslipnum", packingslip, MboConstants.NOVALIDATION);
		//End modification DR-053
		
		//++COMM-IT - Batch Tracking Customization
		MboRemote owner = getOwner();
		String name = owner.getName();
		if (owner != null)
		{			
			if ((name.equals("PO")) && ("ITEM".equalsIgnoreCase(receipt.getString("LINETYPE"))) && ("RECEIPT".equalsIgnoreCase(receipt.getString("ISSUETYPE"))))
			{
				String itemnum = receipt.getString("ITEMNUM");
				MboSetRemote itemOrgInfoSetRemote = getMboServer().getMboSet("ITEMORGINFO", getUserInfo());
				itemOrgInfoSetRemote.setWhere("itemnum='" +itemnum+ "' and category='STK'");
				itemOrgInfoSetRemote.reset();
				if(!itemOrgInfoSetRemote.isEmpty())
				{
					MboSetRemote autoKeySetRemote = getMboServer().getMboSet("AUTOKEY", getUserInfo());
					autoKeySetRemote.setWhere("autokeyname='BATCHNUM'");
					autoKeySetRemote.reset();
					if(!autoKeySetRemote.isEmpty())
					{
						String keyvalue = Integer.toString(autoKeySetRemote.getMbo(0).getInt("SEED"));
						receipt.setValue("BATCHNUM", keyvalue, 2L);	
						receipt.setFieldFlag("BATCHNUM", 7L, true);
					}
					autoKeySetRemote.getMbo(0).setValue("SEED", autoKeySetRemote.getMbo(0).getInt("SEED")+1);
					
					autoKeySetRemote.save();
					autoKeySetRemote.commit();
					autoKeySetRemote.close();
					autoKeySetRemote.clear();				
				}				
				itemOrgInfoSetRemote.commit();
				itemOrgInfoSetRemote.close();
				itemOrgInfoSetRemote.clear();
			}
		}	
		//--COMM-IT - Batch Tracking Customization
				
		return receipt;
	}
	
	//++COMM-IT - Batch Tracking Customization
	public MboRemote createReturnReceipt(MboSetRemote targetSet)
			throws MXException, RemoteException
	{
		MboRemote newReceipt = super.createReturnReceipt(targetSet);
		
		MboSetRemote receiptSetRemote = getMboSet("$receiptRef","MATRECTRANS","matrectransid=" +getLong("matrectransid")+ "");
		if (!receiptSetRemote.isEmpty())
		{
			newReceipt.setValue("BATCHNUM", receiptSetRemote.getMbo(0).getString("BATCHNUM"), 11L);
			newReceipt.setFieldFlag("BATCHNUM", 7L, true);
		}		
		return newReceipt;
	}
	//--COMM-IT - Batch Tracking Customization
	
}
