package com.psa.app.rfq;

import java.rmi.RemoteException;

import com.psa.custom.common.MboConstantsCustom;

import com.psa.app.rfq.QuotationLineCustom;
import psdi.app.rfq.QuotationLine;
import psdi.app.rfq.QuotationLineRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboSet;
import psdi.util.MXException;

import psdi.common.action.ActionCustomClass;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.security.UserInfo;
import psdi.server.MXServer;

public class TotalQuotationRecalculate
implements ActionCustomClass
{
	private static final MXLogger mxLogger = MXLoggerFactory.getLogger("maximo.application.RFQ");
	
	public TotalQuotationRecalculate() {
	}

	public void applyCustomAction(MboRemote mboremote, Object aobj[])
	throws MXException, RemoteException
	{

		mxLogger.debug("QUOTATIONLINERFQTOTALQUOTATION Start");

		//get the mboset of RFQ to POLINE RFQVendor DB Relationship
		//Commented off as records retrieve is for QuotationLineCustom and not QuotationLine somehow. Hit some QuotationLineCustom error on 10th June 2015
		
		MboSetRemote quotationLineSet = MXServer.getMXServer().getMboSet("QUOTATIONLINE", mboremote.getUserInfo());
		SqlFormat sql = new SqlFormat("rfqnum=:1 AND siteid=:2 AND vendor=:3");
		sql.setObject(1, "quotationline", "rfqnum", mboremote.getString("rfqnum"));
		sql.setObject(2, "quotationline", "siteid", mboremote.getString("siteid"));
		sql.setObject(3, "quotationline", "vendor", mboremote.getString("vendor"));
		//System.out.println("QUOTATIONLINERFQTOTALQUOTATION QUOTATIONLINE SQL Output :["+sql+"]");
		quotationLineSet.setWhere(sql.format());
		mxLogger.debug("QUOTATIONLINERFQTOTALQUOTATION QuotationLine MBO Count: ["+quotationLineSet.count()+"]");	
		double totalqtn = 0.0;
		MboRemote quote= null;
		for(int i=0; (quote=quotationLineSet.getMbo(i)) != null; i++)
				totalqtn += quote.getDouble("linecost");
				
				
		MboSetRemote rfqvendorset = MXServer.getMXServer().getMboSet("RFQVENDOR", mboremote.getUserInfo());
		SqlFormat sql2 = new SqlFormat("rfqnum=:1 AND siteid=:2 AND vendor=:3");
		sql2.setObject(1, "RFQVENDOR", "rfqnum", mboremote.getString("rfqnum"));
		sql2.setObject(2, "RFQVENDOR", "siteid", mboremote.getString("siteid"));
		sql2.setObject(3, "RFQVENDOR", "vendor", mboremote.getString("vendor"));
		//System.out.println("QUOTATIONLINERFQTOTALQUOTATION RFQVENDOR SQL Output :["+sql2+"], Total Quotation :["+totalqtn+"]");
		rfqvendorset.setWhere(sql2.format());
		mxLogger.debug("QUOTATIONLINERFQTOTALQUOTATION RFQVENDOR MBO Count: ["+rfqvendorset.count()+"]");	
		int i=0;
		/**
		* Commented to test Select Query
		**/
		for(MboRemote rfqvendor = null; (rfqvendor=rfqvendorset.getMbo(i)) != null;i++)
		{
			rfqvendor.setValue("TOTALQUOTATIONAMT",totalqtn,MboConstantsCustom.DBSET);
		}
		rfqvendorset.save();
		rfqvendorset.close();
		/**/
		
		
		/**
		** Change to use SQLFORMAT as hit initializing issue with QuotationLineCustom.java
		*
		* MboSetRemote rfqQuotationLine = mboremote.getMboSet("QUOTATIONLINERFQTOTALQUOTATION");

		int i = 0;//counter
		double totalquo = 0.0D;//variable to store total quotation
		mxLogger.debug("QUOTATIONLINERFQTOTALQUOTATION MBO Count: ["+rfqQuotationLine.count()+"]");		

		//sum up line cost received in quotation line
		for (MboRemote rfqQuo = null; (rfqQuo = rfqQuotationLine.getMbo(i)) != null; i ++)
		{
		    mxLogger.debug("QUOTATIONLINERFQTOTALQUOTATION For Loop: ["+i+"]");	
			String rfqnum=rfqQuo.getString("RFQNUM");
            String vendor = rfqQuo.getString("VENDOR");
            String siteid=rfqQuo.getString("SITEID");
			mxLogger.debug("QUOTATIONLINERFQTOTALQUOTATION: RFQNum:["+rfqnum+"], RFQ Vendor:["+vendor+"], RFQSiteId:["+siteid+"] .");	
			totalquo = totalquo + rfqQuo.getDouble("LINECOST");
			
		}
		
		//set value for received qty in POLINE
		mboremote.setValue("TOTALQUOTATIONAMT",totalquo,MboConstantsCustom.DBSET);
		**/
		
		mxLogger.debug("QUOTATIONLINERFQTOTALQUOTATION End. TOTALQUOTATIONAMT:["+totalqtn+"].");	
		

	}
}
