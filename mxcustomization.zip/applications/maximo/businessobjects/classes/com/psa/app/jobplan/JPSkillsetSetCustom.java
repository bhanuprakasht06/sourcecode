package com.psa.app.jobplan;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.custapp.CustomMboSet;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.app.jobplan.JobPlanRemote;

public class JPSkillsetSetCustom extends CustomMboSet 
	implements JPSkillsetSetCustomRemote 
{
	public JPSkillsetSetCustom (MboServerInterface mboserverinterface) 
		throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}
	
	protected Mbo getMboInstance(MboSet mboset) 
		throws MXException, RemoteException
	{
		return (new JPSkillsetCustom(mboset));
	}
	
	public void canAdd()
			throws MXException
    {
	    super.canAdd();
	    try
	    {
	        MboRemote JPRemote = getOwner();
	        if (JPRemote == null)
	        {
	        	if (getMbo(0) != null)
	        	{
	        		JPRemote = getMbo(0).getMboSet("JOBPLAN").getMbo(0);
	        	}
	        }
	        if (JPRemote != null && JPRemote instanceof JobPlanRemote)
	        {
	        	String JPStatus = JPRemote.getString("STATUS");
	        	if(JPStatus.equalsIgnoreCase("ACTIVE") || JPStatus.equalsIgnoreCase("INACTIVE") || JPStatus.equalsIgnoreCase("CANCEL") || JPStatus.equalsIgnoreCase("REVISED"))
	        		throw new MXApplicationException("jspmessages", "table_cannotadd");
	        }
	    }
	    catch(RemoteException t)
	    {
	        t.printStackTrace();
	    }
	}
}
