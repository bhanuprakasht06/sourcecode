/*
 * Modification history
 * 28-09-2007	LES	eRFQ		Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQRemote;
import psdi.app.rfq.RFQVendorSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class RFQVendorCustomSet extends RFQVendorSet
{
	public RFQVendorCustomSet(MboServerInterface mboserverinterface)
			throws MXException, RemoteException
	{
		super(mboserverinterface);
	}


	protected Mbo getMboInstance(MboSet rfqvendorset)
			throws MXException, RemoteException
	{
		return new RFQVendorCustom(rfqvendorset);
	}


	/*
	 * Do not throw error if status is 'SENT'
	 */
	public void canAdd()
			throws MXException
	{
		try
		{
			super.canAdd();
		}
		catch (MXApplicationException e)
		{
			try
			{
				RFQRemote rfqremote = (RFQRemote) getOwner();
				if (!rfqremote.getString("STATUS").equalsIgnoreCase("SENT"))
					throw e;
			}
			catch (RemoteException remoteexception)
			{
				remoteexception.printStackTrace();
			}
		}
	}

}
