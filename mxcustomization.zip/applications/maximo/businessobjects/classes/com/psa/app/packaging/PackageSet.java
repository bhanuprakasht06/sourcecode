// Decompiled by DJ v3.0.0.63 Copyright 2002 Atanas Neshkov  Date: 8/16/2009 11:04:05 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CustomMboSet.java

package com.psa.app.packaging;

import java.rmi.RemoteException;
import psdi.mbo.*;
import psdi.util.MXException;

// Referenced classes of package psdi.mbo.custapp:
//            CustomMbo, CustomMboSetRemote

public class PackageSet extends MboSet
    implements PackageSetRemote
{

    public PackageSet(MboServerInterface ms)
        throws MXException, RemoteException
    {
        super(ms);
    }

    protected Mbo getMboInstance(MboSet ms)
        throws MXException, RemoteException
    {
        return new Package(ms);
    }
}