/*
 * Modification history
 * 06-10-06	HCHA	Creation
 * 20-04-08 HAM 	DR-061  When saving receipt, commit DB (PO & POLINE) after maximo commits 
 */
package com.psa.app.inventory;

import java.rmi.RemoteException;
import java.sql.SQLException;

import psdi.app.inventory.MatRecTransSet;
import psdi.app.inventory.MatRecTransSetRemote;
import psdi.mbo.DBShortcut;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.txn.MXTransaction;
import psdi.util.MXException;


/**
 * @author		HCHA
 * @class		MatRecTransCustomSet
 * @date		Oct 6, 2006
 * @function	
 */
public class MatRecTransCustomSet extends MatRecTransSet 
implements MatRecTransSetRemote
{

/**
 * @param arg0
 * @throws MXException
 * @throws RemoteException
 */
public MatRecTransCustomSet(MboServerInterface arg0) throws MXException,
		RemoteException 
{
	super(arg0);	
}

protected Mbo getMboInstance(MboSet mboset)
    throws MXException, RemoteException
{
    return new MatRecTransCustom(mboset);
}
//----------Start----------Comm-IT--------Commented during Maximo 7.6 Phase II
// Begin modification DR-061
/*public void fireEventsAfterDBCommit(MXTransaction mxtransaction)
throws MXException, RemoteException
{
	super.fireEventsAfterDBCommit(mxtransaction);
	
	//Update via DBShortcut all the PO lines and PO
	if(getMbo(0) != null)
	{
		
    	int count=0; 	
    	MboRemote temp=null;
    	for(int i=0; (temp=getMbo(i)) != null;i++)
    	{
    		if((!temp.getString("ISSUETYPE").equals("TRANSFER")) && (!temp.getString("STATUS").equals("WINSP")))
    		{
	    		MboSetRemote polineset = temp.getMboSet("POLINE");
		    	SqlFormat sqlformat = new SqlFormat("ponum=:1 AND siteid=:2");
		    	sqlformat.setObject(1,"poline","ponum",temp.getString("ponum"));
		    	sqlformat.setObject(2,"poline","ponum",temp.getString("siteid"));
		    	
		    	polineset.setWhere(sqlformat.format());
		    	MboRemote poline = null;
				for(int j=0;(poline = polineset.getMbo(j)) != null;j++)
				{
					double receivedqty=0;
					double orderqty = 0;
					double rejectedqty=0;
					double unitcost=0;
					double linecost=0;
					int recpcomp=0;
					receivedqty = calculateReceivedQty(poline.getString("ponum"),poline.getLong("polinenum"));
					rejectedqty = (-1) * (calculateRejectedQty(poline.getString("ponum"),poline.getLong("polinenum")));
					orderqty = poline.getDouble("orderqty");
					unitcost = poline.getDouble("unitcost");
					linecost = unitcost * receivedqty;
					if(receivedqty >= orderqty)
					{
						recpcomp = 1;
					}
					else
					{
						recpcomp = 0;
						count++;   //if it gets counted, receipt is not complete
					}				
					UserInfo userinfo = poline.getUserInfo();
					DBShortcut dbshortcut = new DBShortcut();
					try
					{
						dbshortcut.connect(userinfo.getConnectionKey());
						// update poline table with new calculated values
						sqlformat = new SqlFormat(userinfo, "UPDATE POLINE SET receiptscomplete=:1, receivedqty=:2, rejectedqty=:3, receivedunitcost=:4, receivedtotalcost=:5  WHERE polinenum =:6 AND ponum=:7 AND siteid=:8");
						sqlformat.setInt(1, recpcomp);
						sqlformat.setDouble(2, receivedqty);
						sqlformat.setDouble(3, rejectedqty);
						sqlformat.setDouble(4, unitcost);
						sqlformat.setDouble(5, linecost);
						
						sqlformat.setLong(6, poline.getLong("polinenum"));
						sqlformat.setObject(7, "poline", "ponum", poline.getString("ponum"));
						sqlformat.setObject(8, "poline", "siteid", poline.getString("siteid"));
		
						dbshortcut.execute(dbshortcut.UPDATE, sqlformat);
						dbshortcut.commit();
					}
					catch (SQLException sqle)
					{
						try {
							dbshortcut.rollBack();
						}
						catch (Exception e) { 
							// Do nothing
						}
					}
					
					finally
					{
						try {
							dbshortcut.close();
						}
						catch (Exception e) {
							// Do nothing
						}
					}
				}
    		}
    	}
    	    	
    	MboSetRemote poset = getMbo(0).getMboSet("PO");
    	MboRemote po;
    	for(int i=0; (po=poset.getMbo(i)) != null; i++)
    	{
    		UserInfo userinfo = po.getUserInfo();
			DBShortcut dbshortcut = new DBShortcut();
			try
			{
				String receiptstatus=null;
	    		if(count > 0)
	    			receiptstatus = "PARTIAL";
	        	else
	        		receiptstatus = "COMPLETE";
	        	
				dbshortcut.connect(userinfo.getConnectionKey());
				//updating PO table for the receipt status
				SqlFormat sqlformat = new SqlFormat(userinfo, "UPDATE PO SET receipts=:1 WHERE ponum=:2 AND siteid=:3");
				sqlformat.setObject(1,"po","receipts", receiptstatus);
						
				sqlformat.setObject(2, "po", "ponum", po.getString("ponum"));
				sqlformat.setObject(3, "po", "siteid", po.getString("siteid"));
	
				dbshortcut.execute(dbshortcut.UPDATE, sqlformat);
				dbshortcut.commit();
			}
			catch (SQLException sqle)
			{
				try {
					dbshortcut.rollBack();
				}
				catch (Exception e) { 
					// Do nothing
				}
			}
			
			finally
			{
				try {
					dbshortcut.close();
				}
				catch (Exception e) {
					// Do nothing
				}
			}
    	}
	}
}


private double calculateReceivedQty(String ponum, long polinenum)
	throws MXException, RemoteException
{
	double receivedqty = 0;
	MboRemote receipt = null;
	for (int i=0; (receipt = getMbo(i)) != null;i ++)
		if ((receipt.getString("ponum").equals(ponum)) && (receipt.getLong("polinenum") == polinenum))
			if((receipt.getString("ISSUETYPE").equals("RECEIPT") && receipt.getString("STATUS").equals("COMP")) || receipt.getString("ISSUETYPE").equals("RETURN"))
				receivedqty = receivedqty + receipt.getDouble("receiptquantity");
	return receivedqty;
}

private double calculateRejectedQty(String ponum, long polinenum)
throws MXException, RemoteException
{
	double rejectedqty = 0;
	MboRemote receipt = null;
	for (int i=0; (receipt = getMbo(i)) != null;i ++)
		if ((receipt.getString("ponum").equals(ponum)) && (receipt.getLong("polinenum") == polinenum))
			if(receipt.getString("ISSUETYPE").equals("RETURN"))
				rejectedqty = rejectedqty + receipt.getDouble("receiptquantity");
return rejectedqty;
}*/
// End modification DR-061

//----------End----------Comm-IT--------Commented during Maximo 7.6 Phase II
}
