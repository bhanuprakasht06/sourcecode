/*
 * Modification history
 * 11-12-06	LES	NA			Creation
 * 10-04-07	AGD	SR-087	Get the WO GL A/c rather than the work type GL A/c for capital work (cater for capital work defined WO per WO)
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.item.ItemRemote;
import psdi.app.item.ItemSetRemote;
import psdi.app.rfq.FldRFQLineItemNum;
import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOSetRemote;
import psdi.app.workorder.WorkTypeRemote;
import psdi.app.workorder.WorkTypeSetRemote;
import psdi.mbo.GLFormat;
import psdi.mbo.Mbo;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;

/**
 * @author		LS
 * @class		FldRFQLineItemNumCustom
 * @date		Dec 11, 2006
 * @function	
 */

public class FldRFQLineItemNumCustom extends FldRFQLineItemNum 
{
	private static final String LABSERV_DEBIT_GL = "???-????-1-??-???-????-????-004";

	public FldRFQLineItemNumCustom(MboValue mbovalue) 
	throws MXException, RemoteException 
	{
		super(mbovalue);
	}

	public void getGLDebitAcct()
	throws MXException, RemoteException
	{
	
		//System.out.println("[FldPurItemNumcustom.getGLDebitAcct] Entering...");
		Mbo mbo = getMboValue().getMbo();
		
	 	//Check for if Work Order is of Capital Work Type 
		boolean isCapWorkType = false;
		//Start -- Converted to Automation Script in Maximo 7.6
		/*if(!mbo.isNull("wonum"))
		{
	    	
	    	WOSetRemote woSet =(WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", mbo.getUserInfo());
	        SqlFormat sqlformat = new SqlFormat(mbo.getUserInfo(), "wonum = :1 and siteid = :2");
	        sqlformat.setObject(1, "WORKORDER", "WONUM", mbo.getString("wonum"));
	        sqlformat.setObject(2, "WORKORDER", "SITEID", mbo.getString("siteid"));
	        woSet.setWhere(sqlformat.format());
	        
	        if(!woSet.isEmpty())
	        {
	        	WORemote wo = (WORemote) woSet.getMbo(0);
		    	String woWorkType = wo.getString("WORKTYPE");
		    	if(woWorkType != null){
		    		
		    		//Get Worktype mbo
		    		WorkTypeSetRemote worktypeSet =(WorkTypeSetRemote) MXServer.getMXServer().getMboSet("WORKTYPE", mbo.getUserInfo());
		    		
		            SqlFormat sqlformatWOType = new SqlFormat(mbo.getUserInfo(), "worktype = :1 and orgid = :2");
		            sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
		            sqlformatWOType.setObject(2, "LABTRANS", "ORGID", mbo.getString("orgid"));
		            worktypeSet.setWhere(sqlformatWOType.format());
		            
		            if(!worktypeSet.isEmpty())
		            {
		            	WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
		            	isCapWorkType = worktype.getBoolean("capitalwork");
		            	if(isCapWorkType){
		            		//Capital Type Work Order
//		            	 Begin modification SR-087
//		            		String wotypeGlAccount = worktype.getString("glaccount");
//		            		if(wotypeGlAccount != null){
	    	            		String wotypeGlAccount = wo.getString("glaccount");
		            			//Set WO GL Account into LabTrans Gl Debit Account
		            			mbo.setValue("gldebitacct", wotypeGlAccount, 2L);
		            			//System.out.println("[FldPurItemNumcustom.getGLDebitAcct] Capital Account..GL Debit Accout ="+wotypeGlAccount);
		            			return;
//		            		}
//	End modification SR-087
		            			
		            	}
		            	
		            }
	            }
	        }
		}*/
		//End -- Converted to Automation Script in Maximo 7.6
		
		//System.out.println("[FldPurItemNumcustom.getGLDebitAcct] Running super.getGLDebitAcct()...");
		super.getGLDebitAcct();
		
		//Start -- Converted to Automation Script in Maximo 7.6
	    //Check for if it is Labor Service 	   
	    /*if(!mbo.isNull("itemnum"))
	    {
	        //Get item mbo
		    	ItemSetRemote itemSet =(ItemSetRemote) MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo());
		    	
		    SqlFormat sqlformatItemSet = new SqlFormat(mbo.getUserInfo(), "itemnum = :1 and itemsetid = :2");
		    sqlformatItemSet.setObject(1, "PRLINE", "ITEMNUM", mbo.getString("itemnum"));
		    sqlformatItemSet.setObject(2, "PRLINE", "ITEMSETID", mbo.getString("itemsetid"));
		    itemSet.setWhere(sqlformatItemSet.format());
		           
		    if(!itemSet.isEmpty())
		    {
		        ItemRemote item = (ItemRemote) itemSet.getMbo(0);
		        boolean isLabService = item.getBoolean("LABORSERVICE");
		        if(isLabService){
						
			        //Get current debit Glaccount
			        String curGLAccount = mbo.getString("gldebitacct");
					//System.out.println("[FldPurItemNumcustom.getGLDebitAcct]Current Debit GL Account:"+curGLAccount);
						
					if(curGLAccount!=null&&!curGLAccount.equals("")){
						GLFormat glformat = new GLFormat(LABSERV_DEBIT_GL, mbo.getString("orgid"));
						glformat.mergeString(curGLAccount);
						//System.out.println("[FldPurItemNumcustom.getGLDebitAcct]Merged GL Account:"+glformat.toDisplayString());
							
						mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
					}          		
		        }
		    }
	    }*/
	  //End -- Converted to Automation Script in Maximo 7.6
	}
}
