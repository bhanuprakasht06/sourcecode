package com.psa.app.psa_edp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringEscapeUtils;

import com.ibm.icu.util.StringTokenizer;
import com.psa.custom.common.MxEmail;

import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class PSA_EDPCronTaskAdhoc extends SimpleCronTask

{
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	private String adminEmailId;
    private MxEmail email;
    private static final String SUBJECT = "[EMS-EDP] Error: Error occured in EDP Cron.";
	public PSA_EDPCronTaskAdhoc() {

	}
	
	/*
	  * 
	  * 06-11-2020 - added the below to fix issue that popped when user tries changing the parameter values from Application.
	  * <START>
	  * 
	  */
	
	 private static CrontaskParamInfo params[];
	 
	 static {
             
             params = null;
             params = new CrontaskParamInfo[5];
             
            params[0] = new CrontaskParamInfo();
     		params[0].setName("Destination_Path");
     		params[0].setDefault("");
     		
     		params[1] = new CrontaskParamInfo();
     		params[1].setName("Script_excution_Path");
     		params[1].setDefault("");
     		
     		params[2] = new CrontaskParamInfo();
     		params[2].setName("ALERTEMAIL");
     		params[2].setDefault("");
     		
     		params[3] = new CrontaskParamInfo();
     		params[3].setName("Adhoc_Queries_File");
     		params[3].setDefault("psa_edp_adhoc.csv");

     		params[4] = new CrontaskParamInfo();
     		params[4].setName("Date_Format");
     		params[4].setDefault("yyyyMMddhh");
   
     }
	 public CrontaskParamInfo[] getParameters() throws MXException, RemoteException 
	 {
		return params;
	 }

	 /*
	  * 
	  * 06-11-2020 - added the below to fix issue that popped when user tries changing the parameter values from Application.
	  * <END>
	  * 
	  */
	 
	public void cronAction() {
		integrationLogger.debug("*******************CRON EDP CODE STARTED***********************");
		MboSetRemote psaedpset;
		MboRemote psaedp;
		SimpleDateFormat formatter = null;
		try {
			ArrayList<String> ar = new ArrayList<String>();
			File csvFile = new File(getParamAsString("Script_excution_Path")+getParamAsString("Adhoc_Queries_File"));
			BufferedReader br = new BufferedReader(new FileReader(csvFile));
			
			String csvline = "";
			StringTokenizer st = null;
			int lineNumber = 0;
			int tokenNumber = 0;
			String headers = br.readLine();
			adminEmailId=getParamAsString("ALERTEMAIL");
			email.setAdmin(adminEmailId);
			
			while ((csvline = br.readLine()) != null){

				String[] arr = csvline.split(",(?=(?:[^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)");
				//for the first line it'll print
				System.out.println(arr[0]+" " + arr[2]);
				
				String path = "";
				String FileName = "";
				String FileName1 = "";
				String query = "";
				String header = "";
				String gilePath = "";
				String fpath[]= null;
				String dateFormat = "";
				Process p= Runtime.getRuntime().exec("ps -ef");
				try {
					
					gilePath = arr[2];
					if(gilePath!=null && !gilePath.equals("")){
						fpath= gilePath.split("_");
						if(fpath!=null && !fpath.equals("")){
							dateFormat = fpath[fpath.length-1];
						}
						
						if (dateFormat == null || dateFormat == "") {
							formatter = new SimpleDateFormat("yyyyMMddhh");
						} else {
							formatter = new SimpleDateFormat(dateFormat);
						}
						Date date = new Date();
						
						String dateVal = formatter.format(date);						
						if (getParamAsString("Date_Format").equals("")) {
							gilePath = gilePath.replaceAll(dateFormat, dateVal);
						}
						else {
							gilePath = gilePath.replaceAll(dateFormat, getParamAsString("Date_Format"));
						}
						
					}
				
					
					integrationLogger.debug("gilePath ::>>>" + gilePath);
					
					
					path=getParamAsString("Script_excution_Path")+"move.sh";
					FileName = gilePath+"_1.dsv";
					FileName1 = gilePath+".dsv";
					integrationLogger.debug("filename is "+FileName);
					integrationLogger.debug("FileName1 is "+FileName1);
					List<String> cmdList = new ArrayList<String>();
					query = arr[1];
					
					
					
					String fQuery = query.replace("\"","");
					String fQuery1 = "";
					String fQuery2 = "";

						integrationLogger.debug("final fQuery1 ::>>>" + fQuery);
						
						integrationLogger.debug("final fQuery2 ::>>>" + fQuery1);
						
						integrationLogger.debug("final fQuery3 ::>>>" + fQuery2);

					
					header = arr[3];
					cmdList.add("sh");
					integrationLogger.debug("desit ::>>>"+path);
					cmdList.add(path);
					cmdList.add(FileName1);
					cmdList.add(fQuery);
					cmdList.add(FileName);
					cmdList.add(header);
					cmdList.add(fQuery1);
					cmdList.add(fQuery2);
					cmdList.add(getParamAsString("Destination_Path"));
					
					//move.sh FileName1 (1)				fQuery 	(2)				FileName (3)				header(4)		fQuery1(5) fQuery2(6) 	DestinationPath (7)
					//move.sh COMPANIES_yyyyMMddhh.dsv companiesQueryValue COMPANIES_yyyyMMddhh_1.dsv 	companiesHeader 	""		 	""			/opt/psa/data/rw/emsscp/outgoing/edp
					
					integrationLogger.debug("********before start btach script***");
					//ProcessBuilder pb = new ProcessBuilder(cmdList);
					ProcessBuilder pb = new ProcessBuilder(cmdList);
					
					try
					{
					p = pb.start();
					integrationLogger.debug("*******After batch script*******");
					p.waitFor();
					integrationLogger.debug("*******After wait batch script*******");
					}
					catch (Exception e) {
						throw e;
					}
					
					integrationLogger.debug("*****************SUCCESFULLY EXECUTED BATCH SCRIPT**********************");
					BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
					String line;

					while ((line = reader.readLine()) != null) {
						integrationLogger.debug(line);
					}
					reader.close();

					integrationLogger.debug("*******************CODE TO READ CSV FILE*********************************");
					
					
				}catch (Exception e) {
					// TODO Auto-generated catch block
					integrationLogger.debug("*********************inside catch%%%***************************");
					e.printStackTrace();
					
					//email.send(SUBJECT+" For Table : "+psaedp.getString("TABLENAME"),e.getMessage());
					
					String emailContent = genEmail(e);
		            email.send(SUBJECT+" For Table : "+gilePath,emailContent );
				}
				lineNumber++;
				integrationLogger.debug("*********************completed***************************");

			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private String genEmail(Exception e){
        System.out.println("--start of genEmail()--");

        //Form Email Message
        String emailMsg = "Date: " + new Date()+"\n";
        emailMsg += "Error in CronTask: "+getName()+ "\n";
        emailMsg+="Error Message: "+ e.getMessage()+"\n";
        emailMsg+="Detail:\n";
        emailMsg+=e.toString()+"\n";
        StackTraceElement element[] = e.getStackTrace();
        for(int i=0; i< element.length; i++){
                emailMsg+="\tat "+ element[i].toString()+"\n";
        }
        System.out.println("--end of genEmail()--");

        return emailMsg;
        }
	
	public void init() {
        email = new MxEmail(adminEmailId);
     

    }
}
