/*
 * Modification history
 * 17-07-013 Creation
 *   
 */
package com.psa.app.inventory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import com.psa.custom.common.MxEmail;
import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskParamInfo;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.ConnectionKey;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class ReportInvBalCustom extends SimpleCronTask
{

	public ReportInvBalCustom()
	{
		System.out.println("---inside ReportInvBalCustom constructor");
		logfile_Param = null;
		storeroom_Param=null;
		query_Param=null;
		userInfo = null; 
		logger = MXLoggerFactory.getLogger("maximo.application.INVENTOR");
		checkParanNull=false;
	}
	

	
	public void start()
	{
		System.out.println("----- inside Start ----------");
		try
		{
			logger.info(getName() + " Start");
		}
		catch (Exception e)
		{
			logger.error(getName() + " " + e.getMessage(), e);
		}
	}
	
	
	public void stop()
	{
		System.out.println("--------- inside Stop -------------");
		logger.info(getName() + " Stop");
		if (mxLog.isEnabled())
		{
			try
			{
				mxLog.writeLog(getName() + " Stop");
				mxLog.closeLogFile();
			}
			catch (Exception e)
			{
				logger.error(getName() + " " + e.getMessage(), e);
			}
		}
		
	}
	
	public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
	{
		System.out.println("--------- inside setCronInstance ---------");
		try
		{
			super.setCrontaskInstance(crontaskinstanceremote);
		}
		catch (Exception e)
		{
			logger.error(getName() + " " + e.getMessage(), e);
		}
	}
	
	public CrontaskParamInfo[] getParameters() throws MXException,RemoteException
	{
	   System.out.println("---------inside  CrinTaskParamInfo ----------");
	   CrontaskParamInfo parameters[] = new CrontaskParamInfo[7];
	   parameters[0] = new CrontaskParamInfo();
	   parameters[0].setName("Communication Template");
	   parameters[1] = new CrontaskParamInfo();
	   parameters[1].setName("Delimeter");
	   parameters[2] = new CrontaskParamInfo();
	   parameters[2].setName("Emailto");
	   parameters[3] = new CrontaskParamInfo();
	   parameters[3].setName("Filelocation");
	   parameters[4] = new CrontaskParamInfo();
	   parameters[4].setName("Logfile");
	   parameters[5] = new CrontaskParamInfo();
	   parameters[5].setName("Query");	  
	   parameters[6] = new CrontaskParamInfo();
	   parameters[6].setName("Storeroom");	  

	   return parameters;

	}
	
	
	public void cronAction() 
	{		
		System.out.println("-------------------- Action Running -------------");
		
		email = new MxEmail();
		mxLog = new MxLog();
		
		try
		{
			logger.debug(getName() + " Start of CronTask action");
			readConfig();
			if(checkParanNull==false)
			{
				if (!processData())
				{
					// Email for error
					String message = "Some data have problems. See log file " + mxLog.getLogFilePath() + " for details";
					email.send(emailSubj, genEmail(message, ""));
					logger.info(getName() + " Email sent");
				}
			}
			if(checkParanNull==true)
			{		
				// Email for error
				String message = "Some data have problems. See log file " + mxLog.getLogFilePath() +  " " + " for details";
				email.send(emailSubj, genEmail(message, ""));
				logger.info(getName() + " Email sent");
				stop();
			}
		}
		catch(Exception e)
		{
			String message = e.getMessage();
			String stack = getStackTrace(e);
			
			// Log error
			logger.error(getName() + " " + message, e);
			mxLog.writeLog("ERROR " + message + "\n" + stack);
			
			
			// Email for error
			email.send(emailSubj, genEmail(message, stack));
			logger.info(getName() + " Email sent");
			stop();
		}
	}
	
	private void readConfig() throws RemoteException, MXException
	{
		System.out.println("-------------inside  readConfig ------------");
		
		mxserver = MXServer.getMXServer();

		userInfo = getRunasUserInfo();
		
		//parameters value
		
		logfile_Param = getParamAsString("Logfile");
		
		communicationTemplateID_Param=getParamAsString("Communication Template");
		
		query_Param=getParamAsString("Query");
		
		delimeter_Param=getParamAsString("Delimeter");
		
		storeroom_Param=getParamAsString("Storeroom");
		
		emailTo_Param=getParamAsString("Emailto");
		
		filelocation_Param=getParamAsString("Filelocation");
		
		

		
		// Log file
		
		if (logfile_Param != null)
		{
			logfile_Param = logfile_Param.trim();
			if (logfile_Param.equals(""))
				logfile_Param = null;
			else
			{
				mxLog.setEnabled(true);
				mxLog.setLogFilePath(logfile_Param);
				mxLog.setLogTag(getName());
				try 
				{
					mxLog.createLogFile();
				}
				catch (Exception e) 
				{
	             logger.error(getName() + " " + e.getMessage(), e);
				}
			}
		}

		// Email
		email.setToMail(getParamAsString("Emailto"));
		Properties properties = mxserver.getConfig();
		email.setFromMail(properties.getProperty("mxe.adminEmail", null));
		emailSubj = getName() + " "+ "Cron Task Error";
		
		if(communicationTemplateID_Param!=null)
		{
			communicationTemplateID_Param.trim();
			if(communicationTemplateID_Param.equals(""))
				communicationTemplateID_Param=null;
		}
		
		if(communicationTemplateID_Param==null)
		{
			logger.error(getName() + ":" + "Communication Template Parameter is not specified.");
			mxLog.writeLog("ERROR" + ":" + "Communication Template Parameter is not specified.");
			checkParanNull=true;
		}
		
		
		
		if(query_Param!=null)
		{
			query_Param.trim();
			if(query_Param.equals(""))
				query_Param=null;
		}
		
		if(query_Param==null)
		{
			logger.error(getName() + " " + "Query Parameter is not specified.");
			mxLog.writeLog("ERROR " + ":" + "Query Parameter is not specified.");
			checkParanNull=true;
		}
		
		
		if(delimeter_Param!=null)
		{
			delimeter_Param.trim();
			if(delimeter_Param.equals(""))
				delimeter_Param=null;
		}
		
		if(delimeter_Param==null)
		{
			logger.error(getName() + " " + "Delimeter Parameter is not specified.");
			mxLog.writeLog("ERROR "  + ":" + "Delimeter Parameter is not specified.");
			checkParanNull=true;
		}
		
		if(emailTo_Param!=null)
		{
			emailTo_Param.trim();
			if(emailTo_Param.equals(""))
				emailTo_Param=null;
		}
		
		if(emailTo_Param==null)
		{
			logger.error(getName() + " " + "EmailTo Parameter is not specified.");
			mxLog.writeLog("ERROR " + ":" + "EmailTo Parameter is not specified.");
			checkParanNull=true;
		}
		
		
		if(filelocation_Param!=null)
		{
			filelocation_Param.trim();
			if(filelocation_Param.equals(""))
				filelocation_Param=null;
		}
		
		if(filelocation_Param==null)
		{
			logger.error(getName() + " " + "File location Parameter is not specified.");
			mxLog.writeLog("ERROR " + ":" + "File location Parameter is not specified.");
			checkParanNull=true;
		}
		
		if(logfile_Param==null)
		{
			logger.error(getName() + " " + "Logfile Parameter is not specified.");
			mxLog.writeLog("ERROR " + ":" + "Logfile Parameter is not specified.");
			checkParanNull=true;
		}
		
	}
	
	private boolean processData() throws Exception
	{
		System.out.println("------------ inside processData -----------");
		boolean noproblem = true;
		try
		{
			MboSetRemote communicationTemplateList = MXServer.getMXServer().getMboSet("COMMTEMPLATE",userInfo);
			ConnectionKey connectionKey = communicationTemplateList.getUserInfo().getConnectionKey();
			DBShortcut dbShortcut = new DBShortcut();
			dbShortcut.connect(connectionKey);
			
			//check whether Storeroom is specified or not and set the query according to it
			
			if(storeroom_Param !=null)
			{
				storeroom_Param=storeroom_Param.trim();
				if(storeroom_Param.equals(""))
					storeroom_Param=null;
				else
				{
					//storeroom contain value and add these to query provided in parameter
					addStoreroomToQuery=new StringBuffer(query_Param);
					if(query_Param.contains("location in()"))
					{
						String[]storesplit=storeroom_Param.split(",");
						StringBuffer storefinal=new StringBuffer();
						for(int k=0;k<=storesplit.length-1;k++)
						{
							storefinal.append("'"+storesplit[k].trim()+"'"+",");
						}
						storefinal.deleteCharAt(storefinal.length()-1);
						addStoreroomToQuery.replace(addStoreroomToQuery.indexOf("location in()"), addStoreroomToQuery.indexOf("location in()")+13, "location in"+"("+storefinal.toString()+")");
					}
					finalQuery=addStoreroomToQuery.toString();
				}
			}
			if(storeroom_Param==null)
			{
				//storeroom not specify fetch  all storeroom values
				addStoreroomToQuery=new StringBuffer(query_Param);
				if(query_Param.contains("location in()"))
					addStoreroomToQuery.replace(addStoreroomToQuery.indexOf("location in()"), addStoreroomToQuery.indexOf("location in()")+13, "location is not null");
				
				finalQuery=addStoreroomToQuery.toString();
			}
			
			//write final query in logs
			logger.info(getName() + "sql query to be execute is "+finalQuery);
			mxLog.writeLog(getName() + ":" + "sql query to be execute is"+finalQuery);		
			
			
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
			String fileName="inv_balance_"+timeStamp+".txt";
			  
			
			File file = new File(filelocation_Param+fileName);
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			bw = new BufferedWriter(fw);
			
				SqlFormat sqlF = new SqlFormat(finalQuery);
				ResultSet resSet = dbShortcut.executeQuery(sqlF.format());
				ResultSetMetaData rsmd = resSet.getMetaData();
				int columnsNumber = rsmd.getColumnCount();
			
				//write header of Report inventory balance file start
			
				StringBuffer colName = new StringBuffer();
				for(int y=1; y <=columnsNumber;y++)
				{
					colName.append(rsmd.getColumnName(y));
					colName.append("\t");
					if(y!=columnsNumber)
					{
						colName.append(delimeter_Param);
						colName.append("\t");
					}
				}
				bw.write(colName.toString());
				colName.delete(0, colName.length());
				bw.newLine();
				bw.newLine();
				
				//header of Report inventory balance file finish
			
				//query results start to write in file
			
				while(resSet.next())
				{
					StringBuffer sb = new StringBuffer();
					for(int x=1;x<=columnsNumber;x++)
					{
						sb.append(resSet.getString(x));
						sb.append("\t");							
						if(x!=columnsNumber)
						{
							sb.append(delimeter_Param);
							sb.append("\t");							
						}
					}
				
					bw.write(sb.toString());
					bw.newLine();
					sb.delete(0, sb.length());
				}
			
				bw.close();
				resSet.close();
				dbShortcut.close();
				
				communicationTemplateList.setWhere("templateid='"+communicationTemplateID_Param+"'");
				String fromAddr = communicationTemplateList.getMbo(0).getString("SENDFROM");
				String subject = communicationTemplateList.getMbo(0).getString("SUBJECT");
				String message = communicationTemplateList.getMbo(0).getString("MESSAGE");
				MboSetRemote CommTMPLTSendToList=MXServer.getMXServer().getMboSet("COMMTMPLTSENDTO",userInfo);
				
				CommTMPLTSendToList.setWhere("templateid='"+communicationTemplateID_Param+"'");
				
				StringBuffer toAddr=new StringBuffer();
			    StringBuffer ccAddr=new StringBuffer();
			    StringBuffer bccAddr=new StringBuffer();
			    int CommTMPLTSendToListCount=CommTMPLTSendToList.count();
			    if(CommTMPLTSendToListCount<1)
			    {
			    	logger.error(getName() + ":" + "no any Recipients email address in Communication Template:" +communicationTemplateID_Param + "Query result created file will not be email.");		
			    	mxLog.writeLog(getName() + ":" + "no any Recipients email address in Communication Template:" +communicationTemplateID_Param + "Query result created file will not be email.");
			    }
			    else
			    {
			    	for(int total=0;total<=CommTMPLTSendToList.count()-1;total++)
					{
						
				    	boolean sendtoBoolean=CommTMPLTSendToList.getMbo(total).getBoolean("SENDTO");
						boolean ccBoolean=CommTMPLTSendToList.getMbo(total).getBoolean("CC");
						boolean bccBoolean=CommTMPLTSendToList.getMbo(total).getBoolean("BCC");
						if(sendtoBoolean==true)
						{
							toAddr.append(CommTMPLTSendToList.getMbo(total).getString("SENDTOVALUE")+",");
						}
						if(ccBoolean==true)
						{
							ccAddr.append(CommTMPLTSendToList.getMbo(total).getString("SENDTOVALUE")+",");
						}
						if(bccBoolean==true)
						{
							bccAddr.append(CommTMPLTSendToList.getMbo(total).getString("SENDTOVALUE")+",");
						}

						int tolength=toAddr.length();
				    	int cclength=ccAddr.length();
				    	int bcclength=bccAddr.length();
						
				    	if(tolength>0)
							toAddr.deleteCharAt(toAddr.length()-1);
						if(cclength>0)
							ccAddr.deleteCharAt(ccAddr.length()-1);
						if(bcclength>0)
							bccAddr.deleteCharAt(bccAddr.length()-1);
						
						String fileNames[] = {filelocation_Param+ fileName};
						if(tolength>0)
						{
							if(cclength<1 || bcclength<1)
							{
								// to check cc email addresses or bcc email addresses  or both cc and bcc email addresses are null or not 
								if(cclength<1 && bcclength<1)
									MXServer.sendEMail(toAddr.toString(), null, null, fromAddr, subject, message, fromAddr, fileNames, null);
												
								if(cclength<1 && bcclength>0)
									MXServer.sendEMail(toAddr.toString(), null, bccAddr.toString(), fromAddr, subject, message, fromAddr, fileNames, null);
								
								if(cclength>0 && bcclength<1)
									MXServer.sendEMail(toAddr.toString(), ccAddr.toString(), null, fromAddr, subject, message, fromAddr, fileNames, null);

							}
						}
						else
						{
						 	logger.error(getName() + ":" + "no any To Recipients email address in Communication Template:" +communicationTemplateID_Param + "Query result created file will not be email.");		
					    	mxLog.writeLog(getName() + ":" + "no any Recipients To email address in Communication Template:" +communicationTemplateID_Param + "Query result created file will not be email.");
						}
					}

			    }

		}
		catch(Exception e)
		{
			logger.warn(getName() + " " +e.getMessage() + getStackTrace(e)+". See log file for details");
			mxLog.writeLog("|--"  + "\n" + e.getMessage() + "\n" + getStackTrace(e));
			noproblem = false;
		}
		
		
		
		return noproblem;
		
	}
	
	private String genEmail(String error, String stack)
	{
		String emailMsg = "Date: " + new Date() + "\n"
				+ "Error Message: " + error + "\n"
				+ stack;
		return emailMsg;
	}
	
	
	private String getStackTrace(Exception e)
	{
		System.out.println("--------------- inside getStackTrace -------------");
		String stack = "";
		StackTraceElement element[] = e.getStackTrace();
		for (int i = 0; i < element.length; i++)
			stack += "\tat " + element[i].toString() + "\n";
		return stack;
	}
	
	// Log variables
	private MXLogger					logger;
	private MxLog						mxLog;

	
	private UserInfo					userInfo;
	private MXServer					mxserver;
	
	// Email variables
	private MxEmail					email;
	private String						emailSubj;	
	
	//parameters variables
	
	private String				communicationTemplateID_Param;
	private String				query_Param;
	private String				delimeter_Param;
	private String				storeroom_Param;
	private String				emailTo_Param;
	private String				filelocation_Param;
	private String				logfile_Param;
	private String 				finalQuery;
	private StringBuffer		addStoreroomToQuery;
	
	private boolean 			checkParanNull;

	private BufferedWriter bw;
	

}
