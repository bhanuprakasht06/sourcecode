package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

public class FldReconciliation extends MboValueAdapter {

	public FldReconciliation() {
		// TODO Auto-generated constructor stub
	}

	public FldReconciliation(MboValue mbv) {
		super(mbv);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void initValue() throws MXException, RemoteException {
		// TODO Auto-generated method stub
		super.initValue();
		getMboValue().setValue(getMboValue().getMbo().getOwner().getString("RECONCILIATION"));
	}
	
	

}
