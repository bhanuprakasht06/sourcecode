package com.psa.app.jobplan;

import psdi.mbo.MboRemote;

public interface JPSkillsetCustomRemote extends MboRemote 
{
}
