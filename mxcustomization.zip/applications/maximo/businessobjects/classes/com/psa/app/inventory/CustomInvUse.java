package com.psa.app.inventory;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;

import psdi.app.inventory.InvUse;
import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.ConnectionKey;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class CustomInvUse extends InvUse 
	implements CustomInvUseRemote 
{
	public CustomInvUse (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}

	public void add() 
		throws MXException, RemoteException 
	{
		super.add();
	}
	
	public void save() 
		throws MXException, RemoteException 
	{
		super.save();	
	}
	
	
	private void issueValidation(MboSetRemote invUseBatchSet) throws RemoteException, MXException{
		if(invUseBatchSet.count()>0){
			System.out.println("issueValidation : invUseBatchSet Count ::::::::::::::::::::>>>>"+invUseBatchSet.count());
			for (MboRemote invUseBatchMbo = invUseBatchSet.moveFirst(); invUseBatchMbo != null; invUseBatchMbo = invUseBatchSet.moveNext())
			{
			    String itemNum = invUseBatchMbo.getString("ITEMNUM");
				String storeLoc = invUseBatchMbo.getString("LOCATION");
				String binNum = invUseBatchMbo.getString("BINNUM");
				String batchNum = invUseBatchMbo.getString("BATCHNUM");
				String lotNum = invUseBatchMbo.getString("LOTNUM");
				String cc = invUseBatchMbo.getString("CONDITIONCODE");
				double invUseQuantity = invUseBatchMbo.getDouble("QUANTITY");
				MboSetRemote invBatchSet = this.getMboSet("$INVBATCH","INVBATCH");
				
				invBatchSet.setWhere("ITEMNUM = '"+itemNum+"' AND LOCATION='"+storeLoc+"' AND BINNUM='"+binNum+"' AND BATCHNUM='"+batchNum+"' AND (LOTNUM='"+lotNum+"' OR LOTNUM is null) AND CONDITIONCODE='"+cc+"'");
				invBatchSet.reset();
				
				System.out.println("issueValidation : invBatchSet Count ::::::::::::::::::::>>>>"+invBatchSet.count());
				
				if(invBatchSet.count()>0){
					MboRemote invBatchMbo = invBatchSet.getMbo(0);
					double invBatchQuantity = invBatchMbo.getDouble("CURBAL");
					 System.out.println("invUseQuantity::::::::::::::::::::>>>>"+invUseQuantity);
                	 System.out.println("invBatchQuantity::::::::::::::::::::>>>>"+invBatchQuantity);
					
					if(invUseQuantity > invBatchQuantity){
						Object[] params = { itemNum, batchNum};
						throw new MXApplicationException("psa","negativeBatchBalisNotAllowed");
					}
				}else{
					throw new MXApplicationException("psa","invbatchnotexist");
				}
				
			}
			
		}
	}
	
	
	
	
	private void batchTrackingValidate()throws MXException, RemoteException{
		String usetype = getString("USETYPE");
		MboSetRemote invUseLineSet = getMboSet("INVUSELINE");
		System.out.println("invUseLineSet Count ::::::::::::::::::::>>>>"+invUseLineSet.count());
		System.out.println("usetype::::::::::::::::::::>>>>"+usetype);
		
		if(invUseLineSet.count()>0 && usetype!=null && !usetype.equals("") && usetype.equalsIgnoreCase("TRANSFER")){
			for (MboRemote invUseLineMbo = invUseLineSet.moveFirst(); invUseLineMbo != null; invUseLineMbo = invUseLineSet.moveNext())
			{
				String invuselinenum = "";
				String toStoreRoom = "";
				String toBin = "";
				String toLot = "";
				double linequantity = 0;
				double batquantity = 0;
				String fromStoreRoom = "";
				String fromBin = "";
				String fromLot = "";
				String fromCond = "";
				
				 invuselinenum = invUseLineMbo.getString("INVUSELINENUM");
				 toStoreRoom = invUseLineMbo.getString("TOSTORELOC");
				 toBin = invUseLineMbo.getString("TOBIN");
				 toLot = invUseLineMbo.getString("TOLOT");
				 linequantity = invUseLineMbo.getDouble("QUANTITY");
				 fromStoreRoom = invUseLineMbo.getString("FROMSTORELOC");
				 fromBin = invUseLineMbo.getString("FROMBIN");
				 fromLot = invUseLineMbo.getString("FROMLOT");
				 fromCond = invUseLineMbo.getString("FROMCONDITIONCODE");
				 
				 System.out.println("---CustomInvUse----------Enter For loop--------------");
					MboSetRemote users = MXServer.getMXServer().getMboSet("MAXUSER", getUserInfo());
	                SqlFormat sql = new SqlFormat("userid=:1");
	                sql.setObject(1, "maxuser", "userid", getUserName());
	                users.setWhere(sql.format());
	                MboRemote user = users.getMbo(0);
	                System.out.println("---CustomInvUse----------userid--------------"+user.getString("userid"));
	                System.out.println("---CustomInvUse----------user--------------"+user.getString("sysuser"));
	                if (user.getBoolean("sysuser"))
	                        return;
	                String defaultstore = user.getString("defstoreroom");
	                System.out.println("---CustomInvUse----------defaultstore--------------"+defaultstore);
	                users.close();
	                if (!user.getString("USERID").equalsIgnoreCase("MXSYS") && !user.getString("USERID").equalsIgnoreCase("WMSMXWS"))
	                {
	                if (!invUseLineMbo.getString("TOSTORELOC").equals(defaultstore) ){
	                	String params[]= {"You are only allowed to receive into your default store"};
	                	throw new MXApplicationException("po", "wrongstoreuser");
	                        }
	                }
				 
				 
				 MboSetRemote invUsebatchSet = invUseLineMbo.getMboSet("INVUSEBATCH");
                 if(invUsebatchSet.count()>0){
                	 for (MboRemote invUsebatchMbo  = invUsebatchSet.moveFirst(); invUsebatchMbo  != null; invUsebatchMbo  = invUsebatchSet.moveNext())
         			{
                		 String invBatToLoc = "";
                		 String invBatToBin = "";
                		 String invBatToLot = "";
                		 String invBatFromLoc = "";
                		 String invBatFromBin = "";
                		 String invBatFromLot = "";
                		 String invBatUsageType = "";
                		 String condCode = "";
                		  invBatToLoc = invUsebatchMbo.getString("TOLOCATION");
                		  invBatToBin = invUsebatchMbo.getString("TOBIN");
                		  invBatToLot = invUsebatchMbo.getString("TOLOT");
                		  invBatFromLoc = invUsebatchMbo.getString("LOCATION");
                		  invBatFromBin = invUsebatchMbo.getString("BINNUM");
                		  invBatFromLot = invUsebatchMbo.getString("LOTNUM");
                		  invBatUsageType = invUsebatchMbo.getString("USAGETYPE");
                		  batquantity = batquantity + invUsebatchMbo.getDouble("QUANTITY");
                		  condCode = invUsebatchMbo.getString("CONDITIONCODE");
                		 
                         if(!toStoreRoom.equalsIgnoreCase(invBatToLoc)){
                        	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"To Store"});
                         }
			             if(!toBin.equalsIgnoreCase(invBatToBin)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"To Bin"});
			             }
			             if(!fromStoreRoom.equalsIgnoreCase(invBatFromLoc)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"From Store"});
			             }
			             if(!fromBin.equalsIgnoreCase(invBatFromBin)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"From Bin"});
			             }
			             if(!"TRANSFER".equalsIgnoreCase(invBatUsageType)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"Usage Type"});
			             }
			             if(!fromLot.equalsIgnoreCase(invBatFromLot)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"From Lot"});
			             }
			             if(!toLot.equalsIgnoreCase(invBatToLot)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"To Lot"});
			             }
			             
			             if((!fromCond.equalsIgnoreCase(condCode)) || (!fromCond.equalsIgnoreCase("NEW"))){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"Condition Code"});
			             }
			             
			             if(batquantity <= 0){
	    	            	 throw new MXApplicationException("inventory","notLessThanOrEqualZero");
	    	             }
			             
			             
			             
			            }
                	 System.out.println("linequantity::::::::::::::::::::>>>>"+linequantity);
                	 System.out.println("batquantity::::::::::::::::::::>>>>"+batquantity);
                	 
                	 if(linequantity!=batquantity){
    	            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"Quantity"});
    	             }
                	 
                	 
                	 
		            	 issueValidation(invUsebatchSet);
		             	 
                	 
                 }else if(fromCond!=null && fromCond.equalsIgnoreCase("NEW")){
                	 System.out.println("inv batch is empty::::::::::::::::::::>>>>");
                	throw new MXApplicationException("psa","nobatchSelected");
                 }
                

			}
		}else if(invUseLineSet.count()>0 && usetype!=null && !usetype.equals("") && (usetype.equalsIgnoreCase("ISSUE") || usetype.equalsIgnoreCase("MIXED"))){
             
			for (MboRemote invUseLineMbo = invUseLineSet.moveFirst(); invUseLineMbo != null; invUseLineMbo = invUseLineSet.moveNext())
			{
				String invuselinenum = "";
				double linequantity = 0;
				double batquantity = 0;
				String fromStoreRoom = "";
				String fromBin = "";
				String fromLot = "";
				String fromCond = "";
				String usageType = "";
				 invuselinenum = invUseLineMbo.getString("INVUSELINENUM");
				 linequantity = invUseLineMbo.getDouble("QUANTITY");
				 fromStoreRoom = invUseLineMbo.getString("FROMSTORELOC");
				 fromBin = invUseLineMbo.getString("FROMBIN");
				 fromLot = invUseLineMbo.getString("FROMLOT");
				 fromCond = invUseLineMbo.getString("FROMCONDITIONCODE");
				 usageType = invUseLineMbo.getString("USETYPE");
				 MboSetRemote invUsebatchSet = invUseLineMbo.getMboSet("INVUSEBATCH");
                 if(invUsebatchSet.count()>0){
                	 for (MboRemote invUsebatchMbo  = invUsebatchSet.moveFirst(); invUsebatchMbo  != null; invUsebatchMbo  = invUsebatchSet.moveNext())
         			{
                		 String invBatFromLoc = "";
                		 String invBatFromBin = "";
                		 String invBatFromLot = "";
                		 String invBatUsageType = "";
                		 
                		 String condCode = "";
                		 
                		  invBatFromLoc = invUsebatchMbo.getString("LOCATION");
                		  invBatFromBin = invUsebatchMbo.getString("BINNUM");
                		  invBatFromLot = invUsebatchMbo.getString("LOTNUM");
                		  invBatUsageType = invUsebatchMbo.getString("USAGETYPE");
                		  batquantity = batquantity + invUsebatchMbo.getDouble("QUANTITY");
                		  condCode = invUsebatchMbo.getString("CONDITIONCODE");
                		 if(!fromStoreRoom.equalsIgnoreCase(invBatFromLoc)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"From Store"});
			             }
			             if(!fromBin.equalsIgnoreCase(invBatFromBin)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"From Bin"});
			             }
			             if(!usageType.equalsIgnoreCase(invBatUsageType)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"Usage Type"});
			             }
			             if(!fromLot.equalsIgnoreCase(invBatFromLot)){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"From Lot"});
			             }
			            if((!fromCond.equalsIgnoreCase(condCode)) || (!fromCond.equalsIgnoreCase("NEW"))){
			            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"Condition Code"});
			             }
			             
			            if(batquantity <= 0){
	    	            	 throw new MXApplicationException("inventory","notLessThanOrEqualZero");
	    	             }
			             

			            }
                	 System.out.println("linequantity::::::::::::::::::::>>>>"+linequantity);
                	 System.out.println("batquantity::::::::::::::::::::>>>>"+batquantity);
                	 
                	 
                	 if(linequantity !=batquantity){
		            	 throw new MXApplicationException("PSA_INVUSEVAL","PSA_INVUSEVAL", new Object[]{invuselinenum,"Quantity"});
		             }
                	 
                	 System.out.println("usageType::::::::::::::::::::>>>>"+usageType);
                	 
                	 if(usageType!=null && usageType.equalsIgnoreCase("ISSUE")){
		            	 issueValidation(invUsebatchSet);
		             }	 
                 }else if(fromCond!=null && fromCond.equalsIgnoreCase("NEW")){
                	 System.out.println("inv batch is empty::::::::::::::::::::>>>>");
                	 throw new MXApplicationException("psa","nobatchSelected");
                 }
			}
		}
	}
	public void complete(String currentMaxStatus)
			throws MXException, RemoteException, MXApplicationException
	{
		System.out.println("---CustomInvUse----------inside complete()--------------");		
		super.complete(currentMaxStatus);
		
		
		System.out.println("---CustomInvUse----------before batchTrackingValidate validate--------------");		
		batchTrackingValidate();
		System.out.println("---CustomInvUse----------after batchTrackingValidate validate--------------");
		
		MXServer mxServer = MXServer.getMXServer();
		//ConnectionKey conKey = mxServer.getSystemUserInfo().getConnectionKey();
		//DBShortcut dbs = new DBShortcut();
		//dbs.connect(conKey);	
		
		
		MboSetRemote invUseLineSet = getMboSet("INVUSELINE");
		System.out.println("Count-->"+invUseLineSet.count());
		boolean changed = false;
		try
		{
		
			if (!invUseLineSet.isEmpty())
			{
				System.out.println("---CustomInvUse----------invUseLineSet.isEmpty() not empty--------------");
				
				String usetype = getString("USETYPE");
				if (usetype.equalsIgnoreCase("TRANSFER"))				
				{
					for (MboRemote invUseLine = invUseLineSet.moveFirst(); invUseLine != null; invUseLine = invUseLineSet.moveNext())
					{	
						System.out.println("---CustomInvUse----------Enter For loop--------------");
						MboSetRemote users = MXServer.getMXServer().getMboSet("MAXUSER", getUserInfo());
		                SqlFormat sql = new SqlFormat("userid=:1");
		                sql.setObject(1, "maxuser", "userid", getUserName());
		                users.setWhere(sql.format());
		                MboRemote user = users.getMbo(0);
		                System.out.println("---CustomInvUse----------userid--------------"+user.getString("userid"));
		                System.out.println("---CustomInvUse----------user--------------"+user.getString("sysuser"));
		                if (user.getBoolean("sysuser"))
		                        return;
		                String defaultstore = user.getString("defstoreroom");
		                System.out.println("---CustomInvUse----------defaultstore--------------"+defaultstore);
		                users.close();
		                if (!user.getString("USERID").equalsIgnoreCase("MXSYS") && !user.getString("USERID").equalsIgnoreCase("WMSMXWS"))
		                {
		                if (!invUseLine.getString("TOSTORELOC").equals(defaultstore) ){
		                	String params[]= {"You are only allowed to receive into your default store"};
		                	throw new MXApplicationException("po", "wrongstoreuser",params);
		                        }
		                }
		                System.out.println("---CustomInvUse----------Exit For loop--------------");
					}
				}
				
				System.out.println("---CustomInvUse----------after to store validation--------------");
                
				for (MboRemote invUseLine = invUseLineSet.moveFirst(); invUseLine != null; invUseLine = invUseLineSet.moveNext())
				{
					System.out.println("---CustomInvUse----------inside for invUseLine--------------");
					MboSetRemote InvUseBatchSet = invUseLine.getMboSet("INVUSEBATCH");
					if (!InvUseBatchSet.isEmpty())
					{
						for (MboRemote InvUseBatch = InvUseBatchSet.moveFirst(); InvUseBatch != null; InvUseBatch = InvUseBatchSet.moveNext())
						{
							String invUseBatchnum = InvUseBatch.getString("BATCHNUM");
							String usagetype = InvUseBatch.getString("USAGETYPE");
							double quantity = InvUseBatch.getDouble("quantity");
							String status = InvUseBatch.getString("STATUS");
							//System.out.println("---CustomInvUse----------InvUseBatch Batch-------------------"+invUseBatchnum);
							//System.out.println("---CustomInvUse----------InvUseBatch Usage Type-------------------"+usagetype);
							//System.out.println("---CustomInvUse----------InvUseBatch Quantity-------------------"+quantity);
							//System.out.println("---CustomInvUse----------InvUseBatch status-------------------"+status);
							
							boolean batch_changed = InvUseBatch.getBoolean("CHANGED");
							if (batch_changed)
								changed=true;
							
							if (usagetype.equalsIgnoreCase("ISSUE"))
							{
								System.out.println("---CustomInvUse----------usagetype.equalsIgnoreCase(ISSUE)-------------------");
								MboSetRemote InvBatchSet = InvUseBatch.getMboSet("INVBATCH");
								if (!InvBatchSet.isEmpty())
								{
									MboRemote InvBatch = InvBatchSet.getMbo(0);
									String invBatchnum = InvBatch.getString("BATCHNUM");
									double curbal = InvBatch.getDouble("curbal");
									System.out.println("---CustomInvUse----issue------InvBatch invBatchnum-------------------"+invBatchnum);
									System.out.println("---CustomInvUse----issue------InvBatch curbal-------------------"+curbal);
									
									double newCurbal = curbal - quantity;
									System.out.println("---CustomInvUse----issue------InvBatch newCurbal-------------------"+newCurbal);
									InvBatch.setValue("CURBAL", newCurbal, 2L);
									/*if (InvUseBatch.isNull("LOTNUM"))
										dbs.executeQuery("update INVBATCH set curbal='" + newCurbal + "' where batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "'");
									else
										dbs.executeQuery("update INVBATCH set curbal='" + newCurbal + "' where batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "' and LOTNUM='" +InvBatch.getString("LOTNUM")+ "'");
									dbs.commit();*/
								}
							}
							else if (usagetype.equalsIgnoreCase("RETURN"))
							{
								System.out.println("---CustomInvUse----------usagetype.equalsIgnoreCase(RETURN)-------------------");
								MboSetRemote InvBatchSet = InvUseBatch.getMboSet("INVBATCH");
								if (!InvBatchSet.isEmpty())
								{
									MboRemote InvBatch = InvBatchSet.getMbo(0);
									String invBatchnum = InvBatch.getString("BATCHNUM");
									double curbal = InvBatch.getDouble("curbal");
									System.out.println("---CustomInvUse----return------InvBatch invBatchnum-------------------"+invBatchnum);
									System.out.println("---CustomInvUse----return------InvBatch curbal-------------------"+curbal);
									
									double newCurbal = curbal + quantity;
									System.out.println("---CustomInvUse----return------InvUseBatch newCurbal-------------------"+newCurbal);
									InvBatch.setValue("CURBAL", newCurbal, 2L);
									/*if (InvUseBatch.isNull("LOTNUM"))
										dbs.executeQuery("update INVBATCH set curbal='" + newCurbal + "' where batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "'");
									else
										dbs.executeQuery("update INVBATCH set curbal='" + newCurbal + "' where batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "' and LOTNUM='" +InvBatch.getString("LOTNUM")+ "'");
									dbs.commit();*/
								}
							}							
							//else if (usagetype.equalsIgnoreCase("TRANSFER") && status.equalsIgnoreCase("ENTERED"))
							else if (usagetype.equalsIgnoreCase("TRANSFER"))
							{								
								//batchnum=:batchnum and itemnum=:itemnum and location=:location and binnum=:binnum and (lotnum=:lotnum or lotnum is null)
										
								System.out.println("---CustomInvUse------------InvBatchSet batchnum -------------------"+InvUseBatch.getString("batchnum"));
								System.out.println("---CustomInvUse----------InvBatchSet itemnum -------------------"+InvUseBatch.getString("itemnum"));
								System.out.println("---CustomInvUse----------InvBatchSet location -------------------"+InvUseBatch.getString("location"));
								System.out.println("---CustomInvUse----------InvBatchSet binnum -------------------"+InvUseBatch.getString("binnum"));
								System.out.println("---CustomInvUse----------InvBatchSet lotnum -------------------"+InvUseBatch.getString("lotnum"));
								System.out.println("---CustomInvUse----------InvBatchSet TOLOCATION -------------------"+InvUseBatch.getString("TOLOCATION"));
								System.out.println("---CustomInvUse----------InvBatchSet TOBIN -------------------"+InvUseBatch.getString("TOBIN"));
								System.out.println("---CustomInvUse----------InvBatchSet TOLOT -------------------"+InvUseBatch.getString("TOLOT"));
								
								MboSetRemote InvBatchSet = InvUseBatch.getMboSet("INVBATCH");
								
								System.out.println("Location-->"+InvBatchSet.getMbo(0).getString("Location"));
								System.out.println("---CustomInvUse----------InvBatchSet count -------------------"+InvBatchSet.count());
																
								/*MboSetRemote InvBatchSet;
								if (InvUseBatch.isNull("LOTNUM"))
									InvBatchSet = getMboSet("$invBatch","INVBATCH","itemnum='" +InvUseBatch.getString("ITEMNUM")+ "' and LOCATION='" +InvUseBatch.getString("LOCATION")+ "' and BINNUM='" +InvUseBatch.getString("BINNUM")+ "' and batchnum='" +InvUseBatch.getString("BATCHNUM")+ "'");
								else
									InvBatchSet = getMboSet("$invBatch","INVBATCH","itemnum='" +InvUseBatch.getString("ITEMNUM")+ "' and LOCATION='" +InvUseBatch.getString("LOCATION")+ "' and BINNUM='" +InvUseBatch.getString("BINNUM")+ "' and LOTNUM='" +InvUseBatch.getString("LOTNUM")+ "' and batchnum='" +InvUseBatch.getString("BATCHNUM")+ "'");
								*/
								if (!InvBatchSet.isEmpty())
								{
									MboRemote InvBatch = InvBatchSet.getMbo(0);
									String invBatchnum = InvBatch.getString("BATCHNUM");
									double curbal = InvBatch.getDouble("curbal");
									//System.out.println("---CustomInvUse----transfer------InvBatch invBatchnum-------------------"+invBatchnum);
									//System.out.println("---CustomInvUse----transfer------InvBatch curbal-------------------"+curbal);
									
									
									//MboSetRemote toInvBatchSetRemote = getMboSet("$invBatch","INVBATCH","itemnum='" +InvUseBatch.getString("ITEMNUM")+ "' and LOCATION='" +InvUseBatch.getString("TOLOCATION")+ "' and BINNUM='" +InvUseBatch.getString("TOBIN")+ "' and LOTNUM='" +InvUseBatch.getString("TOLOT")+ "' and batchnum='" +InvUseBatch.getString("BATCHNUM")+ "'");
									
									  MboSetRemote toInvBatchSetRemote = getMboSet("$invBatch1", "INVBATCH");
					                  if (InvUseBatch.getString("TOLOT") != null && !InvUseBatch.getString("TOLOT").equals("")) {
					                    toInvBatchSetRemote.setWhere("itemnum='" + InvUseBatch.getString("ITEMNUM") + "' and LOCATION='" + InvUseBatch.getString("TOLOCATION") + "' and BINNUM='" + InvUseBatch.getString("TOBIN") + "' and LOTNUM='" + InvUseBatch.getString("TOLOT") + "' and batchnum='" + InvUseBatch.getString("BATCHNUM") + "'");
					                  } else {
					                    toInvBatchSetRemote.setWhere("itemnum='" + InvUseBatch.getString("ITEMNUM") + "' and LOCATION='" + InvUseBatch.getString("TOLOCATION") + "' and BINNUM='" + InvUseBatch.getString("TOBIN") + "' and LOTNUM is null and batchnum='" + InvUseBatch.getString("BATCHNUM") + "'");
					                  } 
					                  toInvBatchSetRemote.reset();
					                  System.out.println("---CustomInvUse----toInvBatchSetRemote count-------------------------" + toInvBatchSetRemote.count());
					                  System.out.println("---CustomInvUse----toInvBatchSetRemote count-------------------------" + toInvBatchSetRemote.getWhere());
					           
									if (toInvBatchSetRemote.isEmpty())
									{
										//MboRemote toInvBatch = toInvBatchSetRemote.add();
										System.out.println("---Inside CustomInvUse----toInvBatchSetRemote count-------------------------" + toInvBatchSetRemote.count());
										System.out.println("---CustomInvUse----transfer add-------------------------");
										/*toInvBatch.setValue("BATCHNUM", InvUseBatch.getString("BATCHNUM"), 2L);
										toInvBatch.setValue("BATCHDATE", InvBatch.getDate("BATCHDATE"), 2L);
										toInvBatch.setValue("ITEMNUM", InvUseBatch.getString("ITEMNUM"), 2L);
										toInvBatch.setValue("BINNUM", InvUseBatch.getString("TOBIN"), 2L);
										toInvBatch.setValue("LOTNUM", InvUseBatch.getString("TOLOT"), 2L);
										toInvBatch.setValue("CONDITIONCODE", InvUseBatch.getString("CONDITIONCODE"), 2L);
										toInvBatch.setValue("LOCATION", InvUseBatch.getString("TOLOCATION"), 2L);
										toInvBatch.setValue("SITEID", invUseLine.getString("TOSITEID"), 2L);
										toInvBatch.setValue("ORGID", invUseLine.getString("TOORGID"), 2L);
										toInvBatch.setValue("CURBAL", InvUseBatch.getString("QUANTITY"), 2L);*/
										
										MboSetRemote inventoryAddMboSet=MXServer.getMXServer().getMboSet("INVBALANCES",getUserInfo());
							            inventoryAddMboSet.setWhere("ITEMNUM='"+InvUseBatch.getString("ITEMNUM")+"' and SITEID='"+invUseLine.getString("TOSITEID")+"'");
							            inventoryAddMboSet.reset();
							            System.out.println(inventoryAddMboSet.count());
							            MboSetRemote addinvBatchMboSet=null;
							            MboRemote addinvBatchMbo=null;
							            if(!inventoryAddMboSet.isEmpty())
							            {
							                addinvBatchMboSet = inventoryAddMboSet.getMbo(0).getMboSet("INVBATCH");
							            }
										
										System.out.println("---CustomInvUse----transfer add - INVBATCH records---Start-------------");
										//MboSetRemote addinvBatchMboSet= MXServer.getMXServer().getMboSet("INVBATCH",getUserInfo());
										addinvBatchMboSet.setWhere("ITEMNUM='"+InvUseBatch.getString("ITEMNUM")+"' and SITEID='"+invUseLine.getString("TOSITEID")+"'");
										addinvBatchMboSet.reset();
										
										System.out.println("Count-->"+addinvBatchMboSet.count());
					
									
										try {
											
											addinvBatchMbo = addinvBatchMboSet.addAtEnd(MboConstants.NO_RELATEDMBOS_OF_OWNERSCHILDREN_FETCH|MboConstants.NOVALIDATION_AND_NOACTION);
										}
										catch(Exception e){
											 e.printStackTrace();
										}
										//MboRemote addinvBatchMboremote = addinvBatchMboSet.addAtEnd();
										
										addinvBatchMbo.setValue("BATCHNUM",InvUseBatch.getString("BATCHNUM"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("BATCHDATE",InvBatch.getDate("BATCHDATE"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("ITEMNUM",InvUseBatch.getString("ITEMNUM"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("BINNUM",InvUseBatch.getString("TOBIN"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("LOTNUM",InvUseBatch.getString("TOLOT"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("CONDITIONCODE",InvUseBatch.getString("CONDITIONCODE"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("LOCATION",InvUseBatch.getString("TOLOCATION"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("SITEID",invUseLine.getString("TOSITEID"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("ORGID",invUseLine.getString("TOORGID"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("CURBAL",InvUseBatch.getDouble("QUANTITY"), MboConstants.NOACCESSCHECK);
										addinvBatchMbo.setValue("FAULTQTY",0.00, MboConstants.NOACCESSCHECK);
										addinvBatchMboSet.save();

										System.out.println("---CustomInvUse----transfer add - INVBATCH records---End-------------");
										
										/*
										String inser_query = "insert into INVBATCH (BATCHNUM,BATCHDATE,ITEMNUM,BINNUM,LOTNUM,CONDITIONCODE,LOCATION,SITEID,ORGID,CURBAL,FAULTQTY,INVBATCHTRACKID, HASLD) VALUES ('" + InvUseBatch.getString("BATCHNUM") + "', to_date('" + strDate + "','yyyy-MM-dd HH24:mi'), '" + InvUseBatch.getString("ITEMNUM") + "', '" + InvUseBatch.getString("TOBIN") + "', '" + InvUseBatch.getString("TOLOT") + "', '" + InvUseBatch.getString("CONDITIONCODE") + "', '" + InvUseBatch.getString("TOLOCATION") + "', '" + invUseLine.getString("TOSITEID") + "', '" + invUseLine.getString("TOORGID") + "', '" + InvUseBatch.getDouble("QUANTITY") + "', '0.00', (select max(INVBATCHTRACKID)+1 from INVBATCH), 0)";
										System.out.println("---CustomInvUse----transfer inser_query-------------------------"+inser_query);
										dbs.executeQuery(inser_query);							
										*/
										
										double newCurbal = curbal - quantity;
										System.out.println("---CustomInvUse----transfer add - update INVBATCH ---Start---newCurbal>>"+newCurbal);
										MboSetRemote updinvBatchMboSet=MXServer.getMXServer().getMboSet("INVBATCH",getUserInfo());
										
										String wheresql="";
										MboRemote updinvBatchremote=null;
										if (InvUseBatch.isNull("LOTNUM"))
										{
											wheresql="batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "'";
										}
										else
										{
											wheresql="batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "' and LOTNUM='" +InvBatch.getString("LOTNUM")+ "'";
										}
										System.out.println("---CustomInvUse----transfer - wheresql >>"+wheresql);
										updinvBatchMboSet.setWhere(wheresql);
										updinvBatchMboSet.reset();
										if(!updinvBatchMboSet.isEmpty() && updinvBatchMboSet.count()>0 ) {
											for(int i=0;(updinvBatchremote=updinvBatchMboSet.getMbo(i))!=null;i++) {
												updinvBatchremote.setValue("CURBAL", newCurbal);						
											}
											updinvBatchMboSet.save();
										}
										System.out.println("---CustomInvUse----transfer add - update INVBATCH ---End---");
										/*
										
										System.out.println("---CustomInvUse----transfer add------InvBatch newCurbal-------------------"+newCurbal);
										//InvBatch.setValue("CURBAL", newCurbal, 2L);	
										if (InvUseBatch.isNull("LOTNUM"))
											dbs.executeQuery("update INVBATCH set curbal='" + newCurbal + "' where batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "'");
										else
											dbs.executeQuery("update INVBATCH set curbal='" + newCurbal + "' where batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "' and LOTNUM='" +InvBatch.getString("LOTNUM")+ "'");
										dbs.commit();
										*/
									}
									else
									{
										System.out.println("---CustomInvUse----transfer update-------------------------");
										MboRemote toInvBatch = toInvBatchSetRemote.getMbo(0);
										double update_curbal = toInvBatch.getDouble("curbal");
										double newCurbal = update_curbal + quantity;
										//toInvBatch.setValue("CURBAL", newCurbal, 2L);
										System.out.println("---CustomInvUse----transfer update - update INVBATCH ---Start---newCurbal>>"+newCurbal);
										MboSetRemote updupdinvBatchMboSet=MXServer.getMXServer().getMboSet("INVBATCH",getUserInfo());
										
										String wheresql="";
										MboRemote updupdinvBatchremote=null;
										if (InvUseBatch.isNull("LOTNUM"))
										{
											wheresql="itemnum='" +InvUseBatch.getString("ITEMNUM")+ "' and LOCATION='" +InvUseBatch.getString("TOLOCATION")+ "' and BINNUM='" +InvUseBatch.getString("TOBIN")+ "' and batchnum='" +InvUseBatch.getString("BATCHNUM")+ "'";
										}
										else
										{
											wheresql="itemnum='" +InvUseBatch.getString("ITEMNUM")+ "' and LOCATION='" +InvUseBatch.getString("TOLOCATION")+ "' and BINNUM='" +InvUseBatch.getString("TOBIN")+ "' and LOTNUM='" +InvUseBatch.getString("TOLOT")+ "' and batchnum='" +InvUseBatch.getString("BATCHNUM")+ "'";
										}
										System.out.println("---CustomInvUse----transfer update - wheresql >>"+wheresql);
										updupdinvBatchMboSet.setWhere(wheresql);
										updupdinvBatchMboSet.reset();
										if(!updupdinvBatchMboSet.isEmpty() && updupdinvBatchMboSet.count()>0 ) {
											for(int i=0;(updupdinvBatchremote=updupdinvBatchMboSet.getMbo(i))!=null;i++) {
												updupdinvBatchremote.setValue("CURBAL", newCurbal);						
											}
											updupdinvBatchMboSet.save();
										}
										System.out.println("---CustomInvUse----transfer update - update INVBATCH ---End---");
										
										/*
										String update_invbatch = null;
										if (InvUseBatch.isNull("LOTNUM"))
											update_invbatch = "update INVBATCH set curbal='" + newCurbal + "' where itemnum='" +InvUseBatch.getString("ITEMNUM")+ "' and LOCATION='" +InvUseBatch.getString("TOLOCATION")+ "' and BINNUM='" +InvUseBatch.getString("TOBIN")+ "' and batchnum='" +InvUseBatch.getString("BATCHNUM")+ "'";
										else
											update_invbatch = "update INVBATCH set curbal='" + newCurbal + "' where itemnum='" +InvUseBatch.getString("ITEMNUM")+ "' and LOCATION='" +InvUseBatch.getString("TOLOCATION")+ "' and BINNUM='" +InvUseBatch.getString("TOBIN")+ "' and LOTNUM='" +InvUseBatch.getString("TOLOT")+ "' and batchnum='" +InvUseBatch.getString("BATCHNUM")+ "'";
										System.out.println("---CustomInvUse----update update_invbatch-------------------------"+update_invbatch);
										dbs.executeQuery(update_invbatch);
										*/
										double newCurbal1 = curbal - quantity;
										System.out.println("---CustomInvUse----transfer update -update InvBatch based on batchnum. newCurbal1--->>"+newCurbal1);
										
										updupdinvBatchMboSet = null;
										updupdinvBatchremote=null;
										wheresql="";
										updupdinvBatchMboSet=MXServer.getMXServer().getMboSet("INVBATCH",getUserInfo());
										if (InvUseBatch.isNull("LOTNUM"))
										{
											wheresql="batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "'";
										}
										else
										{
											wheresql="batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "' and LOTNUM='" +InvBatch.getString("LOTNUM")+ "'";
										}
										System.out.println("---CustomInvUse----transfer update based on batchnum - wheresql >>"+wheresql);
										updupdinvBatchMboSet.setWhere(wheresql);
										updupdinvBatchMboSet.reset();
										if(!updupdinvBatchMboSet.isEmpty() && updupdinvBatchMboSet.count()>0 ) {
											for(int i=0;(updupdinvBatchremote=updupdinvBatchMboSet.getMbo(i))!=null;i++) {
												updupdinvBatchremote.setValue("CURBAL", newCurbal1);						
											}
											updupdinvBatchMboSet.save();
										}
										System.out.println("---CustomInvUse----transfer update -update InvBatch based on batchnum. --- End ---");
										
										/*
										double newCurbal1 = curbal - quantity;
										System.out.println("---CustomInvUse----transfer update org------InvBatch newCurbal-------------------"+newCurbal);
										//InvBatch.setValue("CURBAL", newCurbal1, 2L);
										String update_invbatch_org = null;
										if (InvUseBatch.isNull("LOTNUM"))		
											update_invbatch_org="update INVBATCH set curbal='" + newCurbal1 + "' where batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "'";
										else
											update_invbatch_org="update INVBATCH set curbal='" + newCurbal1 + "' where batchnum='" + InvBatch.getString("BATCHNUM") + "' and itemnum='" + InvBatch.getString("ITEMNUM") + "' and location='" + InvBatch.getString("LOCATION") + "' and BINNUM='" +InvBatch.getString("BINNUM")+ "' and LOTNUM='" +InvBatch.getString("LOTNUM")+ "'";
										System.out.println("---CustomInvUse----update update_invbatch_org-------------------------"+update_invbatch_org);
										dbs.executeQuery(update_invbatch_org);
										dbs.commit();
										*/
									}									
								}							
							}
							System.out.println("---CustomInvUse----before update batch status--------------------");
							InvUseBatch.setValue("STATUS", "COMPLETE", 2L);
							
						}
					}
				}
						
			}		
		
			if (changed)
			{
				//System.out.println("---CustomInvUse----------inside sending mail--------------");
				CommTemplateSetRemote commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
				commTemplateSet.setWhere("TEMPLATEID='BATCH_CHANGE'");
				commTemplateSet.reset();
				if (!commTemplateSet.isEmpty())
				{
					CommTemplateRemote tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);	
					String toMail=tempRemote.getString("TOLIST");
					String fromMail=tempRemote.getString("SENDFROM");
					String ccTo=tempRemote.getString("CCLIST");
					String bccTo=tempRemote.getString("BCCLIST");
					String subject=tempRemote.getString("SUBJECT");
					String message=tempRemote.getString("MESSAGE");
					String replyTo=tempRemote.getString("REPLYTO");
					
					subject=subject.replace("#INVUSE", getString("INVUSENUM"));
					message=message.replace("#INVUSE", getString("INVUSENUM"));
					toMail=tempRemote.convertSendTo("COMMTMPLT_TO", tempRemote);
					ccTo=tempRemote.convertSendTo("COMMTMPLT_CC", tempRemote);
					bccTo=tempRemote.convertSendTo("COMMTMPLT_BCC", tempRemote);
					
					MXServer.sendEMail(toMail, ccTo, bccTo, fromMail, subject, message, replyTo, null, null);
					System.out.println("---CustomInvUse----------mail sent--------------");
				}
			}
		}
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }		
	}
}
