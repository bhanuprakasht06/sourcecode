/*
 * Modification history
 * 22-06-07	HCHA	NA			Creation
 * 23-11-06	HCHA	NA			???
 * 11-04-07	AGD	SR-087	Correct bug occuring only when using Labor Reporting
 * 01-05-07	AGD	SR-030	Set fincntrlid (supposed to be set by Maximo but somehow it's blanked off)
 */
package com.psa.app.labor;

import java.rmi.RemoteException;

import psdi.app.labor.FldLabTransRefWO;
import psdi.app.labor.LabTrans;
import psdi.app.workorder.WorkTypeRemote;
import psdi.app.workorder.WorkTypeSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldLabTransRefWOCustom extends FldLabTransRefWO {

	public FldLabTransRefWOCustom(MboValue arg0) throws MXException,
			RemoteException {
		super(arg0);
	}


	public void action()
			throws MXException, RemoteException
	{
//		System.out.println("FldLabTransRefWOCustom.action(): Start");
// Begin modification SR-087 - ignore MXApplicationException error (GL A/c not valid)
		try {
			super.action();
		}
		catch (MXApplicationException e) { }
// End modification SR-087 - ignore MXApplicationException error

//		System.out.println("FldLabTransRefWOCustom.action(): WONum = "+getMboValue().getString());

		LabTrans labtrans = (LabTrans)getMboValue().getMbo(); 

// Begin modification SR-030
      MboRemote wo = getMboValue().getMbo().getMboSet("WORKORDER").getMbo(0);
		labtrans.setValue("fincntrlid", wo.getString("fincntrlid"));
// End modification SR-030

		if (getMboValue().isNull())
		{
			labtrans.setValue("payrate", labtrans.getPayRate(), 2L);
			return;
		}

//	 Begin modification SR-030 - We get the WO above so it's not necessary to get here anymore
/*		WOSetRemote woSet = (WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER",
				labtrans.getUserInfo());
		SqlFormat sqlformat = new SqlFormat(labtrans.getUserInfo(), "wonum = :1 and siteid = :2");
		sqlformat.setObject(1, "WORKORDER", "WONUM", labtrans.getString("refwo"));
		sqlformat.setObject(2, "WORKORDER", "SITEID", labtrans.getString("siteid"));
		woSet.setWhere(sqlformat.format());
        
		if (!woSet.isEmpty())
		{
//			System.out.println("FldLabTransRefWOCustom.action(): Found WO");
			WORemote wo = (WORemote) woSet.getMbo(0);
*/
// End modification SR-030
			String woWorkType = wo.getString("WORKTYPE");
			if (woWorkType != null)
			{
				//Get Worktype mbo
				WorkTypeSetRemote worktypeSet = (WorkTypeSetRemote) MXServer.getMXServer().getMboSet(
						"WORKTYPE", labtrans.getUserInfo());

				SqlFormat sqlformatWOType = new SqlFormat(labtrans.getUserInfo(),
						"worktype = :1 and orgid = :2");
				sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
				sqlformatWOType.setObject(2, "LABTRANS", "ORGID", labtrans.getString("orgid"));
				worktypeSet.setWhere(sqlformatWOType.format());

				if (!worktypeSet.isEmpty())
				{
					WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
					boolean noLabCost = worktype.getBoolean("nolabcost");
					if (noLabCost)
						//No Charging Internal Labor Cost Required
						labtrans.setValue("payrate", 0, 2L);
					else
						labtrans.setValue("payrate", labtrans.getPayRate(), 2L);
//	Begin modification SR-087 - set the GL A/c to the WO GL A/c
					if (worktype.getBoolean("capitalwork"))
						labtrans.setValue("gldebitacct", wo.getString("glaccount"), 2L);
//	End modification SR-087
				}
			}
//	Begin modification SR-030
//		}
//	End modification SR-030
//		System.out.println("FldLabTransRefWOCustom.action(): End");
	}

}
