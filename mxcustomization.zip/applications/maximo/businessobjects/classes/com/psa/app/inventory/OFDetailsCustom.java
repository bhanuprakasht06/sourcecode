
package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.mbo.MboSet;
import psdi.mbo.custapp.NonPersistentCustomMbo;
import psdi.util.MXException;

public class OFDetailsCustom extends NonPersistentCustomMbo {

	public OFDetailsCustom(MboSet ms) throws RemoteException {
		super(ms);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void checkFieldAccess(long accessModifier) throws MXException 
	{		// TODO Auto-generated method stub
			return;
	}
}
