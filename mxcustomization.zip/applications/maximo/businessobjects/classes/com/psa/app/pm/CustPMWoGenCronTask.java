package com.psa.app.pm;

import java.io.FileOutputStream;
import java.io.PrintStream;

import psdi.app.pm.PMSetRemote;
import psdi.app.pm.PMWoGenCronTask;



/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;

/*     */ import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboConstants;
/*     */ import psdi.mbo.MboRemote;
/*     */ import psdi.mbo.MboSetRemote;
/*     */ import psdi.mbo.SqlFormat;
/*     */ import psdi.security.UserInfo;
/*     */ import psdi.server.MXServer;
/*     */ import psdi.server.SimpleCronTask;
/*     */ import psdi.util.CombineWhereClauses;
/*     */ import psdi.util.MXException;
/*     */ import psdi.util.MXFormat;
/*     */ import psdi.util.Message;
/*     */ import psdi.util.Resolver;
/*     */ import psdi.util.logging.MXLogger;
/*     */ import psdi.util.logging.MXLoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustPMWoGenCronTask
/*     */   extends SimpleCronTask
/*     */ {
/*     */   private MXServer mxserver;
/*  48 */   private boolean initialized = false;
/*  49 */   private UserInfo userInfo = null;
/*  50 */   private String notifyEmail = null;
/*  51 */   private String adminEmail = null;
/*  52 */   private Properties configData = null;
/*  53 */   private String logFilePath = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws MXException
/*     */   {
/*     */     try
/*     */     {
/*  62 */       super.init();
/*     */       
/*     */ 
/*  65 */       mxserver = MXServer.getMXServer();
/*     */       
/*  67 */       configData = mxserver.getConfig();
/*     */       
/*  69 */       userInfo = getRunasUserInfo();
/*     */       
/*     */ 
/*  72 */       adminEmail = configData.getProperty("mxe.adminEmail", null);
/*  73 */       logFilePath = getParamAsString("logfile");
/*     */       
/*  75 */       if ((logFilePath == null) || (logFilePath.equals("")))
/*     */       {
/*  77 */         logFilePath = configData.getProperty("mxe.msgLogFile");
/*     */       }
/*     */       
/*  80 */       logFilePath = logFilePath.trim();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (RemoteException e)
/*     */     {
/*     */ 
/*  87 */       System.out.println("PMWoGenCronTask failed to init()");
/*  88 */       e.printStackTrace();
/*  89 */       return;
/*     */     }
/*     */     
/*  92 */     initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 101 */     return "PMWoGenCronTask";
/*     */   }
/*     */   
/*     */ 
/* 105 */   private static final String[] varNames = { "AUTOPMWOGEN", "WOGENEMAIL", "WOGENERATIONDAYS", "WOGENUSEFREQCRITRA", "WOGENWHERECLAUSE" };
/*     */   
/*     */   private static final int POS_AUTOPMWOGEN = 0;
/*     */   
/*     */   private static final int POS_WOGENEMAIL = 1;
/*     */   
/*     */   private static final int POS_WOGENERATIONDAYS = 2;
/*     */   
/*     */   private static final int POS_WOGENUSEFREQCRITRA = 3;
/*     */   private static final int POS_WOGENWHERECLAUSE = 4;
/*     */   
/*     */   public void cronAction()
/*     */   {
/* 118 */     String filter = "active=1";
/*     */     
/* 120 */     cronAction(filter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cronAction(String filter)
/*     */   {
/* 128 */     if (!initialized) {
/* 129 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 133 */       createLogFile();
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 138 */       System.out.println(e.getMessage());
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 144 */       MboSetRemote siteSet = mxserver.getMboSet("SITE", userInfo);
/*     */       
/* 146 */       siteSet.setWhere(filter);
/* 147 */       siteSet.reset();
/*     */       
/*     */ 
/* 150 */       if (siteSet.isEmpty()) {
/*     */         return;
/*     */       }
/* 153 */       int index = 0;
/* 154 */       MboRemote siteMbo = siteSet.getMbo(index);
/*     */       
/* 156 */       while (siteMbo != null)
/*     */       {
/*     */ 
/* 159 */         String emailMessage = "";
/* 160 */         String site = siteMbo.getString("SITEID");
/* 161 */         Object[] paramsMsg = { site };
/* 162 */         Message msg = Resolver.getResolver().getMessage("pm", "WogenMessage");
/*     */         
/* 164 */         System.out.println(msg.getMessage(paramsMsg));
/*     */         
/*     */ 
/* 167 */         MboSetRemote maxVarSet = getMaxVar(siteMbo, varNames);
/*     */         
/*     */ 
/* 170 */         if (!maxVarSet.isEmpty())
/*     */         {
/*     */ 
/* 173 */           if (MXFormat.stringToBoolean(maxVarSet.getMbo(0).getString("varvalue")))
/*     */           {
/* 175 */             PMSetRemote pmSet = (PMSetRemote)mxserver.getMboSet("PM", userInfo);
/* 176 */             CombineWhereClauses cwc = new CombineWhereClauses();
/*     */             
/*     */ 
/* 179 */             String whereClause = maxVarSet.getMbo(4).getString("VARVALUE");
/*     */             
/* 181 */             if (!whereClause.equals("NULL"))
/*     */             {
/* 183 */               cwc.addWhere(whereClause);
/*     */             }
/*     */             
/*     */ 
/* 187 */             cwc.addWhere("siteid ='" + site + "'");
/*     */             
/*     */ 
/*     */ 
/* 191 */             cwc.addWhere("parent is null");
/*     */             
/*     */ 
/* 194 */             SqlFormat sqf = new SqlFormat(siteMbo, cwc.getWhereClause());
/* 195 */             pmSet.setWhere(sqf.format());
/*     */             
/* 197 */             if (!pmSet.isEmpty())
/*     */             {
/* 199 */               boolean useFreqCrit = MXFormat.stringToBoolean(maxVarSet.getMbo(3).getString("VARVALUE"));
/* 200 */               int leadTime = MXFormat.stringToInt(maxVarSet.getMbo(2).getString("VARVALUE"));
/*     */               
/* 202 */               pmSet.setFlag(39L, true);
/*     */               
/* 204 */               int i = 0;
/* 205 */               while (pmSet.getMbo(i) != null)
/*     */               {
/*     */ 
/* 208 */                 PMSetRemote individualSet = (PMSetRemote)MXServer.getMXServer().getMboSet("PM", userInfo);
/*     */                 
/* 210 */                 MboRemote pmMbo = pmSet.getMbo(i);
/* 211 */                 String pmnum = pmMbo.getString("pmnum");
/* 212 */                 String siteid = pmMbo.getString("siteid");
/*     */                 
/*     */ 
/* 215 */                 SqlFormat sqf2 = new SqlFormat("pmnum = :1 and siteid = :2");
/* 216 */                 sqf2.setObject(1, "PM", "pmnum", pmnum);
/* 217 */                 sqf2.setObject(2, "PM", "siteid", siteid);
/* 218 */                 individualSet.setWhere(sqf2.format());
/*     */                 
/* 220 */                 individualSet.generateWork(useFreqCrit, leadTime, true);
/*     */                 
/*     */ 
/* 223 */                 if (individualSet.hasWarnings())
/*     */                 {
/* 225 */                   if (maxVarSet.getMbo(1).isNull("VARVALUE"))
/*     */                   {
/* 227 */                     notifyEmail = adminEmail;
/*     */                   }
/*     */                   else
/*     */                   {
/* 231 */                     notifyEmail = maxVarSet.getMbo(1).getString("VARVALUE");
/*     */                   }
/*     */                   
/* 234 */                   String message = composeMsg(individualSet, site);
/*     */                   
/*     */ 
/* 237 */                   writeLog(message);
/*     */                   
/*     */ 
/* 240 */                   emailMessage = emailMessage + "\n" + message;
/*     */                 }
/* 242 */                 individualSet.cleanup();
/* 243 */                 i++;
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 249 */             if (emailMessage.length() > 0) {
/* 250 */               writeEmail(emailMessage, site);
/*     */             }
/* 252 */             pmSet.reset();
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 258 */         index++;
/* 259 */         siteMbo = siteSet.getMbo(index);
/*     */       }
/*     */       
/*     */       return;
/*     */     }
/*     */     catch (MXException me)
/*     */     {
/* 266 */       me.printStackTrace();
/*     */     }
/*     */     catch (RemoteException re)
/*     */     {
/* 270 */       re.printStackTrace();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 274 */       e.printStackTrace();
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 281 */         closeLogFile();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 285 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MboSetRemote getMaxVar(MboRemote siteMbo, String[] varNames)
/*     */     throws MXException, RemoteException
/*     */   {
/* 308 */     String varwhere = "varname in (";
/* 309 */     boolean firstOne = true;
/* 310 */     for (int i = 0; i < varNames.length; i++)
/*     */     {
/* 312 */       if (!firstOne) {
/* 313 */         varwhere = varwhere + ",'";
/*     */       } else
/* 315 */         varwhere = varwhere + "'";
/* 316 */       varwhere = varwhere + varNames[i];
/* 317 */       varwhere = varwhere + "'";
/* 318 */       firstOne = false;
/*     */     }
/* 320 */     varwhere = varwhere + ")";
/*     */     
/* 322 */     SqlFormat sf = new SqlFormat(siteMbo, "siteid = :siteid and " + varwhere);
/*     */     
/* 324 */     MboSetRemote vars = mxserver.getMboSet("MAXVARS", userInfo);
/* 325 */     vars.setWhere(sf.format());
/* 326 */     vars.setOrderBy("varname");
/*     */     
/* 328 */     return vars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeEmail(String message, String site)
/*     */   {
/*     */     try
/*     */     {
/* 342 */       Object[] param = { site };
/* 343 */       String subject = Resolver.getResolver().getMessage("pm", "GenWOEmailSubject").getMessage(param);
/*     */       
/* 345 */       List<String> emailList = new ArrayList();
/*     */       
/* 347 */       StringTokenizer st = new StringTokenizer(notifyEmail, ",");
/* 348 */       while (st.hasMoreTokens())
/*     */       {
/* 350 */         String email = st.nextToken();
/* 351 */         emailList.add(email);
/*     */       }
/* 353 */       String[] emails = (String[])emailList.toArray(new String[0]);
/*     */       
/* 355 */       MXServer.sendEMail(emails, adminEmail, subject, message);
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 360 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String composeMsg(MboSetRemote set, String site)
/*     */     throws MXException, RemoteException
/*     */   {
/* 381 */     Object[] param = { mxserver.getDate(), site };
/* 382 */     String msg = Resolver.getResolver().getMessage("pm", "CronPMGenWOResult").getMessage(param);
/*     */     
/* 384 */     if ((set != null) && (set.hasWarnings()))
/*     */     {
/* 386 */       Exception[] exs = set.getWarnings();
/*     */       
/* 388 */       for (int i = 0; i < exs.length; i++)
/*     */       {
/* 390 */         msg = msg + "\n" + exs[i].getMessage();
/*     */       }
/*     */     }
/*     */     
/* 394 */     return msg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLogFilePath()
/*     */   {
/* 402 */     return logFilePath;
/*     */   }
/*     */   
/* 405 */   PrintStream logWriter = null;
/* 406 */   boolean isSystem = true;
/* 407 */   MXLogger myLogger = MXLoggerFactory.getLogger("maximo.application.PM");
/*     */   
/*     */ 
/*     */   private void createLogFile()
/*     */     throws Exception
/*     */   {
/* 413 */     if (logFilePath.equalsIgnoreCase("stdout"))
/*     */     {
/* 415 */       logWriter = System.out;
/*     */     }
/* 417 */     else if (logFilePath.equalsIgnoreCase("stderr"))
/*     */     {
/* 419 */       logWriter = System.err;
/*     */     }
/*     */     else
/*     */     {
/* 423 */       isSystem = false;
				logFilePath = getParamAsString("logfile").trim();
				String path[]= logFilePath.split("_");
				System.out.println("from CustPMCronParamUpdate log file name = "+logFilePath);
				String runtime="";
				
				DateFormat fileDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
				runtime = fileDateFormat.format(MXServer.getMXServer().getDate());
				logFilePath = path[0]+"_"+runtime+".log";
				//param.setValue("value", logFilePath,MboConstants.NOVALIDATION_AND_NOACTION);
				System.out.println("from CustPMCronParamUpdate log file name after updation= "+logFilePath);
/* 424 */       logWriter = new PrintStream(new FileOutputStream(logFilePath, true));
/* 425 */       if (myLogger.isDebugEnabled())
/*     */       {
/* 427 */         myLogger.debug("preparelogfile" + logWriter);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void closeLogFile()
/*     */     throws Exception
/*     */   {
/* 440 */     if (logWriter == null)
/*     */     {
/* 442 */       return;
/*     */     }
/* 444 */     logWriter.println("");
/* 445 */     logWriter.flush();
/*     */     
/* 447 */     if (!isSystem)
/*     */     {
/* 449 */       logWriter.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void writeLog(String msg)
/*     */     throws Exception
/*     */   {
/* 458 */     if (logWriter == null)
/* 459 */       return;
/* 460 */     logWriter.println(msg);
/* 461 */     logWriter.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CrontaskParamInfo[] getParameters()
/*     */     throws MXException, RemoteException
/*     */   {
/*     */     try
/*     */     {
/* 471 */       String[] names = { "logfile" };
/* 472 */       String[] defs = { "c:\\temp\\PMwogenCron.log" };
/*     */       
/* 474 */       CrontaskParamInfo[] ret = new CrontaskParamInfo[names.length];
/* 475 */       for (int i = 0; i < names.length; i++)
/*     */       {
/* 477 */         ret[i] = new CrontaskParamInfo();
/* 478 */         ret[i].setName(names[i]);
/* 479 */         ret[i].setDefault(defs[i]);
/*     */       }
/* 481 */       return ret;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 485 */       if (getCronTaskLogger().isErrorEnabled())
/* 486 */         getCronTaskLogger().error(e); }
/* 487 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 497 */     super.start();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 502 */       if ((logFilePath != null) && (!logFilePath.equals("")))
/*     */       {
/* 504 */         if (!logFilePath.toString().equalsIgnoreCase(getParamAsString("logfile")))
/*     */         {
/* 506 */           logFilePath = getParamAsString("logfile");
/*     */         }
/*     */         
/* 509 */         logFilePath = logFilePath.trim();
/*     */       }
/* 511 */       else if ((logFilePath != null) && (logFilePath.trim().equals("")) && (!getParamAsString("logfile").trim().equals("")))
/*     */       {
/* 513 */         logFilePath = getParamAsString("logfile").trim();
/*     */       }
					//String logFilePath = param.getString("value");
					String path[]= logFilePath.split("_");
					System.out.println("from CustPMCronParamUpdate log file name = "+logFilePath);
					String runtime="";
					
					DateFormat fileDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
					runtime = fileDateFormat.format(MXServer.getMXServer().getDate());
					logFilePath = path[0]+"_"+runtime+".log";
					//param.setValue("value", logFilePath,MboConstants.NOVALIDATION_AND_NOACTION);
					System.out.println("from CustPMCronParamUpdate log file name after updation= "+logFilePath);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 518 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Suresh_work files\PSA\Source & Lib\psa76_lib\businessobjects.jar
 * Qualified Name:     psdi.app.pm.PMWoGenCronTask
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.1
 */