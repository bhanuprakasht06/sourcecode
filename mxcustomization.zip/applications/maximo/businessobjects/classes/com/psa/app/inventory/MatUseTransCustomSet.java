/**
 * @author	HCHA
 * Date		Jun 22, 2006
 * Comment	 
 */
package com.psa.app.inventory;

import java.rmi.RemoteException;
import psdi.util.MXException;
import psdi.app.inventory.MatUseTransSet;
import psdi.app.inventory.MatUseTransSetRemote;
import psdi.mbo.*;



/**
 * @author		HCHA
 * @class		MatUseTransCustomSet
 * @date		Jun 22, 2006
 * @function	
 */
public class MatUseTransCustomSet extends MatUseTransSet 
	implements MatUseTransSetRemote, MboSetListenable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param arg0
	 * @throws MXException
	 * @throws RemoteException
	 */
	public MatUseTransCustomSet(MboServerInterface arg0) throws MXException,
			RemoteException {
		super(arg0);

	}

    protected Mbo getMboInstance(MboSet mboset)
	    throws MXException, RemoteException
	{
	    return new MatUseTransCustom(mboset);
	}
}
