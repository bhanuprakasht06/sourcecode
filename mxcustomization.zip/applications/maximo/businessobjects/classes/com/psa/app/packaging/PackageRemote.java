// Decompiled by DJ v3.0.0.63 Copyright 2002 Atanas Neshkov  Date: 8/16/2009 11:03:56 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CustomMboRemote.java

package com.psa.app.packaging;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import java.rmi.RemoteException;
import psdi.util.MXException;

public interface PackageRemote
    extends MboRemote
{
	  public abstract void copyReserveItem(MboSetRemote paramMboSetRemote)
    throws MXException, RemoteException;
}