
package com.psa.app.packaging;

import psdi.mbo.MboSetRemote;
import java.rmi.RemoteException;
import psdi.util.MXException;

public interface PackageLinesSetRemote
    extends MboSetRemote
{
	public abstract void copyInvReserveSet(MboSetRemote paramMboSetRemote)
    	throws MXException, RemoteException;
}