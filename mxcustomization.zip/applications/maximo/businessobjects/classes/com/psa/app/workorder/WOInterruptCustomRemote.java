package com.psa.app.workorder;

import psdi.mbo.MboRemote;

public interface WOInterruptCustomRemote 
	extends MboRemote 
{
}
