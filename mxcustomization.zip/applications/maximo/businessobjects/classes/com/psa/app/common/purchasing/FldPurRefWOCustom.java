/*
 * Modification history
 * 23-06-06	HCHA	NA			Creation
 * 10-04-07	AGD	SR-087	Get the WO GL A/c rather than the work type GL A/c for capital work (cater for capital work defined WO per WO)
 * 01-05-07	AGD	SR-030	Set fincntrlid (supposed to be set by Maximo but somehow it's blanked off)
 * 11-11-08 HMD DR-065  Get the WO GL A/c rather than the work type GL A/c for capital work when auto generating RFQ from PR.
 */
package com.psa.app.common.purchasing;

import psdi.app.common.purchasing.FldPurRefWO;
import psdi.app.item.ItemRemote;
import psdi.app.item.ItemSetRemote;
import psdi.app.workorder.WorkTypeRemote;
import psdi.app.workorder.WorkTypeSetRemote;
import psdi.mbo.GLFormat;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import java.rmi.RemoteException;

public class FldPurRefWOCustom extends FldPurRefWO 
{

	//20061004 HCHA - Add 1 Type Segment
	//private static final String LABSERV_DEBIT_GL = "???-????-?-??-???-????-????-004";
	/*BCT modifications starts.
	 * COA structure change from 24 Bit to 28 Bit
	private static final String LABSERV_DEBIT_GL = "???-????-1-??-???-????-????-004";
	private static final String MATERIAL_RC = "???-????-1-??-???-????-????-003";
	private static final String SERVICE_RC = "???-????-1-??-???-????-????-005";*/
	
    private static final String LABSERV_DEBIT_GL = "???-???????-???-????-???-????-????";
    private static final String MATERIAL_RC = "???-???????-???-????-???-????-????";
    private static final String SERVICE_RC = "???-???????-???-????-???-????-????";
   
	/*BCT modifications ends.
	 * COA structure change from 24 Bit to 28 Bit
	 */

	public FldPurRefWOCustom(MboValue arg0) throws MXException {
		super(arg0);
	}


	public void action()
	    throws MXException, RemoteException
	{
		
		Mbo mbo = getMboValue().getMbo();
		System.out.println("-----------mbo--------------"+mbo);
		//System.out.println("[FldPurRefWOCustom.action()] Entering..."+mbo.getName());

		//Begin modification SR-030
		boolean skipOtherGLCode = false;
		MboRemote wo = mbo.getMboSet("WORKORDER").getMbo(0);
		//End modification SR-030

		//Check for if Work Order is of Capital Work Type 
		boolean isCapWorkType = false;
		System.out.println("-----------1--------------");
		if (!mbo.isNull("wonum")) 
		{
			String wonum = mbo.getString("wonum");
			if (wonum == null)
				wonum = mbo.getString("refwo");
			//	Begin modification SR-030 - We get the WO mbo above so the below part is not required any more
			/*WOSetRemote woSet = (WOSetRemote) MXServer.getMXServer().getMboSet("WORKORDER", mbo.getUserInfo());
			SqlFormat sqlformat = new SqlFormat(mbo.getUserInfo(), "wonum = :1 and siteid = :2");
			sqlformat.setObject(1, "WORKORDER", "WONUM", mbo.getString("wonum"));
			sqlformat.setObject(2, "WORKORDER", "SITEID", mbo.getString("siteid"));
			woSet.setWhere(sqlformat.format());
            
            if(!woSet.isEmpty())
            {
            	WORemote wo = (WORemote) woSet.getMbo(0);
			 */
			// End modification SR-030
			String woWorkType = wo.getString("WORKTYPE");
			System.out.println("-----------woWorkType--------------"+woWorkType);
			if(woWorkType != null)
			{
				System.out.println("-----------2--------------");
				//Get Worktype mbo
				WorkTypeSetRemote worktypeSet =(WorkTypeSetRemote) MXServer.getMXServer().getMboSet("WORKTYPE", mbo.getUserInfo());
    	    		
				SqlFormat sqlformatWOType = new SqlFormat(mbo.getUserInfo(), "worktype = :1 and orgid = :2");
				sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
				sqlformatWOType.setObject(2, "LABTRANS", "ORGID", mbo.getString("orgid"));
				worktypeSet.setWhere(sqlformatWOType.format());
    	            
				if(!worktypeSet.isEmpty())
				{
					System.out.println("-----------3--------------");
					WorkTypeRemote worktype = (WorkTypeRemote) worktypeSet.getMbo(0);
					isCapWorkType = worktype.getBoolean("capitalwork");
					if(isCapWorkType)
					{
						//Capital Type Work Order
						//Begin modification SR-087
						//String wotypeGlAccount = worktype.getString("glaccount");
						//if(wotypeGlAccount != null){
						//Set WO GL Account into LabTrans Gl Debit Account
						String wotypeGlAccount = wo.getString("glaccount");
						mbo.setValue("gldebitacct", wotypeGlAccount, 2L);
						//System.out.println("[FldPurRefWOCustom.action()] Capital Account..GL Debit Accout ="+wotypeGlAccount);
						//Begin modification SR-030 - Cannot return now as we also need to process things that are not GL related
						skipOtherGLCode = true;
            			/*
            			 * Call super.action recoded in the below method to avoid GL account issues
            			 * This is required as we skip the below call to super.action()
            			 */
    	            	superActionForCapitalWork();
    	            	//   	            			return;
    	            	// End modification SR-030
    	            	//   	            		}
    	            	// End modification SR-087
					}
				}
			}
			// Begin modification SR-087
			//	        }
			// End modification SR-087
		}
		System.out.println("-----------4--------------");
    	
		//	Begin modification SR-030
		if (!skipOtherGLCode)
		{
			System.out.println("-----------5--------------");
			//	End modification SR-030
			System.out.println("-----------wo--------------"+wo);		
			//Begin Modification DR-065
			String woWorkType = wo.getString("WORKTYPE");
			System.out.println("-----------6--------------");
			if(woWorkType != null) 
			{
				System.out.println("-----------7--------------");
				WorkTypeSetRemote worktypeSet = (WorkTypeSetRemote)MXServer.getMXServer().getMboSet("WORKTYPE", mbo.getUserInfo());
				SqlFormat sqlformatWOType = new SqlFormat(mbo.getUserInfo(), "worktype = :1 and orgid = :2");
				sqlformatWOType.setObject(1, "WORKTYPE", "WORKTYPE", woWorkType);
				sqlformatWOType.setObject(2, "LABTRANS", "ORGID", mbo.getString("orgid"));
				worktypeSet.setWhere(sqlformatWOType.format());
				if(!worktypeSet.isEmpty()) 
				{
					WorkTypeRemote worktype = (WorkTypeRemote)worktypeSet.getMbo(0);
					isCapWorkType = worktype.getBoolean("capitalwork");
				}
			}
			System.out.println("-----------8--------------");
			if(isCapWorkType) 
			{
				System.out.println("-----------9--------------");
				String wotypeGlAccount = wo.getString("glaccount");
				mbo.setValue("gldebitacct", wotypeGlAccount, 2L);
				//System.out.println("[FldPurRefWOCustom.action()] Capital Account..GL Debit Accout =" + wotypeGlAccount);
				superActionForCapitalWork();
			}
			else
			{
//				End Modification DR-065
				
			//System.out.println("[FldPurRefWOCustom.action()] Running super.action()...");
	    	super.action();
	    	System.out.println("-----------10--------------");
		    //Check for if it is Labor Service 	   
		    if(!mbo.isNull("itemnum")){
		        //Get item mbo
			    ItemSetRemote itemSet =(ItemSetRemote) MXServer.getMXServer().getMboSet("ITEM", mbo.getUserInfo());
			    	
			    SqlFormat sqlformatItemSet = new SqlFormat(mbo.getUserInfo(), "itemnum = :1 and itemsetid = :2");
			    sqlformatItemSet.setObject(1, "PRLINE", "ITEMNUM", mbo.getString("itemnum"));
			    sqlformatItemSet.setObject(2, "PRLINE", "ITEMSETID", mbo.getString("itemsetid"));
			    itemSet.setWhere(sqlformatItemSet.format());
			           
			    if(!itemSet.isEmpty())
			    {
			        ItemRemote item = (ItemRemote) itemSet.getMbo(0);
			        boolean isLabService = item.getBoolean("LABORSERVICE");
			        if(isLabService){
							
				        //Get current debit Glaccount
				        String curGLAccount = mbo.getString("gldebitacct");
						//System.out.println("[FldPurRefWOCustom.action()]Current Debit GL Account 1a: "+curGLAccount);
							
						if(curGLAccount!=null&&!curGLAccount.equals("")){
							GLFormat glformat = new GLFormat(LABSERV_DEBIT_GL, mbo.getString("orgid"));
							glformat.mergeString(curGLAccount);
							//System.out.println("[FldPurRefWOCustom.action()]Merged GL Account 1a:"+glformat.toDisplayString());
								
							mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
						}          		
			        }
			    }
		    }
		    else{
		    	//For Item Type = Service or Material => Merge GL Account with resource code
		     
		    /*
		        
		        //Code Making use of commodity group to fill in GL Account
		       
		    	if(!mbo.isNull("COMMODITYGROUP")){
		    		
		    		//Get AccountDefault MBO (Resource Code)
			    	AccountDefaultsSetRemote acctDefSet =(AccountDefaultsSetRemote) MXServer.getMXServer().getMboSet("ACCOUNTDEFAULTS", mbo.getUserInfo());
				    	
				    SqlFormat sqlformatAcctDefSet = new SqlFormat(mbo.getUserInfo(), "orgid = :1 and dfltgroup = :2 and groupvalue = :3");
				    sqlformatAcctDefSet.setObject(1, "ACCOUNTDEFAULTS", "ORGID", mbo.getString("ORGID"));
				    sqlformatAcctDefSet.setObject(2, "ACCOUNTDEFAULTS", "DFLTGROUP", "INVRESCODE" );
				    sqlformatAcctDefSet.setObject(3, "ACCOUNTDEFAULTS", "GROUPVALUE", mbo.getString("COMMODITYGROUP"));
				    acctDefSet.setWhere(sqlformatAcctDefSet.format());
				    if(!acctDefSet.isEmpty())
				    {
				    	AccountDefaultsRemote accDef = (AccountDefaultsRemote) acctDefSet.getMbo(0);
				    	String resourcecode = accDef.getString("GLDEFAULT");
				    	System.out.println("[FldPurRefWOCustom.action()]Resource:"+resourcecode);
				    	
				        //Get current debit Glaccount
				        String curGLAccount = mbo.getString("gldebitacct");
						System.out.println("[FldPurRefWOCustom.action()]Current Debit GL Account:"+curGLAccount);
							
						if(resourcecode!=null && curGLAccount!=null && !resourcecode.equals("") && !curGLAccount.equals("")){
							GLFormat glformat = new GLFormat(resourcecode, mbo.getString("orgid"));
							glformat.mergeString(curGLAccount);
							System.out.println("[FldPurRefWOCustom.action()]Merged GL Account:"+glformat.toDisplayString());
								
							mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
						}  
				    	
				    }
		    	}
		    */
		    	String linetype = mbo.getString("LINETYPE");
		    	
		    	if(linetype.equalsIgnoreCase("MATERIAL")){
		    		//Get current debit Glaccount
			        String curGLAccount = mbo.getString("gldebitacct");
					//System.out.println("[FldPurRefWOCustom.action()]Current Debit GL Account:"+curGLAccount);
						
					if(curGLAccount!=null  && !curGLAccount.equals("")){
						GLFormat glformat = new GLFormat(MATERIAL_RC, mbo.getString("orgid"));
						glformat.mergeString(curGLAccount);
						//System.out.println("[FldPurRefWOCustom.action()]Merged GL Account 1:"+glformat.toDisplayString());
							
						mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
					}  	    		
		    	}
		    	else if(linetype.equalsIgnoreCase("SERVICE")){
		    		//Get current debit Glaccount
			        String curGLAccount = mbo.getString("gldebitacct");
					//System.out.println("[FldPurRefWOCustom.action()]Current Debit GL Account:"+curGLAccount);
						
					if(curGLAccount!=null  && !curGLAccount.equals("")){
						GLFormat glformat = new GLFormat(SERVICE_RC, mbo.getString("orgid"));
						glformat.mergeString(curGLAccount);
						//System.out.println("[FldPurRefWOCustom.action()]Merged GL Account 2:"+glformat.toDisplayString());
							
						mbo.setValue("gldebitacct", glformat.toDisplayString(), 2L);	
					} 
		    	}
		    }
//		  Begin Modification DR-065
		}//end of else
//			End Modification DR-065
				
// Begin modification SR-030
		}	// End if (!skipOtherGLCode)

		mbo.setValue("fincntrlid", wo.getString("fincntrlid"));
// End modification SR-030
	}


// Begin modification SR-030
	/*
	 * This method should be called as a replacement of super.action only when handling capital work
	 * Basically, it calls super, ignores the error that will definitely be thrown because of the GL account
	 * then proceeds with the code from super.action() that is after the line throwing the exception
	 */
	private void superActionForCapitalWork()
			throws MXException, RemoteException
	{
		Mbo mbo = getMboValue().getMbo();
      MboRemote mboremote = null;
      if(!getMboValue().isNull())
          mboremote = mbo.getMboSet("$CommonWorkOrder", "WORKORDER", "wonum=:refwo").getMbo(0);

      try {
			super.action();
		}
		catch (MXApplicationException e) {
			// Ignore GL account exception thrown
		}

		if (getMboValue().isNull())
		{
			if (!mbo.getBoolean("issue"))
				mbo.setFieldFlag("storeloc", 7L, false);
			mbo.setValue("chargestore", false, 2L);
			String s = getTranslator().toInternalString("linetype", mbo.getString("linetype"));
			if (s.equals("SERVICE") || s.equals("STDSERVICE"))
				mbo.setFieldFlag("chargestore", 7L, false);
			mbo.setValueNull("fincntrlid", 11L);
			if (s.equalsIgnoreCase("MATERIAL") || s.equalsIgnoreCase("SERVICE") || s.equalsIgnoreCase("STDSERVICE"))
			{
				return;
			}
			else
			{
				mbo.setValue("issue", false, 2L);
				mbo.setFieldFlag("issue", 7L, false);
				return;
			}
		}
		mbo.setValue("issue", true, 2L);
		mbo.setFieldFlag("issue", 7L, true);
		if (mboremote.getBoolean("chargestore"))
		{
			mbo.setValue("chargestore", true, 11L);
			mbo.setFieldFlag("assetnum", 7L, true);
			mbo.setFieldFlag("location", 7L, true);
			mbo.setFieldFlag("chargestore", 7L, true);
		}
		else
		{
			mbo.setValue("chargestore", false, 11L);
			mbo.setFieldFlag("assetnum", 7L, false);
			mbo.setFieldFlag("location", 7L, false);
		}
	}
// End modification SR-030

}
