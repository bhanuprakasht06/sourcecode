package com.psa.app.workorder;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.io.*;

import psdi.app.inventory.InvBalancesRemote;
import psdi.app.inventory.InvBalancesSetRemote;
import psdi.app.inventory.InventoryRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.server.MXServer;
import psdi.mbo.*;
import psdi.app.inventory.MatRecTransRemote;
import psdi.app.inventory.MatRecTrans;
import psdi.app.location.*;
import psdi.app.inventory.*;
import java.rmi.RemoteException;
import java.sql.SQLException;
import psdi.app.inventory.MatRecTransRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.DBShortcut;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import com.psa.app.workorder.RecondUtilCustom;



/*
 * Prints items reservations on storeroom's fax machine
 */
public class RecWorkorderIssue
                implements ActionCustomClass
{
        public RecWorkorderIssue()
        {
        }


        public void applyCustomAction(MboRemote mboremote, Object aobj[])
    throws MXException, RemoteException
    {
                                                        wo = mboremote;
                                                mxLogger.debug("TransferPlansCustom - Entering");
                                                        MboSetRemote woset = wo.getThisMboSet();
                                                String wonum = wo.getString("wonum");

                                                        MboSetRemote wpMaterialset = wo.getMboSet("LOANPLANMATERIALS");
                                                        if (wpMaterialset.isEmpty())
                                                                return;
                                                        MboRemote wpMaterialmbo =  wpMaterialset.getMbo(0);
                                                        String loanid = wpMaterialmbo.getString("LOANID");
                                                        if (loanid.equalsIgnoreCase("") || loanid == null || loanid.length() < 2)
                                                                return;
                                                MboSetRemote invreserveSet = MXServer.getMXServer().getMboSet("INVRESERVE", wo.getUserInfo());
                                                SqlFormat qsqf1 = new SqlFormat(wo.getUserInfo(), "wonum=:1");
                                                qsqf1.setObject(1, "INVRESERVE", "wonum",wonum);
                                                invreserveSet.setWhere(qsqf1.format());
                                                MboRemote invreserveMbo;
                                                MboSetRemote issueset = null;
                                                for (int i=0; (invreserveMbo = invreserveSet.getMbo(i)) != null;i++)
                                                {
                                                        String location = invreserveMbo.getString("LOCATION");
                                                        MboSetRemote storelocSet = wo.getMboSet("$LOCATIONS", "LOCATIONS", "location='"+location+"' and type='STOREROOM'" );
                                                        if (!storelocSet.isEmpty())
                                                        {
                                                                MboRemote storeroom=storelocSet.getMbo(0);
                                                                issueset=storeroom.getMboSet("MATUSETRANSISSUE");
                                                                MboRemote issue=issueset.add();
                                                                issue.setValue("siteid", invreserveMbo.getString("STORELOCSITEID"),2L);
                                                                issue.setValue("storeloc", invreserveMbo.getString("LOCATION"),2L);
                                                                issue.setValue("tositeid", invreserveMbo.getString("SITEID"),2L);
                                                                issue.setValue("wonum", invreserveMbo.getString("WONUM"),2L);
                                                                issue.setValue("itemnum", invreserveMbo.getString("ITEMNUM"),2L);
                                                                issue.setValue("linetype", "ITEM",2L);
                                                                issue.setValue("issuetype", "ISSUE",2L);

/*---------------------------------------------------------Code to get fromstoreloc binnum & lotnum Aravind changed March 21st 2012----------*/
																MboSetRemote matrectransSet = MXServer.getMXServer().getMboSet("MATRECTRANS", wo.getUserInfo());
																SqlFormat qsqf2 = new SqlFormat(wo.getUserInfo(), "loanid =:1 and itemnum =:2 and fromstoreloc =:3 and quantity=:4");
																qsqf2.setObject(1, "MATRECTRANS", "loanid", loanid);
																qsqf2.setObject(2, "MATRECTRANS", "itemnum",invreserveMbo.getString("ITEMNUM"));
																qsqf2.setObject(3, "MATRECTRANS", "fromstoreloc",invreserveMbo.getString("LOCATION"));
																qsqf2.setObject(4, "MATRECTRANS", "quantity", invreserveMbo.getString("RESERVEDQTY"));
																matrectransSet.setWhere(qsqf2.format());
																String binnum = null;
																String lotnum = null;
																String condcode = null;
																if (!matrectransSet.isEmpty())
																{
																	MboRemote matrectrans=matrectransSet.getMbo(0);
																	binnum =  matrectrans.getString("FROMBIN");
																	lotnum =  matrectrans.getString("FROMLOT");
																	condcode =  matrectrans.getString("CONDITIONCODE");
																}
                                                                issue.setValue("BINNUM", binnum,2L);
                                                                issue.setValue("LOTNUM", lotnum,2L);
/*---------------------------------------------------End of getting lotnum and binnum------------------------------------------------------*/
                                                                issue.setValue("conditioncode", condcode,2L);
                                                                issue.setValue("QTYREQUESTED", invreserveMbo.getDouble("RESERVEDQTY"),2L);
                                                                double QUANTITY =  invreserveMbo.getDouble("RESERVEDQTY") * -1.0D;
                                                                issue.setValue("QUANTITY", QUANTITY,2L);
                                                                issue.setValue("enterby", wo.getUserName(),2L);

                                                                issueset.save();
                                                        }
                                                }

                                                MboSetRemote invreserveDelSet = MXServer.getMXServer().getMboSet("INVRESERVE", wo.getUserInfo());
                                                //System.out.println("-delete invreserve-2-");
                                                SqlFormat qsqf = new SqlFormat(wo.getUserInfo(), "wonum=:1");
                                                //System.out.println("-delete invreserve-3-");
                                                qsqf.setObject(1, "INVRESERVE", "wonum",wonum);
                                                //System.out.println("-delete invreserve-4-");
                                                invreserveDelSet.setWhere(qsqf.format());
                                                //System.out.println("-delete invreserve-5-");
                                                if(!invreserveDelSet.isEmpty())
                                                {
                                                        invreserveDelSet.deleteAll();
                                                        invreserveDelSet.save();
                                                }
                                                //System.out.println("-delete invreserve-7-");

        }

        private MboRemote wo;
        private MXServer mxserver;
        private static final MXLogger   mxLogger        = MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}
