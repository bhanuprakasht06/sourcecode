package com.psa.app.appurl;

import java.rmi.RemoteException;

import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

public class FldUrlCustom extends MboValueAdapter {

	public FldUrlCustom() {
		// TODO Auto-generated constructor stub
	}

	public FldUrlCustom(MboValue mbv) {
		super(mbv);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void action() throws MXException, RemoteException {
		// TODO Auto-generated method stub
		super.action();
		String urlValue=getMboValue().getString();
		if((urlValue!=null)&&!(urlValue.equals(""))&&!(urlValue.contains(":")))
		{
			urlValue="http://"+urlValue;
			getMboValue().setValue(urlValue,11L);
		}
	}
	
}
