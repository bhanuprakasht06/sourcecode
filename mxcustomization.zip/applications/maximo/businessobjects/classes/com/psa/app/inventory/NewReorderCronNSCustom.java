package com.psa.app.inventory;

import com.psa.custom.common.MxEmail;
import com.psa.custom.ois.MxLog;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import psdi.app.contract.ContractServiceRemote;
import psdi.app.pr.PRLineSetRemote;
import psdi.app.pr.PRSetRemote;
import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.app.workorder.WO;
import psdi.app.workorder.WPItemRemote;
import psdi.mbo.*;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.txn.MXTransaction;
import psdi.util.MXException;
import psdi.util.MXSession;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class NewReorderCronNSCustom extends SimpleCronTask
{
    private class ItemGroup
    {
		ItemGroup()
		{
			grouping = new HashMap();
		}
		void add(String contract, String vendor, MboRemote mbo)
		{
			String key = null;
			if (vendor != null)
				if (contract != null)
					key = contract + "|" + vendor;
				else
					key = "|" + vendor;

			ArrayList value = new ArrayList();
			if (grouping.containsKey(key))
				value = (ArrayList) grouping.get(key);
			value.add(mbo);
			grouping.put(key, value);	// replace the previous value if it existed
		}
		Set keySet()
		{
			return grouping.keySet();
		}
		ArrayList get(String key)
		{
			return (ArrayList)grouping.get(key);
		}
		private HashMap grouping;
    }


    public NewReorderCronNSCustom()
    {
        logFilePath = null;
        userInfo = null;
        logger = MXLoggerFactory.getLogger("maximo.application.INVENTOR");
        emailSubj = null;
        al=new ArrayList();
        email = new MxEmail();
        mxLog = new MxLog();
    }

    public void init()
        throws MXException
    {
        super.init();        
    }

    public void start()
    {
        try
        {
            logger.info((new StringBuilder(String.valueOf(getName()))).append(" Start").toString());
            if(getSleepTime() < 10000L)
            {
                mxLog.writeLog("Starting crontask");
                setSleepTime(0L);
            } else
            {
                logger.info((new StringBuilder(String.valueOf(getName()))).append(" crontask not yet scheduled : stopping now").toString());
            }
        }
        catch(Exception e)
        {
            logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
        }
    }

    public void stop()
    {
        logger.info((new StringBuilder(String.valueOf(getName()))).append(" Stop").toString());
        if(mxLog.isEnabled())
            try
            {
                mxLog.writeLog("Stopping crontask");
                mxLog.closeLogFile();
            }
            catch(Exception e)
            {
                logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
            }
    }

    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
    {
        try
        {
            super.setCrontaskInstance(crontaskinstanceremote);
        }
        catch(Exception e)
        {
            logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
        }
    }

    public CrontaskParamInfo[] getParameters()
        throws MXException, RemoteException
    {
        return params;
    }

    public void cronAction()
    {
        try
        {
            logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Start of CronTask action").toString());
            readConfig();
            if(!processData())
            {
            	mxLog.writeLog((new StringBuilder("Some data have problems. See log file : ")).toString());
                String message = (new StringBuilder("Some data have problems. See log file ")).append(mxLog.getLogFilePath()).append(" for details").toString();
                email.send(emailSubj, genEmail(message, ""));
                logger.info((new StringBuilder(String.valueOf(getName()))).append(" Email sent").toString());
                //new code starts
                	Iterator itr=al.iterator();
                	StringBuffer sb=new StringBuffer();
                	while(itr.hasNext())
                	{
                		sb.append("'");
                		sb.append(itr.next());
                		sb.append("'");
                		sb.append(",");
                	}
                	sb.deleteCharAt(sb.length()-1);
                	MboSetRemote woList = mxserver.getMboSet("workorder", userInfo);
                	woList.setWhere("wonum in "+"("+sb.toString()+")");
                	sb.delete(0, sb.length());
                	al.removeAll(al);
                	
                	for(int i=0;i<woList.count();i++)
                	{                		
                		WO wo = (WO)woList.getMbo(i);
                		wo.changeStatus(getParamAsString("wostatus"), MXSession.getSession().getDate(), "Error occured in NS REORDER");
                		woList.save();
                   	}
                	
                	woList.close();
                	
                	
                //new code ends
                
            }
            logger.debug((new StringBuilder(String.valueOf(getName()))).append(" End of CronTask action").toString());
        }
        catch(Exception e)
        {
            String message = e.getMessage();
            String stack = getStackTrace(e);
            logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).toString(), e);
            mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
            email.send(emailSubj, genEmail(message, stack));
            logger.info((new StringBuilder(String.valueOf(getName()))).append(" Email sent").toString());
            stop();
        }
    }

    private void readConfig()
        throws RemoteException, MXException
    {
        mxserver = MXServer.getMXServer();
        userInfo = getRunasUserInfo();
        DateFormat fileDateFormat = new SimpleDateFormat("d-MMM-yy HH:mm");
        String runtime = fileDateFormat.format(mxserver.getDate());
        logFilePath = getParamAsString("logfile");
        if(logFilePath != null)
        {
            logFilePath = logFilePath.trim();
            if(logFilePath.equals(""))
            {
                logFilePath = null;
            } else
            {
                fileDateFormat = new SimpleDateFormat("yyMMddHHmm");
                runtime = fileDateFormat.format(mxserver.getDate());
                logFilePath = logFilePath.replaceAll("yyyymmddhhmm", runtime);
                mxLog.setEnabled(true);
                mxLog.setLogFilePath(logFilePath);
                mxLog.setLogTag(getName());
                try
                {
                    mxLog.createLogFile();
                }
                catch(Exception e)
                {
                    logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
                }
            }
        }
        email.setToMail(getParamAsString("emailto"));
        Properties properties = mxserver.getConfig();
        email.setFromMail(properties.getProperty("mxe.adminEmail", null));
        emailSubj = getParamAsString("alertemailsubj");
    }

    private boolean processData()
        throws Exception
    {
        boolean noproblem = true;
        MboSetRemote woList = mxserver.getMboSet("workorder", userInfo);
        SqlFormat sqlformat = new SqlFormat("status IN (SELECT value FROM synonymdomain WHERE domainid='WOSTATUS' AND MAXVALUE IN ('APPR','WSCH','WMATL','INPRG'))");
        woList.setWhere(sqlformat.format());
        MboRemote wo = null;
        int prcounter = 0;
        for(int i = 0; (wo = woList.getMbo(i)) != null; i++)
            try
            {
            	
                MboSetRemote wpset = wo.getMboSet("wpitem");
                sqlformat = new SqlFormat("siteid=:1 AND wonum=:2 AND directreq=1 AND pr IS NULL");
                sqlformat.setObject(1, "wpitem", "siteid", wo.getString("siteid"));
                sqlformat.setObject(2, "wpitem", "wonum", wo.getString("wonum"));
                wpset.setWhere(sqlformat.format());
                if(!wpset.isEmpty())
                {
                    String wonum = wo.getString("wonum");
                    logger.info((new StringBuilder(String.valueOf(getName()))).append(" Reordering for WO ").append(wonum).toString());
                    mxLog.writeLog((new StringBuilder("Reordering for WO ")).append(wonum).toString());
                    mxLog.writeLog("Total workorder "+woList.count()+"Loop Counter"+i);
                    if(!wo.isNull("description"))
                        prdesc = wo.getString("description");
                    else
                        prdesc = "";
                    if(!wo.isNull("description_longdescription"))
                        prdescLong = wo.getString("description_longdescription");
                    else
                        prdescLong = "";
                    mxLog.writeLog((new StringBuilder("Description for WO: ")).append(prdesc).toString());
                    mxLog.writeLog((new StringBuilder("Long Description for WO: ")).append(prdescLong).toString());
                    ItemGroup itemgroup = new ItemGroup();
                    MboRemote wp = null;
                    for(int j = 0; (wp = wpset.getMbo(j)) != null; j++)
                    {
                        String itemnum = null;
                        String contractnum = null;
                        String vendor = null;
                        if(!wp.isNull("vendor"))
                            vendor = wp.getString("vendor");
                        if(!wp.isNull("itemnum"))
                        {
                            itemnum = wp.getString("itemnum");
                            logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Searching for a contract for item ").append(itemnum).toString());
                            ContractServiceRemote contractservice = (ContractServiceRemote)MXServer.getMXServer().lookup("CONTRACT");
                            Vector contractauthvector = contractservice.findValidContracts(wp, null, null, true);
                            if(contractauthvector.isEmpty())
                                contractauthvector = contractservice.findValidContracts(wp, null, null, false);
                            Vector validcontracts = new Vector();
                            for(Enumeration enumeration = contractauthvector.elements(); enumeration.hasMoreElements();)
                            {
                                MboRemote contractauth = (MboRemote)enumeration.nextElement();
                                MboRemote contract = contractauth.getMboSet("CONTRACT").getMbo(0);
                                if(!validcontracts.contains(contract))
                                    validcontracts.add(contract);
                            }

                            if(!validcontracts.isEmpty())
                            {
                                for(Enumeration enumeration = validcontracts.elements(); enumeration.hasMoreElements();)
                                {
                                    MboRemote contract = (MboRemote)enumeration.nextElement();
                                    if(contract.getString("vendor").equals(vendor))
                                    {
                                        contractnum = contract.getString("contractnum");
                                        break;
                                    }
                                }

                                if(contractnum == null)
                                {
                                    MboRemote contract = (MboRemote)validcontracts.elementAt(0);
                                    vendor = contract.getString("vendor");
                                    contractnum = contract.getString("contractnum");
                                }
                            }
                        }
                        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Adding to the reorder list: ").append(itemnum).append("/").append(wp.getString("description")).append("\t-->\t").append(contractnum).append("/").append(vendor).toString());
                        itemgroup.add(contractnum, vendor, wp);
                    }

                    PRSetRemote prset = (PRSetRemote)mxserver.getMboSet("PR", userInfo);
                    MXTransaction mxtransaction = prset.getMXTransaction();
                    wpset.setMXTransaction(mxtransaction);
                    boolean mustsave = true;
                    Set groups = itemgroup.keySet();
                    for(Iterator iterator = groups.iterator(); iterator.hasNext() && mustsave;)
                    {
                        String group = (String)iterator.next();
                        try
                        {
                            generatePR(prset.add(), group, itemgroup.get(group), wpset);
                            prcounter++;
                        }
                        catch(Exception e)
                        {
                            String message = (new StringBuilder("Cannot create PR for WO ")).append(wonum).toString();
                            logger.warn((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(". See log file for details").toString());
                            mxLog.writeLog((new StringBuilder("|--")).append(message).append("\n").append(e.getMessage()).append("\n").append(getStackTrace(e)).toString());
                            noproblem = false;
                            mustsave = false;
                        }
                    }

                    if(mustsave)
                    {
                        mxtransaction.commit();
                        logger.info((new StringBuilder(String.valueOf(getName()))).append(" WO and related PR saved successfully for WO ").append(wonum).toString());
                        mxLog.writeLog((new StringBuilder("|--WO and related PR saved successfully for WO ")).append(wonum).toString());
                    } else
                    {
                        mxtransaction.rollback();
                        String errormessage = (new StringBuilder("No PR created for WO ")).append(wonum).toString();
                        logger.info((new StringBuilder(String.valueOf(getName()))).append(" ").append(errormessage).toString());
                        mxLog.writeLog((new StringBuilder("|--")).append(errormessage).toString());
                        al.add(wonum);
                       // ((StatefulMbo) wo).changeStatus(getParamAsString("wostatus"),MXSession.getSession().getDate(), "Error occured in NS REORDER");
    					
    					//mxLog.writeLog("|--Status changed for workorder to WAPPR"+woList.count());
                    }
                }
            }
            catch(Exception e)
            {
                String message = (new StringBuilder("Problem reordering for WO ")).append(wo.getString("wonum")).toString();
                logger.warn((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(". See log file for details").toString());
                mxLog.writeLog((new StringBuilder("|--")).append(message).append("\n").append(e.getMessage()).append("\n").append(getStackTrace(e)).toString());
                noproblem = false;
                //((StatefulMbo) wo).changeStatus(getParamAsString("wostatus"),MXSession.getSession().getDate(), "Error occured in NS REORDER");
				//wo.getThisMboSet().save();
				al.add(wo.getString("wonum"));
            }

        logger.info((new StringBuilder(String.valueOf(getName()))).append(" Total : ").append(prcounter).append(" PR created").toString());
        mxLog.writeLog((new StringBuilder("Total : ")).append(prcounter).append(" PR created").toString());
        //woList.save();
        return noproblem;
    }

    private void generatePR(MboRemote pr, String group, ArrayList wpitems, MboSetRemote wpsetforupdate)
        throws Exception
    {
        String contractnum = null;
        String vendor = null;
        String message = (new StringBuilder("Creating PR ")).append(pr.getString("prnum")).toString();
        if(group != null)
        {
            int index = group.indexOf("|");
            if(index > 0)
                contractnum = group.substring(0, index);
            vendor = group.substring(index + 1);
            message = (new StringBuilder(String.valueOf(message))).append(" for contract=").append(contractnum).append(" vendor=").append(vendor).toString();
        } else
        {
            message = (new StringBuilder(String.valueOf(message))).append(" without contract nor vendor").toString();
        }
        logger.info((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).toString());
        mxLog.writeLog((new StringBuilder("|--")).append(message).toString());
        pr.setValue("buyahead", false, 2L);
        Date date = mxserver.getDate();
        pr.setValue("changedate", date, 2L);
        pr.setValue("changeby", userInfo.getPersonId(), 2L);
        MboRemote wp = (MboRemote)wpitems.get(0);
        pr.setValue("description", prdesc);
        pr.setValue("description_longdescription", prdescLong);
        pr.setValue("requestedby", wp.getString("requestby"));
        pr.setValue("requireddate", wp.getString("requiredate"));
        String siteid = wp.getString("siteid");
        pr.setValue("siteid", siteid, 2L);
        String orgid = wp.getString("orgid");
        pr.setValue("orgid", orgid, 2L);
        if(vendor != null)
            pr.setValue("vendor", vendor);
        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" PR tab general data set").toString());
        MboRemote contract = null;
        if(contractnum != null)
        {
            contract = getContractMbo(contractnum);
            pr.setValue("contractrefid", contract.getString("contractid"), 2L);
            pr.setValue("contractrefnum", contractnum, 2L);
            pr.setValue("contractrefrev", contract.getInt("revisionnum"), 2L);
            pr.setValue("currencycode", contract.getString("currencycode"), 2L);
        }
        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" PR data related to the contract set").toString());
        MboRemote site = getSiteMbo(siteid);
        //Start -- Modified to suite Maximo 7.6 framework - Comm-IT
        MboRemote billtoShiptoBillingMbo = site.getMboSet("BILLTODEFAULT").getMbo(0);
        MboRemote billtoShiptoShippingMbo = site.getMboSet("SHIPTODEFAULT").getMbo(0);
        
        
        //if(site.isNull("billtoaddresscode"))
        if(billtoShiptoBillingMbo != null) 	//End -- Modified to suite Maximo 7.6 framework - Comm-IT
        {
            MboRemote wo = wp.getMboSet("WORKORDER").getMbo(0);
            MboRemote location = wo.getMboSet("LOCATION").getMbo(0);
            String prefix = location.getString("prefix");
            String realsiteid;
            if(prefix.equalsIgnoreCase("K"))
                realsiteid = "KT";
            else
            if(prefix.equalsIgnoreCase("B"))
                realsiteid = "BT";
            else
            if(prefix.equalsIgnoreCase("T"))
                realsiteid = "TPT";
            else
            if(prefix.equalsIgnoreCase("P1"))
                realsiteid = "PPT1";
            else
                realsiteid = "PPT2";
            site = getSiteMbo(realsiteid);
        }
        
        //Start -- Modified to suite Maximo 7.6 - Comm-IT
        if ((pr.getString("billto").equals("")) && (billtoShiptoBillingMbo != null)) 
        {
        	pr.setValue("billto", billtoShiptoBillingMbo.getString("addresscode"), 11L);
        }
        if ((pr.getString("shipto").equals("")) && (billtoShiptoShippingMbo != null))
        {
        	pr.setValue("shipto", billtoShiptoShippingMbo.getString("addresscode"), 11L);
        	if (billtoShiptoShippingMbo.getString("shiptocontact").equals(""))
        		pr.setValue("shiptoattn", userInfo.getPersonId());
        	else
        		pr.setValue("shiptoattn", billtoShiptoShippingMbo.getString("shiptocontact"), 11L);
        }
        if ((pr.getString("billtoattn").equals("")) && (billtoShiptoBillingMbo != null)) 
        {
        	if (billtoShiptoShippingMbo.getString("billtocontact").equals(""))
        		pr.setValue("billtoattn", userInfo.getPersonId());
        	else
        		pr.setValue("billtoattn", billtoShiptoBillingMbo.getString("billtocontact"), 11L);
        }
        
        /*if(!site.isNull("billtoaddresscode"))
            pr.setValue("billto", site.getString("billtoaddresscode"));
        if(!site.isNull("shiptoaddresscode"))
            pr.setValue("shipto", site.getString("shiptoaddresscode"));
        if(site.isNull("billtolaborcode"))
            pr.setValue("billtoattn", userInfo.getPersonId());
        else
            pr.setValue("billtoattn", site.getString("billtolaborcode"));
        if(site.isNull("shiptolaborcode"))
            pr.setValue("shiptoattn", userInfo.getPersonId());
        else
            pr.setValue("shiptoattn", site.getString("shiptolaborcode"));*/
        //End -- Modified to suite Maximo 7.6 - Comm-IT
        
        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" PR data related to ship to... set").toString());
        PRLineSetRemote prlineset = (PRLineSetRemote)pr.getMboSet("prline");
        WPItemRemote wpitem;
        MboRemote prline;
        for(Iterator iterator = wpitems.iterator(); iterator.hasNext(); generatePRLine(prline, pr, wpitem, contract, wpsetforupdate))
        {
            wpitem = (WPItemRemote)iterator.next();
            prline = prlineset.add();
        }

        logger.info((new StringBuilder(String.valueOf(getName()))).append(" PR ").append(pr.getString("prnum")).append(" created but not saved yet").toString());
        mxLog.writeLog((new StringBuilder("|--PR ")).append(pr.getString("prnum")).append(" created but not saved yet").toString());
    }

    private void generatePRLine(MboRemote prline, MboRemote pr, WPItemRemote wp, MboRemote contract, MboSetRemote wpsetforupdate)
        throws Exception
    {
        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Adding PR line for item=").append(wp.getString("itemnum")).append(", desc=").append(wp.getString("description")).toString());
        String linetype = wp.getString("linetype");
        prline.setValue("linetype", linetype);
        if(wp.isNull("itemnum"))
        {
            prline.setValue("description", wp.getString("description"));
        } else
        {
            prline.setValue("itemnum", wp.getString("itemnum"));
            if(!wp.isNull("conditioncode"))
                prline.setValue("conditioncode", wp.getString("conditioncode"));
            else
            if(linetype.equalsIgnoreCase("ITEM"))
            {
                MboRemote itemconditionfull = wp.getMboSet("ITEMCONDITION_FULL").getMbo(0);
                if(itemconditionfull != null)
                    prline.setValue("conditioncode", itemconditionfull.getString("conditioncode"));
            }
        }
        if(!wp.isNull("description_longdescription"))
            prline.setValue("description_longdescription", wp.getString("description_longdescription"));
        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Batch 1/3 of PR line data set").toString());
        prline.setValue("wonum", wp.getString("wonum"), 2L);
        prline.setValue("reqdeliverydate", wp.getString("requiredate"));
        prline.setValue("requestedby", wp.getString("requestby"));
        if(!wp.isNull("orderunit"))
            prline.setValue("orderunit", wp.getString("orderunit"), 2L);
        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Batch 2/3 of PR line data set").toString());
        if(prline.isNull("contractrefnum"))
        {
            double unitcost = 0.0D;
            if(!wp.isNull("unitcost"))
                unitcost = wp.getDouble("unitcost");
            prline.setValue("unitcost", unitcost, 2L);
        }
        prline.setValue("orderqty", wp.getDouble("itemqty"), 2L);
        prline.setValue("linecost2", 0, 2L);
        prline.setValue("mktplcitem", 0, 2L);
        
//Start************Ref 4.2.1***********
		
		if (!prline.isNull("contractrefnum")&&getParamAsString("validationenabled").equals("1"))

		{
			mxLog.writeLog("|--BA Validation is Enabled and Contract is not null in PRLINE");
			double prcost=0.0,apprpocost=0.0,closepocost=0.0,outstanding=0.0;
			String prlinecontract=prline.getString("contractrefnum");
			MboRemote prlineconmbo=getContractMbo(prlinecontract);
			
			DBShortcut dbshortcut = new DBShortcut();
			try{
				
			dbshortcut.connect(this.userInfo.getConnectionKey());
			SqlFormat sqlformat = new SqlFormat(this.userInfo, "SELECT coalesce(sum(LINECOST),0) AS PRCOST FROM PRLINE A, PR B WHERE A.PRNUM = B.PRNUM AND A.CONTRACTREFID=:1 AND B.STATUS='APPR' ");
			sqlformat.setObject(1,"PRLINE","CONTRACTREFID",prlineconmbo.getString("CONTRACTID") );
			ResultSet rs = dbshortcut.executeQuery(sqlformat.format());
			    if (rs.next())
			     {
			    	prcost = rs.getDouble("PRCOST");
			     }
			     rs.close();
			     
			     	SqlFormat sqlformat2 = new SqlFormat(this.userInfo, "SELECT (SELECT coalesce(sum(LINECOST),0.0) AS POCOST FROM POLINE A, PO B WHERE A.PONUM = B.PONUM AND A.CONTRACTREFID=:1 AND B.STATUS IN ('APPR','CLOSE') ) - ( SELECT coalesce(sum(LINECOST),0.0) AS POCOST FROM POLINE A, PO B WHERE A.PONUM = B.PONUM AND A.CONTRACTREFID=:1 AND B.STATUS IN ('APPR','CLOSE') AND B.RECEIPTS ='COMPLETE' and A.RECEIVEDTOTALCOST = '0') POCOST from DUAL");
					sqlformat2.setObject(1,"POLINE","CONTRACTREFID",prlineconmbo.getString("CONTRACTID") );
					ResultSet rs2 = dbshortcut.executeQuery(sqlformat2.format());
					    if (rs2.next())
					     { 
					    	apprpocost =rs2.getDouble("POCOST");
					     }
					     rs2.close();
					    
				outstanding=prlineconmbo.getDouble("PURCHVIEW.MAXVOL")-(prcost+apprpocost);
				mxLog.writeLog("|--Outstanding Amount for this Contract "+prlineconmbo.getString("CONTRACTNUM")+"is SGD"+outstanding);
							
			}
			catch (Exception e)
			{	mxLog.writeLog("|--Caught Exception in BA Validation"+e.toString());
				e.printStackTrace();
			}
			
			 if(prline.getDouble("LINECOST")>outstanding)
			 {	mxLog.writeLog("|--Line Cost is "+prline.getDouble("LINECOST")+" which is more than outsatnding amount");
				/* MboSetRemote WOset=wp.getMboSet("WORKORDER");
				 if(!WOset.isEmpty())
				  {
					 System.out.println("@@@@@@@@@WOSET IS NOT EMPTY @@@@@@@@@");
					 WO wombo=(WO)WOset.getMbo(0);
				 wombo.changeStatus(getParamAsString("wostatus"), mxserver.getDate(), "BA AMOUNT EXHAUSTED");
				 WOset.save();
				 mxLog.writeLog("|--Changed Work order status to "+getParamAsString("wostatus")+" BA validation fails");
				  }
				 //noproblem=false;
				  
				  */
				 throw new Exception("BA AMOUNT EXHAUSTED");
			 }
		}
		//End ************Ref 4.2.1***********
		
        
        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Batch 3/3 of PR line data set").toString());
        MboRemote wpforupdate = null;
        long prlineid = wp.getLong("wpitemid");
        for(int j = 0; (wpforupdate = wpsetforupdate.getMbo(j)) != null; j++)
        {
            if(wpforupdate.getLong("wpitemid") != prlineid)
                continue;
            wpforupdate.setValue("pr", prline.getString("prnum"), 2L);
            wpforupdate.setValue("prlinenum", prline.getLong("prlinenum"), 2L);
            break;
        }

        logger.debug((new StringBuilder(String.valueOf(getName()))).append(" WO updated but not saved yet").toString());
    }

    private String genEmail(String error, String stack)
    {
        String emailMsg = (new StringBuilder("Date: ")).append(new Date()).append("\n").append("Error Message: ").append(error).append("\n").append(stack).toString();
        return emailMsg;
    }

    private String getStackTrace(Exception e)
    {
        String stack = "";
        StackTraceElement element[] = e.getStackTrace();
        for(int i = 0; i < element.length; i++)
            stack = (new StringBuilder(String.valueOf(stack))).append("\tat ").append(element[i].toString()).append("\n").toString();

        return stack;
    }

    private MboRemote getContractMbo(String contractnum)
        throws Exception
    {
        MboSetRemote contractset = mxserver.getMboSet("contract", userInfo);
        SqlFormat sqlformat = new SqlFormat("contractnum=:1 AND status='APPR'");
        sqlformat.setObject(1, "contract", "contractnum", contractnum);
        contractset.setWhere(sqlformat.format());
        return contractset.getMbo(0);
    }

    private MboRemote getSiteMbo(String siteid)
        throws Exception
    {
        MboSetRemote siteset = mxserver.getMboSet("site", userInfo);
        SqlFormat sqlformat = new SqlFormat("siteid=:1");
        sqlformat.setObject(1, "site", "siteid", siteid);
        siteset.setWhere(sqlformat.format());
        return siteset.getMbo(0);
    }

    protected static CrontaskParamInfo params[];
    private MxEmail email;
    private String emailSubj;
    private MXLogger logger;
    private MxLog mxLog;
    private String logFilePath;
    private String prdesc;
    private String prdescLong;
    private UserInfo userInfo;
    private MXServer mxserver;
    private ArrayList al;
    private static final long NOACCESSCHECK = 2L;

    static 
    {
        params = null;
        params = new CrontaskParamInfo[5];
        params[0] = new CrontaskParamInfo();
        params[0].setName("emailto");
        params[0].setDescription("CommonCron", "Adminemailaddress");
        params[1] = new CrontaskParamInfo();
        params[1].setName("alertemailsubj");
        params[1].setDescription("CommonCron", "EmailSubject");
        params[2] = new CrontaskParamInfo();
        params[2].setName("logfile");
        params[2].setDescription("CommonCron", "LogDirectory");
        
        params[3] = new CrontaskParamInfo();
		params[3].setName("validationenabled");
		params[3].setDescription("CommonCron","bavalid");
		
		params[4] = new CrontaskParamInfo();
		params[4].setName("wostatus");
		params[4].setDescription("CommonCron","wostatus");
    }
}
