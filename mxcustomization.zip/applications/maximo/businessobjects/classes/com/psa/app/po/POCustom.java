/*
 * Modified by BCT 
 * 
 * validating the PO comment while changing the PO status to CAN 
 * 
 * 
 */
package com.psa.app.po;

import com.psa.app.common.VendorCheckCustom;
import java.io.PrintStream;
import java.rmi.RemoteException;
import java.util.Date;
import psdi.app.po.PO;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.StatusHandler;
import psdi.mbo.Translate;
import psdi.server.AppService;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class POCustom extends PO
  implements POCustomRemote
{
  private boolean isalreadyld;

  public POCustom(MboSet mboset)
    throws MXException, RemoteException
  {
    super(mboset);

    this.isalreadyld = false;
  }

  public void add()
    throws MXException, RemoteException
  {
    super.add();
    String app = getThisMboSet().getApp();
    System.out.println("--app is--3" + app);
    if ((app == null) || 
      (!(app.equalsIgnoreCase("TRANSFER"))))
      return;
    setValue("internal", true);
    Date sysdate = ((AppService)getMboServer()).getMXServer().getDate();
    setValue("vendeliverydate", sysdate, 11L);
  }

  protected void setEditibilityFlags(boolean setflag)
    throws MXException, RemoteException
  {
    super.setEditibilityFlags(setflag);
    String[] fields = { "vendeliverydate" };
    setFieldFlag(fields, 7L, setflag);
  }
// PO Cancel comment validation
  public void changeStatus(String status, Date statusdate, String memo, long modifier)
    throws MXException, RemoteException
  {

	  String newStatus=status;
	  String poComment=getString("POCOMMENT");
	  if (newStatus.equalsIgnoreCase("CAN") && !newStatus.equalsIgnoreCase("") && this.getUserInfo().isInteractive()) {
	  	if (poComment.equalsIgnoreCase("")) {
	  		
	  		throw new MXApplicationException("PO","PoCancel");
	  	}
	  }

	  
    if (getTranslator().toInternalString(getStatusListName(), status, this).equals("APPR"))
      VendorCheckCustom.checkValidity(this, "VENDOR");
    super.changeStatus(status, statusdate, memo, modifier);
  }

  public void setLD(boolean bool)
  {
    this.isalreadyld = bool;
  }

  public boolean getLD() {
    return this.isalreadyld;
  }

  protected StatusHandler getStatusHandler()
  {
    return new POStatusHandlerCustom(this);
  }
}