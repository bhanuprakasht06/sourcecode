package com.psa.app.rfq;

import java.rmi.RemoteException;
import java.util.*;

import psdi.app.po.PORemote;
import psdi.app.rfq.QuotationLineRemote;
import psdi.app.rfq.RFQLineRemote;
import psdi.app.rfq.RFQVendorRemote;
import psdi.common.action.ActionCustomClass;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.mbo.*;
import psdi.security.ConnectionKey;

/**
 * @author		LS
 * @class		RFQCreatePOCustom
 * @date		Nov 30, 2006
 * @function	Generate PO from RFQ and Auto Approve PO
 */

public class RFQCreatePOCustom
implements ActionCustomClass
{

public RFQCreatePOCustom() 
{
}

public void applyCustomAction(MboRemote mboremote, Object aobj[])
throws MXException, RemoteException
{
	MboSetRemote rfqvendorset = mboremote.getMboSet("RFQVENDOR");
	MboSetRemote quotationlineset;
	QuotationLineRemote quotationline;
	int i = 0;
	int j = 0;
	boolean isawarded;
	
//	System.out.println("[RFQCreeatePOCustom]Start of Vendor FOR Loop");
	// Get all the vendor for the RFQ
	for (RFQVendorRemote rfqvendor; (rfqvendor = (RFQVendorRemote) rfqvendorset.getMbo(i)) != null; i++)
	{
//		System.out.println("[RFQCreeatePOCustom]RFQVENDOR: " + rfqvendor);
		quotationlineset = rfqvendor.getMboSet("QUOTATIONLINEVENDOR");
//		System.out.println("[RFQCreeatePOCustom]QUOTATIONLINESET: " + quotationlineset);
		isawarded = false;
		// Get all the quotation lines for each RFQ vendor
		for (j = 0; (quotationline = (QuotationLineRemote) quotationlineset.getMbo(j)) != null && !isawarded; j++)
		{
			isawarded = quotationline.getBoolean("isawarded");
//			System.out.println("[RFQCreeatePOCustom]ISAWARDED: " + isawarded);
			if (isawarded)
			{
				// Get Auto Number for PO
				String ponum = getPOAutoKey(mboremote);
//				System.out.println("[RFQCreeatePOCustom]PONUM: "+ponum);
				// Create PO for RFQline 
				rfqvendor.createPOFromRFQ(ponum, mboremote.getString("description"));
//				System.out.println("[RFQCreeatePOCustom]PONUM: " + ponum + " created");
			}
		}
	}
	try
	{
		closeRFQ(mboremote);
		rfqvendorset.save();
	}
	finally
	{
		rfqvendorset.close();
	}
	//Approval of PO created
//	System.out.println("[RFQCreatePOCustom]Start of PO APPR");
	autoApprPO(mboremote);
}

/**
 * @author		LS
 * @class		closeRFQ
 * @date		Mar 19, 2007
 * @function	Change Status of RFQ to CLOSE if not CLOSE
 */

private void closeRFQ(MboRemote mboremote)
throws MXException, RemoteException
{
	if(!mboremote.getString("status").equals("CLOSE"))
	{
//		System.out.println("[RFQCreatePOCustom]BSTATUS: " + mboremote.getString("status"));
		mboremote.setValue("STATUS", "CLOSE", 2L);
//		System.out.println("[RFQCreatePOCustom]ASTATUS: " + mboremote.getString("status"));
		mboremote.setValue("STATUSDATE", MXServer.getMXServer().getDate(), 2L);
//		System.out.println("[RFQCreatePOCustom]STATUSDATE: " + mboremote.getDate("statusdate"));
		mboremote.setValue("HISTORYFLAG", true, 2L);
//		System.out.println("[RFQCreatePOCustom]HISTORYFLAG: " + mboremote.getBoolean("historyflag"));
		
		MboSetRemote rfqstatusset = mboremote.getMboSet("RFQSTATUS");
		rfqstatusset.setFlag(1L, false);
		rfqstatusset.add(); 
	}
}

/**
 * @author		LS
 * @class		autoApprPO
 * @date		Nov 30, 2006
 * @function	Auto Approval of PO
 */

private void autoApprPO(MboRemote mboremote)
throws MXException, RemoteException
{
	MboSetRemote rfqlineset = mboremote.getMboSet("RFQLINE");
	int i = 0;
	String ponum;
//	System.out.println("[RFQCreeatePOCustom]Start of APPR FOR Loop");
	/* Get all the rfqlines for the RFQ */
	for (RFQLineRemote rfqline; (rfqline = (RFQLineRemote) rfqlineset.getMbo(i)) != null; i++)
	{
		/* Get the ponum from the rfqlines */
		ponum = rfqline.getString("ponum");
//		System.out.println("[RFQCreeatePOCustom]PONUM: "+ponum);
		if ((ponum != null) && (!ponum.equals("")))
		{
			/* Get the PO record from the PO table */
			MboSetRemote posetremote = MXServer.getMXServer().getMboSet("PO", mboremote.getUserInfo());
	        SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "ponum = :1 and siteid = :2");
		    sqlformat.setObject(1, "PO", "PONUM", ponum);
		    sqlformat.setObject(2, "PO", "SITEID", mboremote.getString("siteid"));
		    posetremote.setWhere(sqlformat.format());
		    PORemote poremote = (PORemote)posetremote.getMbo(0);
//		    System.out.println("[RFQCreeatePOCustom]POREMOTE: "+poremote);
	        
		    if(!poremote.getString("status").equals("APPR"))
		    {
		        /* Set the BILLTO field of the PO to 'PSA HQ' */
		    	poremote.setValue("billto", mboremote.getString("replyto"), 2L);
//		    	System.out.println("[RFQCreeatePOCustom]BILLTO: "+mboremote.getString("replyto"));
		    	/* Set the BILLTOATTN field of the PO to 'PSA HQ' */
		    	poremote.setValue("billtoattn", mboremote.getString("replytoattn"), 2L);
//		    	System.out.println("[RFQCreeatePOCustom]BILLTOATTN: "+mboremote.getString("replytoattn"));
		    	
		    	/* Set the VENDEVLVERYDATE field of the PO to the approval date + the max delivery time */
		    	MboSetRemote qlsetremote = MXServer.getMXServer().getMboSet("QUOTATIONLINE", mboremote.getUserInfo());
//		    	System.out.println("[RFQCreeatePOCustom]QLSETREMOTE: "+qlsetremote);
		    	SqlFormat sqlformat1 = new SqlFormat(mboremote.getUserInfo(), "rfqnum=:1 and vendor=:2 and isawarded=1");
//		        System.out.println("[RFQCreeatePOCustom]SQLFORMAT1: "+sqlformat1);
		        sqlformat1.setObject(1, "QUOTATIONLINE", "RFQNUM", mboremote.getString("rfqnum"));
//			    System.out.println("[RFQCreeatePOCustom]RFQNUM: "+mboremote.getString("rfqnum"));
			    sqlformat1.setObject(2, "QUOTATIONLINE", "VENDOR", poremote.getString("vendor"));
//			    System.out.println("[RFQCreeatePOCustom]VENDOR: "+poremote.getString("vendor"));
			    qlsetremote.setWhere(sqlformat1.format());
			    int k = 0;
		    	int maxdeliverytime=0;
		    	for(MboRemote qlremote; (qlremote = qlsetremote.getMbo(k)) != null; k++)
		    	{
//		    		System.out.println("[RFQCreeatePOCustom]QLREMOTE: "+qlremote);
		    		if(qlremote.getInt("deliverytime") > maxdeliverytime)
		    		{
		    			maxdeliverytime = qlremote.getInt("deliverytime");
		    		}
//		    		System.out.println("[RFQCreeatePOCustom]MAXDELIVERYTIME: "+maxdeliverytime);
		    	}
		    	qlsetremote.close();
		    	
		    	GregorianCalendar vendordate = new GregorianCalendar();
		    	vendordate.setGregorianChange(MXServer.getMXServer().getDate());
		    	vendordate.add(Calendar.DATE, maxdeliverytime);
		    	poremote.setValue("vendeliverydate", vendordate.getTime(), 2L);
//		    	System.out.println("[RFQCreeatePOCustom]VENDORDATE: "+vendordate);
		    	
		    	/* Change status of the PO to 'APPR' */
		    	poremote.changeStatus("APPR",MXServer.getMXServer().getDate(),"");
//		    	System.out.println("[RFQCreeatePOCustom]: Status change to 'APPR'");
//		    	System.out.println("[RFQCreatePOCustom]PONUM: " + ponum + " Status change to 'APPR'");
		    	/* Save the PO record */
		    	try
				{
		    		posetremote.save();
				}
				finally
				{
					posetremote.close();
				}
		    }
		}
	}
	rfqlineset.close();
}

/**
 * @author		LS
 * @class		getPOAutoKey
 * @date		Nov 30, 2006
 * @function	Generate Auto Number for PO
 */

private String getPOAutoKey(MboRemote mboremote)
throws MXException, RemoteException
{
		psdi.security.UserInfo userinfo = mboremote.getUserInfo();
//		System.out.println("[RFQCreeatePOCustom]USERINFO: "+userinfo);
		ConnectionKey connectionkey = null;
		connectionkey = new ConnectionKey(userinfo);
		AutoKey autokey;
	MboSetInfo mbosetinfo = MXServer.getMXServer().getMaximoDD().getMboSetInfo("PO");
//	System.out.println("[RFQCreeatePOCustom]MBOSETINFO: "+mbosetinfo);
	MboValueInfo mbovalueinfo = mbosetinfo.getMboValueInfo("ponum");
//	System.out.println("[RFQCreeatePOCustom]MBOVALUEINFO: "+mbovalueinfo);
	java.sql.Connection connection;
	String nextval=null;
	try
	{
		connection = MXServer.getMXServer().getDBManager().getConnection(connectionkey);
//		System.out.println("[RFQCreeatePOCustom]CONNECTION: "+connection);
		autokey = new AutoKey(connection, mbovalueinfo, userinfo, mboremote, mbosetinfo);
//		System.out.println("[RFQCreeatePOCustom]AUTOKEY: "+autokey);
		nextval = autokey.nextValue();
//		System.out.println("[RFQCreeatePOCustom]NEXTVAL: "+nextval);
	}
	finally {
		MXServer.getMXServer().getDBManager().freeConnection(connectionkey);
	}
	return nextval;
}
}


