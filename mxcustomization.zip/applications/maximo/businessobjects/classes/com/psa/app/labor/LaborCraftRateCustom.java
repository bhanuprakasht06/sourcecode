/**
 * @author	HCHA
 * Date		Jun 14, 2006
 * Comment	 
 */
package com.psa.app.labor;

import java.rmi.RemoteException;
import psdi.util.MXException;
import psdi.mbo.*;
import psdi.app.labor.*;


/**
 * @author		HCHA
 * @class		LaborCraftRateCustom
 * @date		Jun 14, 2006
 * @function	
 */
public class LaborCraftRateCustom extends LaborCraftRate 
implements LaborCraftRateRemote
{

/**
 * @param arg0
 * @throws MXException
 * @throws RemoteException
 */
public LaborCraftRateCustom(MboSet arg0) 
	throws MXException,RemoteException 
{
	super(arg0);
}

public void init()
	throws MXException
{
	super.init();

    setFieldFlag("controlaccount", 7L, false);
    
}
}
