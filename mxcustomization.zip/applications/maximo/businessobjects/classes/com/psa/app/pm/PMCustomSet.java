package com.psa.app.pm;

import java.rmi.RemoteException;

import psdi.app.pm.PMSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;

public class  PMCustomSet extends PMSet 
	implements PMCustomSetRemote 
{
	public PMCustomSet (MboServerInterface mboserverinterface) 
			throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}
	
	protected Mbo getMboInstance(MboSet mboset) 
			throws MXException, RemoteException
	{
		return (new PMCustom(mboset));
	}
}
