
package com.psa.app.packaging;

import java.rmi.RemoteException;
import psdi.mbo.*;
import psdi.util.MXException;
import psdi.util.MXApplicationException;

public class PackageLinesSet extends MboSet
    implements PackageLinesSetRemote
{

    public PackageLinesSet(MboServerInterface ms)
        throws MXException, RemoteException
    {
        super(ms);
        super.canAdd();
        System.out.println("--Inside Pack Lines Set Main Add--");         
    }

    protected Mbo getMboInstance(MboSet ms)
        throws MXException, RemoteException
    {
        return new PackageLines(ms);
    }

	public void canAdd()
		throws MXException
    	{
	    super.canAdd();
	    try
	    {
	    	System.out.println("--Inside Pack Lines Set canadd--");
	        /*MboRemote packageRemote = getOwner(); 	    	
	        String packageStatus = packageRemote.getString("STATUS");	       
	        if(packageStatus.equalsIgnoreCase("CAN") || packageStatus.equalsIgnoreCase("ISSUED") || packageStatus.equalsIgnoreCase("TRANSFER"))
	        	throw new MXApplicationException("jspmessages", "table_cannotadd");	       
	        super.save();*/
	        
	    }
	    
	    //catch(RemoteException t)
	    catch(Exception t)
	    {
	        t.printStackTrace();
	    }
	}
	
	public void copyInvReserveSet(MboSetRemote invReserveSet)
		throws MXException, RemoteException
	{
		MboRemote invRes = null;
		int index = 0;
		System.out.println("--Inside Pack Lines Set copyInvReserveSet--");
		while ((invRes = invReserveSet.getMbo(index)) != null)
		{
			++index;
			if (!(invRes.isSelected()))
			{
				continue;
			}

			double qtyForIssue = invRes.getDouble("RESERVEDQTY");
			MboRemote newMatUse = addMatUseFromInvReserve(invRes);			
		}
		System.out.println("--Inside Pack Lines Set copyInvReserveSet After--");
	}

	public MboRemote addMatUseFromInvReserve(MboRemote invRes)
		throws MXException, RemoteException
	{
		MboRemote newMatUse = add();
		System.out.println("--Inside Pack Lines Set addMatUseFromInvReserve--"+newMatUse);
		try
		{
			newMatUse.setValue("itemnum", invRes.getString("itemnum"), 2L);
			newMatUse.setValue("conditioncode", invRes.getString("conditioncode"), 2L);
			newMatUse.setValue("siteid", invRes.getString("STORELOCSITEID"), 2L);	
			newMatUse.setValue("QTY", invRes.getString("RESERVEDQTY"), 2L);		
			System.out.println("--Inside Pack Lines Set addMatUseFromInvReserve try--");
		}
		catch (MXException m)
		{
			newMatUse.delete();
			newMatUse.getThisMboSet().remove();
			throw m;
		}
		catch (RemoteException r)
		{
			newMatUse.delete();
			newMatUse.getThisMboSet().remove();
			throw r;
		}
		return newMatUse;
	}
}