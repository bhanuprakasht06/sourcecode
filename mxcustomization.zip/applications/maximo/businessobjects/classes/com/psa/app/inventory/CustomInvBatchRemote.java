package com.psa.app.inventory;

import psdi.mbo.MboRemote;

public interface CustomInvBatchRemote extends MboRemote 
{
}
