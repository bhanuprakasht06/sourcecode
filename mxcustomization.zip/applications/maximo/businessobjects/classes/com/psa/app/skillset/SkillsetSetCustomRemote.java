package com.psa.app.skillset;

import psdi.mbo.MboSetRemote;

public interface SkillsetSetCustomRemote extends MboSetRemote 
{
		
}
