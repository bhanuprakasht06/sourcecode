/*
 * Modification history
 * 19-03-2007	LS		eRFQ	Creation
 * 29-01-2009	HMD		DR 67	Get the RFQ Remote by matching with an instance of RFQRemote	
 * 28-03-2013	WMJ		EMS-560	[RFQ]Add a No Award option for RFQ lines with a Reason field for users if they do not wish to award the items	
 */

package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.rfq.RFQRemote;
import psdi.app.rfq.RFQVendorRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.app.rfq.FldQuotationLineIsAwarded;
import psdi.util.MXException;

//Start of EMS-560
import psdi.mbo.MboValueAdapter;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
//End of EMS-560


/**
 * @author		LS
 * @class		FldQuotationLineIsAwardedCustom
 * @date		Mar 19, 2007
 * @function	Update the Total Awarded Amount for RFQ vendor
 */

public class FldQuotationLineIsAwardedCustom extends FldQuotationLineIsAwarded
{
	public FldQuotationLineIsAwardedCustom(MboValue mbv) 
		throws MXException,	RemoteException 
	{
		super(mbv);
	}

	public void action() throws MXException, RemoteException
    {
        super.action();
        Mbo mbo = getMboValue().getMbo();
        
        /*//Start of EMS-560
        if (getMboValue().getBoolean())
    	{
	        MboSetRemote rfqLineSetRemote = getMboValue().getMbo().getMboSet("RFQLINE");
	        if (rfqLineSetRemote.getMbo(0).getBoolean("NOAWARD"))
	    	{
	      		throw new MXApplicationException("rfq", "rfqLineNoAward");
	    	}
    	}
        //End of EMS-560
         */        
        //Start -- Converted to Automation Script in Maximo 7.6
        /*String vendor = mbo.getString("VENDOR");
        //Get RFQVendor Mbo
        MboRemote rfqvendorremote = null;
        
        if(mbo.getOwner() instanceof RFQVendorRemote)
        	rfqvendorremote = mbo.getOwner();
        else
        {
        	//Begin Modification DR 67
        	//MboRemote rfqremote = mbo.getOwner().getOwner();
        	
        	MboRemote rfqremote = null;
        	if( (mbo.getOwner()) instanceof RFQRemote)
        		rfqremote = mbo.getOwner();
        	else if ( (mbo.getOwner().getOwner()) instanceof RFQRemote)
        		rfqremote = mbo.getOwner().getOwner();
        	//End Modification DR 67
        	
//        	System.out.println("RFQ  Remote : " + rfqremote.getName());
        	MboSetRemote rfqvendorsetremote = rfqremote.getMboSet("RFQVENDOR");
        	int i = 0;
        	for(rfqvendorremote = rfqvendorsetremote.getMbo(i);!rfqvendorremote.getString("VENDOR").equals(vendor) && rfqvendorremote != null; i++ )
        	{
        		rfqvendorremote = rfqvendorsetremote.getMbo(i);
        	}
        }
        
        //System.out.println("[FldQuotationLineIsAwardedCustom]quotationlineremote: " + rfqvendorremote.getName());
        if(rfqvendorremote == null)
            return;
        
        double totalaward = 0.0D;
        
        totalaward = rfqvendorremote.getDouble("totalawardamt");
        //System.out.println("[FldQuotationLineIsAwardedCustom]totalaward: " + totalaward);

        if(getMboValue().getBoolean())
        {
        	//Add line cost to total awarded
        	totalaward = totalaward + mbo.getDouble("linecost");
//        	System.out.println("[FldQuotationLineIsAwardedCustom]linecost: " + mbo.getDouble("linecost"));
        	rfqvendorremote.setValue("totalawardamt", totalaward);
        	//System.out.println("[FldQuotationLineIsAwardedCustom]set totalawardamt: " + totalaward);
        }
        else
        {
        	//Subtract line cost from total awarded
        	totalaward = totalaward - mbo.getDouble("linecost");
//        	System.out.println("[FldQuotationLineIsAwardedCustom]linecost: " + mbo.getDouble("linecost"));
        	rfqvendorremote.setValue("totalawardamt", totalaward);
        	//System.out.println("[FldQuotationLineIsAwardedCustom]set totalawardamt: " + totalaward);
        }*/
        //End -- Converted to Automation Script in Maximo 7.6
        //System.out.println("Leaving FldQuotationLineIsAwardedCustom");
    }
}
