/*
 * Modification history
 * 05-10-2007	AGD	SR-117	Populate store based on user default store
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.FldWpMatLocation;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldWpMatLocationCustom extends FldWpMatLocation
{

	public FldWpMatLocationCustom(MboValue locationvalue)
			throws MXException
	{
		super(locationvalue);
	}


	public void validate()
			throws MXException, RemoteException
	{
		super.validate();

		MboValue locationvalue = getMboValue();
		((WPMaterialCustom) locationvalue.getMbo()).checkQty(locationvalue);
	}

	// Begin Modification for CR by GPTM 
	
	public void action() throws MXException, RemoteException
	{
		Mbo mbo=getMboValue().getMbo();
		
		String store= getMboValue().getString();
		
		boolean consign = store.endsWith("CONSIGN");
		String itemnum=mbo.getString("itemnum");
		double itemqty=mbo.getDouble("itemqty");
		
		if(consign && itemnum != null)
		{
			int i = store.indexOf("CONSIGN");
			String main_store=store.substring(0, i)+ "STORE";
			MboSetRemote mboset=getMboValue().getMbo().getThisMboSet();
			double wo_qty=0D;
			
			if(!mboset.isEmpty())
			{
				MboRemote mboremote;
				for(int j=0;(mboremote=mboset.getMbo(j))!=null;j++)
				{
					if(mboremote.getString("location").equalsIgnoreCase(main_store) && 
							mboremote.getString("itemnum").equalsIgnoreCase(itemnum))
					{
					wo_qty=wo_qty+mboset.getMbo(j).getDouble("itemqty");
					}
				}
			}
			
			 SqlFormat sqlformat = new SqlFormat(mbo.getUserInfo(), "location = :1 and itemnum=:2");
	            sqlformat.setObject(1, "wpmaterial", "location", main_store);
	            sqlformat.setObject(2, "wpmaterial", "itemnum", itemnum);
	            MboSetRemote mbosetremote = mbo.getMboSet("$invcurbal", "invbalances", sqlformat.format());
	    
	            if(!mbosetremote.isEmpty())
	            {
	            	double presentqty=0D;
	            	for(int k=0;k<=(mbosetremote.count()-1);k++)
	            	{
	            		presentqty=presentqty+mbosetremote.getMbo(k).getDouble("curbal");
	            	}
	            	
	            	 
	            	 if(itemqty <= (presentqty-wo_qty) || (((itemqty > 0) && ((presentqty-wo_qty)>0)) && (itemqty >(presentqty-wo_qty))))
	            	{
	            		Object params[] = { main_store, Double.toString(presentqty),itemnum };
	            		throw new MXApplicationException("custom", "consignmentstock",params);
	            	}
	            	 
	            }
		}
		
		
		super.action();
	}
// End Modification for CR by GPTM
}

