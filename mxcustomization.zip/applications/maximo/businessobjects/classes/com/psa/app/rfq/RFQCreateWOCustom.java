/*
 * Modiifcation History
 * 24-04-08	HAM		Retrieving the attachments details from the related WO into RFQ
 * 
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class RFQCreateWOCustom 
implements ActionCustomClass
{
public RFQCreateWOCustom() 
{
}

public void applyCustomAction(MboRemote mboremote, Object aobj[])
	throws MXException, RemoteException
{
	//mboremote is pointing processing RFQ details.
	try
	{
		// Get all the WO 
		MboSetRemote woset = MXServer.getMXServer().getMboSet("WORKORDER", mboremote.getUserInfo());
		// MboSetRemote woset = mboremote.getMboSet("WORKORDER"); //This statment is also correct
		// Add a new WO 
		MboRemote wo=woset.add();
		
		System.out.println("WO Num : "+wo.getString("WONUM")+" has been created");
		woset.save(); //Saving new WO to make them availbale from DB for the following calling method
		
		// Get the woset which contains only this new WO details
		SqlFormat sqlformat = new SqlFormat(mboremote.getUserInfo(), "wonum = :1 and siteid = :2");
		sqlformat.setObject(1, "WORKORDER", "WONUM", wo.getString("WONUM"));
		sqlformat.setObject(2, "WORKORDER", "SITEID",wo.getString("SITEID"));
		woset.setWhere(sqlformat.format());
	
		// Copy this eRFQ awarded quotation details into current WO'sPlan 
		((RFQCustomRemote)mboremote).copyeRFQtoNewWO(woset);
	//	woset.save();
		woset.close();
		
		//Display the new WO Num in the Appn screen
		Object param[] = {wo.getString("WONUM") }; 				
		//MXServer.getMXServer().addWarning(new MXApplicationException("rfq", "newwonum"), param);
		MboSet temp = (MboSet)woset;
		temp.addWarning(new MXApplicationException("rfq", "newwonum", param));
	}
	catch (MXException e) 
	{
		e.printStackTrace();
		throw e;
	}
}


}
