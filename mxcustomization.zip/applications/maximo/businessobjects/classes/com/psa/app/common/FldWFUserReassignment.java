/*
 * Created by BCT 
 * 
 * making set read only false to the new created attribute
 * 
 * 
 */
package com.psa.app.common;

import java.rmi.RemoteException;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

public class FldWFUserReassignment extends MboValueAdapter {

	public FldWFUserReassignment(MboValue mbv) {
		super(mbv);
	
	}
		
	public void initValue() throws MXException, RemoteException {
		getMboValue("WFREASSIGN").setReadOnly(false);
		super.initValue();
	}

}
