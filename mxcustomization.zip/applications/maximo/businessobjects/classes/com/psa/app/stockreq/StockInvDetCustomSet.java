/*
 * Modification history
 * 27-05-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.*;
import psdi.mbo.*;
import psdi.util.*;
import psdi.mbo.custapp.*;

public class  StockInvDetCustomSet extends CustomMboSet 
	implements StockInvDetCustomSetRemote 
{
	public StockInvDetCustomSet (MboServerInterface mboserverinterface) 
		throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}

	protected Mbo getMboInstance(MboSet mboset) 
		throws MXException, RemoteException
	{
		return (new StockInvDetCustom(mboset));
	}
	
	public void canAdd()
    throws MXException
    {
	    super.canAdd();
	    try
	    {
	        MboRemote stockItemRemote = getOwner();  	        
	        String stockIteStatus = stockItemRemote.getString("STATUS");
	        if(stockIteStatus.equalsIgnoreCase("DRAFT") || stockIteStatus.equalsIgnoreCase("WCFM") || stockIteStatus.equalsIgnoreCase("WAPPR") || stockIteStatus.equalsIgnoreCase("WIMSCFM"))
	        	throw new MXApplicationException("jspmessages", "table_cannotadd");
	        
	        ((StockReqCustomRemote)stockItemRemote).canAddIMS();
	    }
	    catch(RemoteException t)
	    {
	        t.printStackTrace();
	    }
	}
}
