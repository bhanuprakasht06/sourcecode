/**
 * @author	HCHA
 * Date		Jun 20, 2006
 * Comment	 
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.mbo.*;
import psdi.util.MXException;
import psdi.app.workorder.*;

/**
 * @author		HCHA
 * @class		WOCustomSet
 * @date		Jun 20, 2006
 * @function	
 */
public class WOCustomSet extends WOSet 
	implements WOSetRemote, MboSetListenable
{

	/**
	 * @param arg0
	 * @throws MXException
	 * @throws RemoteException
	 */
	public WOCustomSet(MboServerInterface arg0) 
		throws MXException, RemoteException 
	{
		super(arg0);
	}
	
    protected Mbo getMboInstance(MboSet mboset)
	    throws MXException, RemoteException
	{
	    return new WOCustom(mboset);
	}

}
