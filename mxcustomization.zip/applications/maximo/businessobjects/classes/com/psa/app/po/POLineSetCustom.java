/*
 * Created by BCT 
 * 
 * Force Receipt complete validation,
 * PO comment is mandatory to enter.
 * 
 * 
 */

package com.psa.app.po;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

import psdi.app.po.POLineRemote;
import psdi.app.po.POLineSet;
import psdi.app.po.PORemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class POLineSetCustom extends POLineSet {

	public POLineSetCustom(MboServerInterface ms) throws MXException,
			RemoteException {
		super(ms);
	
	}
// force Complete validation
	public void completeReceipts() throws MXException, RemoteException {
		
		int oldReceiptComp=0;
		boolean receiptsComplete=false;
		int totalCount=0;
		int currentCount=0;
		
		System.out.println();
		
		 Date currentDate = MXServer.getMXServer().getDate();
		PORemote  poRemote = (PORemote) getMbo(0).getOwner();
		
		MboSetRemote lineSetRemote=poRemote.getMboSet("POLINE");
		
		if(!lineSetRemote.isEmpty() &lineSetRemote.count()>0)
		{
		for (int i = 0;i<=lineSetRemote.count()-1; i++) {
			
			 MboRemote poLineRemote = lineSetRemote.getMbo(i);
		     
		      receiptsComplete=poLineRemote.getBoolean("RECEIPTSCOMPLETE");
		      if(receiptsComplete==true)
		      {
		    	oldReceiptComp++;
		      }
		      totalCount++;

		}
		}
		
		 for (int i = 0; ; ++i)
		    {
		      MboRemote poLineRemote = getMbo(i);
		      if (poLineRemote == null)
		        break;
		      if (poLineRemote.isSelected())
		      {
		    	  currentCount++;
		      }
		    }
		int total= oldReceiptComp + currentCount;
		if(totalCount==total)
		{
			String poComment=poRemote.getString("POCOMMENT");
			if(poComment.equalsIgnoreCase(""))
			{
				throw new MXApplicationException("PO","CompleteReceipts");
			}
			else
			{
				 for (int i = 0; ; ++i)
				    {
				      MboRemote poLineRemote = getMbo(i);
				      if (poLineRemote == null)
				        break;
				      if (poLineRemote.isSelected())
				      {
				    	  	poLineRemote.getString("POLINENUM");
							 poLineRemote.setValue("FORCECOMPLETE",currentDate,MboConstants.NOACCESSCHECK);
				      }
				    } 
						
				
			}
		}
		else {
			 for (int i = 0; ; ++i)
			    {
			      MboRemote poLineRemote = getMbo(i);
			      if (poLineRemote == null)
			        break;
			      if (poLineRemote.isSelected())
			      {
			    	  	poLineRemote.getString("POLINENUM");
						 poLineRemote.setValue("FORCECOMPLETE",currentDate,MboConstants.NOACCESSCHECK);
			      }
			    } 
		}
		super.completeReceipts();
	}

	
	protected Mbo getMboInstance(MboSet ms) throws MXException, RemoteException {
		
		return  new POLineCustom(ms);
	}

}
