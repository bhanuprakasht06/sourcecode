package com.psa.app.psa_edp;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.psa.custom.common.MxEmail;

import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class PSA_EDPCronTask extends SimpleCronTask

{
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	private String adminEmailId;
    private MxEmail email;
    private static final String SUBJECT = "[EMS-EDP] Error: Error occured in EDP Cron.";
	public PSA_EDPCronTask() {

	}
	
	/*
	  * 
	  * 06-11-2020 - added the below to fix issue that popped when user tries changing the parameter values from Application.
	  * 12-07-2022 Added Batch Number concept to run particular batch objects
	  * <START>
	  * 
	  */
	
	 private static CrontaskParamInfo params[];
	 
	 static {
             
             params = null;
             params = new CrontaskParamInfo[5];
             
            params[0] = new CrontaskParamInfo();
     		params[0].setName("Destination_Path");
     		params[0].setDefault("");
     		
     		params[1] = new CrontaskParamInfo();
     		params[1].setName("Script_excution_Path");
     		params[1].setDefault("");
     		
     		params[2] = new CrontaskParamInfo();
     		params[2].setName("ALERTEMAIL");
     		params[2].setDefault("krishnaprabu.k@bahwancybertek.com");
     		
     		params[3] = new CrontaskParamInfo();
     		params[3].setName("BATCHNUM");
     		params[3].setDefault("BATCH1");
     		
     		params[4] = new CrontaskParamInfo();
     		params[4].setName("FILETYPE");
     		params[4].setDefault("dsv");
   
     }
	 public CrontaskParamInfo[] getParameters() throws MXException, RemoteException 
	 {
		return params;
	 }

	 /*
	  * 
	  * 06-11-2020 - added the below to fix issue that popped when user tries changing the parameter values from Application.
	  * 12-07-2022 Added Batch Number concept to run particular batch objects
	  * <END>
	  * 
	  */
	 
	public void cronAction() {
		integrationLogger.debug("*******************CRON EDP CODE STARTED**************************");
		MboSetRemote psaedpset;
		MboRemote psaedp;
		
		SimpleDateFormat formatter = null;
		try {
			String batchNum = getParamAsString("BATCHNUM");
			if(getParamAsString("Script_excution_Path")!=null && !getParamAsString("Script_excution_Path").equals("")){
			psaedpset = MXServer.getMXServer().getMboSet("PSA_EDP", getRunasUserInfo());
			//psaedpset.setWhere("STATUS='ACTIVE' AND QUERY IS NOT NULL AND TABLENAME IS NOT NULL AND HEADER IS NOT NULL AND FILENAME IS NOT NULL");
			//psaedpset.setWhere("STATUS='ACTIVE' AND QUERY IS NOT NULL AND TABLENAME IS NOT NULL AND HEADER IS NOT NULL AND FILENAME IS NOT NULL AND BATCHNUM ='"+batchNum+"'");
			psaedpset.setWhere("STATUS='ACTIVE' AND QUERY IS NOT NULL AND TABLENAME IS NOT NULL AND FILENAME IS NOT NULL AND BATCHNUM ='"+batchNum+"'");
			integrationLogger.debug("psaedpset count is"+psaedpset.count());
			psaedpset.reset();
			adminEmailId=getParamAsString("ALERTEMAIL");
			email.setAdmin(adminEmailId);
			
			for (int k = 0; (psaedp =  (MboRemote) psaedpset.getMbo(k)) != null; k++) {
				//String OUTPUT_GZIP_FILE = "";
				//String SOURCE_FILE = "";
				String path = "";
				String FileName = "";
				String FileName1 = "";
				String query = "";
				String header = "";
				String gilePath = "";
				String fpath[]= null;
				String dateFormat = "";
				Process p= Runtime.getRuntime().exec("ps -ef");
				try {
					
					gilePath = psaedp.getString("FILENAME");
					
					String fileType = getParamAsString("FILETYPE");
					System.out.println("Filetype--> "+fileType);
					
					if(gilePath!=null && !gilePath.equals("") && gilePath.toLowerCase().contains("yyyy")){
						fpath= gilePath.split("_");
						if(fpath!=null && !fpath.equals("")){
							dateFormat = fpath[fpath.length-1];
						}
						
						if (dateFormat == null || dateFormat == "") {
							formatter = new SimpleDateFormat("yyyyMMddhh");
						} else {
							formatter = new SimpleDateFormat(dateFormat);
						}
						Date date = new Date();
						
						String dateVal = formatter.format(date);
						
						gilePath = gilePath.replaceAll(dateFormat, dateVal);
					}
				
					
					integrationLogger.debug("gilePath ::>>>" + gilePath);
					
					
					path=getParamAsString("Script_excution_Path")+"move.sh";
					FileName = gilePath+"_1."+fileType;
					FileName1 = gilePath+"."+fileType;
					integrationLogger.debug("filename is "+FileName);
					integrationLogger.debug("FileName1 is "+FileName1);
					List<String> cmdList = new ArrayList<String>();
					query = psaedp.getString("QUERY");
					
					
					
					String fQuery = "";
					String fQuery1 = "";
					String fQuery2 = "";
					String first1900Val = "";
					String after1900Val = "";
					String after1900before3800Val = "";
					String after3800Val = "";
					String[] after1900SplitVal = null;
					String after1900FSplitVal = "";
					String[] after3800SplitVal = null;
					String after3800FSplitVal = "";
					String after1900FSplitValcomman;
					if(query!=null && query.length() >2000){
						 first1900Val = query.substring(0, 1900);
						 after1900Val = query.substring(1900, query.length());
						if(after1900Val!=null && !after1900Val.equals("") && first1900Val!=null && !first1900Val.equals("")){
							after1900SplitVal = after1900Val.split(",");
							if(after1900SplitVal!=null && !after1900SplitVal.equals("")){
							  after1900FSplitVal = after1900SplitVal[0];
							  fQuery = first1900Val+after1900FSplitVal;
							  if(after1900Val!=null && after1900Val.length()>2000){
								  
								  after1900before3800Val = after1900Val.substring(0, 1900);
								  after3800Val = after1900Val.substring(1900, after1900Val.length());
								  
								  if(after1900before3800Val!=null && !after1900before3800Val.equals("") && after3800Val!=null && !after3800Val.equals("")){
									  after3800SplitVal = after3800Val.split(",");
									  if(after3800SplitVal!=null && !after3800SplitVal.equals("")){
										  after3800FSplitVal = after3800SplitVal[0];
										  //Added the below logic to include RRM integration -Code start here 
										  if(after1900before3800Val.startsWith(","))
										  {
											  after1900FSplitValcomman = after1900before3800Val.replaceFirst(",", "");
											  fQuery1 = after1900FSplitValcomman + after3800FSplitVal;
											  
										  }
										  else
										  {
											  fQuery1 = after1900before3800Val + after3800FSplitVal;
										  }
										  
										  //Added the below logic to include RRM integration -Code ends here 
										 // fQuery1 = after1900before3800Val + after3800FSplitVal;
										  fQuery2 = after3800Val.substring(after3800FSplitVal.length(),after3800Val.length());
										 }
								  }
								  
							  }else{
								  fQuery1 = after1900Val.substring(after1900FSplitVal.length(),after1900Val.length());
							  }
							  
							}
						}
						
						integrationLogger.debug("final fQuery1 ::>>>" + fQuery);
						
						integrationLogger.debug("final fQuery2 ::>>>" + fQuery1);
						
						integrationLogger.debug("final fQuery3 ::>>>" + fQuery2);
					}else{
						fQuery = query;
					}
					
					
					
					header = psaedp.getString("HEADER");
					cmdList.add("sh");
					//cmdList.add(getCronValue("Destination Path")+"move.sh");
					
					integrationLogger.debug("desit"+path);
					cmdList.add(path);
					cmdList.add(FileName1);
					cmdList.add(fQuery);
					cmdList.add(FileName);
					if(header != null && !header.trim().isEmpty()) {
						cmdList.add(header);
					}
					
					cmdList.add(fQuery1);
					cmdList.add(fQuery2);
					cmdList.add(getParamAsString("Destination_Path"));
					
					//move.sh FileName1 (1)				fQuery 	(2)				FileName (3)				header(4)		fQuery1(5) fQuery2(6) 	DestinationPath (7)
					//move.sh COMPANIES_yyyyMMddhh.dsv companiesQueryValue COMPANIES_yyyyMMddhh_1.dsv 	companiesHeader 	""		 	""			/opt/psa/data/rw/emsscp/outgoing/edp
					
					integrationLogger.debug("********before start btach script***");
					//ProcessBuilder pb = new ProcessBuilder(cmdList);
					ProcessBuilder pb = new ProcessBuilder(cmdList);
					
					try
					{
					p = pb.start();
					integrationLogger.debug("*******After batch script*******");
					p.waitFor();
					integrationLogger.debug("*******After wait batch script*******");
					}
					catch (Exception e) {
						throw e;
					}
					
					integrationLogger.debug("*****************SUCCESFULLY EXECUTED BATCH SCRIPT**********************");
					BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
					String line;

					while ((line = reader.readLine()) != null) {
						integrationLogger.debug(line);
					}
					reader.close();

					integrationLogger.debug("*******************CODE TO READ CSV FILE*********************************");
					
					
				}catch (Exception e) {
					// TODO Auto-generated catch block
					integrationLogger.debug("*********************inside catch%%%***************************");
					e.printStackTrace();
					
					//email.send(SUBJECT+" For Table : "+psaedp.getString("TABLENAME"),e.getMessage());
					
					String emailContent = genEmail(e);
		            email.send(SUBJECT+" For Table : "+gilePath,emailContent );
				}

				integrationLogger.debug("*********************completed***************************");

			}
			
		}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private String genEmail(Exception e){
        System.out.println("--start of genEmail()--");

        //Form Email Message
        String emailMsg = "Date: " + new Date()+"\n";
        emailMsg += "Error in CronTask: "+getName()+ "\n";
        emailMsg+="Error Message: "+ e.getMessage()+"\n";
        emailMsg+="Detail:\n";
        emailMsg+=e.toString()+"\n";
        StackTraceElement element[] = e.getStackTrace();
        for(int i=0; i< element.length; i++){
                emailMsg+="\tat "+ element[i].toString()+"\n";
        }
        System.out.println("--end of genEmail()--");

        return emailMsg;
        }
	
	public void init() {
        email = new MxEmail(adminEmailId);
     

    }
}
