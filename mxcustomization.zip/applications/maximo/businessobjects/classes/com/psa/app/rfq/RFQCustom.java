/*
 * Modification history
 * 08-11-2012	WMJ	EMS-526	[RFQ]System check to ensure that the RFQ CLOSEONDATE is the current date or in the future 
 * 04-04-2013	WMJ	EMS-558	[RFQ]Allow users to self help to extend RFQ closing Date process in Maximo  
 * 04-04-2013	WMJ	EMS-572	[RFQ]Allow EQRD to change buyer themselves  
 * 26-12-2014   BCT REQ-4.3.1[RFQ ]allow access on field wfreassign while RFQ status in FINISHED 
 */

package com.psa.app.rfq;

import java.rmi.*;
import psdi.mbo.*;
import psdi.util.*;
import psdi.app.rfq.*;
import psdi.app.workorder.WPMaterialSetRemote;
import psdi.app.workorder.WPServiceSetRemote;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValueInfo;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import java.util.Iterator;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class RFQCustom extends RFQ
implements RFQCustomRemote
{
public RFQCustom(MboSet mboset)
        throws MXException, RemoteException
{
super(mboset);
}

        public void add() throws MXException, RemoteException
        {
                super.add();
        }

        public void save() throws MXException, RemoteException
        {
	        //EMS-526
			String status=getString("STATUS");
		
			if((status.equalsIgnoreCase("INPRG")) || (status.equalsIgnoreCase("REOPEN")))
			{
				if(!isNull("CLOSEONDATE"))//WMJ: allow NULL value for the field CLOSEONDATE as CLOSEONDATE will be set to NULL for reopened RFQs.
				{
					Calendar cal = Calendar.getInstance();//get current date time
					
					//clear off the time component from cal
					cal.set(Calendar.HOUR_OF_DAY, 0);
					cal.set(Calendar.MINUTE, 0);
					cal.set(Calendar.SECOND, 0);
					cal.set(Calendar.MILLISECOND, 0);
					
					Date curDate = cal.getTime();//get Date object from cal
							
					if((curDate.compareTo(getDate("CLOSEONDATE")))>0)//WMJ: returns a value greater than zero if curDate is before Close Date, 0 if both dates are the same
				    throw new MXApplicationException("rfq", "closeOnDateBeforeCurrentDate");
				}
			}
	        //end EMS-526
	        
                super.save();
        }


        /*
         * Add vendor to the eRFQ
         */
        public void joinVendor() throws MXException, RemoteException {
                // TODO Auto-generated method stub
                String vendor = getVendorFromUser(getUserName());
                addVendor(vendor);
        }

        /*
         * Get the vendor from the user
         */
        private String getVendorFromUser(String user)
                        throws MXException, RemoteException
        {
//              System.out.println("[RFQCustom] getVendorFromUser: User: " + user);

                MboSetRemote comploginerfqset = MXServer.getMXServer().getMboSet("COMPLOGINERFQ", getUserInfo());
                SqlFormat sqlformat = new SqlFormat("userid = :1");
                sqlformat.setObject(1, "comploginerfq", "userid", user);
                comploginerfqset.setWhere(sqlformat.format());

                String vendor = null;
                if (!comploginerfqset.isEmpty())
                {
                        vendor = comploginerfqset.getMbo(0).getString("company");
                }

//              System.out.println("[RFQCustom] getVendorFromUser: vendor: " + vendor);

                if (vendor == null)
                {
                        Object param[] = {
                        user
                    };
                        throw new MXApplicationException("rfq", "usernotsetup", param);
                }

                return vendor;
        }

        /*
         * Add a vendor to the RFQ given a vendor code. Nothing is done if the vendor is already in
         */
        private void addVendor(String vendor)
                        throws MXException, RemoteException
        {
                // Verify whether the vendor is already in. If so, nothing else to do
                MboSetRemote rfqvendorset = getMboSet("ERFQVENDOR");
                if (!rfqvendorset.isEmpty())
                        return;

                MboRemote rfqvendor = rfqvendorset.add(MboConstantsCustom.NOACCESSCHECK);
                rfqvendor.setValue("vendor", vendor,  MboConstantsCustom.NOACCESSCHECK);
                rfqvendorset.save();
                rfqvendorset.close();
        }


        /*
         * Get the list of WO where we can copy this RFQ to
         */
        public MboSetRemote getWOForRFQ()
                        throws MXException, RemoteException
        {
                MboSetRemote woset = MXServer.getMXServer().getMboSet("WORKORDER", getUserInfo());
                String wostatuswappr = getTranslator().toExternalList("WOSTATUS", new String[] { "WAPPR", "WSCH" } );
                SqlFormat sql = new SqlFormat("status IN (" + wostatuswappr + ") AND siteid=:1 AND istask=0");
                sql.setObject(1, "workorder", "siteid", getString("siteid"));
                woset.setWhere(sql.format());
                woset.setOrderBy("wonum");
                woset.reset();
                return woset;
        }

        /*
         * Copy eRFQ awarded lines to the WO selected, with price from awarded line
         */
        public void copyeRFQtoWO(MboSetRemote woset)
                        throws MXException, RemoteException
        {
                // Get all the awarded quotations first
                MboSetRemote quotematset = getMboSet("AWARDEDMAT");
                MboSetRemote quoteservset = getMboSet("AWARDEDSERV");

                // Copy the eRFQ to all the WO selected
                woset.resetWithSelection();
                int i = 0;
                //System.out.println(MXServer.getMXServer().getDate() + " copyeRFQtoWO - woset.count="+woset.count());

                for (MboRemote wo = null; (wo = woset.getMbo(i)) != null; i ++)
                {
                        //System.out.println(MXServer.getMXServer().getDate() + " copyeRFQtoWO - i="+i+", wo="+wo.getString("wonum")+", selected="+wo.isSelected());
                        // Create material first
                        WPMaterialSetRemote wpmatset = (WPMaterialSetRemote) wo.getMboSet("WPMATERIAL");
                        if (!quotematset.isEmpty())
                        {
                                copyQuotesToWPMat(wpmatset, quotematset);
//                              wpmatset.save();
                        }
//                      wpmatset.close();

                        // Create service second
                        WPServiceSetRemote wpservset = (WPServiceSetRemote) wo.getMboSet("WPSERVICE");
                        if (!quoteservset.isEmpty())
                        {
                                copyQuotesToWPServ(wpservset, quoteservset);
//                              wpservset.save();
                        }
//                      wpservset.close();
                        //System.out.println(MXServer.getMXServer().getDate() + " copyeRFQtoWO - Loop over and woset.count="+woset.count());
                }
                woset.save();
        }

// Copy all awarded material quotes from top of the array to bottom to the WP.


        private void copyQuotesToWPMat(MboSetRemote wpset, MboSetRemote quotes)
                        throws MXException, RemoteException
        {
                int sizeofquotes=quotes.count();
                MboRemote quote = null;
                for (int j = sizeofquotes; j > 0; j --)
                {
                        quote = quotes.getMbo(j-1);
                        addToWPMat(wpset.add(), quote);
                }
        }

        // Copy all awarded service quotes to the WP

        private void copyQuotesToWPServ(MboSetRemote wpset, MboSetRemote quotes)
        throws MXException, RemoteException
        {
                int sizeofquotes=quotes.count();
                MboRemote quote = null;
                for (int j = sizeofquotes; j > 0; j --)
                {
                        quote = quotes.getMbo(j-1);
                        addToWPServ(wpset.add(), quote);
                }
        }


        /*
         * Create a new material WP based on an awarded quotation
         */
        private void addToWPMat(MboRemote wp, MboRemote quote)
                        throws MXException, RemoteException
        {
                addToWP(wp, quote);
        }


        /*
         * Create a new service WP based on an awarded quotation
         */
        private void addToWPServ(MboRemote wp, MboRemote quote)
                        throws MXException, RemoteException
        {
                addToWP(wp, quote);
        }


        /*
         * Create a new WP based on an awarded quotation
         */
        private void addToWP(MboRemote wp, MboRemote quote)
                        throws MXException, RemoteException
        {
                MboSetRemote rfqlineset=quote.getMboSet("RFQLINE");
                MboRemote rfqline=rfqlineset.getMbo(0);
                rfqline.setValue("wpitem",wp.getInt("wpitemid"));
                rfqline.setValue("wo",wp.getString("wonum"));
                rfqlineset.save();


                wp.setValue("linetype", quote.getString("linetype"));
                wp.setValue("directreq", true, MboConstantsCustom.NOACCESSCHECK);
                if (!quote.isNull("itemnum"))
                {
                        wp.setValue("itemnum", quote.getString("itemnum"));
                        if (!quote.isNull("catalogcode"))
                                wp.setValue("catalogcode", quote.getString("catalogcode"), MboConstantsCustom.NOACCESSCHECK);
                }
                else
                {
                        wp.setValue("description", quote.getString("description"));
                        wp.setValue("hasld", quote.getBoolean("hasld"), MboConstantsCustom.NOACCESSCHECK);
                        if (!quote.isNull("description_longdescription"))
                                wp.setValue("description_longdescription", quote.getString("description_longdescription"));
                }
                wp.setValue("itemqty", quote.getDouble("orderqty"));
                wp.setValue("vendor", quote.getString("vendor"));
                wp.setValue("orderunit", quote.getString("orderunit"));
                wp.setValue("unitcost", quote.getDouble("unitcost"));
                wp.setValue("originatingerfq", quote.getString("rfqnum"));
        }

        /*
         * Copy eRFQ awarded lines to the  Single WO , with price from awarded line
         */
        public void copyeRFQtoNewWO(MboSetRemote woset)
        throws MXException, RemoteException
        {
                // Get all the awarded quotations first
                MboSetRemote quotematset = getMboSet("AWARDEDMAT");
                MboSetRemote quoteservset = getMboSet("AWARDEDSERV");

                int i = 0;
                //System.out.println(MXServer.getMXServer().getDate() + " copsyeRFQtoWO - woset.count="+woset.count());
                for (MboRemote wo = null; (wo = woset.getMbo(i)) != null; i ++)
                {
                        //System.out.println(MXServer.getMXServer().getDate() + " copyeRFQtoWO - i="+i+", wo="+wo.getString("wonum")+", selected="+wo.isSelected());
                        // Create material first
                        WPMaterialSetRemote wpmatset = (WPMaterialSetRemote) wo.getMboSet("WPMATERIAL");
                        if (!quotematset.isEmpty())
                        {
                                copyQuotesToWPMat(wpmatset, quotematset);
                //              wpmatset.save();
                        }
                //      wpmatset.close();

                        // Create service second
                        WPServiceSetRemote wpservset = (WPServiceSetRemote) wo.getMboSet("WPSERVICE");
                        if (!quoteservset.isEmpty())
                        {
                                copyQuotesToWPServ(wpservset, quoteservset);
                //              wpservset.save();
                        }
                //      wpservset.close();
                        //System.out.println(MXServer.getMXServer().getDate() + " copyeRFQtoWO - Loop over and woset.count="+woset.count());
                }
                woset.save();
        }


        /*
         * Get the valid quotations (with regards to dates) that we can copy from
         */
        public MboSetRemote getRFQForCopy()
                        throws MXException, RemoteException
        {
                MboSetRemote quotationset = MXServer.getMXServer().getMboSet("QUOTATIONLINE", getUserInfo());
                //SqlFormat sql = new SqlFormat("quoteenddate>sysdate AND rfqnum in (SELECT rfqnum FROM rfq WHERE siteid=:1)");
                //SqlFormat sql = new SqlFormat("quoteenddate>sysdate AND linetype = 'MATERIAL' AND vendor not in (select vendor from rfqvendor where rfqnum=:1)");
                SqlFormat sql = new SqlFormat("quoteenddate>sysdate AND rfqnum<>:1 AND linetype = 'MATERIAL'");
                sql.setObject(1, "rfq", "rfqnum", getString("rfqnum"));
                quotationset.setWhere(sql.format());
                quotationset.setOrderBy("unitcost");
                quotationset.reset();
                return quotationset;
        }


        /*
         * Copy all awarded quotations from the eRFQ that originated the WO plan
         */
        public void copyFromeRFQ()
                        throws MXException, RemoteException
        {
                MXServer mxserver = MXServer.getMXServer();
                UserInfo userinfo = getUserInfo();

                /*
                 * Get the first WO plan that we find that originates from an eRFQ
                 * If no RFQ line is added manually, all lines fit. The below piece of code caters for the other case
                 */
                MboSetRemote rfqlineset = getMboSet("RFQLINE");
                MboRemote wp = null;
                int i = 0;
                for (MboRemote rfqline; (rfqline = rfqlineset.getMbo(i)) != null; i++)
                {
                        wp = rfqline.getMboSet("WPITEM").getMbo(0);
                        if (!wp.isNull("originatingerfq"))
                                break;
                }
                if (wp.isNull("originatingerfq"))
                        return;

                /*
                 * Get the awarded lines of the eRFQ for the RFQ vendor
                 * Because the user may have entered another vendor, we take the vendor from the WO plan
                 */
                MboSetRemote erfquotation = mxserver.getMboSet("QUOTATIONLINE", userinfo);
                //SqlFormat sql = new SqlFormat("rfqnum=:1 AND siteid=:2 AND vendor=:3 AND isawarded=1");
                //SqlFormat sql = new SqlFormat("rfqnum=:1 AND siteid=:2 AND vendor=:3");
                SqlFormat sql = new SqlFormat("rfqlinenum IN (SELECT rfqlinenum FROM QUOTATIONLINE WHERE rfqnum=:1 AND siteid=:2 AND isawarded=1) AND rfqnum=:1 AND siteid=:2");
                sql.setObject(1, "quotationline", "rfqnum", wp.getString("originatingerfq"));
                sql.setObject(2, "quotationline", "siteid", wp.getString("siteid"));
                //sql.setObject(3, "quotationline", "vendor", wp.getString("vendor"));
                erfquotation.setWhere(sql.format());
                // Copy the quotations from the eRFQ
                copyDetailsFromRFQ(erfquotation);
        }
        /*
         * Copy the quotation data from a set of quotations
         */
        public void copyDetailsFromRFQ(MboSetRemote refquoteset)
                        throws MXException, RemoteException
        {
                MboSetRemote quotationset = getMboSet("QUOTATIONLINEALL");

                String rfqnum=null;
                String vendor=null;
                String siteid=null;
                int i = 0;
                for (MboRemote refquote; (refquote = refquoteset.getMbo(i)) != null; i ++)
                {
                        int newrfqnum=0;
                        newrfqnum=getRFQLineNum(refquote);
                        //Quotaion Line will not be added if its not match with the RFQ Lines
                        if(newrfqnum == 0)
                                continue;
                        rfqnum=refquote.getString("rfqnum");
                        vendor = refquote.getString("vendor");
                        siteid=refquote.getString("siteid");
//                      System.out.println("rfqnum : "+rfqnum);
//                      System.out.println("rfqlinenum : "+newrfqnum);
//                      System.out.println("siteid : "+siteid);
//                      System.out.println("vendor : "+vendor);

                        boolean addvendor=true;

//                      System.out.println("rfqnum : "+getString("rfqnum"));
//                      System.out.println("siteid : "+getString("siteid"));
//                      System.out.println("vendor : "+vendor);
                        MboSetRemote vendorset = MXServer.getMXServer().getMboSet("RFQVENDOR", getUserInfo());
                        SqlFormat sql = new SqlFormat("rfqnum=:1 AND vendor=:2 AND siteid=:3");
                        sql.setObject(1, "rfqvendor", "rfqnum", getString("rfqnum"));
                        sql.setObject(2, "rfqvendor", "vendor", vendor);
                        sql.setObject(3, "rfqvendor", "siteid", getString("siteid"));
                        vendorset.setWhere(sql.format());

//                      System.out.println("Vendorset Size: "+vendorset.getSize());
//                      System.out.println("Vendorset Count: "+vendorset.count());

                        MboRemote vendor1= null;
//                      Vendor will not be added if the vendor is already in for this RFQ
                        for (int k=0; (vendor1 = vendorset.getMbo(k)) != null; k++)
                        {
//                              System.out.println("Vendorset Vendor: "+vendor1.getString("vendor"));
                                if(vendor.equals(vendor1.getString("vendor")))
                                        addvendor = false;
                        }
                        vendorset.reset();

                        if(addvendor)
                                addRFQVendor(getString("rfqnum"),vendor,getString("siteid"));

//                      System.out.println("Add Quote Start..................");

                        MboRemote temp = quotationset.add();
                        temp.setValue("RFQNUM", getString("rfqnum"),MboConstantsCustom.DBSET);

                        temp.setValue("RFQLINENUM", newrfqnum);
                        temp.setValue("alternate", refquote.getBoolean("alternate"));
                        addQuotation(temp, refquote);

                        //Set Total Quotation Amt
                        MboSetRemote rfqvendorset = temp.getMboSet("RFQVENDOR");
                        MboRemote rfqvendor = null;
                        rfqvendor=rfqvendorset.getMbo(0);
                        double totalquo = 0.0D;
                        totalquo= rfqvendor.getDouble("totalquotationamt") + refquote.getDouble("LINECOST");
                        rfqvendor.setValue("TOTALQUOTATIONAMT",totalquo,MboConstantsCustom.DBSET);
                        rfqvendorset.save();
                        rfqvendorset.close();
                }
                quotationset.save();
                quotationset.close();
        }

        /*
         * Add a vendor details from RFQ to the RFQ given a vendor code. Nothing is done if the vendor is already in
         */
        private void addeRFQVendor(String rfqnum, String vendor, String siteid)
                        throws MXException, RemoteException
        {
                /*
                //Retrieve all the quotaions(incl alt) with regards to awarded RFQ Line Num,  from eRFQ  for this vendor
                MboSetRemote erfquotationset = MXServer.getMXServer().getMboSet("QUOTATIONLINE", getUserInfo());
                SqlFormat sql2 = new SqlFormat("rfqlinenum IN (SELECT rfqlinenum FROM QUOTATIONLINE WHERE rfqnum=:1 AND siteid=:2 AND isawarded=1) AND rfqnum=:1 AND siteid=:2 AND vendor=:3");
                sql2.setObject(1, "quotationline", "rfqnum", rfqnum);
                sql2.setObject(2, "quotationline", "siteid", siteid);
                sql2.setObject(3, "quotationline", "vendor", vendor);
                erfquotationset.setWhere(sql2.format());
                double totalqtn = 0.0;
                MboRemote quote= null;
                for(int i=0; (quote=erfquotationset.getMbo(i)) != null; i++)
                        totalqtn += quote.getDouble("linecost");
*/
                MboSetRemote rfqvendorset = getMboSet("ERFQVENDOR");
                MboRemote rfqvendor = rfqvendorset.add(MboConstantsCustom.NOACCESSCHECK);
                rfqvendor.setValue("vendor", vendor, MboConstantsCustom.NOACCESSCHECK);
        //      rfqvendor.setValue("TOTALQUOTATIONAMT",totalqtn,MboConstantsCustom.DBSET);
                rfqvendorset.save();
                rfqvendorset.close();
        }

        /*
         * Create a quotationline from another quotation
         */
        private void addQuotation(MboRemote quote, MboRemote refquote)
                        throws MXException, RemoteException
        {
                quote.setValue("linetype", refquote.getString("linetype"));
                //quote.setValue("directreq", true, MboConstantsCustom.NOACCESSCHECK);
                if (!refquote.isNull("itemnum"))
                {
                        quote.setValue("itemnum", refquote.getString("itemnum"));
                        if (!refquote.isNull("catalogcode"))
                                quote.setValue("catalogcode", refquote.getString("catalogcode"), MboConstantsCustom.NOACCESSCHECK);
                }
                else
                {
                        quote.setValue("description", refquote.getString("description"));
                        quote.setValue("hasld", refquote.getBoolean("hasld"), MboConstantsCustom.NOACCESSCHECK);
                        if (!refquote.isNull("description_longdescription"))
                                quote.setValue("description_longdescription", refquote.getString("description_longdescription"));
                }
                quote.setValue("orderqty", refquote.getDouble("orderqty"),MboConstantsCustom.DBSET);
                quote.setValue("vendor", refquote.getString("vendor"),MboConstantsCustom.DBSET);
                quote.setValue("orderunit", refquote.getString("orderunit"));
                quote.setValue("unitcost", refquote.getDouble("unitcost"),MboConstantsCustom.DBSET);
                quote.setValue("linecost", refquote.getDouble("linecost"),MboConstantsCustom.DBSET);
                quote.setValue("deliverytime", refquote.getString("deliverytime"));
                quote.setValue("memo", refquote.getString("memo"));
                quote.setValue("quotestartdate", MXServer.getMXServer().getDate());
                quote.setValue("quoteenddate", refquote.getDate("quoteenddate"));
                quote.setValue("comments", refquote.getString("comments"));
                quote.setValue("itemsetid", refquote.getString("itemsetid"),MboConstantsCustom.DBSET);
                quote.setValue("tax1",refquote.getDouble("tax1"));
                quote.setValue("tax2",refquote.getDouble("tax2"));
                quote.setValue("tax3",refquote.getDouble("tax3"));
                quote.setValue("tax4",refquote.getDouble("tax4"));
                quote.setValue("tax5",refquote.getDouble("tax5"));
                quote.setValue("ENTERBY",refquote.getString("ENTERBY"));
                //Copy GL Credit AC details from the current RFQ related PR Line
                MboSetRemote prlineset = getMboSet("PRLINE");
                MboRemote prline = prlineset.getMbo(0);
                if(prline != null)
                        quote.setValue("GLCREDITACCT",prline.getString("GLCREDITACCT"),MboConstantsCustom.DBSET);
        }

        /*
         * Add a vendor details from RFQ to the RFQ given a vendor code. Nothing is done if the vendor is already in
         */
        private void addRFQVendor(String rfqnum, String vendor, String siteid)
                        throws MXException, RemoteException
        {
                MboSetRemote rfqvendorset = getMboSet("RFQVENDOR");
                MboRemote rfqvendor = rfqvendorset.add(MboConstantsCustom.NOACCESSCHECK);
                rfqvendor.setValue("vendor", vendor, MboConstantsCustom.NOACCESSCHECK);
                rfqvendor.setValue("rfqnum", rfqnum, MboConstantsCustom.NOACCESSCHECK);
                rfqvendor.setValue("siteid", siteid, MboConstantsCustom.NOACCESSCHECK);
                rfqvendorset.save();
                rfqvendorset.close();
        }

        private int getRFQLineNum(MboRemote refquote)
                                throws MXException, RemoteException
        {
                MboSetRemote refrfqlineset=refquote.getMboSet("RFQLINE");
                MboRemote refrfqline = refrfqlineset.getMbo(0);
                MboSetRemote rfqlineset = getMboSet("RFQLINE");
                int i=0;
                int rfqnum=0;
                for(MboRemote rfqline=null;(rfqline = rfqlineset.getMbo(i)) != null; i++)
                {
                        //Naming QUOTATION.RFQ Line Num with regards to RFQLINE.RFQ Line Num if copy from eRFQ
                        MboSetRemote prlineset = rfqline.getMboSet("PRLINE");
                        MboRemote prline = prlineset.getMbo(0);
                        MboSetRemote wpset = prline.getMboSet("WPITEM");
                        MboRemote wp = wpset.getMbo(0);
                        MboSetRemote orgrfqlineset = wp.getMboSet("ERFQLINE");
                        MboRemote orgrfqline = orgrfqlineset.getMbo(0);
                        if(orgrfqline != null)
                                if(refrfqline.getString("rfqnum").equals(orgrfqline.getString("rfqnum")) && refrfqline.getString("rfqlinenum").equals(orgrfqline.getString("rfqlinenum")) && refrfqline.getString("siteid").equals(orgrfqline.getString("siteid")))
                                        rfqnum=rfqline.getInt("rfqlinenum");
                }
                return rfqnum;
        }

        //working
        /*
         * Copy the quotation data from a set of quotations
         */
        public void copyFromRFQ(MboSetRemote refquoteset, String rfqlinenum)
                        throws MXException, RemoteException
        {
                MboSetRemote quotationset = getMboSet("QUOTATIONALTALL");
                String rfqnum=null;
                String vendor=null;
                String siteid=null;
                int i = 0;
                for (MboRemote refquote; (refquote = refquoteset.getMbo(i)) != null; i ++)
                {
                        /*MboRemote nextrefquote = null;
                        if(refquoteset.getMbo(i+1) != null)
                                nextrefquote =refquoteset.getMbo(i+1);*/
                        rfqnum=refquote.getString("rfqnum");
                        vendor = refquote.getString("vendor");
                        MboSetRemote vendorset = getMboSet("RFQVENDOR");
                        siteid=refquote.getString("siteid");
                        MboRemote refquote1;
                        int count=0;
                        //Counting the repetition of particular vendor details on the quotation line
                        for(int j=0; (refquote1 = vendorset.getMbo(j)) != null; j ++)
                                if(vendor.equals(refquote1.getString("vendor")))
                                        count++;

                        //Make sure vendor details are not repeated on RFQ
                        if(count == 0)
                                addRFQVendor(rfqnum,vendor,siteid);
                        MboRemote temp = quotationset.add();
                        temp.setValue("RFQNUM", getString("rfqnum"),MboConstantsCustom.DBSET);
                        temp.setValue("RFQLINENUM", rfqlinenum);
                        addQuotation(temp, refquote);

                        //Update Toatal Qtn Amt in RFQVendr
                        MboSetRemote rfqvendorset = temp.getMboSet("RFQVENDOR");
                        MboRemote rfqvendor = null;
                        rfqvendor=rfqvendorset.getMbo(0);
                        double totalquo = 0.0D;
                        totalquo= rfqvendor.getDouble("totalquotationamt") + refquote.getDouble("LINECOST");
                        rfqvendor.setValue("TOTALQUOTATIONAMT",totalquo,MboConstantsCustom.DBSET);
                        rfqvendorset.save();
                        rfqvendorset.close();
                }
                quotationset.save();
                quotationset.close();
        }

        //Allow editing of Open Duration filed in FINISHED(SENT) state
        public void setRelatedMboEditibility(String relationship, MboSetRemote mbosetremote)
        throws MXException, RemoteException
        {
                super.setRelatedMboEditibility(relationship, mbosetremote);
                String status=getString("STATUS");
                //String appn=getName();
                //System.out.println("-----------"+getInternalStatus()+"----------RFQ : "+getString("rfqnum")+"-------------Status : "+status
                                                                        //      +"-----------Appn : "+appn);
                if (!getInternalStatus().equalsIgnoreCase("INPRG"))
                {
                //Begin change of std MX method
                        //if (getInternalStatus().equalsIgnoreCase("SENT"))
                        if(status.equalsIgnoreCase("FINISHED") || status.equalsIgnoreCase("EFINISHED"))
                        {
                                // Get list of fields and set them all to read-only except open duration
                                Iterator attributelist = getMboSetInfo().getAttributes();
                                while (attributelist.hasNext())
                                {
                                        String attributename = ((MboValueInfo) attributelist.next()).getAttributeName();
                                        //added by WMJ for 20121031 for set OPENDURATION and WFREASSIGN as editable during FINISHED status
                                        if((attributename.equalsIgnoreCase("OPENDURATION"))||(attributename.equalsIgnoreCase("WFREASSIGN")))
                                        {
                                                setFieldFlag(attributename, MboConstantsCustom.READONLY, false);
                                        }
                                        //end of added by WMJ for 20121031 for set OPENDURATION as editable during FINISHED status
                                }
                                setFlag(7L, false);
                        }
                }
        }
        
        //Fix Open Duration is not read only during status FINISHED 
        public void initFieldFlagsOnMbo(String attrName)
		throws MXException
	  	{
		    super.initFieldFlagsOnMbo(attrName);
		    
		    if(attrName.equalsIgnoreCase("OPENDURATION"))
		    {
			    try
			    {
				    String status=getString("STATUS");	
				    if(status.equalsIgnoreCase("FINISHED") || status.equalsIgnoreCase("EFINISHED"))
		            {
			        	setFieldFlag(attrName, MboConstantsCustom.READONLY, false);
		            }
	        	}
	        	catch (RemoteException rx)
			    {
			      rx.printStackTrace();
			    }
			}
		    //Fix WF ReAssign  is not read only during status FINISHED  
		  //added by BCT* 2014
		    if(attrName.equalsIgnoreCase("WFREASSIGN"))
		    {
			    try
			    {
				    String status=getString("STATUS");	
				    if(status.equalsIgnoreCase("FINISHED") || status.equalsIgnoreCase("EFINISHED"))
		            {
			        	setFieldFlag(attrName, MboConstantsCustom.READONLY, false);
		            }
	        	}
	        	catch (RemoteException rx)
			    {
			      rx.printStackTrace();
			    }
			}
		    //End of add by BCT* 2014
			//start of EMS-558
			if(attrName.equalsIgnoreCase("CHGCLOSEONDATE"))
		    {
			    try
			    {
				    String status=getString("STATUS");	
				    if(status.equalsIgnoreCase("SENT"))
		            {
			        	setFieldFlag(attrName, MboConstantsCustom.READONLY, false);
		            }
	        	}
	        	catch (RemoteException rx)
			    {
			      rx.printStackTrace();
			    }
			}
			//start of EMS-558
			
			//start of EMS-572
			if(attrName.equalsIgnoreCase("CHGPURCHASEAGENT"))
		    {
			    try
			    {
				    String status=getString("STATUS");	
				    if(status.equalsIgnoreCase("FINISHED") || status.equalsIgnoreCase("SENT") || status.equalsIgnoreCase("REOPEN") || status.equalsIgnoreCase("REJECT-TO"))
		            {
			        	setFieldFlag(attrName, MboConstantsCustom.READONLY, false);
		            }
	        	}
	        	catch (RemoteException rx)
			    {
			      rx.printStackTrace();
			    }
			}
			//start of EMS-572
			
			if(attrName.equalsIgnoreCase("CHKEARLYCLOSURE"))
		    {
			    try
			    {
				    String status=getString("STATUS");	
				    if( status.equalsIgnoreCase("SENT") )
		            {
			        	setFieldFlag(attrName, MboConstantsCustom.READONLY, false);
		            } else {
		            	setFieldFlag(attrName, MboConstantsCustom.READONLY, true);
		            }
	        	}
	        	catch (RemoteException rx)
			    {
			      rx.printStackTrace();
			    }
			}
			
	  	}
        //End of Fix Open Duration is not read only during status FINISHED 

}
