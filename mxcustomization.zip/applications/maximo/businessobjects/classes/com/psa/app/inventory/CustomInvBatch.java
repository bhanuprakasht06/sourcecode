package com.psa.app.inventory;

import java.rmi.RemoteException;
import java.util.Date;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.custapp.CustomMbo;
import psdi.server.AppService;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class CustomInvBatch extends CustomMbo 
	implements CustomInvBatchRemote 
{
	public CustomInvBatch (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void init() 
		throws MXException 
	{
		super.init();
		String AlwaysReadOnly[] = {"BATCHNUM","BATCHDATE","BINNUM","LOTNUM","CONDITIONCODE","ITEMNUM","FAULTQTY","REMARKS"};
		setFieldFlag(AlwaysReadOnly, 7L, true);		
	}

	public void add() 
		throws MXException, RemoteException 
	{
		super.add();
		System.out.println("-------CustomInvBatch---------inside createReceipt()------------------");
		MboRemote owner = getOwner();
		String name = owner.getName();
		System.out.println("-------CustomInvBatch---------owner-----------------"+owner);
		System.out.println("-------CustomInvBatch---------name-----------------"+name);
		if (owner != null)
		{			
			if (name.equals("INVBALANCES"))
			{
				System.out.println("-------CustomInvBatch---------Entering to set Autonum------------------");
				MboSetRemote autoKeySetRemote = getMboServer().getMboSet("AUTOKEY", getUserInfo());
				autoKeySetRemote.setWhere("autokeyname='BATCHNUM'");
				autoKeySetRemote.reset();
				System.out.println("-------CustomInvBatch---------autoKeySetRemote------------------"+autoKeySetRemote);
				if(!autoKeySetRemote.isEmpty())
				{
					String keyvalue = Integer.toString(autoKeySetRemote.getMbo(0).getInt("SEED"));
					System.out.println("--------CustomInvBatch--------keyvalue----------------"+keyvalue);
					setValue("BATCHNUM", keyvalue, 2L);					
				}
				autoKeySetRemote.getMbo(0).setValue("SEED", autoKeySetRemote.getMbo(0).getInt("SEED")+1);
				System.out.println("--------CustomInvBatch--------after keyvalue update ----------------"+autoKeySetRemote.getMbo(0).getInt("SEED"));
					
				autoKeySetRemote.save();
				autoKeySetRemote.commit();
				autoKeySetRemote.close();
				autoKeySetRemote.clear();
				Date currentDate = ((AppService)getMboServer()).getMXServer().getDate();
				setValue("BATCHDATE", currentDate, 2L);
				setValue("ITEMNUM", owner.getString("ITEMNUM"), 2L);
				setValue("BINNUM", owner.getString("BINNUM"), 2L);
				setValue("LOTNUM", owner.getString("LOTNUM"), 2L);
				setValue("CONDITIONCODE", owner.getString("CONDITIONCODE"), 2L);
				setValue("LOCATION", owner.getString("LOCATION"), 2L);
				setValue("SITEID", owner.getString("SITEID"), 2L);
				setValue("ORGID", owner.getString("ORGID"), 2L);
				
			}			
		}		
	}
	
	public void save() 
		throws MXException, RemoteException 
	{
		super.save();
	}
	
	public void canDelete() 
			throws MXException, RemoteException 
	{
		super.canDelete();
		if (!toBeAdded())
			throw new MXApplicationException("jspmessages", "table_cannotdelete");		
	}
}
