/*
 * Modification history
 * 23-08-2007	AGD	SR-112	Creation
 * 14-09-2007	AGD	DR-046	SR-112 : Payment terms are required because vendor is copied to RFQ and can be awarded, but payment terms are required to approve the PO
 */
package com.psa.app.pr;

import java.rmi.RemoteException;
import java.sql.SQLException;

import psdi.common.action.ActionCustomClass;
import com.psa.custom.common.MxEmail;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXException;


public class SetVendorFromWPCustom
implements ActionCustomClass
{

public SetVendorFromWPCustom()
{
}


public void applyCustomAction(MboRemote pr, Object actionparam[])
	throws MXException, RemoteException
{
/*
 * Use to detect errors so that an email can be sent in that case, instead of throwing
 * This is required as the action is part of a workflow that's fully automated
 * (ie without user action). Therefore, throwing now would leave some cursors opened
 */
boolean error = false;
String errormsg = null;

MboRemote localpr = pr;
MboRemote prline = localpr.getMboSet("PRLINE").getMbo(0);
MboRemote wp = prline.getMboSet("WPITEM").getMbo(0);

// Run the update SQL (cannot be done via mbo as the vendor field class throws an error because the PR is approved)
UserInfo userinfo = localpr.getUserInfo();

//Begin DR-046
MboSetRemote companyset = MXServer.getMXServer().getMboSet("COMPANIES", userinfo);
SqlFormat sqlformat = new SqlFormat(userinfo, "company=:1 AND orgid=:2");
sqlformat.setObject(1, "companies", "company", wp.getString("vendor"));
sqlformat.setObject(2, "companies", "orgid", localpr.getString("orgid"));
companyset.setWhere(sqlformat.format());
String paymentterms = companyset.getMbo(0).getString("paymentterms");
companyset.close();
//End DR-046

DBShortcut dbshortcut = new DBShortcut();
try
{
	dbshortcut.connect(userinfo.getConnectionKey());
//Begin DR-046
//	SqlFormat sqlformat = new SqlFormat(userinfo, "UPDATE pr SET vendor=:1, pr10=0 WHERE prnum=:2 AND siteid=:3");
	sqlformat = new SqlFormat(userinfo, "UPDATE pr SET vendor=:1, pr10=0, paymentterms=:4 WHERE prnum=:2 AND siteid=:3");
	sqlformat.setObject(4, "pr", "paymentterms", paymentterms);
//End DR-046
	sqlformat.setObject(1, "pr", "vendor", wp.getString("vendor"));
	sqlformat.setObject(2, "pr", "prnum", localpr.getString("prnum"));
	sqlformat.setObject(3, "pr", "siteid", localpr.getString("siteid"));

	dbshortcut.execute(dbshortcut.UPDATE, sqlformat);
	dbshortcut.commit();
}
catch (SQLException sqle)
{
	try {
		dbshortcut.rollBack();
	}
	catch (Exception e) { 
		// Do nothing
	}
	sqle.printStackTrace();
	error = true;
	errormsg = sqle.getMessage();
}
catch (Exception e)
{
	e.printStackTrace();
	error = true;
	errormsg = e.getMessage();
}
finally
{
	try {
		dbshortcut.close();
	}
	catch (Exception e) {
		// Do nothing
	}
}

if (error)
{
	// Send an email to the administrator
	try
	{
		MxEmail email = new MxEmail();
		String errordetail = "Vendor " + wp.getString("vendor") + "cannot be set back in PR " + localpr.getString("prnum");
		Object param[] = { errordetail, errormsg };
		email.emailForActionError(getClass().getName(), param);
	}
	catch (Exception e) {
		// Do nothing
	}
}
}

}
