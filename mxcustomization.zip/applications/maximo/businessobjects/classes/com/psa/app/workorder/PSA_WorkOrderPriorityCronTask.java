package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboSetRemote;
import psdi.security.ConnectionKey;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;

public class PSA_WorkOrderPriorityCronTask extends SimpleCronTask {
	private boolean ready;
	private MXLogger logger;
	private MXServer server;
	private UserInfo userInfo;
	private String email;

	public PSA_WorkOrderPriorityCronTask() {
		ready = false;
		logger = getCronTaskLogger();
	}
	public CrontaskParamInfo[] getParameters() throws MXException,RemoteException
	{
		CrontaskParamInfo params[] = new CrontaskParamInfo[2];
		params[0] = new CrontaskParamInfo();
		params[0].setName("SITEID");
		
		params[1] = new CrontaskParamInfo();
		params[1].setName("FUNCTYPE");
		//params[0].setDefault("");
		


		return params;	

	}
	private String getCronValue(String paramName)
	{
		String paramValue=null;
		try
		{
			paramValue = getParamAsString(paramName);
			if(paramValue==null || paramValue.trim().length()==0)
			{
				paramValue="";
			}
			if(paramValue.contains(","))
			{
				String paramreplace=null;
				paramreplace=paramValue.replace(",", "','");
				paramValue = "('"+paramreplace+"')";
			}
			else
			{
				paramValue = "('"+paramValue+"')";
			}
		}
		catch (Exception e)
		{
			System.out.println("@@@@@@@@@@@@@@@@@@@@@");
			System.out.println("Exception is::"+ e);
			
		}
		return paramValue;
	}
	public void start() {
		try {
			readConfig();
			ready = true;
		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				logger.error("Unable to start cron task");
				logger.error(e);
			}
		}
	}

	void readConfig() throws Exception {
		server = MXServer.getMXServer();
		userInfo = getRunasUserInfo();
		email = server.getConfig().getProperty("mxe.adminEmail", null);
	}

	@Override
	public void cronAction() {
		int i = 0;
		// boolean updateStatus = false;
		if (!ready) {
			if (logger.isErrorEnabled())
				logger.error("Cron task is not ready to run, aborting action");
			return;
		}

		double overduePctTemp = 0;
		double overduePctTemp1 = 0;
		double overduePctTemp2 = 0;

		MXServer mxServer = null;
		ConnectionKey conKey = null;
		MboSetRemote woSet;
		Connection conn = null;
		Statement stmt1 = null;
		Statement stmt2 = null;
		ResultSet mainResultSet = null;
		ResultSet priorityResultSet = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try 
		{
			mxServer = MXServer.getMXServer();
			conKey = mxServer.getSystemUserInfo().getConnectionKey();
			conn = mxServer.getDBManager().getConnection(conKey);

			stmt1 = conn.createStatement();
			stmt2 = conn.createStatement(); //Copied here from line 326 for connection close issue
			
			String funcTypeVal = getCronValue("FUNCTYPE");
			System.out.println("funcTypeVal##########################"+funcTypeVal);
			String funcType = "";
			if(funcTypeVal!=null && !funcTypeVal.equals("") && funcTypeVal.contains("QC")) {
				funcType = "QC";
			}else {
				funcType = "YC";
			}
			System.out.println("funcType##########################"+funcType);
			
	/*BCT modification starts.
	 * Date: 07-Sep-2020
	 *  
	 * Oracle format query is commented.		
	 */

		/*	String query = "SELECT MAX(OVERDUE) OVERDUE,WORKORDERID,WONUM,LOCATION,ASSETNUM,WORKTYPE,FREQUENCY,SITEID,COLORCODE,"
				+ " TARGSTARTDATE,PMNUM,USETARGETDATE,FREQUNIT, LASTSTARTDATE,LASTCOMPDATE,PREFIX"
				+ " FROM (SELECT LC.SITEID,LC.LOCATION,LC.PREFIX,WO.WORKORDERID,WO.WONUM,WO.TARGSTARTDATE,WO.COLORCODE,WO.ASSETNUM,PM.PMNUM,PM.WORKTYPE,PM.USETARGETDATE,"
				+ " PM.LASTSTARTDATE,PM.LASTCOMPDATE,PM.FREQUENCY,PM.FREQUNIT,PMM.TOLERANCE,PMM.METERNAME,PMM.LASTPMWOGENREAD + NVL(PMM.TOLERANCE,0) READINGATNEXTWO,"  
				+ " PMM.FREQUENCY METEWRFREQUENCY,LM.LOCATIONMETERID,LM.LASTREADING,LM.LASTREADINGDATE,AM.ASSETMETERID,AM.LASTREADING AS AM_LASTREADING,AM.LASTREADINGDATE AS AM_LASTREADINGDATE,"  
				+ " CASE WHEN LM.LOCATIONMETERID IS NOT NULL THEN ((TO_NUMBER(NVL(REPLACE(LM.LASTREADING,',',''),0)) - (PMM.FREQUENCY + NVL((SELECT READING FROM LOCMETERREADING WHERE LOCATION=LC.LOCATION AND SITEID=LC.SITEID AND METERNAME=PMM.METERNAME AND"  
				+ " READINGDATE=(SELECT MAX(READINGDATE) FROM LOCMETERREADING WHERE LOCATION=LC.LOCATION AND SITEID=LC.SITEID AND METERNAME=PMM.METERNAME AND" 
				+ " READINGDATE <= PM.LASTCOMPDATE)),0)))/PMM.FREQUENCY) ELSE ((TO_NUMBER(NVL(REPLACE(AM.LASTREADING,',',''),0)) - (PMM.FREQUENCY + NVL((SELECT READING FROM METERREADING WHERE ASSETNUM=WO.ASSETNUM AND SITEID=LC.SITEID"  
				+ " AND METERNAME=PMM.METERNAME AND READINGDATE=(SELECT MAX(READINGDATE) FROM METERREADING WHERE ASSETNUM=WO.ASSETNUM AND" 
				+ " SITEID=LC.SITEID AND METERNAME=PMM.METERNAME AND READINGDATE <= PM.LASTCOMPDATE)),0)))/PMM.FREQUENCY) END AS OVERDUE" 
				+ " FROM LOCATIONS LC, WORKORDER WO, PM, PMMETER PMM, LOCATIONMETER LM, ASSETMETER AM"  
				+ " WHERE LC.LOCATION = WO.LOCATION (+)  AND LC.SITEID = WO.SITEID (+)"  
				+ " AND WO.PMNUM = PM.PMNUM (+)  AND WO.SITEID = PM.SITEID (+)"  
				+ " AND PM.SITEID = PMM.SITEID (+) AND PM.PMNUM = PMM.PMNUM (+)"  
				+ " AND PMM.SITEID = LM.SITEID (+) AND PMM.LOCATION = LM.LOCATION (+) AND PMM.METERNAME = LM.METERNAME (+)"  
				+ " AND PMM.SITEID = AM.SITEID (+) AND PMM.ASSETNUM = AM.ASSETNUM (+)  AND PMM.METERNAME = AM.METERNAME (+)"  
				+ " AND WO.STATUS NOT IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID = 'WOSTATUS' AND MAXVALUE IN ('COMP','CAN','CLOSE'))"  
				+ " AND WO.COLORCODE IN ('RED', 'AMBER') AND PM.STATUS = 'ACTIVE'  AND (PM.FREQUENCY <> 0 OR PMM.FREQUENCY <> 0)" 
				+ " AND WO.ACTSTART IS NULL AND WO.SITEID in "+getCronValue("SITEID")+" ) WO" 
				+ " GROUP BY WORKORDERID,WONUM,LOCATION,ASSETNUM,PREFIX,WORKTYPE,FREQUENCY,SITEID,COLORCODE,TARGSTARTDATE,PMNUM,USETARGETDATE,FREQUNIT,LASTSTARTDATE,LASTCOMPDATE" 
				+ " ORDER BY LOCATION, ASSETNUM, WORKTYPE";*/
		
	/*
	 * BCT: Oracle to SQL conversion is completed. The SQL server format query is rendered below. 
	 * 
	 */
			
			String query = " SELECT MAX(OVERDUE) OVERDUE,WORKORDERID,WONUM,LOCATION,ASSETNUM,WORKTYPE,FREQUENCY,SITEID,COLORCODE, "
					+ " TARGSTARTDATE,PMNUM,USETARGETDATE,FREQUNIT, LASTSTARTDATE,LASTCOMPDATE,PREFIX "
					+ " FROM (SELECT LC.SITEID,LC.LOCATION,LC.PREFIX,WO.WORKORDERID,WO.WONUM,WO.TARGSTARTDATE,WO.COLORCODE,WO.ASSETNUM,PM.PMNUM,PM.WORKTYPE,PM.USETARGETDATE, "
					+ " PM.LASTSTARTDATE,PM.LASTCOMPDATE,PM.FREQUENCY,PM.FREQUNIT,PMM.TOLERANCE,PMM.METERNAME,PMM.LASTPMWOGENREAD + isnull(PMM.TOLERANCE,0) READINGATNEXTWO,   "
					+ " PMM.FREQUENCY METEWRFREQUENCY,LM.LOCATIONMETERID,LM.LASTREADING,LM.LASTREADINGDATE,AM.ASSETMETERID,AM.LASTREADING AS AM_LASTREADING,AM.LASTREADINGDATE AS AM_LASTREADINGDATE,  " 
					+ " CASE WHEN LM.LOCATIONMETERID IS NOT NULL THEN ((cast(isnull(REPLACE(LM.LASTREADING,',',''),0) as char) - (PMM.FREQUENCY + isnull((SELECT READING FROM LOCMETERREADING WHERE LOCATION=LC.LOCATION AND SITEID=LC.SITEID AND METERNAME=PMM.METERNAME AND  " 
					+ " READINGDATE=(SELECT MAX(READINGDATE) FROM LOCMETERREADING WHERE LOCATION=LC.LOCATION AND SITEID=LC.SITEID AND METERNAME=PMM.METERNAME AND  "
					+ " READINGDATE <= PM.LASTCOMPDATE)),0)))/PMM.FREQUENCY) ELSE ((cast(isnull(REPLACE(AM.LASTREADING,',',''),0) as char) - (PMM.FREQUENCY + isnull((SELECT READING FROM METERREADING WHERE ASSETNUM=WO.ASSETNUM AND SITEID=LC.SITEID   "
					+ " AND METERNAME=PMM.METERNAME AND READINGDATE=(SELECT MAX(READINGDATE) FROM METERREADING WHERE ASSETNUM=WO.ASSETNUM AND  "
					+ " SITEID=LC.SITEID AND METERNAME=PMM.METERNAME AND READINGDATE <= PM.LASTCOMPDATE)),0)))/PMM.FREQUENCY) END AS OVERDUE  "
					+ " FROM  "
					+ " LOCATIONS LC " 
					+ " left outer join  WORKORDER WO on  "
					+ " LC.LOCATION = WO.LOCATION  AND LC.SITEID = WO.SITEID "
					+ " left outer join  PM on  "
					+ " WO.PMNUM = PM.PMNUM  AND WO.SITEID = PM.SITEID  "
					+ " left outer join PMMETER PMM on  "
					+ " PM.SITEID = PMM.SITEID AND PM.PMNUM = PMM.PMNUM  "
					+ " left outer join LOCATIONMETER LM on "
					+ " PMM.SITEID = LM.SITEID AND PMM.LOCATION = LM.LOCATION AND PMM.METERNAME = LM.METERNAME  "
					+ " left outer join  ASSETMETER AM  on "
					+ " PMM.SITEID = AM.SITEID AND PMM.ASSETNUM = AM.ASSETNUM  AND PMM.METERNAME = AM.METERNAME   "
					+ " WHERE "
					+ " WO.STATUS NOT IN (SELECT VALUE FROM SYNONYMDOMAIN WHERE DOMAINID = 'WOSTATUS' AND MAXVALUE IN ('COMP','CAN','CLOSE'))  "  
					+ " AND WO.COLORCODE IN ('RED', 'AMBER') AND PM.STATUS = 'ACTIVE'  AND (PM.FREQUENCY <> 0 OR PMM.FREQUENCY <> 0)  "
					+ " AND WO.ACTSTART IS NULL AND WO.SITEID in "+getCronValue("SITEID")+" AND LC.FUNCTIONTYPE in "+getCronValue("FUNCTYPE")+" ) WO  "
					+ " GROUP BY WORKORDERID,WONUM,LOCATION,ASSETNUM,PREFIX,WORKTYPE,FREQUENCY,SITEID,COLORCODE,TARGSTARTDATE,PMNUM,USETARGETDATE,FREQUNIT,LASTSTARTDATE,LASTCOMPDATE  "
					+ " ORDER BY LOCATION, ASSETNUM, WORKTYPE ";

			/*
			 * BCT Modification ends (Oracle to SQL Conversion).
			 */
			mainResultSet = stmt1.executeQuery(query);

			while (mainResultSet.next()) 
			{
				overduePctTemp1 = mainResultSet.getDouble("overdue") * 100;
				Calendar lastPMDate = Calendar.getInstance();
				Calendar nextPMDate = Calendar.getInstance();
				String wonum = mainResultSet.getString("WONUM");
				String woid = mainResultSet.getString("WORKORDERID");
				String siteid = mainResultSet.getString("SITEID");
				String worktype = mainResultSet.getString("WORKTYPE");
				double frequency = mainResultSet.getDouble("FREQUENCY");
				double noOfDayOverdue = 0;
				logger.info("---WONUM: " + wonum);
				logger.info("---FREQUENCY: " + frequency);
				logger.info("---OVERDUE 1: " + overduePctTemp1);
				System.out.println("---WONUM: " + wonum);
				System.out.println("---FREQUENCY: " + frequency);
				System.out.println("---OVERDUE 1: " + overduePctTemp1);
				overduePctTemp2 = 0;
				if (frequency > 0.0) 
				{
					String freqUnit = mainResultSet.getString("FREQUNIT");
					logger.info("---FREQUNIT: " + freqUnit);
					System.out.println("---FREQUNIT: " + freqUnit);
					if (mainResultSet.getDouble("USETARGETDATE") != 0) 
					{
						if (mainResultSet.getTimestamp("LASTSTARTDATE") != null) 
						{
							lastPMDate.setTimeInMillis(mainResultSet.getTimestamp("LASTSTARTDATE").getTime());
						}
					} 
					else 
					{
						if (mainResultSet.getTimestamp("LASTCOMPDATE") != null) 
						{
							lastPMDate.setTimeInMillis(mainResultSet.getTimestamp("LASTCOMPDATE").getTime());
						}
					}
					logger.info("---LAST PM DATE: " + dateFormat.format(lastPMDate.getTime()));
					System.out.println("---LAST PM DATE: " + dateFormat.format(lastPMDate.getTime()));
					if (nextPMDate != null) 
					{
						nextPMDate.setTime(lastPMDate.getTime());
						if (freqUnit.equalsIgnoreCase("HOURS")) {
							nextPMDate.add(Calendar.HOUR_OF_DAY, (int) frequency);
						} else if (freqUnit.equalsIgnoreCase("DAYS")) {
							nextPMDate.add(Calendar.DATE, (int) frequency);
						} else if (freqUnit.equalsIgnoreCase("WEEKS")) {
							nextPMDate.add(Calendar.WEEK_OF_YEAR, (int) frequency);
						} else if (freqUnit.equalsIgnoreCase("MONTHS")) {
							nextPMDate.add(Calendar.MONTH, (int) frequency);
						} else if (freqUnit.equalsIgnoreCase("YEARS")) {
							nextPMDate.add(Calendar.YEAR, (int) frequency);
						}
					}
					
					logger.info("---NEXT PM DATE: " + dateFormat.format(nextPMDate.getTime()));
					System.out.println("---NEXT PM DATE: " + dateFormat.format(nextPMDate.getTime()));
					if (nextPMDate != null) 
					{
						long diff = (new Date()).getTime() - nextPMDate.getTimeInMillis();
						noOfDayOverdue = (diff / (1000 * 60 * 60 * 24));
					}
					
					overduePctTemp2 = 0;
					logger.info("---Number Of Day Overdue: " + noOfDayOverdue);
					System.out.println("---Number Of Day Overdue: " + noOfDayOverdue);
					/*if (noOfDayOverdue > 0) 
					{*/
						if (freqUnit.equalsIgnoreCase("HOURS")) 
						{
							double result = frequency / 24;
							double result1 = noOfDayOverdue / result;
							overduePctTemp2 = result1 * 100;
						} 
						else if (freqUnit.equalsIgnoreCase("DAYS")) 
						{
							double result = frequency;
							double result1 = noOfDayOverdue / result;
							overduePctTemp2 = result1 * 100;
						} 
						else if (freqUnit.equalsIgnoreCase("WEEKS")) 
						{
							overduePctTemp2 = (noOfDayOverdue / (frequency * 7)) * 100;
						} 
						else if (freqUnit.equalsIgnoreCase("MONTHS")) 
						{
							overduePctTemp2 = ((noOfDayOverdue / (frequency * 30)) * 100) + .1;
						} 
						else if (freqUnit.equalsIgnoreCase("YEARS")) 
						{
							overduePctTemp2 = ((noOfDayOverdue / (frequency * 365)) * 100);
						}
					/*} 
					else 
					{
						overduePctTemp2 = 0;
					}*/
					
				}
				logger.info("---OVERDUE 2: " + overduePctTemp2);
				System.out.println("---OVERDUE 2: " + overduePctTemp2);
                System.out.println("---OVERDUE 1: " + overduePctTemp1); 
                 
                //Commented the below code to remove the overdue precedence of time over meter
	                /*if(overduePctTemp2 < 0){ 
	                    overduePctTemp = overduePctTemp2; 
	                } 
	                else*/ 
	                	if ((overduePctTemp2 > overduePctTemp1)) 
				{
					overduePctTemp = overduePctTemp2;
				} 
				else if ((overduePctTemp1 > overduePctTemp2)) 
				{
					overduePctTemp = overduePctTemp1;
				} 
				else if (overduePctTemp1 == 0) 
				{
					overduePctTemp = overduePctTemp2;
				} 
				else if (overduePctTemp2 == 0) 
				{
					overduePctTemp = overduePctTemp1;
				}
				
				logger.info("---FINAL OVERDUE: " + overduePctTemp);
				System.out.println("---FINAL OVERDUE: " + overduePctTemp);
				//stmt2 = conn.createStatement();
				/*String queryGetPriority = "SELECT PRIORITY FROM PSA_PRIORITYMATRIX"
				+ " WHERE ROWNUM=1 AND SITEID='"+siteid+"' AND WORKTYPE='"+worktype+"' AND PERCENTAGE < " + overduePctTemp;*/				
				String queryGetPriority = "";
				if(overduePctTemp <0){
					if(funcType!=null && funcType.equalsIgnoreCase("QC")) {
						
						 queryGetPriority = "SELECT TOP 1 PRIORITY FROM PSA_PRIORITYMATRIX"
									+ " WHERE PSA_FUNCTYPE in "+getCronValue("FUNCTYPE")+"  AND SITEID='"+siteid+"' AND WORKTYPE='"+worktype+"' AND PERCENTAGE > " + overduePctTemp +" order by percentage asc ";
						 
					}else {
						 queryGetPriority = "SELECT TOP 1 PRIORITY FROM PSA_PRIORITYMATRIX"
									+ " WHERE PSA_FUNCTYPE in "+getCronValue("FUNCTYPE")+"  AND SITEID='"+siteid+"' AND WORKTYPE='"+worktype+"' AND PERCENTAGE > " + overduePctTemp +" order by percentage asc ";
					}
				}else{
					if(funcType!=null && funcType.equalsIgnoreCase("QC")) {
						
						 queryGetPriority = "SELECT TOP 1 PRIORITY FROM PSA_PRIORITYMATRIX"
									+ " WHERE PSA_FUNCTYPE in "+getCronValue("FUNCTYPE")+" AND SITEID='"+siteid+"' AND WORKTYPE='"+worktype+"' AND PERCENTAGE < " + overduePctTemp +" order by percentage desc ";
						 
					}else {
						 queryGetPriority = "SELECT TOP 1 PRIORITY FROM PSA_PRIORITYMATRIX"
									+ " WHERE PSA_FUNCTYPE in "+getCronValue("FUNCTYPE")+" AND SITEID='"+siteid+"' AND WORKTYPE='"+worktype+"' AND PERCENTAGE < " + overduePctTemp +" order by percentage desc ";
					}
				}
				System.out.println("queryGetPriority##########################"+queryGetPriority);
				
				
				priorityResultSet = stmt2.executeQuery(queryGetPriority);
				if (priorityResultSet.next()) 
				{
					String priority = priorityResultSet.getString("PRIORITY");
					logger.info("---PRIORITY FOUND FROM MATRIX: " + priority);
					System.out.println("---PRIORITY FOUND FROM MATRIX: " + priority);
					if (overduePctTemp > 0 || overduePctTemp < 0) 
					{
						woSet = server.getMboSet("WORKORDER", userInfo);
						woSet.setWhere("WORKORDERID=" + woid.replace(",",""));
						try 
						{
							for (i = 0; i < woSet.count(); i++) 
							{
								System.out.println("---UPDATE PIRORITY");
								logger.info("---UPDATE PIRORITY");
								woSet.moveTo(i).setValue("WOPRIORITY", priority);
								if  (overduePctTemp > 0)
								{									
									double round_overduePctTemp = Math.round(overduePctTemp);
									System.out.println("---round_overduePctTemp----"+round_overduePctTemp);
									woSet.moveTo(i).setValue("PM_BACKLOG_PERCENTAGE", String.valueOf(round_overduePctTemp));
									System.out.println("---UPDATE PM_BACKLOG_PERCENTAGE");
								}
							}
							woSet.save();
						} 
						catch (Exception e) 
						{								
							if (logger.isErrorEnabled()) 
							{
								logger.error("Cron action failed");
								logger.error(e);
							}
						}
					}
				} 
				else 
				{
					logger.info("---Cannot find any matching priority in PSA_PRIORITYMATRIX");
					System.out.println("---Cannot find any matching priority in PSA_PRIORITYMATRIX");
				}				
			}
		} 
		catch (Exception e) 
		{
			if (logger.isErrorEnabled()) 
			{
				logger.error("Cron action failed");
				logger.error(e);
			}
		} 
		finally 
		{
			try 
			{
				logger.info("Closing connection...");
				System.out.println("Closing connection...");
				mainResultSet.close();
				priorityResultSet.close();
				stmt1.close();
				stmt2.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				if (logger.isErrorEnabled()) 
				{
					logger.error("Cron action failed");
					logger.error(e);
				}
			}
		}
	}

}
