/*
 * Created by BCT 
 * 
 * Section code duplicate validation
 * 
 * 
 */
package com.psa.app.section;
import java.rmi.RemoteException;

import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldSectionCustom extends MboValueAdapter {

	public FldSectionCustom(MboValue mbv) {
		super(mbv);
	
	}

//Should not allow dublicate Section Code
	public void validate() throws MXException, RemoteException {
		
		
		System.out.println();
		String section=getMboValue("SECTION").getString();
	
		SqlFormat sectionSql=new SqlFormat("SECTION=:1");
		sectionSql.setObject(1, "SECTIONMAP", "SECTION", section);
		MboSetRemote sectionSetRemote=getMboValue().getMbo().getMboSet("$SECTION","SECTIONMAP",sectionSql.format());
		if(sectionSetRemote.count()>0)
		{
			throw new MXApplicationException("section","sectioncode");
		}
		
		super.validate();
	}

	
	

}
