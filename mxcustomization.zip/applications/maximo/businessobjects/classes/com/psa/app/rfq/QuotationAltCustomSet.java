/*
 * Modification history
 * 28-09-07	AGD	NA		Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.app.rfq.QuotationLineSet;
import psdi.util.MXException;


public class QuotationAltCustomSet extends QuotationLineSet//QuotationLineSet
		implements QuotationAltCustomSetRemote
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public QuotationAltCustomSet(MboServerInterface mboserverinterface)
			throws MXException, RemoteException
	{
		super(mboserverinterface);
	}


	protected Mbo getMboInstance(MboSet quotationlinealtset)
			throws MXException, RemoteException
	{
		return new QuotationAltCustom(quotationlinealtset);
	}
}
