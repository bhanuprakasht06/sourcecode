/*
 * Modification history
 * 03-Oct-2007		AGD	SR-116	Validate vendor and update lookup
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;

import com.psa.app.common.VendorCheckCustom;

import psdi.app.rfq.FldRFQVendorVendor;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXException;


public class FldRFQVendorVendorCustom extends FldRFQVendorVendor
{

	public FldRFQVendorVendorCustom(MboValue vendorvalue)
			throws MXException, RemoteException
	{
		super(vendorvalue);
	}


	public void validate()
			throws MXException, RemoteException
	{
		super.validate();
		VendorCheckCustom.checkValidity(getMboValue(), "COMPANIES");
	}


	/*
	 * Lookup
	 */
	public MboSetRemote getList()
   		throws MXException, RemoteException
    {
		return VendorCheckCustom.getValidVendorList(getMboValue().getMbo());
    }
	
	/*
	 * Copy the GL Credit A/C, fax and email fields from the company
	 */
	 
/*
 * Written Automation script for the following commented part of the code.  
 	public void action()
    	throws MXException, RemoteException
    {
		super.action();
		if(!getMboValue().isNull() || !getMboValue().equals(""))
		{
			Mbo mbo = getMboValue().getMbo();
			MboRemote vendor = getMboSet().getMbo(0);
			mbo.setValue("glcreditacct", vendor.getString("rbniacc"), MboConstantsCustom.DBSET);
			mbo.setValue("emailrfq", vendor.getBoolean("emailrfq"), MboConstantsCustom.DBSET);
			mbo.setValue("faxrfq", vendor.getBoolean("faxrfq"),MboConstantsCustom.DBSET);
			mbo.setValue("faxbriefrfq", vendor.getBoolean("faxbriefrfq"),MboConstantsCustom.DBSET);
		}
    }*/
}
