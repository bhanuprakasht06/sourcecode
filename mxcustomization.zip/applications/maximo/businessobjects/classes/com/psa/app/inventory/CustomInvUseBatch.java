package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.custapp.CustomMbo;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class CustomInvUseBatch extends CustomMbo 
	implements CustomInvUseBatchRemote 
{
	public CustomInvUseBatch (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void init() 
			throws MXException 
	{
		super.init();
		try
		{
			if (!toBeAdded())
			{
				String maxStatus = getString("STATUS");
				if (maxStatus.equalsIgnoreCase("COMPLETE"))
					setFlag(7L, true);
				else
				{
					setFieldFlag("batchnum", 7L, true);
					setFlag(7L, false);					
				}
			}
				
		}
		catch (RemoteException e)
		{
			e.printStackTrace();
		}		
	}
	
	
	public void add() 
		throws MXException, RemoteException 
	{
		super.add();
		MboRemote owner = getOwner();
		String name = owner.getName();
		if ((owner != null) && (name.equals("INVUSELINE")))
		{
			setValue("invuselineid", owner.getString("invuselineid"), 2L);
			setValue("invusenum", owner.getString("invusenum"), 2L);
			setValue("siteid", owner.getString("siteid"), 2L);
			setValue("orgid", owner.getString("orgid"), 2L);
			setValue("location", owner.getString("fromstoreloc"), 2L);
			setValue("tolocation", owner.getString("tostoreloc"), 2L);
			setValue("usagetype", owner.getString("usetype"), 2L);
			setValue("itemnum", owner.getString("itemnum"), 2L);
			setValue("binnum", owner.getString("frombin"), 2L);
			setValue("tobin", owner.getString("tobin"), 2L);
			setValue("lotnum", owner.getString("fromlot"), 2L);
			setValue("tolot", owner.getString("tolot"), 2L);
			setValue("conditioncode", owner.getString("fromconditioncode"), 2L);
			setValue("refwo", owner.getString("refwo"), 2L);
			setValue("quantity", owner.getString("quantity"), 2L);
			setValue("status", "ENTERED", 2L);			
			setValue("changed", true, 2L);
			setFieldFlag("remarks", 8L, true);
		}
	}
	
	public void save() 
		throws MXException, RemoteException 
	{				
		if (getBoolean("CHANGED") && isNull("REMARKS"))
		{
			setFieldFlag("remarks", 8L, true);
			Object[] params = { getString("ITEMNUM"), getString("BATCHNUM")};
			throw new MXApplicationException("psa", "enterRemarks",params);
		}
		super.save();
	}
	
	public void canDelete() 
			throws MXException, RemoteException 
	{
		super.canDelete();
		
		MboRemote owner = getOwner();
		if (owner != null)
		{
			MboRemote OwnerOwner = owner.getOwner();
			String name = OwnerOwner.getName();
			if ((owner != null) && (name.equals("INVUSE")))
			{
				if (!toBeAdded() && OwnerOwner.getString("STATUS").equalsIgnoreCase("COMPLETE"))
					throw new MXApplicationException("jspmessages", "table_cannotdelete");
			}
		}			
	}
}
