/*
 * Modification history
 * 22-01-13 WMJ Creation
 * 22-01-13 WMJ EMS-545 [LABTRANS]Escalation to highlight labour with more than 60 hours of OT in a calendar month 
 *
 *
 *
 */
package com.psa.app.labor;

import java.rmi.RemoteException;

import psdi.mbo.MboConstants;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXException;

import java.util.Calendar;
import java.util.Date;

import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

//import com.psa.app.labor.LabTransCustom;
import com.psa.app.labor.LabTransCustomRemote;
//import com.psa.app.labor.LabTransCustomSet;

public class FldLaborMtdOTHrs extends MboValueAdapter
{
  public FldLaborMtdOTHrs(MboValue mbv)
    throws MXException
  {
    super(mbv);
  }

  public void initValue()
    throws MXException, RemoteException
  {
    super.initValue();

    double laborMtdOTHrs = 0.0D;

    MboValue laborMtdOTHrsTotal = getMboValue();
    
    MboRemote localLabTrans = getMboValue().getMbo().getMboSet("LABTRANS").getMbo(0);

    if (!getMboValue("laborcode").isNull() && localLabTrans!=null)
    {
	    //A. Get sum of regular hours of all labtrans of this labourcode with the conditions below:
	    //1. OT flag=1
	    //2. start date is in this month(equal to or after first day of this month)
	    //3. finish date is in this month(equal to or after first day of this month & before first Date of next month)
		//LabTransCustomSet laborTransSetA = (LabTransCustomSet)MXServer.getMXServer().getMboSet("LABTRANS", localLabTrans.getUserInfo());
		MboSetRemote laborTransSetA = MXServer.getMXServer().getMboSet("LABTRANS", localLabTrans.getUserInfo());
		laborTransSetA.setFlag(MboConstants.DISCARDABLE, true);
		
		/*
    	 * 03-09-2020
    	 * <START> - Code below has been commented as part of the DB migration from Oracle to SQL 
    	 
    	 
		//SqlFormat sqlformatLabA = new SqlFormat(localLabTrans.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE>=trunc(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1) and FINISHDATE>=trunc(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1) and FINISHDATE<trunc(LAST_DAY(SYSDATE)+1)");
		*/
		
		SqlFormat sqlformatLabA = new SqlFormat(localLabTrans.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE>= dateadd(day,1,EOMONTH(getdate(),-1)) and FINISHDATE>=dateadd(day,1,EOMONTH(getdate(),-1)) and FINISHDATE<dateadd(day,1,EOMONTH(getdate()))");
		
		/*
		 *  03-09-2020 : BCT modification ends here (Oracle to SQL conversion)
		 *  <END>	    	
		 */
		
		sqlformatLabA.setObject(1, "LABTRANS", "LABORCODE", localLabTrans.getString("laborcode"));
    	sqlformatLabA.setObject(2, "LABTRANS", "PSA_OT_FLAG", "1");
    	laborTransSetA.setWhere(sqlformatLabA.format());
    	
    	//System.out.println("-localLabTrans-" + localLabTrans.getString("laborcode"));
    	//System.out.println("-laborTransSetA-" + laborTransSetA.getMbo(0).getString("laborcode"));
    	
    	//B. Get sum of regular hours of all labtrans of this labourcode with the conditions below:
	    //1. OT flag=1
	    //2. start date is not in this month(before the first day of this month)
	    //3. finish date is in this month(equal to/after first day of this month & before first Date of next month)
		MboSetRemote laborTransSetB = MXServer.getMXServer().getMboSet("LABTRANS", localLabTrans.getUserInfo());
		laborTransSetB.setFlag(MboConstants.DISCARDABLE, true);
		

		/*
    	 * 03-09-2020
    	 * <START> - Code below has been commented as part of the DB migration from Oracle to SQL 
    	 
		SqlFormat sqlformatLabB = new SqlFormat(localLabTrans.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE<trunc(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1) and FINISHDATE>=trunc(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1) and FINISHDATE<trunc(LAST_DAY(SYSDATE)+1)");
		*
		*/
		
		SqlFormat sqlformatLabB = new SqlFormat(localLabTrans.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE<dateadd(day,1,EOMONTH(getdate(),-1)) and FINISHDATE>=dateadd(day,1,EOMONTH(getdate(),-1)) and FINISHDATE<dateadd(day,1,EOMONTH(getdate()))");
		
		/*
		 *  03-09-2020 : BCT modification ends here (Oracle to SQL conversion)
		 *  <END>	    	
		 */
		
		sqlformatLabB.setObject(1, "LABTRANS", "LABORCODE", localLabTrans.getString("laborcode"));
    	sqlformatLabB.setObject(2, "LABTRANS", "PSA_OT_FLAG", "1");
    	laborTransSetB.setWhere(sqlformatLabB.format());
    	
    	//System.out.println("-laborTransSetB-" + laborTransSetB.getMbo(0).getString("laborcode"));
    	
    	//Get the Regular hours in B based on the startdate as the first date of the month at 0000hours
	    //Get First Date of this month
	    Calendar calThisMth = Calendar.getInstance();
		calThisMth.set(Calendar.DATE, 1);
		//set time component of calThisMth to zero
		calThisMth.set(Calendar.HOUR_OF_DAY, 0);
        calThisMth.set(Calendar.MINUTE, 0);
        calThisMth.set(Calendar.SECOND, 0);
        calThisMth.set(Calendar.MILLISECOND,0);
		Date thisMthFirstDate = calThisMth.getTime();
		
		//System.out.println("-thisMthFirstDate-" + thisMthFirstDate.toString());
		//System.out.println("-thisMthFirstDate in hours-" + thisMthFirstDate.getHours());
		//System.out.println("-thisMthFirstDate in min-" + thisMthFirstDate.getMinutes());
		//System.out.println("-thisMthFirstDate in sec-" + thisMthFirstDate.getSeconds());
    	
    	//Loop through MboSet B to get hours based on startdate as the first date of the month at 0000hours
		LabTransCustomRemote labtrans;
		
		//for (MboRemote wo = null; (wo = woset.getMbo(i)) != null; i ++)
		
    	for (int i = 0; (labtrans = (LabTransCustomRemote)laborTransSetB.getMbo(i)) != null; i++)
     	{
	     	labtrans.checkDates();
	     	Date dtFinish = labtrans.validateDateTime(labtrans.getDate("finishdate"), labtrans.getDate("finishtime"));
    		Date dtStart = labtrans.validateDateTime(thisMthFirstDate, thisMthFirstDate);
	     	
 			//System.out.println("-dtStart-" + dtStart.toString());
			//System.out.println("-dtStart in hours-" + dtStart.getHours());
			//System.out.println("-dtStart in min-" + dtStart.getMinutes());
			//System.out.println("-dtStart in sec-" + dtStart.getSeconds());
			//System.out.println("-dtFinish-" + dtFinish.toString());
			//System.out.println("-dtFinish in hours-" + dtFinish.getHours());
			//System.out.println("-dtFinish in min-" + dtFinish.getMinutes());
			//System.out.println("-dtFinish in sec-" + dtFinish.getSeconds());

	     	if ((dtFinish != null) && (dtStart != null))
		    {
		      laborMtdOTHrs = laborMtdOTHrs + (dtFinish.getTime() - dtStart.getTime()) / 3600000.0D;
		    }
	     	
	    }
	    
	    //System.out.println("-laborMtdOTHrs before A+B-" + laborMtdOTHrs);
    	
    	//Add the regular hours from A and B
    	laborMtdOTHrs = laborMtdOTHrs + laborTransSetA.sum("REGULARHRS");
    	
    	//System.out.println("-laborMtdOTHrs after A+B-" + laborMtdOTHrs);
    }

    //Set value to non persistent field laborMtdOTHrs
    laborMtdOTHrsTotal.setValue(laborMtdOTHrs, 11L);
  }
}