/*
 * Modification history
 
 * 29-07-2013--4.1.1-  Enhance Work Order Tracking Application to enable users to create follow up work orders across multiple sites.
 *   
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.FldWOSiteId;
import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldSiteIDCust extends FldWOSiteId
{

	public FldSiteIDCust(MboValue mbv) throws MXException 
	{
		super(mbv);
		// TODO Auto-generated constructor stub
	}
	
	 public void action()throws MXException, RemoteException
	 {
		 System.out.println("Inside SiteID Action");
		 super.action();
		 if(!getMboValue().isNull())
		 {
		     Mbo woMbo = getMboValue().getMbo();
		     if(woMbo.isNew())
		     {
		    	 System.out.println("Inside SiteID Action Mbo is New");
			     if(!woMbo.isNull("ORIGRECORDID"))
			     {
			    	 System.out.println("Inside SiteID Action Originating Record Is Not NULL");
			    	 String origrecord = woMbo.getString("ORIGRECORDID");
			    	 String origrecordclass = woMbo.getString("ORIGRECORDCLASS");
			    	 woMbo.setValueNull("ORIGRECORDID",MboConstants.NOVALIDATION_AND_NOACTION);
			    	 woMbo.setValueNull("ORIGRECORDCLASS",MboConstants.NOVALIDATION_AND_NOACTION);
			    	 woMbo.setValue("ORIGRECORDCLASS", origrecordclass); 
			    	 woMbo.setValue("ORIGRECORDID", origrecord);
			    	 
			     }
		     }
		 }
	 }

}
