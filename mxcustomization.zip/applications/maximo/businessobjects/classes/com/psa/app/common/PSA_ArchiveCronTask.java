package com.psa.app.common;


import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import psdi.app.system.CrontaskParamInfo;
import psdi.iface.mic.MicUtil;
import psdi.mbo.DBShortcut;
import psdi.mbo.MboSetRemote;
import psdi.security.ConnectionKey;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;

public class PSA_ArchiveCronTask extends SimpleCronTask {
	private boolean ready;
	private MXLogger logger;
	private MXServer server;
	private UserInfo userInfo;
	private String email;

	public PSA_ArchiveCronTask() {
		ready = false;
		logger = getCronTaskLogger();
	}

	public CrontaskParamInfo[] getParameters() throws MXException,RemoteException
	{
		CrontaskParamInfo params[] = new CrontaskParamInfo[23];
		params[0] = new CrontaskParamInfo();
		params[0].setName("BASEQUERY_WO_TRANS");
		params[0].setDefault(" t0.STATUS in  (''CLOSE'',''CAN'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[1] = new CrontaskParamInfo();
		params[1].setName("BASEQUERY_PR_TRANS");
		params[1].setDefault(" t0.STATUS IN (''CLOSE'',''CAN'') AND NOT EXISTS (SELECT 1 FROM PO po,POLINE pol,PRLINE prl WHERE po.Ponum = pol.ponum and   pol.ponum = prl.ponum and pol.polinenum = prl.polinenum and   prl.prnum = t0.prnum and   po.status IN (''CLOSE'',''CAN'')) AND NOT  EXISTS (SELECT 1 FROM RFQ rfq,RFQLINE rfql,PRLINE prl  WHERE rfq.rfqnum = rfql.rfqnum and   rfql.rfqnum = prl.rfqnum and rfql.rfqlinenum = prl.rfqlinenum and   prl.prnum = t0.prnum and rfq.status IN (''CLOSE'',''CAN'')) AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[2] = new CrontaskParamInfo();
		params[2].setName("BASEQUERY_ASSET_STATIC");
		params[2].setDefault(" not exists (select 1 from workorder wo where wo.siteid = t0.siteid and wo.assetnum = t0.assetnum) and not exists (select 1 from asset a1 where a1.assetnum = t0.assetnum and a1.status not in (''DECOMMISSIONED'')) and t0.STATUS in  (''DECOMMISSIONED'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[3] = new CrontaskParamInfo();
		params[3].setName("BASEQUERY_LOCATION_STATIC");
		params[3].setDefault(" not exists (select 1 from workorder wo where wo.siteid = t0.siteid and wo.location = t0.location) and not exists (select 1 from locations a1 where a1.location = t0.location and a1.status not in (''DECOMMISSIONED'')) and t0.STATUS in  (''DECOMMISSIONED'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[4] = new CrontaskParamInfo();
		params[4].setName("BASEQUERY_ITEM_STATIC");
		params[4].setDefault(" t0.STATUS in  (''OBSOLETE'') AND NOT EXISTS (SELECT 1 FROM PRLINE pr WHERE pr.itemnum = t0.itemnum) AND NOT EXISTS (SELECT 1 FROM MATUSETRANS mt where mt.itemnum = t0.itemnum) AND NOT EXISTS (SELECT 1 FROM MATRECTRANS mr where mr.itemnum = t0.itemnum) AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[5] = new CrontaskParamInfo();
		params[5].setName("BASEQUERY_CONTRACT_STATIC");
		params[5].setDefault(" t0.STATUS in  (''EXPIRD'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[6] = new CrontaskParamInfo();
		params[6].setName("BASEQUERY_EXCHANGE_STATIC");
		params[6].setDefault(" TRUNC(t0.EXPIREDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[7] = new CrontaskParamInfo();
		params[7].setName("BASEQUERY_FINCNTRL_STATIC");
		params[7].setDefault(" t0.FCSTATUS in  (''CLOSED'') AND TRUNC(t0.CHANGEDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[8] = new CrontaskParamInfo();
		params[8].setName("BASEQUERY_PERSON_STATIC");
		params[8].setDefault(" t0.STATUS in  (''INACTIVE'') AND NOT EXISTS (SELECT 1 FROM MAXUSER mx WHERE mx.USERID = t0.PERSONID and mx.status=''ACTIVE'') AND NOT EXISTS (SELECT 1 FROM LABOR lb WHERE lb.laborcode = t0.PERSONID and lb.status= ''ACTIVE'') AND NOT EXISTS (SELECT 1 FROM LABTRANS lt WHERE lt.laborcode = t0.personid) AND TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-24)");
		params[9] = new CrontaskParamInfo();
		params[9].setName("BASEQUERY_DOCUMENT_STATIC");
		params[9].setDefault("");
		
		params[10] = new CrontaskParamInfo();
		params[10].setName("WO_TRANS_ARCHQUERY");
		params[10].setDefault(" t0.STATUS in  (''CLOSE'',''CAN'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-60)");
		
		params[11] = new CrontaskParamInfo();
		params[11].setName("PR_TRANS_ARCHQUERY");
		params[11].setDefault(" t0.STATUS IN (''CLOSE'',''CAN'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-60)");
		params[12] = new CrontaskParamInfo();
		params[12].setName("ASSET_STATIC_ARCHQUERY");
		params[12].setDefault(" and t0.STATUS in  (''DECOMMISSIONED'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-60)");
		params[13] = new CrontaskParamInfo();
		params[13].setName("LOCATION_STATIC_ARCHQUERY");
		params[13].setDefault(" t0.STATUS in  (''DECOMMISSIONED'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-60)");
		params[14] = new CrontaskParamInfo();
		params[14].setName("ITEM_STATIC_ARCHQUERY");
		params[14].setDefault(" t0.STATUS in  (''OBSOLETE'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-60)");
		params[15] = new CrontaskParamInfo();
		params[15].setName("CONTRACT_STATIC_ARCHQUERY");
		params[15].setDefault(" t0.STATUS in  (''EXPIRD'') AND  TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-60)");
		params[16] = new CrontaskParamInfo();
		params[16].setName("EXCHANGE_STATIC_ARCHQUERY");
		params[16].setDefault(" TRUNC(t0.EXPIREDATE) < ADD_MONTHS(SYSDATE,-60)");
		params[17] = new CrontaskParamInfo();
		params[17].setName("FINCNTRL_STATIC_ARCHQUERY");
		params[17].setDefault(" t0.FCSTATUS in (''CLOSED'') AND TRUNC(t0.CHANGEDATE) < ADD_MONTHS(SYSDATE,-60)");
		params[18] = new CrontaskParamInfo();
		params[18].setName("PERSON_STATIC_ARCHQUERY");
		params[18].setDefault(" t0.STATUS in  (''INACTIVE'') AND TRUNC(t0.STATUSDATE) < ADD_MONTHS(SYSDATE,-60)");
		params[19] = new CrontaskParamInfo();
		params[19].setName("DOCUMENT_STATIC_ARCHQUERY");
		params[19].setDefault("");
		
		params[20] = new CrontaskParamInfo();
		params[20].setName("ARCH_PRINT_ONLY");
		params[20].setDefault("0");
		
		params[21] = new CrontaskParamInfo();
		params[21].setName("ARCH_DEBUG_ONLY");
		params[21].setDefault("1");
		
		params[22] = new CrontaskParamInfo();
		params[22].setName("ARCH_DELETE");
		params[22].setDefault("NO");
		
		
		
		return params;	

	}
	
	public void start() {
		try {
			readConfig();
			ready = true;
		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				logger.error("Unable to start cron task");
				logger.error(e);
			}
		}
	}


	void readConfig() throws Exception {
		server = MXServer.getMXServer();
		userInfo = getRunasUserInfo();
		email = server.getConfig().getProperty("mxe.adminEmail", null);
	}

	@Override
	public void cronAction() {
		try {
			
			
			//COMM-IT Changes starts.
			//*****************Update Base query and archival query from UI to database*****************
			 logger.debug("Inside Data Archiave-->>Cron logic Starts #####################");
			 String woTrans = getParamAsString("BASEQUERY_WO_TRANS");
			 String prTrans = getParamAsString("BASEQUERY_PR_TRANS");
			 String assetTrans = getParamAsString("BASEQUERY_ASSET_STATIC");
			 String locationTrans = getParamAsString("BASEQUERY_LOCATION_STATIC");
			 String itemTrans = getParamAsString("BASEQUERY_ITEM_STATIC");
			 String contractTrans = getParamAsString("BASEQUERY_CONTRACT_STATIC");
			 String exchangeTrans = getParamAsString("BASEQUERY_EXCHANGE_STATIC");
			 String finTrans = getParamAsString("BASEQUERY_FINCNTRL_STATIC");
			 String personTrans = getParamAsString("BASEQUERY_PERSON_STATIC");
			 String docTrans = getParamAsString("BASEQUERY_DOCUMENT_STATIC");
			 
			 String woTransArch = getParamAsString("WO_TRANS_ARCHQUERY");
			 String prTransArch = getParamAsString("PR_TRANS_ARCHQUERY");
			 String assetTransArch = getParamAsString("ASSET_STATIC_ARCHQUERY");
			 String locationTransArch = getParamAsString("LOCATION_STATIC_ARCHQUERY");
			 String itemTransArch = getParamAsString("ITEM_STATIC_ARCHQUERY");
			 String contractTransArch = getParamAsString("CONTRACT_STATIC_ARCHQUERY");
			 String exchangeTransArch = getParamAsString("EXCHANGE_STATIC_ARCHQUERY");
			 String finTransArch = getParamAsString("FINCNTRL_STATIC_ARCHQUERY");
			 String personTransArch = getParamAsString("PERSON_STATIC_ARCHQUERY");
			 String docTransArch = getParamAsString("DOCUMENT_STATIC_ARCHQUERY");
			 String printArch = getParamAsString("ARCH_PRINT_ONLY");
			 String debugArch = getParamAsString("ARCH_DEBUG_ONLY");
			 String deleteArch = getParamAsString("ARCH_DELETE");
			// String archDocumentation = getParamAsString("ARCH_DOCUMENT");
			 
			 logger.debug("Inside Data Archiave cron file woTrans###################"+woTrans);
			 logger.debug("Inside Data Archiave cron file prTrans###################"+prTrans);
			 logger.debug("Inside Data Archiave cron file assetTrans###################"+assetTrans);
			 logger.debug("Inside Data Archiave cron file locationTrans###################"+locationTrans);
			 logger.debug("Inside Data Archiave cron file itemTrans###################"+itemTrans);
			 logger.debug("Inside Data Archiave cron file contractTrans###################"+contractTrans);
			 logger.debug("Inside Data Archiave cron file exchangeTrans###################"+exchangeTrans);
			 logger.debug("Inside Data Archiave cron file finTrans###################"+finTrans);
			 logger.debug("Inside Data Archiave cron file personTrans###################"+personTrans);
			 logger.debug("Inside Data Archiave cron file ###################docTrans"+docTrans);
			 logger.debug("Inside Data Archiave cron file deleteArch###################"+deleteArch);
			 logger.debug("Inside Data Archiave cron file printArch###################"+printArch);
			 logger.debug("Inside Data Archiave cron file debugArch###################"+debugArch);
			 //logger.debug("Inside Data Archiave cron file archDocumentation###################"+archDocumentation);
			 
			/* if(archDocumentation!=null && archDocumentation.equalsIgnoreCase("YES")){
				//COMM-IT Changes starts.
					logger.debug("Inside Data Archiave --> Archieve documents starts###################");
					
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('LOCATIONS');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('PR');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('ITEM');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('RFQ');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('PO');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('WORKORDER');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('INVUSE');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('STOCKITEM');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('ASSET');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('INVENTORY');	end;"));
					logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('JOBPLAN');	end;"));
					
					logger.debug("Inside Data Archiave --> Archieve documents ends ###################");
					//COMM-IT Changes end
			 }*/

			 if(deleteArch!=null && deleteArch.equalsIgnoreCase("YES")){
				// delete old archive
				System.out.println("Inside Data Archiave-->> Delete Archieve table starts###################");
				logger.info("Result call PSAARCHIVE.archive_delete('WO_TRAN'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('WO_TRAN');	end;"));
				logger.info("Result call PSAARCHIVE.archive_delete('PR_TRAN'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('PR_TRAN');	end;"));
				logger.info("Result call PSAARCHIVE.archive_delete('ASSET_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('ASSET_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_delete('LOCATION_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('LOCATION_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_delete('ITEM_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('ITEM_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_delete('CONTRACT_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('CONTRACT_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_delete('EXCHANGE_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('EXCHANGE_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_delete('FINCNTRL_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('FINCNTRL_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_delete('PERSON_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_delete('PERSON_STATIC');	end;"));
				System.out.println("Inside Data Archiave-->> Delete Archieve table ends###################");
			}else{
				System.out.println("Inside Data Archiave-->> Delete Master table  starts###################");
				MXServer mxServer = MXServer.getMXServer();
				ConnectionKey conKey = mxServer.getSystemUserInfo().getConnectionKey();
				DBShortcut dbs = new DBShortcut();
				dbs.connect(conKey);
				String 	woTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+woTrans+"' WHERE ARCHIVETYPE = 'WO_TRAN'";
				String 	prTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+prTrans+"' WHERE ARCHIVETYPE = 'PR_TRAN'";
				String 	assetTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+assetTrans+"' WHERE ARCHIVETYPE = 'ASSET_STATIC'";
				String 	locationTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+locationTrans+"' WHERE ARCHIVETYPE = 'LOCATION_STATIC'";
				String 	itemTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+itemTrans+"' WHERE ARCHIVETYPE = 'ITEM_STATIC'";
				String 	contractTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+contractTrans+"' WHERE ARCHIVETYPE = 'CONTRACT_STATIC'";
				String 	exchangeTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+exchangeTrans+"' WHERE ARCHIVETYPE = 'EXCHANGE_STATIC'";
				String 	finTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+finTrans+"' WHERE ARCHIVETYPE = 'FINCNTRL_STATIC'";
				String 	personTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+personTrans+"' WHERE ARCHIVETYPE = 'PERSON_STATIC'";
				String 	docTransQuery = "UPDATE PSAARCHIVEPROP SET BASEQUERY='"+docTrans+"' WHERE ARCHIVETYPE = 'DOCUMENT_STATIC'";
				
				
				String 	woTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+woTransArch+"' WHERE ARCHIVETYPE = 'WO_TRAN'";
				String 	prTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+prTransArch+"' WHERE ARCHIVETYPE = 'PR_TRAN'";
				String 	assetTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+assetTransArch+"' WHERE ARCHIVETYPE = 'ASSET_STATIC'";
				String 	locationTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+locationTransArch+"' WHERE ARCHIVETYPE = 'LOCATION_STATIC'";
				String 	itemTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+itemTransArch+"' WHERE ARCHIVETYPE = 'ITEM_STATIC'";
				String 	contractTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+contractTransArch+"' WHERE ARCHIVETYPE = 'CONTRACT_STATIC'";
				String 	exchangeTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+exchangeTransArch+"' WHERE ARCHIVETYPE = 'EXCHANGE_STATIC'";
				String 	finTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+finTransArch+"' WHERE ARCHIVETYPE = 'FINCNTRL_STATIC'";
				String 	personTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+personTransArch+"' WHERE ARCHIVETYPE = 'PERSON_STATIC'";
				String 	docTransArchQuery = "UPDATE PSAARCHIVEPROP SET ARCHIVEQUERY='"+docTransArch+"' WHERE ARCHIVETYPE = 'DOCUMENT_STATIC'";
				
				String 	printArchQuery = "UPDATE PSAARCHIVEPROP SET PRINT_ONLY='"+printArch+"'";
				String 	debugArchQuery = "UPDATE PSAARCHIVEPROP SET DE_BUG='"+debugArch+"'";
				
				
				
				dbs.executeQuery(woTransQuery);	
				dbs.executeQuery(prTransQuery);	
				dbs.executeQuery(assetTransQuery);	
				dbs.executeQuery(locationTransQuery);	
				dbs.executeQuery(itemTransQuery);	
				dbs.executeQuery(contractTransQuery);	
				dbs.executeQuery(exchangeTransQuery);	
				dbs.executeQuery(finTransQuery);	
				dbs.executeQuery(personTransQuery);	
				dbs.executeQuery(docTransQuery);	
				
				dbs.executeQuery(woTransArchQuery);	
				dbs.executeQuery(prTransArchQuery);	
				dbs.executeQuery(assetTransArchQuery);	
				dbs.executeQuery(locationTransArchQuery);	
				dbs.executeQuery(itemTransArchQuery);	
				dbs.executeQuery(contractTransArchQuery);	
				dbs.executeQuery(exchangeTransArchQuery);	
				dbs.executeQuery(finTransArchQuery);	
				dbs.executeQuery(personTransArchQuery);	
				dbs.executeQuery(docTransArchQuery);
				
				dbs.executeQuery(printArchQuery);
				dbs.executeQuery(debugArchQuery);
				
				dbs.commit();
				dbs.close();
				System.out.println("after committed where class query  ###################");
				
				//COMM-IT Changes ends.
				
				logger.info("Result call PSAARCHIVE.validate_tables(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.validate_tables();	end;"));
				
				logger.info("Result call PSAARCHIVE.archive_main('WO_TRAN'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_main('WO_TRAN');	end;"));
				
				
				logger.info("Result call PSAARCHIVE.archive_main('PR_TRAN'): " + callOracleProcedure("begin		MAXIMO.PSAARCHIVE.archive_main('PR_TRAN');	end;"));
				
				
				logger.info("Result call PSAARCHIVE.archive_static('ASSET_STATIC'): " + callOracleProcedure("begin		MAXIMO.PSAARCHIVE.archive_static('ASSET_STATIC');	end;"));
			
				
				logger.info("Result call PSAARCHIVE.archive_static('LOCATION_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_static('LOCATION_STATIC');	end;"));
				
				
				logger.info("Result call PSAARCHIVE.archive_static('ITEM_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_static('ITEM_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_static('CONTRACT_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_static('CONTRACT_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_static('EXCHANGE_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_static('EXCHANGE_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_static('FINCNTRL_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_static('FINCNTRL_STATIC');	end;"));
				logger.info("Result call PSAARCHIVE.archive_static('PERSON_STATIC'): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_static('PERSON_STATIC');	end;"));
				
				logger.debug("Inside Data Archiave-->> Delete Master table  ends###################");
				
				logger.debug("Inside Data Archiave --> Archieve documents starts###################");
				
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('LOCATIONS');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('PR');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('ITEM');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('RFQ');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('PO');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('WORKORDER');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('INVUSE');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('STOCKITEM');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('ASSET');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('INVENTORY');	end;"));
				logger.info("Result call PSAARCHIVE.archive_document(): " + callOracleProcedure("begin	MAXIMO.PSAARCHIVE.archive_document('JOBPLAN');	end;"));
				
				System.out.println("Inside Data Archiave --> Archieve documents ends ###################");
			}
			 
			 System.out.println("Inside Data Archiave-->>Cron logic ends ###################");
			// doing archive first
		//	try{
			
		} catch (Exception e) {
			logger.error("SQL Error", e);
			e.printStackTrace();
		}
	}

	public int callOracleProcedure(String procName) throws MXException, RemoteException {
		int ret;

		logger.info("Calling " + procName);

		MXServer mxServer = MXServer.getMXServer();
		UserInfo userInfo = mxServer.getSystemUserInfo();
		Connection dbConnection = mxServer.getDBManager().getConnection(userInfo.getConnectionKey());

		try {
			//CallableStatement cs = dbConnection.prepareCall("{call " + procName + "}");
			CallableStatement cs = dbConnection.prepareCall(procName);
			ret = cs.executeUpdate();
		} catch (SQLException e) {
			logger.error("SQL Error", e);
			throw new MXApplicationException("Error in procedure " + procName, e.getMessage());
		} finally {
			mxServer.getDBManager().freeConnection(userInfo.getConnectionKey());
		}

		return ret;
	}

}
