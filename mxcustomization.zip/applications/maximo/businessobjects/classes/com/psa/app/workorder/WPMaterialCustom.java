/*
 * Modification history
 * 05-10-2007	AGD	SR-117	Populate store based on user default store
 * 29-02-2008   HAM SR-117  Made condition to return if pmnum is not null
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;

import com.psa.app.common.InventoryCommonCustom;

import psdi.app.workorder.WPMaterial;
import psdi.app.workorder.WPMaterialRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationYesNoCancelException;
import psdi.util.MXException;
import psdi.util.MXAccessException;

public class WPMaterialCustom extends WPMaterial
implements WPMaterialRemote
{

public WPMaterialCustom(MboSet wpmatset)
	throws MXException, RemoteException
{
super(wpmatset);
}

public void init()
	throws MXException
{
	super.init();
	try
	{
	/*System.out.println("-WC init--VERSION 1-");
	String maxLineType = getTranslator().toInternalString("linetype", getString("linetype"));

			if ((toBeAdded()) && (maxLineType.equalsIgnoreCase("ITEM")))
			return;   */
	/*if (maxLineType.equalsIgnoreCase("ITEM"))
			{
			setFieldFlag("conditioncode", 8L, true); 
			}
	else
	{
		setFieldFlag("conditioncode", 8L, false);
	}  */
		String loanid = getString("loanid");
	System.out.println("-loanid-"+loanid+"-length of loanid-" + loanid.length());
	if (loanid != null && loanid.length() > 0)
	{
		String[] arrayOfLoanString = { "ITEMQTY", "LOANID", "ITEMNUM", "LOCATION", "STORELOCSITE", "CONDITIONCODE", "UNITCOST" ,"DIRECTREQ","DONUM" };
		//String[] arrayOfLoanString2 = {"LOCATION", "STORELOCSITE", "CONDITIONCODE" };
		setFieldFlag(arrayOfLoanString, READONLY, true);
		//setFieldFlag(arrayOfLoanString2, 7, true);
	}

}
catch (Exception e)
	{
			if (getMboLogger().isDebugEnabled())
			getMboLogger().debug(e);
	}
}


/*
* Check if there's enough stock. If not, prompt the user whether he wants to change his mind or not
*/
public void checkQty(MboValue mbovalue)
	throws MXException, RemoteException
{
WPMaterialCustom wpmaterial = (WPMaterialCustom) mbovalue.getMbo();

// No check if the field is set during a background operation
if (!wpmaterial.getUserInfo().isInteractive())
	return;
//Begin Modification SR-117
if (!wpmaterial.getOwner().isNull("pmnum"))
	return;
//End Modification SR-117

// No check possible if item, store, condition code and qty are not all populated
if (wpmaterial.isNull("itemnum") || wpmaterial.isNull("location") || wpmaterial.isNull("conditioncode") || wpmaterial.isNull("itemqty"))
	return;

// If not enough stock, prompt user whether he wants to proceed or not
double balance = InventoryCommonCustom.getBalance(wpmaterial.getString("itemnum"), wpmaterial.getString("location"),
		wpmaterial.getString("storelocsite"), wpmaterial.getString("conditioncode"), wpmaterial.getUserInfo());
if (balance < wpmaterial.getDouble("itemqty"))
	if (!wpmaterial.proceedWithoutStock(getString("location")))
		mbovalue.setValueNull();
}


/*
* Prompt user to check whether he wants to proceed without enough stock
*/
private boolean proceedWithoutStock(String store)
	throws RemoteException, MXException
{
boolean proceed = false;

int userInput = MXApplicationYesNoCancelException.getUserInput("continueWithoutStock", MXServer.getMXServer(), getUserInfo());
switch (userInput) {
case MXApplicationYesNoCancelException.NULL:
	Object param[] = { store, buildBalanceMsg() };
	throw new MXApplicationYesNoCancelException("continueWithoutStock", "workorder", "NotEnoughStock", param);

case MXApplicationYesNoCancelException.YES:
	proceed = true;
	break;

case MXApplicationYesNoCancelException.NO:
	proceed = false;
	break;
}

return proceed;
}


/*
* Builds the message to display to the user, showing an item balance in all the main stores,
* given a certain condition code
*/
private String buildBalanceMsg()
	throws RemoteException, MXException
{
String message = "";

// Get the list of inventory records in main stores in the site
MboSetRemote inventoryset = MXServer.getMXServer().getMboSet("INVENTORY", getUserInfo());
SqlFormat sqlformat = new SqlFormat("itemnum=:1 AND siteid=:2 AND location LIKE '%STORE'");
sqlformat.setObject(1, "inventory", "itemnum", getString("itemnum"));
sqlformat.setObject(2, "inventory", "siteid", getString("storelocsite"));
inventoryset.setWhere(sqlformat.format());
inventoryset.setOrderBy("location ASC");

// Get the stock balance in each of these stores and build the message
MboRemote inventory = null;
for (int i = 0; (inventory = inventoryset.getMbo(i)) != null; i++)
	message += inventory.getString("location") + "\t" + InventoryCommonCustom.getBalance(inventory, getString("conditioncode")) + "\n";

return message;
}

public void canDelete()
throws MXException
{
try
{
if (!(getMboSet("MATUSETRANS").isEmpty()))
throw new MXAccessException("workorder", "deletewpmaterial");
MboSetRemote loandeleteSetMbo= getMboSet("LOANDELETE");
MboRemote loandeleteMbo = null;
int index = 0;
while ((loandeleteMbo = loandeleteSetMbo.getMbo(index)) != null)
{
	loandeleteMbo.setValueNull("REFWO",2L);
	//loandeleteSetMbo.save();
	++index;
}

super.canDelete();
//loandeleteSetMbo.save();
//getMboSet("LOANUNDELETE").save();
}
catch (RemoteException localRemoteException)
{
if (getMboLogger().isDebugEnabled())
getMboLogger().debug(localRemoteException);

}


}

public void undelete()
throws MXException, RemoteException
{
super.undelete();
String wonum = getString("WONUM");
MboRemote loandeleteMbo1 = null;
int index = 0;
MboSetRemote loandeleteSetMbo1= getMboSet("LOANDELETE");
while ((loandeleteMbo1 = loandeleteSetMbo1.getMbo(index)) != null)
{
	/*MboRemote loandeleteMbo= getMboSet("LOANUNDELETE").getMbo(0);
	if (loandeleteMbo != null)
	{*/
loandeleteMbo1.setValue("REFWO",wonum, 11L);
//loandeleteSetMbo1.save();
	++index;
}
//loandeleteSetMbo1.save();
//getMboSet("LOANDELETE").save();

}

}
