/*
 * Modification history
 * 04-05-2007	AGD	SR-030	Common methods applicable to financial transactions
 */
package com.psa.app.common;

import java.rmi.RemoteException;
import java.util.Date;

import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FinancialTransaction extends Mbo
{

	public FinancialTransaction(MboSet mboset)
			throws MXException, RemoteException
	{
		super(mboset);
	}


	/*
	 * Validate that the project used in the transaction is valid :
	 * 	- remaining amt >= linecost
	 * 	- transaction date within project dates
	 */
	public void validateProject(MboRemote transaction, String relationship)
			throws MXException, RemoteException
	{
		MboRemote wo = transaction.getMboSet(relationship).getMbo(0);
		if (wo == null)
			return;
		MboRemote projecttask = wo.getMboSet("FINCNTRL").getMbo(0);
		if (projecttask != null)
		{
			// Get the project mbo (we don't know if we're currently looking at a project or a task)
			MboRemote project = projecttask;
			if (!projecttask.isNull("taskid"))	// We got a project task --> need to get the project
				project = projecttask.getMboSet("PROJECT").getMbo(0);

/* Commented because OPA does not maintain the remaining amount so budget control has no meaning
 			// Budget control
			double remainingcost = project.getDouble("remainingcost");
			if (transaction.getDouble("linecost") > remainingcost)
			{
				String param[] = { transaction.getString("linecost"), "" + remainingcost };
				throw new MXApplicationException("financial", "projectbudgetexceeded", param);
			}
*/
			// Dates control
			Date date = MXServer.getMXServer().getDate();
			if (date.before(project.getDate("startdate")) || date.after(project.getDate("enddate")))
				throw new MXApplicationException("financial", "projectdatesnotvalidvstransdate");
		}
	}

}


