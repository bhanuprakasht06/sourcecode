/*
 * Modification history
 
 * 29-07-2013--4.1.1-  Enhance Work Order Tracking Application to enable users to create follow up work orders across multiple sites.
 *   
 */

package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.common.TicketWOUtility;
import psdi.app.workorder.FldWOOrigRecordId;
import psdi.app.workorder.WO;
import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldCustOrigRecordID extends FldWOOrigRecordId
	{

		public FldCustOrigRecordID(MboValue mbv) throws MXException {
			super(mbv);
			// TODO Auto-generated constructor stub
		}
		
		  public void validate()
	      throws MXException, RemoteException
	  {
		  System.out.println("###IN Class FldCustOrigRecordID Method Validate ()ANURAGG###");
	      Mbo record = getMboValue().getMbo();
	      System.out.println("### M Here setting Originating Record Class ###");
	      record.setValue("ORIGRECORDCLASS", record.getString("ORIGRECORDCUST.WOCLASS"));
	      
	      System.out.println("### M Here after setting Originating Record Class ###"+record.getString("ORIGRECORDID")+"#####"+record.getString("ORIGRECORDCLASS"));
	      if(record.isNull("ORIGRECORDID") || record.isNull("ORIGRECORDCLASS"))
	      {
	    	  System.out.println("###IN Class FldCustOrigRecordID Originators Record ID or Class is Null###");
	          return;
	      }
	      if(record.isBasedOn("WORKORDER") && record.getString("ORIGRECORDID").equals(record.getString("WONUM")) && record.getString("ORIGRECORDCLASS").equals(record.getString("WOCLASS")))
	      {
	    	  
	          Object param[] = 
	          {
	              record.getString("ORIGRECORDID"), record.getString("ORIGRECORDCLASS")
	          };
	          throw new MXApplicationException("ticket", "NotValidOrgRecord", param);
	      }
	      if(record.isBasedOn("TICKET") && record.getString("ORIGRECORDID").equals(record.getString("TICKETID")) && record.getString("ORIGRECORDCLASS").equals(record.getString("CLASS")))
	      {
	          Object param[] = {
	              record.getString("ORIGRECORDID"), record.getString("ORIGRECORDCLASS")
	          };
	          throw new MXApplicationException("ticket", "NotValidOrgRecord", param);
	      }
	      ((WO)record).CheckOrigIsFollowup();
	      
	      System.out.println("###IN Class FldCustOrigRecordID Method Validate () Break Point 1###");
	      		if(record.isNull("ORIGRECORDCLASS"))
	      		record.setValue("ORIGRECORDCHECK", "WORKORDER",MboConstants.NOVALIDATION_AND_NOACTION);
	      if(TicketWOUtility.getInternalWorkOrderClass(record, record.getString("ORIGRECORDCLASS")) != null)
	      {
	          MboSetRemote orgRecSet = record.getMboSet("$WOSET", "WORKORDER", "wonum = :origrecordid and woclass = :origrecordclass");
	          origsiteid=orgRecSet.getMbo(0).getString("SITEID");
	          System.out.println("###IN Class FldCustOrigRecordID Getting Site ID in ORGSITED VARIABLE###");
	          if(orgRecSet.isEmpty())
	          {
	              Object param[] = {
	                  record.getString("ORIGRECORDID"), record.getString("ORIGRECORDCLASS")
	              };
	              throw new MXApplicationException("ticket", "NotValidOrgRecord", param);
	          }
	      } else
	      {
	          MboSetRemote orgRecSet = record.getMboSet("$TICKETSET", "TICKET", "ticketid = :origrecordid and class = :origrecordclass");
	          if(orgRecSet.isEmpty())
	          {
	              Object param[] = {
	                  record.getString("ORIGRECORDID"), record.getString("ORIGRECORDCLASS")
	              };
	              throw new MXApplicationException("ticket", "NotValidOrgRecord", param);
	          }
	      }
	 }

		  public MboSetRemote getList()
	      throws MXException, RemoteException
	  {
	      setup();
	      Mbo record = getMboValue().getMbo();
	      System.out.println("###Entering Class FldCustOrigRecordID Method GetLIST ()###");
	      if(record.isZombie() || record.isNull("ORIGRECORDCLASS"))
	          return record.getMboSet("myWvSet", "WORKVIEW");
	      if(TicketWOUtility.getInternalTicketClass(record, record.getString("ORIGRECORDCLASS")) != null)
	          if(record.isBasedOn("TICKET"))
	              return record.getMboSet("myTkSet", "TICKET", "class = :origrecordclass and not (ticketid = :ticketid and class = :class)");
	          else
	              return record.getMboSet("myTkSet", "TICKET", "class = :origrecordclass");
	      if(record.isBasedOn("WORKORDER"))
	          return record.getMboSet("myWoSet", "WORKORDER", "woclass = :origrecordclass and not (wonum = :wonum and woclass = :woclass and siteid = :siteid)");
	      if(!record.isNull("siteid"))
	          return record.getMboSet("myWoSet", "WORKORDER", "woclass = :origrecordclass");
	      else
	          return record.getMboSet("myWoSet", "WORKORDER", "woclass = :origrecordclass");
	  }

		  
		

	  
	   protected void setup()
       throws MXException, RemoteException
   {
       MboValue value = getMboValue();
       Mbo record = value.getMbo();
       if(!record.isZombie() && !record.isNull("origrecordclass"))
       {
           String ticketClass = TicketWOUtility.getInternalTicketClass(record, record.getString("ORIGRECORDCLASS"));
           if(ticketClass != null)
           {
               setRelationship(ticketClass, "1=1");
               value.getMboValueInfo().setSameAsObject("TICKET");
               value.getMboValueInfo().setSameAsAttribute("TICKETID");
               setLookupKeyMapInOrder(new String[] {
                   "ORIGRECORDID", "ORIGRECORDCLASS"
               }, new String[] {
                   "TICKETID", "CLASS"
               });
           } else
           {
               String woClass = TicketWOUtility.getInternalWorkOrderClass(record, record.getString("ORIGRECORDCLASS"));
               if(woClass.equals("ACTIVITY"))
                   setRelationship("WOACTIVITY", "1=1");
               if(woClass.equals("RELEASE"))
                   setRelationship("WORELEASE", "1=1");
               if(woClass.equals("CHANGE"))
                   setRelationship("WOCHANGE", "1=1");
               else
                   setRelationship("WORKORDER", "1=1");
               value.getMboValueInfo().setSameAsObject("WORKORDER");
               value.getMboValueInfo().setSameAsAttribute("WONUM");
               setLookupKeyMapInOrder(new String[] {
                    "ORIGRECORDID", "ORIGRECORDCLASS"
               }, new String[] {
                    "WONUM", "WOCLASS"
               });
           }
       } else
       {
           setRelationship("WORKVIEW", "1=1");
           value.getMboValueInfo().setSameAsObject("WORKVIEW");
           value.getMboValueInfo().setSameAsAttribute("RECORDKEY");
           setLookupKeyMapInOrder(new String[] {
                "ORIGRECORDID", "ORIGRECORDCLASS"
           }, new String[] {
                "RECORDKEY", "CLASS"
           });
       }
   }
	   

	   public void action()
       throws MXException, RemoteException
   {
	    System.out.println("###Entering Class FldCustOrigRecordID Method Action()###");
       Mbo wo = getMboValue().getMbo();
       if(!wo.isNull("SITEID"))
       ((WOCustom)wo).updateOriginator(origsiteid);
   }
	    String origsiteid=null;
}
	

