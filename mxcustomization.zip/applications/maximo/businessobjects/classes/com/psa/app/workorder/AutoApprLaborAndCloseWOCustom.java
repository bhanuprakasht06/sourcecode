package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.labor.LabTransRemote;
import psdi.app.workorder.WORemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class AutoApprLaborAndCloseWOCustom
		implements ActionCustomClass
{

	
	private static final MXLogger mxLogger = MXLoggerFactory.getLogger("maximo.application.WORKORDER");
	/*
	 * Constructor - does nothing
	 */
	public AutoApprLaborAndCloseWOCustom()
	{
	}


	/*
	 * Approve all unapproved labor reports
	 */
	public void applyCustomAction(MboRemote woremote, Object aobj[])
			throws MXException, RemoteException
	{
		mxLogger.debug("AutoApprLaborCustom - Entering");
		
		MboSetRemote mboSet = null;
		MboRemote mboRemote = null;
		MboSetRemote mboStatusSet = null;
		MboRemote mboStatusRemote = null;
		LabTransRemote labtrans;
		WORemote wo;
		
		int i;
		
		mboSet = woremote.getMboSet("LABTRANS");
		
		for(i = 0; (mboRemote = mboSet.getMbo(i)) != null; i++)
		{
			if(!mboRemote.getBoolean("GENAPPRSERVRECEIPT"))
			{
				if(mboRemote instanceof LabTransRemote)
				{
					System.out.println("-------it is valid instance");
					labtrans = (LabTransRemote) mboRemote;
					labtrans.approveLaborTransaction();	
				}				
			}
		}
		
		System.out.println("***AutoApprLaborAndCloseWOCustom b: B4 Change status");
		/*
		wo  = (WORemote) woremote;
		System.out.println("***AutoApprLaborAndCloseWOCustom: wonum:"+wo.getString("wonum"));
		wo.changeStatus("CLOSE", MXServer.getMXServer().getDate(), "", MboConstants.NOACCESSCHECK);
		wo.getThisMboSet().save();
		System.out.println("***AutoApprLaborAndCloseWOCustom a: Aft Change status");
		*/
		
		woremote.setValue("HISTORYFLAG", true, 2L);
		woremote.setValue("STATUS", "CLOSE", 2L);
		woremote.getThisMboSet().save();
		mboStatusSet = woremote.getMboSet("WOSTATUS");
		mboStatusRemote = mboStatusSet.add(2L);
		mboStatusRemote.setValue("STATUS", "CLOSE", 2L);
		mboStatusRemote.setValue("CHANGEBY", woremote.getUserName(), 2L);
		mboStatusRemote.setValue("CHANGEDATE", MXServer.getMXServer().getDate(), 2L);
		mboStatusRemote.setValue("GLACCOUNT", woremote.getString("GLACCOUNT"), 2L);			
		
		woremote.getThisMboSet().save();
		
		
		mxLogger.debug("AutoApprLaborCustom - Leaving");
	}

	
}
