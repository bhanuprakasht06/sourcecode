/*
 * Modification history
 * 30-06-08	HAM	Creation
 */

package com.psa.app.rfq;

import java.rmi.RemoteException;

import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.CrossOverDomain;
import psdi.mbo.Mbo;
import psdi.mbo.MboValue;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldFaxBriefRFQCustom extends CrossOverDomain
{

	public FldFaxBriefRFQCustom(MboValue mbovalue)
    throws MXException, RemoteException
	{
		super(mbovalue);
	}

	public void action() throws MXException, RemoteException
    {
       
	}
	
	 public void validate()
     throws MXException, RemoteException
     {
		 Mbo mbo = getMboValue().getMbo();
		 String appn=mbo.getName();
		 if(mbo.getBoolean("FAXBRIEFRFQ"))
		 {
			Object param[] = {"Fax"}; 
			if(appn.equals("RFQVENDOR"))
				if (mbo.isNull("FAXPHONE"))
		             throw new MXApplicationException("system", "null",param);
			if(mbo.getBoolean("FAXRFQ"))
				mbo.setValue("FAXRFQ",false,MboConstantsCustom.DBSET);
		 }
     }
}
