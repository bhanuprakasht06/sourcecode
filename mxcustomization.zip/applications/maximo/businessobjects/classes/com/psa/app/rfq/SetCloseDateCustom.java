/*
 * Modification history
 * 08-07-08	HAM	Creation
 */
package com.psa.app.rfq;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import psdi.common.action.ActionCustomClass;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboRemote;
import psdi.server.MXServer;
import psdi.util.MXException;


public class SetCloseDateCustom
implements ActionCustomClass
{

public SetCloseDateCustom()
{
}


public void applyCustomAction(MboRemote mboremote, Object param[])
	throws MXException, RemoteException
{	
//Set the Deadline to current date + Opening Duration 
GregorianCalendar deadline = new GregorianCalendar();
deadline.setGregorianChange(MXServer.getMXServer().getDate());
deadline.add(Calendar.DATE, mboremote.getInt("OPENDURATION"));
mboremote.setValue("CLOSEONDATE",deadline.getTime(),MboConstantsCustom.DBSET);
mboremote.getThisMboSet().save();
}


}
