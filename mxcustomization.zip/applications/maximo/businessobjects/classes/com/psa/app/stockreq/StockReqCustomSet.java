/*
 * Modification history
 * 27-05-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.*;
import psdi.mbo.*;
import psdi.util.*;
import psdi.mbo.custapp.*;

public class  StockReqCustomSet extends CustomMboSet 
	implements StockReqCustomSetRemote 
{
	public StockReqCustomSet (MboServerInterface mboserverinterface) 
		throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}

	protected Mbo getMboInstance(MboSet mboset) 
		throws MXException, RemoteException
	{
		return (new StockReqCustom(mboset));
	}
}
