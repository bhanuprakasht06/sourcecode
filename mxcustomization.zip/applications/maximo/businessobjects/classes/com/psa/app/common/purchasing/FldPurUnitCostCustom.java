/*
 * Modification history
 * 04-04-2013	WMJ		EMS-568	[RFQ]To default the unit cost of quotation lines to zero so that buyers do not have to amend quotes if an eRFQ vendor selects a RFQ line for quotation but did not enter any value  
 */
package com.psa.app.common.purchasing;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboValue;
import psdi.app.common.purchasing.FldPurUnitCost;
import psdi.util.MXException;

//Start of EMS-568
import com.psa.app.rfq.QuotationAltCustomRemote;
import com.psa.app.rfq.QuotationLineCustomRemote;
//End of EMS-568

import psdi.app.po.POLineRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXMath;

/**
 * @author		LS
 * @class		FldPurUnitCostCustom
 * @date		Mar 19, 2007
 * @function	Update Total Quotation Amount and Total Awarded Amount of RFQ Vendor
 */

public class FldPurUnitCostCustom extends FldPurUnitCost 
{
	public FldPurUnitCostCustom(MboValue mbv) 
	throws MXException, RemoteException 
	{
		super(mbv);
	}

	public void action() throws MXException, RemoteException
	{
	    //start of EMS-568
		try
		{
		//End of EMS-568	
		Mbo mbo = getMboValue().getMbo();
	    //Get RFQVendor Mbo
	    MboRemote rfqvendorremote = mbo.getOwner();
	    //System.out.println("[FldPurUnitCostCustom]quotationlineremote: " + rfqvendorremote);
	    if(rfqvendorremote == null)
	        return;
	    
	    double totalquo = 0.0D;
	    double prevuc = 0.0D;
	    double curuc = 0.0D;
	    double totalaward = 0.0D;
	    
	    //Get Total Quotation Amount
	    totalquo = rfqvendorremote.getDouble("totalquotationamt");
	//    System.out.println("[FldPurUnitCostCustom]orig totalquo: " + totalquo);
	    //Get Total Awarded Amount
	    totalaward = rfqvendorremote.getDouble("totalawardamt");
	//    System.out.println("[FldPurUnitCostCustom]totalaward: " + totalaward);
	
	    if(!getMboValue().getPreviousValue().isNull())
	    {
	    	//Get Previous Unit Cost
	    	prevuc = getMboValue().getPreviousValue().asDouble();
	    	//System.out.println("[FldPurUnitCostCustom]prevuc: " + prevuc);
	        if(!(mbo.isNull("orderqty") || mbo.getMboValue("orderqty").getPreviousValue().asDouble() == 0.0D))
	        {
	        	//Subtract line cost from total quotation amount
	        	totalquo = totalquo - (prevuc * mbo.getDouble("orderqty"));
	        	//System.out.println("[FldPurUnitCostCustom]less prev totalquo(not null or 0): " + totalquo);
	        	
	            if(mbo.getMboValue("isawarded").getBoolean())
	            {
	            	//Subtract line cost from total awarded amount
	            	totalaward = totalaward - (prevuc * mbo.getDouble("orderqty"));
	            	rfqvendorremote.setValue("totalawardamt", totalaward);
	            	//System.out.println("[FldPurUnitCostCustom]set totalawardamt: " + totalaward);
	            }
	        }
	    }
		
	    if(!getMboValue().isNull())
	    {
	    	//Get Current Unit Cost
	    	curuc = getMboValue().getDouble();
	       	//System.out.println("[FldPurUnitCostCustom]curuc: " + curuc);
	    }
	    if(!mbo.isNull("orderqty"))
	    {
	    	//Add line cost to total quotation amount
	    	totalquo = totalquo + (curuc * mbo.getDouble("orderqty"));
	    	//System.out.println("[FldPurUnitCostCustom]less prev totalquo(not null): " + totalquo);
	    }
	    if(mbo.getMboValue("isawarded").getBoolean())
	    {
	    	//Add line cost to total awarded amount
	    	totalaward = totalaward + (curuc * mbo.getDouble("orderqty"));
	    	rfqvendorremote.setValue("totalawardamt", totalaward);
	    	//System.out.println("[FldPurUnitCostCustom]set totalawardamt: " + totalaward);
	    }
	    
	    rfqvendorremote.setValue("totalquotationamt", totalquo);
	    //System.out.println("[FldPurUnitCostCustom]set totalquotationamt: " + totalquo);
	    
	    
	    super.action();
	    
		//start of EMS-568
		}
		catch (MXApplicationException mxe)
		{
			// Ignore errors "attribute doesn't exist" because super.linecost_class.action exits in the middle if the mbo is quotation
			if ((getMboValue().getMbo() instanceof QuotationAltCustomRemote || getMboValue().getMbo() instanceof QuotationLineCustomRemote)&&
					mxe.getErrorGroup().equalsIgnoreCase("system") && mxe.getErrorKey().equalsIgnoreCase("noattribute"))
				return;
			else
				throw mxe;
		}
	    //End of EMS-568
	    
	}
}
