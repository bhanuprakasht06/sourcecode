/*
 * Modification history 
 * 
 * 11-Nov-11 YCH Creation
 * 
 * This class is Data Bean to process OT transaction
 * 
 */
package com.psa.webclient.beans.workorder;

import java.rmi.RemoteException;

import com.psa.app.labor.LabTransCustomRemote;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;

public class ActualOTBean extends DataBean {
	
	public ActualOTBean()
	{		
	}
	
	/*
	 * Process the logic when user click New Row from OT Section of UI
	 * init PSA_OT_FLAG as 1 for OT Transaction 
	 * 
	 * @Date: 31 Oct 2011
	 * @throws MXException
	 * @throws RemoteException
	 */
    public int addOTRow() throws MXException, RemoteException
    {
    	int status = super.addrow();
    	
    	// set OT flag to the OT Transaction when create new row for OT
    	System.out.println("addOTRow() --> parent.getMbo()" + parent.getMbo().getClass().getName());
    	System.out.println("addOTRow() --> getMbo()" + getMbo().getClass().getName());
    	LabTransCustomRemote otremote = (LabTransCustomRemote) getMbo();
    	otremote.setOTFlag(true);
    	
    	return status;
    }    
    
    /*
	 * Process the logic when user click Copy from Labor Selection of UI
	 *  
	 * @Date: 31 Oct 2011
	 * @throws MXException
	 * @throws RemoteException
	 * 
	 * Revised 11 Nov 2011
	 */
    public int copyFromLabor() throws MXException, RemoteException
    {
		LabTransCustomRemote labtransremote = (LabTransCustomRemote) getMbo();
		labtransremote.copyLabTransToCurrentOT(getMboSet());
		parent.save();
		return 1;
	}
}
