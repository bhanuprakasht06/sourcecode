package com.psa.webclient.beans.ofdetails;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.SessionContext;
import psdi.webclient.system.controller.Utility;
import psdi.webclient.system.controller.WebClientEvent;
import psdi.webclient.system.session.WebClientSession;

public class OFDetailsBeanCustom extends DataBean {

	public OFDetailsBeanCustom() {
		// TODO Auto-generated constructor stub
	}

	public int editMatrectrans() throws RemoteException, MXException
	{
		String[][] datas=app.getDataBean("EDITMAT").getDataAsArray();
		processValues(datas);
		Utility.sendEvent(new WebClientEvent("dialogclose",app.getCurrentPageId(),null,this.sessionContext));
		return 1;
	}

	
	public int editServrectrans() throws RemoteException, MXException
	{
		String[][] datas=app.getDataBean("EDITSERV").getDataAsArray();
		processValues(datas);
		Utility.sendEvent(new WebClientEvent("dialogclose",app.getCurrentPageId(),null,this.sessionContext));
		return 1;
	}

	public int editInvtrans() throws RemoteException, MXException
	{
		String[][] datas=app.getDataBean("EDITINV").getDataAsArray();
		processValues(datas);
		Utility.sendEvent(new WebClientEvent("dialogclose",app.getCurrentPageId(),null,this.sessionContext));
		return 1;
	}
	
	public int editMatuseTrans() throws RemoteException, MXException
	{
		String[][] datas=app.getDataBean("EDITMATUSE").getDataAsArray();
		processValues(datas);
		Utility.sendEvent(new WebClientEvent("dialogclose",app.getCurrentPageId(),null,this.sessionContext));
		return 1;
	}
	
	public int editLabTrans() throws RemoteException, MXException
	{
		String[][] datas=app.getDataBean("EDITLAB").getDataAsArray();
		processValues(datas);
		Utility.sendEvent(new WebClientEvent("dialogclose",app.getCurrentPageId(),null,this.sessionContext));
		return 1;
	}
	
	public int editTransfer() throws RemoteException, MXException
	{
		String[][] datas=app.getDataBean("EDITTRANS").getDataAsArray();
		processValues(datas);
		Utility.sendEvent(new WebClientEvent("dialogclose",app.getCurrentPageId(),null,this.sessionContext));
		return 1;
	}
	public void processValues(String[][] datas) throws MXException,
			RemoteException {
		MboSetRemote receiptsSet=getMboSetRemote();
		MboRemote receiptLine=null;
		List<String> attrList=new ArrayList<String>();
		for(int i=0;i<datas[0].length;i++)
		{
			attrList.add(datas[0][i]);
		}
		
		for(int i=0;i<receiptsSet.count();i++)
		{
			receiptLine=receiptsSet.getMbo(i);
			String oldMessage=receiptLine.getString("OFTRANSMESSAGE");
			String oldReconciliation=receiptLine.getString("RECONCILIATION");
			String newMessage=datas[i+1][attrList.indexOf("OFDETAILS.OFMESSAGE")];
			String newReconciliation=datas[i+1][attrList.indexOf("OFDETAILS.RECONCILIATION")];

			if(!(oldMessage.equals(newMessage)))
			{
			receiptLine.setValue("OFTRANSMESSAGE", newMessage,2L);
			}
			if(!(oldReconciliation.equals(newReconciliation)))
			{
			receiptLine.setValue("RECONCILIATION", newReconciliation,2L);
			}
			receiptsSet.save();
		}
	}
	


	
}
