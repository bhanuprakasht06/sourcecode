/*
 * Created  by BCT 
 * 
 * Location renumbering select action menu.
 * based on this action , will create new location and move meters or move meters to 
 * existing location.
 * 
 * 
 */
package com.psa.webclient.beans.location;

import psdi.app.location.LocMeterReadingRemote;
import psdi.app.location.LocMeterReadingSetRemote;
import psdi.app.location.LocationMeterRemote;
import psdi.app.location.LocationMeterSetRemote;
import psdi.app.location.LocationSetRemote;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import psdi.app.location.LocationRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXSession;
import psdi.webclient.system.beans.DataBean;
import psdi.app.pm.PM;

public class locationRenumCustom extends DataBean {

	public locationRenumCustom() {

	}

	private String curentLoc;
	private String curentSiteId;
	private String renumLocation;
	private String renumDescription;
	private String renumSiteID;
	private String groupName;
	boolean moveAll;
	boolean resetMeter;
	private String effectiveDate="";
	String orgId;
	private MboRemote newMbo;
	private int success=0;
	
	public synchronized int execute() throws MXException, RemoteException {

			LocationRemote locationMbo=(LocationRemote) app.getAppBean().getMbo();

			curentLoc=locationMbo.getString("LOCATION");
			curentSiteId=locationMbo.getString("SITEID");
			renumLocation=locationMbo.getString("RENUMLOCATION");
			renumDescription=locationMbo.getString("RENUMLOCDESCRIPTION");
			renumSiteID=locationMbo.getString("RENUMSITEID");
			orgId=locationMbo.getString("ORGID");
			String locDescription
			=locationMbo.getString("RENUMLOCDESCRIPTION");
			groupName=locationMbo.getString("GROUPNAME");

			moveAll=locationMbo.getBoolean("MOVEALL");
			resetMeter=locationMbo.getBoolean("RESETMETER");
			Date  actualEffectiveDate=locationMbo.getDate("EFFECTIVEDATE");

			if(actualEffectiveDate!=null)
			{
				SimpleDateFormat fileDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
				effectiveDate = fileDateFormat.format(actualEffectiveDate);
			}
			
			//check exception part
			
			//check if renum location and renum SITEID is left NULL
			
			if(renumLocation.equalsIgnoreCase("") || renumSiteID.equalsIgnoreCase("") )
			{
				throw new MXApplicationException("locations","renumlocsiteid");
			}
			
			//check if new location and site is same as current location and site
			if(renumLocation.equalsIgnoreCase(curentLoc)&& curentSiteId.equalsIgnoreCase(renumSiteID))
			{
				throw new MXApplicationException("locations","Locrenum");
			}

			//check if moveall is ticked or effective date is entered
			if(effectiveDate.equalsIgnoreCase("")&& moveAll==false)
			{
				throw new MXApplicationException("locations","Movedate");
			}
			
			//Check if any open WO exists in current location
			boolean checkOpenWo=checkOpenWo( curentLoc, curentSiteId, locationMbo);
			
			if(checkOpenWo){
				throw new MXApplicationException("locations","openwo");
			}
			
		
			//check if PM or meters exists in new location
			boolean checkPMNewLocMeterExist=checkPMNewLocMeterExist(renumLocation,renumSiteID,locationMbo);
			
			
			if (checkPMNewLocMeterExist) {
				
				throw new MXApplicationException("locations","renumloc");
			}

			//Check if pmnum length will hit max field length with new location name replacement
				MboSetRemote pmSetRemote=locationMbo.getMboSet("PM");
				if(!pmSetRemote.isEmpty() & pmSetRemote!=null)
				{
					for(int i=0;i<pmSetRemote.count();i++)
					{
						MboRemote pmRemote=pmSetRemote.getMbo(i);
						String pmNumber=pmRemote.getString("PMNUM");
						String newPMNum=pmNumber.replace(curentLoc, renumLocation);
						MboSetRemote maxAttSetRemote=MXServer.getMXServer().getMboSet("MAXATTRIBUTE", locationMbo.getUserInfo());
						SqlFormat pmSql=new SqlFormat("OBJECTNAME='PM' AND ATTRIBUTENAME='PMNUM'");
						maxAttSetRemote.setWhere(pmSql.format());
						maxAttSetRemote.reset();
						int length=maxAttSetRemote.getMbo(0).getInt("LENGTH");
						if (newPMNum.length()>length) {
							throw new MXApplicationException("locations","PmNum");
						}
					}
					
					
				}
			
			//location part	
			boolean locationExist=checkLocation(locationMbo,renumLocation,renumSiteID);
			
			if(locationExist)
			{
				//to set the old locname, old siteid, renumdate and renum flag after renaming
				MboSetRemote renumLocSetRemote=MXServer.getMXServer().getMboSet("LOCATIONS", locationMbo.getUserInfo());
				SqlFormat renumLocSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
				renumLocSql.setObject(1, "LOCATIONS", "LOCATION", renumLocation);
				renumLocSql.setObject(2, "LOCATIONS", "SITEID", renumSiteID);
				renumLocSetRemote.setWhere(renumLocSql.format());
				renumLocSetRemote.reset();
				MboRemote renumLocRemote=renumLocSetRemote.getMbo(0);
				renumLocRemote.setValue("PREVLOC", curentLoc,MboConstants.NOACCESSCHECK);
				renumLocRemote.setValue("PREVSITEID", curentSiteId,MboConstants.NOACCESSCHECK);
				renumLocRemote.setValue("RENUMDATE", MXServer.getMXServer().getDate(),MboConstants.NOACCESSCHECK);
				locationMbo.setValue("ISLOCRENUM", "Y");
				renumLocSetRemote.save();
			}
			//if new location does not exists
			else
			{
				MboSetRemote locMboSetRemote=MXServer.getMXServer().getMboSet("LOCATIONS", locationMbo.getUserInfo());
				
				//create new location that will be under the same site
				if(curentSiteId.equalsIgnoreCase(renumSiteID))
				{
					
					MboRemote duplLocationMbo=locationMbo.duplicate();
					duplLocationMbo.setValue("LOCATION", renumLocation,MboConstants.NOACCESSCHECK);
					duplLocationMbo.setValue("DESCRIPTION", renumDescription,MboConstants.NOACCESSCHECK);
					duplLocationMbo.setValue("PREVLOC", curentLoc,MboConstants.NOACCESSCHECK);
					duplLocationMbo.setValue("PREVSITEID", curentSiteId,MboConstants.NOACCESSCHECK);
					duplLocationMbo.setValue("RENUMDATE", MXServer.getMXServer().getDate(),MboConstants.NOACCESSCHECK);
					locationMbo.setValue("ISLOCRENUM", "Y");
					
					duplLocationMbo.getThisMboSet().save();
					
					/*
					if (groupName.equalsIgnoreCase("")) {
						moveAllMeterToNewLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
					}
					else {
						moveLocReading( curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
					}
					
					duplLocationMbo.getMboSet("LOCATIONMETER").count();
					
					updatePM(renumLocation, curentLoc, curentSiteId, renumSiteID, locationMbo);
					if (moveAll==true) {
						
						moveMeterNoEffectiveDateToNewLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
						if (!groupName.equalsIgnoreCase("")) {
							deleteMeterFromOldLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
						}
						
					}
					else if (!effectiveDate.equalsIgnoreCase("") && moveAll==false)
					{
					
						moveMeterEffectiveDateToNewLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
						
					}
					*/
				
				}
				//create new location that will be under a different site
				else
				{
			
				//create new location that will be under a different site and set values
				SqlFormat locationMboSql=new SqlFormat(" LOCATION=:1 and SITEID=:2");
				locationMboSql.setObject(1, "LOCATIONS","LOCATION", curentLoc);
				locationMboSql.setObject(2, "LOCATIONS","SITEID", curentSiteId);
				locMboSetRemote.setWhere(locationMboSql.format());
				locMboSetRemote.reset();
				if(!locMboSetRemote.isEmpty() & locMboSetRemote!=null)
				{
					
					MboRemote locationMboRemote=locMboSetRemote.addAtEnd();
					locationMboRemote.setValue("SITEID",renumSiteID,MboConstants.NOACCESSCHECK);
					locationMboRemote.setValue("LOCATION", renumLocation,MboConstants.NOACCESSCHECK);
					locationMboRemote.setValue("DESCRIPTION", locDescription);
					locationMboRemote.setValue("STATUS","OPERATING",MboConstants.NOACCESSCHECK);
					locationMboRemote.setValue("ORGID", locMboSetRemote.getMbo(0).getString("ORGID"),MboConstants.NOACCESSCHECK);
					locationMboRemote.setValue("GROUPNAME", locMboSetRemote.getMbo(0).getString("GROUPNAME"),MboConstants.NOACCESSCHECK);
					locationMboRemote.setValue("OAASSETNUM", locMboSetRemote.getMbo(0).getString("OAASSETNUM"));
					locationMboRemote.setValue("GLACCOUNT", locMboSetRemote.getMbo(0).getString("GLACCOUNT"),11L);
					locationMboRemote.setValue("TYPE", locMboSetRemote.getMbo(0).getString("TYPE"));
					locationMboRemote.setValue("FAILURECODE", locMboSetRemote.getMbo(0).getString("FAILURECODE"));
					locationMboRemote.setValue("PREFIX", locMboSetRemote.getMbo(0).getString("PREFIX"));
					locationMboRemote.setValue("TERMINAL_C", locMboSetRemote.getMbo(0).getString("TERMINAL_C"));
					locationMboRemote.setValue("BRANDBATCH", locMboSetRemote.getMbo(0).getString("BRANDBATCH"));
					locationMboRemote.setValue("SROA", locMboSetRemote.getMbo(0).getString("SROA"));
					locationMboRemote.setValue("SRSTS", locMboSetRemote.getMbo(0).getString("SRSTS"));
					locationMboRemote.setValue("SRDO", locMboSetRemote.getMbo(0).getString("SRDO"));
					locationMboRemote.setValue("PLANNER", locMboSetRemote.getMbo(0).getString("PLANNER"));
					locationMboRemote.setValue("STS", locMboSetRemote.getMbo(0).getString("STS"));
					locationMboRemote.setValue("TECHOFF", locMboSetRemote.getMbo(0).getString("TECHOFF"));
					locationMboRemote.setValue("SNRTECHOFF", locMboSetRemote.getMbo(0).getString("SNRTECHOFF"));
					locationMboRemote.setValue("ENGINEER", locMboSetRemote.getMbo(0).getString("ENGINEER"));
					locationMboRemote.setValue("SECTHEAD", locMboSetRemote.getMbo(0).getString("SECTHEAD"));
					locationMboRemote.setValue("ENGMANAGER", locMboSetRemote.getMbo(0).getString("ENGMANAGER"));
					locationMboRemote.setValue("LOCPRIORITY", locMboSetRemote.getMbo(0).getString("LOCPRIORITY"));
					locationMboRemote.setValue("INTLABREC", locMboSetRemote.getMbo(0).getString("INTLABREC"));
					locationMboRemote.setValue("SERVICEADDRESSCODE", locMboSetRemote.getMbo(0).getString("SERVICEADDRESSCODE"));
					locationMboRemote.setValue("BILLTOADDRESSCODE", locMboSetRemote.getMbo(0).getString("BILLTOADDRESSCODE"));
					locationMboRemote.setValue("SHIPTOADDRESSCODE", locMboSetRemote.getMbo(0).getString("SHIPTOADDRESSCODE"));
					locationMboRemote.setValue("CALNUM", locMboSetRemote.getMbo(0).getString("CALNUM"));
					locationMboRemote.setValue("SHIFTNUM", locMboSetRemote.getMbo(0).getString("SHIFTNUM"));
					locationMboRemote.setValue("FUNCTIONTYPE", locMboSetRemote.getMbo(0).getString("FUNCTIONTYPE"));
					locationMboRemote.setValue("SUBTYPE", locMboSetRemote.getMbo(0).getString("SUBTYPE"));
					locationMboRemote.setValue("BRANDBATCH", locMboSetRemote.getMbo(0).getString("BRANDBATCH"));
					locationMbo.setValue("PREVLOC", curentLoc,MboConstants.NOACCESSCHECK);
					locationMbo.setValue("PREVSITEID", curentSiteId,MboConstants.NOACCESSCHECK);
					locationMbo.setValue("RENUMDATE", MXServer.getMXServer().getDate(),MboConstants.NOACCESSCHECK);
				}
				
				/*
				//move locationmeters for new location at new site
				moveAllMeterToNewLoc(curentLoc, renumLocation, curentSiteId,renumSiteID,locationMbo);
				updatePM(renumLocation, curentLoc, curentSiteId, renumSiteID, locationMbo);
				if (moveAll==true) {
				
					moveMeterNoEffectiveDateToNewLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
				}
				else if (!effectiveDate.equalsIgnoreCase("") && moveAll==false)
				{
				moveMeterEffectiveDateToNewLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);	
				}
				*/
				
				locationMbo.setValue("ISLOCRENUM", "Y");
				locMboSetRemote.save();
				}
			
				
			}
			
			//rename part
			
			/*
			3 scenarios of renaming locations:
			a) move all=true(eg. move loc to diff site[KT->PPT1], new eqpt taking over name[TPM->OLD_TPM])
			-move all locationmeter, locmeterreading, pm data to new location
			
			b) move all=false and effective date is not null and reset meter=false(eg. same site KQC221 move to KQC300)
			-move all pm data to new location
			-move all locmeterreading from effective date(inclusive) to new location
			-copy all locationmeter over to new location
			?-subtract sum(delta) of locmeterreading at new location from locationmeter at old location
			
			c) move all=false and effective date is not null and reset meter=true(eg. TPM300 has new meters already, move TPM to OLD_TPM, then use this to move back to TPM based on effective date)
			-move all pm data to new location
			-move all locmeterreading from effective date(inclusive) to new location
			-set reading of all locmeterreading to start at zero from effective date(inclusive) at new location
			-create new locationmeters at new location and set reading based on reading at locmeterreading
			
			*/

			
			
			//scenario a
			if (moveAll==true) 
			{
				updatePM(renumLocation, curentLoc, curentSiteId, renumSiteID, locationMbo);
				
				//check if new location has locationmeter. If yes, delete and move over from old location
				//delete can be done because rename will check if new location has locationmeters or not.
				//only time new location has locationmeters is because duplicate from existing by rename
				SqlFormat checkNewLocMeterSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
				checkNewLocMeterSql.setObject(1, "LOCATIONMETER", "LOCATION", renumLocation);
				checkNewLocMeterSql.setObject(2, "LOCATIONMETER", "SITEID", renumSiteID);
				MboSetRemote newlocMeterSetRemote=locationMbo.getMboSet("$LOCATIONMETER","LOCATIONMETER",checkNewLocMeterSql.format());
				//newly added
				newlocMeterSetRemote.reset();
				
				if (newlocMeterSetRemote.count()>0) 
				{
					System.out.println("*******************Deleting the Meters from Old location ");
					deleteMeterFromOldLoc(renumLocation, renumLocation, renumSiteID, renumSiteID, locationMbo);
				}

				moveAllMeterToNewLoc(curentLoc, renumLocation, curentSiteId,renumSiteID,locationMbo);
				
				moveMeterNoEffectiveDateToNewLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
				success=1;
				
				
			}
			//scenario b
			else if (!effectiveDate.equalsIgnoreCase("") && moveAll==false && resetMeter==false)
			{
				updatePM(renumLocation, curentLoc, curentSiteId, renumSiteID, locationMbo);
				
				//check if new location has locationmeter. If yes, delete and move over from old location
				//delete can be done because rename will check if new location has locationmeters or not.
				//only time new location has locationmeters is because duplicate from existing by rename
				SqlFormat checkNewLocMeterSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
				checkNewLocMeterSql.setObject(1, "LOCATIONMETER", "LOCATION", renumLocation);
				checkNewLocMeterSql.setObject(2, "LOCATIONMETER", "SITEID", renumSiteID);
				
				MboSetRemote newlocMeterSetRemote=locationMbo.getMboSet("$LOCATIONMETER","LOCATIONMETER",checkNewLocMeterSql.format());
				newlocMeterSetRemote.reset();
				int count_temp=newlocMeterSetRemote.count();
				System.out.println("********************count of newlocationmeter"+count_temp);
				
				//if meters exist, copy values over
				if (newlocMeterSetRemote.count()>0) 
				{
					System.out.println("******************* SCENARIO B Function moveLocReading has been called ");
					moveLocReading( curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
				}
				//if meters does not exist, create locationmeters and copy values over
				else
				{
					    System.out.println("*******************SCENARIO B ELSE PART getting executed ");
						MboSetRemote  newLocMeterSet=locationMbo.getMboSet("LOCATIONMETER");
						//added locmeterCount variable 
						int locmeterCount = newLocMeterSet.count();
						for (int i = 0; i <locmeterCount; i++) 
						{
							//create new locationmeter
							LocationMeterRemote newlocmeter;
							newlocmeter = (LocationMeterRemote) newLocMeterSet.addAtEnd();
							
							//set values for new locationmeter
							newlocmeter.setValue("LOCATION",renumLocation,MboConstants.NOACCESSCHECK);
							newlocmeter.setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK);
							newlocmeter.setValue("AVERAGE", newLocMeterSet.getMbo(i).getDouble("AVERAGE"),11L);
							newlocmeter.setValue("LIFETODATE", newLocMeterSet.getMbo(i).getDouble("LIFETODATE"),11L);
							newlocmeter.setValue("LASTREADING", newLocMeterSet.getMbo(i).getString("LASTREADING"),11L);
							newlocmeter.setValue("LASTREADINGDATE", newLocMeterSet.getMbo(i).getDate("LASTREADINGDATE"),11L);
							newlocmeter.setValue("LASTREADINGINSPCTR", newLocMeterSet.getMbo(i).getString("LASTREADINGINSPCTR"),11L);
							newlocmeter.setValue("SINCELASTREPAIR", newLocMeterSet.getMbo(i).getDouble("SINCELASTREPAIR"),11L);
							newlocmeter.setValue("SINCELASTOVERHAUL", newLocMeterSet.getMbo(i).getDouble("SINCELASTOVERHAUL"),11L);
							newlocmeter.setValue("SINCELASTINSPECT", newLocMeterSet.getMbo(i).getDouble("SINCELASTINSPECT"),11L);
							newlocmeter.setValue("SINCEINSTALL", newLocMeterSet.getMbo(i).getDouble("SINCEINSTALL"),11L);
							newlocmeter.setValue("CHANGEDATE", newLocMeterSet.getMbo(i).getDate("CHANGEDATE"),11L);
							
						//	newlocmeter.setValue("METERNAME", newLocMeterSet.getMbo(i).getDate("METERNAME"),11L);
						//	newlocmeter.setValue("MEASUREUNITID", newLocMeterSet.getMbo(i).getDate("MEASUREUNITID"),11L);
						//	newlocmeter.setValue("ACTIVE", newLocMeterSet.getMbo(i).getDate("ACTIVE"),11L);
						//	newlocmeter.setValue("AVGCALCMETHOD", newLocMeterSet.getMbo(i).getDate("AVGCALCMETHOD"),11L);
						//	newlocmeter.setValue("SLIDINGWINDOWSIZE", newLocMeterSet.getMbo(i).getDate("SLIDINGWINDOWSIZE"),11L);
						//	newlocmeter.setValue("ROLLOVER", newLocMeterSet.getMbo(i).getDate("ROLLOVER"),11L);
						//	newlocmeter.setValue("READINGTYPE", newLocMeterSet.getMbo(i).getDate("READINGTYPE"),11L);
							
							newlocmeter.setValue("METERNAME", newLocMeterSet.getMbo(i).getString("METERNAME"),11L);
							newlocmeter.setValue("MEASUREUNITID", newLocMeterSet.getMbo(i).getString("MEASUREUNITID"),11L);
							newlocmeter.setValue("ACTIVE", newLocMeterSet.getMbo(i).getBoolean("ACTIVE"),11L);
							newlocmeter.setValue("AVGCALCMETHOD", newLocMeterSet.getMbo(i).getString("AVGCALCMETHOD"),11L);
							newlocmeter.setValue("SLIDINGWINDOWSIZE", newLocMeterSet.getMbo(i).getInt("SLIDINGWINDOWSIZE"),11L);
							newlocmeter.setValue("ROLLOVER", newLocMeterSet.getMbo(i).getDouble("ROLLOVER"),11L);
							newlocmeter.setValue("READINGTYPE", newLocMeterSet.getMbo(i).getString("READINGTYPE"),11L);
							
						//	newlocmeter.setValue("REMARKS", newLocMeterSet.getMbo(i).getDate("REMARKS"),11L);
							
							newlocmeter.setValue("REMARKS", newLocMeterSet.getMbo(i).getString("REMARKS"),11L);
							
							//newlocmeter.save();
							
						}
						newLocMeterSet.save();
						
				}
				
				//moveAllMeterToNewLoc(curentLoc, renumLocation, curentSiteId,renumSiteID,locationMbo);
				moveMeterEffectiveDateToNewLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);	
				success=1;
			}
			//scenario c
			else if (!effectiveDate.equalsIgnoreCase("") && moveAll==false && resetMeter==true)
			{
			
				
				//updatePM(renumLocation, curentLoc, curentSiteId, renumSiteID, locationMbo);
				
				//check if new location has locationmeter. If yes, delete and move over from old location
				//delete can be done because rename will check if new location has locationmeters or not.
				//only time new location has locationmeters is because duplicate from existing by rename
				SqlFormat checkNewLocMeterSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
				checkNewLocMeterSql.setObject(1, "LOCATIONMETER", "LOCATION", renumLocation);
				checkNewLocMeterSql.setObject(2, "LOCATIONMETER", "SITEID", renumSiteID);
				MboSetRemote newlocMeterSetRemote=locationMbo.getMboSet("$LOCATIONMETER","LOCATIONMETER",checkNewLocMeterSql.format());
				newlocMeterSetRemote.reset();
				
				//if meters exist, reset meters
				if (newlocMeterSetRemote.count()>0) 
				{
					moveLocReading( curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
				}
				//if meters does not exist, create locationmeters
				else
				{
						MboSetRemote  locMeterSet=locationMbo.getMboSet("LOCATIONMETER");
						int locmeterCount = locMeterSet.count();
						for (int i = 0; i <locmeterCount; i++) 
						{
							//create new locationmeter
							LocationMeterRemote newlocmeter;
							newlocmeter = (LocationMeterRemote) locMeterSet.addAtEnd();
							
							//set values for new locationmeter
							newlocmeter.setValue("LOCATION",renumLocation,MboConstants.NOACCESSCHECK);
							newlocmeter.setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK);
							newlocmeter.setValue("AVERAGE", locMeterSet.getMbo(i).getDouble("AVERAGE"),11L);
							newlocmeter.setValue("LIFETODATE", locMeterSet.getMbo(i).getDouble("LIFETODATE"),11L);
							newlocmeter.setValue("LASTREADING", locMeterSet.getMbo(i).getString("LASTREADING"),11L);
							newlocmeter.setValue("LASTREADINGDATE", locMeterSet.getMbo(i).getDate("LASTREADINGDATE"),11L);
							newlocmeter.setValue("LASTREADINGINSPCTR", locMeterSet.getMbo(i).getString("LASTREADINGINSPCTR"),11L);
							newlocmeter.setValue("SINCELASTREPAIR", locMeterSet.getMbo(i).getDouble("SINCELASTREPAIR"),11L);
							newlocmeter.setValue("SINCELASTOVERHAUL", locMeterSet.getMbo(i).getDouble("SINCELASTOVERHAUL"),11L);
							newlocmeter.setValue("SINCELASTINSPECT", locMeterSet.getMbo(i).getDouble("SINCELASTINSPECT"),11L);
							newlocmeter.setValue("SINCEINSTALL", locMeterSet.getMbo(i).getDouble("SINCEINSTALL"),11L);
							newlocmeter.setValue("CHANGEDATE", locMeterSet.getMbo(i).getDate("CHANGEDATE"),11L);
							
						//	newlocmeter.setValue("METERNAME", locMeterSet.getMbo(i).getDate("METERNAME"),11L);
						//	newlocmeter.setValue("MEASUREUNITID", locMeterSet.getMbo(i).getDate("MEASUREUNITID"),11L);
						//	newlocmeter.setValue("ACTIVE", locMeterSet.getMbo(i).getDate("ACTIVE"),11L);
						//	newlocmeter.setValue("AVGCALCMETHOD", locMeterSet.getMbo(i).getDate("AVGCALCMETHOD"),11L);
						//	newlocmeter.setValue("SLIDINGWINDOWSIZE", locMeterSet.getMbo(i).getDate("SLIDINGWINDOWSIZE"),11L);
						//	newlocmeter.setValue("ROLLOVER", locMeterSet.getMbo(i).getDate("ROLLOVER"),11L);
						//	newlocmeter.setValue("READINGTYPE", locMeterSet.getMbo(i).getDate("READINGTYPE"),11L);
							
							newlocmeter.setValue("METERNAME", locMeterSet.getMbo(i).getString("METERNAME"),11L);
							newlocmeter.setValue("MEASUREUNITID", locMeterSet.getMbo(i).getString("MEASUREUNITID"),11L);
							newlocmeter.setValue("ACTIVE", locMeterSet.getMbo(i).getBoolean("ACTIVE"),11L);
							newlocmeter.setValue("AVGCALCMETHOD", locMeterSet.getMbo(i).getString("AVGCALCMETHOD"),11L);
							newlocmeter.setValue("SLIDINGWINDOWSIZE", locMeterSet.getMbo(i).getInt("SLIDINGWINDOWSIZE"),11L);
							newlocmeter.setValue("ROLLOVER", locMeterSet.getMbo(i).getDouble("ROLLOVER"),11L);
							newlocmeter.setValue("READINGTYPE", locMeterSet.getMbo(i).getString("READINGTYPE"),11L);
							
							
						//	newlocmeter.setValue("REMARKS", locMeterSet.getMbo(i).getDate("REMARKS"),11L);
							
							newlocmeter.setValue("REMARKS", locMeterSet.getMbo(i).getString("REMARKS"),11L);
							
							//newlocmeter.save();
							
						}
						locMeterSet.save();
				}
				
				//moveAllMeterToNewLoc(curentLoc, renumLocation, curentSiteId,renumSiteID,locationMbo);
				moveMeterEffectiveDateToNewLoc(curentLoc, renumLocation, curentSiteId, renumSiteID, locationMbo);
				
				//set reading value for moved locmeterreading
				
				MboSetRemote renumLocSetRemote=MXServer.getMXServer().getMboSet("LOCATIONS", locationMbo.getUserInfo());
				SqlFormat renumLocSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
				renumLocSql.setObject(1, "LOCATIONS", "LOCATION", renumLocation);
				renumLocSql.setObject(2, "LOCATIONS", "SITEID", renumSiteID);
				renumLocSetRemote.setWhere(renumLocSql.format());

				
				MboSetRemote  locMeterSet=renumLocSetRemote.getMbo(0).getMboSet("LOCATIONMETER");
				for (int i = 0; i <locMeterSet.count(); i++) 
				{
					LocMeterReadingSetRemote newLocMeterReadingSet=(LocMeterReadingSetRemote)locMeterSet.getMbo(0).getMboSet("LOCMETERREADING");
	                newLocMeterReadingSet.setOrderBy("READINGDATE");
	                
	                LocMeterReadingRemote locmeterread;
                    if(newLocMeterReadingSet.count() != 0)
                    {
                        Double currreading = 0.0;
                        for (int l=0; ((locmeterread =  (LocMeterReadingRemote) newLocMeterReadingSet.getMbo(l))!= null);l++)
                        {
	                        //first record, set reading =delta
	                        if( l == 0 )
                            {
	                            currreading = locmeterread.getDouble("DELTA");
	                            locmeterread.setValue("READING", currreading, MboConstants.NOACCESSCHECK);	                           
                            }
                            //all other readings, set reading = nextreading + delta
                            else 
                            {
	                            currreading = currreading + locmeterread.getDouble("DELTA");
	                            locmeterread.setValue("READING", currreading, MboConstants.NOACCESSCHECK);
                            }
                        }
		                newLocMeterReadingSet.save();
		                newLocMeterReadingSet.reset();
	                }
				}
				
				//set locationmeter to use value of reading of latest locmeterreading
				for (int i = 0; i <locMeterSet.count(); i++) 
				{
					LocMeterReadingSetRemote newLocMeterReadingSet=(LocMeterReadingSetRemote)locMeterSet.getMbo(0).getMboSet("LOCMETERREADING");
	                newLocMeterReadingSet.setOrderBy("READINGDATE");
	                
	                LocMeterReadingRemote locmeterread;
                    if(newLocMeterReadingSet.count() != 0)
                    {
	                    //get the last locmeterreading mbo to get the READING value
	                    double reading=newLocMeterReadingSet.getMbo(locMeterSet.count()-1).getDouble("READING");
	                    
						locMeterSet.getMbo(i).setValue("LIFETODATE", reading,11L);
						locMeterSet.getMbo(i).setValue("LASTREADING", reading,11L);
						locMeterSet.getMbo(i).setValue("SINCELASTREPAIR", reading,11L);
						locMeterSet.getMbo(i).setValue("SINCELASTOVERHAUL", reading,11L);
						locMeterSet.getMbo(i).setValue("SINCELASTINSPECT", reading,11L);
						locMeterSet.getMbo(i).setValue("SINCEINSTALL", reading,11L);

						locMeterSet.getMbo(i).setValue("LASTREADINGDATE", newLocMeterReadingSet.getMbo(locMeterSet.count()-1).getDate("READINGDATE"),11L);
	                }
				}
			}
			
			if (success==1)
			{
				String params[] ={renumLocation};
				clientSession.showMessageBox(clientSession.getCurrentEvent(), "location", "renumSuccess",params);
				return 1;
			}
			else
			{
				return 1;
			}
	}
	
	//end of main logic execute()
	
	//check if new location is in DB
	private boolean checkLocation(MboRemote locMbo,String location,String siteID) throws RemoteException, MXException {

		boolean locExist=false;

		SqlFormat locationSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");		
		locationSql.setObject(1, "LOCATIONS", "LOCATION", location);
		locationSql.setObject(2, "LOCATIONS", "SITEID", siteID);
		MboSetRemote locationSetRemote=locMbo.getMboSet("$LOCATIONS","LOCATIONS",locationSql.format());
		if(locationSetRemote.count()>0)
		{
			locExist=true;
		}
		return locExist;

	}

	//move locationmeter to new location
	private void moveAllMeterToNewLoc(String curentLoc,String renumLocation,String curentSiteId,String renumSiteID,MboRemote locationMbo) throws MXException,RemoteException
	{
		SqlFormat locationMeterSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
		locationMeterSql.setObject(1, "LOCATIONMETER", "LOCATION", curentLoc);
		locationMeterSql.setObject(2, "LOCATIONMETER", "SITEID", curentSiteId);
		
		MboSetRemote  locationMeterSetRemote=locationMbo.getMboSet("$LOCATIONMETER","LOCATIONMETER",locationMeterSql.format());
		
		if(locationMeterSetRemote!=null & locationMeterSetRemote.count()>0)
		{
			for(int i=0;i<=locationMeterSetRemote.count()-1;i++)
			{
				locationMeterSetRemote.getMbo(i).setValue("LOCATION",renumLocation,MboConstants.NOACCESSCHECK);
				locationMeterSetRemote.getMbo(i).setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK);
				
				
			}
			
			locationMeterSetRemote.save();
		}
	
	
	
	}

	//move PM related data to new location
	private void updatePM(String renumLocation,String curentLoc,String curentSiteId,String renumSiteID,MboRemote locationMbo)throws MXException,RemoteException
	{
		
		
		SqlFormat updatePMSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
		updatePMSql.setObject(1, "PM", "LOCATION", curentLoc);
		updatePMSql.setObject(2, "PM", "SITEID", curentSiteId);
		MboSetRemote pmSetRemote=locationMbo.getMboSet("$PM","PM",updatePMSql.format());
		if(!pmSetRemote.isEmpty() & pmSetRemote!=null)
		{
			for(int i=0;pmSetRemote.count()!=0;)
			{
				MboRemote pmRemote=pmSetRemote.getMbo(i);
				String pmNumber=pmRemote.getString("PMNUM");
				int jpSeqInUse=pmRemote.getInt("JPSEQINUSE");
				String jpNum=pmRemote.getString("JPNUM");
				
				
				//String[] splitOldPMnum=pmNumber.split("_");
				
				
				
				
				String newPMnum=pmNumber.replace(curentLoc, renumLocation);
				
				pmRemote.setValue("LOCATION", renumLocation,MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION_AND_NOACTION);
				pmRemote.setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION_AND_NOACTION);
				pmRemote.setValue("STORELOC","",MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION_AND_NOACTION);
				pmRemote.setValue("STORELOCSITE","",MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION_AND_NOACTION);
				
				SqlFormat updatePMSequenceSql=new SqlFormat("PMNUM=:1 AND SITEID=:2");
				updatePMSequenceSql.setObject(1, "PMSEQUENCE","PMNUM",pmRemote.getString("PMNUM"));    
				updatePMSequenceSql.setObject(2, "PMSEQUENCE", "SITEID", curentSiteId);
				MboSetRemote pmSeqSetRemote=pmRemote.getMboSet("$PMSEQUENCE","PMSEQUENCE",updatePMSequenceSql.format());
				if(!pmSeqSetRemote.isEmpty() & pmSeqSetRemote!=null)
				{
					for(int k=0;k<=pmSeqSetRemote.count()-1;k++)
					{
						pmSeqSetRemote.getMbo(k).setValue("PMNUM",newPMnum,11L);						
						pmSeqSetRemote.getMbo(k).setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION_AND_NOACTION);
					
						
					}
					
				}
				
				SqlFormat updatePMAncestorSql=new SqlFormat("PMNUM=:1 AND SITEID=:2");
				updatePMAncestorSql.setObject(1, "PMANCESTOR","PMNUM",pmRemote.getString("PMNUM"));    
				updatePMAncestorSql.setObject(2, "PMANCESTOR", "SITEID", curentSiteId);
				MboSetRemote pmAncestorSetRemote=pmRemote.getMboSet("$PMANCESTOR","PMANCESTOR",updatePMAncestorSql.format());
				if(!pmAncestorSetRemote.isEmpty() & pmAncestorSetRemote!=null)
				{
					for(int l=0;l<=pmAncestorSetRemote.count()-1;l++)
					{
					
						pmAncestorSetRemote.getMbo(l).setValue("PMNUM",newPMnum,11L);
						pmAncestorSetRemote.getMbo(l).setValue("ANCESTOR",newPMnum,11L);
						pmAncestorSetRemote.getMbo(l).setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION_AND_NOACTION);
					
						
					}
					
				}
				SqlFormat updatePMMeterSql=new SqlFormat("LOCATION=:1 AND SITEID=:2 AND PMNUM=:3");
				updatePMMeterSql.setObject(1, "PMMETER", "LOCATION", curentLoc);
				updatePMMeterSql.setObject(2, "PMMETER", "SITEID", curentSiteId);
				updatePMMeterSql.setObject(3, "PMMETER", "PMNUM", pmRemote.getString("PMNUM"));
				MboSetRemote pmMeterSetRemote=locationMbo.getMboSet("$PMMETER","PMMETER",updatePMMeterSql.format());
				if(!pmMeterSetRemote.isEmpty() & pmMeterSetRemote!=null)
				{
					for(int j=0;j<=pmMeterSetRemote.count()-1;j++)
					{
						pmMeterSetRemote.getMbo(j).setValue("PMNUM",newPMnum,11L);
						pmMeterSetRemote.getMbo(j).setValue("LOCATION", renumLocation,MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION_AND_NOACTION);
						pmMeterSetRemote.getMbo(j).setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK|MboConstants.NOVALIDATION_AND_NOACTION);
					//	pmMeterSetRemote.save();
					//  UR Changes	
					}
					
				}
				pmRemote.setValue("PMNUM", newPMnum,11L);
				pmSetRemote.save();
}
			
									
		}
		
		System.out.println("Setting jpSeqInUse");	
		
		SqlFormat updatePMSql1=new SqlFormat("LOCATION=:1 AND SITEID=:2 ");
		updatePMSql1.setObject(1, "PM", "LOCATION", renumLocation);
		updatePMSql1.setObject(2, "PM", "SITEID", renumSiteID);
		MboSetRemote pmSetRemotenew=locationMbo.getMboSet("$PM","PM",updatePMSql1.format());
		if(!pmSetRemotenew.isEmpty() & pmSetRemotenew!=null)
		{			
			for(int j=0;j<pmSetRemotenew.count();j++)
			{
				MboRemote pmRemoteNew=pmSetRemotenew.getMbo(j);
				String pmNumber=pmRemoteNew.getString("PMNUM");
				int jpSeqInUse=pmRemoteNew.getInt("JPSEQINUSE");
				String jpNum=pmRemoteNew.getString("JPNUM");
				if (pmRemoteNew instanceof PM) {
				    PM pmInstance = (PM) pmRemoteNew; 
				    pmInstance.updateJpSeqInUse(); 
				    System.out.println("pmNumber after save--> "+pmNumber);
					System.out.println("jpSeqInUse after save--> "+jpSeqInUse);
				}
	            	
			} pmSetRemotenew.save();
			
			} 
		
	}
	
	//move locmeterreading based on effective date
	private void moveMeterEffectiveDateToNewLoc(String curentLoc,String renumLocation,String curentSiteId,String renumSiteID,MboRemote locationMbo) throws MXException,RemoteException
	{
	//	SqlFormat locationMeterReadingSql=new SqlFormat("LOCATION='"+curentLoc+"' AND TRUNC(READINGDATE)>='"+effectiveDate+"' AND SITEID='"+curentSiteId+"'");
		SqlFormat locationMeterReadingSql=new SqlFormat("LOCATION='"+curentLoc+"' AND CAST(READINGDATE as date)>='"+effectiveDate+"' AND SITEID='"+curentSiteId+"'");
		MboSetRemote  locationMeterReadingSetRemote=locationMbo.getMboSet("$LOCMETERREADING","LOCMETERREADING",locationMeterReadingSql.format());
		System.out.println("***SQL Query to fetch locationmeter reading based on Effective date"+locationMeterReadingSql.format());
		locationMeterReadingSetRemote.count();
		System.out.println("Count of the records counts fetched from SQL query"+locationMeterReadingSetRemote.count());
			if(locationMeterReadingSetRemote.count()>0)
			{
				for(int i=0;i<=locationMeterReadingSetRemote.count()-1;i++)
				{
				
						locationMeterReadingSetRemote.getMbo(i).setValue("LOCATION",renumLocation,MboConstants.NOACCESSCHECK);
						locationMeterReadingSetRemote.getMbo(i).setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK);
				}
				locationMeterReadingSetRemote.save();
			}
	}
	private boolean checkOpenWo(String curentLoc,String curentSiteId,MboRemote locationMbo) throws MXException,RemoteException
	{
		boolean openWoExist=false;
		SqlFormat woCheckFormat=new SqlFormat("LOCATION=:1 AND SITEID=:2 AND PMNUM IS NOT NULL AND STATUS NOT IN (SELECT VALUE  FROM SYNONYMDOMAIN WHERE DOMAINID ='WOSTATUS' AND MAXVALUE IN ('CLOSE','CAN'))");
		woCheckFormat.setObject(1, "WORKORDER", "LOCATION", curentLoc);
		woCheckFormat.setObject(2, "WORKORDER", "SITEID", curentSiteId);
		MboSetRemote  workOrderSetRemote=locationMbo.getMboSet("$WORKORDER","WORKORDER",woCheckFormat.format());
		if (workOrderSetRemote!=null & workOrderSetRemote.count()>0) {
			
			openWoExist=true;
			return openWoExist;	
		}
		return openWoExist;
	}
	
private boolean checkPMNewLocMeterExist(String renumloc,String renumsiteID,MboRemote locationMbo)throws MXException,RemoteException
	
	{
		boolean checkPMNewLocMeterExist=false;
		SqlFormat checkMeterSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
		checkMeterSql.setObject(1, "LOCATIONMETER", "LOCATION", renumloc);
		checkMeterSql.setObject(2, "LOCATIONMETER", "SITEID", renumsiteID);
		MboSetRemote locMeterSetRemote=locationMbo.getMboSet("$LOCATIONMETER","LOCATIONMETER",checkMeterSql.format());
		
		SqlFormat checkPMExistSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
		checkPMExistSql.setObject(1, "PM", "LOCATION", renumloc);
		checkPMExistSql.setObject(2, "PM", "SITEID", renumsiteID);
		MboSetRemote pmSetRemote=locationMbo.getMboSet("$PM","PM",checkPMExistSql.format());
		
		if (locMeterSetRemote.count()>0 || pmSetRemote.count()>0) {
			checkPMNewLocMeterExist=true;
			return checkPMNewLocMeterExist;
		}
		return checkPMNewLocMeterExist;
	}

private void moveMeterNoEffectiveDateToNewLoc(String curentLoc,String renumLocation,String curentSiteId,String renumSiteID,MboRemote locationMbo) throws MXException,RemoteException
{
		
		SqlFormat locMeterReadingSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
		locMeterReadingSql.setObject(1, "LOCMETERREADING", "LOCATION", curentLoc);
		locMeterReadingSql.setObject(2, "LOCMETERREADING", "SITEID", curentSiteId);
		
		MboSetRemote  locMeterReadingSetRemote=locationMbo.getMboSet("$LOCMETERREADING","LOCMETERREADING",locMeterReadingSql.format());
		
		if(locMeterReadingSetRemote!=null & locMeterReadingSetRemote.count()>0)
		{
			for(int i=0;i<=locMeterReadingSetRemote.count()-1;i++)
			{
				locMeterReadingSetRemote.getMbo(i).setValue("LOCATION",renumLocation,MboConstants.NOACCESSCHECK);
				locMeterReadingSetRemote.getMbo(i).setValue("SITEID", renumSiteID,MboConstants.NOACCESSCHECK);
			
				
			}
			
			locMeterReadingSetRemote.save();
			
		}

	}

private void deleteMeterFromOldLoc(String curentLoc,String renumLocation,String curentSiteId,String renumSiteID,MboRemote locationMbo) throws MXException,RemoteException
{

	SqlFormat oldLocSql=new SqlFormat("LOCATION=:1 AND SITEID=:2");
	oldLocSql.setObject(1, "LOCATIONMETER", "LOCATION", curentLoc);
	oldLocSql.setObject(2, "LOCATIONMETER", "SITEID", curentSiteId);
	
	MboSetRemote  oldLocSetRemote=locationMbo.getMboSet("$LOCATIONMETER","LOCATIONMETER",oldLocSql.format());
	
	if(oldLocSetRemote!=null & oldLocSetRemote.count()>0)
	{
		for(int i=0;i<=oldLocSetRemote.count()-1;i++)
		{
			MboRemote oldLocRemote=oldLocSetRemote.getMbo(i);
			oldLocRemote.delete();
}
		oldLocSetRemote.save();
}
}

//set locationmeter of renum location if there is no meter group
private void moveLocReading(String curentLoc,String renumLocation,String curentSiteId,String renumSiteID,MboRemote locationMbo) throws MXException,RemoteException
{
	/*SqlFormat meterLoc=new SqlFormat("LOCATION=:1 AND SITEID=:2");
	meterLoc.setObject(1, "LOCATIONMETER", "LOCATION", curentLoc);
	meterLoc.setObject(2, "LOCATIONMETER", "SITEID", curentSiteId);
	MboSetRemote  locMeterSet=locationMbo.getMboSet("$LOCATIONMETER","LOCATIONMETER",meterLoc.format());*/
	
	MboSetRemote  locMeterSet=locationMbo.getMboSet("LOCATIONMETER");
	int oldlocMeterCount=locMeterSet.count();
	for (int i = 0; i <oldlocMeterCount; i++) {
		System.out.println("********************Inside the FOR LOOP of the function moveLocReading with oldlocMeterCount as"+oldlocMeterCount);
		
		MboRemote oldLocRemote=locMeterSet.getMbo(i);
		if (oldLocRemote!=null) {
			String meterName=oldLocRemote.getString("METERNAME");
			SqlFormat meterLoc=new SqlFormat("LOCATION=:1 AND SITEID=:2 AND METERNAME=:3");
			meterLoc.setObject(1, "LOCATIONMETER", "LOCATION", renumLocation);
			meterLoc.setObject(2, "LOCATIONMETER", "SITEID", renumSiteID);
			meterLoc.setObject(3, "LOCATIONMETER", "METERNAME", meterName);
			MboSetRemote  newLocMeterSet=locationMbo.getMboSet("$LOCATIONMETER","LOCATIONMETER",meterLoc.format());
			System.out.println("********************SQL Query to fetch locationmeter of new location of meter"+i+"  "+"   "+meterName+"   "+meterLoc.format());
			
			if (newLocMeterSet.getMbo(0)!=null) {
				System.out.println("********************Inside the IF BLOCK of value setting");
				newLocMeterSet.getMbo(0).setValue("AVERAGE", oldLocRemote.getDouble("AVERAGE"),11L);
				newLocMeterSet.getMbo(0).setValue("LIFETODATE", oldLocRemote.getDouble("LIFETODATE"),11L);
				newLocMeterSet.getMbo(0).setValue("LASTREADING", oldLocRemote.getString("LASTREADING"),11L);
				newLocMeterSet.getMbo(0).setValue("LASTREADINGDATE", oldLocRemote.getDate("LASTREADINGDATE"),11L);
				newLocMeterSet.getMbo(0).setValue("LASTREADINGINSPCTR", oldLocRemote.getString("LASTREADINGINSPCTR"),11L);
				newLocMeterSet.getMbo(0).setValue("SINCELASTREPAIR", oldLocRemote.getDouble("SINCELASTREPAIR"),11L);
				newLocMeterSet.getMbo(0).setValue("SINCELASTOVERHAUL", oldLocRemote.getDouble("SINCELASTOVERHAUL"),11L);
				newLocMeterSet.getMbo(0).setValue("SINCELASTINSPECT", oldLocRemote.getDouble("SINCELASTINSPECT"),11L);
				newLocMeterSet.getMbo(0).setValue("SINCEINSTALL", oldLocRemote.getDouble("SINCEINSTALL"),11L);
				newLocMeterSet.getMbo(0).setValue("CHANGEDATE", oldLocRemote.getDate("CHANGEDATE"),11L);
			}
			newLocMeterSet.save();
		}

	}
}
}