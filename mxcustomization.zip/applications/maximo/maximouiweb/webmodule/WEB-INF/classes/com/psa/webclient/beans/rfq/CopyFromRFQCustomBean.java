/*
 * Modification history
 * 17-10-07	AGD		NA		Creation
 */
package com.psa.webclient.beans.rfq;

import java.rmi.RemoteException;

import com.psa.app.rfq.RFQCustomRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;


public class CopyFromRFQCustomBean extends DataBean
{

	public CopyFromRFQCustomBean()
	{
	}


	public MboSetRemote getMboSetRemote()
			throws MXException, RemoteException
	{
		RFQCustomRemote rfq = (RFQCustomRemote) parent.getMbo();
		return rfq.getRFQForCopy();
	}


	/*
	 * Implement the OK button on the popup window
	 */
	public int execute()
			throws MXException, RemoteException
	{
		Object param[] = {"RFQ Line Num"}; 
		if (getSelection().size() == 0)
			return 1;
		if(rfqlinenum.equalsIgnoreCase(""))
		{
			throw new MXApplicationException("rfq", "invalidrfqlinenum");	
		}
			//throw new MXApplicationException("system", "null",param);
			
		
		
		
		MboSetRemote rfqset = getMboSet();
		if (!rfqset.isEmpty())
		{
			rfqset.resetWithSelection();
			RFQCustomRemote rfq = (RFQCustomRemote) parent.getMbo();
			rfq.copyFromRFQ(rfqset,rfqlinenum);
		}
		parent.save();
		rfqlinenum = null;
		return 1;
	}

	public void copyRFQLineNum()
	throws MXException, RemoteException
	{
		MboSetRemote rfqlineset = parent.getMbo().getMboSet("RFQLINE");
		boolean flag = false;
		MboRemote rfqline=null;
		for(int i=0; (rfqline = rfqlineset.getMbo(i)) != null; i++)
			if(rfqline.getString("rfqlinenum").equalsIgnoreCase(getDefaultValue("RFQLINENUM")))
				flag = true;
		if(!flag)
			throw new MXApplicationException("rfq", "invalidrfqlinenum");		
		
		rfqlinenum = getDefaultValue("RFQLINENUM");
	}
	public static String rfqlinenum = null;
}
