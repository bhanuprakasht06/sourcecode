/*
 * Created  by BCT 
 * 
 * PM update Unit to go select action menu.
 * 
 * based on this action PM Units to go will update with new value modify.
 * 
 * 
 */
package com.psa.webclient.beans.pm;

import java.rmi.RemoteException;

import psdi.app.pm.PMMeterRemote;
import psdi.app.pm.PMMeterSetRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.controls.Dialog;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.Utility;
import psdi.webclient.system.controller.WebClientEvent;
import psdi.webclient.system.session.WebClientSession;

public class UnitsToGoCustom extends DataBean {

public UnitsToGoCustom() {
		
	}
	
	@Override
	protected MboSetRemote getMboSetRemote() throws MXException,
			RemoteException {
		
		MboRemote pmRemote=app.getAppBean().getMbo();
		
		MboSetRemote pmMeterSet=pmRemote.getMboSet("PMMETER");
		pmMeterSet.setWhere("");
		return pmMeterSet;
	}

	public synchronized int updateUnitToGo() throws MXException, RemoteException {
	
		super.execute();
		MboRemote pmRemote=app.getAppBean().getMbo();
		
		PMMeterSetRemote pmMeterSet=(PMMeterSetRemote) pmRemote.getMboSet("PMMETER");
		
		if(pmMeterSet.count()>0)
		{
			for(int i=0;i<=pmMeterSet.count()-1;i++)
			{
				PMMeterRemote pmMeter=(PMMeterRemote) pmMeterSet.getMbo(i);
				if(!pmMeter.getString("READINGATNEXTWO").equalsIgnoreCase("") && (!pmMeter.getString("LTDREADATNEXTWO").equalsIgnoreCase("")))
				{
				if(!pmMeter.getString("UPUNITTOGO").equalsIgnoreCase(""))
				{
					if((pmMeter.getDouble("UNITSTOGO"))<0 || (pmMeter.getDouble("UNITSTOGO")>0))
					{

					double lifeToDate=0;
					SqlFormat pmLocationMeterSql=new SqlFormat("LOCATION='"+pmMeter.getString("LOCATION")+"' AND METERNAME='"+pmMeter.getString("METERNAME")+"' AND SITEID='"+pmMeter.getString("SITEID")+"' ");
					MboSetRemote pmLocationMeterSet=pmMeter.getMboSet("$LOCMETERREADING","LOCATIONMETER",pmLocationMeterSql.format());
					pmLocationMeterSet.count();
										
					lifeToDate=pmLocationMeterSet.getMbo(0).getDouble("LIFETODATE");
					
					double newUnitsToGo=pmMeter.getDouble("UPUNITTOGO");
					double readingNextToGo=lifeToDate+newUnitsToGo;
					
					double frequency=pmMeter.getDouble("FREQUENCY");
					double ltdlastpmworead=readingNextToGo-frequency;
					
					pmMeter.setValue("READINGATNEXTWO",readingNextToGo, MboConstants.NOACCESSCHECK);
					pmMeter.setValue("LTDREADATNEXTWO",readingNextToGo, MboConstants.NOACCESSCHECK);
					
					pmMeter.setValue("LASTPMWOGENREAD",ltdlastpmworead, MboConstants.NOACCESSCHECK);
					pmMeter.setValue("LTDLASTPMWOREAD",ltdlastpmworead, MboConstants.NOACCESSCHECK);
					
					pmMeter.setValue("UNITSTOGO", pmMeter.getDouble("UPUNITTOGO"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
					pmMeter.setValue("PVUNITTOGO", pmMeter.getDouble("UPUNITTOGO"), MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION);
					pmRemote.setValue("UNITFLAG", true);					
					}
					else
					{
						throw new MXApplicationException("PM", "UnitsToGONotExist");
					}

					
				}
				}
				else
				{
					throw new MXApplicationException("PM", "WOExist");
				}
				
			}
			
		}
		pmMeterSet.save();
		 Utility.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.sessionContext));
		    this.sessionContext.queueRefreshEvent();
		
		return 1;
	}
	
	

}


