/*
 * Modification history
 * 22-07-2013--4.2.6	Creation For Select Services For Return Dialog Box in Receiving Application (Dialog Box Id : "srvreturn")  
 */

package com.psa.webclient.beans.receipts;

import java.rmi.RemoteException;

import psdi.app.common.receipt.ReceiptMbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;

public class RetOrdServicesCustomBean extends DataBean
{
	public RetOrdServicesCustomBean()
	{
		
	}
	
protected void initialize() throws MXException, RemoteException
 {
	 System.out.println("I am Inside Intialize Method");
     super.initialize();
     DataBean servicesreturn = this.app.getDataBean("servreceipts_servreturn_table");
	     if (!servicesreturn.isEmpty())
		     { 
		       for (int j = 0; j < servicesreturn.count(); j++)
			       {
		    	   	   System.out.println("Inside Initialize For Loop");
		    	   	   System.out.println("Count for Records in Select Services For Return Dialog "+servicesreturn.count());
			    	   ReceiptMbo servicereceipt = (ReceiptMbo)servicesreturn.getMbo(j);
			    	   servicereceipt.setFlag(MboConstants.READONLY, false);
			    	   MboRemote poline = servicereceipt.getPOLine();
			    	   System.out.println("POLINE Number is "+poline.getString("POLINENUM"));
			    	   System.out.println("Quantity Received "+poline.getString("RECEIVEDQTY"));
			    	   servicereceipt.setValue("RETQUANTITY",poline.getString("RECEIVEDQTY"),MboConstants.NOVALIDATION);
			    	   servicereceipt.setFieldFlag("ENTERBY", MboConstants.READONLY, true);
			       }
		     }
     
 }
	 
public int execute()throws MXException, RemoteException
  {
	  System.out.println("I am in Execute Method");
      DataBean servicesreturn = this.app.getDataBean("servreceipts_servreturn_table");
      DataBean servicesrecvd = app.getDataBean("servreceipts_servreceipts_table");
      MboSetRemote servrectrans = servicesrecvd.getMboSet(); 
      int x = -1;
      if (!servicesreturn.isEmpty())
      {
     	 
        for (int j = 0; j < servicesreturn.count(); j++)
        {
        	ReceiptMbo servicereceipt = (ReceiptMbo)servicesreturn.getMbo(j);
     	   		if(servicereceipt.isSelected())
		     	   {
     	   			   System.out.println("POLINE Number "+servicereceipt.getString("POLINENUM")+" is Selected");
		     		   MboRemote servrectransmbo = servrectrans.addAtEnd();
		     		   servrectransmbo.setValue("POLINENUM", servicereceipt.getString("POLINENUM"));
		     		   servrectransmbo.setValue("ISSUETYPE","RETURN");
		     		   servrectransmbo.setValue("QTYTORECEIVE", servicereceipt.getDouble("RETQUANTITY")*x);
		     		   if(servicereceipt.getPOLine().getInt("INSPECTIONREQUIRED") == 1)
		     		   {
		     			  System.out.println("Inside Inspection Required Check");
		     			  System.out.println("Inspection Required For POLine Number "+servicereceipt.getString("POLINENUM"));
		     			  servrectransmbo.setValue("STATUS", "COMP",MboConstants.NOACCESSCHECK);  
		     		   }
		     	   
		     	   }
     	   
        }
      }
      servicesrecvd.refreshTable();
      return 1;
  }
	
}
