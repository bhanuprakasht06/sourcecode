package com.psa.webclient.beans.workflow;
import java.rmi.RemoteException;
import java.util.Hashtable;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.webclient.system.beans.WorkflowBean;
import psdi.webclient.system.controller.WebClientEvent;
import psdi.webclient.system.session.WebClientSession;

public class WorkflowBeanCustom extends WorkflowBean {

	public WorkflowBeanCustom() {
		// TODO Auto-generated constructor stub
	}






	@Override
	public void setupBean(WebClientSession wcs) {
		// TODO Auto-generated method stub
		super.setupBean(wcs);
		if(app.getApp().toLowerCase().contains("wotrack"))
		{
			try {
				String instruction = getInstruction();
				if(instruction.equalsIgnoreCase("Item Reservation"))
				{
					clientSession.handleEvent(new WebClientEvent("dialogok", "inputwf", null, clientSession));
				}
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}












	@Override
	public synchronized int execute() throws MXException,RemoteException{
		// TODO Auto-generated method stub

		if(app.getApp().toLowerCase().contains("wotrack"))
		{
			String instruction = getInstruction();
			MboRemote workorderRemote=app.getAppBean().getMbo();
			if(instruction.equalsIgnoreCase("Item Reservation"))
			{
				
				String reportName=MXServer.getMXServer().getProperty("mxe.wolaunch.reportname");
				MboSetRemote reportSet=MXServer.getMXServer().getMboSet("REPORT", MXServer.getMXServer().getUserInfo("MAXADMIN"));
				reportSet.setWhere("reportname='"+reportName+"'");
				reportSet.reset();
				String reportNum=reportSet.getMbo(0).getString("REPORTNUM");
				reportNum=reportNum.replaceAll(",", "");
				String pageName = (new StringBuilder()).append("reportd"+reportNum).append("").toString();
				clientSession.loadDialog(pageName);
				Hashtable<String,Object> reportParam = new Hashtable<String,Object>();
				reportParam.put("reportnumber", Integer.valueOf(reportNum));
				reportParam.put("whereclause", workorderRemote.getUniqueIDName() + " = " + workorderRemote.getUniqueIDValue());
				reportParam.put("quickprinttype", "");
				reportParam.put("command", "createreport");
				clientSession.handleEvent(new WebClientEvent("requestreportrun", pageName, reportParam, clientSession));
			}
		}

		return super.execute();


	}
	
	
	
	
	private String getInstruction() throws MXException, RemoteException {
		MboRemote inputWFRemote=app.getDataBean("inputwf").getMbo();
		MboSetRemote wfActionSet=MXServer.getMXServer().getMboSet("WFACTION", MXServer.getMXServer().getUserInfo("MAXADMIN"));
		wfActionSet.setWhere("ACTIONID="+inputWFRemote.getString("ACTIONID")+" and PROCESSNAME='"+inputWFRemote.getOwner().getString("PROCESSNAME")+"'");
		wfActionSet.reset();
		String instruction ="";
		if(wfActionSet!=null&&wfActionSet.count()>0)
		{
			instruction = wfActionSet.getMbo(0).getString("INSTRUCTION");
		}
		return instruction;
	}

	
	
}
