package com.psa.webclient.beans.workorder;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.webclient.beans.workorder.WOTasksBean;


public class WOTasksBeanCustom extends WOTasksBean {
	
	 public WOTasksBeanCustom()
	    {
		 
	    }
	 
	  private int markAll(MboSetRemote mbosetremote, String s, boolean flag)
     throws MXException, RemoteException
 {
     String s1 = s;
    
     MboRemote mboremote;
    
     for(int i = 0; (mboremote = mbosetremote.getMbo(i)) != null; i++)
     {
         if(flag && mboremote.getBoolean(s1) || !flag && !mboremote.getBoolean(s1))
             continue;
         try
         {
             if(!mboremote.getMboValueData(s1).isReadOnly())
                 mboremote.setValue(s1, flag);
             continue;
         }
         catch(Exception e)
         {
            e.printStackTrace();
         }
     }

     refreshTable();
     sessionContext.queueRefreshEvent();
     return 1;
 }
   public int taskcomplete() throws RemoteException, MXException
   {
   	MboSetRemote mbosetremote = app.getDataBean("copy_copy_plans_task_table").getMboSet();
       return markAll(mbosetremote, "TASKCOMP", true);
   }
   

  public int taskpend() throws RemoteException, MXException
   {
	   	MboSetRemote mbosetremote = app.getDataBean("copy_copy_plans_task_table").getMboSet();
       return markAll(mbosetremote, "TASKCOMP", false);
   }
}	
  
