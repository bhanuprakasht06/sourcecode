/*
 * Modification history
 * 17-10-07	AGD	eRFQ		Creation
 */
package com.psa.webclient.beans.rfq;

import java.rmi.RemoteException;

import com.psa.app.rfq.RFQCustomRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;


public class CopyeRFQtoWOCustomBean extends DataBean
{

	public CopyeRFQtoWOCustomBean()
	{
	}


	public MboSetRemote getMboSetRemote()
			throws MXException, RemoteException
	{
		RFQCustomRemote rfq = (RFQCustomRemote) parent.getMbo();
		return rfq.getWOForRFQ();
	}


	/*
	 * Implement the OK button on the popup window
	 */
	public int execute()
			throws MXException, RemoteException
	{
		MboSetRemote woset = getMboSet();
		if (getSelection().size() == 0 || woset.isEmpty())		// Nothing selected
			return 1;

//		woset.resetWithSelection();
		parent.save();
		RFQCustomRemote rfq = (RFQCustomRemote) parent.getMbo();
		rfq.copyeRFQtoWO(woset);
//		save();
		return 1;
	}

}
