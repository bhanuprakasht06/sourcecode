/*
 * Modification history
 * 28-09-2007	LES	eRFQ		Creation
 */
package com.psa.webclient.beans.rfq;

import java.rmi.RemoteException;

import psdi.util.MXException;
import psdi.webclient.beans.rfq.QuotationsVendorTableBean;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.Utility;
import com.psa.app.rfq.RFQCustomRemote;


public class QuotationsVendorTableCustomBean extends QuotationsVendorTableBean 
{
	public QuotationsVendorTableCustomBean() 
	{
	}

	/**
	 * @comment		Action (via push button "Join Vendor") on screen.
	 * 				Add vendor to the eRFQ.
	 */
	public int joinrfqvendor()
			throws MXException, RemoteException
	{
		DataBean databean = Utility.getDataBean(sessionContext, "quotations_quotations_vendorquotations_rfqvendorquo_table");

		RFQCustomRemote rfqremote = (RFQCustomRemote) getMboSet().getOwner();
		rfqremote.joinVendor();

		databean.refreshTable();
		sessionContext.queueRefreshEvent();
		
		int currentRow = databean.getCurrentRow();
		databean.save();
		databean.reloadTable();
		databean.setCurrentRow(currentRow);
		
		return 1;
	}

}
