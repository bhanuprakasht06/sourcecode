package com.psa.webclient.beans.appurl;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;

public class AppURLBean extends DataBean {

	public AppURLBean() {
		// TODO Auto-generated constructor stub
	}

	public int openLink() throws RemoteException, MXException
	{
		MboRemote currentMbo=app.getDataBean("load_url").getMbo();
		String urlPath=currentMbo.getString("URL");
		app.openURL(urlPath, true);
		return 1;
	}
	
	
}
