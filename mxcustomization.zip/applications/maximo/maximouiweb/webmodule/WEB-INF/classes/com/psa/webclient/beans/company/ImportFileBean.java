package com.psa.webclient.beans.company;


import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import com.ibm.ws.webservices.utils.BufferedWriter;
import com.psa.app.company.CompLogineRFQCustom;
import com.psa.app.company.CompLogineRFQCustomRemote;
import com.psa.app.company.CompLogineRFQCustomSet;
import com.psa.app.company.CompLogineRFQCustomSetRemote;
import com.psa.custom.common.MboConstantsCustom;

import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.NonPersistentMboSetRemote;
import psdi.mbo.custapp.CustomMboSetRemote;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.MXSession;
import psdi.webclient.beans.extsystem.LoadBean;
import psdi.webclient.controls.UploadFile;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.ControlInstance;
import psdi.webclient.system.controller.MPFormData;
import psdi.webclient.system.controller.PageInstance;
import psdi.webclient.system.controller.Utility;
import psdi.webclient.system.controller.WebClientEvent;
import psdi.webclient.system.runtime.WebClientRuntime;
import psdi.webclient.system.session.WebClientSession;

public class ImportFileBean extends DataBean {

	public ImportFileBean() {
		// TODO Auto-generated constructor stub
	}

	public  int loadData() throws MXException, IOException, MessagingException 
	{
		MboSetRemote companySet=MXServer.getMXServer().getMboSet("COMPANIES", MXServer.getMXServer().getUserInfo("MAXADMIN"));
		MboSetRemote userSet=MXServer.getMXServer().getMboSet("MAXUSER", MXServer.getMXServer().getUserInfo("MAXADMIN"));


		//Read data from file
		HttpServletRequest request = clientSession.getRequest();
		WebClientEvent wce = clientSession.getCurrentEvent();
		ControlInstance uploadfileControl = wce.getSourceControlInstance();
		String maxfilesize = uploadfileControl.getProperty("maxfilesize");
		MPFormData mpData = new MPFormData(request,Integer.parseInt(maxfilesize));		
		byte[] fileBytes = mpData.getFileOutputStream().toByteArray();
		String fullFileName=mpData.getFileName();
		String[] fileName=fullFileName.split(".csv");
		ByteArrayInputStream  btIn = new ByteArrayInputStream(fileBytes);
		BufferedReader reader=new BufferedReader(new InputStreamReader(btIn));

		//Data validation
		List<String> dataList = validateDataAndAddToList(companySet, userSet,reader);
		if(dataList.size()==0)
		{
			String[] params={"No data found"};
			throw new MXApplicationException("companies","loadData",params);
		}

		//Data import
		File file=loadDataFromList(companySet, dataList,fileName[0]);	
		sendEmail(file);
		file.delete();
		String[] params={"Data loaded successfully"};
		Utility.showMessageBox(sessionContext.getCurrentEvent(), "companies","loadData",params);
		return 1;
	}







	//Send email to user specified on the communication template with CC as the user who imported

	private void sendEmail(File file)
	
	{
		try
		{
		CommTemplateSetRemote commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
		commTemplateSet.setWhere("TEMPLATEID='SENDEMAIL'");
		commTemplateSet.reset();		
		MboRemote commTemplateRemote=commTemplateSet.getMbo(0);
		String emailBody=commTemplateRemote.getString("MESSAGE");
		String emailSubject=commTemplateRemote.getString("SUBJECT");
		String emailFrom=commTemplateRemote.getString("sendfrom");
		String emailCc=getMXSession().getUserInfo().getEmail();
		String emailTo=commTemplateRemote.getString("TOLIST");
		String[] files={file.getAbsolutePath()};
		
		MXServer.sendEMail(emailTo, emailCc, null, emailFrom, emailSubject, emailBody, null, files, null);	
		}catch(Exception e)
		{
			System.out.println("ERROR     : "+e.getMessage());
			e.printStackTrace();
		}
	}






	/*Validate company and user. 
	If it is wrong, throw error. 
	Else add data to list*/

	private List<String> validateDataAndAddToList(MboSetRemote companySet,
			MboSetRemote userSet, BufferedReader reader) throws IOException,
			RemoteException, MXException, MXApplicationException {

	//	MboSetRemote compLoginERFQSet=MXServer.getMXServer().getMboSet("COMPLOGINERFQ", MXServer.getMXServer().getUserInfo("MAXADMIN"));
		String[] lineData = {};
		int lineNumber=0;
		String fileData = null;
		String invalidData="";
		String companiesWithNoUser="";
		String companiesWithUser="";
		List<String> dataList=new ArrayList<String>();

		while((fileData = reader.readLine()) != null)
		{

			lineData=fileData.split(",");
			if(dataList.contains(fileData))
			{
				companiesWithUser=companiesWithUser+"\nLine "+lineNumber+" - "+"Company : "+lineData[0];
				continue;
			}
			if((lineNumber!=0)&&(lineData.length>1))
			{
				companySet.setWhere("COMPANY='"+lineData[0]+"'");
				userSet.setWhere("USERID='"+lineData[1]+"'");
				companySet.reset();
				userSet.reset();
				int userCount=userSet.count();
				int companyCount=companySet.count();
				if((companySet==null||companyCount==0)&&(userSet==null||userCount==0))
				{
					invalidData=invalidData+"\nLine "+lineNumber+" - "+"Company : "+lineData[0]+" , User : "+lineData[1];
				}
				else if(companySet==null||companyCount==0)
				{
					invalidData=invalidData+"\nLine "+lineNumber+" - "+"Company : "+lineData[0];
				}
				else if(userSet==null||userCount==0)
				{
					invalidData=invalidData+"\nLine "+lineNumber+" - "+"User : "+lineData[1];
				}
				dataList.add(fileData);

			}

			else if((lineNumber!=0)&&(lineData.length<=1))
			{
				companiesWithNoUser=companiesWithNoUser+"\nLine "+lineNumber+" - "+lineData[0];
			}
			lineNumber++;

		}
		if(!(companiesWithUser.equals("")))
		{

			String[] params={"The following data duplicated in file \n"+companiesWithUser};
			throw new MXApplicationException("companies","loadData",params);
		}
		else if(!(invalidData.equals("")))
		{

			String[] params={"Data could not be imported. The following data are invalid.\n"+invalidData};
			throw new MXApplicationException("companies","loadData",params);
		}
		else if(!(companiesWithNoUser.equals("")))
		{
			String[] params={"Data could not be imported. No userid specified for the following companies.\n"+companiesWithNoUser};
			throw new MXApplicationException("companies","loadData",params);
		} 
		return dataList;
	}




	//Load all the data from list

	private File loadDataFromList(MboSetRemote companySet, List<String> dataList,String fileName)
	throws MXException, IOException {
		MboSetRemote compLoginERFQSet;
		String[] lineData;
		String beforeImport="";
		String afterImport="";

		String filePath="/opt/psa/data/rw/emsscp/eRfq/ImportDetails.csv";
		CompLogineRFQCustom compLoginERFQRemote;

		File file = new File(filePath);
		FileWriter writer = new FileWriter(file);
		beforeImport=beforeImport+"\n***************  BEFORE  IMPORT eRFQ User Details ***************** \n\n";
		beforeImport=beforeImport+"COMPANY,USERID \n\n";

		afterImport=afterImport+" \n ***************  AFTER  IMPORT eRFQ User Details  ***************** \n\n";
		afterImport=afterImport+"COMPANY,USERID \n\n";

		for(int i=0;i<dataList.size();i++)
		{
			lineData=dataList.get(i).split(",");
			companySet.setWhere("COMPANY='"+lineData[0]+"'");
			companySet.reset();
			compLoginERFQSet=(CompLogineRFQCustomSet) companySet.getMbo(0).getMboSet("COMPLOGINERFQ");
			//compLoginERFQSet.setWhere("USERID='"+lineData[1]+"'");
			//compLoginERFQSet.reset();
			beforeImport=beforeImport+lineData[0]+",";
			afterImport=afterImport+lineData[0]+",";

			int count=compLoginERFQSet.count();
			if(count!=0)
			{
				compLoginERFQRemote=(CompLogineRFQCustom) compLoginERFQSet.getMbo(0);
				beforeImport=beforeImport+compLoginERFQRemote.getString("USERID")+" \n";
				afterImport=afterImport+lineData[1]+"\n";
				compLoginERFQRemote.setValue("USERID", lineData[1]);
				compLoginERFQRemote.setValue("MODIFIEDBY", getMXSession().getUserInfo().getUserName());
				compLoginERFQRemote.setValue("CREATEDDATE", MXServer.getMXServer().getDate());
				compLoginERFQSet.save();
			}
			else
			{

				compLoginERFQRemote=(CompLogineRFQCustom) compLoginERFQSet.add();
				beforeImport=beforeImport+"'' \n";
				afterImport=afterImport+lineData[1]+" \n";
				compLoginERFQRemote.setValue("USERID", lineData[1]);
				compLoginERFQRemote.setValue("CREATEDDATE", MXServer.getMXServer().getDate());
				compLoginERFQRemote.setValue("MODIFIEDBY", getMXSession().getUserInfo().getUserName());
				compLoginERFQSet.save();
			}

		}
		String totalImported=beforeImport+"\n"+afterImport;
		writer.write(totalImported);
		writer.close();

		return file;
	}



}
