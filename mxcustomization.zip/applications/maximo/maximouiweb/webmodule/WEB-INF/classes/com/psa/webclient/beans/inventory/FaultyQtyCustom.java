package com.psa.webclient.beans.inventory;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.Utility;
import psdi.webclient.system.controller.WebClientEvent;

import com.psa.app.inventory.CustomInvBatchSetRemote;

@SuppressWarnings("deprecation")
public class FaultyQtyCustom extends DataBean 
{

	public FaultyQtyCustom() 
	{
		
	}
	
	@Override
	protected MboSetRemote getMboSetRemote() 
			throws MXException, RemoteException 
	{		
		MboRemote pmRemote=app.getAppBean().getMbo();		
		MboSetRemote pmMeterSet=pmRemote.getMboSet("INVBATCH_DEFAULT");
		pmMeterSet.setWhere("");
		return pmMeterSet;
	}

	public synchronized int updateFaultyQty() throws MXException, RemoteException 
	{
		super.execute();
		MboRemote inventoryRemote=app.getAppBean().getMbo();		
		CustomInvBatchSetRemote invBatchRemoteSet=(CustomInvBatchSetRemote) inventoryRemote.getMboSet("INVBATCH_DEFAULT");
		System.out.println("---FaultyQtyCustom----------------inside updateFaultyQty()---------------------");	
		if(!invBatchRemoteSet.isEmpty())
		{
			for (MboRemote invBatchRemote = invBatchRemoteSet.moveFirst(); invBatchRemote != null; invBatchRemote = invBatchRemoteSet.moveNext())
			{
				String newFaultyQty_str = invBatchRemote.getString("NEWFAULTQTY");
				double newFaultyQty_decimal = invBatchRemote.getDouble("NEWFAULTQTY");
				System.out.println("---FaultyQtyCustom----------------NEWFAULTQTY String---------------------"+newFaultyQty_str);
				System.out.println("---FaultyQtyCustom----------------NEWFAULTQTY Decimal---------------------"+newFaultyQty_decimal);	
				if(!newFaultyQty_str.equalsIgnoreCase(""))
				{
					System.out.println("---FaultyQtyCustom----------------Current FAULTQTY---------------------"+invBatchRemote.getDouble("FAULTQTY"));
					System.out.println("---FaultyQtyCustom----------------Current Balance---------------------"+invBatchRemote.getDouble("CURBAL"));
					double newcurbal = invBatchRemote.getDouble("CURBAL") + invBatchRemote.getDouble("FAULTQTY") - newFaultyQty_decimal;
					if (newcurbal<0)
						throw new MXApplicationException("inventory", "negativeBalisNotAllowed");
					invBatchRemote.setValue("FAULTQTY", newFaultyQty_decimal, 2L);
					invBatchRemote.setValue("CURBAL", newcurbal, 2L);
				}				
			}			
		}
		invBatchRemoteSet.save();
		 Utility.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.sessionContext));
		    this.sessionContext.queueRefreshEvent();
		
		return 1;
	}
	
	

}


