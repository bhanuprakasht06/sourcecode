/*
 * Created  by BCT 
 * 
 * Work flow reassignment select action menu.
 * 
 * based on this action work flow assignment will assign to newly selected person.
 * 
 * 
 */
package com.psa.webclient.beans.workflow;

import java.rmi.RemoteException;

import psdi.app.person.PersonRemote;
import psdi.app.rfq.RFQRemote;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.MXSession;
import psdi.webclient.beans.common.StatefulAppBean;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.Utility;
import psdi.webclient.system.controller.WebClientEvent;

public class WFReassignCustom extends DataBean {

	private String count;
	public WFReassignCustom() {
		
	}

// this will get the value from the dialogue box and reassign the current RFQ to the specified user by updating the 
//	ASSIGNCODE attribute in WFASSIGNMENT object  
	  public void ASSTODEL()
	    throws RemoteException, MXException
	  {

		  WebClientEvent event = this.sessionContext.getCurrentEvent();
		  MboRemote getCurrentMbo=app.getAppBean().getMbo();
		  String selectUser=getCurrentMbo.getString("WFREASSIGN");
	 
		  if(!selectUser.equalsIgnoreCase(""))
		  {
			  MboSetRemote wfassignmentMboSet=getCurrentMbo.getMboSet("WFASSIGNMENT");
			  
			int count=wfassignmentMboSet.count();
			 
			  if(!wfassignmentMboSet.isEmpty() & wfassignmentMboSet!=null & count==1)
			  {
			
				  MboRemote wfassignMbo=wfassignmentMboSet.getMbo(0);
				 
				  		  wfassignMbo.setValue("ASSIGNCODE", selectUser,MboConstants.NOACCESSCHECK);
				
				  wfassignmentMboSet.save();
				
			      String[] param = { selectUser };
			
			        Utility.showMessageBox(event, "person", "AssignToDelegate",param);
				  }
			  if(!wfassignmentMboSet.isEmpty() & wfassignmentMboSet!=null & count!=1)
			 {
				  String[] param = { selectUser };
				 Utility.showMessageBox(event, "person", "AssignNoDelegate",param);  
			 }
			  Utility.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.sessionContext));
			    this.sessionContext.queueRefreshEvent();
		  	
	  }
	  }
	
}
