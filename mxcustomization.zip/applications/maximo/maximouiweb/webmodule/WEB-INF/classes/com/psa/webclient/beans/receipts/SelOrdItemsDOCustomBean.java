/*
 * Modification history
 * 15-08-2007	AGD	SR-098	Allow to enter the packing slip once for many lines
 */
package com.psa.webclient.beans.receipts;

import java.rmi.RemoteException;

import psdi.mbo.MboConstants;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;


public class SelOrdItemsDOCustomBean extends DataBean
{

	public SelOrdItemsDOCustomBean()
	{
	}


	public int copy()
			throws MXException, RemoteException
	{
		// Get the material receipt bean but if it's not a material receipt, get the service receipt bean
		DataBean receiptinputbean = app.getDataBean("selorditem");
		if (receiptinputbean == null)
		{
			receiptinputbean = app.getDataBean("selordserv");
		}
		

		// Make sure that we're reading the latest UI
		receiptinputbean.fireDataChangedEvent();

		// Exit if no row is selected
		if (receiptinputbean.getSelection().isEmpty())
			return 1;

		save();
		// Populate the packing slip from the current bean to the selected lines of the receipt bean
		for (int i = 0; i < receiptinputbean.count(); i++)
		{
			if (receiptinputbean.isSelected(i))
			{
//Begin modification DR-053
//				receiptinputbean.setValue(i, "packingslipnum", getString("packingslipnum"));
				receiptinputbean.setValue(i, "packingslipnum", getString("packingslipnum"), MboConstants.NOVALIDATION);
//End modification DR-053
			}
		}
		receiptinputbean.refreshTable();
		sessionContext.queueRefreshEvent();

		return 1;
	}

}
