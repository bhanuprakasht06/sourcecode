package com.psa.webclient.beans.invusage;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.StatefulMbo;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.beans.invusage.InvUseAppBean;
import psdi.webclient.system.beans.DataBean;

public class CustInvUseAppBean extends InvUseAppBean
{
	
	public int IssuesBatch()throws MXException, RemoteException
	{
		DataBean appBean = app.getAppBean();
		StatefulMbo mbo = (StatefulMbo)appBean.getMbo();
		MboSetRemote issuesSet = mbo.getMboSet("PSA_INVUSELINE_ISSUE");
		MboSetRemote invuseBatchSet = mbo.getMboSet("INVUSEBATCH");
		MboRemote batchtoAdd = null;
		if(issuesSet != null && !issuesSet.isEmpty())
		{
			double issueQty = 0 ;
			for(MboRemote issue = issuesSet.moveFirst(); issue != null; issue = issuesSet.moveNext())
			{
				
				issueQty = issue.getDouble("QUANTITY");
				MboSetRemote batchSet = issue.getMboSet("PSA_INVBALANCESBINLOT").getMbo(0).getMboSet("INVBATCHWITHQTY");
				batchSet.setOrderBy("BATCHDATE");
				batchSet.reset();
				double batchQty = 0;
				double alreadySetQty = 0;
				for(MboRemote batch = batchSet.moveFirst(); batch != null; batch = batchSet.moveNext())
				{
					double Qty = 0;
					MboSetRemote useBatchSet = issue.getMboSet("INVUSEBATCH");
					useBatchSet.deleteAll();
					batchtoAdd = invuseBatchSet.addAtEnd();
					batchtoAdd.setValue("invuselineid",issue.getString("invuselineid"), 2L);
					batchtoAdd.setValue("invusenum", issue.getString("invusenum"), 2L);
					batchtoAdd.setValue("itemnum",issue.getString("itemnum"), 2L);
					batchtoAdd.setValue("usagetype", "ISSUE", 2L);
					batchtoAdd.setValue("binnum", batch.getString("binnum"), 2L);
					batchtoAdd.setValue("CONDITIONCODE", batch.getString("CONDITIONCODE"), 2L);
					batchtoAdd.setValue("LOTNUM", batch.getString("LOTNUM"), 2L);
					batchtoAdd.setValue("refwo", issue.getString("refwo"), 2L);
					batchtoAdd.setValue("siteid", issue.getString("siteid"), 2L);
					batchtoAdd.setValue("orgid", issue.getString("orgid"), 2L);
					batchtoAdd.setValue("location", issue.getString("fromstoreloc"), 2L);
					batchtoAdd.setValue("tolocation", issue.getString("tostoreloc"), 2L);
					batchtoAdd.setValue("batchnum", batch.getString("batchnum"), 2L);
					batchtoAdd.setValue("changed", false, 2L);
					
					batchQty += batch.getDouble("CURBAL");
					if (batchQty >= issueQty)
					{
						Qty = issueQty-alreadySetQty;
						batchtoAdd.setValue("quantity", Qty, 2L);
						alreadySetQty += Qty;
						break;
					}
					else
						Qty = batch.getDouble("CURBAL");
					batchtoAdd.setValue("quantity", Qty, 2L);
					alreadySetQty += Qty;
				}
				if(alreadySetQty < issueQty)
				{
					invuseBatchSet.deleteAndRemove();
					
					throw new MXApplicationException("psa","invusage");
				}
			}
		}
		
		save();
		return 1;
	}
}
