/*
 * Modification history
 * 09-07-07	RHA		SR-099	Creation
 */

package com.psa.webclient.beans.rfq;

import java.rmi.RemoteException;
import psdi.app.rfq.RFQVendorRemote;
import psdi.app.rfq.RFQVendorSetRemote;
import psdi.util.MXException;
import psdi.webclient.beans.rfq.RFQAppBean;

/*
 * SR-099
 * Problem: Selection of RFQ lines is being repeated for each vendor quotation.
 * Function of class: To perform a one-time step only. All or some items can be selected.
 */
public class RFQAppCustomBean extends RFQAppBean {

	/**
	 * @comment		SIGOPTION: SELRFQLINEALLVENDORS
	 * @author		RHA
	 * @function	RFQAppCustomBean
	 * @date		9 July 2007
	 */
    public RFQAppCustomBean()
    {
    }
    
    public int SELRFQLINEALLVENDORS()
    throws MXException, RemoteException
	{
	    RFQVendorSetRemote rfqvendorsetremote = (RFQVendorSetRemote)parent.getMboSet(); 
	    
        //System.out.println("RFQAppCustomBean Iterating through the vendors.......... ");
	    int i = 0;
	    for(RFQVendorRemote rfqvendorremote; (rfqvendorremote = (RFQVendorRemote)rfqvendorsetremote.getMbo(i)) != null; i++)
		{
			//System.out.println("[RFQAppCustomBean RFQVendorSetRemote] row: " + i);
			rfqvendorremote.checkSentCompStatus("cannotCopyQuotation");	
		}	    
	    return 2;
	}
}
