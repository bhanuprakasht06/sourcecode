/*
 * Modification history
 * 22-07-2013--4.1.1	Creation Follow Up Work Order Custom Action in Work Order Application Select Action.  
 */

package com.psa.webclient.beans.workorder;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.webclient.beans.workorder.WorkorderAppBean;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.Utility;

import com.psa.app.workorder.WOCustom;

public class CustWorkorderAppBean extends WorkorderAppBean
{
	
	 public synchronized boolean custCreateFollowup()throws MXException, RemoteException
 {
	 System.out.println("###Inside CustWorkorderAppBean custCreateFollowup() method###");
     MboRemote mboRemote = getMbo();
     if(mboRemote != null)
     {
         if(mboRemote.toBeValidated())
             mboRemote.validate();
         MboRemote newMbo = ((WOCustom) mboRemote).custDuplicate();
         if(newMbo != null)
         {
             currentRow = mboSetRemote.getCurrentPosition();
             invalidateTableData();
             setCurrentRecordData(newMbo);
             if(saveCount > -1)
                 saveCount++;
             System.out.println("###Follow Up Work Order Created###");
             System.out.println("###Exiting CustWorkorderAppBean custCreateFollowup() method###");
             return true;
         }
     }
     System.out.println("###Follow Up Work Order Not Created###");
     System.out.println("###Exiting CustWorkorderAppBean custCreateFollowup() method###");
     return false;
 }

	public  int CREATEFWO()throws MXException, RemoteException
{
		 System.out.println("###Create Follow Up Work Order Event Called###");
		 DataBean appBean = app.getAppBean();
	        try
	        {
	            MboSetRemote appBeanWOSet = getMboSet();
	            if(appBeanWOSet != null)
	                if(appBeanWOSet.toBeSaved())
	                    appBeanWOSet.save();
	                else
	                    appBeanWOSet.reset();
	          // MboRemote woMbo = appBean.getMbo();
	           System.out.println("###Creating Follow Up Work Order###");
	           ((CustWorkorderAppBean) appBean).custCreateFollowup();
               sessionContext.queueRefreshEvent();
               gotoTab(sessionContext, "insert");
	          
	        }
	        catch(MXException mxe)
	        {
	            Utility.showMessageBox(sessionContext.getCurrentEvent(), mxe);
	        }
	        System.out.println("###Exiting CustWorkorderAppBean createFollowupWO() method ###");
	        return 1;
}
	

}
