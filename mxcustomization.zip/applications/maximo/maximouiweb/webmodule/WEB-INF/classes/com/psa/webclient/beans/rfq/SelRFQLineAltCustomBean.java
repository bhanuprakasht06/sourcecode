/*
 * Modification history
 * 15-10-07	AGD		NA		Creation
 */
package com.psa.webclient.beans.rfq;

import java.rmi.RemoteException;

import com.psa.app.rfq.RFQVendorCustomRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.webclient.beans.rfq.SelRFQLineBean;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.Utility;


public class SelRFQLineAltCustomBean extends SelRFQLineBean
{

	public SelRFQLineAltCustomBean()
	{
	}


	/*
	 * Get the list of all RFQ lines, whether selected before or not as a supplier can enter many alternate quotes
	 */
	public MboSetRemote getMboSetRemote()
			throws MXException, RemoteException
	{
		MboSetRemote rfqlineset = null;
		DataBean databean = Utility.getDataBean(sessionContext, "quotations_quotations_vendorquotations_rfqvendorquo_table");
		if (databean != null)
		{
			RFQVendorCustomRemote rfqvendor = (RFQVendorCustomRemote) databean.getMboSet().getMbo();
			rfqlineset = rfqvendor.getRFQLinesForQuotationAlt();
		}
		return rfqlineset;
	}


	/*
	 * Implement the OK button on the popup window
	 */
	public int execute()
			throws MXException, RemoteException
	{
		DataBean databean = Utility.getDataBean(sessionContext, "quotations_quotations_vendorquotations_rfqvendorquo_table");
		RFQVendorCustomRemote rfqvendor = (RFQVendorCustomRemote) databean.getMboSet().getMbo();
		MboSetRemote rfqlineset = getMboSet();
		rfqvendor.copyRFQToQuotationAlt(rfqlineset);
		int i = databean.getCurrentRow();
		databean.save();
		databean.setCurrentRow(i);
		databean.reloadTable();
		return 1;
	}

}
