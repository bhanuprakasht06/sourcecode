package com.psa.webclient.beans.multisite;

import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.ConnectionKey;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.MXSession;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.ControlHandler;
import psdi.webclient.system.controller.Utility;
import psdi.webclient.system.controller.WebClientEvent;

public class CustSiteContractBean extends DataBean
{
	protected void initialize() throws RemoteException, MXException
	{
		super.initialize();
	}
	
	public void applysitetoBA() throws RemoteException, MXException
	{
		MXSession session = sessionContext.getMXSession();
		WebClientEvent event = this.sessionContext.getCurrentEvent();
		ControlHandler triggerfield = creatingEvent.getSourceControl();
		String datasrc = triggerfield.getProperties().getString("datasrc");
		DataBean ownerBean = Utility.getDataBean(sessionContext, datasrc);
		MboRemote owner = ownerBean.getMbo();
		String orgid= owner.getString("ORGID");
		String siteid= getMbo().getString("SITEID");
		int noofcontracts=0;
		System.out.println("Dialog mbo name = "+getMbo().getName());
		System.out.println("Main mbo name = "+owner.getName());
		
		MXServer mxserver = MXServer.getMXServer();
		MboSetRemote contractSet = mxserver.getMboSet("PURCHVIEW", getMbo().getUserInfo());
		contractSet.setWhere("STATUS= 'APPR' and ORGID ='"+orgid+"' and contractnum not in (select contractnum from contractauth where authsiteid = '"+siteid+"' and authorgid = '"+orgid+"')");
		if(!contractSet.isEmpty())
			noofcontracts=contractSet.count();
		
		MboSetRemote contractauthset= session.getMboSet("CONTRACTAUTH");
		System.out.println("Total no of contract to be copied  = "+noofcontracts);
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;
		long id=0;
		MboRemote contract = null;
		
		for (int i= 0; ((contract=contractSet.getMbo(i))!= null); i++ )
			{
				System.out.println("contractauthset = "+contractauthset.isEmpty());
				System.out.println("currently processing  = "+contract.getString("CONTRACTNUM"));
				MboRemote contractauth = contractauthset.addAtEnd(MboConstants.NOACCESSCHECK);
				contractauth.setFlag(7L, false);
				contractauth.setValue("CONTRACTNUM", contract.getString("CONTRACTNUM"),MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
				contractauth.setValue("AUTHORGID", orgid,MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
				contractauth.setValue("AUTHSITEID", siteid,MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
				contractauth.setValue("VENDOR", contract.getString("VENDOR"),MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
				contractauth.setValue("BILLTO", "PSA HQ",MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
				contractauth.setValue("ORGID", contract.getString("ORGID"),MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
				contractauth.setValue("REVISIONNUM", contract.getInt("REVISIONNUM"),MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
				contractauth.setValue("ISDEFAULT", "1",MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
				contractauth.setValue("CONTRACTID", contract.getLong("CONTRACTID"),MboConstants.NOACCESSCHECK+MboConstants.NOVALIDATION_AND_NOACTION);
		  }
			contractauthset.save();
			contractauthset.commit();
			
		
		String[] param = { siteid, ""+noofcontracts+""};
		Utility.showMessageBox(event, "multisite", "applyba", param);
		Utility.sendEvent(new WebClientEvent("dialogclose", this.app.getCurrentPageId(), null, this.sessionContext));
	  
	}
	
}
