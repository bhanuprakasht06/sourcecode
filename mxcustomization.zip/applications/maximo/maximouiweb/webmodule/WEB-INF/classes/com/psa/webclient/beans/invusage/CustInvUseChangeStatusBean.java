package com.psa.webclient.beans.invusage;

import java.rmi.RemoteException;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.Translate;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.beans.invusage.InvUseChangeStatusBean;

public class CustInvUseChangeStatusBean extends InvUseChangeStatusBean
{

	public int execute()
		    throws MXException, RemoteException
	{
		Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
	    String status = translate.toInternalString("INVUSESTATUS", getString("status"));
	    if(status.equalsIgnoreCase("COMPLETE"))
	    {
	    	MboRemote invUse = getMbo().getOwner();
	    	MboSetRemote lineSet = invUse.getMboSet("psa_invuseline");
	    	MboSetRemote invUseLineBatchSet = null;
	    	MboSetRemote invBatchSet =null;
	    	for(MboRemote line = lineSet.moveFirst(); line != null ; line= lineSet.moveNext())
	        {
	    		invUseLineBatchSet = line.getMboSet("invusebatch");
	    		if(invUseLineBatchSet.isEmpty())
	    			throw new MXApplicationException("psa","nobatchSelected");
	    		
	    		        		
	    		if(invUseLineBatchSet != null && !invUseLineBatchSet.isEmpty())
	    		{
	    			if(line.getDouble("quantity") != invUseLineBatchSet.sum("quantity"))
	    			{
	    				Object[] params = { line.getString("INVUSELINENUM") };
	    				throw new MXApplicationException("psa","batchqtynotmatch", params);
	    			}
	    			else if ((line.getString("USETYPE").equalsIgnoreCase("ISSUE")) || line.getString("USETYPE").equalsIgnoreCase("TRANSFER"))
	    			{
	    				double invqty = 0;
	    				double invuselineqty = 0;
	    				for(MboRemote invuselinebatch = invUseLineBatchSet.moveFirst(); invuselinebatch != null ; invuselinebatch= invUseLineBatchSet.moveNext())
	    				{
	    					invBatchSet = invuselinebatch.getMboSet("invbatch");
	    					invqty = invBatchSet.sum("CURBAL");
	    					invuselineqty =  invuselinebatch.getDouble("quantity");
	    					if(invuselineqty > invqty)
	    					{
	    	    				Object[] params = { invuselinebatch.getString("ITEMNUM"), invuselinebatch.getString("BATCHNUM")};
	    						throw new MXApplicationException("psa", "negativeBatchBalisNotAllowed", params);
	    					}
	    				}
	    			}	    			
	    		}
	    		
	    		else		        			
	    			throw new MXApplicationException("psa","nobatchSelected");	        
	        }	        	
	    }
	    super.execute();
	    return 1;
	}
}
