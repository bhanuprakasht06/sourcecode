/*
 * Modification history 
 * 
 * 11-Nov-11 YCH Creation
 * 
 * This class is Data Bean to process OT transaction
 * 
 */
package com.psa.webclient.beans.labrep;

import java.rmi.RemoteException;
import java.util.Vector;

import com.psa.app.labor.LabTransCustomRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.beans.labrep.LabTransAppBean;;

public class LabTransAppCustomBean extends LabTransAppBean {
	
	public LabTransAppCustomBean()
	{
		
	}
	
	/*
	 * Verify OT transaction
	 * 1. Get selected OT transactions needed to be verified
	 * 2. Call Mbo object's verifyOTTransaction method to verify the OT Transaction
	 * 
	 * @Date 07 Nov 2011
	 * 
	 * @exception MXException, RemoteException
	 */
    public int VERIFYOT()
    	throws MXException, RemoteException
    {
    	try
    	{
    		System.out.println("VERIFYOT - Entering: " + MXServer.getMXServer().getDate());
    		Vector vector = getSelection();
    		int i = 0;
    		if (vector.size() == 0)
    			throw new MXApplicationException("labor", "NoOtTransSelectedForVerify");
    		if (sessionContext.runLongOp(this, "VERIFYOT"))
    		{
    			for (int j = vector.size(); j > i; i++)
    			{
    				LabTransCustomRemote labtransremote = null;
    				if ((labtransremote = (LabTransCustomRemote)vector.elementAt(i)) != null)
    					labtransremote.verifyOTTransaction(true);
    			}
    		}
    		
    		if (sessionContext.haslongOpCompleted())
    		{
    			save();
    			reset();
    			sessionContext.queueRefreshEvent();
    		}
    		
    		System.out.println("VERIFYOT - Leaving: " + MXServer.getMXServer().getDate());
    	}
    	catch (RemoteException remoteexception)
    	{
    		remoteexception.printStackTrace();
    	}    	
    	return 1;
    }
    
    /*
	 * Approve OT transaction
	 * 1. Get selected OT transactions needed to be approved
	 * 2. Call Mbo object's approveOTTransaction method to approve the OT Transaction
	 * 
	 * @Date : 07 Nov 2011
	 * 
	 * @exception RemoteException, MXException
	 */
    public int APPROT()
    	throws MXException, RemoteException
    {
    	try
    	{
    		System.out.println("APPROT - Entering: " + MXServer.getMXServer().getDate());
    		Vector vector = getSelection();
    		int i = 0;
    		if (vector.size() == 0)
    			throw new MXApplicationException("labor", "NoOtTransSelectedForApprove");
    		if (sessionContext.runLongOp(this, "APPROT"))
    		{
    			for (int j = vector.size(); j > i; i++)
    			{
    				LabTransCustomRemote labtransremote = null;
    				if ((labtransremote = (LabTransCustomRemote)vector.elementAt(i)) != null)
    					labtransremote.approveOTTransaction();
    			}
    		}
    		
    		if (sessionContext.haslongOpCompleted())
    		{
    			save();
    			reset();
    			sessionContext.queueRefreshEvent();
    		}
    		System.out.println("APPROT - Leaving: " + MXServer.getMXServer().getDate());
    	}
    	catch (RemoteException remoteexception)
    	{
    		remoteexception.printStackTrace();
    	}    	
    	return 1;
    }
    
    /*
	 * Unverify OT transaction
	 * 1. Get selected OT transactions needed to be unverified
	 * 2. Call Mbo object's unverifyOTTransaction method to verify the OT Transaction
	 * 
	 * @Date 18 Jan 2012
	 * 
	 * @exception MXException, RemoteException
	 */
    public int UNVERIFYOT()
    	throws MXException, RemoteException
    {
    	try
    	{
    		System.out.println("UNVERIFYOT - Entering: " + MXServer.getMXServer().getDate());
    		Vector vector = getSelection();
    		int i = 0;
    		if (vector.size() == 0)
    			throw new MXApplicationException("labor", "NoOtTransSelectedForUnVerify");
    		if (sessionContext.runLongOp(this, "UNVERIFYOT"))
    		{
    			for (int j = vector.size(); j > i; i++)
    			{
    				LabTransCustomRemote labtransremote = null;
    				if ((labtransremote = (LabTransCustomRemote)vector.elementAt(i)) != null)
    					labtransremote.unverifyOTTransaction();
    			}
    		}
    		
    		if (sessionContext.haslongOpCompleted())
    		{
    			save();
    			reset();
    			sessionContext.queueRefreshEvent();
    		}
    		System.out.println("UNVERIFYOT - Leaving: " + MXServer.getMXServer().getDate());
    	}
    	catch (RemoteException remoteexception)
    	{
    		remoteexception.printStackTrace();
    	}    	
    	return 1;
    }
}
