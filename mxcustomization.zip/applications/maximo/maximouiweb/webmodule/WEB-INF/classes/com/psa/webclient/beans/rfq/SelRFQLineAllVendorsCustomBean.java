/*
 * Modification history
 * 09-07-07	RHA		SR-099	Select all or some RFQ lines for all vendor
 */
package com.psa.webclient.beans.rfq;

import java.rmi.RemoteException;
import psdi.app.rfq.RFQLineRemote;
import psdi.app.rfq.RFQVendorRemote;
import psdi.app.rfq.RFQVendorSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.util.MXException;
import psdi.webclient.beans.rfq.SelRFQLineBean;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.controller.Utility;
import psdi.security.UserInfo;
import psdi.server.MXServer;


/**
 * @comment		Execution upon clicking "OK".
 * 				Action (via push button "Select RFQ Lines for All Vendors") on screen.
 * 				All selected lines items will be copied to all vendors.
 * 				If new vendors or items are added later, the action can be used again
 * 				and it will add the items as required.
 * 				This action is the same as the existing "Select RFQ Lines". The only difference 
 * 				is that the selected lines will be copied to all vendors.
 */
public class SelRFQLineAllVendorsCustomBean extends SelRFQLineBean {

	//Application: RFQ
	//Tab: Quotation
	public SelRFQLineAllVendorsCustomBean()
    {
		//Do nothing
    }


	//standard function overriding
	public int execute()
			throws MXException, RemoteException
	{
		DataBean databean = Utility.getDataBean(sessionContext, "quotations_quotations_vendorquotations_rfqvendorquo_table");

		//Get all vendors for this RFQ
		RFQVendorSetRemote rfqvendorsetremote = (RFQVendorSetRemote)databean.getMboSet();

		//Current RFQVendor (from superclass SelRFQLineBean):
		databean.getMbo();

		//System.out.println("SelRFQLineAllVendorsCustomBean Iterating through the vendors.......... ");
		int i = 0;
		for(RFQVendorRemote rfqvendorremote; (rfqvendorremote = (RFQVendorRemote)rfqvendorsetremote.getMbo(i)) != null; i++)
		{
			String vendor = rfqvendorremote.getString("vendor");
			copyRFQToQuotation(vendor);
		}

		//The lines below are standard from superclass SelRFQLineBean
		int k = databean.getCurrentRow();
		databean.save();
		databean.setCurrentRow(k);
		databean.reloadTable();
		return 1;
	}


	//This overloads the method in the superclass RFQVendor
	//public void copyRFQToQuotation(MboSetRemote mbosetremote)
	public void copyRFQToQuotation(String vendor)
			throws MXException, RemoteException
	{
		MboSetRemote mbosetremote = getMboSet();	//rfqline(s) not in current vendor's quotationline(s)
		if(mbosetremote.isEmpty())
	        return;

		String s = vendor;
		// System.out.println("[SelRFQLineAllVendorsCustomBean copyRFQToQuotation vendor] "+ s);
		int i = 0;
		do
		{
			MboRemote mboremote = mbosetremote.getMbo(i);
			if (mboremote != null)
			{
				// check if rfqline is already in the quotation
				boolean qlineexists = LineExists(mboremote.getString("rfqnum"), mboremote.getString("rfqlinenum"), vendor);
				if (mboremote.isSelected() && (qlineexists == false))
				{
					((RFQLineRemote) mboremote).copyRFQLinesToQuotationLines(s);
				}
				i++;
			}
			else
			{
				return;
			}
		} while (true);
	}


	/*
	 * This function checks if the rfqline already exists in the quotation line for a particular vendor in the RFQ
	 */
	public boolean LineExists(String rfqnum, String rfqlinenum, String vendor)
			throws MXException, RemoteException
	{
		boolean lineExists = true;
		MXServer mxserver = MXServer.getMXServer();
		UserInfo userinfo = getMboSet().getUserInfo();
		MboSetRemote mbosetremote = mxserver.getMboSet("QUOTATIONLINE", userinfo);
		SqlFormat sqlformat = new SqlFormat("rfqnum = '" + rfqnum + "' AND rfqlinenum = '" + rfqlinenum + "' AND vendor = '" + vendor + "' AND siteid = '" + getString("siteid") + "' AND orgid = '" + getString("orgid") + "'");
		mbosetremote.setWhere(sqlformat.format());

		if (mbosetremote.isEmpty())
		{
			lineExists = false;
		}
		return lineExists;
	}

}
