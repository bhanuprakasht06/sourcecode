package com.psa.app.user;

import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import psdi.app.signature.MaxUser;
import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboSetRemote;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import com.psa.custom.common.MxEmail;
import com.psa.custom.ois.MxLog;

public class customldapcrontask extends SimpleCronTask
{
        private MxEmail email;
        private String emailSubj;
        private MXLogger logger;
        private MxLog mxLog;
        private String logFilePath;
        private UserInfo userInfo;
        private MXServer mxserver;
        private ArrayList al;
        String[] arrParams = new String[8];

        public customldapcrontask()
        {
                logFilePath = null;
                userInfo = null;
                logger = MXLoggerFactory.getLogger("maximo.application.USER");
            emailSubj = null;
            al=new ArrayList();
        }

        public void init()throws MXException
        {
                System.out.println("ENTERING INIT()");
                super.init();
                email = new MxEmail();
                mxLog = new MxLog();
System.out.println("EXITING INIT()");
        }

        public void start()
        {
                try
                {
                        System.out.println("LDAP Entering Start()");
                        super.start();
                        logger.info((new StringBuilder(String.valueOf(getName()))).append(" Start").toString());
                        System.out.println((new StringBuilder(String.valueOf(getName()))).append(" Start").toString());
                                cacheResources();
                                setSleepTime(0L);
                }

                catch(Exception e)
                {
                        logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
                        System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());
                }
                System.out.println("LDAP Exiting START () ");
        }

        public CrontaskParamInfo[] getParameters() throws MXException,RemoteException
        {
                System.out.println("LDAP Entering CRONTASKPARAMINFO()");
                CrontaskParamInfo parameters[] = new CrontaskParamInfo[8];

                   parameters[0] = new CrontaskParamInfo();
                   parameters[0].setName("ldap_url");
                   parameters[0].setDescription("CommonCron","URL of ldap server");

                   parameters[1] = new CrontaskParamInfo();
                   parameters[1].setName("principal");
                   parameters[1].setDescription("CommonCron","LDAP user name");

                   parameters[2] = new CrontaskParamInfo();
                   parameters[2].setName("password");
                   parameters[2].setDescription("CommonCron","LDAP password");

                   parameters[3] = new CrontaskParamInfo();
                   parameters[3].setName("searchbase");
                   parameters[3].setDescription("CommonCron","LDAP search base");

                   parameters[4] = new CrontaskParamInfo();
                   parameters[4].setName("emailto");
                   parameters[4].setDescription("CommonCron", "Adminemailaddress");

                   parameters[5] = new CrontaskParamInfo();
                   parameters[5].setName("alertemailsubj");
                   parameters[5].setDescription("CommonCron", "EmailSubject");

                   parameters[6] = new CrontaskParamInfo();
                   parameters[6].setName("logfile");
                   parameters[6].setDescription("CommonCron", "LogDirectory");

                    parameters[7] = new CrontaskParamInfo();
                   parameters[7].setName("PNUSRROLE");
                   parameters[7].setDescription("CommonCron","PNUSRROLE");
                   System.out.println("LDAP Exiting CRONTASKINFO");
                return parameters;

        }

        public void cacheResources()
        {
                try
                {
                        arrParams[0] = getParamAsString("ldap_url");
                        arrParams[1] = getParamAsString("principal");
                        arrParams[2] = getParamAsString("password");
                        arrParams[3] = getParamAsString("searchbase");
                        arrParams[4] = getParamAsString("emailto");
                        arrParams[5] = getParamAsString("alertemailsubj");
                        arrParams[6] = getParamAsString("logfile");
                        arrParams[7] = getParamAsString("PNUSRROLE");

                }

                catch(Exception e)
                {
                        logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString(), e);
                        System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(e.getMessage()).toString());

                }

        }


        public void cronAction()
        {
        try
        {
                logger.debug((new StringBuilder(String.valueOf(getName()))).append(" Start of CronTask action").toString());
                System.out.println((new StringBuilder(String.valueOf(getName()))).append(" Start of CronTask action").toString());
                System.out.println("Parameter Check :"+parameterCheck(arrParams));
                logger.info("Parameter Check :"+parameterCheck(arrParams));

                if(parameterCheck(arrParams))
                {
                        if(readConfig())
                        {
                                if(processData())
                                {
                                        logger.info("LDAP Sync Successfull");
                                        System.out.println("LDAP Sync Successfull");
                                        mxLog.writeLog("LDAP Sync Successfull");
                                }
                                else
                                {
                                        throw new Exception("Error While Processing Data, LDAP SYNC may not be completed check logs");
                                }
                        }
                        else
                        {
                                throw new Exception("Error While Configuring Logging and Email, Check Logs For Error");
                        }
                }
                else
                {
                        throw new Exception("Some Parameter Values are left blank , please fill values.");
                }
                }
        catch(Exception e)
        {
                String message = e.getMessage();
                String stack = getStackTrace(e);
                logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
                System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
                if(mxLog.isEnabled())
                {
                mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
                }
                System.out.println("Email Genration : "+genEmail(message, stack));
                logger.info("Email Genration : "+genEmail(message, stack));
                email.send(emailSubj, genEmail(message, stack));
                logger.info((new StringBuilder(String.valueOf(getName()))).append(" Email sent").toString());
                stop();
        }


        }

        public boolean processData()
        {
                boolean flag = true;
                try
                        {
                        logger.info(getName()+" Cron Action, Inside Process Data");
                        System.out.println(getName()+" Cron Action, Inside Process Data");
                        mxLog.writeLog(getName()+" Cron Action, Inside Process Data");

                        Hashtable<String, String> env = new Hashtable();
                    env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
                    env.put(Context.PROVIDER_URL,getParamAsString("ldap_url"));
                    env.put( Context.SECURITY_PRINCIPAL, getParamAsString("principal"));
                    env.put( Context.SECURITY_CREDENTIALS,getParamAsString("password"));

                    logger.info(getName()+" Cron Action, Inside Process Data , Fetching all users");
                mxLog.writeLog(getName()+" Cron Action, Inside Process Data , Fetching all users");
                System.out.println(getName()+" Cron Action, Inside Process Data , Fetching all users");

                MboSetRemote msr=mxserver.getMboSet("MAXUSER",userInfo);

                logger.info(getName()+" Cron Action, Inside Process Data , Count For Total Users"+msr.count());
                                System.out.println(getName()+" Cron Action, Inside Process Data , Count For Total Users"+msr.count());
                                mxLog.writeLog(getName()+" Cron Action, Inside Process Data , Count For Total Users"+msr.count());

                                msr.setWhere("Status='ACTIVE'");
                                msr.reset();



                                MaxUser usermbo = null;
                                DirContext ctx = new InitialDirContext(env);
                                logger.info(getName()+" Cron Action, Inside Process Data connected to ldap, Count For Active Users"+msr.count());
                                System.out.println(getName()+" Cron Action, Inside Process Data connected to ldap, Count For Active Users"+msr.count());
                                mxLog.writeLog(getName()+" Cron Action, Inside Process Data , Count For Active Users"+msr.count());
                                for(int k=0; ((usermbo = (MaxUser)msr.getMbo(k))!= null);k++)
                        {
                                String username=usermbo.getString("userid");
                                String fltr=new String("uid="+username);
                            SearchControls ctls = new SearchControls();
                            String[] attrIDs = {"uid"};
                            String basedn=getParamAsString("searchbase");
                            //ctls.setReturningAttributes(attrIDs);
                            ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
                            Date d1=mxserver.getDate();

                            NamingEnumeration answer = ctx.search(basedn,fltr ,ctls );


                                if(!(answer.hasMore()))
                                {
                                        logger.info(getName()+" Cron Action, Inside Process Data , Changing Status For User "+username+ " to INACTIVE");
                                        System.out.println(getName()+" Cron Action, Inside Process Data , Changing Status For User "+username+ " to INACTIVE");
                                        mxLog.writeLog(getName()+" Cron Action, Inside Process Data , Changing Status For User "+username+ " to INACTIVE");
                                        usermbo.changeStatus("INACTIVE",d1, "LDAP SYNC TASK");
                                        MboSetRemote grp = usermbo.getMboSet("GROUPUSER");
                                                        if(!grp.isEmpty())
                                                        {
                                                                grp.deleteAll();
                                                                grp.save();
                                                        }

                                                        logger.info(getName()+" Cron Action, Inside Process Data , User "+username+ " is INACTIVE now");
                                        System.out.println(getName()+" Cron Action, Inside Process Data , User "+username+ " is INACTIVE now");
                                        mxLog.writeLog(getName()+" Cron Action, Inside Process Data , User "+username+ " is INACTIVE now");
                                    }
                                                 else
                {
	                System.out.println(getName()+" Cron Action, Inside Process Data , updating pnusrroles For User "+username );
                    mxLog.writeLog(getName()+" Cron Action, Inside Process Data , updating pnusrr For User "+username);
	                
                        // code to be done here
                        while (answer.hasMoreElements())
                        {
                                SearchResult si = (SearchResult)answer.next();
                                Attributes attrs = si.getAttributes();
                                if (attrs != null)
                                {
                                        // we have some attributes for this object
                                        NamingEnumeration ae = attrs.getAll();
                                        System.out.println("The ae is ---> " + ae);
                                        mxLog.writeLog((new StringBuilder("The ae is --->").toString()));
                                        while (ae.hasMoreElements())
                                        {
                                                Attribute attr = (Attribute)ae.next();
                                                String attrId = attr.getID();

                                                mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(" Attribute Defination for attribute--------------").append(attrId).toString());
                                                if(attrId.equalsIgnoreCase(getParamAsString("PNUSRROLE")))
                                                {
                                                // this object has the right attribute
                                                // get all the values of this attribute
                                                NamingEnumeration vals = attr.getAll();
                                                while (vals.hasMoreElements())
                                                {
                                                        String emailaddr = (String)vals.nextElement();
                                                        System.out.println("Attribute id is "+attrId+"Value for this attribute is "+emailaddr);
                                                        mxLog.writeLog((new StringBuilder("Attribute id is").append(attrId).append("Value is ").append(emailaddr).toString()));
                                                        al.add(emailaddr);
                                                }
                                                Iterator itr=al.iterator();
                                                StringBuffer sb=new StringBuffer();
                                                while(itr.hasNext())
                                                {
                                                        sb.append(itr.next().toString()+" ");

                                                }
                                                mxLog.writeLog(sb.toString()+"!!!!!!!!");
                                                usermbo.setValue("PNUSRROLE", sb.toString());
                                                //mxLog.writeLog(sb.toString()+"2222222");                                           
                                                al.removeAll(al);
                                                sb.delete(0, sb.length());
                                                usermbo.save();

                                                }
                                        }

                                }


                        }//while loop
                }//else loop


                        msr.save();
                        ctx.close();

                        }
                        }
                catch (Exception e)
                        {
                        String message = e.getMessage();
                        String stack = getStackTrace(e);
                        logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString(), e);
                        System.out.println((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append("\n").append(stack).toString());
                        mxLog.writeLog((new StringBuilder("ERROR ")).append(message).append("\n").append(stack).toString());
                        flag = false;
                        }
                return flag;
}

        public boolean parameterCheck(String []arrParams)
        {
                boolean bFlag = true;
                for (int iParamCount = 0; iParamCount < arrParams.length; iParamCount++)        // Iteration on Parameter values
                {
                        System.out.println("Parameter is "+iParamCount+ " Value Is @@@@"+arrParams[iParamCount]+"@@@");
                        if (arrParams[iParamCount] == null || arrParams[iParamCount].trim().equalsIgnoreCase("") || arrParams[iParamCount].trim() == "") // Check for null parameter values
                        {
                                bFlag = false;
                        }
                }

                return bFlag;
        }

        public boolean readConfig()
        {
                boolean flag = true;
                        try
                        {
                        mxserver = MXServer.getMXServer();
                        userInfo = getRunasUserInfo();
                        DateFormat fileDateFormat = new SimpleDateFormat("d-MMM-yy HH:mm");
                        String runtime = fileDateFormat.format(mxserver.getDate());
                        logFilePath = getParamAsString("logfile");
                        System.out.println("Log File Name : "+logFilePath);
                        logger.info("Log File Name : "+logFilePath);
                        if(logFilePath != null)
                        {
                                logFilePath = logFilePath.trim();
                                if(logFilePath.equals(""))
                                {

                                        logFilePath = null;
                                } else
                                {

                                        fileDateFormat = new SimpleDateFormat("yyMMddHHmm");
                                        runtime = fileDateFormat.format(mxserver.getDate());
                                        logFilePath = logFilePath.replaceAll("yyyymmddhhmm", runtime);
                                        mxLog.setEnabled(true);
                                        mxLog.setLogFilePath(logFilePath);
                                        mxLog.setLogTag(String.valueOf(getName()));
                                        mxLog.createLogFile();

                                }
                        }
                        email.setToMail(getParamAsString("emailto"));
                        Properties properties = mxserver.getConfig();
                        email.setFromMail(properties.getProperty("mxe.adminEmail", null));
                        emailSubj = getParamAsString("alertemailsubj");
                        }
                        catch(Exception e)
                        {
                                String message = e.getMessage();
                                String stack = getStackTrace(e);
                                logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
                                logger.error((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
                                mxLog.writeLog((new StringBuilder(String.valueOf(getName()))).append(" ").append(message).append(stack).append(". See log file for details").toString());
                                flag =  false;
                        }
                return flag;
        }

        public String getStackTrace(Exception e)
        {
                String stack = "";
                StackTraceElement element[] = e.getStackTrace();
                for(int i = 0; i < element.length; i++)
                        stack = (new StringBuilder(String.valueOf(stack))).append("\tat ").append(element[i].toString()).append("\n").toString();

                        //System.out.println("Stack Trace Is : "+stack);
                        //logger.info("Stack Trace Is : "+stack);
                        //mxLog.writeLog("Stack Trace Is : "+stack);
                        return stack;
        }

        public String genEmail(String error, String stack)
        {
                String emailMsg = (new StringBuilder("Date: ")).append(new Date()).append("\n").append("Error Message: ").append(error).append("\n").append(stack).toString();
                System.out.println("Email Msg  Is : "+emailMsg);
                logger.info("Email Msg Is : "+emailMsg);
                mxLog.writeLog("Email Msg Is : "+emailMsg);
                return emailMsg;
        }
}
