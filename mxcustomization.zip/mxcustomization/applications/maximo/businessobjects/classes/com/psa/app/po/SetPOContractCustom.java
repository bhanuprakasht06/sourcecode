/*
 * Modification history
 * 
 */

package com.psa.app.po;

import java.rmi.RemoteException;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.mbo.MboConstants;


public class SetPOContractCustom
implements ActionCustomClass
{

public SetPOContractCustom()
{
}


public void applyCustomAction(MboRemote mboremote, Object param[])
        throws MXException, RemoteException
{

//System.out.println("old contract:"+mboremote.getString("CONTRACTREFNUM"));

   String contract="BA"+mboremote.getString("CONTRACTREFNUM");
   
//  System.out.println("new contract:"+contract);

  mboremote.setValue("CONTRACTREFNUM",contract,11L);

/*	MboSetRemote poset = mboremote.getMboSet("PRLINE");
MboRemote prline = prlineset.getMbo(0);
MboSetRemote woset = prline.getMboSet("WORKORDER");
MboRemote wo = woset.getMbo(0);


if(wo.getString("DPBUYER").equals(""))
{
        mboremote.setValue("SHIPTOATTN",wo.getString("PRAPPROVEDBY"));
        mboremote.setValue("BILLTOATTN",wo.getString("PRAPPROVEDBY"));
}
else
{
        mboremote.setValue("SHIPTOATTN",wo.getString("DPBUYER"));
        mboremote.setValue("BILLTOATTN",wo.getString("DPBUYER"));
}*/
}
}
