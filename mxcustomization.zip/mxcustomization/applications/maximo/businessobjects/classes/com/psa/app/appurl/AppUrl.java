package com.psa.app.appurl;

import java.rmi.RemoteException;
import java.util.Iterator;

import psdi.mbo.Mbo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueInfo;
import psdi.mbo.custapp.CustomMbo;
import psdi.util.MXException;

public class AppUrl extends CustomMbo {

	public AppUrl(MboSet ms) throws RemoteException {
		super(ms);
		// TODO Auto-generated constructor stub
	}
	
	public void init() throws MXException {
		// TODO Auto-generated method stub
		super.init();
		String[] readOnlyAfterSave={"DESCRIPTION","URL"};
		if (!toBeAdded()) {
			setFieldFlag(readOnlyAfterSave, MboConstants.READONLY, true);
		}
	}
	public void add() throws MXException, RemoteException {
		// TODO Auto-generated method stub
		super.add();
		String appName=getOwner().getThisMboSet().getApp();
		if (appName.equalsIgnoreCase("ASSET")) {
			setValue("APPREFID", getOwner().getString("ASSETNUM"));			
		}
		else if (appName.equalsIgnoreCase("PM")) {
			setValue("APPREFID", getOwner().getString("PMNUM"));			
		}
		else if (appName.equalsIgnoreCase("ITEM")) {
			setValue("APPREFID", getOwner().getString("ITEMNUM"));			
		}
		else if (appName.equalsIgnoreCase("LOCATION")) {
			setValue("APPREFID", getOwner().getString("LOCATION"));			
		}
		
		setValue("SITEID", getOwner().getString("SITEID"));		

	}
	

	
}
