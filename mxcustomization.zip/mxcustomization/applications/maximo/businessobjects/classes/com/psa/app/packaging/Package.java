// Decompiled by DJ v3.0.0.63 Copyright 2002 Atanas Neshkov  Date: 8/16/2009 11:03:49 AM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CustomMbo.java

package com.psa.app.packaging;

import java.rmi.RemoteException;
import psdi.mbo.*;
import psdi.util.MXException;
import psdi.server.AppService;
import java.util.*;
import java.rmi.*;
import psdi.util.MXApplicationException;

// Referenced classes of package psdi.mbo.custapp:
//            CustomMboRemote

public class Package extends Mbo
    implements PackageRemote
{

    public Package(MboSet ms)
        throws MXException, RemoteException
    {
    	
        super(ms);
        System.out.println("--Package SAVE AE--");
    }

	public void copyReserveItem(MboSetRemote sourceLineSet)
		throws MXException, RemoteException
	{
		if (sourceLineSet.isEmpty())
		return;
		Vector reserveLineSize = sourceLineSet.getSelection();
		if (reserveLineSize.size() == 0)
			return;
		sourceLineSet.setOrderBy("wonum, itemnum");
		sourceLineSet.resetWithSelection();
		MboSetRemote mboLineSet = getMboSet("PACKAGELINE");       
		int i = 0;
		while (true)
		{
			MboRemote sourceLine = sourceLineSet.getMbo(i);
			if (sourceLine == null)
				break;
			MboRemote newLine = mboLineSet.add();		
			newLine.setValue("ITEMNUM", sourceLine.getString("ITEMNUM"), 2L);
			newLine.setValue("QTY", sourceLine.getDouble("RESERVEDQTY"), 2L);
			++i;
		}
	}
	/*public void add() 
		throws MXException, RemoteException 
	{
		System.out.println("--inside add()--");
		super.add();

		Date currentDate = ((AppService)getMboServer()).getMXServer().getDate();
		//setValue("CREATEDBY", getUserName(), 2L);	
		//setValue("CREATEDATE", currentDate, 11L);
		//String site = getUserInfo().getInsertSite();		
		//setValue("SITEID", site, 11L);
		//setValue("STATUS", "NEW", 2L);
		if (isNew())
		{
    		setFieldFlag("PONUM", 7L, false);
    		setFieldFlag("WONUM", 7L, false);
		} 
	}*/

	public void save() 
		throws MXException, RemoteException 
	{
		super.add();
		System.out.println("--SAVE BE--");
		super.save();
		System.out.println("--SAVE AE--");
	}


	public void init()
	throws MXException
{
try
{
    super.init(); 
	System.out.println("--inside init()--");
if(!isNew())
{
    String alwaysReadOnly[] = {"SITEID", "CREATEDATE", "CREATEDBY","PACKAGEID","WONUM","PONUM","STORELOC"};    
    setFieldFlag(alwaysReadOnly, 7L, true);
}
System.out.println("--inside init()-- Complete");
}
catch (RemoteException e)
{
e.printStackTrace();
   
}

}


    public MboRemote duplicate()
        throws MXException, RemoteException
    {
        return copy();
    }

	public void copyInvReserveSetForIssues(MboSetRemote invReserveSet)
		throws RemoteException, MXException
	{
		String packageStatus = getString("STATUS");
	    	if(packageStatus.equalsIgnoreCase("CAN") || packageStatus.equalsIgnoreCase("ISSUED") || packageStatus.equalsIgnoreCase("TRANSFER"))
			throw new MXApplicationException("package", "YouCanAddLine");
		PackageLinesSetRemote packSet = (PackageLinesSetRemote)getMboSet("PACKAGE");
		packSet.copyInvReserveSet(invReserveSet);
	}

    protected boolean skipCopyField(MboValueInfo mvi)
        throws RemoteException, MXException
    {
        return !mvi.getAttributeName().equalsIgnoreCase("SITEID") && !mvi.getAttributeName().equalsIgnoreCase("ORGID") && mvi.isKey();
    }
}