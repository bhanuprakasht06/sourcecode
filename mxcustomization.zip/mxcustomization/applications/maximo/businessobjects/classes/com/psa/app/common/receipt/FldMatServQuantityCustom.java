/**
 * @author	HCHA
 * Date		Nov 24, 2006
 * Comment	 
 */
package com.psa.app.common.receipt;

import psdi.mbo.MboValue;
import java.rmi.RemoteException;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.app.common.receipt.FldMatServQuantity;
import psdi.app.inventory.*;
import psdi.mbo.*;
import psdi.app.labor.*;

/**
 * @author		HCHA
 * @class		FldMatServQuantityCustom
 * @date		Nov 24, 2006
 * @function	SR-028 (Enhancement is aimed at preventing users from receiving more items than received.)
 */
public class FldMatServQuantityCustom extends FldMatServQuantity {

	/**
	 * @param arg0
	 */
	public FldMatServQuantityCustom(MboValue arg0) {
		super(arg0);

	}
	
    public void validate()
	    throws MXException, RemoteException
	{
	    Mbo mbo = getMboValue().getMbo();
	    String s = "";
	    double d = 0.0D;
	    if((mbo instanceof MatRecTransRemote) || (mbo instanceof ServRecTransRemote) && getMboValue().getDouble() > 0.0D)
	    {
	        double d3 = 0.0D;
	        double d6 = 0.0D;
	        String s1 = "";
	        if(mbo instanceof MatRecTransRemote)
	        {
	            double d1;
	            if(!mbo.isNull("conversion") && mbo.getDouble("conversion") != 0.0D)
	                d1 = getMboValue().getDouble() / mbo.getDouble("conversion");
	            else
	                d1 = getMboValue().getDouble();
	            MatRecTrans matrectrans = (MatRecTrans)mbo;
	            double d4 = matrectrans.getRemainingQty();
	            if(matrectrans.getPOLine() != null)
	            {
	                String s2 = matrectrans.getPOLine().getString("polinenum");
	                double d7 = matrectrans.getPOLine().getDouble("orderqty");
	                if(d1 > d4)
	                {
	                    Object aobj[] = {
	                        s + d1, s2, s + d7, s + (d1 - d4)
	                    };
	                    //Throws an exception instead of the warning
	                    throw new MXApplicationException("inventory", "OrderQuantityExceeded", aobj);
	                }
	            }
	        } else
	        {
	            ServRecTrans servrectrans = (ServRecTrans)mbo;
	            MboRemote mboremote = servrectrans.getMboSet("POLINE").getMbo(0);
	            String s3 = mboremote.getString("polinenum");
	            double d8 = mboremote.getDouble("orderqty");
	            double d2 = getMboValue().getDouble();
	            double d5 = mboremote.getDouble("orderqty") - mboremote.getDouble("receivedqty");
	            if(d2 > d5)
	            {
	                Object aobj1[] = {
	                    s + d2, s3, s + d8, s + (d2 - d5)
	                };
	                //Throws an exception instead of the warning
	                throw new MXApplicationException("inventory", "OrderQuantityExceeded", aobj1);
	            }
	        }
	    }
	}
}
