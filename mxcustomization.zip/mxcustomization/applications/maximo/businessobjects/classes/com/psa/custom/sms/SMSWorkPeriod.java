package com.psa.custom.sms;

import java.rmi.RemoteException;

import psdi.app.calendar.WorkPeriodRemote;
import psdi.app.calendar.WorkPeriodSetRemote;
import psdi.iface.mic.MicSetIn;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.CombineWhereClauses;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

/*
 * Author: BTE
 * 05 APR 2006 - Initial version
 */
public class SMSWorkPeriod extends MicSetIn {
	
	/*
	 * Variables
	 */	 
	private UserInfo userInfo;
	private static SMSConstant SMS = new SMSConstant();
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - constructor  
	 */	
	public SMSWorkPeriod(UserInfo userInfo) throws MXException, RemoteException {		 
		this.userInfo = userInfo;	   
	}
	 
	 	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Check workperiod exists in database based on orgid, CalNum and workdate.  
	 */	
	public boolean isWorkperiodExist(String orgid, String calNum, String workDate) 
	 	throws MXException, RemoteException {
	   
        INTEGRATIONLOGGER.debug("Entering isWorkperiodExist");
        
		// Check if vaiables is null
		if(orgid == null || calNum == null ) {
	        INTEGRATIONLOGGER.debug("Leaving isWorkperiodExist");
	        return false;
		}
		 
		WorkPeriodSetRemote workPeriodSet = (WorkPeriodSetRemote) MXServer.getMXServer().getMboSet(SMS.WORKPERIOD, userInfo);
				
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
	
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("CALNUM= :2");
		combinewhereclauses.addWhere("WORKDATE= :3");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.WORKPERIOD, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.WORKPERIOD, SMS.CALNUM, calNum);
			sqlformat.setObject(3, SMS.WORKPERIOD, SMS.WORKDATE, workDate);
			workPeriodSet.setWhere(sqlformat.format());
			
			if(!workPeriodSet.isEmpty()) {
		
				WorkPeriodRemote workPeriodRemote = (WorkPeriodRemote) workPeriodSet.getMbo(0);
		
				if(!workPeriodRemote.isNull(SMS.WORKDATE)){
			        INTEGRATIONLOGGER.debug("Leaving isWorkperiodExist");
					return true;
				}
			}
		}			
			
        INTEGRATIONLOGGER.debug("Leaving isWorkperiodExist");
		return false;		   
	}
	 
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Add or Change workperiod in database based on orgid and calnum.  
	 */
	public void addChangeWorkPeriod(String orgid, String calNum, String workDate, String startTime, String endTime, String shiftNum)
		throws MXException, RemoteException {

        INTEGRATIONLOGGER.debug("Entering addChangeWorkPeriod");
        
		if (isWorkperiodExist(orgid, calNum, workDate)) {
			if (!updateWorkPeriod(orgid,  calNum, workDate, startTime, endTime, shiftNum)){
				throw new MXApplicationException(SMS.IFACE, SMS.WORKPERIOD_UPDATE_ERROR);
			}
			
		} else {
			if (!addWorkPeriod(orgid,  calNum, workDate, startTime, endTime, shiftNum)) {
				throw new MXApplicationException(SMS.IFACE, SMS.WORKPERIOD_CREATE_ERROR);
			}
		}
		
        INTEGRATIONLOGGER.debug("Leaving addChangeWorkPeriod");
	}
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Add workperiod in database based on orgid and calnum.  
	 */
	public boolean addWorkPeriod(String orgid, String calNum, String workDate, String startTime, String endTime, String shiftNum) 
 		throws MXException, RemoteException {
	   
        INTEGRATIONLOGGER.debug("Entering addWorkPeriod");
        
		// Check if vaiables is null
		if(orgid == null || calNum == null ) {
	        INTEGRATIONLOGGER.debug("Leaving addWorkPeriod");
	        return false;
		}
		 
		WorkPeriodSetRemote workPeriodSet = (WorkPeriodSetRemote) MXServer.getMXServer().getMboSet(SMS.WORKPERIOD, userInfo);		
				
		workPeriodSet.add(0);
		workPeriodSet.setValue(SMS.ORGID, orgid);
		workPeriodSet.setValue(SMS.WORKDATE, workDate);
		workPeriodSet.setValue(SMS.CALNUM, calNum);
		workPeriodSet.setValue(SMS.STARTTIME, startTime);
		workPeriodSet.setValue(SMS.ENDTIME, endTime);
		workPeriodSet.setValue(SMS.SHIFTNUM, shiftNum);
		
		workPeriodSet.save(0);
		workPeriodSet.commit();		
		workPeriodSet.close();
			
        INTEGRATIONLOGGER.debug("Leaving addWorkPeriod");
		return true;													   
	}
	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Change workperiod in database based on orgid and calnum.  
	 */
	public boolean updateWorkPeriod(String orgid, String calNum, String workDate, String startTime, String endTime, String shiftNum) 
 		throws MXException, RemoteException {
	   		
        INTEGRATIONLOGGER.debug("Entering updateWorkPeriod");
        
		// Check if vaiables is null
		if(orgid == null || calNum == null || workDate == null) {
	        INTEGRATIONLOGGER.debug("Leaving updateWorkPeriod");
	        return false;
		}
		 
		WorkPeriodSetRemote workPeriodSet = (WorkPeriodSetRemote) MXServer.getMXServer().getMboSet(SMS.WORKPERIOD, userInfo);
			
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
		
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("CALNUM= :2");
		combinewhereclauses.addWhere("WORKDATE= :3");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.WORKPERIOD, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.WORKPERIOD, SMS.CALNUM, calNum);
			sqlformat.setObject(3, SMS.WORKPERIOD, SMS.WORKDATE, workDate);			
			workPeriodSet.setWhere(sqlformat.format());

			
			if(!workPeriodSet.isEmpty()) {
				
				WorkPeriodRemote workPeriodRemote = (WorkPeriodRemote) workPeriodSet.getMbo(0);
				
				if(!workPeriodRemote.isNull(SMS.WORKDATE)){
					
					workPeriodSet.getMbo(0).setValue(SMS.STARTTIME, startTime);			
					workPeriodSet.getMbo(0).setValue(SMS.ENDTIME, endTime);
					workPeriodSet.getMbo(0).setValue(SMS.SHIFTNUM, shiftNum);				

					workPeriodSet.save(0);				
					workPeriodSet.commit();	
					workPeriodSet.close();	
					
					INTEGRATIONLOGGER.debug("Leaving updateWorkPeriod");
					return true;
				}				
			}
		}			
			
		INTEGRATIONLOGGER.debug("Leaving updateWorkPeriod");
		return false;			   
	}		
	
	
	/*
	 * Author: BTE
	 * 06 APR 2006 - Change workperiod Starttime and endtime in database based on orgid and calnum.  
	 */
	public boolean updateWorkPeriodTime(String orgid, String calNum, String workDate, String startTime, String endTime, String shiftNum) 
 		throws MXException, RemoteException {
		
        INTEGRATIONLOGGER.debug("Entering updateWorkPeriodTime");
        
		// Check if vaiables is null
		if(orgid == null || calNum == null || workDate == null) {
	        INTEGRATIONLOGGER.debug("Leaving updateWorkPeriodTime");
	        return false;
		}
		 
		WorkPeriodSetRemote workPeriodSet = (WorkPeriodSetRemote) MXServer.getMXServer().getMboSet(SMS.WORKPERIOD, userInfo);
			
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
		
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("CALNUM= :2");
		combinewhereclauses.addWhere("WORKDATE= :3");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.WORKPERIOD, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.WORKPERIOD, SMS.CALNUM, calNum);
			sqlformat.setObject(3, SMS.WORKPERIOD, SMS.WORKDATE, workDate);			
			workPeriodSet.setWhere(sqlformat.format());

			
			if(!workPeriodSet.isEmpty()) {
				
				WorkPeriodRemote workPeriodRemote = (WorkPeriodRemote) workPeriodSet.getMbo(0);
				
				if(!workPeriodRemote.isNull(SMS.WORKDATE)){
					
					workPeriodSet.getMbo(0).setValue(SMS.STARTTIME, startTime);			
					workPeriodSet.getMbo(0).setValue(SMS.ENDTIME, endTime);			

					workPeriodSet.save(0);				
					workPeriodSet.commit();	
					workPeriodSet.close();	
					
			        INTEGRATIONLOGGER.debug("Leaving updateWorkPeriodTime");
					return true;
				}				
			}
		}			
			
        INTEGRATIONLOGGER.debug("Leaving updateWorkPeriodTime");
		return false;			   
	}

	
	
	/*
	 * Author: BTE
	 * 05 APR 2006 - Replace workperiod
	 */
    public void replaceWorkPeriod(String orgid, String calNum, String workDate) throws MXException, RemoteException {
    	
        INTEGRATIONLOGGER.debug("Entering replaceWorkPeriod");
        
     	MboSetRemote workPeriodSet = (MboSetRemote) MXServer.getMXServer().getMboSet(SMS.WORKPERIOD, userInfo);	    	
		
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
		
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("CALNUM= :2");
		combinewhereclauses.addWhere("WORKDATE= :3");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.WORKPERIOD, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.WORKPERIOD, SMS.CALNUM, calNum);
			sqlformat.setObject(3, SMS.WORKPERIOD, SMS.WORKDATE, workDate);  			    			
			workPeriodSet.setWhere(sqlformat.format());   
			
			if(!workPeriodSet.isEmpty()) {   				
				
				workPeriodSet.deleteAll(0L);
				
				workPeriodSet.save();
				workPeriodSet.commit();
				workPeriodSet.close();	
			}			
		}    	
		
        INTEGRATIONLOGGER.debug("Leaving replaceWorkPeriod");
    }
    
    
    /*
	 * Author: BTE
	 * 05 APR 2006 - Getter non work time shift
	 */
    public boolean isShift(String orgid, String shiftnum) throws MXException, RemoteException  { 

        INTEGRATIONLOGGER.debug("Entering isShift");
        
     	MboSetRemote shiftSet = (MboSetRemote) MXServer.getMXServer().getMboSet(SMS.SHIFT, userInfo);	    	
		
		CombineWhereClauses combinewhereclauses = new CombineWhereClauses();
		
		combinewhereclauses.addWhere("ORGID= :1");
		combinewhereclauses.addWhere("SHIFTNUM= :2");
		String s = combinewhereclauses.getWhereClause();
	
		if(s != null && s != ""){
			SqlFormat sqlformat = new SqlFormat(userInfo, s);
		
			sqlformat.setObject(1, SMS.SHIFT, SMS.ORGID, orgid);
			sqlformat.setObject(2, SMS.SHIFT, SMS.SHIFTNUM, shiftnum);  			    			
			shiftSet.setWhere(sqlformat.format());   
			
			if(!shiftSet.isEmpty()) {
		        INTEGRATIONLOGGER.debug("Leaving isShift");
				return true;
			}
		}
    	
        INTEGRATIONLOGGER.debug("Leaving isShift");		
    	return false;
    } 
}
