/*
 * Modification history
 * 22-07-2013--4.2.6	Creation For Validation of Quantity to Return with respect to Received Quantity.  
 */

package com.psa.app.labor;

import java.rmi.RemoteException;

import psdi.app.common.receipt.ReceiptMbo;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class FldRetQuantityCustom extends MboValueAdapter
{
	 public FldRetQuantityCustom(MboValue mbv)
	  {
	    super(mbv);
	  }
	 
	 public void validate() throws MXException, RemoteException
	  {
		 System.out.println("Inside Quantity To Return Field Validation Class");
		 super.validate();
		 ReceiptMbo servicereceipt = (ReceiptMbo)getMboValue().getMbo();
		 
		 if(!getMboValue().isNull())
		 	{
			 System.out.println("RETQUANTITY is not null");
			 if(getMboValue().getDouble() > servicereceipt.getPOLine().getDouble("RECEIVEDQTY"))
			 {
				 System.out.println("Quantity to Return is Greater Than Received Quantity");
				 System.out.println("Quantity To Return "+getMboValue().getDouble());
				 System.out.println("Quantity Received "+servicereceipt.getPOLine().getDouble("RECEIVEDQTY"));
				 throw new MXApplicationException("inventory", "returnMoreThanReceipt");
			 }
		 	}
	  }
}
