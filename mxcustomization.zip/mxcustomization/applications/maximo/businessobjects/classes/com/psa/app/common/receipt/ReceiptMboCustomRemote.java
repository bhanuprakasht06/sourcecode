package com.psa.app.common.receipt;

import java.rmi.RemoteException;

import psdi.app.common.receipt.ReceiptMboRemote;
import psdi.mbo.MboRemote;
import psdi.util.MXException;


public interface ReceiptMboCustomRemote
		extends ReceiptMboRemote
{

	public void emailForLD(MboRemote receipt)
			throws MXException, RemoteException;

}
