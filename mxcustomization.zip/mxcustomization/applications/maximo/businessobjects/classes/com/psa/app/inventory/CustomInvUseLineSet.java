package com.psa.app.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.InvUseLineSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class  CustomInvUseLineSet extends InvUseLineSet 
	implements CustomInvUseLineSetRemote 
{
	public CustomInvUseLineSet (MboServerInterface mboserverinterface) 
		throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}
	
	protected Mbo getMboInstance(MboSet mboset) 
		throws MXException, RemoteException
	{
		return (new CustomInvUseLine(mboset));
	}
}
