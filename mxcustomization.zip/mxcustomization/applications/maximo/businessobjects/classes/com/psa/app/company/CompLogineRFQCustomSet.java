/*
 * Modification history
 * 28-09-07	AGD	NA		Creation
 */
package com.psa.app.company;

import java.rmi.RemoteException;


import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class CompLogineRFQCustomSet extends MboSet
		implements CompLogineRFQCustomSetRemote
{

	public CompLogineRFQCustomSet(MboServerInterface mboserverinterface)
			throws MXException, RemoteException
	{
		super(mboserverinterface);
	}


	protected Mbo getMboInstance(MboSet comploginset)
			throws MXException, RemoteException
	{
		return new CompLogineRFQCustom(comploginset);
	}

}
