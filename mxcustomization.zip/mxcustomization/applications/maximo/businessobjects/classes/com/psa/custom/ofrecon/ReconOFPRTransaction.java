/*
  * Created  by BCT 
 * 
 *  
 * This cron is used for  Reconciling check between OF Receipts transaction and Maximo
 * Maximo will receive the Flat file from Del Bomi and put into Location
 * The flat file first file contains all the Maximo objects
 * Flat file from the second line contains the data
 * The flat file second line first component contains the object:attrbuteID (LABTRANS:12345)
 * Based on the Object and AttributeID, need to check in Maximo
 * if data is present need to check the cost(LOADEDCOST). 
 * If the value is matching, update the the following fields OA_RECONDATETIME,OA_COA,OA_LINECOST
 * if data is not present then send error message
 * 
 */
package com.psa.custom.ofrecon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.mail.MessagingException;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;
import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskParamInfo;
import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class ReconOFPRTransaction extends SimpleCronTask {
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	private static final String DATE_TIME_FORMAT = "yyyyMMdd";


	private String adminEmail;
	private String adminEmailSub;
	private String outPutDirectory;
	private String tempProcessFolder;
	private String processFolder;
	private String backupFileFolder;
	private String importFileName;
	private String splitTag;
	private String unzipCmd;
	private MxEmail email;
	protected MxLog mxLog;
	protected MxLog withOutIdLog;
	private String logFileName;
	private String logFilePath;
	private String withOutIdLogName;
	private String withOutIdLogPath;
	private boolean enableLog;
	private File fileDirctory;
	private String transId;
	private ArrayList parsdata;



	public ReconOFPRTransaction() {
		adminEmail=null;
		adminEmailSub=null;
		outPutDirectory=null;
		tempProcessFolder=null;
		processFolder=null;
		backupFileFolder=null;
		importFileName=null;
		unzipCmd=null;
		email=null;
		mxLog=new MxLog();
		withOutIdLog=new MxLog();
		logFileName=null;
		logFilePath=null;
		withOutIdLogName=null;
		withOutIdLogPath=null;
		fileDirctory=null;
		enableLog=false;

	}


	public CrontaskParamInfo[] getParameters() throws MXException,
	RemoteException {

		CrontaskParamInfo[] params = new CrontaskParamInfo[12];

		params[0] = new CrontaskParamInfo();
		params[0].setName("ADMINEMAIL");
		params[0].setDescription("ADMINEMAIL", "Administrator Email ID");

		params[1] = new CrontaskParamInfo();
		params[1].setName("ADMINEMAILSUB");
		params[1].setDescription("ADMINEMAILSUB", "Administrator Email Subject");


		params[2] = new CrontaskParamInfo();
		params[2].setName("TEMPPROCESSFOLDER");
		params[2].setDescription("TEMPPROCESSFOLDER", " Temp Process folder file path");

		params[3] = new CrontaskParamInfo();
		params[3].setName("PROCESSFOLDER");
		params[3].setDescription("PROCESSFOLDER", "Process folder file path");

		params[4] = new CrontaskParamInfo();
		params[4].setName("BACKUPFILEFOLDER");
		params[4].setDescription("BACKUPFILEFOLDER", "Back Up file folder path");

		params[5] = new CrontaskParamInfo();
		params[5].setName("FILENAME");
		params[5].setDescription("FILENAME", "Processing file name");

		params[6] = new CrontaskParamInfo();
		params[6].setName("SPLITTAG");
		params[6].setDescription("SPLITTAG", "SPLITTAG");

		params[7] = new CrontaskParamInfo();
		params[7].setName("UNZIPCMD");
		params[7].setDescription("UNZIPCMD", "Unzip file command");

		params[8] = new CrontaskParamInfo();
		params[8].setName("LOGFILENAME");
		params[8].setDescription("LOGFILENAME", "Log File Name");

		params[9] = new CrontaskParamInfo();
		params[9].setName("LOGFILEPATH");
		params[9].setDescription("LOGFILEPATH", "Log File Path");

		params[10] = new CrontaskParamInfo();
		params[10].setName("ENABLELOG");
		params[10].setDescription("CommonCron","Enable log output('Y' or 'N').");
		params[10].setDefault("Y");

		params[11] = new CrontaskParamInfo();
		params[11].setName("WITHOUTIDLOGFILENAME");
		params[11].setDescription("WITHOUTIDLOGFILENAME", "Log File Path For Data Without Id");

		return params;
	}



	private void refreshSettings() throws RemoteException, MXException
	{
		try
		{
			adminEmail=getParamAsString("ADMINEMAIL");
			adminEmailSub=getParamAsString("ADMINEMAILSUB");
			tempProcessFolder=getParamAsString("TEMPPROCESSFOLDER");

			processFolder=getParamAsString("PROCESSFOLDER");
			fileDirctory=new File(processFolder);

			backupFileFolder=getParamAsString("BACKUPFILEFOLDER");
			//	importFileName=getParamAsString("FILENAME");

			DateFormat fileDateFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
			String todayDate=fileDateFormat.format(new Date());
			//importFileName = getParamAsString("FILENAME");
			//importFileName=importFileName.replaceAll("yyyyMMdd",todayDate);
			
			// Modify to replace with by previous day's if "yyyymmpd" is specified in import file base name
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH,-1);
            String prevDate = fileDateFormat.format(cal.getTime());
            importFileName = getParamAsString("FILENAME").replaceAll("yyyymmpd", prevDate);
			
			splitTag=getParamAsString("SPLITTAG");
			unzipCmd=getParamAsString("UNZIPCMD");
			logFileName=getParamAsString("LOGFILENAME");
			logFilePath=getParamAsString("LOGFILEPATH");
			enableLog=(getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
			withOutIdLogName=getParamAsString("WITHOUTIDLOGFILENAME");
			withOutIdLogPath=getParamAsString("LOGFILEPATH");

			Date curDate = new Date();
			DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
			String logFileDate = fileDateTimeFormat.format(curDate);
			logFileName = logFileName.replaceAll("yyyyMMdd",logFileDate);
			logFilePath =logFilePath+logFileName;
			withOutIdLogPath=withOutIdLogPath+withOutIdLogName;
			mxLog.setLogFilePath(logFilePath);
			mxLog.setLogTag(getName());
			mxLog.setEnabled(enableLog);
			mxLog.createLogFile();
			withOutIdLog.setLogFilePath(withOutIdLogPath);
			withOutIdLog.setLogTag(getName());
			withOutIdLog.setEnabled(enableLog);
			withOutIdLog.createLogFile();

		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}


	}

	private boolean isReqParamSet() {
		if (adminEmail.equalsIgnoreCase(""))
			return false;
		if (adminEmailSub.equalsIgnoreCase(""))
			return false;

		if (tempProcessFolder.equalsIgnoreCase(""))
			return false;
		if (processFolder.equalsIgnoreCase(""))
			return false;
		if (backupFileFolder.equalsIgnoreCase(""))
			return false;
		if (importFileName.equalsIgnoreCase(""))
			return false;
		if (splitTag.equalsIgnoreCase(""))
			return false;
		if (unzipCmd.equalsIgnoreCase(""))
			return false;
		if (logFileName.equalsIgnoreCase(""))
			return false;
		if (logFilePath.equalsIgnoreCase(""))
			return false;
		if (withOutIdLogName.equalsIgnoreCase(""))
			return false;

		return true;
	}
	public void init() throws MXException {
		super.init();

		email = new MxEmail(adminEmail);
		mxLog = new MxLog();

	}

	private String genEmail(Exception e) {

		// Form Email Message
		String emailMsg = "Date: " + new Date() + "\n";
		emailMsg += "Error in CronTask: " + getName() + "\n";
		emailMsg += "Error Message: " + e.getMessage() + "\n";
		emailMsg += "Detail:\n";
		emailMsg += e.toString() + "\n";
		StackTraceElement element[] = e.getStackTrace();
		for (int i = 0; i < element.length; i++) {
			emailMsg += "\tat " + element[i].toString() + "\n";
		}

		return emailMsg;
	}

	public void cronAction() {

		try
		{
			refreshSettings();
			if(isReqParamSet())
			{
				String fileRead=tempProcessFolder+importFileName;
				int dotPos = fileRead.lastIndexOf(".");
				String actualFile=fileRead.substring(0,dotPos);

				if(checkFileExist(importFileName))
				{
					MxFileCopy.fileCopy(processFolder+importFileName,tempProcessFolder+importFileName);

					//WMJ: do backup of file before processing
					MxFileCopy.fileCopy(processFolder+importFileName,backupFileFolder+importFileName);
					//WMJ: end backup of file before processing

					File deleteZipProcessed = new File(processFolder+importFileName);
					deleteZipProcessed.delete();

					if(unZipFileTemp())
					{
					processFolderData(actualFile);
					File processedFile = new File(actualFile);
					processedFile.delete(); 
					mxLog.writeLog("Cron:"+getName()+":File process is completed.");
					}

				}
				else
				{
					integrationLogger.debug("File does not found. cron job is Stopped.");
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			genEmail(e);
		}

	}

	public boolean checkFileExist (String importFileName) throws MessagingException {

		SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);

		File checkFile[] = fileDirctory.listFiles(filter);

		String currentFileName=importFileName.substring(0,36);

		if(checkFile!=null)
		{
			for (int j = 0; j < checkFile.length; j++) 
			{
				if(checkFile[j].getName().startsWith(currentFileName)){
					integrationLogger.debug("File exists process the file data.");
					return true;
				}
			}


		}
		integrationLogger.debug("File does not exists.");
		mxLog.writeLog("File not found in Processing Folder");
		MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,"File not found in Processing Folder");
		return false;
	}

	private boolean unZipFileTemp() throws Exception
	{
		boolean fileUNZipCompleted=true;
		try{
			String zipoutputFilePath = tempProcessFolder+importFileName;
			String cmd = unzipCmd + " " + zipoutputFilePath;
			int retcode= MxZip.unzipFile(cmd);
			if (retcode != 0){
				fileUNZipCompleted=false;
			}


		}
		catch(Exception e)
		{
			mxLog.writeLog("File Unzip is failed:"+getName()+":"+e.getMessage());
		}
		return fileUNZipCompleted;

	}

	public void processFolderData(String actualFile) throws MXException,Exception {

		try {
			String errorMessage="";
			BufferedReader  flatfileReader = new BufferedReader(new FileReader(actualFile));
			String currentLine;
			ArrayList<String> headerList=new ArrayList<String>();
			ArrayList<String> lineList=new ArrayList<String>();

			while((currentLine=flatfileReader.readLine())!=null)
			{
				try{
					if(!(currentLine.equals("")))
					{
						String recHeadertype = currentLine.substring(0, 1);
						if(recHeadertype.equals("0"))
						{
							headerList.add(currentLine);
						}
						if(recHeadertype.equals("1"))
						{
							lineList.add(currentLine);
						}
					}
				}
				catch (Exception e) {
					mxLog.writeLog("Error on while Processing the folder data:"+getName()+":"+e.getMessage());
				}
			}

			for(int i=0;i<headerList.size();i++)
			{
				int totalRecordsHeaderLevel=0;
				int totalRecordsLineLevel=0;

				BigDecimal totalAmountHeaderLevel=new BigDecimal("0.00");
				BigDecimal totalAmountLineLevel=new BigDecimal("0.00");

				String headerData=headerList.get(i);
				String[] headerValues=headerData.split(splitTag);
				String headerCurrency=headerValues[2];
				if(!(headerValues[3].equals("")))
				{
					totalRecordsHeaderLevel=Integer.parseInt(headerValues[3]);
				}
				if(!(headerValues[4].equals("")))
				{
					totalAmountHeaderLevel=new BigDecimal(headerValues[4]);
				}


				for(int j=0;j<lineList.size();j++)
				{
					int size=lineList.size();

					String lineData=lineList.get(j);
					String[] lineValues=lineData.split(splitTag);
					if(headerCurrency.equals(lineValues[6]))
					{
						if(!(lineValues[9].equals("")))
						{
							totalAmountLineLevel=totalAmountLineLevel.add(new BigDecimal(lineValues[9]));
						}
						totalRecordsLineLevel++;
					}	
				}

				if(totalRecordsHeaderLevel!=totalRecordsLineLevel)
				{
					errorMessage=errorMessage+"\n Mismatch on total number of records between header and line for "+headerCurrency+" currency. \n";
				}
				if(totalAmountHeaderLevel.compareTo(totalAmountLineLevel) != 0)
				{
					errorMessage=errorMessage+"\n Mismatch on total amount between header and line for "+headerCurrency+" currency. \n";
				}

			}

			if (errorMessage.length()>0)
			{
				flatfileReader.close();
				String fileRead=backupFileFolder+importFileName;
				int dotPos = fileRead.lastIndexOf(".");
				String backupfile=fileRead.substring(0,dotPos);
				File deleteProcessedFile = new File(actualFile);
				deleteProcessedFile.delete();
				mxLog.writeLog(errorMessage);
				MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessage+" \nPlease check the Backup folder and process again."+backupfile);
			}
			else			
			{
				Collection fileData=extractFileRead(actualFile);
				processOFTransData(fileData);
				fileData.clear();
				flatfileReader.close();
			}
		}



		catch(Exception e)
		{
			mxLog.writeLog("Error on while Processing the folder data:"+getName()+":"+e.getMessage());
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,"Error on while Processing the folder data:"+getName()+":"+e.getMessage());
		}

	}

	private void processOFTransData(Collection processdata) throws MXException,RemoteException,ParseException, MessagingException
	{
		String[] errorMessages={"","","","","",""};

		/*
		 * The different fields present in parsdata
		 *  parsdata.get(0) SOURCE
		 *	parsdata.get(1) oa_recondatetime
		 *	parsdata.get(2) oa_exchangerate
		 *	parsdata.get(3) currenyCode_OF
		 *	parsdata.get(4) reconcile_OF(totalCost_OF)
		 *	parsdata.get(5) prStatus_OF


		 * The Differnet Flags Present
		 * OA_RECON_AMT -->Verification between Maximo and OF for Line Cost
		 * OA_RECON_EXCHG -->Verification between Maximo and OF for ProjectID
		 * OA_RECON_CURRENCY -->Verification between Maximo and OF for TaskID
		 * OA_RECON_PRSTATUS -->Verification between Maximo and OF for TaskID

		 * The Different Error Message
		 * Error [2]: Cost Mismatch for the  Transaction:
		 * Error [3]: Currency Code Mismatch for the Transaction:
		 * Error [4]: Exchange Rate Mismatch for the Transaction:
		 * 
		 */
		Iterator processOFReconData=processdata.iterator();
		String OfaMessage;
		Date reconDate;
		String transidAndMbo;
		String reconcile_OF;
		String exchangeRateValue_OF;
		String objectName = null;
		String currenyCode_OF;
		String prStatus_OF= null;
		//String transId = null;
		boolean OA_RECON_AMT;
		boolean OA_RECON_EXCHG;
		boolean OA_RECON_CURRENCY;
		boolean OA_RECON_PRSTATUS;
		List<String> transIDList=new ArrayList<String>();
		Set<String> reconSet=new LinkedHashSet<String>();
		while(processOFReconData.hasNext())
		{
			try{
				parsdata=(ArrayList) processOFReconData.next();
				OA_RECON_AMT=false;
				OA_RECON_EXCHG= false;
				OA_RECON_CURRENCY=false;
				OA_RECON_PRSTATUS=false;
				transidAndMbo=(String) parsdata.get(0);
				if(!(transidAndMbo.equals("")))
				{
					double totalCost_OF=0.0;
					double exchangeRate_OF=0.0;
					//	String oa_coa="";
					reconcile_OF=(String) parsdata.get(4);
					if(!(reconcile_OF.equals("")))
					{
						totalCost_OF=Double.parseDouble(reconcile_OF);
					}
					
					String getactualMbo="PR";
					reconDate=MXServer.getMXServer().getDate();



					//OF exchange rate
					exchangeRateValue_OF=(String)parsdata.get(2);
					if(!(exchangeRateValue_OF.equals("")))
					{
						exchangeRate_OF=Double.parseDouble(exchangeRateValue_OF);
					}

					//OPS Currency Code
					currenyCode_OF=(String) parsdata.get(3);

					prStatus_OF= (String) parsdata.get(5);
					
					
					if(getactualMbo!=null && !transidAndMbo.equalsIgnoreCase(""))
					{
						objectName="PR";
						transId=(String) parsdata.get(0);

						if (!objectName.equalsIgnoreCase("")&& !transId.equalsIgnoreCase("")) {

							if(objectName.trim().equalsIgnoreCase("PR") & !transId.trim().equalsIgnoreCase("") )
							{
								MboSetRemote prSet=MXServer.getMXServer().getMboSet("PR",getRunasUserInfo());
								SqlFormat prSetSQL=new SqlFormat("PRNUM='"+transId+"'");
								prSet.setWhere(prSetSQL.format());
								prSet.reset();
								if(!prSet.isEmpty() & prSet!=null)
								{

									MboRemote prMbo=prSet.getMbo(0);
									if(prMbo!= null)
									{
										//As discussed with OF Team, we have commneted the below. No need to recon the all the values.
										
//										double totalCost=prMbo.getDouble("TOTALCOST");
//										//	String gldebitacct=matusetransMbo.getString("GLDEBITACCT");
//										double of_exchangeRate = prMbo.getDouble("EXCHANGERATE");
//										String currencyCode = prMbo.getString("CURRENCYCODE");
//										String prStatus = prMbo.getString("STATUS");
//
//										// Getting the Line Cost from Maximo and getting the Cost from OF File
//										// if the values are equal then set the flag as True or else rest the flag
//										if(totalCost_OF ==totalCost)
//										{
//											OA_RECON_AMT = true;
//
//										}
//										else
//										{
//											OA_RECON_AMT = false;
//											errorMessages[2]=errorMessages[2] +parsdata+"\n";
//											mxLog.writeLog("Cost Mismatch for the PR Transaction:"+parsdata);
//										}
//										// Getting the Currency Code from Maximo and getting the Currency Code from OF File
//										// if the values are equal then set the flag as True or else rest the flag
//										if ((currencyCode.equalsIgnoreCase(currenyCode_OF)))
//										{
//											OA_RECON_CURRENCY = true;
//										}
//										else
//										{
//											OA_RECON_CURRENCY = false;
//											errorMessages[3]=errorMessages[3] +parsdata+"\n";
//											mxLog.writeLog("COA Mismatch for the MATUSETRANS Transaction:"+parsdata);
//										}
//
//										// Getting the Exchange Rate from Maximo and getting the Exchange Rate from OF File
//										// if the Exchange Rate  are equal then set the flag as True or else rest the flag
//										if (of_exchangeRate == exchangeRate_OF)
//										{
//											OA_RECON_EXCHG = true;
//										}
//										else
//										{
//											OA_RECON_EXCHG = false;
//											errorMessages[4]=errorMessages[4] +parsdata+"\n";
//											mxLog.writeLog("COA Mismatch for the MATUSETRANS Transaction:"+parsdata);
//										}
//										if(((prStatus.equalsIgnoreCase("APPR"))&& (prStatus_OF.equalsIgnoreCase("APPROVED")))||(prStatus.equalsIgnoreCase("CAN"))&& (prStatus_OF.equalsIgnoreCase("CANCELED")))
//										{
//											OA_RECON_PRSTATUS =true;
//										}
//										else
//										{
//											OA_RECON_PRSTATUS=false;
//											errorMessages[5]=errorMessages[5] +parsdata+"\n";
//											mxLog.writeLog("Mismatch between PR Status:"+parsdata);
//											
//										}
//										

										//if (OA_RECON_AMT == true && OA_RECON_CURRENCY == true && OA_RECON_EXCHG == true && OA_RECON_PRSTATUS==true)
									//	{
											prMbo.setValue("OA_RECONDATETIME",reconDate,MboConstants.NOACCESSCHECK);
											prMbo.setValue("OA_EXCHANGERATE",exchangeRate_OF,MboConstants.NOACCESSCHECK);
											prMbo.setValue("OA_CURRENCYCODE",currenyCode_OF,MboConstants.NOACCESSCHECK);
											prMbo.setValue("OA_TOTALCOST",totalCost_OF,MboConstants.NOACCESSCHECK);
											prMbo.setValue("OA_FLAGREC",true,MboConstants.NOACCESSCHECK);
											prMbo.setValue("OA_PRSTATUS",prStatus_OF,MboConstants.NOACCESSCHECK);
											prSet.save();
											System.out.println("Update PR transaction");
										//}
									}

								}
								else
								{
									errorMessages[1] = errorMessages[1]+"Transaction Data not Present in Maximo:\n\n"+"\n\n"+parsdata+"\n";
									mxLog.writeLog("Invalid Transaction ID found for the record:"+parsdata);
								}
							}

			
						}
						else
						{
							errorMessages[0]=errorMessages[0]+"Transaction Data not Present in Maximo:\n\n"+"\n\n"+parsdata+"\n";
							mxLog.writeLog("Incorrect Data present in the file:"+parsdata);
						}
					}
					else
					{
						errorMessages[0]=errorMessages[0]+"Transaction Data not Present in Maximo:\n\n"+"\n\n"+parsdata+"\n";
						mxLog.writeLog("Incorrect Data present in the file:"+parsdata);
					}
				}
			}
			catch (Exception e) {
				errorMessages[0]=errorMessages[0]+"Transaction Data not Present in Maximo:"+"\n\n"+parsdata+"\n\n"+e.getMessage()+"\n\n";
				mxLog.writeLog("Incorrect Data present in the file:"+parsdata+"\n\n"+e.getMessage()+"\n\n");
			}
		}
		if(errorMessages[0].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub,  errorMessages[0]);
		}
		if(errorMessages[1].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, errorMessages[1]);
		}
		if(errorMessages[2].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Cost Mismatch for the PR Transaction:\n\n" +errorMessages[2]);
		}
		if(errorMessages[3].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Currency Code Mismatch for the PR Transaction:\n\n" +errorMessages[3]);
		}
		if(errorMessages[4].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Exchange Rate Mismatch for the PR Transaction:\n\n" +errorMessages[4]);
		}
		if(errorMessages[5].length()>0)
		{
			MXServer.sendEMail(adminEmail, adminEmail, adminEmailSub, "Mismatch between PR Status:\n\n" +errorMessages[5]);
		}

	}

	private Collection extractFileRead(String file) throws IOException {


		Collection col = new ArrayList();
		try
		{

			BufferedReader  flatfileReader = new BufferedReader(new FileReader(file));
			String curLine = flatfileReader.readLine();

			while((curLine = flatfileReader.readLine()) != null)
			{
				String[] data = curLine.split(splitTag);

				ArrayList list =new ArrayList();

				for(int i=0;i<data.length;i++){

					list.add(data[i].trim());
				}


				col.add(list);
			}

			integrationLogger.debug("Flat file parsing is completed");
			flatfileReader.close();
		}
		catch(Exception e)
		{

			mxLog.writeLog("Error On Parsing a flat file:"+getName()+":"+e.getMessage());
			e.printStackTrace();

		}
		return col;
	}


}
