package com.psa.app.rfq;

import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;

public class RFQMailCronCustom extends SimpleCronTask {

	public RFQMailCronCustom() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void cronAction() {
		// TODO Auto-generated method stub
		
		try{
			MboSetRemote rfqSet= MXServer.getMXServer().getMboSet("RFQ",MXServer.getMXServer().getUserInfo("MAXADMIN"));
			rfqSet.setWhere(" RFQID IN (SELECT DISTINCT ownerid FROM WFASSIGNMENT WHERE APP='RFQ' AND ASSIGNSTATUS='ACTIVE' and  (duedate+7) < sysdate )");
			rfqSet.reset();
		String rfqNumbers="";
		if (rfqSet.count()>0) {
			for (int i = 0; i < rfqSet.count(); i++) {
				 rfqNumbers+=rfqSet.getMbo(i).getString("RFQNUM")+",";	
				}
			
			rfqNumbers = rfqNumbers.substring(0, rfqNumbers.length()-1);
			
			CommTemplateSetRemote commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
			commTemplateSet.setWhere("TEMPLATEID='RFQ_DUE'");
			commTemplateSet.reset();
			CommTemplateRemote tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);	
			String toMail=tempRemote.getString("TOLIST");
			String fromMail=tempRemote.getString("SENDFROM");
			String ccTo=tempRemote.getString("CCLIST");
			String bccTo=tempRemote.getString("BCCLIST");
			String subject=tempRemote.getString("SUBJECT");
			String message=tempRemote.getString("MESSAGE");
			String replyTo=tempRemote.getString("REPLYTO");
			
			message =message.replace("#RFQIDS", rfqNumbers);
			
			toMail=tempRemote.convertSendTo("COMMTMPLT_TO", tempRemote);
			ccTo=tempRemote.convertSendTo("COMMTMPLT_CC", tempRemote);
			bccTo=tempRemote.convertSendTo("COMMTMPLT_BCC", tempRemote);
			
			MXServer.sendEMail(toMail, ccTo, bccTo, fromMail, subject, message, replyTo, null, null);
		}
		}catch(Exception e)
		{
			
		}
	}
		
	

}
