package com.psa.custom.sms;

import java.rmi.RemoteException;

import psdi.iface.mic.MicConstants;
import psdi.iface.mic.MicSetIn;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

/*
 * Author: BTE
 * 05 APR  2006 - Initial version
 */
public class SMSBANDataInProcess extends MicSetIn {
	
	/*
	 * Variables
	 */
    private static SMSConstant SMS = new SMSConstant();

    
	/*
	 * Author: BTE
	 * 05 APR 2006 - Constructor
	 */
    public SMSBANDataInProcess() throws MXException, RemoteException {
    	super();
    }

    /*
	 * Author: BTE
	 * 05 APR 2006 - Check business rules for inbound Staff Skill information 
	 */
    public int checkBusinessRules() throws MXException, RemoteException {        
        
        INTEGRATIONLOGGER.debug("Entering checkBusinessRules");
        
        if(struc.isCurrentDataNull(SMS.ORGID)) {
            throw new MXApplicationException(SMS.IFACE, SMS.LABNOORGID);
        }
        

        if(struc.isCurrentDataNull(SMS.IC)) {
            throw new MXApplicationException(SMS.IFACE, SMS.LABNOIC);
        }
                
		SMSPerson person =  new SMSPerson(getUserInfo());
		String code = person.getPersonID(struc.getCurrentData(SMS.IC)); 

        if(code == null) {
            throw new MXApplicationException(SMS.IFACE, SMS.LABNOLABORCODE);
            
        } else {
            struc.setCurrentData(SMS.LABORCODE, code);            
        }
        
        INTEGRATIONLOGGER.debug("Leaving checkBusinessRules");
        return MicConstants.PROCESS;
    }
}
