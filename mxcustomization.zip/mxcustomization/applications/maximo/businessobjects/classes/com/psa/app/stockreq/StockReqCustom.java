/*
 * Modification history
 * 27-05-2011	COMM-IT		Creation
 */

package com.psa.app.stockreq;

import java.rmi.*;

import psdi.mbo.*;
import psdi.util.*;
import psdi.mbo.custapp.*;
import java.util.*;
import psdi.server.AppService;


public class StockReqCustom extends CustomMbo 
	implements StockReqCustomRemote 
{
	public void init()
	throws MXException
{
    super.init();
    String alwaysReadOnly[] = {
        "STATUS", "SITEID", "REQUESTEDBY", "REQDATE", "APPROVERNAME", "APPROVEDDATE"
    };    
    String RequiredAlways[] = {
            "EQTYPE", "BRANDBATCH", "SECTION", "DESCRIPTION", "DESCRIPTION_LONGDESCRIPTION", "ISSUEUNIT", "USEDPERMACHINE", "REASON", "REORDERUSGQTY", "REORDERUSGINT"
    };
    setFieldFlag(alwaysReadOnly, 7L, true);
    setFieldFlag(RequiredAlways, 8L, true);
    setFieldFlag("ITEMNUM", 7L, true);
    setFieldFlag("IMSJO", 7L, true);
        
    try
    {
    	if(getString("STATUS").equals("WIMSCFM") || getString("STATUS").equals("WIMSASN") || getString("STATUS").equals("WIMSAPPR"))
    	{
    		setFieldFlag("ITEMNUM", 7L, false);
    		setFieldFlag("IMSJO", 7L, false);    		
    	}
    	
    	if (!isNew())
    	{
			if (getBoolean("COVERRISK"))
			{
				setFieldFlag("REORDERUSGQTY", 8L, false);
				setFieldFlag("REORDERUSGINT", 8L, false);
			}
			else
			{
				setFieldFlag("REORDERUSGQTY", 8L, true);
				setFieldFlag("REORDERUSGINT", 8L, true);
			}
			
			MboRemote mboRemote = getMboSet("STOCKINVDETAIL").getMbo(0);
			if (mboRemote != null)
			{
				String ReadOnly[] = {
				        "DESCRIPTION", "DESCRIPTION_LONGDESCRIPTION", "ITEMNUM", "COMMODITYGROUP", "COMMODITY", "ISSUEUNIT", "SITEID", "SECTION", "EQTYPE", "BRANDBATCH", "ITEMSIZE", "RECOND", "MODIFIED", "COVERRISK", "SPARESBRAND", "SYSTEM", "REORDERPOINT", "REORDERUSGQTY", "REORDERUSGINT", "INTORDERQTY", "CATALOGNUM", "REMARK", "IMSJO", "SSTOCK"
				};
				setFieldFlag(ReadOnly, 7L, true);
			}
    	}    	
    	
    	if(getString("STATUS").equals("DRAFT") || getString("STATUS").equals("WCFM") || getString("STATUS").equals("WAPPR"))
        {
    		setFieldFlag("ITEMNUM", 7L, true);  
    		setFieldFlag("IMSJO", 7L, true); 
        }    	
    	else if(getString("STATUS").equals("WIMSCFM") || getString("STATUS").equals("WIMSASN") || getString("STATUS").equals("WIMSAPPR"))
        {
    		String ReadOnly[] = {
    		        "SECTION", "MODIFIED", "USEDPERMACHINE", "COVERRISK", "REASON"
    		    };   
    		setFieldFlag(ReadOnly, 7L, true);    		           
        }    	
    	else if(getString("STATUS").equals("CLOSED") || getString("STATUS").equals("CAN"))
        {
    		setFlag(7L, true);
            return;
        }
    }
    catch(RemoteException rx)
    {
        rx.printStackTrace();
    }
    return;
}
	
	public StockReqCustom (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void add() 
		throws MXException, RemoteException 
	{
		super.add();
		Date currentDate = ((AppService)getMboServer()).getMXServer().getDate();
		setValue("REQUESTEDBY", getUserName(), 2L);	
		setValue("REQDATE", currentDate, 11L);
		String site = getUserInfo().getInsertSite();		
		setValue("SITEID", site, 11L);
		setValue("STATUS", "DRAFT", 2L);		
		
		setValue("RECOND", false, 11L);
		setValue("MODIFIED", false, 11L);
		setValue("HISTORYFLAG", false, 11L);
		setValue("COVERRISK", false, 11L);
		setValue("HASLD", false, 11L);
		
		//++COMM-IT++ To get Organization from Site
		SqlFormat sqf = new SqlFormat(this, " SITEID = :SITEID");
        MboSetRemote SiteSetRemote = getMboSet("$SITE", "SITE", sqf.format());
        MboRemote siteMbo = SiteSetRemote.getMbo(0);
        String orgid = siteMbo.getString("ORGID");
        setValue("ORGID", orgid, 11L);
        //--COMM-IT-- To get Organization from Site
        
		//++COMM-IT++ To get item Set from Organization
		SqlFormat sqf1 = new SqlFormat(this, " ORGID = :ORGID");
        MboSetRemote organizationSetRemote = getMboSet("$ORGANIZATION", "ORGANIZATION", sqf1.format());
        MboRemote orgMbo = organizationSetRemote.getMbo(0);
        String itemsetid = orgMbo.getString("ITEMSETID");
        setValue("ITEMSETID", itemsetid, 11L);
        //--COMM-IT-- To get item Set from Organization		
	}	
		
	public void save() 
		throws MXException, RemoteException 
	{
		super.save();
	}
	
	public void canAddIMS()
    	throws MXException, RemoteException
	{			
        if(isNull("itemnum"))
        	throw new MXApplicationException("item", "enterItem");
	}	
}
