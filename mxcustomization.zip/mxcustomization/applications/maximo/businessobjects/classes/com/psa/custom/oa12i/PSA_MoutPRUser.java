/* Modification History
 * 03 Dec 2020 - BCT - GL Account related changes
 */

package com.psa.custom.oa12i;

import java.rmi.RemoteException;
import java.util.List;
import psdi.app.contract.ContractLineSetRemote;
import psdi.app.contract.purch.PurchViewRemote;
import psdi.app.contract.purch.PurchViewSetRemote;
import psdi.iface.mic.StructureData;
import psdi.iface.migexits.UserExit;
import psdi.mbo.MaximoDD;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.mbo.Translate;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;

public class PSA_MoutPRUser
  extends UserExit
{
  private static final double MAX_SKIP_PR_COST = 10000.0D;
  
  public StructureData setUserValueOut(StructureData irData)
    throws MXException, RemoteException
  {
    irData.breakData();
    
    ERPOutExtCustom erpoutext = new ERPOutExtCustom(getUserInfo());
    String orgid = irData.getCurrentData("ORGID");
    List prlinelist = irData.getChildrenData("PRLINE");
    if (prlinelist.size() > 0)
    {
      for (int i = 0; i < prlinelist.size(); i++)
      {
        irData.setAsCurrent(prlinelist, i);
        if (!irData.isCurrentDataNull("OA_EXPENDTYPE"))
        {
          MboRemote worktype = erpoutext.getWorkTypeMbo(irData.getCurrentData("OA_EXPENDTYPE"), orgid);
          irData.setCurrentData("OA_EXPENDTYPE", worktype.getString("wtypedesc"));
        }
        //Modified by Karthik (Comm-IT) for GFS Integration Project UOM mapping and GL mapping//
        String MXorderUnit = irData.getCurrentData("ORDERUNIT");
        if (!MXorderUnit.equalsIgnoreCase("") || !irData.isCurrentDataNull("ORDERUNIT")) {
        	MboSetRemote uomSet=MXServer.getMXServer().getMboSet("MEASUREUNIT", getUserInfo());
        	uomSet.setWhere("measureunitid='"+MXorderUnit+"' and psa_gfsuomid is not null");
        	uomSet.reset();
        	if (uomSet.count()>1 || uomSet.count()==0) {
  		      	integrationLogger.debug("Skipping transaction : This orderunit does not have GFS UOM mapping");
  		      	throw new MXApplicationException("iface", "oa_uommappingerr");
			} else if (uomSet.count()==1) {
				String gfsUOM = uomSet.getMbo(0).getString("PSA_GFSUOMID");
				irData.setCurrentData("ORDERUNIT", gfsUOM);
			}
		}
        
        /* * 03 Dec 2020
		 * <START> - Code below has been commented as part of the GL Account changes
		 */
        
        /*
        if (!irData.isGLDataNull("GLDEBITACCT")) {
       	String maximoDebGL = irData.getGL("GLDEBITACCT");
       	MboSetRemote coaDebSet=MXServer.getMXServer().getMboSet("CHARTOFACCOUNTS", getUserInfo());
       	coaDebSet.setWhere("glaccount='"+maximoDebGL+"' and active=1 and psa_gfsglaccount is not null");
       	coaDebSet.reset();
       	if (coaDebSet.count()==1) {
       		MboRemote coaDebMbo = coaDebSet.getMbo(0);
   			String gfsDebGL=coaDebMbo.getString("PSA_GFSGLACCOUNT");
   			irData.setCurrentData("GLDEBITACCT",gfsDebGL);
   			} 
       	else {
   				throw new MXApplicationException("iface", "oa_nodebglmapping");
   			}
        }
        else {
        	throw new MXApplicationException("iface", "oa_nogldebitpa");
        }
        */
        /*
        if (!irData.isGLDataNull("GLCREDITACCT")) {
       	String maximoCredGL = irData.getGL("GLCREDITACCT");
       	MboSetRemote coaCredSet=MXServer.getMXServer().getMboSet("CHARTOFACCOUNTS", getUserInfo());
       	coaCredSet.setWhere("glaccount='"+maximoCredGL+"' and active=1 and psa_gfsglaccount is not null");
       	coaCredSet.reset();
       	if (coaCredSet.count()==1) {
       		MboRemote coaCredMbo = coaCredSet.getMbo(0);
   			String gfsCredGL=coaCredMbo.getString("PSA_GFSGLACCOUNT");
   			irData.setCurrentData("GLCREDITACCT",gfsCredGL);
   			} 
       	else {
   				throw new MXApplicationException("iface", "oa_nocredglmapping");
   			}
        }
        else {
        	throw new MXApplicationException("iface", "oa_noglcreditpa");
        }
        */
        
        /* * 03 Dec 2020
		 * <END> - Code above has been commented as part of the GL Account changes
		 */
        //End of Changes - Karthik(Comm-IT)
      }
      irData.setParentAsCurrent();
    }
    if ((!irData.isCurrentDataNull("VENDOR")) && (irData.getCurrentDataAsString("VENDOR").equals("CPD")))
    {
      integrationLogger.debug("[MoutPrUser]Vendor is CPD, need to blank it and then send to oracle, continue..");
      irData.setCurrentDataNull("VENDOR");
      return irData;
    }
    /*double totalcost = irData.getCurrentDataAsDouble("TOTALCOST");
    integrationLogger.debug("[MoutPrUser]TotalCost = " + totalcost);
    if (totalcost > 10000.0D)
    {
      integrationLogger.debug("[MoutPrUser]total cost > 10k, need to send to oracle, continue..");
      return irData;
    }*/
    Translate translate = MXServer.getMXServer().getMaximoDD().getTranslator();
    String orgId = irData.getCurrentData("ORGID");
    String itemnum = null;
    String linetype = null;
    String itemdesc = null;
    
    List list = irData.getChildrenData("PRLINE");
    if ((list != null) && (list.size() > 0))
    {
      irData.setAsCurrent(list, 0);
      
      linetype = irData.getCurrentData("LINETYPE");
      integrationLogger.debug("[MoutPrUser]linetype  = " + linetype);
      if (!irData.isCurrentDataNull("CATEGORY"))
      {
        String stockCategory = translate.toInternalString("CATEGORY", irData.getCurrentData("CATEGORY"));
        integrationLogger.debug("[MoutPrUser]stockCategory  = " + stockCategory);
        if (stockCategory.equalsIgnoreCase("NS"))
        {
          if (!irData.isCurrentDataNull("ITEMNUM"))
          {
            itemnum = irData.getCurrentData("ITEMNUM");
            integrationLogger.debug("[MoutPrUser]itemnum  = " + itemnum);
          }
          else
          {
            irData.setParentAsCurrent();
            integrationLogger.debug("[MoutPrUser]itemnum null?!, continue..");
            return irData;
          }
        }
        else
        {
          irData.setParentAsCurrent();
          integrationLogger.debug("[MoutPrUser]Stock Category not non-stock, continue..");
          return irData;
        }
      }
      else
      {
        itemnum = irData.getCurrentData("ITEMNUM");
        integrationLogger.debug("[MoutPrUser]itemnum  = " + itemnum);
        if (linetype != null)
        {
          if (linetype.equalsIgnoreCase("ITEM"))
          {
            irData.setParentAsCurrent();
            integrationLogger.debug("[MoutPrUser]Stock Category null.. linetype=ITEM.. assuming stock item, continue..");
            return irData;
          }
          if ((linetype.equalsIgnoreCase("MATERIAL")) || (linetype.equalsIgnoreCase("SERVICE")))
          {
            integrationLogger.debug("[MoutPrUser]Line Type = Material or Service");
            itemdesc = irData.getCurrentData("DESCRIPTION");
            integrationLogger.debug("[MoutPrUser]itemdesc  = " + itemdesc);
          }
          else
          {
            integrationLogger.debug("[MoutPrUser]Line Type = Std Service => non stock");
          }
        }
      }
    }
    irData.setParentAsCurrent();
    if (!irData.isCurrentDataNull("VENDOR"))
    {
      /*integrationLogger.debug("[MoutPrUser]no vendor => no contract");
      integrationLogger.debug("[MoutPrUser]SKIP!!!!");
      throw new MXApplicationException("iface", "SKIP_TRANSACTION");*/
    
    	String vendor = irData.getCurrentData("VENDOR");
    	integrationLogger.debug("[MoutPrUser]vendor= " + vendor);
    
    	PurchViewSetRemote contractSet = (PurchViewSetRemote)MXServer.getMXServer().getMboSet("PURCHVIEW", getUserInfo());
    
    	SqlFormat sqlformat = new SqlFormat(getUserInfo(), "vendor = :1 and orgid = :2 and status='APPR'");
    	sqlformat.setObject(1, "PURCHVIEW", "VENDOR", vendor);
    	sqlformat.setObject(2, "PURCHVIEW", "ORGID", orgId);
    
    	contractSet.setWhere(sqlformat.format());
    	for (PurchViewRemote contract = (PurchViewRemote)contractSet.moveFirst(); contract != null; contract = (PurchViewRemote)contractSet.moveNext())
    	{
    		String contractnum = contract.getString("CONTRACTNUM");
    		String contractrev = contract.getString("REVISIONNUM");
    		integrationLogger.debug("[MoutPrUser]contractnum  = " + contractnum);
    		integrationLogger.debug("[MoutPrUser]contractrev  = " + contractrev);
      
    		ContractLineSetRemote contractlineSet = (ContractLineSetRemote)MXServer.getMXServer().getMboSet("CONTRACTLINE", getUserInfo());
      
    		SqlFormat clSqlformat = null;
    		if ((linetype.equalsIgnoreCase("MATERIAL")) || (linetype.equalsIgnoreCase("SERVICE")))
    		{
    			clSqlformat = new SqlFormat(getUserInfo(), "contractnum =:1 and revisionnum =:2 and orgid =:3 and description =:4 and linetype =:5");
    			clSqlformat.setObject(1, "CONTRACTLINE", "CONTRACTNUM", contractnum);
    			clSqlformat.setObject(2, "CONTRACTLINE", "REVISIONNUM", contractrev);
    			clSqlformat.setObject(3, "CONTRACTLINE", "ORGID", orgId);
    			clSqlformat.setObject(4, "CONTRACTLINE", "DESCRIPTION", itemdesc);
    			clSqlformat.setObject(5, "CONTRACTLINE", "LINETYPE", linetype);
    		}
    		else
    		{
    			clSqlformat = new SqlFormat(getUserInfo(), "contractnum =:1 and revisionnum =:2 and orgid =:3 and itemnum =:4 ");
    			clSqlformat.setObject(1, "CONTRACTLINE", "CONTRACTNUM", contractnum);
    			clSqlformat.setObject(2, "CONTRACTLINE", "REVISIONNUM", contractrev);
    			clSqlformat.setObject(3, "CONTRACTLINE", "ORGID", orgId);
    			clSqlformat.setObject(4, "CONTRACTLINE", "ITEMNUM", itemnum);
    		}
    		contractlineSet.setWhere(clSqlformat.format());
    		if (!contractlineSet.isEmpty())
    		{
    			integrationLogger.debug("[MoutPrUser]Contract item...continue..");
    			return irData;
    		}
    	}
    	integrationLogger.debug("[MoutPrUser]Item not found in any contract.....");
    	integrationLogger.debug("[MoutPrUser]SKIP!!!!");
    	throw new MXApplicationException("iface", "SKIP_TRANSACTION");
    }
    return irData;
  }
}
