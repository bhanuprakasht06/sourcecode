/*
 * Modification history
 * 02-05-07	LS	SR-071	Clear the conditioncode if linetype not equal 'ITEM'
 */

package com.psa.app.common.purchasing;

import java.rmi.RemoteException;

import psdi.app.common.purchasing.FldPurLineType;
import psdi.mbo.Mbo;
import psdi.mbo.MboValue;
import psdi.util.MXException;

public class FldPurLineTypeCustom extends FldPurLineType 
{
	public FldPurLineTypeCustom(MboValue arg0) 
		throws MXException, RemoteException 
	{
		super(arg0);
	}

    public void action()
	    throws MXException, RemoteException
	{
    	super.action();
		Mbo mbo = getMboValue().getMbo();
    	if(!getMboValue().getString().equals("ITEM"))
    		mbo.setValueNull("conditioncode", 2L);
	}
}
