package com.psa.custom.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import com.psa.custom.common.MxFileCopy;
//import org.joda.time.LocalDate;
//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;

import com.psa.custom.ois.MxLog;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.mbo.MboRemote;
import psdi.server.MXServer;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

public class PushFiletoBoomi extends SimpleCronTask {
	protected static final MXLogger logger = MXLoggerFactory.getLogger("maximo.custom.cronlogger");
	private static final String DATE_TIME_FORMAT_yyyyMMdd = "yyyyMMdd";
	private static final String DATE_TIME_FORMAT_yyyyMM = "yyyyMM";
	private static final String DATE_TIME_FORMAT_yyyy = "yyyy";
	private static final int BUFFER_SIZE = 4096;
	private static final int CONNECT_TIMEOUT = 5000;
	private MxEmail email;
	protected MxLog mxLog;
	// Parameters
	private String alertEmailTo; // Alert mail to
	private String emailSubj; // Alert mail subject
	private String archiveFilePath; // Processed directory
	private String curlcommand; // The Location of the CURL Command. This will default in the Cron Task Parameter(/bin/curl)
	private String destinationserver; // The Destination Folder. This will default in the Cron Task Parameter(Internal)
	private String systemid; // / System ID. This will default in the Cron Task Parametes(maximo)
	private String receiverfolder; // The Receiving Folder. This Folder location is based on Integration.
	private String pathtopush; // // Path to Push the File. This will default in the Cron Task Parameter(@/opt/psa/data/rw/emsscp/outgoing)
	private String unzipatdestination;  // UnZip the File in Target Destination. This will default in the Cron Task Parameter(NO)
	private String fileName;
	private String logFilePath; // Log Directory
	private String logFile; // Log file output
	private String interfacename; // Name of the Interface
	private Process p = null;
	private String[] command = null ;
	public CrontaskParamInfo[] getParameters() throws MXException, RemoteException {
		
		
	/**
	 * CURLCOMMAND= /bin/curl
Destination_server=Internal
System_id=EAMS
Receiver_folder=RRM
PATHToPush=@/opt/psa/data/rw/emsscp/outgoing
UnzipAtDestination=NO
	 */
		
		  CrontaskParamInfo[] params = new CrontaskParamInfo[13];
		  
		  params[0] = new CrontaskParamInfo();		params[0].setName("ALERTEMAILTO"); 		  	params[0].setDescription("ALERTEMAILTO", "ALERT EMAIL");   				params[0].setDefault("krishnaprabu.k@bahwancybertek.com");
		  params[1] = new CrontaskParamInfo(); 		params[1].setName("EMAILSUBJ");   		  	params[1].setDescription("EMAILSUBJ", "EMAIL SUBJ");
		  params[2] = new CrontaskParamInfo(); 		params[2].setName("ARCHIVEFILEPATH");		params[2].setDescription("ARCHIVEFILEPATH", "ARCHIVE FILE PATH");
		  params[3] = new CrontaskParamInfo(); 		params[3].setName("CURLCOMMAND");			params[3].setDescription("CURLCOMMAND", "Curl Command Location");		params[3].setDefault("/bin/curl");
		  params[4] = new CrontaskParamInfo(); 		params[4].setName("RECEIVERFOLDER"); 		params[4].setDescription("RECEIVERFOLDER", "RECEIVER FOLDER");
		  params[5] = new CrontaskParamInfo(); 		params[5].setName("DESTINATIONSERVER");		params[5].setDescription("DESTINATIONSERVER", "DESTINATION SERVER");
		  params[6] = new CrontaskParamInfo(); 		params[6].setName("SYSTEMID");				params[6].setDescription("SYSTEMID", "Source System ID");				params[6].setDefault("MAXIMO");
		  params[7] = new CrontaskParamInfo(); 		params[7].setName("PATHTOPUSH");			params[7].setDescription("PATHTOPUSH", "PATH TO PUSH");					params[7].setDefault("@/opt/psa/data/rw/emsscp/outgoing/");
		  params[8] = new CrontaskParamInfo(); 		params[8].setName("UNZIPATDESTINATION");	params[8].setDescription("UNZIPATDESTINATION", "UNZIP in DESTINATION");	params[8].setDefault("NO");
		  params[9] = new CrontaskParamInfo(); 		params[9].setName("LOGFILEPATH");		  	params[9].setDescription("LOGFILEPATH", "LOG FILE PATH");
		  params[10] = new CrontaskParamInfo(); 	params[10].setName("LOGFILE");				params[10].setDescription("LOGFILE", "LOG FILE");
		  params[11] = new CrontaskParamInfo(); 	params[11].setName("INTERFACENAME");		params[11].setDescription("INTERFACENAME", "INTERFACE NAME");
		  params[12] = new CrontaskParamInfo();		params[12].setName("FILENAME");				params[12].setDescription("FILENAME","File Name to Push, else use * ");	params[12].setDefault("*");
		  return params;
		 	
		}

	public PushFiletoBoomi() {
		super();
		alertEmailTo = null;
		emailSubj = null;
		archiveFilePath = null;
		curlcommand = null;
		destinationserver = null;
		systemid = null;
		receiverfolder = null;
		pathtopush = null;
		unzipatdestination = null;
		logFilePath = null;
		logFile = null;
		interfacename = null;
		fileName = null;
	}

	public void start() {
		try {
			System.out.println("---> Entering start()");
			refreshSettings();
			setSleepTime(0L);
			System.out.println("---> Exiting start()");
		} catch (Exception exception) {
			System.out.println("Error in crontask : start():" + exception);
		}
	}

	public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {
		try {
			System.out.println("---> Entering setCrontaskInstance()");
			super.setCrontaskInstance(crontaskinstanceremote);
			System.out.println("---> Exiting setCrontaskInstance()");
		} catch (Exception exception) {
			System.out.println("Error in crontask : setCrontaskInstance():" + exception);
		}
	}

	public void cronAction() {
		
		try {
			mxLog.writeLog("---> Entering cronAction()");
			logger.debug(" at cronAction()");
			//refreshSettings();
			
			/* Declaration and initializations for testing manually -START
			
			//String destination="Internal";
			//String System_id="EAMS";
			//String Receiver_folder="RRM";
			//String FilesToPush="@/opt/psa/data/rw/emsscp/outgoing/rrm/";
			//String UnzipAtDestination="NO";
			//String[] command = {"/bin/curl -i -v -k --location --request POST 'https://sit-ipaas-internal.psa.com.sg/ws/rest/PSA/css/ipaasutil/v1.0/pushFilestoCommon/' --header 'x-api-key: 30a875c2-28c0-4141-a972-b859c9f9a176' --header 'Authorization: Basic ZWFtczppbG92ZWJvb21p' --form 'Destination_server=Internal' --form 'System_id=EAMS' --form 'Receiver_folder=RRM' --form 'FilesToPush=@/opt/psa/data/rw/emsscp/outgoing/rrm/rrm_worktype_202209281431.txt.gz' --form 'UnzipAtDestination=NO' "};
			
			// Declaration and initializations for testing manually -END
			
			 *	The different Integration Present
			 * EDOT,EDIA,EDP,OPERATION Indicator
			 * Set Parameters for the Integration Names
			 * Path that reads the File
			 * To create the CURL command based on the Integration and File path
			 * Try to get the response after the CURL is executed
			 * Move the file after the command is executed
			 * 
			 *
			 * MX -> Boomi 1. Prepare the file for push 2. Copy to the Boomi directory 3.
			 * Move the original file to backup directory 4. Handle exceptions for all
			 * scenarios 4.1 No source file found 4.2 Unable to copy the source file to
			 * Boomi 4.3 Unable to move the source file from process directory to back up
			 * directory 4.4 Others
			 * 
			*/
			
			
				
			mxLog.writeLog("---> Starting executing>>>>>");
			String ipaas_weburl= null; //"https://sit-ipaas-internal.psa.com.sg/ws/rest/PSA/css/ipaasutil/v1.0/pushFilestoCommon/";
			String ipaas_x_api_key= null; //" 30a875c2-28c0-4141-a972-b859c9f9a176";)
			String ipaas_authorization=null; // "Basic ZWFtczppbG92ZWJvb21p";
			//String filename ="rrm_worktype_202211091200001.txt.gz";
			
			// From System Properties
			Properties configData = MXServer.getMXServer().getConfig();
			ipaas_weburl = configData.getProperty("psa.ipaas.pftc.int.weburl"); // Need to be updated based on the new system property that is yet to be created
			ipaas_x_api_key = configData.getProperty("psa.ipaas.pffc.int.x_api_key");
			ipaas_authorization = configData.getProperty("psa.ipaas.pftc.authorization");
			
			String path = pathtopush.replaceAll("@", "");
			
			mxLog.writeLog("---> Before if --> path is :"+pathtopush +" --> AFter :"+ path);
			
			if (fileName.equalsIgnoreCase("*"))
			{
				mxLog.writeLog("---> Inside If");
				File processdir = new File(path);
				//Comment: List of all files and directories.
				File[] contents = processdir.listFiles();
				for (int i=0; i<contents.length;i++)
				{
					if (!contents[i].isDirectory())
					{
						mxLog.writeLog("--->>>>>> File Name to be pushed in IF --> " + contents[i].getName());
						command = new String []{curlcommand,"--include","--verbose","--insecure","--location","--request","POST",ipaas_weburl,"--header","x-api-key:"+ ipaas_x_api_key,"--header","Authorization: "+ipaas_authorization,"--form","Destination_server="+destinationserver,"--form","System_id="+systemid,"--form","Receiver_folder="+receiverfolder,"--form","FilesToPush="+pathtopush+contents[i].getName(),"--form","UnzipAtDestination="+unzipatdestination};
						executeCmd(command,contents[i].getName());
						moveFileToArchive(path, contents[i].getName(), archiveFilePath);
					}
				}
			}
			else 
			{
			//String[] command1 = {"/bin/curl","--include","--verbose","--insecure","--location","--request","POST","https://sit-ipaas-internal.psa.com.sg/ws/rest/PSA/css/ipaasutil/v1.0/pushFilestoCommon/","--header","x-api-key: 30a875c2-28c0-4141-a972-b859c9f9a176","--header","Authorization: Basic ZWFtczppbG92ZWJvb21p","--form","Destination_server=Internal","--form","System_id=EAMS","--form","Receiver_folder=RRM","--form","FilesToPush=@/opt/psa/data/rw/emsscp/outgoing/rrm/rrm_worktype_202211091200001.txt.gz","--form","UnzipAtDestination=NO"};
				mxLog.writeLog("--->>>>>> File Name to be pushed in else --> " + fileName);
				command = new String []{curlcommand,"--include","--verbose","--insecure","--location","--request","POST",ipaas_weburl,"--header","x-api-key:"+ ipaas_x_api_key,"--header","Authorization: "+ipaas_authorization,"--form","Destination_server="+destinationserver,"--form","System_id="+systemid,"--form","Receiver_folder="+receiverfolder,"--form","FilesToPush="+pathtopush+fileName,"--form","UnzipAtDestination="+unzipatdestination};
				executeCmd(command,fileName);
				moveFileToArchive(path, fileName, archiveFilePath);
			}
			
				
		} catch (Exception e) {
			mxLog.writeLog("Error in crontask:" + e);
			//String emailContent = genEmail(e);
			//email.send(emailSubj, emailContent);
		}
	}

	

	public void init() throws MXException {
		super.init();

		email = new MxEmail(alertEmailTo);
		mxLog = new MxLog();

	}

	private void moveFileToArchive(String sourcePath,String fileName,String archivePath)
	{
		try {
			mxLog.writeLog("copyFileToArchive function--->Source Path  :"+sourcePath +" --> File Name :"+ fileName + "--> Archive Path"+archivePath);
			
			//File archiveFile = new File(archivePath+fileName);
			
			//File sourceFile=new File(sourcePath+fileName);
			
			Path filemove = Files.move(Paths.get(sourcePath+fileName),Paths.get(archivePath+fileName));
			 
			        if(filemove != null)
			        {
			        	mxLog.writeLog("File moved successfully");
			        }
			        else
			        {
			        	mxLog.writeLog("Failed to move the file");
			        }
			
	/*		MxFileCopy.fileCopy(sourcePath+fileName,archivePath+fileName);
			
			File deleteProcessedFile = new File(sourcePath+fileName);
			deleteProcessedFile.delete();
			mxLog.writeLog("Deleted from path from deleteProcessedFile Method:" + sourcePath);
	
			if (sourceFile.exists())
			{
				if (archiveFile.exists())
				{
			      Path deleteProcessedFile1 = Paths.get(sourcePath+fileName);
			      mxLog.writeLog("deleteProcessedFile in crontask:" + deleteProcessedFile1);
			      Files.deleteIfExists(deleteProcessedFile1);
			      mxLog.writeLog("Deleted from path:" + sourcePath);
				}
			
			} */
		} catch (IOException e) {
			mxLog.writeLog("Error in crontask:" + e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private void executeCmd(String[] command,String fileName)
	{
		mxLog.writeLog("---> entering executeCmd() method ---> command is -->");
		int i=0;
		int j=0;
		mxLog.writeLog("--->>>>>> File Name to be pushed during process --> " + fileName);
		while (i<command.length && i<=100)
		{
			mxLog.writeLog(i+"------->"+command[i]);
			i++;
		}
		
		mxLog.writeLog("URL--> "+command[7]);
		
		ProcessBuilder process = new ProcessBuilder(command);
		
		try{
			mxLog.writeLog(">>>Before Process start");
			p = process.start();
			mxLog.writeLog(">>>After Process start");
			p.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			StringBuilder builder = new StringBuilder();
			mxLog.writeLog(">>>After String Bulder");
			String line = null;
			mxLog.writeLog("ReadLine output " + reader.readLine());
			while ((line = reader.readLine()) != null) 
			{
				builder.append(line);
				builder.append(System.getProperty("line.separator"));
			}
			String result = builder.toString();
			int responseCode = 0;
			
			String[] lines = result.split(System.lineSeparator());
			
			while (j<lines.length && j<=100)
            {
            	mxLog.writeLog(j+ "lines---> "+lines[j]);
            	j++;
            }
			
	        for (String outputLine : lines) {
	            if (outputLine.startsWith("HTTP/")) {
	                String[] parts = outputLine.split(" ");
	                
	                if (parts.length >= 2) {
	                    try {
	                        responseCode = Integer.parseInt(parts[1]);
	                    } catch (NumberFormatException e) {
	                        // Handle the exception if needed
	                        e.printStackTrace();
	                    }
	                }
	                break; // We found the response code, no need to continue searching
	            }
	        }

	        // Handle the response code
	        if (responseCode == 200) {
	            mxLog.writeLog("HTTP Response Code: " + responseCode);
	        } else {
	            mxLog.writeLog("HTTP Response Code is not valid---> "+responseCode);
	            
	            String msgdetails = "";
	            
	            msgdetails = String.valueOf(msgdetails) + "FileName: " + fileName + "<ul>" + "<li>Response Code= " + lines[1]  + "</li>"  + "</ul>" + "<ul>" + "<li>URL= " + command[7]  + "</li>"  + "</ul>" + "<ul>" + "<li>Processed Date= " +lines[3] + "</li>" + "</ul>"+"<ul>" + "<li>" + command[17]+ "</li>"+ "</ul>";
	            
	            mxLog.writeLog("msgdetails--> "+msgdetails);
	            
	            CommTemplateSetRemote commTemplateSet = (CommTemplateSetRemote)MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
	            commTemplateSet.setWhere("TEMPLATEID='PUSH_CRONERROR'");
	            commTemplateSet.reset();
	            mxLog.writeLog("TEMPLATEID---> "+commTemplateSet.getMbo(0).getString("TEMPLATEID"));
	            CommTemplateRemote tempRemote = (CommTemplateRemote)commTemplateSet.getMbo(0);
	            String toMail = tempRemote.getString("TOLIST");
	            String fromMail = tempRemote.getString("SENDFROM");
	            String ccTo = tempRemote.getString("CCLIST");
	            String bccTo = tempRemote.getString("BCCLIST");
	            String subject = tempRemote.getString("SUBJECT");
	            String message = tempRemote.getString("MESSAGE");
	            String replyTo = tempRemote.getString("REPLYTO");
	            message = message.replace("$msgdetails",msgdetails );
	            toMail = tempRemote.convertSendTo("COMMTMPLT_TO", (MboRemote)tempRemote);
	            ccTo = tempRemote.convertSendTo("COMMTMPLT_CC", (MboRemote)tempRemote);
	            bccTo = tempRemote.convertSendTo("COMMTMPLT_BCC", (MboRemote)tempRemote);
	            mxLog.writeLog("-----Before Sending Mail-----");
	            mxLog.writeLog("TO ---> "+toMail);
	            mxLog.writeLog("ccTo ---> "+ccTo);
	            MXServer.sendEMail(toMail, ccTo, bccTo, fromMail, subject, message, replyTo, null, null);
	            mxLog.writeLog("-----After Sending Mail-----");
	            
	            
	        }
	        
			mxLog.writeLog("Result is " + result + "Exit value is  " + p.exitValue());
			
		} 
		catch (Exception e){
			// TODO: handle exception
			mxLog.writeLog("---> " + e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			mxLog.writeLog("----> Inside Finally block before destroying process ");
			p.destroy();
		}
	}


	private void refreshSettings() {
		try {
			alertEmailTo = getParamAsString("ALERTEMAILTO");
			email.setAdmin(alertEmailTo);
			emailSubj = getParamAsString("EMAILSUBJ");
			archiveFilePath = getParamAsString("ARCHIVEFILEPATH");
			curlcommand = getParamAsString("CURLCOMMAND");
			receiverfolder = getParamAsString("RECEIVERFOLDER");
			destinationserver = getParamAsString("DESTINATIONSERVER");

			systemid = getParamAsString("SYSTEMID");
			pathtopush = getParamAsString("PATHTOPUSH");
			unzipatdestination = getParamAsString("UNZIPATDESTINATION");
			

			logFilePath = getParamAsString("LOGFILEPATH");
			logFile = getParamAsString("LOGFILE");
			interfacename = getParamAsString("INTERFACENAME");
			fileName = getParamAsString("FILENAME");
			Date curDate = new Date();
			DateFormat fileDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
			String fileDateStr = fileDateTimeFormat.format(curDate);
			logFile = logFile.replaceAll("yyyyMMdd", fileDateStr);
			logFilePath = logFilePath + logFile;
			mxLog.setLogFilePath(logFilePath);
			mxLog.setLogTag(getName());
			mxLog.setEnabled(true);
			mxLog.createLogFile();

		
		} catch (Exception exception) {
			logger.info("exception.getMessage() crontask:" + exception);
		}
	}

	private boolean isReqParamSet() {
		if ((archiveFilePath == null) || (archiveFilePath.equalsIgnoreCase("")))
			return false;
		if ((pathtopush == null) || (pathtopush.equalsIgnoreCase("")))
			return false;
		if ((interfacename == null) || (interfacename.equalsIgnoreCase("")))
			return false;
		if ((logFilePath == null) || (logFilePath.equalsIgnoreCase("")))
			return false;
		if ((logFile == null) || (logFile.equalsIgnoreCase("")))
			return false;
		if ((receiverfolder == null) || (receiverfolder.equalsIgnoreCase("")))
			return false;
		if ((alertEmailTo == null) || (alertEmailTo.equalsIgnoreCase("")))
			return false;
		if ((emailSubj == null) || (emailSubj.equalsIgnoreCase("")))
			return false;
		if ((curlcommand == null) || (curlcommand.equalsIgnoreCase("")))
			return false;
		if ((destinationserver == null) || (destinationserver.equalsIgnoreCase("")))
			return false;
		if ((systemid == null) || (systemid.equalsIgnoreCase("")))
			return false;
		if ((unzipatdestination == null) || (unzipatdestination.equalsIgnoreCase("")))
			return false;
		if ((fileName == null) || (fileName.equalsIgnoreCase("")))
			return false;
		
		return true;

	}

	private String genEmail(Exception e) {
		// Form Email Message
		String emailMsg = "Date: " + new Date() + "\n";
		emailMsg += "Error in CronTask: " + getName() + "\n";
		emailMsg += "Error Message: " + e.getMessage() + "\n";
		emailMsg += "Detail:\n";
		emailMsg += e.toString() + "\n";
		StackTraceElement element[] = e.getStackTrace();
		for (int i = 0; i < element.length; i++) {
			emailMsg += "\tat " + element[i].toString() + "\n";
		}
		return emailMsg;
	}

}
