package com.psa.custom.common;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

public class ConfigFile
{

	public ConfigFile(String file, String[] keys)
	{
		filename = file;
		config = new HashMap();
		for (int i = 0; i < keys.length; i ++)
			config.put(keys[i], "");
	}


	public void readFile()
		throws IOException
	{
		BufferedReader reader = new BufferedReader(new FileReader(filename));

		for (String line = reader.readLine(); line != null; line = reader.readLine())
		{
			StringTokenizer tok = new StringTokenizer(line.trim(), "=");
			String parameter = tok.nextToken().trim();
			String value = tok.nextToken().trim();
			Iterator keysList = config.keySet().iterator();
			while (keysList.hasNext())
			{
				String key = (String) keysList.next();
				if (parameter.equalsIgnoreCase(key))
				{
					config.put(key, value);
					break;
				}
			}
		}
	}


	public String get(String key)
	{
		return (String) config.get(key);
	}


	String filename;
	HashMap config;
}
