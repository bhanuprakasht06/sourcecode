package com.psa.app.jobplan;

import java.rmi.RemoteException;

import psdi.app.jobplan.JobPlan;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;

public class JobPlanCustom extends JobPlan 
	implements JobPlanCustomRemote 
{
	public JobPlanCustom (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void init() 
			throws MXException 
	{
		super.init();		
	}

	public void add() 
			throws MXException, RemoteException 
	{
		super.add();
	}
	
	public void save() 
			throws MXException, RemoteException 
	{
		super.save();
	}
	
	public MboRemote duplicate()
			throws MXException, RemoteException
	{
		MboRemote newJobPlanMbo = copy();
		
		MboSetRemote newDoclinksSet = getMboSet("DOCLINKS");
		newDoclinksSet.copy(newJobPlanMbo.getMboSet("DOCLINKS"));
		
		MboSetRemote newJobTaskSet = getMboSet("JOBTASK");
		newJobTaskSet.setWhere("1=1");
		newJobTaskSet.resetQbe();
		newJobTaskSet.reset();			 
		newJobTaskSet.copy(newJobPlanMbo.getMboSet("JOBTASK"));

		MboSetRemote newJobLaborSet = getMboSet("JOBLABOR");
			  
		newJobLaborSet.setWhere("1=1");
		newJobLaborSet.resetQbe();
		newJobLaborSet.reset();
		newJobLaborSet.copy(newJobPlanMbo.getMboSet("JOBLABOR"));
			  

		MboSetRemote newJobMaterialSet = getMboSet("JOBMATERIAL");
  
		newJobMaterialSet.setWhere("1=1");
		newJobMaterialSet.resetQbe();
		newJobMaterialSet.reset();
		newJobMaterialSet.copy(newJobPlanMbo.getMboSet("JOBMATERIAL"));
  
		MboSetRemote actualNewJpMtlSet = newJobPlanMbo.getMboSet("JOBMATERIAL");
		MboRemote actualNewJpMtl = null;
		for (int i = 0; (actualNewJpMtl = actualNewJpMtlSet.getMbo(i)) != null; i++)
		{
			actualNewJpMtl.setFieldFlag("location", 7L, actualNewJpMtl.getBoolean("directreq"));
			actualNewJpMtl.setFieldFlag("storelocsite", 7L, actualNewJpMtl.getBoolean("directreq"));
			if (actualNewJpMtl.getBoolean("directreq"))
			{
				actualNewJpMtl.setFieldFlag("location", 128L, false);
				actualNewJpMtl.setFieldFlag("storelocsite", 128L, false);
			}
		}
  

		MboSetRemote newJobServicesSet = getMboSet("JOBSERVICE");
  
		newJobServicesSet.setWhere("1=1");
		newJobServicesSet.resetQbe();
		newJobServicesSet.reset();
		newJobServicesSet.copy(newJobPlanMbo.getMboSet("JOBSERVICE"));
  

		MboSetRemote newJobToolSet = getMboSet("JOBTOOL");
  
		newJobToolSet.setWhere("1=1");
		newJobToolSet.resetQbe();
		newJobToolSet.reset();
		newJobToolSet.copy(newJobPlanMbo.getMboSet("JOBTOOL"));
  
		MboSetRemote newJobskillsetSet = getMboSet("PSA_JPSKILLSET");
		newJobskillsetSet.setWhere("1=1");
		newJobskillsetSet.resetQbe();
		newJobskillsetSet.reset();
		newJobskillsetSet.copy(newJobPlanMbo.getMboSet("PSA_JPSKILLSET"));

		MboSetRemote newJpAssetSpLinkSet = getMboSet("JPASSETSPLINK");
  
		newJpAssetSpLinkSet.setWhere("1=1");
		newJpAssetSpLinkSet.resetQbe();
		newJpAssetSpLinkSet.reset();
		newJpAssetSpLinkSet.copy(newJobPlanMbo.getMboSet("JPASSETSPLINK"));
  

		if (newJpAssetSpLinkSet.getSize() > 0) {
			for (int i = 0; i < newJpAssetSpLinkSet.getSize(); i++) {
				MboSetRemote newJpDSSet = newJpAssetSpLinkSet.getMbo(i).getMboSet("PLUSCJPDSASSETSPLINK");
				newJpDSSet.copy(newJobPlanMbo.getMboSet("JPASSETSPLINK").getMbo(i).getMboSet("PLUSCJPDSASSETSPLINK"));
			}
		}

		MboSetRemote newJpTaskRelationSet = getMboSet("JPTASKRELATION");
		newJpTaskRelationSet.copy(newJobPlanMbo.getMboSet("JPTASKRELATION"));

		MboSetRemote actualNewJpTaskRelSet = newJobPlanMbo.getMboSet("JPTASKRELATION");
		for (int ii = 0; ii < actualNewJpTaskRelSet.count(); ii++)
		{
			actualNewJpTaskRelSet.getMbo(ii).setValue("jobplanid", newJobPlanMbo.getLong("jobplanid"));
		}
  

		MboSetRemote newJobPlanSpecSet = getMboSet("JOBPLANSPECCLASS");
		newJobPlanSpecSet.copy(newJobPlanMbo.getMboSet("JOBPLANSPECCLASS"));
  

		MboSetRemote newJobPlanClassSet = getMboSet("JOBPLANCLASS");
  
		if (newJobPlanMbo.getMboSet("JOBPLANCLASS").count() == 1)
		{

			newJobPlanMbo.getMboSet("JOBPLANCLASS").deleteAll(2L);
		}
		newJobPlanClassSet.copy(newJobPlanMbo.getMboSet("JOBPLANCLASS"));
  

		String[] readOnlyKey = { "ORGID", "SITEID" };
		newJobPlanMbo.setFieldFlag(readOnlyKey, 7L, true);
  	

		return newJobPlanMbo;
	}
	
	/*public MboRemote duplicate()
	throws MXException, RemoteException
	{	
		super.duplicate();
		MboRemote newJobPlanMbo = copy();
		
		MboSetRemote newJobskillsetSet = getMboSet("PSA_JPSKILLSET");
		newJobskillsetSet.setWhere("1=1");
		newJobskillsetSet.resetQbe();
		newJobskillsetSet.reset();
		newJobskillsetSet.copy(newJobPlanMbo.getMboSet("PSA_JPSKILLSET"));
		
		return newJobPlanMbo;
	}*/
}
