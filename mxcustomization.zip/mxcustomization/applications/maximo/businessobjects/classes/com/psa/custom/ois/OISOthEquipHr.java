/*
 * Comment	OIS Main Class for Other Equipment Computation for Operation Running Hours 
 * Modifications history
 * 	03-03-2006	HYC	NA			Creation
 * 	08-01-2007	AGD	SR-45 	catch lines with error
 * 										QC : base on start date/time instead of end date/time
 * 										several readings with the same start time but with different end times
 * 	21-05-2007	AGD	DR-021	Change checks for asset field length = 6
 * 	15-07-2014	WMJ	EMS-819	[Crontask]Handle 4 digit equipment in OIS crontasks
 */
 
package com.psa.custom.ois;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.psa.custom.common.EMSSite;
import com.psa.custom.common.MxSort;


import psdi.security.UserInfo;
import psdi.util.MXException;

public class OISOthEquipHr
{

   private static String delimiter = ",";
   private static final String sortedfileext = ".sort";
   private static final String outputfileext = ".out";
   private static final String outputprevfileext = ".pre";
   private static String LOGON = "0";
   private static String LOGOFF = "1";
   private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";

   // GPTM START

   private static final String SYSTEM = "SYSTEM";
   private static final String OIS = "OIS";

   // GPTM End

   private OISCheck equipIncl;

   private String sortCmd;
   private String sortOpOpt;

   private String operHrMeterName;
   private String operHrMeterNameM;

   private UserInfo userInfo; // Maximo User Info

   private ArrayList finalDataArray;

   private MxLog mxLog;

   private class TransRec
   {
      private String actDT; // activity date time
      private String recCrDT; // record creation date time
      private String staffID; // staff ID
      private String transType; // Transaction Type (0=Logon, 1= Logoff)
      private String recType; // Identify the creator of the record (SYSTEM/OIS)

      public TransRec(String actDT, String recCrDT, String staffID, String transType, String recType)
      {
         this.actDT = actDT;
         this.recCrDT = recCrDT;
         this.staffID = staffID;
         this.transType = transType;
         this.recType = recType; // GPTM Change
      }

      public String getTransRecStr()
      {
         String output = recCrDT + delimiter + transType + delimiter + staffID + delimiter + actDT + delimiter + recType; // GPTM

         return output;
      }

      // GPTM CODE START
      public String getTransRecStr4nextday(String dayEnd)
      {
         String output = recCrDT + delimiter + transType + delimiter + staffID + delimiter + dayEnd + delimiter + SYSTEM;
         return output;
      }

      public String getRecType()
      {
         return recType;
      }

      // GPTM CODE END

      public String getActDT()
      {
         return actDT;
      }

      public void setActDT(String actDT)
      {
         this.actDT = actDT;
      }

      public String getStaffID()
      {
         return staffID;
      }

      public void setStaffID(String staffID)
      {
         this.staffID = staffID;
      }

      public String getTransType()
      {
         return transType;
      }

      public void setTransType(String transType)
      {
         this.transType = transType;
      }

      public String getRecCrDT()
      {
         return recCrDT;
      }

      public void setRecCrDT(String recCrDT)
      {
         this.recCrDT = recCrDT;
      }

   }

   public OISOthEquipHr(String equipInclFile, UserInfo userInfo, String operHrMeterName, String operHrMeterNameM, String sortCmd,
            String sortOpOpt, MxLog mxLog) throws Exception
   {

      this.mxLog = mxLog;

      finalDataArray = new ArrayList();

      this.userInfo = userInfo;
      this.operHrMeterName = operHrMeterName;
      this.operHrMeterNameM = operHrMeterNameM;
      this.sortCmd = sortCmd;
      this.sortOpOpt = sortOpOpt;

      // Load the equipment type list that is included
      equipIncl = new OISCheck(equipInclFile);

   }

   /**
    * @author HCHA
    * @date Mar 2, 2006
    * @function Reads input flat file
    * @param inFileName
    * @throws MXException
    * @throws RemoteException
    */
   /*
    * SR-45 AGD : catch lines with error
    * Change return type to String in order to return the list of lines with error
    * Returns null or the lines separated by comma
    */
   // public void readDataFile(String inFileName, String prevDayFile, String outFileName, String EMSAssetIDCfgFile)
   public String readDataFile(String inFileName, String prevDayFile, String outFileName, String EMSAssetIDCfgFile) throws Exception
   {

      mxLog.writeLog(getClass().getName() + ".readDataFile()");

      String inputText = null;
      String curFileName = null;
      int linenum = 0;
      // SR-45 AGD : catch lines with error
      String errorLines = "";

      try
      {

         curFileName = inFileName;
         File inFile = new File(inFileName);
         if (!inFile.exists())
         {
            // mxLog.writeLog(getClass().getName()+".readDataFile(): Input file: '"+inFileName+"' not found!");
            throw new Exception(getClass().getName() + ".readDataFile(): Input file: '" + inFileName + "' not found!");
         }

         FileReader fReader = new FileReader(inFile);
         BufferedReader bReader = new BufferedReader(fReader);

         File outFile = new File(outFileName);
         FileWriter fWriter = new FileWriter(outFile);
         BufferedWriter bWriter = new BufferedWriter(fWriter);

         EMSAssetIDConversion assetIDConv = new EMSAssetIDConversion(EMSAssetIDCfgFile);

         // Input File Format for Other Equip Running Hours
         // ==============================================
         // actDT (activity date time)   : 26 - 38
         // transType (Transcation Type) : 38 - 42
         // staffId (all except PM)      : 42 - 50
         // staffNric (for PM)           : 58 - 66
         // assetID                      : 66 - 75
         // recCreationDT                : 0 - 14

         // Intermediate Output File Format (Comma delimited)
         // =================================================
         // Field 1: Asset ID
         // Field 2: Record Creation Date Time
         // Field 3: Transcation Type
         // Field 4: Staff Id (Id or NRIC)
         // Field 5: Activaty Date Time
         // Field 6: System/OIS (System/User updated record)

         inputText = bReader.readLine();

         while (inputText != null)
         {

            linenum++;

            /*
             * SR-45 AGD : catch lines with error
             * If a problem with the line format is found, skip the line
             */
            try
            {
               String transType = inputText.substring(38, 42);

               if (transType.compareTo("LOGN") == 0 || transType.compareTo("LOGF") == 0)
               {

	              // start of EMS-819 
	              String assetID = inputText.substring(66, 75);
	              assetID = assetID.trim(); //remove leading and trailing spaces
	              // end of EMS-819                  
	               
                  // 20060823 HCHA - Add Conversion for Location
                  assetID = assetIDConv.getRightAssetId(assetID);

                  // Begin modification DR-021
                  //                  if(assetID.length()==6){
                  // End modification DR-021

                  if (equipIncl.isInList(assetID.substring(1, 3)))
                  {

                     String actDT = inputText.substring(26, 38);
                     /*
                      * SR-45 : catch lines with error
                      * The next statement does nothing but throws an exception that will be caught if there's a conversion problem
                      * so it's actually used to verify that there's no data corruption
                      */
                     OISData.convertDate(actDT);

                     String staffID;
                     if (assetID.substring(1, 3).compareTo("PM") == 0)
                     {
                        // NRIC
                        staffID = inputText.substring(58, 66);
                     }
                     else
                     {
                        // Staff Id
                        staffID = inputText.substring(42, 50);
                     }

                     String transTypeCode;
                     if (transType.compareTo("LOGN") == 0)
                     {
                        transTypeCode = LOGON;
                     }
                     else
                     {
                        transTypeCode = LOGOFF;
                     }

                     String recCrDT = inputText.substring(0, 14);
                     /*
                      * SR-45 : catch lines with error
                      * The next statement does nothing but throws an exception that will be caught if there's a conversion problem
                      * so it's actually used to verify that there's no data corruption
                      */
                     OISData.convertDate(recCrDT.substring(0, 12));

                     // Write data to output file
                     String writeline = assetID + delimiter + recCrDT + delimiter + transTypeCode + delimiter + staffID + delimiter + actDT
                              + delimiter + OIS + "\n";
                     bWriter.write(writeline);
                  }
                  // Begin modification DR-021
                  //               }
                  // End modification DR-021

               }
            }
            catch (Exception e)
            {
               errorLines = errorLines + ", " + linenum;
               String errormsg = getClass().getName() + ".readDataFile(): Error at line(" + linenum + ")of '" + curFileName + "' - "
                        + inputText + "(" + MxLog.genError(e) + ")";
               mxLog.writeLog(errormsg);
            }

            inputText = bReader.readLine();

         }

         bReader.close();
         fReader.close();

         //////////////////////////////
         // Append previous day's file
         //////////////////////////////

         linenum = 0;
         curFileName = prevDayFile;

         inFile = new File(prevDayFile);
         if (inFile.exists())
         {

            fReader = new FileReader(inFile);
            bReader = new BufferedReader(fReader);

            inputText = bReader.readLine();

            while (inputText != null)
            {
               linenum++;
               bWriter.write(inputText);
               bWriter.newLine();
               inputText = bReader.readLine();
            }

            bReader.close();
            fReader.close();

         }
         else
         {
            mxLog.writeLog(getClass().getName() + ".readDataFile(): Previous Day Input file: '" + prevDayFile + "' not found!");
         }

         bWriter.close();
         fWriter.close();

      }
      catch (IOException e)
      {
         String errormsg;
         if (inputText != null)
         {
            errormsg = getClass().getName() + ".readDataFile(): I/O Error at line(" + linenum + ") of '" + curFileName + "' - '"
                     + inputText + "'(" + MxLog.genError(e) + ")";
         }
         else
         {
            errormsg = getClass().getName() + ".readDataFile(): I/O Error reading/writing text file '" + curFileName + "'" + "("
                     + MxLog.genError(e) + ")";
         }
         //         mxLog.writeLog(errormsg);
         throw new Exception(errormsg);
      }
      catch (Exception e)
      {
         String errormsg;
         // if(inputText!=null){
         // errormsg = getClass().getName()+".readDataFile(): Error at line("+linenum+") of '"+curFileName+"' - '"+inputText+"'("+MxLog.genError(e)+")";
         // }
         // else{
         errormsg = getClass().getName() + ".readDataFile(): Unexpected error processing text file '" + curFileName + "'" + "("
                  + MxLog.genError(e) + ")";
         // }
         // mxLog.writeLog(errormsg);
         throw new Exception(errormsg);
      }

      // SR-45 AGD : catch lines with error
      return (errorLines.equals("")) ? null : errorLines.substring(2);
   }

   /**
    * @author HCHA
    * @date Mar 3, 2006
    * @function
    * @param filename
    * @throws MXException
    * @throws RemoteException
    * @throws InterruptedException
    * @throws IOException
    */
   public void calTotal(String filename, String outFileName) throws MXException, RemoteException, InterruptedException, Exception
   {

      mxLog.writeLog(getClass().getName() + ".calTotal(): Start Calculation");

      // Sort file
      String sortfilename = filename + sortedfileext;
      if (MxSort.sort(sortCmd, filename, sortOpOpt, sortfilename) != 0)
      {
         // mxLog.writeLog(getClass().getName()+".calTotal(): Unable to sort file "+ filename);
         throw new Exception(getClass().getName() + ".calTotal(): Unable to sort file " + filename);
      }

      int linenum = 0;
      String inputText = null;

      try
      {
         File sortedFile = new File(sortfilename);
         FileReader fReader = new FileReader(sortedFile);
         BufferedReader bReader = new BufferedReader(fReader);
         String splitText[] = new String[6]; // 5 fields in the intermediate output file //GPTM 6 elements

         // String outFileName=sortfilename+".out1";
         File outFile = new File(outFileName);
         FileWriter fWriter = new FileWriter(outFile);
         BufferedWriter bWriter = new BufferedWriter(fWriter);

         // Intermediate File Format (Comma delimited)
         // =================================================
         // Field 1: Asset ID
         // Field 2: Record Creation Date Time
         // Field 3: Transcation Type
         // Field 4: Staff Id (Id or NRIC)
         // Field 5: Activaty Date Time
         // Field 6: Type of the record -GPTM

         String curAssetID = "";
         ArrayList transRecs = new ArrayList();
         inputText = bReader.readLine();

         while (inputText != null)
         {

            linenum++;

            splitText = inputText.split(delimiter);
            String assetID = splitText[0];
            String recCrDT = splitText[1];
            String transType = splitText[2];
            String staffID = splitText[3];
            String actDT = splitText[4];
            String recType = splitText[5]; // GPTM code for identifying the system record

            if (assetID.compareTo(curAssetID) == 0)
            {

               TransRec transRec = new TransRec(actDT, recCrDT, staffID, transType, recType);
               transRecs.add(transRec);

            }
            else
            {
               if (transRecs.size() > 0)
               {
                  calAsset(curAssetID, transRecs, bWriter);
                  transRecs.clear();
               }

               curAssetID = assetID;

               TransRec transRec = new TransRec(actDT, recCrDT, staffID, transType, recType);
               transRecs.add(transRec);
            }

            inputText = bReader.readLine();

         }

         // Processing the last asset
         if (transRecs.size() > 0)
         {
            calAsset(curAssetID, transRecs, bWriter);
            transRecs.clear();
         }

         bWriter.close();
         fWriter.close();

         bReader.close();
         fReader.close();
      }
      catch (IOException e)
      {
         String errormsg;
         if (inputText != null)
         {
            errormsg = getClass().getName() + ".calTotal(): I/O Error at line(" + linenum + ")of '" + sortfilename + "' - '" + inputText
                     + "' (" + MxLog.genError(e) + ")";
         }
         else
         {
            errormsg = getClass().getName() + ".calTotal(): I/O Error reading text file '" + sortfilename + "'" + " (" + MxLog.genError(e)
                     + ")";
         }
         // mxLog.writeLog(errormsg);
         throw new Exception(errormsg);
      }
      catch (Exception e)
      {
         String errormsg;
         // if(inputText!=null){
         // errormsg = getClass().getName()+".calTotal(): Error at line("+linenum+")of '"+sortfilename+"' - '"+inputText+"' ("+MxLog.genError(e)+")";
         // }
         // else{
         errormsg = getClass().getName() + ".calTotal(): Unexpected error while processing text file '" + sortfilename + "'" + " ("
                  + MxLog.genError(e) + ")";
         // }
         // mxLog.writeLog(errormsg);
         throw new Exception(errormsg);
      }

      mxLog.writeLog(getClass().getName() + ".calTotal(): Calculation Done");

   }

   /*
    * Function to re-process the sort data for case of same activity date and time
    * Example:
    * BTT380,200602210250,0,BT$LPL
    * BTT380,200602210659,0,BT$NBK <-
    * BTT380,200602210659,1,BT$LPL <-
    * BTT380,200602211451,1,BT$NBK
    */
   private void processTransRecsArray(String assetID, ArrayList transRecs) throws Exception
   {

      TransRec curRec = null;
      TransRec nextRec = null;

      try
      {

         for (int i = 0; i < transRecs.size() - 1; i++)
         {

            // There is next record
            if (transRecs.size() > (i + 1))
            {

               curRec = (TransRec) transRecs.get(i);
               nextRec = (TransRec) transRecs.get(i + 1);

               // If Activity Dates of current and next record are the same
               if ((curRec.getActDT().compareTo(nextRec.getActDT()) == 0))
               {
                  // staff ID are not the same
                  if ((curRec.getStaffID().compareTo(nextRec.getStaffID()) != 0))
                  {
                     // If record creation time exactly the same
                     if ((curRec.getRecCrDT().compareTo(nextRec.getRecCrDT()) == 0))
                     {
                        // Check if current record has same staffID as 2 records after
                        if (transRecs.size() > (i + 2))
                        {
                           if (((TransRec) transRecs.get(i + 2)).getStaffID().compareTo(curRec.getStaffID()) == 0)
                           {
                              // Swap Current and Next
                              transRecs.set(i + 1, curRec);
                              transRecs.set(i, nextRec);

                              // Write Debug
                              String debugline = assetID + delimiter + curRec.getTransRecStr() + delimiter
                                       + "processTransRecsArray: Wrong Order(1) -> Swapped";
                              mxLog.writeLog(debugline);
                              debugline = assetID + delimiter + nextRec.getTransRecStr() + delimiter
                                       + "processTransRecsArray: Wrong Order(1) -> Swapped";
                              mxLog.writeLog(debugline);

                              continue;
                           }
                        }

                        // Check if next record has same staffID as 2 records before
                        if (i > 0)
                        {
                           if (((TransRec) transRecs.get(i - 1)).getStaffID().compareTo(nextRec.getStaffID()) == 0)
                           {
                              // Swap Current and Next
                              transRecs.set(i + 1, curRec);
                              transRecs.set(i, nextRec);

                              // Write Debug
                              String debugline = assetID + delimiter + curRec.getTransRecStr() + delimiter
                                       + "processTransRecsArray: Wrong Order(2) -> Swapped";
                              mxLog.writeLog(debugline);
                              debugline = assetID + delimiter + nextRec.getTransRecStr() + delimiter
                                       + "processTransRecsArray: Wrong Order(2) -> Swapped";
                              mxLog.writeLog(debugline);
                           }
                        }
                     }
                  }
                  else
                  {
                     // Login and Logoff for the same user as the same date time
                     if (curRec.getTransType().compareTo(nextRec.getTransType()) != 0)
                     {
                        // Extra Logoff (on the same minutes) => remove
                        if (nextRec.getTransType().compareTo(LOGOFF) == 0)
                        {
                           if (transRecs.size() > (i + 2))
                           {
                              TransRec aftNextRec = (TransRec) transRecs.get(i + 2);
                              // if 2 records after belongs to the same Staff ID and is logoff
                              if ((aftNextRec.getStaffID().compareTo(curRec.getStaffID()) == 0)
                                       && (aftNextRec.getTransType().compareTo(LOGOFF) == 0))
                              {
                                 transRecs.remove(i + 1); // remove extra logoff

                                 // Write Debug
                                 String debugline = assetID + delimiter + curRec.getTransRecStr() + delimiter
                                          + "processTransRecsArray: Extra login-logoff pair (1)";
                                 mxLog.writeLog(debugline);

                                 debugline = assetID + delimiter + nextRec.getTransRecStr() + delimiter
                                          + "processTransRecsArray: Extra login-logoff pair (1) -> Removed ";
                                 mxLog.writeLog(debugline);

                              }
                           }
                           else
                           {

                              // Write Debug
                              String debugline = assetID + delimiter + curRec.getTransRecStr() + delimiter
                                       + "[INFO]processTransRecsArray: Extra login-logoff pair (1) ";
                              mxLog.writeLog(debugline);

                              debugline = assetID + delimiter + nextRec.getTransRecStr() + delimiter
                                       + "[INFO]processTransRecsArray: Extra login-logoff pair (1) ";
                              mxLog.writeLog(debugline);

                           }
                        }
                        else
                        {
                           if (transRecs.size() > (i + 2))
                           {
                              TransRec aftNextRec = (TransRec) transRecs.get(i + 2);
                              // if 2 records after does not belows to same Staff ID
                              // i.e. next record is logon and the record after next is of another staffID
                              // -> causes logon without logoff
                              if (aftNextRec.getStaffID().compareTo(curRec.getStaffID()) != 0)
                              {
                                 transRecs.remove(i + 1); // remove extra logon

                                 // Write Debug
                                 String debugline = assetID + delimiter + curRec.getTransRecStr() + delimiter
                                          + "processTransRecsArray: Extra login-logoff pair (2)";
                                 mxLog.writeLog(debugline);

                                 debugline = assetID + delimiter + nextRec.getTransRecStr() + delimiter
                                          + "processTransRecsArray: Extra login-logoff pair (2) -> Removed ";
                                 mxLog.writeLog(debugline);

                              }
                           }
                           else
                           {
                              // Write Debug
                              String debugline = assetID + delimiter + curRec.getTransRecStr() + delimiter
                                       + "[INFO]processTransRecsArray: Extra logoff-login pair (2)";
                              mxLog.writeLog(debugline);

                              debugline = assetID + delimiter + nextRec.getTransRecStr() + delimiter
                                       + "[INFO]processTransRecsArray: Extra logoff-login pair (2)";
                              mxLog.writeLog(debugline);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
      catch (Exception e)
      {
         String errormsg;
         errormsg = getClass().getName() + ".processTransRecsArray(): Unexpected Error" + "(" + MxLog.genError(e) + ")"
                  + "\nCurrently Processing for:" + "\n\tAssetID=" + assetID;
         if (curRec != null)
         {
            errormsg += "\n\tCurrent Record:" + "\n\t\tRecord Creation DT=" + curRec.getRecCrDT() + "\n\t\tActivity DT="
                     + curRec.getActDT() + "\n\t\tTranscation Type(0=login,1=logoff)=" + curRec.getTransType() + "\n\t\tStaff ID="
                     + curRec.getStaffID();
         }
         if (nextRec != null)
         {
            errormsg += "\n\tNext Record:" + "\n\t\tRecord Creation DT=" + nextRec.getRecCrDT() + "\n\t\tActivity DT=" + nextRec.getActDT()
                     + "\n\t\tTranscation Type(0=login,1=logoff)=" + nextRec.getTransType() + "\n\t\tStaff ID=" + nextRec.getStaffID();
         }
         // mxLog.writeLog(errormsg);
         throw new Exception(errormsg);
      }
   }

   /*
    * Calculate running hours based on transcation of 1 asset
    */
   private void calAsset(String assetID, ArrayList transRecs, BufferedWriter bWriter) throws IOException, MXException, RemoteException,
            Exception
   {
      boolean isExpectLogOn = true;
      TransRec lstLogInRec = null; // Cannot be same as previous as there are cases of double logins
      TransRec prevRec = null;

      // Begin modification SR-110
      //      int totalduration = 0;
      double totalduration = 0;
      // End modification SR-110
      String lstReadingDT = null;

      TransRec curRec = null;

      processTransRecsArray(assetID, transRecs);
      try
      {

         for (int i = 0; i < transRecs.size(); i++)
         {
            curRec = (TransRec) transRecs.get(i);

            if (isExpectLogOn)
            {

               ///////////////////////////////
               // Expecting Log-on Transcation
               //////////////////////////////

               if (curRec.getTransType().compareTo(LOGON) == 0)
               {
                  ////////////////////////////////////
                  // Expected Case:Log-on transcation
                  ///////////////////////////////////

                  isExpectLogOn = false;
                  lstLogInRec = curRec;
               }
               else
               {
                  //////////////////////////////////////////////////////
                  // Special Case 1: Log-off transcation without Log-on
                  //////////////////////////////////////////////////////

                  // Write Debug
                  String debugline = assetID + delimiter + curRec.getTransRecStr() + delimiter + "Log-off without Log-on";

                  // Check if first record
                  if (i == 0)
                  {

                     ///////////////////////////////////////////////////////////////
                     // Special Case 1a: Expected login from previous day not found
                     ///////////////////////////////////////////////////////////////

                     // Calculate from last reading DT
                     // GPTM CHANGE FOR LOG-OFF WITHOUT LOG-ON -- START
/*
                     MxLocMeter locMeter = new MxLocMeter(userInfo);
                     Date meterLstReading = locMeter.getLastReadingDate(assetID, operHrMeterName);
                     if (meterLstReading != null)
                     {
                        //Calculate from last meter reading till current record
                        Date actDate = OISData.convertDate(curRec.getActDT());
                        // Begin modification SR-110
                        // int duration = (int)((actDate.getTime() - meterLstReading.getTime())/(1000 * 60));
                        double duration = (actDate.getTime() - meterLstReading.getTime()) / (1000 * 60);
                        // End modification SR-110

                        //Check if the duration base on the calculation is less than half a day (720 min)
                        if ((duration > 0) && (duration < 720))
                        {
                           //use the calculation
                           totalduration += duration;
                        }
                        else
                        {
                           //calculate from current day mid-night to the activity date
                           String midDT = curRec.getActDT().substring(0, 8) + "0000";
                           totalduration += OISData.calDuration(midDT, curRec.getActDT());
                        }
                     }
                     else
                     {
                        //if unable to get previous meter reading,
                        //calculate from current day mid-night to the activity date
                        String midDT = curRec.getActDT().substring(0, 8) + "0000";
                        totalduration += OISData.calDuration(midDT, curRec.getActDT());
                     }
*/
                     String dayStart = curRec.getActDT();
                     dayStart = dayStart.substring(0, (dayStart.length() - 4));
                     dayStart = dayStart + "0000";
                     totalduration += OISData.calDuration(dayStart, curRec.getActDT());
                     // GPTM CHANGE FOR LOG-OFF WITHOUT LOG-ON -- END

                     debugline += "(First Record)";
                     lstReadingDT = curRec.getActDT();

                  }
                  else
                  {

                     //////////////////////////////////////////
                     // Special Case 1b: Possible Double Logoff
                     //////////////////////////////////////////

                     if (curRec.getStaffID().compareTo(prevRec.getStaffID()) == 0)
                     {
                        // Double Logoff case:
                        // Calculate operation hour from previous record to current record
                        totalduration += OISData.calDuration(prevRec.getActDT(), curRec.getActDT());
                     }
                     else
                     {
                        // Note: Using Simple calculation
                        // Calculate operation hour from previous record to current record
                        totalduration += OISData.calDuration(prevRec.getActDT(), curRec.getActDT());
                     }

                     lstReadingDT = curRec.getActDT();
                     debugline += "(Not First Record)";
                  }

                  mxLog.writeLog(debugline);

               }

            }
            else
            {
               /////////////////////////////////
               // Expecting Log-off Transcation
               /////////////////////////////////

               if (curRec.getTransType().compareTo(LOGON) == 0)
               {

                  //////////////////////////////////
                  // Special Case 2: 2nd Log-on read
                  //////////////////////////////////

                  if (curRec.getStaffID().compareTo(lstLogInRec.getStaffID()) != 0)
                  {

                     ////////////////////////////////////////////////////////////////////////////
                     // Case 2a : Different staffID -> previous log-on transcation without log-off
                     ////////////////////////////////////////////////////////////////////////////

                     // Note: Simple Calculation Used
                     // Calculate duration from first logon to second logon
                     // (assuming logoff of the 1st logon is before the 2nd logon)
                     totalduration += OISData.calDuration(lstLogInRec.getActDT(), curRec.getActDT());

                     // Write debug Msg
                     String debugline = assetID + delimiter + lstLogInRec.getTransRecStr() + delimiter
                              + "Log-on without Log-off (Not last record 1)";
                     mxLog.writeLog(debugline);

                     lstReadingDT = curRec.getActDT();
                     lstLogInRec = curRec;

                  }
                  else
                  {
                     ////////////////////////////////////////////////////////////////
                     // Case 2b : Same staffID -> double log-on transcation => ignore
                     ////////////////////////////////////////////////////////////////
                  }

               }
               else
               {
                  //////////////////////////////////
                  // Expected Case : LogOff read
                  //////////////////////////////////

                  if (curRec.getStaffID().compareTo(lstLogInRec.getStaffID()) == 0)
                  {
                     ////////////////////////////////////////
                     // Expected Case: Expected Log-Off Read
                     ////////////////////////////////////////
                     // Case: Found a pair of log-in & log-off transcation

                     // Calculate operation hour
                     totalduration += OISData.calDuration(lstLogInRec.getActDT(), curRec.getActDT());

                  }
                  else
                  {
                     /////////////////////////////////////////////////////
                     // Special Case 3: Log-off belongs to different user!
                     //////////////////////////////////////////////////////

                     // Note: Extreme Case!
                     // 1st Logon w/o logoff
                     // 2nd Logoff w/o logon

                     // Note: Simple Calcuation Used
                     // Assume: There is 1st logoff immediately follow by 2nd logon
                     // Calculation Method: Ignore different user and find the duration btw logon & logoff
                     totalduration += OISData.calDuration(lstLogInRec.getActDT(), curRec.getActDT());

                     // Write debug file
                     // Logoff 1
                     String debugline = assetID + delimiter + lstLogInRec.getTransRecStr() + delimiter
                              + "Log-on without Log-off (Not last record 2)";
                     mxLog.writeLog(debugline);

                     // Logoff 2
                     debugline = assetID + delimiter + curRec.getTransRecStr() + delimiter + "Log-off without Log-on (Not first record)";
                     mxLog.writeLog(debugline);

                  }

                  lstReadingDT = curRec.getActDT();
                  isExpectLogOn = true;
                  lstLogInRec = null;

               }
            }

            prevRec = curRec;

         }
      }
      catch (Exception e)
      {
         String errormsg;
         errormsg = getClass().getName() + ".processTransRecsArray(): Unexpected Error " + "(" + MxLog.genError(e) + ")"
                  + "\nCurrently Processing for:" + "\n\tAssetID=" + assetID;
         if (curRec != null)
         {
            errormsg += "\n\tCurrent Record:" + "\n\t\tRecord Creation DT=" + curRec.getRecCrDT() + "\n\t\tActivity DT="
                     + curRec.getActDT() + "\n\t\tTranscation Type(0=login,1=logoff)=" + curRec.getTransType() + "\n\t\tStaff ID="
                     + curRec.getStaffID();
         }

         // mxLog.writeLog(errormsg);
         throw new Exception(errormsg);

      }
      /*
      if(prevRec!=null){
         //Last Reading Date = Last Entry's Date
         lstReadingDT = prevRec.getActDT();
      }
       */

      ////////////////////////////
      // Last LogOn without LogOff
      ////////////////////////////
      if (!isExpectLogOn && curRec.getRecType().equalsIgnoreCase(OIS))
      {
         // GPTM: System Created logoff at the end of the day to close the record
         String dayEnd = curRec.getActDT();
         dayEnd = dayEnd.substring(0, dayEnd.length() - 4);
         DateFormat format_date = new SimpleDateFormat("yyyyMMdd");
         Date d = format_date.parse(dayEnd);
         Calendar cal = Calendar.getInstance();
         cal.setTime(d);
         cal.add(Calendar.DATE, 1);
         dayEnd = format_date.format(cal.getTime()) + "0000";
         lstReadingDT = lstLogInRec.getActDT();
         totalduration += OISData.calDuration(lstReadingDT, dayEnd);

         // Write transcation to output file for next day processing
         String writeline = assetID + delimiter + lstLogInRec.getTransRecStr4nextday(dayEnd) + "\n"; // GPTM: change getTransRecStr to getTransRecStr4nextday
         bWriter.write(writeline);

         // Write debug file
         /*
          String debugline = assetID + delimiter + lstLogInRec.getTransRecStr()+ delimiter + "Log-on without Log-off (Last record)";
          debug.file(debugline,true);
          */
      }

      if (totalduration != 0)
      {
         OISData data = new OISData(assetID, 0, totalduration, lstReadingDT);
         finalDataArray.add(data);
      }
   }

   /**
    * @author HCHA
    * @date Mar 9, 2006
    * @function Process the input file and the send the result to Maximo
    * @param filename
    * @param prevDayFileBase
    * @param extSys
    * @param intIface
    * @param intObject
    * @param isdelta
    * @param inspector
    * @return String stating that Location not found in database
    * @throws MXException
    * @throws RemoteException
    * @throws InterruptedException
    * @throws IOException
    * @throws Exception
    */
   /*
    * SR-45 : catch lines with error
    * Changed the return type to String[] to be able to return also the list of lines with error
    */
   public String[] processFile(String filename, String prevDayFileBase, String extSys, String intIface, String intObject, String isdelta,
            String inspector, String EMSAssetIDCfgFile) throws MXException, RemoteException, InterruptedException, IOException, Exception
   {
      mxLog.writeLog(getClass().getName() + ".processFile()");

      // Get Date of the input datafile (last 8 character of the filename)
      String filedate = filename.substring(filename.length() - 8, filename.length());
      Date curDate = OISData.convertDate(filedate + "0000");
      if (curDate == null)
      {
         // mxLog.writeLog(getClass().getName()+".processFile(): Invalid filename '"+ filename+"'. Unable to retrieve date from filename!");
         throw new Exception(getClass().getName() + ".processFile(): Invalid filename '" + filename
                  + "'. Unable to retrieve date from filename!");
      }

      // 1s = 1000ms
      // 1min = 60s
      // 1hr = 60min
      // 1 day = 24 hours
      Date prevDate = new Date(curDate.getTime() - (24 * 60 * 60 * 1000));

      // Output file of current day for the next day processing
      String outprevfilename = prevDayFileBase + filedate + outputprevfileext;

      // Get name of previous day output file
      DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
      String prevDateStr = fileDateFormat.format(prevDate);
      String prevDayFile = prevDayFileBase + prevDateStr + outputprevfileext;

      // Name of intermediate file
      String outfilename = filename + outputfileext;

      // SR-45 AGD : catch lines with error
      String[] returnMsg = { null, null };
      returnMsg[1] = readDataFile(filename, prevDayFile, outfilename, EMSAssetIDCfgFile);
      calTotal(outfilename, outprevfilename);

      OISJmsMessage msg = new OISJmsMessage(extSys, intIface);
      MxXmlLocMeter xmlGen = new MxXmlLocMeter(extSys, intIface, intObject, operHrMeterName, isdelta, inspector);

      String locNotFound = new String();
      int nbLocNotFound = 0;
      OISData curData = null;
      try
      {
         for (int j = 0; j < finalDataArray.size(); j++)
         {
            curData = (OISData) finalDataArray.get(j);
            EMSSite site = new EMSSite(curData.getAssetID(), userInfo);

            if (site.getOrgID() != null && site.getSiteID() != null)
            {
               String xml;

               // Send Running Hours Meter Data (Read-only)
               xmlGen.setMetername(operHrMeterName);
               xml = xmlGen.genXml(site.getOrgID(), site.getSiteID(), curData.getAssetID(), curData.getActLastReadingDT(), String
                        .valueOf(curData.getDurationHr()));
               msg.sendMessage(xml.getBytes());

               // Send Running Hours Meter Data (Modifiable)
               xmlGen.setMetername(operHrMeterNameM);
               xml = xmlGen.genXml(site.getOrgID(), site.getSiteID(), curData.getAssetID(), curData.getActLastReadingDT(), String
                        .valueOf(curData.getDurationHr()));
               msg.sendMessage(xml.getBytes());
            }
            else
            {
               nbLocNotFound++;
               locNotFound += curData.getAssetID() + "\t" + curData.getActLastReadingDT() + "\t" + String.valueOf(curData.getDurationHr())
                        + "\n";
            }
         }
      }
      catch (Exception e)
      {
         String errormsg;
         errormsg = getClass().getName() + ".processFile(): Unexpected Error " + "(" + MxLog.genError(e) + ")"
                  + "\nCurrently Writing to Queue for: AssetID=" + curData.getAssetID();
         mxLog.writeLog(errormsg);
         e.printStackTrace();
         throw new Exception(errormsg);
      }

      if (nbLocNotFound != 0)
      {
         mxLog.writeLog(getClass().getName() + ".processFile(): " + nbLocNotFound + " Locations not found in the database!");
         String title = "[OIS Other Equipment Running Hours]\n" + "Date: " + new Date() + "\n"
                  + "List of locations not found in the database:\n" + "LocationID" + "\t" + "Last Reading" + "\t" + "Running Hrs\n";
         String locNotFoundErrMsg = title + locNotFound;

         // SR-45 AGD : catch lines with error
         returnMsg[0] = locNotFoundErrMsg;
         // return locNotFoundErrMsg;
      }

      // SR-45 AGD : catch lines with error
      return returnMsg;
      // return null;

   }

   /**
    * @author HCHA
    * @date Mar 2, 2006
    * @function [For debug purpose only] Write data array list to file
    * @param outFileName
    */
   public void writeFinalArrayToFile(String outFileName)
   {
      writeArrayToFile(finalDataArray, outFileName);
   }

   /**
    * @author HCHA
    * @date Mar 2, 2006
    * @function [For debug purpose only] Write data array list to file
    * @param arraylst
    * @param outFileName
    */
   private void writeArrayToFile(ArrayList arraylst, String outFileName)
   {

      try
      {

         File outFile = new File(outFileName);
         FileWriter fWriter = new FileWriter(outFile);
         BufferedWriter bWriter = new BufferedWriter(fWriter);

         // Write Header
         String writeHdr = new String();
         writeHdr = "AssetID,";
         writeHdr += "ActLastReadingDT,";
         writeHdr += "NumContainer,";
         writeHdr += "Duration";
         bWriter.write(writeHdr);

         for (int j = 0; j < arraylst.size(); j++)
         {

            OISData temp = (OISData) arraylst.get(j);

            String writeline = new String();
            writeline = "\n" + temp.getAssetID() + ",";
            writeline += temp.getActLastReadingDT() + ",";
            writeline += String.valueOf(temp.getNumContainer()) + ",";
            writeline += String.valueOf(temp.getDuration());

            bWriter.write(writeline);
         }

         bWriter.close();
         fWriter.close();
      }
      catch (IOException e)
      {
         mxLog.writeLog("OISOthEquipHr.writeArrayToFile(): Error writing text file : " + e);
      }

      catch (Exception e)
      {
         mxLog.writeLog("OISOthEquipHr.writeArrayToFile(): Unexpected error writing text file : " + e);
      }

   }

   /*
    * Clears Calculation Results stored in finalDataArray
    */
   public void clearResult()
   {
      finalDataArray.clear();
   }

}
