package com.psa.custom.ois;


import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import psdi.server.SimpleCronTask;
import psdi.util.MXException;

import java.io.File;
import java.io.IOException;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxSCP;
import com.psa.custom.common.MxZip;


import psdi.app.system.CrontaskInstanceRemote;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

/**
 * @author		HCHA
 * @class		OISCronTask
 * @date		Feb 27, 2006
 * @function	Cron Task Class for OIS
 */
public class OISCronTask extends SimpleCronTask
{

	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
	private static final String SPACE = " ";
    private static final String dotdot = ":"; 
    private static final String BACKUP_DIRECTORY = "backup";
    //private static final String asterisk = "*";
    	
    //Parameters 
    protected String adminEmail;		//Adminstrator Email
    protected String emailSubj;			//Alert Email Subject
    protected String intIface;			//Name of Integration Interface
    protected String intObject;			//Name of Integration Object
    protected String extSys;			//Name of External System
    protected String scpConfigFile; 	//SCP - Configuration File
    protected String remoteFilePath;	//Path where import file is
    protected String remoteServer;		//Remote server tor retreive the flatfile
    protected String localDirectory;	//Local directory to copy file to
    protected String impBaseFileName;	//Import Base File Name
    protected String impFileExt;		//Import File Extension
    protected String inspector;			//Meter Reading Inspector
    protected String unzipExec;			//Executable/Command for unzip function
    protected boolean enableLog;		//Enable Log
    protected String processDirectory;	//Directory where processing are done
    protected String logDir;			//Directory where log file will be placed
    protected String EMSAssetIDCfgFile; //20060824 HCHA - Config Filename for Location Conversion

    //For Cron Task
    protected String qualifiedInstanceName;
    protected RecoveryService recoveryService;
    
    protected File loadDir;
    
    protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
    protected MxLog mxLog;
    protected MxEmail email;
    
    protected boolean initialized;
  
	/* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Refresh Cron Task setting.  
     */
    
     protected void refreshSettings()
     {
         try {
        	 
        	 //Integration Objects
        	 extSys = getParamAsString("EXTSYSNAME");
             intIface = getParamAsString("INTERFACE");
             intObject = getParamAsString("INTOBJECT");

             //Paramaters for SCP
             scpConfigFile = getParamAsString("SCPCONFIGFILE");
             remoteFilePath = getParamAsString("REMOTEFILEPATH");            
             remoteServer = getParamAsString("REMOTESERVER");  
             
             //Paramater for Unzip
             unzipExec = getParamAsString("UNZIPEXEC");        
               
             //Email Parameters
             adminEmail = getParamAsString("ALERTEMAIL");
             email.setAdmin(adminEmail);
             emailSubj = getParamAsString("ALERTEMAILSUBJ");
             
             //Inspector for Location Meter
             inspector = getParamAsString("INSPECTOR");            
             
             //Input File Name
             impBaseFileName = getParamAsString("IMPBASEFILENAME");
             impFileExt = getParamAsString("IMPFILEEXT");

             
             //Log
             logDir = getParamAsString("LOGDIRECTORY"); 
             enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y")==0);
               
             DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
             String todayDate=fileDateFormat.format(new Date());
             String logFileName=logDir+impBaseFileName.replaceAll("yyyymmdd",todayDate)+".log";
             
             //20060810 HCHA - Modify to replace with by previous day's if "yyyymmpd" is specified in import file base name            	
     		 Calendar cal = Calendar.getInstance();
     		 cal.add(Calendar.DAY_OF_MONTH,-1);            					
     		 String prevDate = fileDateFormat.format(cal.getTime());
     		 logFileName=logFileName.replaceAll("yyyymmpd",prevDate);
             
             mxLog.setEnabled(enableLog);
             mxLog.setLogFilePath(logFileName);
             mxLog.setLogTag(getName());
             mxLog.createLogFile();
             
             
             //Main Directory to transfer file 
             localDirectory = getParamAsString("LOCALDIRECTORY"); 
             
             //Directory where processing are done
             processDirectory= getParamAsString("PROCESSDIRECTORY");	
             
             loadDir = new File(localDirectory);  
             //Removed by WMJ 20120820 for MX7 recoveryService 
             //recoveryService = new RecoveryService(loadDir);
             
             //20060824 HCHA - Config Filename for Location Conversion
             EMSAssetIDCfgFile = getParamAsString("EMSASSETIDCFGFILE"); 
            
         }
         catch(Exception exception) {
             if(integrationLogger.isErrorEnabled())
                 integrationLogger.error(exception.getMessage(), exception);
         }


     }
    

    
	/**
	 * 
	 */

	public OISCronTask() {
		super();
		
    	initialized = false;
    
	    recoveryService = null;    	
	    qualifiedInstanceName = null;
	    
	    
	    //Default value
    	emailSubj="OIS Flat File import error. Cron Task stopped!";
    	
    	//Init Parameters
    	adminEmail=null;
    	intIface=null;
    	intObject=null;
    	extSys=null;
    	scpConfigFile=null;
    	remoteFilePath=null;
    	remoteServer=null;
    	localDirectory=null;
    	logDir=null;
    	impBaseFileName=null;
    	impFileExt=null;
    	unzipExec=null;
	    inspector=null;
	    enableLog=false;
	    processDirectory=null;


	}


	/* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function]Initialize cron task  
     */

	public void init() 
    	throws MXException
    {
    	
    	super.init();
    	
        mxLog = new MxLog();  
        email = new MxEmail(adminEmail);
        initialized = true;
         
    }
   
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function] Start cron task   
     */

    public void start() {
    	
        try {
            refreshSettings();
            
            mxLog.writeLog(getName()+".start()");
            
            MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Start - " + qualifiedInstanceName + " started for System:" + extSys + " and Interface:" + intIface );
            setSleepTime(0L);
        }
        catch(Exception exception) {
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
        }
    }

    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function]Stop cron task  
     */

    public void stop() 
    {
    	
    	try{
            mxLog.writeLog(getName()+".stop()");
    		mxLog.closeLogFile();
    	}
    	catch(Exception exception){
            if(integrationLogger.isErrorEnabled())
                integrationLogger.error(exception.getMessage(), exception);
    	}
    			
    		MicUtil.INTEGRATIONLOGGER.info("["+getName()+"] Stop - " + 
        		qualifiedInstanceName + 
        		" stopped for System:" + 
        		extSys + 
        		" and interface:" + 
        		intIface );
    }


    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function] Set cron task instance  
     */

    public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote) {
		
    	
        try {
        	
            super.setCrontaskInstance(crontaskinstanceremote);
            qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") + 
            	"." + crontaskinstanceremote.getString("instancename");
        }
        catch(Exception exception) {
            integrationLogger.error(exception.getMessage(), exception);
        }
    }


    
    /* Author: HCHA
     * Date: 28 FEB 2006
     * Comment: returns true if all required parameter is set
     */

    protected boolean isReqParamSet()
    {
    	return true; 
    }
   
    
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: [Standard Cron Task Function]
     * Cron task function - Retrieve flat file from remote server,
     * 						process flat file, convert to xml format and import to maximo.
     * Modified:
     * 	20060810 HCHA - Modify to replace with by previous day's if "yyyymmpd" is specified in import file base name
     * 	20061025 HCHA - Modify check if the file is already processed
     */
	public void cronAction() 
	{
    	
		mxLog.writeLog(getName()+".cronAction(): Start CronTask Action");
		
        try {
        	
        	
            if(!initialized){
            	mxLog.writeLog(getName()+".cronAction(): CronTask not initialized!");
                throw new Exception(getName()+".cronAction(): CronTask not initialized!");
            }

        	// Refresh setting before perform cron action
            refreshSettings();
   
        	if (isReqParamSet()) {
        		
        		if(impBaseFileName.endsWith("*")) {
                	//////////////////////////////////////////////////////
                	//Batch Operation - Process All file in the directory
                	//////////////////////////////////////////////////////
        			processFolderData();
        		}
        		else{
                   	
                	///////////////////////////////////////////
                	//Normal Operation - Use current day file
                	///////////////////////////////////////////
                	
                    //Replace filename by today's date if "yyyymmdd" is specified in import file base name
        			DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
                    String todayDate=fileDateFormat.format(new Date());
                    String impFileName=impBaseFileName.replaceAll("yyyymmdd",todayDate)+impFileExt;
                    
                    //20060810 HCHA - Modify to replace with by previous day's if "yyyymmpd" is specified in import file base name            	
            		Calendar cal = Calendar.getInstance();
            		cal.add(Calendar.DAY_OF_MONTH,-1);            					
            		String prevDate = fileDateFormat.format(cal.getTime());
            		impFileName=impFileName.replaceAll("yyyymmpd",prevDate);
                    
            		//20061025 HCHA - Modify check if the file is already processed
            		File checkBackupFile = new File(localDirectory+BACKUP_DIRECTORY+File.separator+impFileName); 
            		if(checkBackupFile.exists()){
            			mxLog.writeLog(getName()+".cronAction(): File has already been processed.");
            			mxLog.writeLog(getName()+".cronAction(): Stopping Crontask...");
            			return;
            		}
            		
                    File dataFile = new File(localDirectory+impFileName); 
                    
	        		// Check file is in local drive?
	        		if (!dataFile.exists()) {
	        		
	        			//////////////////////
	        			// Get File Using SCP
	        			//////////////////////
	        			
	        			mxLog.writeLog(getName()+".cronAction(): Starting SCP, getting "+impFileName+" from "+ remoteServer +"..." );	        		
		        		
	        			// Get file from remote Server
		        		MxSCP scp = new MxSCP();
		        		
		        		/* Modified by BCT to validate if remoteServer is null  - Start */
		        		String scpParam="";
	        			
	        			//String scpParam = scpConfigFile + SPACE +        				       				
	        				//remoteServer + dotdot +  remoteFilePath + impFileName + SPACE + localDirectory;
		        		if (remoteServer!=null){
                            scpParam = scpConfigFile + SPACE + remoteServer + dotdot +  remoteFilePath + impFileName + SPACE + localDirectory;
		        		}
                        else{
                            scpParam = scpConfigFile + SPACE + remoteFilePath + impFileName + SPACE + localDirectory;
                        }
		        		/* Modified by BCT to validate if remoteServer is null  - End */
		        		if (scp.getFlatFile(scpParam) != 0) {	  	        			
		            		throw new Exception("Cannot get remote file - "+remoteServer + dotdot +  remoteFilePath + impFileName  + ".");
		        		}	
		        		
		        		if (!dataFile.exists()) {
		        			throw new Exception("Remote file transfer not succesful. File '"+dataFile.toString()+"' cannot be found.");
		        		}
		        		
		        		mxLog.writeLog(getName()+".cronAction(): Finished SCP...");
	                }
	        		
	        		
	        		processData(dataFile);
        		}

        		
        	} 
        	else { 
        		mxLog.writeLog(getName()+".cronAction(): Required parameters not set.");
        		throw new Exception("Required parameters not set.");        	
        	}

        }
        catch(Exception e) {
        	
            MicUtil.INTEGRATIONLOGGER.error("["+getName()+"] "+e.getMessage(), e);                   
            
            String emailContent = genEmail(e);
            email.send(emailSubj,emailContent );
          	mxLog.writeLog("Email Sent:\n"+emailContent); 
            
            stop();
        }       
        
        mxLog.writeLog(getName()+".cronAction(): End CronTask Action");
  
	}
	
    /* Author: HCHA
     * Date: 28 FEB 2006
     * Comment: Process the import flat file   
     */

	protected void parseFlatFile(String file)	
		throws MXException, RemoteException, IOException, InterruptedException, Exception
	{
		
	}
	
	
	/* Author: HCHA
     * Date: 16 MAR 2006
     * Comment: Generate Email   
     */
	
	private String genEmail(Exception e){
		
        //Form Email Message
        String emailMsg = "Date: " + new Date()+"\n";
        emailMsg += "Error in CronTask: "+getName()+ "\n";
        emailMsg+="Error Message: "+ e.getMessage()+"\n";
        emailMsg+="Detail:\n";
        emailMsg+=e.toString()+"\n"; 
        StackTraceElement element[] = e.getStackTrace();
        for(int i=0; i< element.length; i++){
        	emailMsg+="\tat "+ element[i].toString()+"\n";	
        }
        
        return emailMsg;
		
	}
	
    /* Author: HCHA
     * Date: 16 MAR 2006
     * Comment: Process the import flat file   
     */

	public void processData(File dataFile)
		throws Exception
	{
	  	try {
			//Added by WMJ 20120820 for MX7 RecoveryService
            recoveryService = new RecoveryService(dataFile);
		  	//recoveryService.startRecovery();	                    
			
	    	try {	        		                    	                        	                    		                    		                    		                    
	            
	System.out.println("--inside processData--");
	    		MxFileCopy.fileCopy(localDirectory+dataFile.getName(), processDirectory+dataFile.getName());
	    		
	    		String cmd = unzipExec + SPACE + processDirectory + dataFile.getName();
	    		mxLog.writeLog(getName()+".processFolderData(): Unzip using cmd: " + cmd);
	    		if ( MxZip.unzipFile(cmd)== 0 )
	    		{	                			
	    			
	    			String file = processDirectory + dataFile.getName();
	                //String file = afile[j].toString();
	                // Remove extension
	                file=file.substring(0,file.length()-impFileExt.length());
	                
	                File unzippedFile = new File(file);
	                if(!unzippedFile.exists()){
	                	mxLog.writeLog(getName()+".processFolderData(): Unable to find unzipped file - "+file+".");
	                	throw new Exception(getName()+".processFolderData(): Unable to find unzipped file- "+file+".");
	                }
	                
	                //Parse flat file 
	                parseFlatFile(file);
	                
	                //Delete unziped file
	                unzippedFile.delete();
	
	    		}
	    		else{
	    			mxLog.writeLog(getName()+".processData(): Unable to unzip file - " + dataFile.getName());
	    			throw new Exception(getName()+".processData(): Unable to unzip file - " + dataFile.getName());
	    		}
	    		
	    	} 
	    	finally {	                    	
	    		try {
	        			
	    			mxLog.writeLog(getName()+".processData(): recoveryService.endRecovery");	                        	
	    			recoveryService.endRecovery();
	                    
	    		} 
	    		catch(Exception e){
	    			MicUtil.INTEGRATIONLOGGER.error("["+getName()+"] "+e.getMessage(), e);
	                    
	    		}
	    	}
	  	}
        catch(Exception e) {        	
        	mxLog.writeLog("[ERROR] "+e.getMessage());
        	
            MicUtil.INTEGRATIONLOGGER.error("["+getName()+"] "+ e.getMessage(), e);            
                      
            String emailContent = genEmail(e);
            email.send(emailSubj,emailContent );
          	mxLog.writeLog("Email Sent:\n"+emailContent); 
          	
            stop();
        }
	}
	
    /* Author: BTE
     * Date: 13 FEB 2006
     * Comment: Process the import flat files in the folder   
     */

    public void processFolderData() throws Exception {

    	mxLog.writeLog(getName()+".processFolderData(): Start Processing Files in Folder");

    	//remove the "*" in the filename
    	String impFileStart = impBaseFileName.substring(0,impBaseFileName.length()-1);
    	
    	try {    		
    		File afile[] = loadDir.listFiles();

    		if(afile != null) {
    				    		
    			int i = afile.length;
	            
    			for(int j = 0; j < i; j++) {
    				
    				if(afile[j].isFile() && afile[j].getName().toLowerCase().startsWith(impFileStart) && afile[j].getName().toLowerCase().endsWith(impFileExt)) {
	            		
    					mxLog.writeLog(getName()+".processFolderData(): Processing "+afile[j].getName());
	                	processData(afile[j]);
	                	
	            	}
    			}
    		}
		}
        catch(Exception e) {        	
        	mxLog.writeLog(e.getMessage());
        	
            MicUtil.INTEGRATIONLOGGER.error("["+getName()+"] "+ e.getMessage(), e);            
                      
            String emailContent = genEmail(e);
            email.send(emailSubj,emailContent );
          	mxLog.writeLog("Email Sent:\n"+emailContent); 
          	
            stop();
        }
        
        mxLog.writeLog(getName()+".processFolderData(): End Processing Files in Folder");
	}

	/* Author: BTE
	 * Date: 21 FEB 2006
	 * Comment: Check file exist in local directory
	 */

	public boolean checkFileExist (String filename)
	{
 
		mxLog.writeLog(getName()+".checkFileExist()");
		
		File afile[] = loadDir.listFiles();
        
	    	if(afile != null) {
		        int i = afile.length;
		        
		        for(int j = 0; j < i; j++) {
		        	if(afile[j].isFile() && afile[j].getName().toLowerCase().compareTo(filename.toLowerCase())==0) {
	        			return true;
	        		}
	        	}
	    	}
		
		return false;		
	}
	


}

