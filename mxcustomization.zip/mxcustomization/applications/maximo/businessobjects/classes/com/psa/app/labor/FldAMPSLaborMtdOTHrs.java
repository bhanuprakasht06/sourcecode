/*
 * Modification history 
 * 
 * 07-09-20 :  BCT Modified (Oracle to SQL conversion)
 * 
 */


package com.psa.app.labor;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.MboValueAdapter;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXException;

public class FldAMPSLaborMtdOTHrs extends MboValueAdapter
{
	public FldAMPSLaborMtdOTHrs(MboValue mbv)
			throws MXException
	{
		super(mbv);
	}

	public void initValue()
			throws MXException, RemoteException
	{
		super.initValue();
	
	    double laborMtdOTHrs = 0.0D;
	    int laborMtdOTHrs_int = 0;
	    MboRemote mboRemote = getMboValue().getMbo();
	    MboValue laborMtdOTHrsTotal = getMboValue();
	    
	
	    if (!getMboValue("laborcode").isNull())
	    {
	    	MboSetRemote laborTransSetA = MXServer.getMXServer().getMboSet("LABTRANS", mboRemote.getUserInfo());

	    	/*
	    	 * 
	    	 * 03-09-2020
	    	 * <START> - Code below has been commented as part of the DB migration from Oracle to SQL 
	    	 
	    	SqlFormat sqlformatLabA = new SqlFormat(mboRemote.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE>=trunc(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1) and FINISHDATE>=trunc(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1) and FINISHDATE<trunc(LAST_DAY(SYSDATE)+1)");
			
			* <END>	    	
	    	*/
	    	
	    	SqlFormat sqlformatLabA = new SqlFormat(mboRemote.getUserInfo(), "LABORCODE = :1 AND PSA_OT_FLAG = :2  AND  cast(startdate as date) >= cast ( DATEADD(month, DATEDIFF(month, 0, getdate()),0) as date) AND cast(finishdate as date) >= cast ( DATEADD(month, DATEDIFF(month, 0, getdate()),0) as date) AND cast(finishdate as date) < cast ( DATEADD(month, DATEDIFF(month, 0, getdate())+1,0) as date)");
			sqlformatLabA.setObject(1, "LABTRANS", "LABORCODE", mboRemote.getString("laborcode"));
	    	sqlformatLabA.setObject(2, "LABTRANS", "PSA_OT_FLAG", "1");
	    	laborTransSetA.setWhere(sqlformatLabA.format());
	    	
	    	
			MboSetRemote laborTransSetB = MXServer.getMXServer().getMboSet("LABTRANS", mboRemote.getUserInfo());
			
			/*
	    	 * 03-09-2020
	    	 * <START> - Code below has been commented as part of the DB migration from Oracle to SQL 
	    	 
	    	SqlFormat sqlformatLabB = new SqlFormat(mboRemote.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and STARTDATE<trunc(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1) and FINISHDATE>=trunc(LAST_DAY(ADD_MONTHS(SYSDATE,-1))+1) and FINISHDATE<trunc(LAST_DAY(SYSDATE)+1)");
			
			* <END>	    	
	    	*/
			SqlFormat sqlformatLabB = new SqlFormat(mboRemote.getUserInfo(), "LABORCODE = :1 and PSA_OT_FLAG = :2 and cast(startdate as date)  <  cast ( DATEADD(month, DATEDIFF(month, 0, getdate()),0) as date) and cast(finishdate as date) >= cast ( DATEADD(month, DATEDIFF(month, 0, getdate()),0) as date) and cast(finishdate as date) <  cast ( DATEADD(month, DATEDIFF(month, 0, getdate())+1,0) as date)");
			sqlformatLabB.setObject(1, "LABTRANS", "LABORCODE", mboRemote.getString("laborcode"));
	    	sqlformatLabB.setObject(2, "LABTRANS", "PSA_OT_FLAG", "1");
	    	laborTransSetB.setWhere(sqlformatLabB.format());
	 	    
	    	Calendar calThisMth = Calendar.getInstance();
			calThisMth.set(Calendar.DATE, 1);
			calThisMth.set(Calendar.HOUR_OF_DAY, 0);
	        calThisMth.set(Calendar.MINUTE, 0);
	        calThisMth.set(Calendar.SECOND, 0);
	        calThisMth.set(Calendar.MILLISECOND,0);
			Date thisMthFirstDate = calThisMth.getTime();
			LabTransCustomRemote labtrans;
			
	    	for (int i = 0; (labtrans = (LabTransCustomRemote)laborTransSetB.getMbo(i)) != null; i++)
	     	{
		     	labtrans.checkDates();
		     	Date dtFinish = labtrans.validateDateTime(labtrans.getDate("finishdate"), labtrans.getDate("finishtime"));
	    		Date dtStart = labtrans.validateDateTime(thisMthFirstDate, thisMthFirstDate);
	
		     	if ((dtFinish != null) && (dtStart != null))
			    {
		     		laborMtdOTHrs = laborMtdOTHrs + (dtFinish.getTime() - dtStart.getTime()) / 3600000.0D;
			    }	     	
		    }	    
	    	laborMtdOTHrs = laborMtdOTHrs + laborTransSetA.sum("REGULARHRS");    
	    	laborMtdOTHrs_int=(int)laborMtdOTHrs;
	    	int decimal_add=0;
	    	double decimal = laborMtdOTHrs-(int)laborMtdOTHrs;
	    	if (decimal>0)
	    		decimal_add=1;
	    	laborMtdOTHrs_int=laborMtdOTHrs_int+decimal_add;
	    }
	    laborMtdOTHrsTotal.setValue(laborMtdOTHrs_int, 11L);
	}
}