package com.psa.app.workorder;

import java.rmi.RemoteException;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class AutoCloseWOCustom
		implements ActionCustomClass
{

	
	private static final MXLogger mxLogger = MXLoggerFactory.getLogger("maximo.application.WORKORDER");
	/*
	 * Constructor - does nothing
	 */
	public AutoCloseWOCustom()
	{
	}


	/*
	 * Close WO
	 */
	public void applyCustomAction(MboRemote woremote, Object aobj[])
			throws MXException, RemoteException
	{
		mxLogger.debug("AutoCloseWOCustom - Entering");
		
		MboSetRemote mboStatusSet = null;
		MboRemote mboStatusRemote = null;
		
		woremote.setValue("HISTORYFLAG", true, 2L);
		woremote.setValue("STATUS", "CLOSE", 2L);
		mboStatusSet = woremote.getMboSet("WOSTATUS");
		mboStatusRemote = mboStatusSet.add(2L);
		mboStatusRemote.setValue("STATUS", "CLOSE", 2L);
		mboStatusRemote.setValue("CHANGEBY", woremote.getUserName(), 2L);
		mboStatusRemote.setValue("CHANGEDATE", MXServer.getMXServer().getDate(), 2L);
		mboStatusRemote.setValue("GLACCOUNT", woremote.getString("GLACCOUNT"), 2L);			
		
		woremote.getThisMboSet().save();
		mxLogger.debug("AutoCloseWOCustom - Leaving");
	}

	
}
