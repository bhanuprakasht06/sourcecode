/*
 * Modification history
 * 11-05-07	LS	SR-089	Add in visibletousser field in the routable WF
 */

package com.psa.workflow.virtual;

import java.rmi.RemoteException;

import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.util.MXException;
import psdi.workflow.virtual.FldInitWFProcessName;

public class FldInitWFProcessNameCustom extends FldInitWFProcessName 
{
	public FldInitWFProcessNameCustom(MboValue mbovalue) 
	{
        super(mbovalue);
	}

	public MboSetRemote getList()
		throws MXException, RemoteException
	{
		String OrigListWhere = getListCriteria();
		setListCriteria("active = :yes and objectname = :ownertable and processname not in (select processname from wfinstance where ownertable = :ownertable and ownerid = :ownerid and active = :yes) and visibletousers = :yes");
/*		Mbo mbo = getMboValue().getMbo();
		
		MboSetRemote mbosetremote = MXServer.getMXServer().getMboSet("WFPROCESS", mbo.getUserInfo());
        SqlFormat sqlformat = new SqlFormat(mbo.getUserInfo(), "active = :yes and objectname = :1 and processname not in (select processname from wfinstance where ownertable = :2 and ownerid = :3 and active = :yes) and visibletousers = :yes");
        sqlformat.setObject(1, "WFPROCESS", "OBJECTNAME", mbo.getString("OWNERTABLE"));
        sqlformat.setObject(2, "WFPROCESS", "OBJECTNAME", mbo.getString("OWNERTABLE"));
        sqlformat.setObject(3, "WFPROCESS", "OWNERID", mbo.getString("OWNERID"));
        mbosetremote.setWhere(sqlformat.format());
*/        
		MboSetRemote processnameset = super.getList();
		processnameset.setOrderBy("PROCESSNAME");
		processnameset.reset();
		
		setListCriteria(OrigListWhere);
		
		return processnameset;
	}
	
}
