
package com.psa.app.workorder;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.io.*;

import psdi.app.inventory.InvBalancesRemote;
import psdi.app.inventory.InvBalancesSetRemote;
import psdi.app.inventory.InventoryRemote;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.server.MXServer;
import psdi.mbo.*;
import psdi.app.inventory.MatRecTransRemote;
import psdi.app.inventory.MatRecTrans;
import psdi.app.location.*;
import psdi.app.inventory.*;
import java.rmi.RemoteException;
import java.sql.SQLException;
import psdi.app.inventory.MatRecTransRemote;
import psdi.common.action.ActionCustomClass;
//import psdi.mbo.DBShortcut;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import com.psa.app.workorder.RecondUtilCustom;



/*
 * Prints items reservations on storeroom's fax machine 
 */
public class RecWorkorderTransfer
		implements ActionCustomClass
{
	public RecWorkorderTransfer()
	{
	}


	public void applyCustomAction(MboRemote mboremote, Object aobj[])
    throws MXException, RemoteException
    {
							//System.out.println("start of RecWorkorderTransfer--version 1");
							wo = mboremote;
						mxLogger.debug("TransferPlansCustom - Entering");
							MboSetRemote woset = wo.getThisMboSet();
							woset.save();
							//System.out.println("-wo.getString(wonum)--" + wo.getString("wonum"));
						//System.out.println("-WO status-1-" + wo.getString ("STATUS"));
						String wonum = wo.getString("wonum");
							MboSetRemote wpMaterialset = wo.getMboSet("LOANPLANMATERIALS");
							if (wpMaterialset.isEmpty())
								return;
							MboRemote wpMaterialmbo =  wpMaterialset.getMbo(0);
							String loanid = wpMaterialmbo.getString("LOANID");
							if (loanid.equalsIgnoreCase("") || loanid == null || loanid.length() < 2)
								return;

						MboSetRemote matrectransSet = MXServer.getMXServer().getMboSet("MATRECTRANS", wo.getUserInfo());
						SqlFormat qsqf = new SqlFormat(wo.getUserInfo(), "loanid=:1 and itemnum=:2");
						qsqf.setObject(1, "MATRECTRANS", "loanid",loanid);
						qsqf.setObject(2, "MATRECTRANS", "itemnum",wpMaterialmbo.getString("itemnum"));
						matrectransSet.setWhere(qsqf.format());
						MboRemote matrectransMbo;
						MboSetRemote recTransSet = null;
						for (int k=0; (matrectransMbo = matrectransSet.getMbo(k)) != null;k++)
						{
							//System.out.println("getting details-k-" + k);
								String tostore=matrectransMbo.getString("fromstoreloc");
								String itemnum=matrectransMbo.getString("itemnum");
								String frombin=matrectransMbo.getString("tobin");
								String tobin=matrectransMbo.getString("frombin");
								double qty=matrectransMbo.getDouble("quantity");
								String linetype=matrectransMbo.getString("linetype");
								String issuetype=matrectransMbo.getString("issuetype");
								String fromlot=matrectransMbo.getString("tolot");
								String tolot=matrectransMbo.getString("fromlot");
								String fromconditioncode=matrectransMbo.getString("conditioncode");
								String conditioncode=matrectransMbo.getString("fromconditioncode");
								String enterby=wo.getUserName();
								String newsite=matrectransMbo.getString("fromsiteid");
								double conversion=matrectransMbo.getDouble("conversion");	
								String gldebitacct=matrectransMbo.getString("GLCREDITACCT");
								String glcreditacct=matrectransMbo.getString("GLCREDITACCT");
								String fromstoreloc=matrectransMbo.getString("tostoreloc");	
							//System.out.println("completed getting details--fromstoreloc-" + fromstoreloc);
								MboSetRemote storeSet = wo.getMboSet("$LOCATIONS", "LOCATIONS", "location='"+fromstoreloc+"' and type='STOREROOM'" );
							//System.out.println("----");
								if(!storeSet.isEmpty())
								{
									//System.out.println("-we1-");
									MboRemote storeroom=storeSet.getMbo(0);
									//System.out.println("-we43-");
									recTransSet = storeroom.getMboSet("MATRECTRANSOUT");
									//System.out.println("-we434-");
									try{										
							//System.out.println("-we2-");
										MboRemote rectrans = recTransSet.add();										
										rectrans.setValue("tostoreloc", tostore,2L);
										rectrans.setValue("itemnum", itemnum,2L);
										rectrans.setValue("frombin", frombin,2L);
							//System.out.println("-we3-");
										rectrans.setValue("tobin", tobin,2L);
										rectrans.setValue("quantity", wpMaterialmbo.getDouble("ITEMQTY"),2L);
										rectrans.setValue("linetype", linetype,2L);
							//System.out.println("-we4-");
										rectrans.setValue("issuetype", issuetype,2L);
										rectrans.setValue("gldebitacct", gldebitacct,2L);
							//System.out.println("-we5-");
										rectrans.setValue("glcreditacct", glcreditacct,2L);
										rectrans.setValue("itemsetid", matrectransMbo.getString("itemsetid"), 2L);
							//System.out.println("-we6-");
										if(!matrectransMbo.isNull("tolot"))
										{
											rectrans.setValue("fromlot", fromlot,2L);
										}
										if(!matrectransMbo.isNull("fromlot"))
										{
											rectrans.setValue("tolot", tolot,2L);
										}										
										if(!matrectransMbo.isNull("conditioncode"))
										{
											rectrans.setValue("fromconditioncode", fromconditioncode,2L);
										}
										if(!matrectransMbo.isNull("fromconditioncode"))
										{
											rectrans.setValue("conditioncode", conditioncode,2L);
										}	
										rectrans.setValue("enterby", enterby,2L);
										rectrans.setValue("conversion", conversion,2L);
										
										recTransSet.save();
							System.out.println("-we9-");
									}catch (Exception e) {
										e.printStackTrace();
									}
								}
								else
							{
								System.out.println("-set is empty-");
							}
						} //end of for loop of Transfers
										recTransSet.close();

						
/*

						MboSetRemote invreserveSet = MXServer.getMXServer().getMboSet("INVRESERVE", wo.getUserInfo());
						SqlFormat qsqf1 = new SqlFormat(wo.getUserInfo(), "wonum=:1");
						qsqf1.setObject(1, "INVRESERVE", "wonum",wonum);
						invreserveSet.setWhere(qsqf1.format());
						MboRemote invreserveMbo;
						for (int i=0; (invreserveMbo = invreserveSet.getMbo(i)) != null;i++)
						{
						System.out.println("-start of ISSUE-i-" + i);
							String location = invreserveMbo.getString("LOCATION");
							MboSetRemote storelocSet = wo.getMboSet("$LOCATIONS", "LOCATIONS", "location='"+location+"' and type='STOREROOM'" );
							if (!storelocSet.isEmpty())
							{
						System.out.println("-start of ISSUE setting-");
								MboRemote storeroom=storelocSet.getMbo(0);
								MboSetRemote issueset=storeroom.getMboSet("MATUSETRANSISSUE");
								MboRemote issue=issueset.add();
						System.out.println("-SOI 1-");
								issue.setValue("siteid", invreserveMbo.getString("STORELOCSITEID"),2L);
								issue.setValue("storeloc", invreserveMbo.getString("LOCATION"),2L);
						System.out.println("-SOI 2-");
								issue.setValue("tositeid", invreserveMbo.getString("SITEID"),2L);
								issue.setValue("itemnum", invreserveMbo.getString("ITEMNUM"),2L);
								issue.setValue("wonum", invreserveMbo.getString("WONUM"),2L);
						System.out.println("-SOI 3-");
								//String itemnum=(String)keyValueMap.get("itemnum");
								//String cond=(String)keyValueMap.get("conditioncode");
								
								//double qty=Double.parseDouble((String)keyValueMap.get("quantity"));
						System.out.println("-SOI 4-");
								issue.setValue("linetype", "ITEM",2L);
								//issue.setValue("quantity", (String)keyValueMap.get("quantity"),2L);
								issue.setValue("issuetype", "ISSUE",2L);
						System.out.println("-SOI 5-");
								//issue.setValue("binnum", (String)keyValueMap.get("binnum"),2L); 
								issue.setValue("conditioncode", invreserveMbo.getString("CONDITIONCODE"),2L);
								issue.setValue("QTYREQUESTED", invreserveMbo.getDouble("RESERVEDQTY"),2L);
								double QUANTITY =  invreserveMbo.getDouble("RESERVEDQTY") * -1.0D;
								issue.setValue("QUANTITY", QUANTITY,2L);
								//issue.setValue("lotnum", (String)keyValueMap.get("lotnum"),2L);
						System.out.println("-SOI 6-");
								issue.setValue("enterby", wo.getUserName(),2L);
								
								issueset.save();
						System.out.println("-SOI 7-");
							
						System.out.println("-SOI 8-");
							}
						} 
*/

						System.out.println("-END OF TRANSFER-WO status last-" + wo.getString ("STATUS"));


	}


/*


	        SqlFormat mrtsqlformat = new SqlFormat(mboremote.getUserInfo(), "INSERT INTO MATRECTRANS (ITEMNUM, TOSTORELOC, TRANSDATE, ACTUALDATE, QUANTITY, RECEIVEDUNIT, ISSUETYPE,			UNITCOST, ACTUALCOST,   CONVERSION,ENTERBY      , TOBIN, GLDEBITACCT, GLCREDITACCT, LINECOST, CURRENCYCODE, EXCHANGERATE, CURRENCYUNITCOST, CURRENCYLINECOST, DESCRIPTION, FROMSTORELOC, FROMBIN, LOADEDCOST, TAX1, TAX2, TAX3, TAX4, TAX5, PRORATED,  STATUS,  EXCHANGERATE2, LINECOST2,ORGID, SITEID,     FROMSITEID,  LINETYPE, ITEMSETID, CONDITIONCODE, FROMCONDITIONCODE,  COMMODITYGROUP, COMMODITY,   LANGCODE, INSPECTEDQTY, HASLD,   SAMESLIP, WOASSETNUM, WOLOCATION, STATUSDATE, STATUSCHANGEBY, MATRECTRANSID,PACKINGSLIPNUM, FROMLOT, TOLOT,REJECTQTY,OUTSIDE,ISPDA,ENTEREDASTASK,COSTINFO,CURBAL,ISSUE,CONDRATE) VALUES ('" + matrectransMbo.getString("ITEMNUM") + "', '" + matrectransMbo.getString("FROMSTORELOC") + "', SYSDATE, SYSDATE, '"+matrectransMbo.getDouble("QUANTITY")+"','"+matrectransMbo.getString("RECEIVEDUNIT")+"','"+matrectransMbo.getString("ISSUETYPE")+"','"+matrectransMbo.getDouble("UNITCOST")+"','"+matrectransMbo.getDouble("ACTUALCOST")+"','"+ matrectransMbo.getDouble("CONVERSION")+"','"+ matrectransMbo.getString("ENTERBY")+"','"+ matrectransMbo.getString("FROMBIN")+"','"+ matrectransMbo.getString("GLCREDITACCT")+"','"+matrectransMbo.getString("GLDEBITACCT")+"','"+ matrectransMbo.getDouble("LINECOST")+"','"+matrectransMbo.getString("CURRENCYCODE")+"','"+ matrectransMbo.getDouble("EXCHANGERATE")+"','"+matrectransMbo.getDouble("CURRENCYUNITCOST")+"','"+matrectransMbo.getDouble("CURRENCYLINECOST")+"','"+matrectransMbo.getString("DESCRIPTION")+"','"+ matrectransMbo.getString("TOSTORELOC")+"','"+ matrectransMbo.getString("TOBIN")+"','"+matrectransMbo.getDouble("LOADEDCOST")+"',0,0,0,0,0,0,'"+ matrectransMbo.getString("STATUS")+"','"+matrectransMbo.getDouble("EXCHANGERATE2")+"','"+matrectransMbo.getDouble("LINECOST2")+"','"+matrectransMbo.getString("ORGID")+"','"+matrectransMbo.getString("FROMSITEID")+"','"+matrectransMbo.getString("SITEID")+"','"+matrectransMbo.getString("LINETYPE")+"','"+ matrectransMbo.getString("ITEMSETID")+"','"+ matrectransMbo.getString("FROMCONDITIONCODE") + "','" + matrectransMbo.getString("CONDITIONCODE") + "','" + matrectransMbo.getString("COMMODITYGROUP") + "','" + matrectransMbo.getString("COMMODITY") + "','" + matrectransMbo.getString("LANGCODE") + "',0,0,0,'"+ matrectransMbo.getString("WOASSETNUM")+ "','"+matrectransMbo.getString("WOLOCATION")+"',SYSDATE,'"+ matrectransMbo.getString("STATUSCHANGEBY")+"',MATRECTRANSSEQ.NEXTVAL,'" + matrectransMbo.getString("PACKINGSLIPNUM")+ "','" + matrectransMbo.getString("TOLOT")+"','"+ matrectransMbo.getString("FROMLOT")+"',0,0,0,0,1,'"+curbal2+"',0,'" + matrectransMbo.getString("CONDRATE")+"')");

*/
//Updating curbal of loaned Storeroom -- Deducting
/*

		        SqlFormat mutsqlformat = new SqlFormat(mboremote.getUserInfo(), "INSERT INTO MATUSETRANS (ITEMNUM, STORELOC, TRANSDATE, ACTUALDATE, QUANTITY, UNITCOST, CONVERSION, ASSETNUM, ENTERBY,   OUTSIDE, PACKINGSLIPNUM, ROLLUP, BINNUM, LOTNUM, ISSUETYPE, LINECOST,  CURRENCYCODE, LOCATION, DESCRIPTION, EXCHANGERATE, SPAREPARTADDED, QTYREQUESTED,  ORGID, SITEID, REFWO, LINETYPE, ITEMSETID, CONDITIONCODE,  COMMODITYGROUP, COMMODITY, TOSITEID, LANGCODE, HASLD,  LOANID,  GLCREDITACCT,GLDEBITACCT,CURRENCYLINECOST,   CURBAL, PHYSCNT,ACTUALCOST,  MATUSETRANSID, ENTEREDASTASK,REVIEWED) VALUES ('" + matrectransMbo.getString("ITEMNUM") + "', '" + matrectransMbo.getString("FROMSTORELOC") + "',SYSDATE,SYSDATE,'"+QUANTITY+"','" + matrectransMbo.getDouble("UNITCOST") + "','" + matrectransMbo.getDouble("CONVERSION") + "','" + matrectransMbo.getString("WOASSETNUM") + "', '" + matrectransMbo.getString("ENTERBY") + "',0,'" + matrectransMbo.getString("PACKINGSLIPNUM") + "',0,'"+matrectransMbo.getString("FROMBIN")+"','" + matrectransMbo.getString("FROMLOT") + "','ISSUE','" + matrectransMbo.getDouble("LINECOST2") + "','" + matrectransMbo.getString("CURRENCYCODE") + "', '" + wo.getString("LOCATION") + "', '" + matrectransMbo.getString("DESCRIPTION") + "','" + matrectransMbo.getDouble("EXCHANGERATE2") + "', 0,'"+ matrectransMbo.getDouble("QUANTITY")+"','" + matrectransMbo.getString("ORGID") + "','" + matrectransMbo.getString("FROMSITEID") + "', '" + wo.getString("WONUM") + "','ITEM','" + matrectransMbo.getString("ITEMSETID") + "','" + matrectransMbo.getString("FROMCONDITIONCODE") + "','" + matrectransMbo.getString("COMMODITYGROUP") + "','" + matrectransMbo.getString("COMMODITY") + "','" + wo.getString("SITEID") + "','" + matrectransMbo.getString("LANGCODE") + "',0,'" + matrectransMbo.getString("LOANID") + "','" + matrectransMbo.getString("GLCREDITACCT") + "','','" + matrectransMbo.getDouble("CURRENCYLINECOST") + "', "+tostoreloccurbal+" ,'" + invbalancesmbo1.getDouble("PHYSCNT") + "','" + matrectransMbo.getDouble("ACTUALCOST") + "',MATUSETRANSSEQ.NEXTVAL,0,0)");

*/



	private MboRemote wo;
	private MXServer mxserver;
	private static final MXLogger	mxLogger	= MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}