package com.psa.app.skillset;

import java.rmi.RemoteException;

import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.custapp.CustomMbo;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class SkillsetCustom extends CustomMbo 
	implements SkillsetCustomRemote 
{
	public SkillsetCustom (MboSet mboset) 
		throws MXException, RemoteException 
	{
		super(mboset);
	}
	
	public void init() 
			throws MXException 
	{
		super.init();
		try 
		{
			if (isNew())
			{
				setFieldFlag("SKILLSET", 7L, false);
				setFieldFlag("SKILLTYPE", 7L, false);
			}
			else
			{
				setFieldFlag("SKILLSET", 7L, true);
				setFieldFlag("SKILLTYPE", 7L, true);
			}
		} 
		catch (RemoteException e) 
		{
			e.printStackTrace();
		}
	}

	public void add() 
			throws MXException, RemoteException 
	{
		super.add();
	}
	
	public void save() 
			throws MXException, RemoteException 
	{
		super.save();
	}
	
	public void canDelete()
			throws MXException, RemoteException
	{
		String skillset = getString("SKILLSET");
		System.out.println("--------------Skill Set--------------"+skillset);
		MboSetRemote JPSkillsetSetRemote=getMboSet("PSA_JPSKILLSET");
		System.out.println("--------------JPSkillsetSetRemote--------------"+JPSkillsetSetRemote);
		if (!JPSkillsetSetRemote.isEmpty())
		{
			System.out.println("--------------Inside JPSkillsetSetRemote--------------");
			String jpnum = JPSkillsetSetRemote.getMbo(0).getString("JPNUM");
			System.out.println("--------------JPNUM--------------"+jpnum);
			Object[] param = {skillset, jpnum};
			throw new MXApplicationException("skillset", "cannotdelete", param);
		}
	}
}
