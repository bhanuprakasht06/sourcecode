package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.util.Date;

import psdi.app.workorder.WORemote;
import psdi.app.workorder.WOServiceRemote;
import psdi.iface.webservices.action.WSMboKey;
import psdi.util.MXException;

public interface CustWOServiceRemote extends WOServiceRemote{
	
	public abstract void custchangeStatus(@WSMboKey("WORKORDER") WORemote wo, String status, Date date, String memo)
		    throws MXException, RemoteException;

}