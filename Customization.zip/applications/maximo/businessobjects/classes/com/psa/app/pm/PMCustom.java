package com.psa.app.pm;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import psdi.app.pm.PM;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;
import psdi.util.MXSystemException;

public class PMCustom extends PM implements PMCustomRemote {

	public PMCustom(MboSet mboset) throws MXException, RemoteException {
		super(mboset);
	}

	public void add() throws MXException, RemoteException {
		super.add();
	}

	public void save() throws MXException, RemoteException {
		super.save();
	}

	public Date getMeterNextDueDateNoForecast(MboRemote pmMeter, boolean assetMeter) 
			throws RemoteException, MXException 
	{
		System.out.println("---------------Enter------------getMeterNextDueDateNoForecast()--------");
		MboRemote assetOrLocMeterMbo = null;

		String[] assetLocMtrVals = new String[3];
		String[] pmMtrVals = new String[3];
		MboRemote pmOwner = getOwner();
		System.out.println("---------------pmOwner------------------"+pmOwner);
		if (assetMeter) 
		{
			System.out.println("-assetMeter--------------inside assetMeter------------------");
			if ((toBeAdded()) && (pmOwner != null) && (pmOwner.toBeAdded()) && (pmOwner.isBasedOn("ASSET"))) 
			{
				MboSetRemote assetOrLocMeterMboSet = pmOwner.getMboSet("ASSETMETER");
				int j = 0;				
				while ((assetOrLocMeterMbo = assetOrLocMeterMboSet.getMbo(j)) != null) 
				{
					System.out.println("-assetMeter--------------j------------------"+j);
					assetLocMtrVals[0] = assetOrLocMeterMbo.getString("metername");
					assetLocMtrVals[1] = assetOrLocMeterMbo.getString("assetnum");
					assetLocMtrVals[2] = assetOrLocMeterMbo.getString("siteid");
					pmMtrVals[0] = pmMeter.getString("metername");
					pmMtrVals[1] = pmMeter.getString("assetnum");
					pmMtrVals[2] = pmMeter.getString("siteid");
					System.out.println("-assetMeter--------------assetLocMtrVals[0]------------------"+assetLocMtrVals[0]);
					System.out.println("-assetMeter--------------assetLocMtrVals[1]------------------"+assetLocMtrVals[1]);
					System.out.println("-assetMeter--------------assetLocMtrVals[2]------------------"+assetLocMtrVals[2]);
					System.out.println("-assetMeter--------------pmMtrVals[0]------------------"+pmMtrVals[0]);
					System.out.println("-assetMeter--------------pmMtrVals[1]------------------"+pmMtrVals[1]);
					System.out.println("-assetMeter--------------pmMtrVals[2]------------------"+pmMtrVals[2]);
					if ((assetLocMtrVals[0].equals(pmMtrVals[0])) && (assetLocMtrVals[1].equals(pmMtrVals[1])) && (assetLocMtrVals[2].equals(pmMtrVals[2]))) 
					{
						System.out.println("-assetMeter--------------before break------------------");
						break;
					}
					j++;
				}
			} 
			else 
			{
				assetOrLocMeterMbo = pmMeter.getMboSet("ASSETPMMETER").getMbo(0);
				System.out.println("------Else---------assetOrLocMeterMbo------------------"+assetOrLocMeterMbo);
			}
		} 
		else if ((toBeAdded()) && (pmOwner != null) && (pmOwner.toBeAdded()) && (pmOwner.isBasedOn("LOCATIONS"))) 
		{
			System.out.println("-assetOrLocMeterMboSet--------------inside assetOrLocMeterMboSet------------------");
			MboSetRemote assetOrLocMeterMboSet = pmOwner.getMboSet("LOCATIONMETER");
			int j = 0;
			while ((assetOrLocMeterMbo = assetOrLocMeterMboSet.getMbo(j)) != null) 
			{
				assetLocMtrVals[0] = assetOrLocMeterMbo.getString("metername");
				assetLocMtrVals[1] = assetOrLocMeterMbo.getString("location");
				assetLocMtrVals[2] = assetOrLocMeterMbo.getString("siteid");
				pmMtrVals[0] = pmMeter.getString("metername");
				pmMtrVals[1] = pmMeter.getString("location");
				pmMtrVals[2] = pmMeter.getString("siteid");
				System.out.println("-assetOrLocMeterMboSet-----else if---------assetLocMtrVals[0]------------------"+assetLocMtrVals[0]);
				System.out.println("-assetOrLocMeterMboSet-----else if---------assetLocMtrVals[1]------------------"+assetLocMtrVals[1]);
				System.out.println("-assetOrLocMeterMboSet-----else if---------assetLocMtrVals[2]------------------"+assetLocMtrVals[2]);
				System.out.println("-assetOrLocMeterMboSet-----else if---------pmMtrVals[0]------------------"+pmMtrVals[0]);
				System.out.println("-assetOrLocMeterMboSet-----else if---------pmMtrVals[1]------------------"+pmMtrVals[1]);
				System.out.println("-assetOrLocMeterMboSet-----else if---------pmMtrVals[2]------------------"+pmMtrVals[2]);
				if ((assetLocMtrVals[0].equals(pmMtrVals[0])) && (assetLocMtrVals[1].equals(pmMtrVals[1])) && (assetLocMtrVals[2].equals(pmMtrVals[2]))) 
				{
					System.out.println("-assetOrLocMeterMboSet-----Else if---------before break------------------");
					break;
				}
				j++;
			}
		} 
		else 
		{
			assetOrLocMeterMbo = pmMeter.getMboSet("LOCATIONPMMETER").getMbo(0);
			System.out.println("-assetOrLocMeterMboSet-----Else---------assetOrLocMeterMbo------------------"+assetOrLocMeterMbo);
		}
		Date readingDate = null;
		if (assetOrLocMeterMbo != null) 
		{
			readingDate = assetOrLocMeterMbo.getDate("lastreadingdate");
			System.out.println("-assetOrLocMeterMboSet--------------readingDate------------------"+readingDate);
			double unitsPerDay = assetOrLocMeterMbo.getDouble("average");
			if ((readingDate == null) || (unitsPerDay == 0.0D)) 
			{
				System.out.println("-assetOrLocMeterMboSet--------------readingDate before return null------------------");
				return null;
			}
			Date todaysdate = calculateTodaysDate();
			double estnxtval = pmMeter.getDouble("LTDREADATNEXTWO")
					- assetOrLocMeterMbo.getDouble("LIFETODATE")
					- pmMeter.getDouble("TOLERANCE");
			double average = assetOrLocMeterMbo.getDouble("average");
			int durationDays = (int) Math.ceil(estnxtval / average);
			Date lastStartDate = getDate("LastStartDate");
			System.out.println("-assetOrLocMeterMboSet--------------todaysdate------------------"+todaysdate);
			System.out.println("-assetOrLocMeterMboSet--------------estnxtval------------------"+estnxtval);
			System.out.println("-assetOrLocMeterMboSet--------------average------------------"+average);
			System.out.println("-assetOrLocMeterMboSet--------------durationDays------------------"+durationDays);
			System.out.println("-assetOrLocMeterMboSet--------------lastStartDate------------------"+lastStartDate);
			if (estnxtval <= 0.0D) 
			{
				System.out.println("-assetOrLocMeterMboSet--------------readingDate before return todaysdate------------------");
				return todaysdate;
			}
			if ((lastStartDate != null) && (lastStartDate.after(readingDate))) 
			{
				if ((getBoolean("UseTargetDate")) || (this.forecastFlag)) 
				{
					Calendar scr = new GregorianCalendar();
					scr.setTime(lastStartDate);
					scr.add(5, durationDays);
					System.out.println("---------------if ((getBoolean(UseTargetDate)) || (this.forecastFlag))------------------"+scr.getTime());
					return scr.getTime();
				}
				if (!isNull("LastCompDate")) 
				{
					Calendar scr = new GregorianCalendar();
					scr.setTime(getDate("LastCompDate"));
					scr.add(5, durationDays);
					System.out.println("---------------if (!isNull(LastCompDate))------------------"+scr.getTime());
					return scr.getTime();
				}
			}
			Calendar scr = new GregorianCalendar();
			scr.setTime(todaysdate);
			scr.add(5, durationDays);

			scr.set(11, 0);
			scr.clear(12);
			scr.clear(13);
			scr.clear(14);
			System.out.println("---------------final return scr.getTime()------------------"+scr.getTime());
			return scr.getTime();
		}
		System.out.println("---------------exit ------------getMeterNextDueDateNoForecast()--------");
		return null;
	}

	private Date calculateTodaysDate() throws RemoteException, MXException {
		Date todaysDate = null;

		todaysDate = MXServer.getMXServer().getDate();
		Calendar scr = new GregorianCalendar();
		scr.setTime(todaysDate);
		scr.set(11, 0);
		scr.clear(12);
		scr.clear(13);
		scr.clear(14);
		todaysDate = scr.getTime();

		return todaysDate;
	}

	// Maximo 7.6 Code
	/*public Date getMeterNextDueDateNoForecast(MboRemote pmMeter, boolean assetMeter) 
			throws RemoteException, MXException 
	{
		MboRemote assetOrLocMeterMbo = null;
		MboRemote assetOrLocMeterMboPMMeterMatch = null;
		boolean matchFound = false;
		MboSetRemote assetOrLocMeterMboSet = null;

		String[] assetLocMtrVals = new String[3];
		String[] pmMtrVals = new String[3];
		MboRemote pmOwner = getOwner();
		try 
		{
			if (assetMeter) 
			{
				if ((toBeAdded()) && (pmOwner != null) && (pmOwner.toBeAdded()) && (pmOwner.isBasedOn("ASSET"))) 
				{
					assetOrLocMeterMboSet = pmOwner.getMboSet("ASSETMETER");
					assetOrLocMeterMboSet.setFlag(39L, true);

					int j = 0;
					while ((assetOrLocMeterMbo = assetOrLocMeterMboSet
							.getMbo(j)) != null) 
					{

						if (!matchFound) {
							assetLocMtrVals[0] = assetOrLocMeterMbo.getString("metername");
							assetLocMtrVals[1] = assetOrLocMeterMbo.getString("assetnum");
							assetLocMtrVals[2] = assetOrLocMeterMbo.getString("siteid");
							pmMtrVals[0] = pmMeter.getString("metername");
							pmMtrVals[1] = pmMeter.getString("assetnum");
							pmMtrVals[2] = pmMeter.getString("siteid");
							if ((assetLocMtrVals[0].equals(pmMtrVals[0])) && (assetLocMtrVals[1].equals(pmMtrVals[1])) && (assetLocMtrVals[2].equals(pmMtrVals[2]))) 
							{
								assetOrLocMeterMboPMMeterMatch = assetOrLocMeterMbo;
								matchFound = true;
							}
						}

						j++;
					}
				} 
				else 
				{
					assetOrLocMeterMboSet = pmMeter.getMboSet("ASSETPMMETER");
					assetOrLocMeterMboSet.setFlag(39L, true);
					assetOrLocMeterMboPMMeterMatch = assetOrLocMeterMboSet.getMbo(0);
				}

			} 
			else if ((toBeAdded()) && (pmOwner != null) && (pmOwner.toBeAdded()) && (pmOwner.isBasedOn("LOCATIONS"))) 
			{
				assetOrLocMeterMboSet = pmOwner.getMboSet("LOCATIONMETER");
				assetOrLocMeterMboSet.setFlag(39L, true);
				int j = 0;
				while ((assetOrLocMeterMbo = assetOrLocMeterMboSet.getMbo(j)) != null) 
				{

					if (!matchFound) {
						assetLocMtrVals[0] = assetOrLocMeterMbo.getString("metername");
						assetLocMtrVals[1] = assetOrLocMeterMbo.getString("location");
						assetLocMtrVals[2] = assetOrLocMeterMbo.getString("siteid");
						pmMtrVals[0] = pmMeter.getString("metername");
						pmMtrVals[1] = pmMeter.getString("location");
						pmMtrVals[2] = pmMeter.getString("siteid");
						if ((assetLocMtrVals[0].equals(pmMtrVals[0])) && (assetLocMtrVals[1].equals(pmMtrVals[1])) && (assetLocMtrVals[2].equals(pmMtrVals[2]))) 
						{
							assetOrLocMeterMboPMMeterMatch = assetOrLocMeterMbo;
							matchFound = true;
						}
					}

					j++;
				}
			} 
			else 
			{
				assetOrLocMeterMboSet = pmMeter.getMboSet("LOCATIONPMMETER");
				assetOrLocMeterMboSet.setFlag(39L, true);
				assetOrLocMeterMboPMMeterMatch = assetOrLocMeterMboSet.getMbo(0);
			}

			Date readingDate = null;

			if (assetOrLocMeterMboPMMeterMatch != null) 
			{
				readingDate = assetOrLocMeterMboPMMeterMatch.getDate("lastreadingdate");
				double unitsPerDay = assetOrLocMeterMboPMMeterMatch.getDouble("average");

				if ((readingDate == null) || (unitsPerDay == 0.0D)) 
				{
					return null;
				}

				Date todaysdate = calculateTodaysDate();

				double unitsToGo = pmMeter.getDouble("ltdlastpmworead")
						+ pmMeter.getDouble("Frequency")
						- assetOrLocMeterMboPMMeterMatch.getDouble("LIFETODATE")
						- pmMeter.getDouble("TOLERANCE");
				double average = assetOrLocMeterMboPMMeterMatch.getDouble("average");
				int durationDays = (int) Math.ceil(unitsToGo / average);
				Date lastStartDate = getDate("LastStartDate");

				if (unitsToGo <= 0.0D) 
				{
					return todaysdate;
				}
				Date localDate3;
				if ((lastStartDate != null)
						&& (lastStartDate.after(readingDate))) 
				{

					if ((getBoolean("UseTargetDate")) || (getBoolean("PMACTMETER")) || (getBoolean("PMASSETWOGEN"))) 
					{

						Object scr = new GregorianCalendar();
						((Calendar) scr).setTime(lastStartDate);
						((Calendar) scr).add(5, durationDays);
						return ((Calendar) scr).getTime();
					}
					if (!isNull("LastCompDate")) 
					{

						Object scr = new GregorianCalendar();
						((Calendar) scr).setTime(getDate("LastCompDate"));
						((Calendar) scr).add(5, durationDays);
						return ((Calendar) scr).getTime();

					}

				} 
				else if (!getBoolean("UseTargetDate")) 
				{
					if ((!isNull("LastCompDate")) && (getDate("LastCompDate").after(readingDate))) 
					{

						Object scr = new GregorianCalendar();
						((Calendar) scr).setTime(getDate("LastCompDate"));
						((Calendar) scr).add(5, durationDays);
						return ((Calendar) scr).getTime();
					}

					Object scr = new GregorianCalendar();
					((Calendar) scr).setTime(readingDate);
					((Calendar) scr).add(5, durationDays);
					return ((Calendar) scr).getTime();
				}

				Object scr = new GregorianCalendar();
				((Calendar) scr).setTime(todaysdate);
				((Calendar) scr).add(5, durationDays);

				((Calendar) scr).set(11, 0);
				((Calendar) scr).clear(12);
				((Calendar) scr).clear(13);
				((Calendar) scr).clear(14);

				return ((Calendar) scr).getTime();
			}
		} catch (MXException mxe) {
			throw mxe;
		} catch (Throwable t) {
			MXException mxex = new MXSystemException("system", "major", t);
			throw mxex;

		} finally {
			if (assetOrLocMeterMboSet != null) {
				assetOrLocMeterMboSet.cleanup();
				assetOrLocMeterMboSet = null;
			}
		}
		return null;
	}*/
}
