package com.psa.app.inventory;

import psdi.mbo.MboSetRemote;

public interface CustomInvBatchSetRemote extends MboSetRemote 
{
		
}
