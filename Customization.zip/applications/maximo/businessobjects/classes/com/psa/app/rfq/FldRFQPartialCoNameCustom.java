/*
 * Modification history
 * 25-06-07	RHA		SR-099	Creation
 */

package com.psa.app.rfq;

import java.rmi.RemoteException;

import psdi.app.company.FldCompany;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.mbo.MboValue;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class FldRFQPartialCoNameCustom extends FldCompany {
	
	/**
	 * @comment		Field on screen for users to input partial vendor name. 
	 * 				Upon tab or enter or click  somewhere else, the vendor will be populated.
	 * 				Otherwise, a popup will warn the user.
	 * @author		RHA
	 * @function	FldRFQPartialCoNameCustom
	 * @date		4 July 2007
	 */
	private static final String npPartialNameAtt = "PARTIALNAME";
	
	//Application: RFQ
	//Tab: Vendor
	public FldRFQPartialCoNameCustom(MboValue mbovalue)
    throws MXException, RemoteException
    {	
		//This is standard
		super(mbovalue);
    }
	
	//Overriding method
	public void action()
    throws MXException, RemoteException
	{
		 //System.out.println("In action rfq.FldRFQPartialCoNameCustom");

	     Mbo mbo = getMboValue().getMbo();  
	     if(!(getMboValue().isNull() || getMboValue().equals("")))
	     {
	    	 String partialName = "";
	    	 MXServer mxserver = MXServer.getMXServer();
			 UserInfo userinfo = mbo.getUserInfo();
		     if(!mbo.isNull(npPartialNameAtt)){
		    	 //System.out.println("Stepping 1: In if condition [!mbo.isNull(npPartialNameAtt)]");
		    	 partialName = mbo.getString(npPartialNameAtt); 
		    	 //System.out.println("Stepping 1a: partialName ["+partialName+"]");
		    	 if(partialName.length()>0){
		    		 MboSetRemote companiesSet = mxserver.getMboSet("COMPANIES", userinfo);//getMboSet();
				     SqlFormat sqlformat = new SqlFormat("where name like '"+partialName+"%'");
				     companiesSet.setWhere(sqlformat.format());
				     //System.out.println("Stepping 2: Where clause already set in companiesSet");
					 
				     //The partial vendor name does not match any vedor.
				     if (companiesSet.isEmpty()) 
					 {
						 //System.out.println("Stepping 3: noVendorNameMatch");
						 throw new MXApplicationException("rfq", "noVendorNameMatch");
					 }			 
					
					 else{
					 
						 if(companiesSet.count()>1){ 
							 //The partial vendor name matches multiple vendor names.
							 //System.out.println("Stepping 3: multipleVendorNameMatches");
							 throw new MXApplicationException("rfq", "multipleVendorNameMatches");
						 }
						
						 else{
							 //System.out.println("Stepping 3: set company and vendor");
						     MboRemote companies = companiesSet.getMbo(0);
						     String vendor = companies.getString("COMPANY");
						     //mbo.setValue("COMPANY", vendor);
						     getMboValue("VENDOR").setValue(vendor);

						 }
					 } 
			     }//End of if(partialName.length()>0)
			 }//End of if(!mbo.isNull(npPartialNameAtt))		     
	     } //End of if(!(getMboValue().isNull() || getMboValue().equals("")))
	     //System.out.println("OUT action()");
	}
	
	//Overriding method
	public void validate(){
		//Do nothing
		//System.out.println("In validate rfq.FldRFQPartialCoNameCustom");
	}


}
