package com.psa.app.jobplan;

import java.rmi.RemoteException;

import psdi.app.jobplan.JobPlanSet;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class JobPlanSetCustom extends JobPlanSet 
	implements JobPlanSetCustomRemote 
{
	public JobPlanSetCustom (MboServerInterface mboserverinterface) 
		throws MXException, RemoteException 
	{
		super(mboserverinterface);
	}
	
	protected Mbo getMboInstance(MboSet mboset) 
		throws MXException, RemoteException
	{
		return (new JobPlanCustom(mboset));	
	}	
}
