/*
 * Modification history
 * 25-09-15	DES	EMS-958 Recon status for some transactions cannot be updated due to LD Import and Labor Overlap prompts
 * 25-06-18	DES	EMS-1376: Auto-populate LD Comments for POs that are LD Applicable (for email alert see Automation Script)
 * 02-07-18	DES	EMS-1381: Send alert emails for LD Applicable receipts consolidated at PO level for that transaction  (Automation Script NO longer in use)
 */

package com.psa.app.labor;

import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.mail.MessagingException;

import java.lang.String;

import psdi.app.labor.ServRecTrans;
import psdi.app.labor.ServRecTransRemote;
import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXApplicationYesNoCancelException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.mbo.SqlFormat;

import java.sql.SQLException;

public class ServRecTransCustom extends ServRecTrans implements
ServRecTransRemote {

        MboSetRemote servRecTransSet=null;
        protected static final MXLogger logger = MXLoggerFactory.getLogger("maximo.application.RECEIPTS"); // Added logging for EMS-1376, Desmond
        protected static final String LOGKEY = " >>>>>>>> "; // Added logging for EMS-1376, Desmond
        
        private boolean isProcessed = false; 	// Added for EMS-1381, Desmond
        private boolean toEmail = false; 		// Added for EMS-1381, Desmond
        
        public ServRecTransCustom(MboSet ms) throws MXException, RemoteException {
                super(ms);
                servRecTransSet=ms;
                // TODO Auto-generated constructor stub
                
                setIsProcessed(false);	// Added for EMS-1381, Desmond
                setToEmail(false);		// Added for EMS-1381, Desmond
        }
        
    	// Added for EMS-1381, Desmond
    	public boolean getIsProcessed() {
    		return isProcessed;
    	}


    	// Added for EMS-1381, Desmond
    	public void setIsProcessed(boolean isProcessed) {
    		this.isProcessed = isProcessed;
    	}

    	// Added for EMS-1381, Desmond
    	public boolean getToEmail() {
    		return toEmail;
    	}

    	// Added for EMS-1381, Desmond
    	public void setToEmail(boolean toEmail) {
    		this.toEmail = toEmail;
    	}

    
        @Override
        public void save() throws MXException, RemoteException {
                // TODO Auto-generated method stub
                if(getString("ISSUETYPE").equalsIgnoreCase("RECEIPT")& !getString("ISSUETYPE").equalsIgnoreCase(""))
                {
	                //Added by WMJ to call vendor date check only if PO for receipt is LD applicable
	                MboSetRemote poset = this.getMboSet("PO");
	                
	                logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("LDAPPLICABLE: ").append(poset.getMbo(0).getBoolean("LDAPPLICABLE")).toString());
	                logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("USER ID: ").append(getUserName()).toString());
	                
	                if(poset.getMbo(0).getBoolean("LDAPPLICABLE"))
	                {
		                if(!isCurrUserInGrp("MAXADMIN") && isEnterDateGreater(this))
						{ // EMS-958: Add criteria to skip LD import check for users in MAXADMIN group, Desmond
							
	                		// START - EMS-1376: Auto-populate LD Comments for POs that are LD Applicable (for email alert see Automation Script), Desmond	                		
		                	logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> START AUTO POPULATE LD COMMENT").toString());
	                		
	                		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); // Added for EMS-1376, Desmond

            				//String[] params = new String[ 1 ];
            				
            				boolean hasAutoPopulated = false;
            				
            				// Loop through all receipts
            				for(int i=0;i<servRecTransSet.count();i++)
            				{
            					MboRemote servRecTransRemote=servRecTransSet.getMbo(i);
            					
            					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("POLINE: ").
            							append(servRecTransRemote.getString("POLINENUM")).append(" LD Comment: ").append(servRecTransRemote.getString("LDCOMMENT")).toString());
            					
            					if(servRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase("RECEIPT")& !servRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase(""))
            					{
            						if(servRecTransRemote.toBeAdded()&&isEnterDateGreater(servRecTransRemote))
            						{                							
            							servRecTransRemote.setValue("LDCOMMENT", "LD TO IMPOSE ACTUAL RECEIPT "+sdf.format(servRecTransRemote.getDate("ENTERDATE")), NOACCESSCHECK);
            							//params[0] = servRecTransRemote.getString("LDCOMMENT");
            							//logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(" >>>>>>>> UPDATED LD COMMENT: ").append(params[0]).toString());
            							hasAutoPopulated = true;
            						}
            					}
            						                					
            				}
            				
            				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("After looping through all receipts").toString());
            				
            				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("hasAutoPopulated = ").append(hasAutoPopulated).toString());
            				
            				// Prompt user if at least 1 line was auto populated
            				if(hasAutoPopulated) {
            					String[] params = {"LD TO IMPOSE ACTUAL RECEIPT <ENTER DATE>"};
            					this.getThisMboSet().addWarning(new MXApplicationException("servrectrans", "AutoSetLDcomments",params));
            				}

            				//String[] warning={ lineList };
	                		
            				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> END AUTO POPULATE LD COMMENT").toString());
	                		// END - EMS-1376: Auto-populate LD Comments for POs that are LD Applicable (for email alert see Automation Script), Desmond
							
							/* Removed for EMS-1376, Desmond
							int userInput = MXApplicationYesNoCancelException.getUserInput("Enterdate", MXServer.getMXServer(), getUserInfo());
							switch(userInput)
							{
								case -1:
							        String lineList="\n";
							        for(int i=0;i<servRecTransSet.count();i++)
							        {
							        	MboRemote servRecTransRemote=servRecTransSet.getMbo(i);
							            if(servRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase("RECEIPT")& !servRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase(""))
							            {
							                 if(servRecTransRemote.toBeAdded() && isEnterDateGreater(servRecTransRemote))
							                 {
							                	 lineList=lineList+"Line : "+servRecTransRemote.getString("POLINENUM")+"\n";
							                 }
							            }
							        }
							
							        String[] warning={ lineList };
							        throw new MXApplicationYesNoCancelException("Enterdate","servrectrans", "Enterdate",warning);
								
								case 8: 
									break;

								case 4: 
									throw new MXApplicationException("messagebox", "MSG_BTNCANCEL");

							}
							*/ // Removed for EMS-1376, Desmond
							
						}
            		}//End of Added by WMJ to call vendor date check only if PO for receipt is LD applicable
                }

// START of EMS-1381, Desmond               
                this.setIsProcessed(true); // Added for EMS-1381 to set servrectrans mbo to isProcessed after above code runs on it
                
                super.save();
                
                int total = 0;
                int processed = 0;
                
                // Count the number of transactions that have setIsProcess true
                ServRecTransCustom temp=null;
				for(int i=0; (temp= (ServRecTransCustom) servRecTransSet.getMbo(i))!=null; i++)
				{
					if(temp.toBeAdded()) total++;			// Count only those that are to be added
				    if(temp.getIsProcessed()) processed++;	// Count only those that have been processed by this code
				}
				
				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("TOTAL: ").append(total).toString());
				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("PROCESSED: ").append(processed).toString());
				
				// Is the last record to be processed, attempt to call method to send email
				if (total == processed) {
					
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("Attempting to call sendLDEmail() ").toString());
					sendLDEmail();
					
				}
				
// END of EMS-1381, Desmond
        	}


                private boolean isEnterDateGreater(MboRemote mbo) throws RemoteException, MXException
                {
                        Date enterDate = mbo.getDate("ENTERDATE");
                        Date  vendorDate = mbo.getDate("POLINEREV.VENDELIVERYDATE"); // EMS-1381: Changed from POLINE to POLINEREV to handle PO revisions, Desmond 
                        
                        logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreater(mbo)").append(LOGKEY).append("vendorDate: ").append(vendorDate).toString());
            			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreater(mbo)").append(LOGKEY).append("enterDate: ").append(enterDate).toString());
            			
                        if((enterDate==null)||(vendorDate==null))
                        {
                                return false;
                        }
                        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                        Date servTransDate = null;
                        Date venDate=null;
                        try {
                                String newTrans=sdf.format(enterDate);
                                servTransDate = sdf.parse(newTrans);
                                if (vendorDate != null) {
                                        String newVendor=sdf.format(vendorDate);
                                        venDate=sdf.parse(newVendor);
                                }

                        }catch (ParseException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                        }
                        
                        logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreater(mbo)").append(LOGKEY).append("venDate: ").append(venDate).toString());
            			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreater(mbo)").append(LOGKEY).append("servTransDate: ").append(servTransDate).toString());
            			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreater(mbo)").append(LOGKEY).append("LDCOMMENT: ").append(mbo.getString("LDCOMMENT")).toString());
            			
                        //removed by WMJ
                        //only return true if enterDate is after receipt date and no LD comments were entered.
                        //return servTransDate.after(venDate);
                        if( servTransDate.after(venDate) ) 
                        {
	                        if( mbo.getString("LDCOMMENT") == null || mbo.getString("LDCOMMENT").length() == 0 )
	                        {
		                        return true;
		                    }
		                    else
		                    {
			                    return false;
			                }
	                    }
	                    else
	                    {
		                    return false;
		                }
                }

//START of EMS-1381, Desmond
                
            	/**
            	 * Function for to check that Enter Date is AFTER Vendor Date, REGARDLESS OF LD COMMENT
            	 * 
            	 * @param mbo Mbo to compare Enter Date and Vendor Date for
            	 * 
            	 * @author	DES
            	 * @since   02/07/2018
            	 */
                private boolean isEnterDateGreaterIgnoreLD(MboRemote mbo) throws RemoteException, MXException
                {
                        Date enterDate = mbo.getDate("ENTERDATE");
                        Date  vendorDate = mbo.getDate("POLINEREV.VENDELIVERYDATE"); // EMS-1381: Changed from POLINE to POLINEREV to handle PO revisions, Desmond 
                        
                        logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("vendorDate: ").append(vendorDate).toString());
            			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("enterDate: ").append(enterDate).toString());
            			
                        if((enterDate==null)||(vendorDate==null))
                        {
                                return false;
                        }
                        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                        Date servTransDate = null;
                        Date venDate=null;
                        try {
                                String newTrans=sdf.format(enterDate);
                                servTransDate = sdf.parse(newTrans);
                                if (vendorDate != null) {
                                        String newVendor=sdf.format(vendorDate);
                                        venDate=sdf.parse(newVendor);
                                }

                        }catch (ParseException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                        }
                        
                        logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("venDate: ").append(venDate).toString());
            			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("servTransDate: ").append(servTransDate).toString());
            			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isEnterDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("LDCOMMENT: ").append(mbo.getString("LDCOMMENT")).toString());
            			
            			return servTransDate.after(venDate);
                }
                
                
        		/**
        		 * Function for sending LD alert emails
        		 * 
        		 * @author	DES
        		 * @since   02/07/2018
        		 */
        	    private void sendLDEmail() throws RemoteException, MXException
                {
        	    	
        	    	// Do NOT run this if no PO (e.g. transfers)
        	    	if(this.getMboSet("PO") == null || this.getMboSet("PO").isEmpty()) return;
        	    	
        	    	MboRemote po = this.getMboSet("PO").getMbo(0);
        	    	
// Start of EMS-1391, Desmond
        	    	String vendor ="";
        	    	String vendorid="";
        	    	
        	    	if(po.getMboSet("VENDOR") == null || po.getMboSet("VENDOR").isEmpty()) {
        	    		
        	    		logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("PO: ").append(po.getString("PONUM")).append(" has NO Vendor").toString());
        	    		
        	    	} else  {
        	    		
        	    		if (po.getMboSet("VENDOR").count() > 1) {
        	    			logger.error((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("PO: ").append(po.getString("PONUM")).append(" has MORE THAN 1 VENDOR!!!").toString());
        	    		}
        	    		
        	    		vendor = po.getMboSet("VENDOR").getMbo(0).getString("NAME");
        	    		vendorid = po.getMboSet("VENDOR").getMbo(0).getString("COMPANY");
            		
        	    	}
        	    	
        	    	logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("PO: ").append(po.getString("PONUM")).
        	    			append(" VENDOR: ").append(vendor).append(" (").append(vendorid).append(")").toString());
// End of EMS-1391, Desmond
        	    	
        	    	// Prevent sending of emails by MAXADMIN and Cron Tasks, skip for cases where PO is no LD Applicable
        	    	if( isCurrUserInGrp("MAXADMIN") || !po.getBoolean("LDAPPLICABLE") ) return;
        	    	
        	    	String lineList="";	
        	    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        	    	try {
        	    	
        				// Loop through all servrectrans to prepare email content if required
        				for(int i=0;i<servRecTransSet.count();i++)
        				{
        					MboRemote servRecTransRemote=servRecTransSet.getMbo(i);
        					
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("PO: ").append(servRecTransRemote.getString("PONUM")).
        							append(" POLINE: ").append(servRecTransRemote.getString("POLINENUM")).append(" IssueType: ").append(servRecTransRemote.getString("ISSUETYPE")).
        							append(" LD Comment: ").append(servRecTransRemote.getString("LDCOMMENT")).toString());
        					
        					// For receipts only
        					if(servRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase("RECEIPT")& !servRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase(""))
        					{
        						// For Is newly added and Actual Date is AFTER Vendor Date, REGARDLESS OF LD COMMENT
        						if(servRecTransRemote.toBeAdded()&&isEnterDateGreaterIgnoreLD(servRecTransRemote))
        						{                							
        							logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("Adding line details ...").toString());
        							
        							// Add line details to email
        							lineList = lineList+"Line: "+servRecTransRemote.getString("POLINENUM")+"<ul>"+
        										"<li>Item No./Line Desc: "+servRecTransRemote.getString("ITEMNUM")+" / "+servRecTransRemote.getString("DESCRIPTION")+"</li>"+
        										"<li>Vendor Date: "+sdf.format(servRecTransRemote.getDate("POLINEREV.VENDELIVERYDATE"))+"</li>"+
        										"<li>Enter Date: "+sdf.format(servRecTransRemote.getDate("ENTERDATE"))+"</li>"+
        										"<li>Rcpt Qty: "+servRecTransRemote.getDouble("QUANTITY")+"</li>"+
        										"</ul>";
        						}
        					}
        						                					
        				}
        				
        				if( lineList == null || lineList.length() == 0 ) {
        					
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("NO EMAIL TO SEND !!!!!").toString());
        					
        				} else {
        				
        					// Get WO linked to the receipt (each PO can only be linked to 1 WO)
        					MboSetRemote woSet = servRecTransSet.getMbo(0).getMboSet("WORKORDER");
        					
        					String templateName="WORCPTLD"; // Default to WO Level Email
        					
        					String ponum = po.getString("PONUM");
        					String wonum ="";
        					
        					MboRemote srcMbo;
        					
        					// Decide template based on whether wonum is null
        					if(woSet.isEmpty() || woSet == null) {
        						
        						// NO linked WO, send PO level email
        						logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("NO WO, preparing PO Level email ...").toString());
        						
        		    			templateName="PORCPTLD"; // Switch to PO level template 
        		    			srcMbo = po;
        						
        					} else {
        						
        						// Send WO level email
        						
        						srcMbo = woSet.getMbo(0);
        						wonum = srcMbo.getString("WONUM");
        						
        						logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("WO (").append(wonum).
        								append(") exists, preparing WO Level email ...").toString());
        						
        					}
        		    		
        			    	// Get relevant comm template 
        			    	CommTemplateSetRemote commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
        					commTemplateSet.setWhere("TEMPLATEID='"+templateName+"'");
        					commTemplateSet.reset();
        					CommTemplateRemote tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);
        					
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).
        							append("Sending email using Template (").append(tempRemote.getString("TEMPLATEID")).append(") ...").toString());

        					// Copy email details from Comm Template
        					String toMail=tempRemote.getString("TOLIST");
        					String fromMail=tempRemote.getString("SENDFROM");
        					String ccTo=tempRemote.getString("CCLIST");
        					String bccTo=tempRemote.getString("BCCLIST");
        					String subject=tempRemote.getString("SUBJECT");
        					String message=tempRemote.getString("MESSAGE");
        					String replyTo=tempRemote.getString("REPLYTO");
        					
        					// Update Subject
        					subject = subject.replace("#WONUM", wonum).replace("#PONUM", ponum).replace("#VENDORNAME", vendor).replace("#VENDORID", vendorid); // Added vendor details for EMS-1391, Desmond
        					
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("SUBJECT: ").append(subject).toString());
        									
        					// Update Message content
        					message =message.replace("#WONUM", wonum).replace("#PONUM", ponum).replace("#VENDORNAME", vendor).replace("#VENDORID", vendorid).replace("#LINEDETAILS", lineList); // Added vendor details for EMS-1391, Desmond
        					
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("MSG: ").append(message).toString());
        					
        					// Convert recipient list to email addresses
        					toMail=tempRemote.convertSendTo("COMMTMPLT_TO", srcMbo);
        					ccTo=tempRemote.convertSendTo("COMMTMPLT_CC", srcMbo);
        					bccTo=tempRemote.convertSendTo("COMMTMPLT_BCC", srcMbo);
        								
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("TO: ").append(toMail).toString());
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("CC: ").append(ccTo).toString());
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("BCC: ").append(bccTo).toString());
        					
        					MXServer.sendEMail(toMail, ccTo, bccTo, fromMail, subject, message, replyTo, null, null);
        					
        					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("After sending email").toString());
        				
        				}

        				
        			} catch (MessagingException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			}
        	    	
                } 
        	    
// END of EMS-1381, Desmond	

                
		//start of EMS-958
		/*
		 * Function for checking if Current User is in the specified group, used by save().
		 * Returns true if Current User is in the specified group, false if otherwise
		 *
		 */
		public boolean isCurrUserInGrp(String grp)
						throws MXException, RemoteException
		{
			
			boolean currUserIsInGrp = false;
			
			MboSetRemote groupset = MXServer.getMXServer().getMboSet("GROUPUSER", getUserInfo());
			SqlFormat sql2 = new SqlFormat("GROUPNAME ='"+grp+"'");
			groupset.setWhere(sql2.format());
			String currentuser = getUserName();

			int i=0;

			//Check if the user belongs to target group
			for(MboRemote user = null; (user = groupset.getMbo(i)) != null; i++) {
				if(user.getString("USERID").equalsIgnoreCase(currentuser)) currUserIsInGrp =true;
			}
			
			return currUserIsInGrp;

		}
		//end of EMS-958
		
}





