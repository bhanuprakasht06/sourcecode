package com.psa.app.labor;

import java.rmi.RemoteException;

import psdi.app.labor.ServRecTransSet;
import psdi.app.labor.ServRecTransSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;

public class ServRecTransSetCustom extends ServRecTransSet implements
		ServRecTransSetRemote {

	public ServRecTransSetCustom(MboServerInterface ms) throws MXException,
			RemoteException {
		super(ms);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected Mbo getMboInstance(MboSet ms) throws MXException, RemoteException {
		// TODO Auto-generated method stub
		return new ServRecTransCustom(ms);
	}
}
