/*
 * Modification history
 * 19-03-07 AGD	SR-070	Fax and Print Reserve Item
 * 04-06-07	LS		SR-079	Modify the Fax and Print Template
 * 04-07-07	AGD	SR-103	Pass supervisor email to UMS
 * 17-09-07	AGD	SR-108	Change in method MxEmail.sendViaUMS
 * 15-01-13 WMJ EMS-544 [UMS]Send email for store reservation to workorder(WO) reporter and team IC
 * 15-07-14	WMJ	EMS-820	[UMS]Switch to using common UMS libraries for sending of faxes
 * 20-OCT-2020 BCT CUSTOMIZATION REMOVING UMS RELATED INFO 
 *
 */

package com.psa.app.workorder;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.io.*;
import java.util.*;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;
import java.util.ArrayList;

import psdi.app.inventory.InvBalancesRemote;
import psdi.app.inventory.InvBalancesSetRemote;
import psdi.app.inventory.InventoryRemote;
import psdi.common.action.ActionCustomClass;
import com.psa.custom.common.MxEmail;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;
import psdi.server.MXServer;
import psdi.mbo.*;

import psdi.app.location.*;
import psdi.app.persongroup.*;
import psdi.app.person.*;

//Added for EMS-544
import java.sql.SQLException;
import javax.mail.MessagingException;

import psdi.security.UserInfo;
import psdi.common.commtmplt.CommTemplate;
import psdi.common.commtmplt.*;
//End of added for EMS-544

/*
 * Prints items reservations on storeroom's fax machine 
 */

/*20-OCT-2020 BCT CUSTOMIZATION STARTS
 * REMOVING UMS RELATED INFO 
 */

public class ResrvEmailNotifCustom
		implements ActionCustomClass
{

	/*
	 * Constructor - does nothing
	 */
	public ResrvEmailNotifCustom()
	{
	}


	/*
	 * Print the items reservations via fax in the stores
	 */
	public void applyCustomAction(MboRemote woremote, Object aobj[])
			throws MXException, RemoteException
	{
		//System.out.println("--VERSION 5-- ");
		mxLogger.debug("ResrvEmailNotifCustom - Entering");

		wo = woremote;

		// Required to ensure that the change status is committed to DB (which ensures that reservations are created)
		MboSetRemote woset = wo.getThisMboSet();
		woset.save();
		System.out.println("Test");
		// Get the reservations for this WO and exit if no reservation
		MboSetRemote invresset = wo.getMboSet("SELECTINVRESVITEM");
		if (invresset.isEmpty())
			return;

		//BCT Read the config file
		try
		{
		//BCT	readConfigFile();
			NODATA= "&nbsp;";
			DATEFORMAT= "EEEE d MMMM y";
			FONTSTYLE= "font-family:Arial;font-size:12";
			ATTACHMENTEXT= ".html";
			FILEPATH= MXServer.getMXServer().getSystemProperties().getProperty("psa.app.workorder.ResrvEmailNotifCustom.filePath");
			
			System.out.println("FilePath" + FILEPATH);
		}
		catch (Exception ioe)
		{
			//mxLogger.error("ResrvEmailNotifCustom - Problem reading the configuration file. Exiting");
			mxLogger.error("ResrvEmailNotifCustom - Problem reading the System Properties file. Exiting");		
			//String[] param = { CFGFILE };
			throw new MXApplicationException("iface", "exception", ioe);
		}

		// Build the content to be sent in HTML format
		String headgen			= buildHeaderGeneral();
// SR 079 Start of Modification
//		String headwo			= buildHeaderWO();
// End of Modification
		String footer			= buildFooter();
		String detailshead	= buildDetailsHeader();
		String detailsfoot	= buildDetailsFooter();
		String message			= "";

		// Build subject
	/* BCT
			String subject = SUBJECT.replaceAll("wonum", wo.getString("wonum"));
		//System.out.println("-wonum-" + wo.getString("wonum"));
		// Parameters of email to UMS
		MxEmail mxemail = new MxEmail();
		mxemail.setFromMail(FROM);
		mxemail.setToMail(UMSEMAIL); */

		// Sort the reservations by store as we need to send 1 fax per store
		invresset.setOrderBy("location");
		invresset.reset();

		//Variabled used to get person emails

		MboRemote locmbo;
		MboRemote emailmbo;
		MboRemote persongrpmbo;
		MboRemote personmbo;


		// Variables used in the below loop
		MboRemote	invres;
		String		store	= "";
		String		details	= "";
		String		fax		= "";
		String		attachmentname = "WO-" + wo.getString("wonum") + ATTACHMENTEXT;
		int			sno = 1;


//------------Aravind code
			ArrayList locationList = new ArrayList();
			for (int j = 0; (invres = invresset.getMbo(j)) != null; j++)
			{
				locationList.add(invres.getString("location"));
			
			}

				// add elements to al, including duplicates
				HashSet hs = new HashSet();
				hs.addAll(locationList);
				locationList.clear();
				locationList.addAll(hs);
		String []locationArray = new String[locationList.size()];
		locationList.toArray(locationArray);
			for (int i=0; i <  locationList.size() ; i++ )
			{
					String uniqueLoc = locationArray[i];
						details = "";
						MboSetRemote itemSet = MXServer.getMXServer().getMboSet("INVRESERVE", wo.getUserInfo());
						SqlFormat qsqf = new SqlFormat(wo.getUserInfo(), "wonum = :1 and location=:2");
						qsqf.setObject(1, "INVRESERVE", "wonum",wo.getString("wonum"));
						qsqf.setObject(2, "INVRESERVE", "location",uniqueLoc);
						itemSet.setWhere(qsqf.format());
						MboRemote itemMbo;
						for (int k=0; (itemMbo = itemSet.getMbo(k)) != null;k++)
						{
								details	= details + buildDetails(itemMbo, sno);
								sno++;

						} //end of items for loop


								message = headgen + buildHeaderStoreWO(uniqueLoc) + detailshead + details + detailsfoot + footer;
								String filename = "WO-" + wo.getString("wonum") + ATTACHMENTEXT;

									/*System.out.println("-file creation starting-");
									FileOutputStream fo = new FileOutputStream(HTMLFILEPATH+filename);
									PrintStream ps = new PrintStream(fo);
									ps.println(message);
									ps.close();
									fo.close();*/
									
									
						//Start of EMS-544

//removed for EMS-544 to consolidate sending of email from communication template instead
/*
				//start of for loop to get emails and send email

						MboSetRemote locset = MXServer.getMXServer().getMboSet("LOCATIONS", wo.getUserInfo());
						SqlFormat qsqf1 = new SqlFormat(wo.getUserInfo(), "location=:1 and type=:2");
						qsqf1.setObject(1, "LOCATIONS", "location",uniqueLoc);
						qsqf1.setObject(2, "LOCATIONS", "type","STOREROOM");
						locset.setWhere(qsqf1.format());
						locmbo = locset.getMbo(0);
					//LocationSetRemote locset = (LocationSetRemote) invres.getMboSet("LOCATIONS");
					//locmbo = locset.getMbo(0);
					PersonGroupSetRemote persongrpset = (PersonGroupSetRemote) locmbo.getMboSet("STOREPERSONGROUP");
					persongrpmbo = persongrpset.getMbo(0);
					PersonSetRemote personset = (PersonSetRemote) persongrpmbo.getMboSet("ALLPEOPLEINPERSONGROUP");


					for (int k=0; (personmbo = personset.getMbo(k)) != null; k++)
					{
						//EmailSetRemote emailet = (EmailSetRemote) personmbo.getMboSet("PRIMARYEMAIL");
						//emailmbo  =  emailet.getMbo(0);
						String personid = personmbo.getString("PERSONID");
						//System.out.println("-personid-" + personid);
						MboSetRemote emailSqlSet = MXServer.getMXServer().getMboSet("EMAIL", wo.getUserInfo());
						SqlFormat qsqf6 = new SqlFormat(wo.getUserInfo(), "personid=:1");
						qsqf6.setObject(1, "EMAIL", "personid",personid);
						emailSqlSet.setWhere(qsqf6.format());
						String emailAddress = null;
						if (!emailSqlSet.isEmpty())
						{
								MboRemote emailSqlMbo;
								emailSqlMbo = emailSqlSet.getMbo(0);
								emailAddress = emailSqlMbo.getString("EMAILADDRESS");

								try
								{
								String emailFrom = FROM;
								MXServer.sendEMail(emailAddress, emailFrom, subject, subject,  message, filename);
								}
								catch (Exception e)
								{
									System.out.println("-e-"+ e);
								}

						}
						else
						{
								System.out.println("-no email id for  person-" + personid);
						}

						//System.out.println("-emailAddress-" + emailAddress + "-personid-" + personid);


						//String type = emailmbo.getString("TYPE");
						//System.out.println("-personid-" + personid + "-type-"+ type);
						//String emailAddress = emailmbo.getString("EMAILADDRESS");
						//System.out.println("-emailAddress-" + emailAddress);

						//if (emailAddress == null || emailAddress.length() < 2)
						//	{
						//		System.out.println("-no mail address--");
						//	}
						//	else
						//	{
						//		try
						//		{
						//		String emailFrom = FROM;
						//		MXServer.sendEMail(emailAddress, emailFrom, subject, subject,  message, filename);
						//		}
						//		catch (Exception e)
						//		{
						//			System.out.println("-e-"+ e);
						//		}
						//	}   
					}  //end of for loop in sending emails to persons related to a store
					
*/
//end of removed for EMS-544 to consolidate sending of email from communication template instead
					
					//Get one of the wpitem MBO for the store reservation location so that the commtemplate can use the relationships from this MBO
					MboSetRemote wpitmSet = MXServer.getMXServer().getMboSet("WPITEM", wo.getUserInfo());
					SqlFormat qsqf7 = new SqlFormat(wo.getUserInfo(), "WONUM=:1 and LOCATION=:2");
					qsqf7.setObject(1, "WPITEM", "wonum",wo.getString("wonum"));
					qsqf7.setObject(2, "WPITEM", "location",uniqueLoc);
					wpitmSet.setWhere(qsqf7.format());
					MboRemote wpitmMbo;
					wpitmMbo = wpitmSet.getMbo(0);
					
					//save the html attachment to a file(same folder and filename for UMS fax so that commtemplate can use it)
					
					//generate filepath of attachment that was created from UMS fax & email actions
			        String fullfilename = FILEPATH + filename; 
			        
			        mxLogger.debug("ResrvEmailNotifCustom - fullfilename is: " + fullfilename);
			        
					// Create the temp file attachment that UMS will send
					try
					{
						File file = new File(fullfilename);
						FileWriter filewriter = new FileWriter(file);
						filewriter.write(message);
						filewriter.close();
						
						mxLogger.debug("ResrvEmailNotifCustom - fullfilename is written");
					}	
					catch (IOException e)
					{
						mxLogger.error("ResrvEmailNotifCustom - I/O Exception while writing UMS attachment file");
						String[] param = { fullfilename };
						throw new MXApplicationException("iface", "ioexception", param, e.fillInStackTrace());
					}

					//Get the commtemplate set to be sent out
                	MboSetRemote commSetRemote = wpitmMbo.getMboSet("$commSetRemote", "COMMTEMPLATE", "templateid='UMSEMAILWO'");
                	
                	if(commSetRemote.count() > 0)
                	{
	                	//Get the commtemplate to be sent out
                        CommTemplate commRemote = (CommTemplate)commSetRemote.getMbo(0);
                        
                        //only do sending out if the status of the commtemplate is ACTIVE
                        if(commRemote.getString("STATUS").equals("ACTIVE"))
                        {
	                        // mboRemote should be that object whose content wil be replaced in commtemplate. So, if your commtemplate sends out workorder information nand you have used :wonum in your template make sure mboRemote is that object whose information will be resolved/replaced
                        	//get subject of commtemplate
                        	SqlFormat sqf = new SqlFormat(wpitmMbo, commRemote.getString("subject"));
	                        
                        	//Set IgnoreUnresolved to true if you want to ignore any errors in commtemplate, errors for stuff like if you have used :wonum and it cannot resolve this attribute.
                        	sqf.setIgnoreUnresolved(true);

	                        //Resolve Content method below converts template in to the dynamic content, by resolving I mean instead of :wonum it will put the current records wonum.
	                        String ctsubject = sqf.resolveContent();
	
	                        //Similarly do it for the message content
	                        sqf = new SqlFormat(wpitmMbo, commRemote.getString("message"));
	
	                        sqf.setIgnoreUnresolved(true);
	
	                        String ctmessage = sqf.resolveContent();
	                        
	                        //try catch to send out email
	                        try
	                        {
		                        	//get sender email
	                                String sendFrom = commRemote.getString("sendFrom");
	                                
	                                //get receipent email strings
	                                String to = commRemote.convertSendTo("COMMTMPLT_TO", wpitmMbo);
			                        String cc = commRemote.convertSendTo("COMMTMPLT_CC", wpitmMbo);
			                        String bcc = commRemote.convertSendTo("COMMTMPLT_BCC", wpitmMbo);
			                        
			                        //create string array for commtemplate attachment
			                        String filepath[] = {fullfilename};
			                        
			                        mxLogger.debug("ResrvEmailNotifCustom - To list is: " + to);
			                        mxLogger.debug("ResrvEmailNotifCustom - cc list is: " + cc);
			                        mxLogger.debug("ResrvEmailNotifCustom - bcc list is: " + bcc);
			                        mxLogger.debug("ResrvEmailNotifCustom - sendFrom list is: " + sendFrom);
			                        mxLogger.debug("ResrvEmailNotifCustom - ctsubject list is: " + ctsubject);
			                        mxLogger.debug("ResrvEmailNotifCustom - ctmessage list is: " + ctmessage);
			                        
			                        //Send out the email. Note the 1 null behind is for URL(attachments from commtemplate will not work too as the attachment is hardcoded)
			                        MXServer.sendEMail(to, cc, bcc, sendFrom, ctsubject, ctmessage, sendFrom, filepath, null);
	                        }
	                        catch(MessagingException messagingexception)
	                        {
			                    messagingexception.printStackTrace();
				                String as[] = {
				                        messagingexception.getMessage()
				                };
				                mxLogger.error("ResrvEmailNotifCustom - I/O Exception while sending commtemplate");
				                throw new MXApplicationException("securgroup", "emailNotSent", as);
		                    }
	
	                	}
	                        
                    }
					//End of EMS-544
			} //end of location for loop
		invresset.close();
		mxLogger.debug("ResrvEmailNotifCustom - Leaving");

	}


	/*
	 * Build the 1st part of the file header
	 */
	private String buildHeaderGeneral()
			throws MXException, RemoteException
	{
// SR 079 Start of Modification		
/*
 		String buffer = "<html>\n"
				+ "<header><title>Reservations for WO " + wo.getString("wonum") + "</title></header>\n"
				+ "<body style='" + FONTSTYLE + "'>\n"
				+ "<table border=0 cellpadding=2 cellspacing=4 style='" + FONTSTYLE + "'>\n";
*/
		
		String buffer = "<html>\n"
						+ "<header><title>Reservations for WO " + wo.getString("wonum") + "</title></header>\n"
						+ "<body style='" + FONTSTYLE + "'>\n"
						+ "<table border=0 cellpadding=2 cellspacing=4 style='" + FONTSTYLE + "'>\n"
						+ "<tr><td>Packing List</td></tr>\n"
						+ "</table>\n";
/* End of Modification */
		return buffer;
	}
// SR 079 Start of Modification
/*
// End of Modification	
	// Build the part of the header for the store
	 
	private String buildHeaderStore(String store)
	{
		String buffer = " <tr>\n"
				+ "  <td>Issuing Store</td>\n"
				+ "  <td>" + store + "</td>\n"
				+ "  <td width=50>" + NODATA + "</td>\n"
				+ "  <td>Print D/T</td>\n"
				+ "  <td>" + convertDateToText(new Date()) + "</td>\n"
				+ " </tr>\n"
				+ " <tr><td colspan=5>" + NODATA + "</td></tr>\n";
		return buffer;
	}


	
	 // Build the part of the header related to the WO
	 
	private String buildHeaderWO()
			throws MXException, RemoteException
	{
		String blankcells	= "<td colspan=3>" + NODATA + "</td>";
		String buffer = " <tr><td>Work Order</td><td>" + wo.getString("wonum") + "</td>" + blankcells + "</tr>\n"
				+ " <tr><td>Location</td><td>" + wo.getString("location") + "</td>" + blankcells + "</tr>\n"
				+ " <tr><td>Work Type</td><td>" + wo.getString("worktype") + "</td>" + blankcells + "</tr>\n"
				+ " <tr><td>WO Description</td><td>" + wo.getString("description") + "</td>" + blankcells + "</tr>\n"
				+ " <tr><td>Required Date and Time</td><td>"
					+ (wo.isNull("schedstart") ? NODATA : convertDateToText(wo.getDate("schedstart")))
					+ "</td>" + blankcells + "</tr>\n"
				+ " <tr><td>Team IC</td><td>" + wo.getString("teamic") + "</td>" + blankcells + "</tr>\n"
				+ " <tr><td>Supervisor</td><td>" + wo.getString("supervisor") + "</td>" + blankcells + "</tr>\n"
				+ "</table>\n<br>\n";
		return buffer;
	}
// SR 079 Start of Modification
 */
//	 End of Modification	
	
	/* SR 079 Start of Modification */
	private String buildHeaderStoreWO(String store)
		throws MXException, RemoteException
	{
		String buffer = "<table border=0 cellpadding=2 cellspacing=4 style='" + FONTSTYLE + "'>\n"
				+ " <tr>\n"
				+ "  <td>Issuing Store</td><td>" + store + "</td>\n"
				+ "  <td>" + NODATA + "</td>\n"
				+ "  <td>Print D/T</td><td>" + convertDateToText(new Date()) + "</td>\n"
				+ " </tr>\n"
				+ " <tr>\n"
				+ "  <td>Work Order</td><td>" + wo.getString("wonum") + "</td>\n"
				+ "  <td>" + NODATA + "</td>\n"
				+ "  <td>Required Date and Time</td><td>" + (wo.isNull("schedstart") ? NODATA : convertDateToText(wo.getDate("schedstart"))) + "</td>\n"
				+ " </tr>\n"
				+ " <tr>\n"
				+ "  <td>Location</td><td>" + wo.getString("location") + "</td>\n"
				+ "  <td>" + NODATA + "</td>\n"
				+ "  <td>Team IC</td><td>" + wo.getString("teamic") + "</td>\n"
				+ " </tr>\n"
				+ " <tr>\n"
				+ "  <td>Work Type</td><td>" + wo.getString("worktype") + "</td>\n"
				+ "  <td>" + NODATA + "</td>\n"
				+ "  <td>Supervisor</td><td>" + wo.getString("supervisor") + "</td>\n"
				+ " </tr>\n"
				+ " <tr>\n"
				+ "  <td valign=top>WO Description</td><td width=400>" + wo.getString("description") + "</td>\n"
				+ " </tr>\n"
				+ "</table>\n"
				+ "<br>\n";
		return buffer;
	}
	/* End of Modification */
	
	/*
	 * Build the table header of the reservation lines
	 */
	private String buildDetailsHeader()
	{
// SR 079 Start of Modification
/*	
		String buffer = "<table border=1 cellspacing=1 cellpadding=2 style='" + FONTSTYLE + "'>\n"
				+ " <tr>\n"
				+ "  <td>Stock Code</td>\n"
				+ "  <td>Condition Code</td>\n"
				+ "  <td>Description</td>\n"
				+ "  <td>Current balance</td>\n"
				+ "  <td>Unit Cost</td>\n"
				+ "  <td>Quantity Requested</td>\n"
				+ "  <td width=200>Remarks</td>\n"
				+ " </tr>\n";
*/
		String buffer = "<table border=1 cellspacing=1 cellpadding=2 style='" + FONTSTYLE + "'>\n"
				+ " <tr>\n"
				+ "  <td>S/No</td>\n"
				+ "  <td>Stock Code</td>\n"
				+ "  <td>Condition Code</td>\n"
				+ "  <td width=200>Description</td>\n"
				+ "  <td>Unit Cost</td>\n"
				+ "  <td width=50>Current Balance</td>\n"
				+ "  <td>Bin Locn</td>\n"
				+ "  <td>Lot No</td>\n"
				+ "  <td width=50>Quantity Requested</td>\n"
				+ "  <td width=200>Remarks</td>\n"
				+ " </tr>\n";
//		 End of Modification
		return buffer;
	}


	/*
	 * Build the table footer of the reservation lines
	 */
	private String buildDetailsFooter()
	{
// SR 079 Start of Modification
		String buffer = " <tr>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ "  <td>End of List</td>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ "  <td>" + NODATA + "</td>\n"
			+ " </tr>\n"
			+ "</table>\n"
			+ "<br><br>\n";
		return buffer;
//		return "</table>\n";
// End of Modification		
	}


	/*
	 * Build the reservation lines
	 */
	private String buildDetails(MboRemote invres, int sno)
			throws MXException, RemoteException
	{
// SR 079 Start of Modification
/*
		String buffer = " <tr>\n"
				+ "  <td>" + invres.getString("itemnum") + "</td>\n"
				+ "  <td>" + invres.getString("conditioncode") + "</td>\n"
				+ "  <td>" + invres.getString("description") + "</td>\n"
				+ "  <td>" + getCurrentBalance(invres) + "</td>\n"
				+ "  <td>" + getUnitCost(invres) + "</td>\n"
				+ "  <td>" + invres.getDouble("reservedqty") + "</td>\n"
				+ "  <td>" + NODATA + "</td>\n"
				+ " </tr>\n";
*/		
	//System.out.println("--itemnum details--" + invres.getString("itemnum"));
		String buffer = " <tr>\n"
				+ "  <td valign=top>" + sno + "</td>\n"
				+ "  <td valign=top>" + invres.getString("itemnum") + "</td>\n"
				+ "  <td valign=top>" + invres.getString("conditioncode") + "</td>\n"
				+ "  <td valign=top>" + invres.getString("description") + "</td>\n"
				+ "  <td valign=top>" + getUnitCost(invres) + "</td>\n"
				+ "  <td>" + getBalance(invres)[0] + "</td>\n"
				+ "  <td>" + getBalance(invres)[1] + "</td>\n"
				+ "  <td>" + getBalance(invres)[2] + "</td>\n"
				+ "  <td valign=top>" + invres.getDouble("reservedqty") + "</td>\n"
				+ "  <td valign=top>" + NODATA + "</td>\n"
				+ " </tr>\n";
// End of Modification
		return buffer;
	}


	/*
	 * Build the footer
	 */
	private String buildFooter()
	{
// SR 079 Start of Modification
/*
		String blankcell	= "<td>" + NODATA + "</td>";
		String blankbox	= "<td><table border=1 width=100% height=100%><tr>" + blankcell + "</tr></table></td>";
		String buffer = "<br><br>\n"
				+ "<table border=0 cellspacing=0 cellpadding=0 style='" + FONTSTYLE + "'>\n"
				+ " <tr>\n"
				+ "  <td width=150>For Store Use Only</td>\n"
				+ "  <td width=150>" + NODATA + "</td>\n"
				+ "  <td width=50>" + NODATA + "</td>\n"
				+ "  <td width=150>For User's Use</td>\n"
				+ "  <td width=150>" + NODATA + "</td>\n"
				+ " </tr>\n"
				+ " <tr height=100>\n"
				+ "  " + blankbox + blankcell + "\n"
				+ "  " + blankcell + "\n"
				+ "  " + blankbox + blankcell + "\n"
				+ " </tr>\n"
				+ " <tr>\n"
				+ "  <td>Checked and Issued By</td>" + blankcell + "\n"
				+ "  " + blankcell + "\n"
				+ "  <td>Collected By</td>" + blankcell + "\n"
				+ " </tr>\n"
				+ " <tr>" + blankcell + blankcell + blankcell + blankcell + blankcell + "</tr>\n"
				+ " <tr height=20 valign=middle>\n"
				+ "  <td>Name</td>" + blankbox + "\n"
				+ "  " + blankcell + "\n"
				+ "  <td>Name</td>" + blankbox + "\n"
				+ " </tr>\n"
				+ " <tr height=20 valign=middle>\n"
				+ "  <td>Designation</td>" + blankbox + "\n"
				+ "  " + blankcell + "\n"
				+ "  <td>Designation</td>" + blankbox + "\n"
				+ " </tr>\n"
				+ " <tr height=20 valign=middle>\n"
				+ "  <td>Date</td>" + blankbox + "\n"
				+ "  " + blankcell + "\n"
				+ "  <td>Date</td>" + blankbox + "\n"
				+ " </tr>\n"
				+ "</table>\n"
				+ "</html>";
*/
		String buffer = "<table border=0 cellspacing=0 cellpadding=0 style='" + FONTSTYLE + "'>\n"
		 		+ " <tr height=20>\n"
		 		+ "  <td width=150>For Store Use Only</td>\n"
		 		+ "  <td width=200>" + NODATA + "</td>\n"
		 		+ "  <td>" + NODATA + "</td>\n"
		 		+ "  <td width=100>"  + NODATA + "</td>\n"
		 		+ "  <td width=150>For User's Use</td>\n"
		 		+ "  <td width=200>"  + NODATA + "</td>\n"
		 		+ " </tr>\n"
		 		+ " <tr height=50>\n"
		 		+ "  <td>Checked and Issued By</td>\n"
		 		+ "  <td colspan=2><table border=1 width=100% height=100% ><tr><td>" + NODATA + "</td></tr></table></td>\n"
		 		+ "  <td>" + NODATA + "</td>\n"
		 		+ "  <td>Collected By</td>\n"
		 		+ "  <td colspan=2><table border=1 width=100% height=100% ><tr><td>" + NODATA + "</td></tr></table></td>\n"
		 		+ " </tr>\n"
		 		+ " <tr>\n"
		 		+ "  <td>" + NODATA + "</td>\n"
		 		+ " </tr>\n"
		 		+ " <tr height=20 valign=middle>\n"
		 		+ "  <td>Name</td>\n"
		 		+ "  <td colspan=2><table border=1 width=100% height=100%><tr><td>" + NODATA + "</td></tr></table></td>\n"
		 		+ "  <td>" + NODATA + "</td>\n"
		 		+ "  <td>Name</td>\n"
		 		+ "  <td colspan=2><table border=1 width=100% height=100%><tr><td>" + NODATA + "</td></tr></table></td>\n"
		 		+ " </tr>\n"
		 		+ " <tr height=20 valign=middle>\n"
		 		+ "  <td>Designation</td>\n"
		 		+ "  <td colspan=2><table border=1 width=100% height=100%><tr><td>" + NODATA + "</td></tr></table></td>\n"
		 		+ "  <td>" + NODATA + "</td>\n"
		 		+ "  <td>Designation</td>\n"
		 		+ "  <td colspan=2><table border=1 width=100% height=100%><tr><td>" + NODATA + "</td></tr></table></td>\n"
		 		+ " </tr>\n"
		 		+ " <tr height=20 valign=middle>\n"
		 		+ "  <td>Date</td>\n"
		 		+ "  <td colspan=2><table border=1 width=100% height=100%><tr><td>" + NODATA + "</td></tr></table></td>\n"
		 		+ "  <td>" + NODATA + "</td>\n"
		 		+ "  <td>Date</td>\n"
		 		+ "  <td colspan=2><table border=1 width=100% height=100%><tr><td>" + NODATA + "</td></tr></table></td>\n"
		 		+ " </tr>\n"
		 		+ "</table>\n"
		 		+ "</html>\n";
// End of Modification	
		return buffer;
	}


	/*
	 * Get current balance and unic cost of the item in store (in this order)
	 */
	private String[] getBalance(MboRemote invres)
			throws MXException, RemoteException
	{
		InvBalancesSetRemote invbalset = (InvBalancesSetRemote) invres.getMboSet("INVBALANCES");
// SR 079 Start of Modification
		invbalset.setOrderBy("LOTNUM");
		invbalset.reset();
		String[] detail = { NODATA, NODATA, NODATA };
// End of Modification
		double curbal = 0;
		InvBalancesRemote invbal;
		
/*		for (int i = 0; (invbal = (InvBalancesRemote) invbalset.getMbo(i)) != null; i ++)
				curbal += invbal.getDouble("curbal");
*/
// SR 079 Start of Modification		
		for (int i = 0; ((invbal = (InvBalancesRemote) invbalset.getMbo(i)) != null) && (curbal < invres.getDouble("reservedqty")); i ++)
		{
			if(invbal.getDouble("curbal") > 0) 
			{
				detail[0] = detail[0] + "<BR>" + invbal.getDouble("curbal");
				detail[1] = detail[1] + "<BR>" + invbal.getString("binnum");
				detail[2] = detail[2] + "<BR>" + (invbal.getString("lotnum").equals("") ? NODATA : invbal.getString("lotnum"));
				curbal += invbal.getDouble("curbal");
				
			}
		}
		return detail;
//		return curbal;
// End of Modification
	}


	/*
	 * Get unic cost of the item in store
	 */
	private double getUnitCost(MboRemote invres)
			throws MXException, RemoteException
	{
		InventoryRemote inv = (InventoryRemote) invres.getMboSet("INVENTORY").getMbo(0);
		return inv.getDefaultIssueCost(invres.getString("conditioncode"));
	}


	/*
	 * Get the fax no of a storeroom
	 */
	private String getStoreFax(MboRemote invres)
			throws MXException, RemoteException
	{
		MboRemote store = invres.getMboSet("LOCATIONS").getMbo(0);
		return store.getString("faxphone");
	}


	/*
	 * Converts a date to a string in the format specified by DATEFORMAT
	 */
	private String convertDateToText(Date date)
	{
		SimpleDateFormat dateformat = new SimpleDateFormat(DATEFORMAT);
		return dateformat.format(date);
	}
	
	
	/*
	 * Read the configuration file (path hard-coded, no choice)
	 */
/*BCT	private void readConfigFile()
			throws IOException
	{
		BufferedReader reader = new BufferedReader(new FileReader(CFGFILE));
		for(String line; (line = reader.readLine()) != null; )
		{
			StringTokenizer tok = new StringTokenizer(line.trim(), "=");
			String parameter	= tok.nextToken().trim();
			String value		= tok.nextToken().trim();
			if (parameter.equalsIgnoreCase("FROM"))
				FROM				= value;
			else if (parameter.equalsIgnoreCase("UMSEMAIL"))
				UMSEMAIL			= value;
			else if (parameter.equalsIgnoreCase("SUBJECT"))
				SUBJECT			= value;
			else if (parameter.equalsIgnoreCase("NODATA"))
				NODATA			= value;
			else if (parameter.equalsIgnoreCase("DATEFORMAT"))
				DATEFORMAT		= value;
			else if (parameter.equalsIgnoreCase("FONTSTYLE"))
				FONTSTYLE		= value;
			else if (parameter.equalsIgnoreCase("ATTACHMENTEXT"))
				ATTACHMENTEXT	= value;
			// Ignore any other parameter
		}
	}*/

	private MXServer			mxserver;
	private MboRemote		wo;
/*BCT private static String	FROM;
	private static String	UMSEMAIL;
	private static String	SUBJECT;*/
	private static String	NODATA;
	private static String	DATEFORMAT;
	private static String	FONTSTYLE;
	private static String ATTACHMENTEXT;
	private static String FILEPATH;
//BCT	private static final String		CFGFILE	= "/opt/psa/rel/config/ums/cfg/faxresa.cfg";
//BCT	private static final String		HTMLFILEPATH	= "/opt/psa/rel/config/ums/cfg/";
	private static final MXLogger	mxLogger	= MXLoggerFactory.getLogger("maximo.application.WORKORDER");
}
