/*
 * Modification history
 * 24-04-07	AGD	SR-030	Prevent user to select a project which budget is exceeded
 * 27-04-07 LS	SR-030 	Make Project ID of WO Org level
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import psdi.app.financial.FinControlRemote;
import psdi.mbo.MAXTableDomain;
import psdi.mbo.MboConstants;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class FldWOFinControlProjectIDCustom extends MAXTableDomain
{

	public FldWOFinControlProjectIDCustom(MboValue mbovalue)
	{
        super(mbovalue);
        setRelationship("FINCNTRL", "projectid = :fcprojectid");
        String as[] = {
            "fcprojectid"
        };
        String as1[] = {
            "projectid"
        };
        setLookupKeyMapInOrder(as, as1);
	}

    public void initValue()
	    throws MXException, RemoteException
	{
        super.initValue();
        if(!getMboValue("fincntrlid").isNull())
        {
            MboSetRemote mbosetremote = getMboValue().getMbo().getMboSet("FINCNTRL");
            if(!mbosetremote.isEmpty())
            {
                FinControlRemote fincontrolremote = (FinControlRemote)mbosetremote.getMbo(0);
                getMboValue().setValue(fincontrolremote.getString("projectid"), 11L);
            }
        }
	}
    
	/*
	 * Validates value by re-coding super as super it validates using siteid so it cannot be used
	 * Validates budget as well
	 */
	public void validate()
			throws MXException, RemoteException
	{
		if(getMboValue().isNull())
			return;

		MboSetRemote projectset = getMboValue().getMbo().getMboSet("$fincontrolProject_VALIDATE", "FINCNTRL", getValidProjectsQuery());
		projectset.setWhere("projectid='" + getMboValue().getString() + "'");
		projectset.reset();
		if(projectset.isEmpty())
		{
			Object param[] = { getMboValue().getString() };
			throw new MXApplicationException("workorder", "InValidFCProject", param);
		}
	}


	/*
	 * Set fincntrlid but without relying on super as super uses siteid
	 */
	public void action()
			throws MXException, RemoteException
	{
        if(getMboValue().isNull())
        {
            getMboValue("fctaskid").setValueNull(11L);
            getMboValue("fincntrlid").setValueNull(11L);
            return;
        }

		String projecttype = getTranslator().toExternalList("FCTYPE", "PROJECT", getMboValue().getMbo());
		SqlFormat sqlformat = new SqlFormat(getMboValue().getMbo(), "projectid=:1 AND fctype IN (" + projecttype + ") AND orgid=:2");
		sqlformat.setObject(1, "FINCNTRL", "projectid", getMboValue().getString());
		sqlformat.setObject(2, "FINCNTRL", "orgid", getMboValue("orgid").getString());
		MboSetRemote projectset = getMboValue().getMbo().getMboSet("$fcproject", "FINCNTRL", sqlformat.format());
		if(!projectset.isEmpty())
			getMboValue("fincntrlid").setValue(projectset.getMbo(0).getString("fincntrlid"), MboConstants.NOVALIDATION);
	}

	
	public boolean hasList()
    {
    	return true;
    }
	
	/*
	 * For the lookup display
	 * Do not call super as it set the list criteria using siteid so it cannot be used
	 */
	public MboSetRemote getList()
			throws MXException, RemoteException
	{
		setListCriteria(getValidProjectsQuery());
		
		MboSetRemote projectset = super.getList();
/*		MboRemote project = null;
		for (int i = 0; (project = projectset.getMbo(i)) != null ; i ++)
		{
			if (project.getDouble("remainingcost") <= 0)
				projectset.remove(project);
		}
*/		return projectset;
	}

	private String getValidProjectsQuery()
			throws MXException, RemoteException
	{
		Date today = MXServer.getMXServer().getDate();
		GregorianCalendar gregoriancalendar = new GregorianCalendar();
		gregoriancalendar.setTime(today);
		gregoriancalendar.add(Calendar.DAY_OF_MONTH, 1);
		Date tomorrow = gregoriancalendar.getTime();

		String projectstatus = getTranslator().toExternalList("FCSTATUS", "APPR", getMboValue().getMbo());
		String projecttype = getTranslator().toExternalList("FCTYPE", "PROJECT", getMboValue().getMbo());
		SqlFormat sqlformat = new SqlFormat(getMboValue().getMbo(),
				"fcstatus IN (" + projectstatus + ") AND fctype IN (" + projecttype + ") "
				+ "AND ((enddate>=:1) OR enddate IS NULL) AND ((startdate<=:2) OR startdate IS NULL) "
				+ "AND orgid=:3");
		sqlformat.setDate(1, today);
		sqlformat.setDate(2, tomorrow);
		sqlformat.setObject(3, "FINCNTRL", "orgid", getMboValue("orgid").getString());
		return sqlformat.format();
	}
}
