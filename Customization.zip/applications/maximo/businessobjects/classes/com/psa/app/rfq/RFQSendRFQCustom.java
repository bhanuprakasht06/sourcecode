/*
 * Modification history
 * 08-03-07     AGD     SR-062  Creation
 * 10-04-07     AGD     SR-085  Don't send to UMS directly (another stand-alone program in charge)
 * 04-07-07     AGD     SR-103  Send buyer email @ as userid to UMS
 * 17-09-07     AGD     SR-108  Change in method MxEmail.sendViaUMS
 * 30-10-07     AGD     eRFQ            Cater for sending brief RFQ
 * 20-06-08     HAM     eRFQ    Cater for sending ReOpened RFQ
 * 28-03-13 WMJ EMS-561 [RFQ]To indicate end timing of 2359 hours for RFQ quote submission in the brief fax, email and/or full fax that is sent to suppliers
 * 28-03-13 WMJ EMS-571 [RFQ]To set the sorting order of the RFQ lines in Fax and eRFQ Vendor Application to be based on the RFQ Line number
 * 28-02-14 WMJ EMS-777 [RFQ][UMS]Use full fax template for all emails/faxes sent out
 * 15-07-14	WMJ	EMS-820	[UMS]Switch to using common UMS libraries for sending of faxes
 */
package com.psa.app.rfq;

//import hello.iconn.client.Contact;
//import com.psa.common.ums.Contact;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;

import psdi.app.person.PersonRemote;
import psdi.common.action.ActionCustomClass;

import com.psa.custom.common.MxEmail;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


/*
 * Sends RFQ outside
 */
public class RFQSendRFQCustom
implements ActionCustomClass
{
/*
* Constructor - does nothing
*/
public RFQSendRFQCustom()
{
rfq = null;
}


/*
* Send the RFQ to all vendors and to the RFQ creator
*/
public void applyCustomAction(MboRemote rfqremote, Object aobj[])
        throws MXException, RemoteException
{
mxLogger.debug("RFQSendRFQCustom.applyCustomAction - Entering");

/*
* Requirement changed : checkbox is now at RFQ vendor level
// Don't do anything if RFQ is not supposed to be sent out
if (!rfqremote.getBoolean("sendout"))
{
        mxLogger.info("RFQSendRFQCustom.applyCustomAction - RFQ " + rfqremote.getString("rfqnum") + " not supposed to be sent out");
        return;
}
*/

// Read the config file
try
{
        readConfigFile();
}
catch (IOException ioe)
{
        mxLogger.warn("RFQSendRFQCustom.applyCustomAction - Problem reading the configuration file. Exiting");
        String[] param = { CFGFILE };
        throw new MXApplicationException("iface", "ioexception", param, ioe);
}

rfq = rfqremote;

// Get contact details of RFQ creator
PersonRemote rfqcreator = (PersonRemote) rfq.getMboSet("ENTERPERSON").getMbo(0);

// Build the content to be sent in HTML format
String headgen = buildHeaderGeneral(rfqcreator);
String headvendor = buildHeaderVendor();
String title = buildTitle();
String details = buildDetails();
//Begin modification eRFQ
String briefdetails = buildBriefDetails();
String reopendetails = buildReopenDetails();
//End modification eRFQ
String footer = buildFooter(rfqcreator);
String brieffooter = buildBriefFooter(rfqcreator);
String message = headgen + headvendor + title + details + footer;
String EMAILBODYMESSAGE = EMAILBODY + System.lineSeparator() + "Note: PSA Terms and Conditions apply.";
mxLogger.debug("RFQSendRFQCustom.applyCustomAction - message=\n"+message);

// Build subject
String subject = SUBJECT.replaceAll("siteid", rfq.getString("siteid")).replaceAll("rfqnum", rfq.getString("rfqnum"));


/*
 * Sending the data
 */
MxEmail mxemail = new MxEmail();
mxemail.setFromMail(FROM);
String attachmentname = "RFQ-" + rfq.getString("rfqnum");

// Send an email to the RFQ creator first
if (!rfqcreator.isNull("primaryemail.emailaddress"))
{
        mxemail.setToMail(rfqcreator.getString("primaryemail.emailaddress"));
        //Start of VO - Add T&C to Email --- Comm-IT ----- Maximo 7.6 Change
        //mxemail.send(subject, EMAILBODY, message, attachmentname + ATTACHMENTEXT);
      
        //mxemail.send(subject, EMAILBODY, emailmessage, attachmentname + "-" + rfqvendor.getString("vendor") + ATTACHMENTEXT);
        String rfqPath = mxemail.rfqPath(attachmentname + ATTACHMENTEXT, message);
        String termsPath = "/opt/psa/data/rw/doclinks/attachments/Terms&Conditions.pdf";
        PersonRemote rfqbuyer = (PersonRemote) rfq.getMboSet("PURCHASEAGENT").getMbo(0);                        
        mxemail.setFromMail(rfqbuyer.getString("primaryemail.emailaddress"));
        mxemail.send(subject, EMAILBODYMESSAGE, message, rfqPath, termsPath);
        
        //End of VO - Add T&C to Email --- Comm-IT ----- Maximo 7.6 Change
}

// Send the same data to the vendors via fax & email
MboSetRemote rfqvendorset = rfq.getMboSet("RFQVENDOR");
MboRemote rfqvendor;
for (int i = 0; (rfqvendor = rfqvendorset.getMbo(i)) != null; i++)
{
        // Send only if RFQ vendor is thus configured
        if (rfqvendor.getBoolean("sendout"))
        {
                headvendor = buildHeaderVendor(rfqvendor);
//Begin modification eRFQ
//              message = headgen + headvendor + title + details + footer;

                message = headgen + headvendor;
                if(rfq.getBoolean("reopenedrfq"))
                        message += reopendetails;
                message += title;

                //message = headgen + headvendor + title;
                //message += (rfqvendor.getBoolean("faxbriefrfq")) ? briefdetails : details;
                //message += footer;

                mxLogger.debug("RFQSendRFQCustom.applyCustomAction - Sending previous message to "
                                + rfqvendor.getString("vendor") + " with difference :\n" + headvendor);
//               Send Via Email
//              if (!rfqvendor.isNull("email"))
                String emailmessage = message;
                if (rfqvendor.getBoolean("emailrfq"))
                {
                        //Start of EMS-777
                            //emailmessage += briefdetails + brieffooter;
                            emailmessage += details + footer;
                            //End of EMS-777

//End modification eRFQ
                        mxemail.setToMail(rfqvendor.getString("email"));
                        // Add the vendor code to the attachment name in order to differentiate easily
                        // which file goes to who if manual tracking is needed
                        
                        //Start of VO - Add T&C to Email --- Comm-IT ----- Maximo 7.6 Change
                        //mxemail.send(subject, EMAILBODY, emailmessage, attachmentname + "-" + rfqvendor.getString("vendor") + ATTACHMENTEXT);
                        String rfqPath = mxemail.rfqPath(attachmentname + "-" + rfqvendor.getString("vendor") + ATTACHMENTEXT, emailmessage);
                        String termsPath = "/opt/psa/data/rw/doclinks/attachments/Terms&Conditions.pdf";
                        PersonRemote rfqbuyer = (PersonRemote) rfq.getMboSet("PURCHASEAGENT").getMbo(0);                        
                        mxemail.setFromMail(rfqbuyer.getString("primaryemail.emailaddress"));
                        mxemail.send(subject, EMAILBODYMESSAGE, emailmessage, rfqPath, termsPath);
                        
                        //End of VO - Add T&C to Email --- Comm-IT ----- Maximo 7.6 Change
                }
//              Send Via Fax
//Begin modification eRFQ
                if (rfqvendor.getBoolean("faxrfq") || (rfqvendor.getBoolean("faxbriefrfq")))
//End modification eRFQ
                {
                        message += (rfqvendor.getBoolean("faxbriefrfq")) ? briefdetails : details;
                        message += (rfqvendor.getBoolean("faxbriefrfq")) ? brieffooter : footer;
                        mxemail.setToMail(UMSEMAIL);
                     /*  mxemail.sendViaUMS(subject, message, rfqvendor.getString("faxphone"), Contact.FAX,
//Begin modification SR-085
//                              "RFQ-" + rfq.getString("rfqnum") + ".html");
//Begin modification SR-103
//                              "RFQ-" + rfq.getString("rfqnum") + "-" + rfqvendor.getString("vendor") + ".html");
                                "RFQ-" + rfq.getString("rfqnum") + "-" + rfqvendor.getString("vendor") + ".html",
//Begin modification SR-108
//                              rfq.getString("purchaseagent.primaryemail.emailaddress"));
                                rfq.getString("purchaseagent.primaryemail.emailaddress"), "rfq");*/
//End modification SR-108
//End modification SR-103
//End modification SR-085
                }
//              Begin modification eRFQ
//                      rfqvendor.setValue("sendout",false,MboConstantsCustom.DBSET);
//              End modification eRFQ
        }
        else
        {
                mxLogger.debug("RFQSendRFQCustom.applyCustomAction - RFQ " + rfqremote.getString("rfqnum")
                                + " not supposed to be sent to " + rfqvendor.getString("vendor"));
        }
}
rfqvendorset.save();
rfqvendorset.close();

mxLogger.debug("RFQSendRFQCustom.applyCustomAction - Leaving");
}

/*
* Build the 1st part of the file header - generic to all vendors
*/
private String buildHeaderGeneral(PersonRemote rfqcreator)
        throws MXException, RemoteException
{
// RFQ creator Phone
String rfqcreatorphone = rfqcreator.getString("primaryphone.phonenum");
if (rfqcreatorphone == null)
        rfqcreatorphone = NODATA;
// RFQ creator fax
MboSetRemote rfqcreatorphones = rfqcreator.getMboSet("PHONE");
SqlFormat sqlformat = new SqlFormat(rfqcreator.getUserInfo(), "type='FAX'");
rfqcreatorphones.setWhere(rfqcreatorphones.getWhere() + sqlformat.format());
String rfqcreatorfax;
if (rfqcreatorphones.isEmpty())
        rfqcreatorfax = NODATA;
else
        rfqcreatorfax = rfqcreatorphones.getMbo(0).getString("phonenum");
rfqcreatorphones.close();
// RFQ creator Email
String rfqcreatoremail = rfqcreator.getString("primaryemail.emailaddress");
if (rfqcreatoremail == null)
        rfqcreatoremail = NODATA;
// RFQ requestor name
String rfqrequestor = rfq.getString("requestperson.displayname");

// Build the header data
String buffer = "<html><header><title>RFQ " + rfq.getString("rfqnum") + "</title></header>\n"
                + "<body style='" + FONTSTYLE + "'>\n"
                + "<table border=0 cellpadding=2 cellspacing=5 style='" + FONTSTYLE + "'>\n"
                + "<tr><td>RFQ number:</td><td>" + rfq.getString("rfqnum") + "</td></tr>\n"
                + "<tr><td>Date:</td><td>" + rfq.getString("statusdate") + "</td></tr>\n"
                + "<tr><td>Company:</td><td>PSA Corporation Ltd</td></tr>\n"
                + "<tr><td>Address:</td><td>PSA Building 460 Alexandra Road</td></tr>\n"
                + "<tr><td>Contact person:</td><td>" + rfqcreator.getString("displayname")
                + "</td></tr>\n" + "<tr><td>Office number:</td><td>" + rfqcreatorphone + "</td></tr>\n"
                + "<tr><td>Fax number:</td><td>" + rfqcreatorfax + "</td></tr>\n"
                + "<tr><td>Email:</td><td>" + rfqcreatoremail + "</td></tr>\n"
                + "<tr><td>Requested by:</td><td>" + rfqrequestor + "</td></tr>\n"
                + "<tr><td colspan=2>" + NODATA + "</td></tr>\n";
return buffer;
}


/*
* Build the 2nd part of the file header - without vendor data
*/
private String buildHeaderVendor()
        throws MXException, RemoteException
{
return buildHeaderVendor(null);
}


/*
* Build the 2nd part of the file header - specific to each vendor
*/
private String buildHeaderVendor(MboRemote rfqvendor)
        throws MXException, RemoteException
{
String name, address, phone, fax;
if (rfqvendor == null)
{
        name = address = phone = fax = NODATA;
}
else
{
        MboRemote company = rfqvendor.getMboSet("COMPANIES").getMbo(0);
        name = company.getString("name");
        address = company.getString("address1") + ", " + company.getString("address4");
        /*
         * No contact sync from Oracle Apps so get the value from the Addresses tab directly
         * MboSetRemote compcontactset = company.getMboSet("PRIMARYCONTACT"); if
         * (compcontactset.isEmpty()) { phone = fax = NODATA; } else { MboRemote compcontact =
         * compcontactset.getMbo(0); phone = compcontact.getString("voicephone"); fax =
         * compcontact.getString("faxphone"); } compcontactset.close();
         */
        phone = company.getString("phone");
        fax = company.getString("fax");
}
String buffer = "<tr><td>Vendor:</td><td>" + name + "</td></tr>\n"
                + "<tr><td>Address:</td><td>" + address + "</td></tr>\n"
                + "<tr><td>Office number:</td><td>" + phone + "</td></tr>\n" + "<tr><td>Fax:</td><td>"
                + fax + "</td></tr>\n" + "</table>\n";
return buffer;
}


/*
* Build the introduction to the RFQ details
*/
private String buildTitle()
        throws MXException, RemoteException
{
String buffer = "<br><b><center><font size='+2'>" + rfq.getString("description")+ "</font></center></b><br>\n";
buffer += (rfq.getBoolean("reopenedrfq"))? "" : "<p>Dear Sir/Mdm,</p>\n";
return buffer;
}


/*
* Build the RFQ lines
*/
private String buildDetails()
        throws MXException, RemoteException
{
String buffer = "<p>1. We are pleased to invite you to quote for this RFQ in accordance to PSA&#039;s terms and conditions and stipulations set out in the attached for the following items:</p>\n\n";
buffer += "<table border=1 cellspacing=1 cellpadding=2 style='"
                + FONTSTYLE
                + "'><tr><td>Line Number</td><td>Description</td><td>Other Description</td>\n"
                + "<td>Quantity</td><td>UOM</td><td>Unit Price</td><td>Total Price</td><td>ETA (days)</td><td>Remarks</td></tr>\n";

// Display all the RFQ lines
MboSetRemote rfqlines = rfq.getMboSet("RFQLINE");
//Start of EMS-571
rfqlines.setOrderBy("rfqnum, rfqlinenum");
rfqlines.reset();
//End of EMS-571
MboRemote rfqline;
for (int i = 0; (rfqline = rfqlines.getMbo(i)) != null; i++)
{
        String longdesc;
        if (rfqline.isNull("description_longdescription"))
                longdesc = NODATA;
        else
                longdesc = rfqline.getString("description_longdescription");
        buffer = buffer + "<tr><td>" + rfqline.getInt("rfqlinenum") + "</td>\n" + "<td>"
                        + rfqline.getString("description") + "</td>\n" + "<td>"
                        + longdesc + "</td>\n" + "<td>"
                        + rfqline.getDouble("orderqty") + "</td>\n" + "<td>"
                        + rfqline.getString("orderunit") + "</td>\n" + "<td>" + NODATA + "</td><td>"
                        + NODATA + "</td>\n" + "<td>" + NODATA + "</td><td>" + NODATA + "</td></tr>\n";
}

// Put the total line
buffer = buffer + "<tr><td colspan=5>" + NODATA + "</td><td>Grand Total</td>\n" + "<td>"
                + NODATA + "</td><td colspan=2>" + NODATA + "</td></tr></table>\n";
return buffer;
}


//Begin modification eRFQ
/*
* Build a short description of the RFQ, inviting the vendor to check it online instead of via the fax
*/
private String buildBriefDetails()
        throws MXException, RemoteException
{
String buffer = "<p>1. We are pleased to invite you to quote for the items listed in RFQ "+rfq.getString("rfqnum")+"; "
                +"the details are available in the online eRFQ system. The RFQ shall be in accordance to PSA&#039;s terms and conditions and stipulations set out in the attached. </p>";
return buffer;
}
//End modification eRFQ

//Begin modification eRFQ
/*
* Build a short description of the RFQ, inviting the vendor to check it online instead of via the fax
*/
private String buildReopenDetails()
        throws MXException, RemoteException
{
String buffer =  "<b><p>Dear Sir/Mdm,</p>\n"
                                +"<p>1. Please refer to the earlier invitation for RFQ "+rfq.getString("rfqnum")+" attached and note that it  has been reopened. Your earlier quotes if any are no longer valid, please re-quote.</p> \n"
                                +"<p>2. Do take note of the revised closing date and validity in the attachment.</p></b>";
return buffer;
}
//End modification eRFQ


/*
* Builds the end of the document for Full Fax template
*/
private String buildFooter(PersonRemote rfqcreator)
        throws MXException, RemoteException
{
String buffer = "<br><br><br><br><br>\n" + "<table border=0 style='" + FONTSTYLE + "'><tr>\n"
+ " <td><table style='border-top:solid thin black;" + FONTSTYLE + "'>"
+ "<tr><td>Company's stamp</td></tr></table></td>\n"
+ " <td width=50>" + NODATA + "</td>\n"
+ " <td><table style='border-top:solid thin black;" + FONTSTYLE + "'>"
+ "<tr><td>Contact person's name and signature</td></tr></table></td>\n"
+ "</tr></table><br>\n";
GregorianCalendar closingdate = new GregorianCalendar();
closingdate.setTime(rfq.getDate("closeondate"));
//Start of EMS-561
buffer += "<p>2. The closing date of the quotation is: " + convertDateToText(closingdate) + " at 2359 hours.</p>\n";
//End of EMS-561
closingdate.add(Calendar.DATE, 30);
buffer = buffer + "<p>3. Validity is: " + convertDateToText(closingdate) + "</p>\n"
                + "<p>4. Remarks: " + rfq.getString("description_longdescription") + "</p>\n"
                //Start of VO - Comm-IT ----- Maximo 7.6 Change
                //+ "<p>5. Please email OR fax your quotations to : "
                + "<p>5. For eRFQ user, please submit quotations via eRFQ system; For non-eRFQ user, please email OR fax quotations to : "
                //End of VO - Comm-IT ----- Maximo 7.6 Change
                + rfqcreator.getString("displayname") + "</p>\n" + "<br><p>Thank you.</p>\n"
                + "<p>Yours faithfully,</p>\n" + "<p>" + rfqcreator.getString("displayname") + "</p>\n"
                + "<p>This is a computer-generated document.<br>No signature is necessary.</p>\n"
                + "</body></html>\n";
return buffer;
}

/*
* Builds the end of the document for Brief Fax/Email template
*/
private String buildBriefFooter(PersonRemote rfqcreator)
        throws MXException, RemoteException
{
GregorianCalendar closingdate = new GregorianCalendar();
closingdate.setTime(rfq.getDate("closeondate"));
//Start of EMS-561
String buffer = "<p>2. The closing date of the quotation is: " + convertDateToText(closingdate) + " at 2359 hours.</p>\n";
//End of EMS-561
closingdate.add(Calendar.DATE, 30);
buffer = buffer + "<p>3. Validity is: " + convertDateToText(closingdate) + "</p>\n"
                + "<p>4. Please submit your quotations by completing the eRFQ at the online system.. "
                + "</p>\n" + "<br><p>Thank you.</p>\n"
                + "<p>Yours faithfully,</p>\n" + "<p>" + rfqcreator.getString("displayname") + "</p>\n"
                + "<p>This is a computer-generated document.<br>No signature is necessary.</p>\n"
                + "</body></html>\n";
return buffer;
}


/*
* Converts a date to a string in the format specified by DATEFORMAT
*/
private String convertDateToText(GregorianCalendar date)
{
SimpleDateFormat dateformat = new SimpleDateFormat(DATEFORMAT);
return dateformat.format(date.getTime());
}


/*
* Read the configuration file (path hard-coded, no choice)
*/
private void readConfigFile()
        throws IOException
{
	BufferedReader reader = new BufferedReader(new FileReader(CFGFILE));
	for(String line; (line = reader.readLine()) != null; )
	{
	        StringTokenizer tok = new StringTokenizer(line.trim(), "=");
	        String parameter        = tok.nextToken().trim();
	        String value            = tok.nextToken().trim();
	        if (parameter.equalsIgnoreCase("FROM"))
	                FROM                            = value;
	        else if (parameter.equalsIgnoreCase("UMSEMAIL"))
	                UMSEMAIL                        = value;
	        else if (parameter.equalsIgnoreCase("SUBJECT"))
	                SUBJECT                 = value;
	        else if (parameter.equalsIgnoreCase("EMAILBODY"))
	                EMAILBODY               = value;
	        else if (parameter.equalsIgnoreCase("NODATA"))
	                NODATA                  = value;
	        else if (parameter.equalsIgnoreCase("DATEFORMAT"))
	                DATEFORMAT              = value;
	        else if (parameter.equalsIgnoreCase("FONTSTYLE"))
	                FONTSTYLE               = value;
	        else if (parameter.equalsIgnoreCase("ATTACHMENTEXT"))
	                ATTACHMENTEXT   = value;
	        // Ignore any other parameter
	}
}


private MboRemote               rfq;
private static String   FROM;
private static String   UMSEMAIL;
private static String   SUBJECT;
private static String   EMAILBODY;
private static String   NODATA;
private static String   DATEFORMAT;
private static String   FONTSTYLE;
private static String   ATTACHMENTEXT;
private static final MXLogger   mxLogger        = MXLoggerFactory.getLogger("maximo.application.RFQ");
private static final String             CFGFILE = "/opt/psa/rel/config/ums/cfg/fax.cfg";
}
