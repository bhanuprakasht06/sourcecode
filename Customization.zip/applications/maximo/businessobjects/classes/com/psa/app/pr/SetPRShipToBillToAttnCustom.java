package com.psa.app.pr;

import java.rmi.RemoteException;
import psdi.common.action.ActionCustomClass;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.util.MXException;


public class SetPRShipToBillToAttnCustom
implements ActionCustomClass
{

public SetPRShipToBillToAttnCustom()
{
}


public void applyCustomAction(MboRemote mboremote, Object param[])
	throws MXException, RemoteException
{
MboSetRemote prlineset = mboremote.getMboSet("PRLINE");
MboRemote prline = prlineset.getMbo(0);
MboSetRemote woset = prline.getMboSet("WORKORDER");
MboRemote wo = woset.getMbo(0);


if(wo.getString("DPBUYER").equals(""))
{
	mboremote.setValue("SHIPTOATTN",wo.getString("PRAPPROVEDBY"));
	mboremote.setValue("BILLTOATTN",wo.getString("PRAPPROVEDBY"));
}
else
{
	mboremote.setValue("SHIPTOATTN",wo.getString("DPBUYER"));
	mboremote.setValue("BILLTOATTN",wo.getString("DPBUYER"));
}
}
}
