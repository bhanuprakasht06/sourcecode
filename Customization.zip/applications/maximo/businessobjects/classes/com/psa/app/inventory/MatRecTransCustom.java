/*
 * Modification history
 * 06-10-06     HCHA                            Creation
 * 05-04-07     AGD     SR-075  Disallow receiving items that are not in condition NEW
 * 11-04-07     AGD     SR-030  Disallow transactions at cost>0 for project with no more budget
 * 28-06-07     LS              DR-035  Check for conditioncode NEW for Receipt of Items Only
 * 03-08-07     AGD     SR-092  Send email if LD (per save transaction)
 * 16-08-07     AGD     SR-098  Prevent duplicate packing slips
 *                                                              Propose users to auto-accept inspections
 *                                                              Prevent users from receipting in a store that's not theirs
 * 01-10-07     AGD     SR-116  Validate vendor before saving or approving
 * 25-10-07     AGD     DR-053  Problem saving service receipt with same DO as material receipt, which can be normal
 * 29-10-07     AGD     eRFQ            Change LD field from REMARK to LDCOMMENT
 * 12-12-07     AGD     DR-058  When auto-approving, both receipt and transfer are sent to GFS instead of just transfer
 * 19-09-14     WMJ     EMS-845 Prevent multiple super.saves when doing transfers
 * 25-09-15 	DES  	EMS-958 Recon status for some transactions cannot be updated due to LD Import and Labor Overlap prompts
 * 01-03-18		Comm-IT	Batch Tracking
 * 25-06-18		DES		EMS-1376: Auto-populate LD Comments for POs that are LD Applicable (for email alert see Automation Script)
 * 02-07-18		DES		EMS-1381: Send alert emails for LD Applicable receipts consolidated at PO level for that transaction  (Automation Script NO longer in use)
 */
package com.psa.app.inventory;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import javax.mail.MessagingException;

import java.lang.String;
import java.text.SimpleDateFormat;

import com.psa.app.common.FinancialTransaction;
import com.psa.app.common.VendorCheckCustom;
import com.psa.app.common.receipt.ReceiptMboCustom;
import com.psa.app.po.POCustom;
import com.psa.app.po.POSetCustom;

import psdi.app.inventory.InvCost;
import psdi.app.inventory.Inventory;
import psdi.app.inventory.InventoryRemote;
import psdi.app.inventory.MatRecTrans;
import psdi.app.inventory.MatRecTransRemote;
import psdi.app.inventory.MatRecTransSet;
import psdi.app.inventory.MatRecTransSetRemote;
import psdi.app.location.LocationRemote;
import psdi.app.po.POLineRemote;
import psdi.app.po.POLineSetRemote;
import psdi.app.po.PORemote;
import psdi.common.commtmplt.CommTemplateRemote;
import psdi.common.commtmplt.CommTemplateSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSet;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXApplicationWarningException;
import psdi.util.MXApplicationYesNoCancelException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class MatRecTransCustom extends MatRecTrans
        implements MatRecTransRemote
{

    MboSetRemote venDatematRecTransSet=null;
    protected static final MXLogger logger = MXLoggerFactory.getLogger("maximo.application.RECEIPTS"); // Added logging for EMS-1376, Desmond
    protected static final String LOGKEY = " >>>>>>>> "; // Added logging for EMS-1376, Desmond
    
    private boolean isProcessed = false; 	// Added for EMS-1381, Desmond
    private boolean toEmail = false; 		// Added for EMS-1381, Desmond
        
	public MatRecTransCustom(MboSet thismboset)
                throws MXException, RemoteException
    {
                super(thismboset);
                //  Begin modification SR-030
        myset = thismboset;
                //  End modification SR-030
                //  Begin modification SR-098
        alreadysaved = false;
                //  End modification SR-098

                flag=true;
                lastItem=null;
                venDatematRecTransSet=thismboset;
                
                setIsProcessed(false);	// Added for EMS-1381, Desmond
                setToEmail(false);		// Added for EMS-1381, Desmond

    }
	
	// Added for EMS-1381, Desmond
	public boolean getIsProcessed() {
		return isProcessed;
	}


	// Added for EMS-1381, Desmond
	public void setIsProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	// Added for EMS-1381, Desmond
	public boolean getToEmail() {
		return toEmail;
	}

	// Added for EMS-1381, Desmond
	public void setToEmail(boolean toEmail) {
		this.toEmail = toEmail;
	}

	//++COMM-IT - Batch Tracking Customization

	protected void copyMatRecTransToMatRecTrans(MatRecTransRemote matrec, String issueType) 
			throws MXException, RemoteException
	{
		super.copyMatRecTransToMatRecTrans(matrec, issueType);
		if (issueType.equalsIgnoreCase("TRANSFER"))
		{
			matrec.setValue("batchnum", getString("batchnum"), 11L);
		}		
	}
	
	//--COMM-IT - Batch Tracking Customization

    public void updateInventory(InventoryRemote inventoryremote, PORemote poremote, InvCost invcost)
        throws MXException, RemoteException
    {
    	System.out.println("---updateInventory----MatRecTransCustom---------inside------------------");
    
        if(inventoryremote == null)
            return;


        double curBalanceTotal = inventoryremote.getCurrentBalance(null,null,getString("conditioncode"))+ ((InvCostCustom)invcost).getAccumulativeReceiptQty();
        double curAvgCost = invcost.getDouble("avgcost");

       

                /*
                System.out.println("[MatRecTransCustomSet.updateInventory]Bef AvgCost:"+curAvgCost);
                System.out.println("[MatRecTransCustomSet.updateInventory]Bef CurBalTotal:" + curBalanceTotal);
                System.out.println("[MatRecTransCustomSet.updateInventory]Exchange Rate:"+getDouble("exchangerate"));
                System.out.println("[MatRecTransCustomSet.updateInventory]Quantity:"+getDouble("quantity"));
                System.out.println("[MatRecTransCustomSet.updateInventory]Unit Cost:"+getDouble("unitcost"));
                System.out.println("[MatRecTransCustomSet.updateInventory]Line Cost:"+getDouble("linecost"));
                System.out.println("[MatRecTransCustomSet.updateInventory]Loaded Cost:"+getDouble("loadedcost"));
                */

        super.updateInventory(inventoryremote, poremote, invcost);

        double newAvgCost = invcost.getDouble("avgcost");
        //Round up to 2 decimal places
        double newAvgCostRnd = Math.round(newAvgCost*100.0)/100.0;
        double newBalTotal = curBalanceTotal + getDouble("quantity");

        //Set the rounded AvgCost into InvCost
        //=> will enable consistant rounding error for muiltiple line receipts
        //=> if not, the unrounded avgcost will be used to calculate the 2nd receipt line
        invcost.setValue("avgcost", newAvgCostRnd, 2L);

        //Rounding Error = New Total Balance * (New Avg Cost Rounded - New Avg Cost Not Rounded)
        // +ve => rounding error increases the store value (with comparison to the actual store value)
        // -ve => rounding error decreases the store value (with comparison to the actual store value)
        double roundingErr = newBalTotal* (newAvgCostRnd - newAvgCost);

        //Another Method of Calculation (not used)
        //Compute difference btw change of store value due to this transaction and the loaded cost of this transaction
        //double storeVariance = (newBalTotal*newAvgCostRnd)-(curBalanceTotal*curAvgCost)-getDouble("loadedcost");

        setValue("oldavgcost",curAvgCost, 11L);
        setValue("newavgcost",newAvgCost, 11L);
        setValue("oldtotalbal",curBalanceTotal, 11L);
        setValue("roundingerr",roundingErr, 11L);

        /*
		System.out.println("[MatRecTransCustomSet.updateInventory]After AvgCost:"+ newAvgCostRnd + "("+newAvgCost+")");
		System.out.println("[MatRecTransCustomSet.updateInventory]After New Bal Total:"+newBalTotal);
		System.out.println("[MatRecTransCustomSet.updateInventory]Rounding Error:"+roundingErr);
		//System.out.println("[MatRecTransCustomSet.updateInventory]Storeroom Variance:"+storeVariance);
        */
        
        //++COMM-IT - Batch Tracking Customization
        
         MboRemote owner =getOwner();
        String name = owner.getName();
		String linetype = getString("LINETYPE");
		String issuetype = getString("ISSUETYPE");
		String status = getString("STATUS");
		String condcode = getString("CONDITIONCODE");
		if ((owner != null)	&& (name.equals("PO")) && ("ITEM".equalsIgnoreCase(linetype)) 
				&& (("RECEIPT".equalsIgnoreCase(issuetype)) && ("COMP".equalsIgnoreCase(status))) 
				|| (("TRANSFER".equalsIgnoreCase(issuetype)) && ("COMP".equalsIgnoreCase(status)) && ("NEW".equalsIgnoreCase(condcode))))
        {
			String itemnum = getString("ITEMNUM");
			String location = getString("TOSTORELOC");
			String binnum = getString("TOBIN");
        	MboSetRemote InvBatchSetRemote = getMboSet("$invBatch","INVBATCH","itemnum='" +itemnum+ "' and LOCATION='" +location+ "' and binnum='" +binnum+ "'");
        	MboRemote InvBatchRemote = InvBatchSetRemote.add();
        	InvBatchRemote.setValue("ITEMNUM", itemnum, 2L);
        	InvBatchRemote.setValue("LOCATION", location, 2L);
        	InvBatchRemote.setValue("LOTNUM", getString("TOLOT"), 2L);
        	InvBatchRemote.setValue("SITEID", getString("FROMSITEID"), 2L);
        	InvBatchRemote.setValue("BATCHNUM", getString("batchnum"), 2L);
        	InvBatchRemote.setValue("BATCHDATE", getDate("ACTUALDATE"), 2L);
        	InvBatchRemote.setValue("BINNUM", binnum, 2L);
        	InvBatchRemote.setValue("CONDITIONCODE", getString("CONDITIONCODE"), 2L);
        	InvBatchRemote.setValue("CURBAL", getDouble("RECEIPTQUANTITY"), 2L);  
        }
		
		if ((owner != null)	&& (name.equals("PO")) && ("ITEM".equalsIgnoreCase(linetype)) 
				&& ("RETURN".equalsIgnoreCase(issuetype)) && ("COMP".equalsIgnoreCase(status)))
        {
			String itemnum = getString("ITEMNUM");
			String location = getString("TOSTORELOC");
			String binnum = getString("TOBIN");
			String batch = getString("BATCHNUM");
        	MboSetRemote InvBatchReturnSetRemote = getMboSet("$invBatch","INVBATCH","itemnum='" +itemnum+ "' and LOCATION='" +location+ "' and binnum='" +binnum+ "' and batchnum='" +batch+ "'");
        	if (!InvBatchReturnSetRemote.isEmpty())
        	{
        		MboRemote InvBatchReturnRemote = InvBatchReturnSetRemote.getMbo(0);
        		double curbal = InvBatchReturnRemote.getDouble("CURBAL");
        		double newBalance = curbal-Math.abs(getDouble("RECEIPTQUANTITY"));
        		if (newBalance <0)
        			throw new MXApplicationException("matrectrans", "cannotReturnAsNotEnoughtQty");
        		InvBatchReturnRemote.setValue("CURBAL", InvBatchReturnRemote.getDouble("CURBAL")-Math.abs(getDouble("RECEIPTQUANTITY")),2L);
        	}        	   	
        }
		//--COMM-IT - Batch Tracking Customization
    
    }
    
    private boolean isActualDateGreater(MboRemote mbo) throws RemoteException, MXException
    {
            Date actualDate = mbo.getDate("ACTUALDATE");
            Date  vendorDate = mbo.getDate("POLINEREV.VENDELIVERYDATE"); // EMS-1381: Changed from POLINE to POLINEREV to handle PO revisions, Desmond 
            
            logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreater(mbo)").append(LOGKEY).append("vendorDate: ").append(vendorDate).toString());
			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreater(mbo)").append(LOGKEY).append("actualDate: ").append(actualDate).toString());
            
            if((actualDate==null)||(vendorDate==null))
            {
                    return false;
            }
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            Date matTransDate = null;
            Date venDate=null;
            try {
                    String newActual=sdf.format(actualDate);
                    matTransDate = sdf.parse(newActual);
                    if (vendorDate != null) {
                            String newVendor=sdf.format(vendorDate);
                            venDate=sdf.parse(newVendor);
                    }

            }catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
            }
            
            logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreater(mbo)").append(LOGKEY).append("venDate: ").append(venDate).toString());
			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreater(mbo)").append(LOGKEY).append("matTransDate: ").append(matTransDate).toString());
			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreater(mbo)").append(LOGKEY).append("LDCOMMENT: ").append(mbo.getString("LDCOMMENT")).toString());
            
            //removed by WMJ
            //only return true if transdate is after receipt date and no LD comments were entered.
            //return matTransDate.after(venDate);
            if( matTransDate.after(venDate) ) 
            {
	            if( mbo.getString("LDCOMMENT") == null || mbo.getString("LDCOMMENT").length() == 0 )
                {
	                return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
	            return false;
            }

    }


	/**
	 * Function for to check that Actual Date is AFTER Vendor Date, REGARDLESS OF LD COMMENT
	 * 
	 * @param mbo Mbo to compare Actual Date and Vendor Date for
	 * 
	 * @author	DES
	 * @since   02/07/2018
	 */
    private boolean isActualDateGreaterIgnoreLD(MboRemote mbo) throws RemoteException, MXException
    {
            Date actualDate = mbo.getDate("ACTUALDATE");
            Date  vendorDate = mbo.getDate("POLINEREV.VENDELIVERYDATE"); // EMS-1381: Changed from POLINE to POLINEREV to handle PO revisions, Desmond s
            
            logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("vendorDate: ").append(vendorDate).toString());
			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("actualDate: ").append(actualDate).toString());
            
            if((actualDate==null)||(vendorDate==null))
            {
                    return false;
            }
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            Date matTransDate = null;
            Date venDate=null;
            try {
                    String newActual=sdf.format(actualDate);
                    matTransDate = sdf.parse(newActual);
                    if (vendorDate != null) {
                            String newVendor=sdf.format(vendorDate);
                            venDate=sdf.parse(newVendor);
                    }

            }catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
            }
            
            logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("venDate: ").append(venDate).toString());
			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("matTransDate: ").append(matTransDate).toString());
			logger.debug((new StringBuilder(String.valueOf(getName()))).append(".isActualDateGreaterIgnoreLD(mbo)").append(LOGKEY).append("LDCOMMENT: ").append(mbo.getString("LDCOMMENT")).toString());
            
			return matTransDate.after(venDate);
            	
    }  

		//start of EMS-958
		/*
		 * Function for checking if Current User is in the specified group, used by save().
		 * Returns true if Current User is in the specified group, false if otherwise
		 *
		 */
		public boolean isCurrUserInGrp(String grp)
						throws MXException, RemoteException
		{
			
			boolean currUserIsInGrp = false;
			
			MboSetRemote groupset = MXServer.getMXServer().getMboSet("GROUPUSER", getUserInfo());
			SqlFormat sql2 = new SqlFormat("GROUPNAME ='"+grp+"'");
			groupset.setWhere(sql2.format());
			String currentuser = getUserName();

			int i=0;

			//Check if the user belongs to target group
			for(MboRemote user = null; (user = groupset.getMbo(i)) != null; i++) {
				if(user.getString("USERID").equalsIgnoreCase(currentuser)) currUserIsInGrp =true;
			}
			
			return currUserIsInGrp;

		}
		//end of EMS-958
	
		//START of EMS-1381, Desmond
		/**
		 * Function for sending LD alert emails
		 * 
		 * @author	DES
		 * @since   02/07/2018
		 */
	    private void sendLDEmail() throws RemoteException, MXException
        {
	    	
	    	// Do NOT run this if no PO (e.g. transfers)
	    	if(this.getMboSet("PO") == null || this.getMboSet("PO").isEmpty()) return;
	    	
	    	MboRemote po = this.getMboSet("PO").getMbo(0);
// Start of EMS-1391, Desmond
	    	String vendor ="";
	    	String vendorid="";
	    	
	    	if(po.getMboSet("VENDOR") == null || po.getMboSet("VENDOR").isEmpty()) {
	    		
	    		logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("PO: ").append(po.getString("PONUM")).append(" has NO Vendor").toString());
	    		
	    	} else  {
	    		
	    		if (po.getMboSet("VENDOR").count() > 1) {
	    			logger.error((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("PO: ").append(po.getString("PONUM")).append(" has MORE THAN 1 VENDOR!!!").toString());
	    		}
	    		
	    		vendor = po.getMboSet("VENDOR").getMbo(0).getString("NAME");
	    		vendorid = po.getMboSet("VENDOR").getMbo(0).getString("COMPANY");
    		
	    	}
	    	
	    	logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("PO: ").append(po.getString("PONUM")).
	    			append(" VENDOR: ").append(vendor).append(" (").append(vendorid).append(")").toString());
// End of EMS-1391, Desmond
	
	    	// Prevent sending of emails by MAXADMIN and Cron Tasks, skip for cases where PO is no LD Applicable
	    	if( isCurrUserInGrp("MAXADMIN") || !po.getBoolean("LDAPPLICABLE") ) return;
	    	
	    	String lineList="";	
	    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

	    	try {
	    	
				// Loop through all matrectrans to prepare email content if required
				for(int i=0;i<venDatematRecTransSet.count();i++)
				{
					MboRemote matRecTransRemote=venDatematRecTransSet.getMbo(i);
					
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("PO: ").append(matRecTransRemote.getString("PONUM")).
							append(" POLINE: ").append(matRecTransRemote.getString("POLINENUM")).append(" IssueType: ").append(matRecTransRemote.getString("ISSUETYPE")).
							append(" LD Comment: ").append(matRecTransRemote.getString("LDCOMMENT")).toString());
					
					// For receipts only
					if(matRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase("RECEIPT")& !matRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase(""))
					{
						// For Is newly added and Actual Date is AFTER Vendor Date, REGARDLESS OF LD COMMENT
						if(matRecTransRemote.toBeAdded()&&isActualDateGreaterIgnoreLD(matRecTransRemote))
						{                							
							logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("Adding line details ...").toString());
							
							// Add line details to email
							lineList = lineList+"Line: "+matRecTransRemote.getString("POLINENUM")+"<ul>"+
										"<li>Item No./Line Desc: "+matRecTransRemote.getString("ITEMNUM")+" / "+matRecTransRemote.getString("DESCRIPTION")+"</li>"+
										"<li>Vendor Date: "+sdf.format(matRecTransRemote.getDate("POLINEREV.VENDELIVERYDATE"))+"</li>"+
										"<li>Actual Date: "+sdf.format(matRecTransRemote.getDate("ACTUALDATE"))+"</li>"+
										"<li>Rcpt Qty: "+matRecTransRemote.getDouble("RECEIPTQUANTITY")+"</li>"+
										"</ul>";
						}
					}
						                					
				}
				
				if( lineList == null || lineList.length() == 0 ) {
					
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("NO EMAIL TO SEND !!!!!").toString());
					
				} else {
				
					// Get WO linked to the receipt (each PO can only be linked to 1 WO)
					MboSetRemote woSet = venDatematRecTransSet.getMbo(0).getMboSet("WORKORDER");
					
					String templateName="WORCPTLD"; // Default to WO Level Email
					
					String ponum = po.getString("PONUM");
					String wonum ="";
					
					MboRemote srcMbo;
					
					// Decide template based on whether wonum is null
					if(woSet.isEmpty() || woSet == null) {
						
						// NO linked WO, send PO level email
						logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("NO WO, preparing PO Level email ...").toString());
						
		    			templateName="PORCPTLD"; // Switch to PO level template 
		    			srcMbo = po;
						
					} else {
						
						// Send WO level email
						
						srcMbo = woSet.getMbo(0);
						wonum = srcMbo.getString("WONUM");
						
						logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("WO (").append(wonum).
								append(") exists, preparing WO Level email ...").toString());
						
					}
		    		
			    	// Get relevant comm template 
			    	CommTemplateSetRemote commTemplateSet=(CommTemplateSetRemote) MXServer.getMXServer().getMboSet("COMMTEMPLATE", MXServer.getMXServer().getUserInfo("MAXADMIN"));
					commTemplateSet.setWhere("TEMPLATEID='"+templateName+"'");
					commTemplateSet.reset();
					CommTemplateRemote tempRemote=(CommTemplateRemote) commTemplateSet.getMbo(0);
					
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).
							append("Sending email using Template (").append(tempRemote.getString("TEMPLATEID")).append(") ...").toString());

					// Copy email details from Comm Template
					String toMail=tempRemote.getString("TOLIST");
					String fromMail=tempRemote.getString("SENDFROM");
					String ccTo=tempRemote.getString("CCLIST");
					String bccTo=tempRemote.getString("BCCLIST");
					String subject=tempRemote.getString("SUBJECT");
					String message=tempRemote.getString("MESSAGE");
					String replyTo=tempRemote.getString("REPLYTO");
					
					// Update Subject
					subject = subject.replace("#WONUM", wonum).replace("#PONUM", ponum).replace("#VENDORNAME", vendor).replace("#VENDORID", vendorid); // Added vendor details for EMS-1391, Desmond
					
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("SUBJECT: ").append(subject).toString());
									
					// Update Message content
					message =message.replace("#WONUM", wonum).replace("#PONUM", ponum).replace("#VENDORNAME", vendor).replace("#VENDORID", vendorid).replace("#LINEDETAILS", lineList); // Added vendor details for EMS-1391, Desmond
					
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("MSG: ").append(message).toString());
					
					// Convert recipient list to email addresses
					toMail=tempRemote.convertSendTo("COMMTMPLT_TO", srcMbo);
					ccTo=tempRemote.convertSendTo("COMMTMPLT_CC", srcMbo);
					bccTo=tempRemote.convertSendTo("COMMTMPLT_BCC", srcMbo);
								
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("TO: ").append(toMail).toString());
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("CC: ").append(ccTo).toString());
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("BCC: ").append(bccTo).toString());
					
					MXServer.sendEMail(toMail, ccTo, bccTo, fromMail, subject, message, replyTo, null, null);
					
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".sendLDEmail()").append(LOGKEY).append("After sending email").toString());
				
				}

				
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
        } // END of EMS-1381, Desmond	

        // SR-075
        public void save()
        		throws MXException, RemoteException
        {
        	
        	// Starts Checking the vendor delivery date
	        	if(getString("ISSUETYPE").equalsIgnoreCase("RECEIPT")& !getString("ISSUETYPE").equalsIgnoreCase(""))
                {
	                //Added by WMJ to call vendor date check only if PO for receipt is LD applicable
	                MboSetRemote poset = this.getMboSet("PO");
	                
	                logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("LDAPPLICABLE: ").append(poset.getMbo(0).getBoolean("LDAPPLICABLE")).toString());
	                logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("USER ID: ").append(getUserName()).toString());
	                
	                if(poset.getMbo(0).getBoolean("LDAPPLICABLE"))
	                {
		                if(!isCurrUserInGrp("MAXADMIN") && isActualDateGreater(this))
	                	{ // EMS-958: Add criteria to skip LD import check for users in MAXADMIN group, Desmond
	                		
	                		// START - EMS-1376: Auto-populate LD Comments for POs that are LD Applicable (for email alert see Automation Script), Desmond
		                	logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> START AUTO POPULATE LD COMMENT").toString());
	                		
	                		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); // Added for EMS-1376, Desmond

            				//String[] params = new String[ 1 ];
            				
            				boolean hasAutoPopulated = false;
            				
            				// Loop through all receipts
            				for(int i=0;i<venDatematRecTransSet.count();i++)
            				{
            					MboRemote matRecTransRemote=venDatematRecTransSet.getMbo(i);
            					
            					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("POLINE: ").
            							append(matRecTransRemote.getString("POLINENUM")).append(" LD Comment: ").append(matRecTransRemote.getString("LDCOMMENT")).toString());
            					
            					if(matRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase("RECEIPT")& !matRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase(""))
            					{
            						if(matRecTransRemote.toBeAdded()&&isActualDateGreater(matRecTransRemote))
            						{                							
            							matRecTransRemote.setValue("LDCOMMENT", "LD TO IMPOSE ACTUAL RECEIPT "+sdf.format(matRecTransRemote.getDate("ACTUALDATE")), NOACCESSCHECK);
            							//params[0] = matRecTransRemote.getString("LDCOMMENT");
            							//logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("UPDATED LD COMMENT: ").append(params[0]).toString());
            							hasAutoPopulated = true;
            						}
            					}
            						                					
            				}
            				
            				
            				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("After looping through all receipts").toString());
            				
            				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("hasAutoPopulated = ").append(hasAutoPopulated).toString());
            				
            				// Prompt user if at least 1 line was auto populated
            				if(hasAutoPopulated) {
            					String[] params = {"LD TO IMPOSE ACTUAL RECEIPT <ACTUAL DATE>"};
            					this.getThisMboSet().addWarning(new MXApplicationException("matrectrans", "AutoSetLDcomments",params));
            				}
	                		
            				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> END AUTO POPULATE LD COMMENT").toString());
// START of EMS-1381, Desmond
	                		// END - EMS-1376: Auto-populate LD Comments for POs that are LD Applicable (for email alert see Automation Script), Desmond
	                		
	                		/* START - Removed for EMS-1376, Desmond
	                		int userInput = MXApplicationYesNoCancelException.getUserInput("Vendordate", MXServer.getMXServer(), getUserInfo());
	                		switch(userInput)
	                		{
	                			case -1:

	                				String lineList="\n";
	                				for(int i=0;i<venDatematRecTransSet.count();i++)
	                				{
	                					MboRemote matRecTransRemote=venDatematRecTransSet.getMbo(i);
	                					if(matRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase("RECEIPT")& !matRecTransRemote.getString("ISSUETYPE").equalsIgnoreCase(""))
	                					{
	                						if(matRecTransRemote.toBeAdded()&&isActualDateGreater(matRecTransRemote))
	                						{
	                							lineList=lineList+"Line : "+matRecTransRemote.getString("POLINENUM")+"\n";
	                						}
	                					}
	                				}

	                				String[] warning={ lineList };
	                				throw new MXApplicationYesNoCancelException("Vendordate","matrectrans", "Vendordate",warning);
	                			case 8: 
									break;

								case 4: 	
									throw new MXApplicationException("messagebox", "MSG_BTNCANCEL");
	                		}
	                		*/ // END - Removed for EMS-1376, Desmond
	                	}
					}//End of Added by WMJ to call vendor date check only if PO for receipt is LD applicable
                }

	        
	        
                mbosetremote = getThisMboSet();

                //Start of Prevention of Transfer of different condition code

                if(getString("ISSUETYPE").equals("TRANSFER") && !toBeDeleted() && !getString("FROMCONDITIONCODE").equals(getString("CONDITIONCODE")))
                {
                        throw new MXApplicationException("inventory", "transDiffCondCode");
                }

                //End of Prevention of Transfer of different condition code



                // Bug Fix for negative curbal transfer

                //Initialise variables
                int[] trans = new int[5];
                int sum = 0;
                MatRecTrans matrectrans3= null;
                boolean nottransfer = false;

                // boolean retmorethanbal = false;//new boolean for bug fix PO return
                Inventory retinventory = null;//MBO to retrieve curbal in inventory of lot and bin
                double curbalinlot = 0;//variable to store current balance of item in lot
                double retqty=0;//variable to store total return quantity
                MatRecTrans matrectrans4= null;//2nd mbo for matrectrans to check if return mbos have the same lot

                //System.out.println("=============================Print out for Before for loop of Bug Fix===============================");
                for (int i = 0; (matrectrans3 = (MatRecTrans) mbosetremote.getMbo(i)) != null; i++)
                {

                        //Initialise variables
                        curbalinlot = 0;//variable to store current balance of item in lot
                        retqty=0;//variable to store total return quantity



                        //new bug fix PO return
                        if(matrectrans3.getString("ISSUETYPE").equals("RETURN") && !matrectrans3.toBeDeleted() && matrectrans3.getString("LINETYPE").equals("ITEM") && matrectrans3.toBeSaved() && matrectrans3.isNew() && !matrectrans3.getBoolean("ISSUE"))
                        {
                                retqty = retqty + matrectrans3.getDouble("QUANTITY");//to get return qty for 1st return
                                //++COMM-IT Added site id to getSharedInventory to make it compatible with Maximo 7 and to ensure best practices
                                retinventory = (Inventory)getSharedInventory(getString("TOSTORELOC"), getString("SITEID"));
                                //--COMM-IT Added site id to getSharedInventory to make it compatible with Maximo 7 and to ensure best practices
                                if(retinventory != null)
                                {
                                        curbalinlot = retinventory.getCurrentBalance(getString("TOBIN"),getString("TOLOT"),getString("conditioncode"));
                                }

                                //System.out.println("Matrectransid for 1st MBO:"+matrectrans3.getInt("matrectransid"));

                                //System.out.println("=============================2nd for loop for check for other mbo with returns in same bin and lot===============================");
                                for (int j = 0; (matrectrans4 = (MatRecTrans) mbosetremote.getMbo(j)) != null; j++)
                                {
                                        if(matrectrans4.getString("ISSUETYPE").equals("RETURN") && !matrectrans4.toBeDeleted() && matrectrans4.getString("LINETYPE").equals("ITEM") && matrectrans4.toBeSaved() && matrectrans4.isNew() && !matrectrans4.getBoolean("ISSUE"))
                                        {
                                                if((matrectrans3.getInt("matrectransid") != matrectrans4.getInt("matrectransid")) && (matrectrans3.getString("TOSTORELOC") == matrectrans4.getString("TOSTORELOC")) && (matrectrans3.getString("TOBIN").equals(matrectrans4.getString("TOBIN"))) && (matrectrans3.getString("TOLOT").equals(matrectrans4.getString("TOLOT"))))
                                                {
                                                        //System.out.println("=============================Calculate total return quantity===============================");
                                                        retqty = retqty + matrectrans4.getDouble("QUANTITY");
                                                        //System.out.println("Return Qty:"+retqty);
                                                }
                                        }

                                }


                                /*System.out.println("=============================check if ret qty greater than curbal===============================");
                                System.out.println("Qty of item in bin of store:"+curbalinlot);
                                System.out.println("Return Qty:"+retqty);
                                */
                                if((curbalinlot+retqty)<0)
                                {
                                        //System.out.println("Return more than balance in lot and bin");
                                        //retmorethanbal = true;
                                        throw new MXApplicationException("inventory", "insufficientQtyinBinLot");
                                }

                        }
                        //end new bug fix PO return

                        //System.out.println("=============================out of the if loop to check issuetype===============================");

                        if(!matrectrans3.getString("ISSUETYPE").equals("TRANSFER") && !matrectrans3.toBeDeleted())
                                nottransfer = true;

                        if(matrectrans3.getString("ISSUETYPE").equals("TRANSFER") && !matrectrans3.toBeDeleted())
                        {
                                if(matrectrans3.getString("FROMCONDITIONCODE").equals("NEW"))
                                {
                                        trans[0] = 1;
                                }
                                else if (matrectrans3.getString("FROMCONDITIONCODE").equals("RECOND"))
                                {
                                        trans[1] = 1;
                                }
                                else if (matrectrans3.getString("FROMCONDITIONCODE").equals("FOC"))
                                {
                                        trans[2] = 1;
                                }
                                else if (matrectrans3.getString("FROMCONDITIONCODE").equals("WRDOWN"))
                                {
                                        trans[3] = 1;
                                }
                                else
                                {
                                        trans[4] = 1;
                                }
                        }
                }

                sum = trans[0]+trans[1]+trans[2]+trans[3]+trans[4];

                if (!nottransfer && sum>1)
                {
                        throw new MXApplicationException("inventory", "diffCondCodeInTransfer");
                }
                //end Bug Fix

                if(lastItem == null)
                        lastItem = mbosetremote.moveLast();

                MatRecTrans matrectrans= null;
                MatRecTrans matrectrans2= null;

                System.out.println("=======================================================PO Line "+getLong("polinenum")+" : "+getString("itemnum")+" ----  Current Item : "+this.getLong("polinenum")+" And Last Item Id : "+lastItem.getUniqueIDValue()+"=====");
                // Start of Modification DR-035
                if(getString("ISSUETYPE").equals("RECEIPT") && getString("LINETYPE").equals("ITEM"))
                {
                        // End of Modification DR-035
                        MboRemote itemcondition = getMboSet("itemcondition").getMbo(0);
                        if (itemcondition != null && itemcondition.getLong("condrate") != 100)
                        {
                                MboRemote item = itemcondition.getMboSet("item").getMbo(0);
                                MboRemote itemfullcond = item.getMboSet("itemcondition_full").getMbo(0);
                                Object param[] = { itemfullcond.getString("conditioncode"), itemcondition.getString("itemnum") };
                                throw new MXApplicationException("inventory", "invalidCondCodeForReceipt", param);
                        }
                }

                //Begin modification SR-030
                if (getDouble("linecost") > 0)
                {
                                FinancialTransaction financialtransaction = new FinancialTransaction(myset);
                                financialtransaction.validateProject(this, "WORKORDER");
                }
                // End modification SR-030

                /*
                 * Begin modification SR-098
                 *  - Prevent duplicate packing slips
                 *  - Prevent users from receipting in a store that's not theirs
                 */
                ReceiptMboCustom receipt = new ReceiptMboCustom(myset);
                //Begin modification DR-053 - superfluous check.
                /*if (toBeAdded())
                        receipt.checkDuplicatePackingSlip(getMboValue("packingslipnum"), getString("po.vendor"));*/
                //End modification DR-053
                //Added by BCT during the OF recon process. As the save is called from cron task the woner is nul,so added if cluse to check null value
                MboRemote owner = getOwner();
                String appname = "";
                if (owner !=null) 
                {
                 appname = getOwner().getThisMboSet().getApp();
                }
                if (!isNull("tostoreloc") && appname != null && appname.equalsIgnoreCase("RECEIPTS"))
                {
                        // Check whether the location of the record is a holding location
                        LocationRemote receivingstore = (LocationRemote) getMboSet("LOCATIONS").getMbo(0);
                        if (receivingstore.isHolding())
                        {
                                // Get the final store from the PO line if it's not a direct issue
                                MboRemote poline = getMboSet("POLINE").getMbo(0);
                                if (!poline.isNull("storeloc"))
                                        checkStore(poline.getString("storeloc"));
                        }
                        else
                                checkStore(getString("tostoreloc"));
                }
                //End modification SR-098

                //Begin modification SR-116
                VendorCheckCustom.checkValidity(getString("po.vendor"), getString("orgid"), getUserInfo());
                //End modification SR-116

                //Begin modification SR-098 - Propose users to auto-accept inspections
/* Removed for EMS-845
                if (isInspectionRequired() && toBeAdded() && isReceipt() && !alreadysaved)//WMJ: new inspection receipt to be saved: save and call autoinspect
                {
                        super.save();
                        //++ COMM-IT Added to make it compatible with Maximo 7
                        //autoInspect();
                        //-- COMM-IT Added to make it compatible with Maximo 7
                }
                else if (!isInspectionRequired())       //WMJ: For matrectrans without PO: transfers
                {
                        flag=false;
                        for (int i = 0; (matrectrans = (MatRecTrans) mbosetremote.getMbo(i)) != null; i++)      //WMJ: For all matrectrans in save set
                        {
                                //++ COMM-IT Added to make it compatible with Maximo 7
                                //if(matrectrans.isInspectionRequired())
                                if(isInspectionRequired())      //WMJ: For matrectrans with PO: receipt, returns, find other matrec with same polinenum, if got other matrec, flag=0
                                //if(matrectrans.isInspectionRequired())
                                        //-- COMM-IT Added to make it compatible with Maximo 7
                                {
                                        int count=0;
                                        for(int j = 0; (matrectrans2 = (MatRecTrans) mbosetremote.getMbo(j)) != null; j++)
                                                if(matrectrans.getLong("polinenum") == matrectrans2.getLong("polinenum"))      // if not saved
                                                        count++;
                                        if(count < 2)
                                                flag = true;
                                }

                                if((this.getUniqueIDValue() != lastItem.getUniqueIDValue()) && flag)    //WMJ: if not last matrec in set and it is the only poline
                                {
                                                setofsave=true;
                                                return;
                                }
                                else    //WMJ: call super save for all other cases
                                super.save();
                        }
                }
 End of Removed for EMS-845 */
                //End modification SR-098

                //Begin modification SR-092
                /*
                 * Conditions to send an email:
                 *      LD remark input
                 *      PO is LD applicable
                 *      type is receipt
                 *      new entry: inspection saves again for status change but we don't want to send again an email
                 */
                //Begin modification eRFQ
                //              if (!isNull("remark") && getBoolean("po.ldapplicable") && isReceipt() && toBeAdded())
/* START - Removed email to buyer for EMS-1376, Desmond
                if (!isNull("ldcomment") && getBoolean("po.ldapplicable") && isReceipt() && toBeAdded())
                //End modification eRFQ
                {
                        //Begin modification SR-098
                        //ReceiptMboCustom receipt = new ReceiptMboCustom(myset);
                        //End modification SR-098
                        receipt.emailForLD(this);
                }
                //End modification SR-092
*/ // END - Removed email to buyer for EMS-1376, Desmond
/* Removed for EMS-845
                if((this.getUniqueIDValue() == lastItem.getUniqueIDValue()) && setofsave)       //WMJ:if it is last mbo and there is a mbo set to save.
                        for (int i = 0; (matrectrans = (MatRecTrans) mbosetremote.getMbo(i)) != null; i ++)
                                //++ COMM-IT Added to make it compatible with Maximo 7
                                //if(!matrectrans.isInspectionRequired())
                                if(!isInspectionRequired())
                                        //-- COMM-IT Added to make it compatible with Maximo 7
                                        matrectrans.save();
End of Removed for EMS-845 */
                
// START of EMS-1381, Desmond
                this.setIsProcessed(true); // Added for EMS-1381

                super.save();
                
                int total = 0;
                int processed = 0;
                
                // Count the number of transactions that have setIsProcess true
                MatRecTransCustom temp=null;
				for(int i=0; (temp= (MatRecTransCustom) venDatematRecTransSet.getMbo(i))!=null; i++)
				{
					if(temp.toBeAdded()) total++;			// Count only those that are to be added
				    if(temp.getIsProcessed()) processed++;	// Count only those that have been processed by this code
				}
				
				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("TOTAL: ").append(total).toString());
				logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("PROCESSED: ").append(processed).toString());
				
				// Is the last record to be processed, attempt to call method to send email
				if (total == processed) {
					
					logger.debug((new StringBuilder(String.valueOf(getName()))).append(".save()").append(LOGKEY).append("Attempting to call sendLDEmail() ").toString());
					sendLDEmail();
					
				}
// END of EMS-1381, Desmond
				
                /*MboSetRemote polineset = getMboSet("POLINE");
                MboRemote poline;
                if(this.getString("linetype").equals("RECEIPT"))
                                for(int i=0;(poline = polineset.getMbo(i)) != null;i++)
                                                if(this.getLong("polinenum") == poline.getLong("polinenum"))
                                                {
                                                                System.out.println("Updating Po.POLIne NO : "+poline.getLong("polinenum")+" with Receipt Qty : "+getDouble("receiptq uantity"));
                                                                poline.setValue("receivedqty",getDouble("receiptquantity"));
                                                }
                //polineset.save();*/

        }




        //Begin modification SR-116
        public void approve (Date date)
                throws MXException, RemoteException
        {
                VendorCheckCustom.checkValidity(getString("po.vendor"), getString("orgid"), getUserInfo());
                super.approve(date);
        }
        //End modification SR-116


        //Begin modification SR-098 - Propose users to auto-accept inspections
        /*
        * Propose users to auto-accept inspections
        * Note that since this method is called after the receipt is saved, we need to save manually again
        */
        private void autoInspect()
                throws MXException, RemoteException
        {
                int userInput = MXApplicationYesNoCancelException.getUserInput("wantToAutoApprove"+getString("polinenum"), MXServer.getMXServer(), getUserInfo());
                switch (userInput)
                {
                        case -1:
                                String param[] = { (new Long(getLong("polinenum"))).toString() };
                                throw new MXApplicationYesNoCancelException("wantToAutoApprove"+getString("polinenum"), "po", "autoapprovereceipt", param);

                        case 8:
                                // Approve the receipt
                                // to avoid an infinite saving loop
                                alreadysaved = true;
                                //Begin modification DR-058 - save also before approving to separate the 2 transactions
                                //getThisMboSet().save();
                                //End modification DR-058
                                setValue("acceptedqty", getDouble("receiptquantity"));
                                approve((Date) null);
                                ((MatRecTrans)this).save();
                                break;

                        case 16:
                                // Do nothing
                                break;
                }
        }


        // Prevent users from receipting in a store that's not theirs
        private void checkStore(String store)
                                        throws MXException, RemoteException
        {
                MboSetRemote users = MXServer.getMXServer().getMboSet("MAXUSER", getUserInfo());
                SqlFormat sql = new SqlFormat("userid=:1");
                sql.setObject(1, "maxuser", "userid", getUserName());
                users.setWhere(sql.format());
                MboRemote user = users.getMbo(0);
                // By-pass the check for system users. Required for interfaces as receipts from GFS are created by MXINTADM, not by an actual user
                if (user.getBoolean("sysuser"))
                        return;
                String defaultstore = user.getString("defstoreroom");
                users.close();
                if (!store.equals(defaultstore))
                        throw new MXApplicationException("po", "wrongstoreuser");
        }
        // End modification SR-098

    //++ COMM-IT added method to make it compatible with Maximo 7 API 
    public boolean isInspectionRequired()
        throws MXException, RemoteException
    {
        POLineRemote poLineMbo = getPOLine();
        if(poLineMbo != null)
            return poLineMbo.isInspectionRequired();
        else
            return false;
    }
    // -- COMM-IT added method to make it compatible with Maximo 7 API 

        // Begin modification SR-098
        private boolean alreadysaved;
        // End modification SR-098
        // Begin modification SR-030
        MboSet myset;
        // End modification SR-030

        private boolean flag;
        private boolean setofsave;
        MboSetRemote mbosetremote = null;
        MboRemote lastItem;
}
