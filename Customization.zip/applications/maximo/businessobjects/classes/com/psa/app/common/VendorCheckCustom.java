/*
 * Modification history
 * 10-Oct-2007		AGD	SR-116	Validate vendor. Common class used where vendor is entered (WO plan, PR, RFQ, PO, inventory
 */
package com.psa.app.common;

import java.rmi.RemoteException;

import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public abstract class VendorCheckCustom
{

	public static void checkValidity(String vendor, String orgid, UserInfo userinfo)
			throws RemoteException, MXException
	{
		if (vendor == null || vendor.equals(""))
			return;

		MboSetRemote recordset = MXServer.getMXServer().getMboSet("COMPANIES", userinfo);
		SqlFormat sql = new SqlFormat("company=:1 AND orgid=:2");
		sql.setObject(1, "companies", "company", vendor);
		sql.setObject(2, "companies", "orgid", orgid);
		recordset.setWhere(sql.format());
		checkValidity(recordset.getMbo(0));
	}


	public static void checkValidity(MboValue vendorfield, String relationship)
			throws RemoteException, MXException
	{
		checkValidity(vendorfield.getMbo(), relationship);
	}


	public static void checkValidity(Mbo record, String relationship)
			throws RemoteException, MXException
	{
		checkValidity(record.getMboSet(relationship).getMbo(0));
	}


	private static void checkValidity(MboRemote vendor)
			throws RemoteException, MXException
	{
		if (vendor == null)
			return;

		if (!vendor.getBoolean("oa_purchsite_flg") && !vendor.isNull("ownersysid"))
			throw new MXApplicationException("company", "InvalidCompany");
	}


	public static MboSetRemote getValidVendorList(MboRemote mbo)
			throws RemoteException, MXException
	{
		SqlFormat sqlformat = new SqlFormat("orgid=:1 AND disabled=0 AND (oa_purchsite_flg=1 OR ownersysid IS NULL)");
		String orgid = mbo.getString("orgid");
      if (mbo.isZombie())
			orgid = ((Mbo) mbo).getProfile().getDefaultOrg();
		sqlformat.setObject(1, "companies", "orgid", orgid);
		MboSetRemote vendorset = MXServer.getMXServer().getMboSet("COMPANIES", mbo.getUserInfo());
   	vendorset.setWhere(sqlformat.format());
   	vendorset.reset();
   	return vendorset;
	}

}
