/*
 * Modification history
 * 01-10-2007	AGD	SR-116	Check vendor validity upon approval
 */
package com.psa.app.pr;

import java.rmi.RemoteException;

import psdi.app.pr.PRSet;
import psdi.app.pr.PRSetRemote;
import psdi.mbo.Mbo;
import psdi.mbo.MboServerInterface;
import psdi.mbo.MboSet;
import psdi.util.MXException;


public class PRCustomSet extends PRSet
		implements PRSetRemote
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public PRCustomSet(MboServerInterface mboserverinterface)
			throws MXException, RemoteException
	{
		super(mboserverinterface);
	}


	protected Mbo getMboInstance(MboSet mboset)
			throws MXException, RemoteException
	{
		return new PRCustom(mboset);
	}

}
