/*
 * Modification history
 * 28-05-2007	AGD	SR-030	Enable project details fields and become compulsory when the work type is a "project work type"
 * 02-10-2020 BCT		Code updated as part of the Chart of Accounts restructure during NextGen Maximo implementation. Below is the account structure
             * 
             * ***********************************************************************************************************************************************
             * 						GLCOMP1		- GLCOMP2					-GLCOMP3	-GLCOMP4		-GLCOMP5	-GLCOMP6		-GLCOMP7		-GLCOMP8
             * ***********************************************************************************************************************************************
             * Old Account Format: Company (3)	- Main Acc (4)			 	-Type(1)	-LOB(2)		 	-InterCo(3) -Resp Center(4)	-Sub (4)		-Local (3)
             * New Account Format: Company (3)	- Main Acc (4)+ Sub Acc(3) 	-LOB(3)		-Resp Center(4) -InterCo(3) -Future1(4)		-Future2(4)     - NA  
			 ************************************************************************************************************************************************
 * 
 */
package com.psa.app.workorder;

import java.rmi.RemoteException;

import psdi.app.workorder.FldWorkType;
import com.psa.custom.common.MboConstantsCustom;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.MboValue;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;


public class FldWorkTypeCustom extends FldWorkType
{

	public FldWorkTypeCustom(MboValue mbovalue)
			throws MXException
	{
		super(mbovalue);
	}


	public void action()
			throws MXException, RemoteException
	{
		WOCustom wo = (WOCustom) getMboValue().getMbo();
		wo.setProjectFieldsFlags();

		/* Start of Modification - LS */
		/* PSSD_EAMS_IN_2010_013_Pre INCAS */
		//Start - Converted to Condition Expression in Maximo 7.6
		/*if(wo.getString("WORKTYPE").equals("ACI"))
			wo.setFieldFlag("INCASNUM", MboConstantsCustom.REQUIRED, true);
		else
			wo.setFieldFlag("INCASNUM", MboConstantsCustom.REQUIRED, false);*/		
		//End - Converted to Condition Expression in Maximo 7.6
		/* End of Modification - LS */
		
		super.action();
	}
	
	/* Start of Modification - LS */
	/* PSSD_EAMS_IN_2010_005_PM Audit Enhancement */

	public void validate()
		throws MXException, RemoteException
	{
		super.validate();
		
		WOCustom wo = (WOCustom) getMboValue().getMbo();
		if(!wo.getInternalStatus().equals("WAPPR"))
		{
			 /* * 02-10-2020
             * <START> - Code below has been commented as part of the Chart of Accounts restructure
             * Going forward the main account and sub-account will be merged as the second component of the GL account.
             * 
             * 						GLCOMP1		- GLCOMP2					-GLCOMP3	-GLCOMP4		-GLCOMP5	-GLCOMP6		-GLCOMP7		-GLCOMP8
             * Old Account Format: Company (3)	- Main Acc (4)			 	-Type(1)	-LOB(2)		 	-InterCo(3) -Resp Center(4)	-Sub (4)		-Local (3)
             * New Account Format: Company (3)	- Main Acc (4)+ Sub Acc(3) 	-LOB(3)		-Resp Center(4) -InterCo(3) -Future1(4)		-Future2(4)     - NA  
			 * 
			String mainacc = "";
            String subacc = "";
            
            
            
            mainacc = wo.getString("GLACCOUNT").substring(4, 8);
            subacc = wo.getString("GLACCOUNT").substring(23, 27);
            
			* 
			* <END>
			* 
            */
			String glAcct = wo.getString("GLACCOUNT").substring(4, 11);
			
			
            MboSetRemote worktypeset = MXServer.getMXServer().getMboSet("WORKTYPE", wo.getUserInfo());
    		SqlFormat sqlformat = new SqlFormat("worktype = :1");
    		sqlformat.setObject(1, "WORKTYPE", "worktype", wo.getString("WORKTYPE"));
    		worktypeset.setWhere(sqlformat.format());
            
    		MboRemote worktype = worktypeset.getMbo(0);
    		
    		/* * 02-10-2020
             * <START> - Code below has been commented as part of the Chart of Accounts restructure
             
             if(!worktype.getString("GLACCOUNT").substring(4, 8).equals(mainacc) || !worktype.getString("GLACCOUNT").substring(23, 27).equals(subacc)) 
             
             *
             * <END>
            */
    		
    		if (!worktype.getString("GLACCOUNT").substring(4,11).equals(glAcct))
            {
            	String param[] = { worktype.getString("WORKTYPE") };
            	throw new MXApplicationException("workorder", "WorktypeDiffGL", param);
            }
		}
	}
	/* End of Modification - LS */
}
