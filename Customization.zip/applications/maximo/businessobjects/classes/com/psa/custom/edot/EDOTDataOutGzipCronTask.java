/*
 * Modification history 
 * 
 * 27-10-11 YCH Creation
 * 
 * This class is cron task to retrieve ED-OT records as flat file for Resource System
 * 
 * 27-02-2014   WMJ     EMS-773 [EDOT]Gzip and gunzip EDOT files sent between Maximo and EDOT
 * 
 */

package com.psa.custom.edot;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.io.File;

import psdi.app.system.CrontaskInstanceRemote;
import psdi.app.system.CrontaskParamInfo;
//import psdi.custom.common.MxDatabase;
//import psdi.custom.common.MxFileCopy;
//import psdi.custom.ois.MxLog;
import psdi.iface.mic.MicUtil;
import psdi.server.SimpleCronTask;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;

import com.psa.custom.common.MxDatabase;
import com.psa.custom.ois.MxLog;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxSCP;
import com.psa.custom.common.MxZip;

public class EDOTDataOutGzipCronTask extends SimpleCronTask 
{
	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
	private static final String SPACE = " ";
	private static final String OTTRANS_FILENAME = "edot.txt";
	//private static final String ZIP_EXT = ".gz";
	private static final String dotdot = ":";

	//Email paramaters	
    protected String adminEmail;                //Adminstrator Email
    protected String emailSubj;                 //Alert Email Subject
    
    private MxEmail email;

	
	//Parameters
	protected String zipExec; //Executable/Command for zip function
	protected boolean enableLog; //Enable Log
	protected String logFilePath; //Filename and Directory where log file will be placed
	protected String processDirectory; // Directory where processing are done
	
	protected String otOutputFilePath; //Filename and Full Path for OT Transaction Output File
	protected String otArchiveFilePath; //Filename and Full Path for OT Transaction Archive File
	
	protected boolean purgeData; //Purge data from table?
	
	protected int extractday; //No. of days before current date to extract data

	protected String scpConfigFile;     //SCP - Configuration File
	protected String remoteFilePath;    //Path where export file will be placed
	protected String remoteServer;              //Remote server tor SCP push the flatfile
	protected String ZIP_EXT;                //Export File Extension
	
	//For Cron Task
	protected String qualifiedInstanceName;
	
	protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.integration");
	protected MxLog mxLog;
	
	protected boolean initialized;
	
	public EDOTDataOutGzipCronTask() {
		super();
		
		initialized = false;
		qualifiedInstanceName = null;
		
		//Init Parameters
		zipExec = null;
		logFilePath = null;
		enableLog = false;
		purgeData = false;
		processDirectory = null;
		otOutputFilePath = null;
		
		extractday = 1;
		
		scpConfigFile=null;
		remoteFilePath=null;
		remoteServer=null;
		ZIP_EXT=null;
		
		email = new MxEmail(adminEmail);
	}
	
	/**
	 * @author YCH
	 * @function refreshSettings
	 * @date Oct 27, 2011
	 * @comment Refresh Cron Task setting
	 */
	private void refreshSettings()
	{
		try
		{
			//Parameter for zip
			zipExec = getParamAsString("ZIPEXEC");
			
			//Output Path and File Name
			DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
			
			//No. of days before current date to extract data
			extractday = getParamAsInt("EXTRACTDAY");
			// Set to able how many days before to extract
			Date curDate = new Date();
			Date fileDate = new Date(curDate.getTime() - ((extractday - 1) * 24L * 60L * 60L * 1000L));
			
			String fileDateStr = fileDateFormat.format(fileDate);
			
			otOutputFilePath = getParamAsString("OTOUTPUTFILEPATH").replaceAll("yyyymmdd", fileDateStr);
			otArchiveFilePath = getParamAsString("OTARCHIVEFILEPATH").replaceAll("yyyymmdd", fileDateStr);
			
			//Log
			logFilePath = getParamAsString("LOGFILEPATH").replaceAll("yyyymmdd", fileDateStr);
			enableLog = (getParamAsString("ENABLELOG").toUpperCase().compareTo("Y") == 0);
			
			mxLog.setEnabled(enableLog);
			mxLog.setLogFilePath(logFilePath);
			mxLog.setLogTag(getName());
			mxLog.createLogFile();
			
			//Directory where processing are done
			processDirectory = getParamAsString("PROCESSDIRECTORY");
			
            //Paramaters for SCP
          	scpConfigFile = getParamAsString("SCPCONFIGFILE");
          	remoteFilePath = getParamAsString("REMOTEFILEPATH");
          	remoteServer = getParamAsString("REMOTESERVER");
          	ZIP_EXT = getParamAsString("IMPFILEEXT");			
			
			//Purge Data?
			purgeData = (getParamAsString("PURGEDATA").toUpperCase().compareTo("Y") == 0);
			
			//Email
            adminEmail = getParamAsString("ALERTEMAIL");
            email.setAdmin(adminEmail);
            emailSubj = getParamAsString("ALERTEMAILSUBJ");

		}
		catch (Exception exception)
		{
			if (integrationLogger.isErrorEnabled())
				integrationLogger.error(exception.getMessage(), exception);
		}
	}
	
	/**
	 * @author YCH
	 * @function init
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function] Initialize cron task
	 */
	public void init() throws MXException
	{
		super.init();
		
		mxLog = new MxLog();
		initialized = true;
	}

	/**
	 * @author YCH
	 * @function start
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function] Start cron task
	 */
	public void start()
	{
		try
		{
			refreshSettings();
			
			mxLog.writeLog(getName() + ".start()");
			
			integrationLogger.info("[" + getName() + "] Start");
			setSleepTime(0L);
		}
		catch (Exception exception)
		{
			if (integrationLogger.isErrorEnabled())
				integrationLogger.error(exception.getMessage(), exception);
		}
	}
	
	/**
	 * @author YCH
	 * @function stop
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function]Stop cron task
	 */
	public void stop()
	{
		try
		{
			mxLog.writeLog(getName() + ".stop()");
			mxLog.closeLogFile();
		}
		catch (Exception exception)
		{
			if (integrationLogger.isErrorEnabled()) 
				integrationLogger.error(exception.getMessage(), exception);
		}
		
		integrationLogger.info("[" + getName() + "] Stop");
	}
	
	/**
	 * @author YCH
	 * @function setCrontaskInstance
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function] Set cron task instance
	 */
	public void setCrontaskInstance(CrontaskInstanceRemote crontaskinstanceremote)
	{
		try
		{
			super.setCrontaskInstance(crontaskinstanceremote);
			qualifiedInstanceName = crontaskinstanceremote.getString("crontaskname") + "." + crontaskinstanceremote.getString("instancename");
		}
		catch (Exception exception)
		{
			integrationLogger.error(exception.getMessage(), exception);
		}
	}
	
	/**
	 * @author YCH
	 * @function isReqParamSet
	 * @date Oct 27, 2011
	 * @comment returns true if all required parameter is set
	 */
	private boolean isReqParamSet()
	{
		if (processDirectory == null)
			return false;
		if (otOutputFilePath == null)
			return false;
		if (otArchiveFilePath == null)
			return false;
			
		if (processDirectory == null)
			return false;
		if (otOutputFilePath == null)
			return false;
		if (otArchiveFilePath == null)
			return false;
			
		if(adminEmail==null) return false;
		if(emailSubj==null) return false;

		return true;
	}

	
	/** 
	* Author: WMJ
    * Date: 28 Feb 2014
    * Comment: Generate Email
    */

    private String genEmail(Exception e)
    {
	    mxLog.writeLog(getName() + ".genEmail():Start genEmail Action");
	
	    //Form Email Message
	    String emailMsg = "Date: " + new Date()+"\n";
	    emailMsg += "Error in CronTask: "+getName()+ "\n";
	    emailMsg+="Error Message: "+ e.getMessage()+"\n";
	    emailMsg+="Detail:\n";
	    emailMsg+=e.toString()+"\n";
	    StackTraceElement element[] = e.getStackTrace();
	    for(int i=0; i< element.length; i++)
	    {
	    	emailMsg+="\tat "+ element[i].toString()+"\n";
	    }
	    
	    mxLog.writeLog(getName() + ".genEmail():End genEmail Action");
	
	    return emailMsg;
    }	
	
	/**
	 * @author YCH
	 * @function cronAction
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function]
	 */
	public void cronAction() 
	{
		try
		{
			mxLog.writeLog(getName() + ".cronAction():[info]Start CronTask Action");
			
			if (!initialized)
			{
				mxLog.writeLog(getName() + ".cronAction():[Error]CronTask not initialized!");
				throw new Exception(getName() + ".cronAction():[Error]CronTask not initialized!");
			}
			
			// Refresh setting before perform cron action
			refreshSettings();
			
			if (!isReqParamSet())
			{
				mxLog.writeLog(getName() + ".cronAction(): Required parameters not set.");
				throw new Exception("Required parameters not set.");
			}
			
			//Generate the output flat files
			processData();
			
			//Start of main part of EMS-773
			
			//Copy and Zip Flat Files to Output and Archive Directory
			depositFile();
			
			//SCP the file over to EDOT(Roster) server
			if(scpFile())
			{
				mxLog.writeLog(getName()+".cronAction(): SCP encoutered error, please check");
				throw new Exception("SCP encoutered error.");
				
			}

			
			//End of main part of EMS-773
			
			
			mxLog.writeLog(getName() + ".cronAction():[Info]End CronTask Action");
		}
		catch (Exception e)
		{
			mxLog.writeLog("[ERROR] " + e.getMessage());
			
			integrationLogger.error("[" + getName() + "] " + e.getMessage(), e);
			
			//to send an email for exception 
			String emailContent = genEmail(e);
            email.send(emailSubj,emailContent );
            mxLog.writeLog("Email Sent:\n"+emailContent);
			
			stop();
		}
	}
	
	/**
	 * @author WMJ
	 * @function scpFile
	 * @date 28 Feb 2014
	 * @comment returns true if SCP is without error. Else function will return false
	 */
	private boolean scpFile()
	{
		boolean scpsuccess = true;
		
		//check if file exists in output directory. if not throw error
		File dataFile = new File(otOutputFilePath + ZIP_EXT);
		
		try
		{
                        
	        if (dataFile.exists()) 
	        {
	            //////////////////////
	            // Get File Using SCP
	            //////////////////////
	
	            mxLog.writeLog(getName()+".scpFile(): Starting SCP, sending "+otOutputFilePath + ZIP_EXT+" to "+ remoteServer +"..." );        
	
	            // Get file from remote Server
	            MxSCP scp = new MxSCP();
	
	            String scpParam = scpConfigFile + SPACE + otOutputFilePath + ZIP_EXT + SPACE + 
	                    remoteServer + dotdot +  remoteFilePath;
	                    
				mxLog.writeLog(getName()+".scpFile(): SCP command executed: <"+ scpParam +">" );                                            
	
	            if (scp.getFlatFile(scpParam) != 0) 
	            {
	            	mxLog.writeLog(getName()+".scpFile(): SCP failed.");
	            	scpsuccess = false;
	            	throw new Exception("Cannot send file - "+otOutputFilePath + ZIP_EXT+".");
	            	
	            }
	            else
	            {
		            mxLog.writeLog(getName()+".scpFile(): SCP done with no errors.");
		        }
		        
		        //Delete the file
				dataFile.delete();            	
	
	        }
        
    	} 
    	catch (Exception e) 
    	{
			mxLog.writeLog("[ERROR] " + e.getMessage());
			
			integrationLogger.error("[" + getName() + "] " + e.getMessage(), e);
			
			//to send an email for exception 
			String emailContent = genEmail(e);
            email.send(emailSubj,emailContent );
            mxLog.writeLog("Email Sent:\n"+emailContent);
			
			stop();
    	}
        
        //return true if scp is without errors. Else return false
		return scpsuccess;
	}
	
	/**
	 * @author YCH
	 * @function depositFile
	 * @date Oct 27, 2011
	 * @comment Copy and Zip Flat Files to Output and Archive Directory modification, 
	 * Do not throw exception when the transaction has been processed
	 * @throws Exception
	 */
	private void depositFile() throws Exception
	{
		mxLog.writeLog(getName() + ".depositFile():[Info]Start depositing output file");
		
/*		File chkOTArchFile = new File(otArchiveFilePath + ZIP_EXT);
		if (chkOTArchFile.exists())
		{
			//Transaction for the day has been processed before.
			//Do not throw exception when the transaction has been processed
			mxLog.writeLog(getName() + ".depositFile():[Warning]Archive files already exist; transactions have been processed before");
			return;
		}
*/		
		//MxFileCopy.fileCopy(processDirectory + OTTRANS_FILENAME, otArchiveFilePath);
		MxFileCopy.fileCopy(processDirectory + OTTRANS_FILENAME, otOutputFilePath);
		
		//Zip Flat Files
		String cmd = zipExec + SPACE + otOutputFilePath;
		mxLog.writeLog(getName() + ".depositFile():[Info]Zip using cmd: " + cmd);
		int retcode = MxZip.zipFile(cmd);
		if (retcode != 0)
		{
			mxLog.writeLog(getName() + ".depositFile():[Error] Unable to zip file - " + otOutputFilePath);
			throw new Exception(getName() + ".depositFile(): Unable to zip file - " + otOutputFilePath);
		}
		
		MxFileCopy.fileCopy(otOutputFilePath + ZIP_EXT, otArchiveFilePath);
		
		//MxFileCopy.fileCopy(processDirectory + OTTRANS_FILENAME, otOutputFilePath);

		mxLog.writeLog(getName() + ".depositFile():[Info]Finish depositing output file");
	}
	
	/**
	 * @author YCH
	 * @function writeOTTrans
	 * @date Oct 27, 2011
	 * @comment Generate the OT Transaction flat file Modification
	 * 
	 * @param conn
	 * @throws SQLException
	 * @throws IOException
	 */
	private void writeOTTrans(Connection conn) throws SQLException, IOException
	{
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		EDOTFile edotfile = null;
		try
		{
			mxLog.writeLog(getName() + ".writeJobTrans():[Info]Start processing OT transactions...");

			/*
			 * SELECT (SELECT IC FROM PERSON WHERE PERSONID = LABORCODE),
			 *        REFWO,
			 *        to_char(STARTDATE, 'ddmmyyyy')||to_char(STARTTIME,'hh24mi'),
			 *        to_char(FINISHDATE,'ddmmyyyy')||to_char(FINISHTIME, 'hh24mi'),
			 *        LABORCODE,
			 *        PSA_VERIFIEDBY, //New Field
			 *        (SELECT DISPLAYNAME FROM PERSON WHERE PERSONID = PSA_VERIFIEDBY),
			 *        to_char(PSA_VERIFIEDDATE, 'ddmmyyyyhh24mi'),  
			 * 		  PSA_APPROVEDBY, //New Field
			 *        (SELECT DISPLAYNAME FROM PERSON WHERE PERSONID = PSA_APPROVEDBY),
			 *        to_char(PAYMENTTRANSDATE, 'ddmmyyyyhh24mi'),
			 *        LABTRANSID,
			 *        PSA_REMARKS //New Field
			 *   FROM LABTRANS
			 *  WHERE TRUNC(PAYMENTTRANSDATE) = TRUNC(SYSDATE) - X
			 *    AND PSA_OT_FLAG = 1
			 *    AND PAYMENTTRANSDATE < SYSDATE
			 *    AND GENAPPRSERVRECEIPT = 1 
			 *    AND VERIFIED = 1;	
			 * 
			 */

			String otSqlStmt = "SELECT "
				+ "(SELECT IC FROM PERSON WHERE PERSONID = LABORCODE) AS ICNO, " //IC No. 
				+ "REFWO, "  //Reference Work Order
				+ "to_char(STARTDATE, 'ddmmyyyy')||to_char(STARTTIME,'hh24mi') AS STARTTIME, " //OT Start Time 
				+ "to_char(FINISHDATE, 'ddmmyyyy')||to_char(FINISHTIME, 'hh24mi') AS FINISHTIME, " //OT Finish Time
				+ "LABORCODE, " //User ID
				+ "PSA_VERIFIEDBY AS VERIFIED_ID, " //Verified By User ID
				+ "(SELECT DISPLAYNAME FROM PERSON WHERE PERSONID = PSA_VERIFIEDBY) AS VERIFIED_NAME, " //Verified By User Name
				+ "to_char(PSA_VERIFIEDDATE, 'ddmmyyyyhh24mi') AS VERIFIED_DATE, " //Verified Date
				+ "PSA_APPROVEDBY AS APPROVED_ID, " //Approved By User ID
				+ "(SELECT DISPLAYNAME FROM PERSON WHERE PERSONID = PSA_APPROVEDBY) AS APPROVED_NAME, " //Approved By User Name 
				+ "to_char(PAYMENTTRANSDATE, 'ddmmyyyyhh24mi') AS APPROVED_DATE, " //Approved Date
				+ "LABTRANSID, " //Maximo OT ID
				+ "PSA_REMARKS " //OT Remarks
				+ "FROM "
				+ "LABTRANS WHERE TRUNC(PAYMENTTRANSDATE) = TRUNC(SYSDATE) - "
				+ extractday
				+ " AND PSA_OT_FLAG = 1 "
				+ "AND PAYMENTTRANSDATE < TRUNC(SYSDATE) "  
				+ "AND GENAPPRSERVRECEIPT = 1 "
				+ "AND PSA_VERIFIED = 1";
			
			mxLog.writeLog(getName() + ".writeJobTrans():[Info]SQL Statement - " + otSqlStmt);
			pstmt = conn.prepareStatement(otSqlStmt);
			rs = pstmt.executeQuery();
			
			edotfile = new EDOTFile(processDirectory + OTTRANS_FILENAME);
			
			int count = 0;
			
			while (rs.next())
			{
				ArrayList lst = new ArrayList();
				
				// IC No.
				String icNo = rs.getString("ICNO");
				String sIcNo = EDOTFile.padString(icNo, SPACE, 20, false);
				lst.add(sIcNo);
				
				// Ref WO
				String refWO = rs.getString("REFWO");
				lst.add(EDOTFile.padString(refWO, SPACE, 10, false));
				
				// OT Start Time
				String otStratTime = rs.getString("STARTTIME");
				lst.add(EDOTFile.padString(otStratTime, SPACE, 12, false));
				
				// OT Finish Time
				String otFinishTime = rs.getString("FINISHTIME");
				lst.add(EDOTFile.padString(otFinishTime, SPACE, 12, false));
				
				// User ID
				String userID = rs.getString("LABORCODE");
				lst.add(EDOTFile.padString(userID, SPACE, 30, false));
				
				// Verify User ID
				String verifyUserID = rs.getString("VERIFIED_ID");
				lst.add(EDOTFile.padString(verifyUserID, SPACE, 30, false));
				
				// Verify User Name
				String verifyUserName = rs.getString("VERIFIED_NAME");
				lst.add(EDOTFile.padString(verifyUserName, SPACE, 62, false));
				
				// Verify Date
				String verifyDate = rs.getString("VERIFIED_DATE");
				lst.add(EDOTFile.padString(verifyDate, SPACE, 12, false));
				
				// Approval User ID
				String approvedUserID = rs.getString("APPROVED_ID");
				lst.add(EDOTFile.padString(approvedUserID, SPACE, 30, false));
				
				// Approval User Name
				String approvedUserName = rs.getString("APPROVED_NAME");
				lst.add(EDOTFile.padString(approvedUserName, SPACE, 62, false));
				
				// Approval Date
				String approvedDate = rs.getString("APPROVED_DATE");
				lst.add(EDOTFile.padString(approvedDate, SPACE, 12, false));
				
				// Maximo OT ID
				int mxOTId = rs.getInt("LABTRANSID");
				lst.add(EDOTFile.padString(String.valueOf(mxOTId), SPACE, 12, false));
				
				// Remarks
				String remarks = rs.getString("PSA_REMARKS");
				lst.add(EDOTFile.padString(remarks, SPACE, 100, false));
				
				 //Write OT Transaction Line
				edotfile.writeTransRec(lst);
				count = count + 1;
			}
			
			mxLog.writeLog(getName() + ".writeOTTrans():[Info]Total number of records: " + count);
						
			edotfile.close();
			
			rs.close();
			pstmt.close();
			
			mxLog.writeLog(getName() + ".writeOTTrans():[Info]End processing OT transactions...");
		}
		catch (SQLException e)
		{
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			throw e;						
		} 
		finally {	                    	
       		try {
       			if (rs != null)
    				rs.close();
    			if (pstmt != null)
    				pstmt.close();
    			if (edotfile != null)
    				edotfile.close();
       		} 
       		catch(Exception e){
       			MicUtil.INTEGRATIONLOGGER.error(e.getMessage(), e);
       		}
       	}
	}
	
	/**
	 * @author YCH
	 * @function processData
	 * @date Oct 27, 2011
	 * @comment Generate the flat file
	 * @throws Exception
	 */
	private void processData() throws Exception
	{
		MxDatabase db = null;
		Connection conn = null;
		
		try
		{
			mxLog.writeLog(getName() + ".processData():[Info]Start processing ...");
			
			db = new MxDatabase(getRunasUserInfo());
			conn = db.getConn();
			
			writeOTTrans(conn);
			
			db.releaseResources();
			mxLog.writeLog(getName() + ".processData():[Info]Finished processing ...");
		}
		catch (Exception e)
		{
			if (db != null)
				db.releaseResources();
			throw e;
		}
	}
	
	/**
	 * @author YCH
	 * @function getParameters
	 * @date Oct 27, 2011
	 * @comment [Standard Cron Task Function] Get the parameter from Cron Task.
	 */
	public CrontaskParamInfo[] getParameters() throws MXException, RemoteException
	{
		return params;
	}
	
	//CronTask Parameters
	protected static CrontaskParamInfo params[];
	static
	{
		//Set the number of the parameter.  
	      params = null;
	      params = new CrontaskParamInfo[13];

	      //All the parameter configurable from Cron Task user interface 

	      params[0] = new CrontaskParamInfo();
	      params[0].setName("ZIPEXEC");
	      params[0].setDescription("CommonCron","Executable for ziping the flat file.");
	      params[0].setDefault("gzip -f -q");

	      params[1] = new CrontaskParamInfo();
	      params[1].setName("OTOUTPUTFILEPATH");
	      params[1].setDescription("CommonCron","OT Transaction Output path and filename(Add 'yyyymmdd' to add date to filename)");
	      params[1].setDefault("/opt/psa/data/rw/emsscp/outgoing/edot/EDOT_yyyymmdd");

	      params[2] = new CrontaskParamInfo();
	      params[2].setName("OTARCHIVEFILEPATH");
	      params[2].setDescription("CommonCron","OT Transaction Archive path and filename (Add 'yyyymmdd' to add date to filename)");
	      params[2].setDefault("/opt/psa/data/rw/emsscp/outgoing/edot/archive/EDOT_yyyymmdd");

	      params[3] = new CrontaskParamInfo();
	      params[3].setName("PROCESSDIRECTORY");
	      params[3].setDescription("CommonCron","Directory where processing will be done.");
	      params[3].setDefault("/opt/psa/data/rw/emsscp/outgoing/edot/temp/");

	      params[4] = new CrontaskParamInfo();
	      params[4].setName("ENABLELOG");
	      params[4].setDescription("CommonCron","Enable log output('Y' or 'N').");
	      params[4].setDefault("Y");
	      
	      params[5] = new CrontaskParamInfo();
	      params[5].setName("LOGFILEPATH");
	      params[5].setDescription("CommonCron","Log Directory and Filename.");
	      params[5].setDefault("/opt/psa/data/maximo/log/edot/edotout_yyyymmdd.log");

	      params[6] = new CrontaskParamInfo();
	      params[6].setName("EXTRACTDAY");
	      params[6].setDescription("CommonCron","[Integer]No. of days before current date to extract data (default:1 for yesterday).");
	      params[6].setDefault("1");

          params[7] = new CrontaskParamInfo();
          params[7].setName("REMOTESERVER");
          params[7].setDescription("CommonCron","Username@RemoteServer to SCP push to");
          params[7].setDefault("edotscp@ROSTER1be1");
          
          params[8] = new CrontaskParamInfo();
          params[8].setName("REMOTEFILEPATH");
          params[8].setDescription("CommonCron","Remote Path of the output flat file.");
          params[8].setDefault("/opt/psa/rel/be/rms/ctrs/rosterfile/edot/input/");
  
          params[9] = new CrontaskParamInfo();
          params[9].setName("SCPCONFIGFILE");
          params[9].setDescription("CommonCron","SCP Config File");
          params[9].setDefault("/opt/psa/rel/config/emsadm/scp.sh");
  
          params[10] = new CrontaskParamInfo();
          params[10].setName("IMPFILEEXT");
          params[10].setDescription("CommonCron","Extension of the input flat file package.");
          params[10].setDefault(".gz");

          params[11] = new CrontaskParamInfo();
          params[11].setName("ALERTEMAILSUBJ");
          params[11].setDescription("CommonCron","Email Subject for the Alert Email.");
          params[11].setDefault("[EMS-PROD-EDOT] ERROR: Error occured in ED Overtime Data Out CronTask");
  
          params[12] = new CrontaskParamInfo();
          params[12].setName("ALERTEMAIL");
          params[12].setDescription("CommonCron","Admin email address for notification of error.");
          params[12].setDefault("emsteam_req@psa.com.sg");
            
	}
}
