/*
 * Modification history
 * 10-04-07     AGD     SR-086  Set craft if department doesn't belong to list of CT departments
 * 22-11-2012	WMJ	EMS-515	[Interface]Peoplesoft Crontask
 */
package com.psa.custom.sms;

import java.rmi.RemoteException;
import java.util.List;

import psdi.iface.mic.StructureData;
import psdi.iface.migexits.UserExit;
import psdi.util.MXException;

public class StaffInfoInUser extends UserExit
{

        public StructureData setUserValueIn(StructureData irData, StructureData erData)
                        throws MXException, RemoteException
        {
                if (!getMaxIfaceControl().getListControl(getExtSystem(), "CTDEPARTMENTS").contains(irData.getCurrentData("DEPARTMENT")))
                {
                        List list = irData.getChildrenData("LABOR");
                        if (list != null && list.size() > 0)
                        {
                                irData.setAsCurrent(list, 0);
                                list = irData.getChildrenData("LABORCRAFTRATE");
                                if (list != null && list.size() > 0)
                                {
                                        irData.setAsCurrent(list, 0);
                                        irData.setCurrentData("CRAFT", getMaxIfaceControl().getValueControl(getExtSystem(), "CRAFT-NCT"));
                                }
                                else
                                        integrationLogger.error("XML is not well formed: no LABORCRAFTRATE tag");
                        }
                        else
                                integrationLogger.error("XML is not well formed: no LABOR tag");
                }
                return irData;
        }
}

