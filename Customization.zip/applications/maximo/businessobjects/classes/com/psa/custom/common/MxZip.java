/**
 * @author	HCHA
 * Date		Feb 28, 2006
 * Comment	 
 */
package com.psa.custom.common;

import java.io.IOException;

/**
 * @author		HCHA
 * @class		MxUnzip
 * @date		Feb 28, 2006
 * @function	Zip/Unzip the file by lauching the shell command
 */
public class MxZip {

	static public int unzipFile(String cmd) 
		throws IOException, InterruptedException
	{
		Process proc;
		
		// Execute external command 
		try {
			proc = Runtime.getRuntime().exec(cmd);

            int exitVal = proc.waitFor();
    		
            return exitVal;
    		
		} 
		catch (IOException e) {
			throw new IOException(e.getMessage());			 
		} 
		catch (InterruptedException e) {
			throw new InterruptedException(e.getMessage());	
		}
	}
	
	static public int zipFile(String cmd) 
		throws IOException, InterruptedException
	{
		Process proc;
		
		// Execute external command 
		try {
			proc = Runtime.getRuntime().exec(cmd);
	
	        int exitVal = proc.waitFor();
			
	        return exitVal;
			
		} 
		catch (IOException e) {
			throw new IOException(e.getMessage());			 
		} 
		catch (InterruptedException e) {
			throw new InterruptedException(e.getMessage());	
		}
	}
}
