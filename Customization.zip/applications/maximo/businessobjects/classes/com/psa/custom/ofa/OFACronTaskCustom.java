/*
 * Enhanced  by BCT 
 * 
 * Modified Existing class
 * 
 * integrating the OFA record to Maximo Using this cron task file
 * 
 * 16-03-16 WMJ EMS-1031 [Crontask]OFA crontask unable to pick up file to process
 * 
 */
package com.psa.custom.ofa;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.mail.MessagingException;
import javax.management.loading.PrivateClassLoader;

import com.psa.custom.common.MxEmail;
import com.psa.custom.common.MxFileCopy;
import com.psa.custom.common.MxZip;
import com.psa.custom.exchangerate.SimpleFilenameFilter;

import psdi.app.asset.AssetSetRemote;
import psdi.app.location.LocationSetRemote;

import psdi.app.system.CrontaskParamInfo;
import psdi.iface.load.RecoveryService;
import psdi.iface.mic.MicUtil;

import psdi.mbo.DBShortcut;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.server.MaxVarServiceRemote;
import psdi.server.SimpleCronTask;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.util.logging.MXLogger;
import psdi.util.logging.MXLoggerFactory;


public class OFACronTaskCustom extends SimpleCronTask {

	
		protected static final MXLogger integrationLogger = MXLoggerFactory.getLogger("maximo.crontask.OFACronTaskCustom");
	 	private static CrontaskParamInfo params[];
	 	private static final String FILE_DATE_TIME_FORMAT = "yyyyMMdd";
	 	 private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+08:00'";
	 	private static final String SPACE = " ";
	 	 private static final String SUBJECT = "[EMS-OFA] Error: Error occured in OFA Cron.";
		private String directory;
	 	private	String unzipExec;              
		private  String processDirectory; 
	    private String splitTag;
	    private String glActTemplate;
	    private File loadDir;
	    private String importFileName;
	    private int noOfDays;
	    private String adminEmailId;
	    private MxEmail email;
	    private RecoveryService recoveryService;
	    private Vector vec;
	    
	  
	    
	public OFACronTaskCustom() {
		directory=null;
		processDirectory=null;
		splitTag=null;
		unzipExec=null;
		loadDir=null;
		importFileName=null;
		noOfDays=0;
		glActTemplate=null;
		adminEmailId=null;
		recoveryService=null;
		vec=null;
		
	}

	 
	public CrontaskParamInfo[] getParameters() throws MXException,
			RemoteException {
	
		return params;
	}

    static
    {
     
        params = null;
        params = new CrontaskParamInfo[8];
        params[0] = new CrontaskParamInfo();
        params[0].setName("ALERTEMAIL");
        params[0].setDescription("CommonCron","Administrator Mail ID");
        params[1] = new CrontaskParamInfo();
        params[1].setName("DIRECTORY");
        params[1].setDescription("CommonCron","LocalDirectory");
        params[2] = new CrontaskParamInfo();
        params[2].setName("GLACTEMPLATE");
        params[2].setDescription("CommonCron","GLAccountTemplate");
        params[3] = new CrontaskParamInfo();
        params[3].setName("PROCESSDIRECTOR");
        params[3].setDescription("CommonCron","TempDirectory");
        params[4] = new CrontaskParamInfo();
        params[4].setName("IMPORTFILENAME");
        params[4].setDescription("CommonCron","FileNameOfTheInputFile");
        params[5] = new CrontaskParamInfo();
        params[5].setName("SPLITTAG");
        params[5].setDefault("~");
        params[5].setDescription("CommonCron","DelimiterFlatFile");
        params[6] = new CrontaskParamInfo();
        params[6].setName("UNZIPEXEC");
        params[6].setDescription("CommonCron","ExecutableUnziping");
        params[7] = new CrontaskParamInfo();
        params[7].setName("DAYS");
        params[7].setDefault("0");
        params[7].setDescription("CommonCron","No of days transaction has to be removed");
    }

    
// Refreshing Cron parameter

	private void refreshSettings() throws RemoteException, MXException
    {
		try
		{
		adminEmailId=getParamAsString("ALERTEMAIL");
		 email.setAdmin(adminEmailId);
		directory=getParamAsString("DIRECTORY");
		loadDir = new File(directory);
		glActTemplate=getParamAsString("GLACTEMPLATE");
		processDirectory=getParamAsString("PROCESSDIRECTOR");
		DateFormat fileDateFormat = new SimpleDateFormat(FILE_DATE_TIME_FORMAT);
        String todayDate=fileDateFormat.format(new Date());
		importFileName = getParamAsString("IMPORTFILENAME").replaceAll("yyyymmdd",todayDate);
		splitTag=getParamAsString("SPLITTAG");
		unzipExec=getParamAsString("UNZIPEXEC");
		noOfDays=getParamAsInt("DAYS");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		//	email.send(SUBJECT,e.getMessage());
		}
		
    }
    
	public void start()
	{
		try {
			refreshSettings();
		} catch (RemoteException e) {
			
			e.printStackTrace();
		} catch (MXException e) {
		
			e.printStackTrace();
		}
	
		super.start();
	}
	// Validating the parameter values 
	 private boolean isReqParamSet() {
	     if (adminEmailId == null)
	             return false;
	     if (directory == null)
	             return false;
	     if (glActTemplate == null)
	             return false;
	     if (processDirectory == null)
             return false;
     if (importFileName == null)
             return false;
     
     if (splitTag == null)
         return false;
     if (unzipExec == null)
         return false;
        return true;
	}

	
	public void cronAction() {
		
		//start of EMS-1031
		try {
			refreshSettings();
		} catch (RemoteException e) {
			
			e.printStackTrace();
		} catch (MXException e) {
		
			e.printStackTrace();
		}
		//end of EMS-1031
		
		try
		{
			if(isReqParamSet())
			{
			integrationLogger.debug("[OFA CRON] Loading");
			MboSetRemote ofa_backMboSet=MXServer.getMXServer().getMboSet("OFABACKUP", getRunasUserInfo());
			if(noOfDays>0)
			{
			//Deleting the data from backup table based on parameter 	
				DBShortcut dbShortcut = new DBShortcut();
				dbShortcut.connect(getRunasUserInfo().getConnectionKey());
				
				String deletetodaysrecords="DELETE OFABACKUP WHERE  CONVERT(DATETIME, CONVERT(DATE, TRANSDATE)) < CONVERT(DATETIME, CONVERT(DATE, GETDATE()))-"+noOfDays+"";
				
				SqlFormat delRecSql=new SqlFormat(deletetodaysrecords);					
				dbShortcut.executeQuery(delRecSql.format());
				dbShortcut.commit();	
				dbShortcut.close();
				
			}
			
			
			if ((importFileName != null) && (directory != null)) {
            
				if (!checkFileExist(importFileName)) {

					integrationLogger.debug("[OFA CRON] unable to read the input file");
             }
				else
				{
					processFolderData(ofa_backMboSet);
					
				}

     } 
			}
			else
			{
				integrationLogger.info("Required Parameters are not set.");
			}
			
			integrationLogger.debug("[OFA CRON] End of cron");
		}
		catch(Exception e)
		{
		
			e.printStackTrace();
			//email.send(SUBJECT,e.getMessage());
			
		}
	
	}
	// Check the file is exist in the specified path 
    public boolean checkFileExist (String fileExtension) {

        SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
        File[] afile = loadDir.listFiles(filter);
                if(afile != null) {
                int i = afile.length;

                if (i > 0)
                {
                                integrationLogger.debug("File found. Leaving checkFileExist");
                                return true;
                }
        }

        integrationLogger.debug("File not found. Leaving checkFileExist");
        return false;
}

 // Processing the OFA interface file
	 public void processFolderData(MboSetRemote ofa_backMboSet) throws MXException,Exception {

         try {
                SimpleFilenameFilter filter = new SimpleFilenameFilter(importFileName);
                
                integrationLogger.debug("[OFA CRON] Processing the folder data");
                 File afile[] = loadDir.listFiles(filter);
                 if(afile != null) {

                         int i = afile.length;
                         int fileprocessed = 0;

                         for(int j = 0; j < i; j++) {

                        	  recoveryService = new RecoveryService(afile[j]); 
                         
                         try {                                                                                                                        

                         String file = processDirectory + afile[j].getName();
                        
                        MxFileCopy.fileCopy(afile[j].toString(), processDirectory + afile[j].getName());

                         //Unzip File
                         String cmd = unzipExec + SPACE + file;
                    
                       int returnUnzipCmd=MxZip.unzipFile(cmd);
                       if (returnUnzipCmd==0)
                            {
                        	
                                 //Get filename without extension
                        	 
                                 int dotPos = file.lastIndexOf(".");
                               
                                String extractedFile = file.substring(0,dotPos);
                                
                                Collection col = parseFlatFile(extractedFile);
                             
                                	ofaRecordProcessing(col,ofa_backMboSet);
                              File fExtractedFile = new File(extractedFile);
                            
                                 fExtractedFile.delete();
                            }
                         }
                            finally {
                                try {
                                        integrationLogger.debug("processFolderData: End Recovery");

                                        recoveryService.endRecovery();
                                }
                                catch(Exception e){
                                        
                                }
                        }
                         fileprocessed++;
                         

                         if(fileprocessed!=0){
                                 
                         }

                        
         
         }

        

}
                 
         }catch(Exception e)
         {
        	 e.printStackTrace();
 			email.send(SUBJECT,e.getMessage());
         }
	 }

	// Parse Interface file and store into the collection
	 private Collection parseFlatFile(String file) throws IOException {

	        
	        Collection col = new Vector();
	        try
	        {
	        	
	        BufferedReader flatfileReader;
	        flatfileReader = new BufferedReader(new FileReader(file));

	        String curLine = flatfileReader.readLine();
	        
	        integrationLogger.debug("[OFA CRON] Read Line: " + curLine);
	       
	        while((curLine = flatfileReader.readLine()) != null)
	        {
	      
	                String[] str = curLine.split(splitTag);
	                
	                integrationLogger.debug("[OFA CRON] No. of Values: " + str.length);
	                integrationLogger.debug("[OFA CRON] Value at Position 3: <" + str[3] +">");
	                integrationLogger.debug("[OFA CRON] Length of Value at Position 3: " + str[3].trim().length());
	                
	                // Skip records with empty Asset Id
	                if (str.length == 8 && str[3].trim().length() == 0 ) {
	                	integrationLogger.debug("[OFA CRON] Skipping Line: " + curLine);
	                	continue;
	                }

	                Vector vec = new Vector();

	                for(int i=0;i<str.length;i++){
	                       
	                        vec.add(str[i].trim());
	                }

	                
	            col.add(vec);
	        }

	        integrationLogger.debug("[OFA CRON] Flat file parsing completed");
	        }
	        catch(Exception e)
	        {
	        	e.printStackTrace();
			//	email.send(SUBJECT,e.getMessage());
	        }
	        return col;
	    }

	// Interface file has been updated into Asset and Location application if data don't exist in location and Asset. it will store into OFABACKUP table
	 private void ofaRecordProcessing(Collection col,MboSetRemote ofa_backMboSet) throws MXException,RemoteException, ParseException, MessagingException, SQLException
	 {
		 
		 DBShortcut dbShortcut = new DBShortcut();
			dbShortcut.connect(getRunasUserInfo().getConnectionKey());
		 DateFormat timeStampFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
		 String errorMessage="";
		 MboRemote ofa_backMbo = null;
	        Iterator iterParsedData = col.iterator();
	        while (iterParsedData.hasNext()) {
	        		try {
						
						
		                 vec = (Vector)iterParsedData.next();
						
		                if(vec.size()!=8) {
							
		                        integrationLogger.debug((String) vec.elementAt(3));
		                        continue;
		                }
		                
		                String OfaAssetLocation = (String) vec.elementAt(3);
						
		                String ofaAssetNum=getOAAssetNum((String) vec.elementAt(2));
						
		                String description = (String) vec.elementAt(4);	   
												
		                String glaccount = (String) vec.elementAt(6);
						
		                String dateStr = (String) vec.elementAt(7);
						
		                SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");
						
		                Date date = dateformat.parse(dateStr);
						
		                String installedDate=timeStampFormat.format(date);
						
		                String changeDate=timeStampFormat.format(date);
						
		            	String	glAccount=formatGLAccount(glaccount,vec);
						
		                if((!OfaAssetLocation.equalsIgnoreCase("") & OfaAssetLocation!=null))
		                {
							
		                	boolean updatedAssetLoc=assetLocationUpdate(OfaAssetLocation,ofaAssetNum,description,installedDate,changeDate,glAccount);
		                	
		                	if(!updatedAssetLoc)
		                	{
		                		 
		    	                		 ofa_backMbo=ofa_backMboSet.addAtEnd();
		    	                		ofa_backMbo.setValue("OAASSETNUM",ofaAssetNum);
		    	                		ofa_backMbo.setValue("LOCATION",OfaAssetLocation);
		    	                		ofa_backMbo.setValue("DESCRIPTION",description);
		    	                		ofa_backMbo.setValue("ORGID","PSAST");
		    	                   		ofa_backMbo.setValue("GLACCOUNT",glAccount);
		    	                		ofa_backMbo.setValue("INSTALLDATE",installedDate);
		    	                		ofa_backMboSet.save();
										
		                	}
		     		
		               	}
					} catch (Exception e) {
						
						ofa_backMboSet.save();
						if (errorMessage.equalsIgnoreCase("")) {
							errorMessage="Error while processing the following data:\n\n"+vec;
							
						}
						else if (!errorMessage.contains(vec.toString())) {
							errorMessage = errorMessage+"\n"+vec;
							
							}
						if(ofa_backMbo!=null){
						String deleteErrorRecords="DELETE FROM OFABACKUP WHERE OFABACKUPID='"+ofa_backMbo.getInt("OFABACKUPID")+"'";
						
						SqlFormat delRecSql=new SqlFormat(deleteErrorRecords);					
						dbShortcut.executeQuery(delRecSql.format());
						dbShortcut.commit();
						}
					}

	                	}
	                if (errorMessage.length()>0) {
	                	MXServer.sendEMail(adminEmailId, adminEmailId, "OFACron Error", errorMessage);
					}
	       	                
	        integrationLogger.debug("[OFA CRON] End of procesing record");
		 
		 
	 }
// getting OFA asset first 2 char  	  
	  private String getOAAssetNum(String assetnum){

	        StringTokenizer stringTokenizer = new StringTokenizer(assetnum, ".");

	        if(stringTokenizer.countTokens()!=2){
	                return assetnum;
	        }

	        stringTokenizer.nextToken(); 

	        return stringTokenizer.nextToken(); 
	    }
	// Formatting the GL code 
	  private String formatGLAccount(String glaccount, Vector vec) throws RemoteException,MXException
	  {
		  
		  MboSetRemote glconfigureset = MXServer.getMXServer().getMboSet("GLCONFIGURE", getRunasUserInfo());
          MaxVarServiceRemote maxvarserviceremote = (MaxVarServiceRemote)MXServer.getMXServer().lookup("MAXVARS");
          String glquestion = maxvarserviceremote.getString("GLQUESTION", "");
          String gldelimiter = glconfigureset.getMbo(0).getString("delimiter");
          String[] glaccountseg = glaccount.split(gldelimiter);
          String glactemplate = getParamAsString("GLACTEMPLATE");
          String[] glactemplateseg = glactemplate.split(gldelimiter);
          if (glactemplateseg.length != glconfigureset.count())
                 throw new MXApplicationException("GLACTEMPLATE","GLACTEMPLATE parameter does not contain the correct number of segments");
          for (int i = 0; i < glactemplateseg.length; i ++)
          {
                  if (glactemplateseg[i].indexOf(glquestion) >= 0)
                          glaccountseg[i] = glactemplateseg[i];
          }
          glaccount = "";
          for (int i = 0; i < glaccountseg.length; i ++)
          {
                  glaccount += glaccountseg[i];
                
                  if (i < glaccountseg.length - 1)
                          glaccount += gldelimiter;
          }
        
          vec.setElementAt(glaccount, 6);
          String glAccount = (String) vec.elementAt(6);
          
          return glAccount;
	  }
// Updating the Asset and Location OFA Asset number and GL Code	  
private boolean assetLocationUpdate(String OfaAssetLocation,String ofaAssetNum,String description,String installedDate,String changeDate, String glAccount)throws MXException,RemoteException
{
	
	boolean fixedAssetupdated=false;
	AssetSetRemote assetMboSet = (AssetSetRemote)MXServer.getMXServer().getMboSet("ASSET",getRunasUserInfo());
	SqlFormat assetSql=new SqlFormat("ASSETNUM=:1");
	
	assetSql.setObject(1, "ASSET", "ASSETNUM", OfaAssetLocation);
	assetMboSet.setWhere(assetSql.format());
	assetMboSet.reset();
	if(!assetMboSet.isEmpty()&& assetMboSet!=null)
	{
		
		fixedAssetupdated=true;
		MboRemote assetMbo=assetMboSet.getMbo(0);
		assetMbo.setValue("OAASSETNUM",ofaAssetNum,2L);
		//assetMbo.setValue("DESCRIPTION",description,2L);
		assetMbo.setValue("INSTALLDATE",installedDate,2L);
		assetMbo.setValue("CHANGEDATE",changeDate,2L);
		assetMbo.setValue("GLACCOUNT",glAccount,2L);
		assetMboSet.save();
		return fixedAssetupdated;
	}
	else
	{
			LocationSetRemote locationMboSet = (LocationSetRemote)MXServer.getMXServer().getMboSet("LOCATIONS",getRunasUserInfo());
			SqlFormat locationSql=new SqlFormat("LOCATION=:1");
			locationSql.setObject(1, "LOCATIONS", "LOCATION", OfaAssetLocation);
        	locationMboSet.setWhere(locationSql.format());
        	if(!locationMboSet.isEmpty()&& locationMboSet!=null)
        	{
        		
        		fixedAssetupdated=true;
        		MboRemote locationMbo=locationMboSet.getMbo(0);
        		locationMbo.setValue("OAASSETNUM",ofaAssetNum,2L);
        		//locationMbo.setValue("DESCRIPTION",description,2L);
        		locationMbo.setValue("GLACCOUNT",glAccount,2L);
        		locationMboSet.save();
        		return fixedAssetupdated;	
        	}
    
	
	}
	
	return fixedAssetupdated;
}
	  
	  public void init() {
	        email = new MxEmail(adminEmailId);
	     

	    }
	 
}
         
                 
