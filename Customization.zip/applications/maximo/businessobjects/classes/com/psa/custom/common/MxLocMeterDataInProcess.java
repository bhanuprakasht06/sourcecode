package com.psa.custom.common;

import psdi.iface.mic.MicConstants;
import psdi.iface.mic.MicSetIn;
import psdi.util.MXException;
import java.rmi.RemoteException;
import psdi.iface.mic.MicSetInfo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;

/**
 * 
 * @author		HCHA
 * @class		MaxLocMeter
 * @date		Feb 25, 2006
 * @function	Inbound Integration Point Processing Class for Location Meter
 */
public class MxLocMeterDataInProcess extends MicSetIn 
{
    public MxLocMeterDataInProcess()
    	throws MXException, RemoteException
    {
    }
    /**
     * Overriden from base class. Set the table to process. 
     * 
     * @external @return PROCESS (means continue to process)
     * 
     * @exception MXException
     *                MAXIMO exception
     * @exception RemoteException
     *                Remote exception
     */
    public int checkBusinessRules() throws MXException, RemoteException
    {
    	INTEGRATIONLOGGER.debug("Entering MxLocMeterDataInProcess.checkBusinessRules");

        this.processTable = "LOCATIONMETER";
        
        INTEGRATIONLOGGER.debug("Leaving MxLocMeterDataInProcess.checkBusinessRules");

        return MicConstants.PROCESS;

    } //checkBusinessRules()

    /**
     * Create mbo set for the correct mbo by using the relationship from the
     * parent mbo. This is required for the all of the METER reading
     * transactions. 
     * 
     * @external @param
     *           primaryMbo Give boolean to specify is it primary table or
     *           additional table
     * @param parentMbo
     *            Give reference to parent Mbo.
     * @param micInfo
     *            Give MicSetInfo for the current level.
     * @param processTable
     *            Give name of table to process
     * 
     * @exception MXException
     *                MAXIMO exception
     * @exception RemoteException
     *                Remote exception
     */
    public MboSetRemote createMboSet(boolean primaryMbo, MboRemote parentMbo,
            MicSetInfo micInfo, String processTable) throws MXException,
            RemoteException
    {
    	INTEGRATIONLOGGER.debug("Entering MxLocMeterDataInProcess.createMboSet");

        MboSetRemote parentMboSet = null;
        MboSetRemote newMbo = null;
        String relationship = processTable;

        //Since this is a merged interface create the correct mbo by first
        // getting the parent mbo, each of the mbos in the merged object
        //needs to be created from a parent mbo.
 
        parentMboSet = MXServer.getMXServer().getMboSet("LOCATIONS",getUserInfo());
        SqlFormat sqfLocation = new SqlFormat(getUserInfo(),"siteid = :1 and location = :2 and status!='DECOMMISSIONED'");

        sqfLocation.setObject(1, "LOCATIONS", "SITEID", struc.getCurrentData("SITEID"));
        sqfLocation.setObject(2, "LOCATIONS", "LOCATION", struc.getCurrentData("LOCATION"));
        parentMboSet.setWhere(sqfLocation.format());


        parentMboSet.reset();

        //make sure the LOCATION is valid
        if (!parentMboSet.isEmpty())
        {
            newMbo = parentMboSet.moveFirst().getMboSet(relationship);
        }
        else
        {
            String[] param =
           { struc.getCurrentData("LOCATION"),
             struc.getCurrentData("SITEID") };
             throw new MXApplicationException("iface",
                      "meter-invalidlocation", param);
        }


        if (parentMboSet != null)
        {
            parentMboSet.close();
        }

        INTEGRATIONLOGGER.debug("Leaving MxLocMeterDataInProcess.createMboSet");

        return newMbo;
    }
}
