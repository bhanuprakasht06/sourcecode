/*
 * Created  by BCT 
 * 
 * PM last completion select action menu.
 * 
 * based on this action PM last completion date will modify.
 * 
 * 
 */
package com.psa.webclient.beans.pm;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import psdi.mbo.MboConstants;
import psdi.mbo.MboRemote;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.system.beans.DataBean;


public class LastCompCustom extends DataBean {

	

	public synchronized int execute() throws MXException, RemoteException {
		
		super.execute();
		Date currentDate = MXServer.getMXServer().getDate();
		MboRemote pmRemote=app.getAppBean().getMbo();
		String lastCompDate=pmRemote.getString("LASTCOMP");
		if(!lastCompDate.equalsIgnoreCase(""))
		{
		if(currentDate.compareTo(pmRemote.getDate("LASTCOMP"))>0)
		{
		//	Date oldCompDate=pmRemote.getDate("LASTCOMPDATE");
		if (!pmRemote.getString("LASTCOMPDATE").equalsIgnoreCase("")) {
			
			
			if(!pmRemote.getBoolean("USETARGETDATE"))
			{
				if ((pmRemote.getInt("FREQUENCY")>0)&& (!pmRemote.getString("NEXTDATE").equalsIgnoreCase("")))
				{
					int frequency=pmRemote.getInt("FREQUENCY");
					String freqUnit=pmRemote.getString("FREQUNIT");
					Calendar scr =new GregorianCalendar();
					scr.setTime(pmRemote.getDate("LASTCOMP"));
					if("DAYS".equalsIgnoreCase(freqUnit))
					{
						scr.add(Calendar.DAY_OF_MONTH, frequency);
					}
					else if("WEEKS".equalsIgnoreCase(freqUnit))
					{
						scr.add(Calendar.WEEK_OF_MONTH, frequency);
					}
					else if("MONTHS".equalsIgnoreCase(freqUnit))
					{
						scr.add(Calendar.MONTH, frequency);
					}
					else if("YEARS".equalsIgnoreCase(freqUnit))
					{
						scr.add(Calendar.YEAR, frequency);
					}
					
			
					pmRemote.setValue("NEXTDATE", scr.getTime(),MboConstants.NOACCESSCHECK);
					
				
				}
		}
			pmRemote.setValue("LASTCOMPDATE", pmRemote.getDate("LASTCOMP"), MboConstants.NOACCESSCHECK);
			
			pmRemote.setValue("COMPFLAG", true);
			
			}
			
		}
		
		else
		{
			throw new MXApplicationException("PM","LastCompDate");
			
		}
		
		this.parent.save();
		
		}
		return 1;
		
	}
	
	

}
