package com.psa.webclient.beans.inventory;

import java.rmi.RemoteException;

import psdi.app.inventory.InvBalancesSetRemote;
import psdi.mbo.MboRemote;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.beans.inventory.AdjustCurBalanceBean;

public class CustAdjustCurBalanceBean extends AdjustCurBalanceBean
{

	public int adjustCurBalance() throws RemoteException, MXException
	{
		InvBalancesSetRemote invbalset = (InvBalancesSetRemote)getMboSet();
		MboRemote mbo = null;
		
		int index=0;
		while((mbo=invbalset.getMbo(index)) != null)
		{
			if (mbo.getString("CONDITIONCODE").equalsIgnoreCase("NEW"))
			{				
				System.out.println("---adjustCurBalance---------------------sum-----------------------------"+(mbo.getMboSet("INVBATCHBINLOTCOND").sum("curbal")+mbo.getMboSet("INVBATCHBINLOTCOND").sum("faultqty")));
				System.out.println("---adjustCurBalance---------------------newcurbal-----------------------------"+mbo.getDouble("newcurbal"));
				if((!mbo.getString("newcurbal").equalsIgnoreCase("")) && ((mbo.getMboSet("INVBATCHBINLOTCOND").sum("curbal")+mbo.getMboSet("INVBATCHBINLOTCOND").sum("faultqty")) != mbo.getDouble("newcurbal")))
					throw new MXApplicationException("psa","adjustbalnotvalid");				
			}
			index++;
		}
		return super.adjustCurBalance();
		  
	}
}
