/*
 * Modification history
 * 09-07-2007	RHA	SR-099	Copy selected RFQ lines to all vendors
 * 24-10-2007	AGD	eRFQ		
 */
package com.psa.webclient.beans.rfq;

import java.rmi.RemoteException;
import psdi.app.rfq.RFQVendorRemote;
import psdi.app.rfq.RFQVendorSetRemote;
import psdi.util.MXException;
import psdi.webclient.beans.rfq.QuotationsVendorBean;
import psdi.webclient.system.controller.Utility;


public class QuotationsVendorCustomBean extends QuotationsVendorBean
{
	public QuotationsVendorCustomBean()
	{
	}


	/**
	 * @comment		Action (via push button "Select RFQ Lines for All Vendors") on screen.
	 * 				All selected lines items will be copied to all vendors.
	 * 				If new vendors or items are added later, the action can be used again
	 * 				and it will add the items as required.
	 * 				This action is the same as the existing "Select RFQ Lines". The only difference 
	 * 				is that the selected lines will be copied to all vendors.
	 */
	public int selrfqlineallvendors()
			throws MXException, RemoteException
	{
//		psdi.webclient.system.controller.WebClientEvent webclientevent = sessionContext.getCurrentEvent();
//		webclientevent = sessionContext.getCurrentEvent();
		try
		{
			RFQVendorSetRemote rfqvendorsetremote = (RFQVendorSetRemote) parent.getMboSet();

			//System.out.println("QuotationsVendorCustomBean Iterating through the vendors.......... ");
			int i = 0;
			for (RFQVendorRemote rfqvendorremote; (rfqvendorremote = (RFQVendorRemote) rfqvendorsetremote.getMbo(i)) != null; i++)
			{
				rfqvendorremote.checkSentCompStatus("cannotCopyQuotation");
			}

		}
		catch (MXException mxexception)
		{
			Utility.showMessageBox(sessionContext.getCurrentEvent(), mxexception);
			return 1;
		}
		return 2;
	}


	/*
	 * Control whether this function can be used
	 */
	public int selrfqlinealt()
			throws MXException, RemoteException
	{
		return super.selrfqline();
	}

}
